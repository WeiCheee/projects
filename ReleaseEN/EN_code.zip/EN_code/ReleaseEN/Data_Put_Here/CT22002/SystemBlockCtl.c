







BYTE chkBzAndSet(QWORD *up64SuccessFlag, BYTE uSetBit)
{
    waitCmdAllDone(cWaitTrigRCnt|cWaitCmdBz);
    // releaseBtSrcAddrInfo();

    // mWaitCmdFifoBz;

    if(rmChkUNC)
    {
        // retry?

        rmChSoftReset;
        setChunkAddr(0);    // HW bug
        resetEcc();
        return cFalse;
    }
    else
    {
        mSet64BitMask(*up64SuccessFlag, uSetBit);
        return cTrue;
    }
}    /* chkBzAndSet */

// //////////////////////////////////////////////
// uOpt :
// Bit4 -1. specific System Block
// Bit5 -1. Put spare byte at beginning
//
//
// |---------------|
// |   Spare Byte  |
// |---------------|
// |               |
// |      Data     |
// |               |
// |_______________|
// //////////////////////////////////////////////
void loadRootPage(WORD u16StrFpage, WORD u16HalfKB, WORD u16BufIdx, BYTE uSpfSysBlk, BYTE uSectorH, BYTE uOpt)
{
    ADDRINFO usTmpAddrInfo;
    BLKSPRINFO *upBlkSprInfo;
    BYTE uCopies, u1stInfo, uHighLoop, uLowLoop, uOddRootAddr=cInvalid8Bit, uEvenRootAddr=cInvalid8Bit, uReadSectCnt, uDoneFlag;
    WORD u16AccuHalfKB=0, u16AccuOneLoopHalfKB=0, u16AccuBufIdx=u16BufIdx, u16AccuFPage=0;
    QWORD u64SuccessFlag=0;

    while(((u16BufIdx+uSectorH+u16HalfKB)>384*2)||(uOpt&(~(cBit5|cBit4))))
        ;

    if(uOpt&cBit4)
    {
        uCopies=1;
        u1stInfo=uSpfSysBlk;
    }
    else if(mChkAllInfoInFL)
    {
        uCopies=2;
        u1stInfo=cSysBlock1stInfo;
    }
    else
    {
        if(mChk1stInfoInFL)
        {
            u1stInfo=cSysBlock1stInfo;
        }
        else if(mChk2ndInfoInFL)
        {
            u1stInfo=cSysBlock2ndInfo;
        }
        else
        {
            while(1)
                ;
        }

        uCopies=1;
    }

    if(uOpt&cBit5)
    {
        u16AccuBufIdx=u16BufIdx+((u16HalfKB/gSectorPerPlaneH)*0x20+(0x200-1))/0x200;    // Hynix V3 256KB need
        u16AccuBufIdx=u16AccuBufIdx+u16AccuBufIdx%2;
    }

    // gbEccFail= 1;

    uHighLoop=0;
    uDoneFlag=0;

    while(!uDoneFlag)
    {
        uLowLoop=0;
        u16AccuOneLoopHalfKB=0;
        u16AccuFPage=0;

        while(u16AccuHalfKB<u16HalfKB)
        {
            if(uLowLoop==64)    // 64bit
            {
                // (Finn) I think it's impossible (512KB)
                break;
            }

            if((uHighLoop&cBit0)&&(mChk64BitMask(u64SuccessFlag, uLowLoop)))
            {
                if(uLowLoop==0)
                {
                    u16AccuHalfKB=gSectorPerPlaneH-uSectorH;
                    u16AccuBufIdx+=u16AccuHalfKB;
                }
                else
                {
                    u16AccuHalfKB+=gSectorPerPlaneH;
                    u16AccuBufIdx+=gSectorPerPlaneH;
                }

                uLowLoop++;
                continue;
            }

            // read flash action
            tranRsvBlkAddr(garSysBlock[u1stInfo+((uLowLoop+uHighLoop)%uCopies)], &usTmpAddrInfo);
            usTmpAddrInfo.u16FPage=u16StrFpage+u16AccuFPage;

            if(uLowLoop==0)
            {
                usTmpAddrInfo.uSectorH=uSectorH;
            }
            else
            {
                usTmpAddrInfo.uSectorH=0;
            }

            if(uLowLoop%uCopies)
            {
                uOddRootAddr=(usTmpAddrInfo.uPlaneAddr<<4)|usTmpAddrInfo.uCh;
            }
            else
            {
                uEvenRootAddr=(usTmpAddrInfo.uPlaneAddr<<4)|usTmpAddrInfo.uCh;
            }

            setFLAddrActCh(usTmpAddrInfo.uCh, &usTmpAddrInfo);
            // tranCeNum(&usTmpAddrInfo);

            // waitCmdFifoDpt(gActiveCh, cFullNorCmdDepth    /*gHalfCmdThr*/, &usTmpAddrInfo);

            if(u16AccuHalfKB==0)
            {
                // first
                uReadSectCnt=gSectorPerPlaneH-usTmpAddrInfo.uSectorH;
            }
            else if(u16AccuHalfKB+gSectorPerPlaneH>=u16HalfKB)
            {
                // last
                uReadSectCnt=u16HalfKB-u16AccuHalfKB;
            }
            else
            {
                uReadSectCnt=gSectorPerPlaneH;
            }

            mSetFRwParam(u16AccuBufIdx, uReadSectCnt, (c16Bit4|c16Bit10|c16Bit13|c16Bit15), cReadData);
            // waitChCeBz(gActiveCh, gIntlvAddr, 0);
            // flashReadPage();
            assignFreeBtSrcAddrInfo();

            if(uOpt&cBit5)
            {
                mSetFRwParam(u16AccuBufIdx, uReadSectCnt, (c16Bit2|c16Bit5|c16Bit13|c16Bit15), cReadData);
                // flashReadPage();

                assignFreeBtSrcAddrInfo();
            }

            // waitCmdAllDone(cWaitTrigRCnt|cWaitCmdBz);
            // releaseBtSrcAddrInfo();

            if(((uHighLoop&cBit0)==0))
            {
                if((((uLowLoop+1)%uCopies)==0)||((u16AccuHalfKB+gSectorPerPlaneH)>=u16HalfKB))
                {
                    if(uEvenRootAddr!=cInvalid8Bit)
                    {
                        setFLActCh(uEvenRootAddr&0x0F);
                        chkBzAndSet(&u64SuccessFlag, uLowLoop-(uCopies-1));

                        if(uOpt&cBit5)
                        {
                            upBlkSprInfo=(BLKSPRINFO *)(&garTsb0[u16BufIdx][((uLowLoop-(uCopies-1))*0x20)]);
                            getSprByte(upBlkSprInfo, (uEvenRootAddr&0xF0)>>4);
                        }
                    }

                    if(uOddRootAddr!=cInvalid8Bit)
                    {
                        setFLActCh(uOddRootAddr&0x0F);
                        chkBzAndSet(&u64SuccessFlag, uLowLoop);

                        if(uOpt&cBit5)
                        {
                            upBlkSprInfo=(BLKSPRINFO *)(&garTsb0[u16BufIdx][(uLowLoop*0x20)]);
                            getSprByte(upBlkSprInfo, (uOddRootAddr&0xF0)>>4);
                        }
                    }
                }
            }
            else
            {
                chkBzAndSet(&u64SuccessFlag, uLowLoop);
            }

            if(uLowLoop==0)
            {
                u16AccuHalfKB=gSectorPerPlaneH-uSectorH;
                u16AccuBufIdx+=gSectorPerPlaneH-uSectorH;
                u16AccuOneLoopHalfKB+=gSectorPerPlaneH-uSectorH;
            }
            else
            {
                u16AccuHalfKB+=gSectorPerPlaneH;
                u16AccuBufIdx+=gSectorPerPlaneH;
                u16AccuOneLoopHalfKB+=gSectorPerPlaneH;
            }

            u16AccuFPage++;
            uLowLoop++;
        }

        if(u64SuccessFlag!=((1<<uLowLoop)-1))    // (QWORD)(cb64BitTab[uLowLoop]-1))
        {
            // check should re-read or not
            u16AccuHalfKB-=u16AccuOneLoopHalfKB;
            u16AccuBufIdx-=u16AccuOneLoopHalfKB;    // later should check buffer wrap

            while(uHighLoop%uCopies)
                ;

            uHighLoop++;
        }
        else
        {
            u16StrFpage+=u16AccuFPage;
            uSectorH=0;
            uHighLoop=(uHighLoop+1)/2*2+2;    // let this value be multiple of 2

            if(u16AccuHalfKB>=u16HalfKB)
            {
                uDoneFlag=1;
            }
        }
    }
}    /* loadRootPage */

void progRootPage(WORD u16StrFpage, BYTE uSysBlkIdx, WORD u16HalfKB, WORD u16BufIdx)
{
    BLKSPRINFO *upBlkSprInfo;
    ADDRINFO usTmpAddrInfo;
    BYTE uLoop;
    WORD u16AccuHalfKB=0;

    tranRsvBlkAddr(garSysBlock[uSysBlkIdx], &usTmpAddrInfo);
    // tranCeNum(&usTmpAddrInfo);
    usTmpAddrInfo.uSectorH=0;
    setFLAddrActCh(usTmpAddrInfo.uCh, &usTmpAddrInfo);

    usTmpAddrInfo.u16BufPtr=u16BufIdx+((u16HalfKB/gSectorPerPlaneH)*0x20+(0x200-1))/0x200;
    usTmpAddrInfo.u16BufPtr=usTmpAddrInfo.u16BufPtr+usTmpAddrInfo.u16BufPtr%2;
    uLoop=0;

    while(u16AccuHalfKB<u16HalfKB)
    {
        usTmpAddrInfo.u16FPage=u16StrFpage;
        // mSetFRwParam(usTmpAddrInfo.u16BufPtr, gSectorPerPlaneH, c16Bit2|c16Bit4|c16Bit14|c16Bit15, cProgData);    /*c16Bit4 is for first 5
        // page using*/
        mSetFRwParam(usTmpAddrInfo.u16BufPtr, (gSectorPerPlaneF*2), c16Bit2|c16Bit4|c16Bit14|c16Bit15, cProgData);    /*c16Bit4 is for first 5
                                                                                                                         * page using*/

        // waitCmdFifoDpt(usTmpAddrInfo.uCh, cFullNorCmdDepth, &usTmpAddrInfo);
        upBlkSprInfo=(BLKSPRINFO *)(&garTsb0[u16BufIdx][(uLoop*0x20)]);
        // upBlkSprInfo->u16Spr11->u16all=g16arCurrSysBlkEsCnt[uSysBlkIdx];
        g16arTsb0[u16BufIdx][(uLoop*0x20)/2+12]=g16arCurrSysBlkEsCnt[uSysBlkIdx];
        setSprByte(upBlkSprInfo, usTmpAddrInfo.uPlaneAddr);
        mSetSprSetDone(gpFlashAddrInfo);    // gpFlashAddrInfo->uSprSetDone=1;
        mSetTabSpr(gpFlashAddrInfo, cBit5);    // gTabSpare=1;
        // waitChCeBz(usTmpAddrInfo.uCh, gIntlvAddr, cNoOp);
        // flashProgPage(usTmpAddrInfo.u16BufPtr, usTmpAddrInfo.uRwHalfKb, usTmpAddrInfo.u16RwOpt);
        // setBzInfo(cProgData, gActiveCh, gIntlvAddr);

        assignFreeBtDesAddrInfo();
        waitCmdAllDone(cWaitTrigWCnt);
        // wait?
        // waitCmdAllDone(cWaitTrigWCnt|cWaitCmdBz);
        // releaseBtDesAddrInfo();
        //
        usTmpAddrInfo.u16BufPtr+=gSectorPerPlaneH;
        u16AccuHalfKB+=gSectorPerPlaneH;
        u16StrFpage++;
        uLoop++;
    }

    waitCmdAllDone(cWaitTrigWCnt|cWaitCmdBz);
    // releaseBtDesAddrInfo();

    // waitCmdFifoDpt(usTmpAddrInfo.uCh, cFullNorCmdDepth, &usTmpAddrInfo);
    // waitChCeBz(usTmpAddrInfo.uCh, gIntlvAddr, cNoOp);
}    /* progRootPage */







