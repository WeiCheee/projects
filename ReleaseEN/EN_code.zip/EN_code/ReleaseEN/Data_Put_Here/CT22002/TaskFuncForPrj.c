







// BootFunc////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
#if _PRJ_BOOT

WORD getDifferAddrCore0(ADDRINFO *upAddrInfo)
{
    TASKENTRY usTskEntry;
    WORD u16FBlock;

    usTskEntry.uTskTyp=cTskGetDifferAddr;
    gsTskFifoCtrl.u16PopFBlk=upAddrInfo->u16FBlock;
    gsTskFifoCtrl.u16PushFBlk=upAddrInfo->uCh;
    gsTskFifoCtrl.u16Seed=upAddrInfo->uIntlvAddr;
    gsTskFifoCtrl.u16EraseCnt=upAddrInfo->uPlaneAddr;

    insertTaskFifo(usTskEntry);

    while(gsTskFifoCtrl.u32HeadPtr!=gsTskFifoCtrl.u32TailPtr)
        ;

    u16FBlock=gsTskFifoCtrl.u16FBlk;

    gsTskFifoCtrl.u16FBlk=c16BitFF;
    gsTskFifoCtrl.u16PopFBlk=c16FBlockInitValue;
    gsTskFifoCtrl.u16PushFBlk=c16FBlockInitValue;
    gsTskFifoCtrl.u16EraseCnt=c16BitFF;

    return u16FBlock;
}    /* getDifferAddrCore0 */

void judgeSwapIspCore0()
{
    TASKENTRY usTskEntry;

    usTskEntry.uTskTyp=cTskJudgeSwapIsp;
    insertTaskFifo(usTskEntry);

    while(gsTskFifoCtrl.u32HeadPtr!=gsTskFifoCtrl.u32TailPtr)
        ;
}

WORD core0GetRndSeed(WORD u16FPage)
{
    TASKENTRY usTskEntry;

    usTskEntry.uTskTyp=cTskCore0GetRndSeed;
    usTskEntry.uTskOpt=0xFF;
    usTskEntry.u16TskSBufPtr=u16FPage;
    insertTaskFifo(usTskEntry);

    while(gsTskFifoCtrl.u32HeadPtr!=gsTskFifoCtrl.u32TailPtr)
        ;

    return gsTskFifoCtrl.u16Seed;
}

void setGlobEraseCnt()
{
    TASKENTRY usTskEntry;

    usTskEntry.uTskTyp=cTskCore1SetGlobEraseCnt;
    usTskEntry.uTskOpt=0xFF;
    usTskEntry.u16TskSBufPtr=c16BitFF;
    insertTaskFifo(usTskEntry);

    while(gsTskFifoCtrl.u32HeadPtr!=gsTskFifoCtrl.u32TailPtr)
        ;
}

void setGlobEraseCnt1Blk(WORD u16FBlk, WORD u16EraseCnt, BYTE uPopBit)
{
    TASKENTRY usTskEntry;

    while(gsTskFifoCtrl.u16FBlk!=0xFFFF)
        ;

    while(gsTskFifoCtrl.u16EraseCnt!=0xFFFF)
        ;

    usTskEntry.uTskTyp=cTskCore1SetGlobEraseCnt1Blk;
    usTskEntry.uTskOpt=uPopBit;
    usTskEntry.u16TskSBufPtr=c16BitFF;
    gsTskFifoCtrl.u16FBlk=u16FBlk;
    gsTskFifoCtrl.u16EraseCnt=u16EraseCnt;

    insertTaskFifo(usTskEntry);

    while(gsTskFifoCtrl.u32HeadPtr!=gsTskFifoCtrl.u32TailPtr)
        ;
}    /* setGlobEraseCnt1Blk */

void getGlobEraseCnt()
{
    TASKENTRY usTskEntry;

    usTskEntry.uTskTyp=cTskCore0GetGlobEraseCnt;
    usTskEntry.uTskOpt=0xFF;
    usTskEntry.u16TskSBufPtr=c16BitFF;
    insertTaskFifo(usTskEntry);

    while(gsTskFifoCtrl.u32HeadPtr!=gsTskFifoCtrl.u32TailPtr)
        ;
}

void getDiffType2Offset()
{
    TASKENTRY usTskEntry;

    usTskEntry.uTskTyp=cTskCore0GetDiffType2Offset;
    usTskEntry.uTskOpt=0xFF;
    usTskEntry.u16TskSBufPtr=c16BitFF;
    insertTaskFifo(usTskEntry);

    while(gsTskFifoCtrl.u32HeadPtr!=gsTskFifoCtrl.u32TailPtr)
        ;
}

void getDiffType2AddrInfo(WORD u16FBlock)
{
    TASKENTRY usTskEntry;

    usTskEntry.uTskTyp=cTskSetDiffType2AddrInfo;
    usTskEntry.uTskOpt=0xFF;
    usTskEntry.u16TskSBufPtr=u16FBlock;
    insertTaskFifo(usTskEntry);

    while(gsTskFifoCtrl.u32HeadPtr!=gsTskFifoCtrl.u32TailPtr)
        ;
}

void chkIspBlockCore0()
{
    TASKENTRY usTskEntry;

    usTskEntry.uTskTyp=cTskChkIspBlock;
    insertTaskFifo(usTskEntry);

    while(gsTskFifoCtrl.u32HeadPtr!=gsTskFifoCtrl.u32TailPtr)
        ;
}

void waitAllChCeBzBtCore0()
{
    TASKENTRY usTskEntry;

    usTskEntry.uTskTyp=cTskWaitAllBz;
    insertTaskFifo(usTskEntry);

    while(gsTskFifoCtrl.u32HeadPtr!=gsTskFifoCtrl.u32TailPtr)
        ;
}

#if (_EN_SLC_END_PARA)
void setSlcEndurParaCore0()
{
    TASKENTRY usTskEntry;

    usTskEntry.uTskTyp=cTskSetSlcEndurPara;
    usTskEntry.uTskOpt=0xFF;
    usTskEntry.u16TskSBufPtr=c16BitFF;
    insertTaskFifo(usTskEntry);

    while(gsTskFifoCtrl.u32HeadPtr!=gsTskFifoCtrl.u32TailPtr)
        ;
}

#endif

#if (_EN_FLASH_WR_CMD)
void flashWriteCmdCore0(WORD u16Fblk)
{
    TASKENTRY usTskEntry;

    usTskEntry.uTskTyp=cTskFlashWriteCmd;
    usTskEntry.uTskOpt=0xFF;
    usTskEntry.u16TskSBufPtr=c16BitFF;

    gsTskFifoCtrl.u16FBlk=u16Fblk;

    insertTaskFifo(usTskEntry);

    while(gsTskFifoCtrl.u32HeadPtr!=gsTskFifoCtrl.u32TailPtr)
        ;
}

#endif/* if (_EN_FLASH_WR_CMD) */

void initSlcQCore0()
{
    TASKENTRY usTskEntry;

    usTskEntry.uTskTyp=cTskInitSlcQ;
    insertTaskFifo(usTskEntry);

    while(gsTskFifoCtrl.u32HeadPtr!=gsTskFifoCtrl.u32TailPtr)
        ;
}

void restoreSlcQCore0(BYTE uOpt)
{
    TASKENTRY usTskEntry;

    usTskEntry.uTskTyp=cTskRestoreSlcQ;
    usTskEntry.uTskOpt=uOpt;
    insertTaskFifo(usTskEntry);

    while(gsTskFifoCtrl.u32HeadPtr!=gsTskFifoCtrl.u32TailPtr)
        ;
}

void loadDiffTabCore0()
{
    TASKENTRY usTskEntry;

    usTskEntry.uTskTyp=cTskLoadDiffTab;
    insertTaskFifo(usTskEntry);

    while(gsTskFifoCtrl.u32HeadPtr!=gsTskFifoCtrl.u32TailPtr)
        ;
}

void saveWproBadInfoCore0()
{
    TASKENTRY usTskEntry;

    usTskEntry.uTskTyp=cTskSaveWproBadInfo;
    insertTaskFifo(usTskEntry);

    while(gsTskFifoCtrl.u32HeadPtr!=gsTskFifoCtrl.u32TailPtr)
        ;
}

void setEraseBadBlockCore0(WORD u16FBlock, LWORD u32EraseFail)
{
    TASKENTRY usTskEntry;

    usTskEntry.uTskTyp=cTskMarkEraseBad;
    gsTskFifoCtrl.u16FBlk=u16FBlock;
    gsTskFifoCtrl.u32EraseFail=u32EraseFail;
    insertTaskFifo(usTskEntry);

    while(gsTskFifoCtrl.u32HeadPtr!=gsTskFifoCtrl.u32TailPtr)
        ;
}

#endif/* if _PRJ_BOOT */

// BootFunc+SMIVU////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
#if (_PRJ_BOOT||_PRJ_ISP||_PRJ_SMIVU)

void saveIndexBlockCore0()
{
    TASKENTRY usTskEntry;

    usTskEntry.uTskTyp=cTskSaveIndexBlockCore0;
    usTskEntry.uTskOpt=0xFF;
    usTskEntry.u16TskSBufPtr=c16BitFF;
    insertTaskFifo(usTskEntry);

    while(gsTskFifoCtrl.u32HeadPtr!=gsTskFifoCtrl.u32TailPtr)
        ;
}

void InitEraseCntCore0()    // 20190506_louis
{
    TASKENTRY usTskEntry;

    usTskEntry.uTskTyp=cTskInitEraseCnt;
    usTskEntry.uTskOpt=0xFF;
    usTskEntry.u16TskSBufPtr=c16BitFF;
    insertTaskFifo(usTskEntry);

    while(gsTskFifoCtrl.u32HeadPtr!=gsTskFifoCtrl.u32TailPtr)
        ;
}

#endif/* if (_PRJ_BOOT||_PRJ_SMIVU) */

// ISP////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
#if _PRJ_ISP||(_PRJ_SMIVU&&_GREYBOX)
void markBadBlockCore0()
{
    TASKENTRY usTskEntry;
    BYTE uSpare;

    usTskEntry.uTskTyp=cTskMarkBad;
    insertTaskFifo(usTskEntry);

    while(gsTskFifoCtrl.u32HeadPtr!=gsTskFifoCtrl.u32TailPtr)
        ;

    // chkAerSpareThreshold();
    if((gsLightSwitch.usSmartLs.uWarning&cSmartWarnAvaliableSpare)&&(!mChkAerSpare))    // Only perform checking if warning bit has not been set
    {
        uSpare=div((g16OrgSpareBlockCnt-gsBadInfo.u16TotalNewBadCnt)*100, g16OrgSpareBlockCnt);

        if(gsLightSwitch.usSmartLs.uAvaliableSpareThres>uSpare)    // the threshold value "50" can be replaced by LS when a LS is created for
        {
            mSetAerSpare;    // Set Asynchronous Eevent Flag
            // NLOG(cLogSYS, AERCMD_C, 2, gsLightSwitch.usSmartLs.uAvaliableSpareThres, uSpare);
        }
    }    /* chkAerSpareThreshold */
}    /* markBadBlockCore0 */

void buildValidCachePageCore0()
{
    TASKENTRY usTskEntry;

    usTskEntry.uTskTyp=cTskBuildF2h;
    insertTaskFifo(usTskEntry);

    while(gsTskFifoCtrl.u32HeadPtr!=gsTskFifoCtrl.u32TailPtr)
        ;
}

void remWproPageCore0(BYTE uWproIdx)
{
    TASKENTRY usTskEntry;

    usTskEntry.uTskTyp=cTskRemWproPage;
    usTskEntry.uTskOpt=uWproIdx;
    insertTaskFifo(usTskEntry);

    while(gsTskFifoCtrl.u32HeadPtr!=gsTskFifoCtrl.u32TailPtr)
        ;
}

#if _ENABLE_RAID
/*
   * void setRaidEncodeCore0(WORD u16BufIdx, WORD u16TotalSctrCnt, WORD u16FPage, WORD u16Opt, BYTE uRaidOpt, BYTE uPageType)
   * {
   *  TASKENTRY usTskEntry;
   *
   *  usTskEntry.uTskTyp=cTskSetRaidEncode;
   *
   *  gsTskFifoCtrl.usRaidEncPara.u16SbufPtr=u16BufIdx;
   *  gsTskFifoCtrl.usRaidEncPara.u16TotalSctrCnt=u16TotalSctrCnt;
   *  gsTskFifoCtrl.usRaidEncPara.u16FPage=u16FPage;
   *  gsTskFifoCtrl.usRaidEncPara.u16TskOpt=u16Opt;
   *  gsTskFifoCtrl.usRaidEncPara.uRaidOpt=uRaidOpt;
   *  gsTskFifoCtrl.usRaidEncPara.uPageType=uPageType;
   *  insertTaskFifo(usTskEntry);
   *
   *  while(gsTskFifoCtrl.u32HeadPtr!=gsTskFifoCtrl.u32TailPtr)
   *      ;
   * }
   *
   * void getRaidParityCore0(WORD u16SbufPtr, WORD u16Opt, BYTE uRaidOpt, WORD u16FPage, BYTE uPageType)
   * {
   *  TASKENTRY usTskEntry;
   *
   *  usTskEntry.uTskTyp=cTskGetRaidParity;
   *
   *  gsTskFifoCtrl.usRaidEncPara.u16SbufPtr=u16SbufPtr;
   *  gsTskFifoCtrl.usRaidEncPara.u16TskOpt=u16Opt;
   *  gsTskFifoCtrl.usRaidEncPara.uRaidOpt=uRaidOpt;
   *  gsTskFifoCtrl.usRaidEncPara.u16FPage=u16FPage;
   *  gsTskFifoCtrl.usRaidEncPara.uPageType=uPageType;
   *  insertTaskFifo(usTskEntry);
   *
   *  while(gsTskFifoCtrl.u32HeadPtr!=gsTskFifoCtrl.u32TailPtr)
   *      ;
   * }
   */
void progPartialRaidParityCore0(WORD u16SbufPtr, WORD u16ParityPtr, BYTE uRaidType, BYTE uPageSel)
{
    TASKENTRY usTskEntry;

    usTskEntry.uTskTyp=cTskProgPartialRaidParity;

    gsTskFifoCtrl.usRaidEncPara.u16SbufPtr=u16SbufPtr;
    gsTskFifoCtrl.usRaidEncPara.u16FPage=u16ParityPtr;
    gsTskFifoCtrl.usRaidEncPara.uRaidOpt=uRaidType;
    gsTskFifoCtrl.usRaidEncPara.uPageType=uPageSel;
    insertTaskFifo(usTskEntry);

    while(gsTskFifoCtrl.u32HeadPtr!=gsTskFifoCtrl.u32TailPtr)
        ;
}

void pushRaidPtyBlkCore0(BYTE uRaidBlkIdx)
{
    TASKENTRY usTskEntry;

    usTskEntry.uTskTyp=cTskPushRaidPtyBlk;
    gsTskFifoCtrl.usRaidEncPara.uRaidOpt=uRaidBlkIdx;
    insertTaskFifo(usTskEntry);

    while(gsTskFifoCtrl.u32HeadPtr!=gsTskFifoCtrl.u32TailPtr)
        ;
}

void rstRaidEngVarCore0(BYTE uRaidType)
{
    TASKENTRY usTskEntry;

    usTskEntry.uTskTyp=cTskRstRaidEngVar;
    gsTskFifoCtrl.usRaidEncPara.uRaidOpt=uRaidType;
    insertTaskFifo(usTskEntry);

    while(gsTskFifoCtrl.u32HeadPtr!=gsTskFifoCtrl.u32TailPtr)
        ;
}

#endif/* if _ENABLE_RAID */

void resetAllFlashCore0()
{
    TASKENTRY usTskEntry;

    usTskEntry.uTskTyp=cTskRstAllFlash;
    usTskEntry.uTskOpt=0;
    insertTaskFifo(usTskEntry);

    while(gsTskFifoCtrl.u32HeadPtr!=gsTskFifoCtrl.u32TailPtr)
        ;
}

void resetCore1Var()
{
    TASKENTRY usTskEntry;

    usTskEntry.uTskTyp=cTskRstCtlVar;
    usTskEntry.uTskOpt=0;
    insertTaskFifo(usTskEntry);

    while(gsTskFifoCtrl.u32HeadPtr!=gsTskFifoCtrl.u32TailPtr)
        ;
}

#if (_EN_GCPWR&&(!_EN_RAID_GC))
void chkPostWriteRead(BYTE uBankNum)
{
    TASKENTRY usTskEntry;

    // the Block is GcDes
    usTskEntry.uTskTyp=cTskChkPostWriteRead;
    usTskEntry.uTskOpt=0;
    usTskEntry.uTskPgOfst=uBankNum;
    insertTaskFifo(usTskEntry);
}

#endif
void clrLastReadGrp()
{
    TASKENTRY usTskEntry;

    usTskEntry.uTskTyp=cTskCore1ClrLastRGrp;
    usTskEntry.uTskOpt=0;
    insertTaskFifo(usTskEntry);

    while((gsTskFifoCtrl.u32HeadPtr!=gsTskFifoCtrl.u32TailPtr)&&(!mChkHandlePcieErrF)) // 20190307_Bill_SMI_S0215F
        ;
}

void getGcSrcBlkCore0()
{
    TASKENTRY usTskEntry;

    usTskEntry.uTskTyp=cTskGetGcSrcBlk;
    insertTaskFifo(usTskEntry);

    while(gsTskFifoCtrl.u32HeadPtr!=gsTskFifoCtrl.u32TailPtr)
        ;
}

/*
   * void resetGCFlagCore0()
   * {
   *  TASKENTRY usTskEntry;
   *
   *  usTskEntry.uTskTyp=cTskResetGCFlag;
   *  insertTaskFifo(usTskEntry);
   *
   *  while(gsTskFifoCtrl.u32HeadPtr!=gsTskFifoCtrl.u32TailPtr)
   *      ;
   * }
   */
#endif/* if _PRJ_ISP */

#if _EN_SLCOpenBlkReadScrub
void pushWLReadReclaimQCore0(WORD u16FBlk)
{
    TASKENTRY usTskEntry;

    usTskEntry.uTskTyp=cTskPushWLReadReclaimQ;
    gsTskFifoCtrl.u16FBlk=u16FBlk;
    insertTaskFifo(usTskEntry);

    while(gsTskFifoCtrl.u32HeadPtr!=gsTskFifoCtrl.u32TailPtr)
        ;
}

#endif

void initGcProcCore0()
{
    TASKENTRY usTskEntry;

    usTskEntry.uTskTyp=cTskinitGcProc;
    insertTaskFifo(usTskEntry);

    while(gsTskFifoCtrl.u32HeadPtr!=gsTskFifoCtrl.u32TailPtr)
        ;
}

void gcDesBlkFullSettingCore0()
{
    TASKENTRY usTskEntry;

    usTskEntry.uTskTyp=cTskgcDesBlkFullSetting;
    insertTaskFifo(usTskEntry);

    while(gsTskFifoCtrl.u32HeadPtr!=gsTskFifoCtrl.u32TailPtr)
        ;
}

void deleteGcSrcBlkCore0(BYTE Srcblk)
{
    TASKENTRY usTskEntry;

    usTskEntry.uTskTyp=cTskdeleteGcSrcBlk;
    usTskEntry.uTskOpt=Srcblk;
    insertTaskFifo(usTskEntry);

    while(gsTskFifoCtrl.u32HeadPtr!=gsTskFifoCtrl.u32TailPtr)
        ;
}

#if _EN_CHK_FINGER_FAIL
BYTE chkFingerFailCore0()
{
    TASKENTRY usTskEntry;

    usTskEntry.uTskTyp=cTskChkFingerFail;
    insertTaskFifo(usTskEntry);

    while(gsTskFifoCtrl.u32HeadPtr!=gsTskFifoCtrl.u32TailPtr)
        ;

    return gsTskFifoCtrl.u32EraseFail;
}

#endif
// ISP+SMIVU+NVME///////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
#if (_PRJ_ISP||_PRJ_SMIVU||_PRJ_NVME)
void setGcInfoHmbLinkCore0(BYTE uWproIdx)
{
    TASKENTRY usTskEntry;

    usTskEntry.uTskTyp=cTskSetGcInfoHmbLink;
    usTskEntry.uTskOpt=uWproIdx;
    insertTaskFifo(usTskEntry);
}

#endif

// BootFunc+ISP+SMIVU////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
#if (_PRJ_BOOT||_PRJ_ISP||_PRJ_SMIVU)

void waitProgH2fTxDataCore0()
{
    TASKENTRY usTskEntry;

    usTskEntry.uTskTyp=cTskWaitProgH2fTxData;
    insertTaskFifo(usTskEntry);

    while(gsTskFifoCtrl.u32HeadPtr!=gsTskFifoCtrl.u32TailPtr)
        ;
}

LWORD prepopBlkChkStatusCore0(BYTE uPopOpt)
{
    TASKENTRY usTskEntry;

    usTskEntry.uTskTyp=cTskPrePopBlkChkStatus;
    usTskEntry.uTskOpt=uPopOpt;

    insertTaskFifo(usTskEntry);

    while(gsTskFifoCtrl.u32HeadPtr!=gsTskFifoCtrl.u32TailPtr)
        ;

    return gsTskFifoCtrl.u32EraseFail;
}

void rstUNCSts1PlaneCore0(BYTE uCh, BYTE uPlaneAddr)
{
    TASKENTRY usTskEntry;

    usTskEntry.uTskTyp=cTskRstUNCSts1Plane;
    usTskEntry.uTskOpt=uCh,
    usTskEntry.uTskPgOfst=uPlaneAddr;
    insertTaskFifo(usTskEntry);

    while(gsTskFifoCtrl.u32HeadPtr!=gsTskFifoCtrl.u32TailPtr)
        ;
}

void rstUNCStsCore0()
{
    TASKENTRY usTskEntry;

    usTskEntry.uTskTyp=cTskRstUNCSts;
    insertTaskFifo(usTskEntry);

    while(gsTskFifoCtrl.u32HeadPtr!=gsTskFifoCtrl.u32TailPtr)
        ;
}

void Init_EEPROM()
{
    // flashReadPage();
    TASKENTRY usTskEntry;

    usTskEntry.uTskTyp=cTskVendorOp;
    usTskEntry.uTskPgOfst=0;    // core0
    usTskEntry.uTskOpt=cVendorCore1WriteMPInfo;
    insertTaskFifo(usTskEntry);

    while(gsTskFifoCtrl.u32HeadPtr!=gsTskFifoCtrl.u32TailPtr)
        ;
}

#endif/* if (_PRJ_BOOT||_PRJ_ISP||_PRJ_SMIVU) */

// NVMe////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
#if (_PRJ_BOOT2||_PRJ_NVME)

void progFwDlTempIspblockCore0(WORD u16BufPtr)
{
    TASKENTRY usTskEntry;

    usTskEntry.uTskTyp=cTskProgFwDlTempIspblock;
    usTskEntry.u16TskSBufPtr=u16BufPtr;
    insertTaskFifo(usTskEntry);

    while(gsTskFifoCtrl.u32HeadPtr!=gsTskFifoCtrl.u32TailPtr)
        ;
}

void swapFwSlotIspCore0(BYTE uFwSlot)
{
    TASKENTRY usTskEntry;

    if(!uFwSlot)
    {
        uFwSlot+=1;
    }

    usTskEntry.uTskTyp=cTskSwapFwSlotIsp;
    usTskEntry.uTskOpt=uFwSlot;
    insertTaskFifo(usTskEntry);

    while(gsTskFifoCtrl.u32HeadPtr!=gsTskFifoCtrl.u32TailPtr)
        ;
}

BYTE loadIspPageCore0(WORD u16Page, BYTE uType)
{
    TASKENTRY usTskEntry;
    LWORD u32HeadPtr=gsTskFifoCtrl.u32HeadPtr;

    usTskEntry.uTskTyp=cTskLoadIspPage;
    usTskEntry.u16TskSBufPtr=u16Page;
    usTskEntry.uTskOpt=uType;
    insertTaskFifo(usTskEntry);

    while(gsTskFifoCtrl.u32HeadPtr!=gsTskFifoCtrl.u32TailPtr)
        ;

    return gsTskFifoCtrl.uarTskFifo[u32HeadPtr].uTskPgOfst;
}

#endif/* if (_PRJ_BOOT2||_PRJ_NVME) */

#if _PRJ_NVME
void loadTelemetryCtlrLogCore0(WORD u16BufPtr)
{
    TASKENTRY usTskEntry;

    usTskEntry.uTskTyp=cTskLoadTelemetryCtlrLog;
    usTskEntry.u16TskSBufPtr=u16BufPtr;
    insertTaskFifo(usTskEntry);

    while(gsTskFifoCtrl.u32HeadPtr!=gsTskFifoCtrl.u32TailPtr)
        ;
}

#endif/* if _PRJ_NVME */

// NVMe+SMIVU////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
#if (_PRJ_NVME||_PRJ_SMIVU)

void readRdCntToTsb0Core0(BYTE uStartPageOffset)
{
    TASKENTRY usTskEntry;

    usTskEntry.uTskTyp=cTskReadRdCnt;
    usTskEntry.uTskPgOfst=uStartPageOffset;
    insertTaskFifo(usTskEntry);

    while(gsTskFifoCtrl.u32HeadPtr!=gsTskFifoCtrl.u32TailPtr)
        ;
}

#endif/* if (_PRJ_NVME||_PRJ_SMIVU) */







