







#if (C_Log_SaveMask&C_Debug_P1)    // 20181031_Bill Wpro
#include "inc/DebugLog.h"
#include "inc/EventLogIDX.h"
#include "inc/EventLogFunctionIDX.h"
#endif

void getDiffAddr2InRdlink(ADDRINFO *upTmpAddrInfo, WORD u16FBlock, BYTE uCh, BYTE uIntlvIdx, BYTE uPlaneIdx)
{
    BYTE uAddr=0;

    upTmpAddrInfo->uCh=uCh;
    upTmpAddrInfo->uIntlvAddr=uIntlvIdx;
    upTmpAddrInfo->uPlaneAddr=uPlaneIdx;
    upTmpAddrInfo->u16FBlock=u16FBlock;

    uAddr=(uCh*gIntlvWay+uIntlvIdx)*gPlaneNum+uPlaneIdx;

    if(u16FBlock!=gsDiffTyp2AddrInfo.u16FBlock)
    {
        getDiffType2AddrInfo(u16FBlock);
    }

    if(gsDiffTyp2AddrInfo.u16arBitMap[uAddr>>4]&cb32BitTab[uAddr&0x0F])
    {
        tranType2Addr(upTmpAddrInfo, gsDiffTyp2AddrInfo.u16arPhyAddr[uAddr]);
    }
}    /* getDiffAddr2InRdlink */

BYTE getWproPageInfo(WORD u16FBlock, WORD u16WproPagePtr, WORD u16SBufPtr, BLKSPRINFO *upBlkSprInfo, BYTE uDiffType2, BYTE uOpt)
{
    ADDRINFO usTmpAddrInfo;
    BYTE uCh, uStartCh, uEndCh;
    BYTE uIntlvAddr1, uPlaneAddr1;
    BYTE uPageStatus=0;
    BYTE uLoop;
    BLKSPRINFO usBlkSprInfo;
    WORD u16RwOpt=c16Bit5|c16Bit10|c16Bit14|c16Bit15;
    BYTE uRwHalfKb=0;

    usTmpAddrInfo.u16FBlock=u16FBlock;
    usTmpAddrInfo.u16FPage=u16WproPagePtr;
    tranAddrInfoTo2Ch(&usTmpAddrInfo);

    uIntlvAddr1=usTmpAddrInfo.uIntlvAddr;
    uPlaneAddr1=usTmpAddrInfo.uPlaneAddr;

    uStartCh=usTmpAddrInfo.uCh;
    uEndCh=uStartCh+cWriteChNum;

    for(uCh=uStartCh, uLoop=0; uCh<uEndCh; uCh++, uLoop++)
    {
        usTmpAddrInfo.uCh=uCh;

        // Diff Type 2 block
        if(uDiffType2)
        {
            getDiffAddr2InRdlink(&usTmpAddrInfo, u16FBlock, uCh, uIntlvAddr1, uPlaneAddr1);
        }

        setFLAddrActCh(usTmpAddrInfo.uCh, &usTmpAddrInfo);

        rstUNCSts1PlaneCore0(gCh, gPlaneAddr);

        if(uDiffType2)
        {
            g16AbstrFBlock=usTmpAddrInfo.u16FBlock;
            g16FBlock=u16FBlock;
        }

        gSectorH=0;

        if(uOpt&cBit0)
        {
            u16RwOpt|=c16Bit4;
            uRwHalfKb=gSectorPerPlaneH;
        }

        mSetFRwParam(u16SBufPtr, uRwHalfKb, u16RwOpt, cReadData);
        // waitChCeBz(gActiveCh, gIntlvAddr, 0);
        // flashReadPage();

        assignFreeBtSrcAddrInfo();
        waitCmdAllDone(cWaitTrigRCnt|cWaitCmdBz);

        if(!mChkBitMask(gPlaneUNCSts[gCh], gPlaneAddr))
        {
            getSprByte(&usBlkSprInfo, gPlaneAddr);

            if(mGetMetaBlockId(usBlkSprInfo)==cWPROBlockID)
            {
                copyCcmVal((BYTE *)upBlkSprInfo, (BYTE *)&usBlkSprInfo, sizeof(usBlkSprInfo));
                mSetBitMask(uPageStatus, uLoop);

                if((mGetMetaWord7(usBlkSprInfo)!=u16WproPagePtr))
                {
                    debugLoop(cGetWproPageInfo1);
                }

                break;
            }
            else if(mGetMetaBlockId(usBlkSprInfo)==0xFF)
            {
                mSetBitMask(uPageStatus, 2+uLoop);
            }
            else
            {
                uPageStatus=0xF;    // non WPRO block
                break;
                // debugLoop();
            }
        }

        usTmpAddrInfo.uIntlvAddr=uIntlvAddr1;
        usTmpAddrInfo.uPlaneAddr=uPlaneAddr1;
    }

    return uPageStatus;
}    /* getWproPageInfo */

/*
   *  binary search find free page ptr
   */

WORD getWproFreePage(WORD u16FBlock, BLKSPRINFO *upBlkSprInfo, BYTE uDiffType2)
{
    BLKSPRINFO usBlkSprInfo;
    WORD u16WproInfoFreePagePtr, u16WproPagePtr;

    WORD u16Left=0;
    WORD u16Right=gsWproInfo.u16PagePerBlock3-1;

    BYTE uPageStatus;
    BYTE uDone=0;

    ctrlOnesCntStop(0);

    uPageStatus=getWproPageInfo(u16FBlock, 0, c16Tsb0SIdx, &usBlkSprInfo, uDiffType2, 0);

    if(uPageStatus==0xF)    // not WPRO block case
    {
        uDone=1;
        u16WproInfoFreePagePtr=c16BitFF;
    }

    // empty block
    if(mChkBitMask(uPageStatus, 2)&&mChkBitMask(uPageStatus, 3))
    {
        uDone=1;
        u16WproInfoFreePagePtr=0;
        copyCcmVal((BYTE *)upBlkSprInfo, (BYTE *)&usBlkSprInfo, sizeof(usBlkSprInfo));
    }
    else if(!uPageStatus)    // 2 ch ecc fail
    {
        uDone=1;
        u16WproInfoFreePagePtr=c16BitFF;
    }

    if(!uDone)
    {
        uPageStatus=getWproPageInfo(u16FBlock, u16Right, c16Tsb0SIdx, &usBlkSprInfo, uDiffType2, 0);

        // full block
        if(!(mChkBitMask(uPageStatus, 2)&&mChkBitMask(uPageStatus, 3)))
        {
            uDone=1;
            u16WproInfoFreePagePtr=gsWproInfo.u16PagePerBlock3;
            copyCcmVal((BYTE *)upBlkSprInfo, (BYTE *)&usBlkSprInfo, sizeof(usBlkSprInfo));

            if(!uPageStatus)    // 2 ch ecc fail
            {
                uPageStatus=getWproPageInfo(u16FBlock, 0, c16Tsb0SIdx, &usBlkSprInfo, uDiffType2, 0);
                copyCcmVal((BYTE *)upBlkSprInfo, (BYTE *)&usBlkSprInfo, sizeof(usBlkSprInfo));

                if(!uPageStatus)
                {
                    debugLoop(cGetWproFreePage1);
                }
            }
        }
    }

    while((u16Left<=u16Right)&&(!uDone))
    {
        u16WproPagePtr=(u16Left+u16Right)>>1;

        uPageStatus=getWproPageInfo(u16FBlock, u16WproPagePtr, c16Tsb0SIdx, &usBlkSprInfo, uDiffType2, 0);

        if(uPageStatus)
        {
            if(mChkBitMask(uPageStatus, 2)&&mChkBitMask(uPageStatus, 3))
            {
                u16WproInfoFreePagePtr=u16WproPagePtr;
                // 2 ch all empty case
                u16Right=u16WproPagePtr-1;
            }
            else
            {
                u16Left=u16WproPagePtr+1;
                copyCcmVal((BYTE *)upBlkSprInfo, (BYTE *)&usBlkSprInfo, sizeof(usBlkSprInfo));
            }
        }
        else
        {
            u16Left=u16WproPagePtr+1;
        }
    }

    ctrlOnesCntStop(3);

    return u16WproInfoFreePagePtr;
}    /* getWproFreePage */

void setWproPagePtrInRdlink(BYTE uWproIdx, WORD u16PagePtr)
{
    BYTE uOrgBlkIdx, uDiffType2Ptr;
    WORD u16FBlock;

    if(gsWproInfo.uarWproIdxPtr[uWproIdx]!=0xFF)
    {
        uOrgBlkIdx=gsWproInfo.uarWproIdxPtr[uWproIdx];    // max wpro block count = 8

        if((uWproIdx!=cMaxWproPageType)&&(uWproIdx!=cWproQBootPg)&&(uWproIdx!=cWproQBWithDumyW)&&(uWproIdx!=cWproInvQBootPg))
        {
            while(!gsWproInfo.u16arVpCnt[uOrgBlkIdx])
                ;

            gsWproInfo.u16arVpCnt[uOrgBlkIdx]--;
        }

        if((!gsWproInfo.u16arVpCnt[uOrgBlkIdx])&&(uOrgBlkIdx!=gsWproInfo.uActIdx))
        {
            if(!gsRdlinkInfo.ubDoNotPushSpare)
            {
                u16FBlock=gsWproInfo.u16arWproBlk[uOrgBlkIdx];
                uDiffType2Ptr=chkDiffType2(u16FBlock);

                if(uDiffType2Ptr!=0xFF)
                {
                    mClrBitMask(gsCacheInfo.u32arDiffType2PopBit[uDiffType2Ptr>>5], uDiffType2Ptr&0x1F);
                    gsCacheInfo.uDiffType2SprBlkCnt++;
                }
                else
                {
                    pushSpareBlockCore0(u16FBlock, cPushNotErase);
                }

                gsWproInfo.uCnt--;
                gsWproInfo.u16arWproBlk[uOrgBlkIdx]=c16BitFF;
            }
        }
    }

    gsWproInfo.uarWproIdxPtr[uWproIdx]=gsWproInfo.uActIdx;
    gsWproInfo.u16arWproIdxPagePtr[uWproIdx]=u16PagePtr;

    if((uWproIdx!=cMaxWproPageType)&&(uWproIdx!=cWproQBootPg)&&(uWproIdx!=cWproQBWithDumyW)&&(uWproIdx!=cWproInvQBootPg))
    {
        gsWproInfo.u16arVpCnt[gsWproInfo.uActIdx]++;
    }
}    /* setWproPagePtrInRdlink */

void sortFoundWproQ(LWORD u32Serial, WORD u16FBlock, WORD u16FreePtr, WORD u16EraseCnt, BYTE uIndex, BYTE uDiffType2)
{
    BYTE uIdx=0, uIdx2;

    // debugLoop();

    garFoundWproQ[gsRdlinkInfo.uReBuWproCnt].u32Serial=u32Serial;
    garFoundWproQ[gsRdlinkInfo.uReBuWproCnt].u16FBlock=u16FBlock;
    garFoundWproQ[gsRdlinkInfo.uReBuWproCnt].u16FreePtr=u16FreePtr;
    garFoundWproQ[gsRdlinkInfo.uReBuWproCnt].u16EraseCnt=u16EraseCnt;
    garFoundWproQ[gsRdlinkInfo.uReBuWproCnt].uIndex=uIndex;
    garFoundWproQ[gsRdlinkInfo.uReBuWproCnt].uDiffType2=uDiffType2;
    g16arWproBlkEraseCnt[uIndex]=u16EraseCnt;
    gsWproInfo.u16arWproBlk[uIndex]=u16FBlock;

    if(gsRdlinkInfo.uReBuWproCnt!=0)
    {
        for(uIdx=0; uIdx<gsRdlinkInfo.uReBuWproCnt; uIdx++)
        {
            if(judgeSerial(u32Serial, garFoundWproQ[garFoundWproIdx[uIdx]].u32Serial)==cSerialSmaller)
            {
                for(uIdx2=gsRdlinkInfo.uReBuWproCnt; uIdx2>uIdx; uIdx2--)
                {
                    garFoundWproIdx[uIdx2]=garFoundWproIdx[uIdx2-1];
                }

                break;
            }
        }
    }

    garFoundWproIdx[uIdx]=gsRdlinkInfo.uReBuWproCnt;
    gsRdlinkInfo.uReBuWproCnt++;
}    /* sortFoundWproQ */

BYTE chkLastWproIsQBoot()
{
    WORD u16FBlock, u16WproInfoFreePagePtr, u16StartPage;
    BYTE uDiffType2, uPgCnt, uGood;
    BLKSPRINFO usBlkSprInfo;

    u16FBlock=gsRdlinkInfo.u16arWproBlk[gsRdlinkInfo.uWproActIdx];

    if(chkDiffType2(u16FBlock)==0xFF)
    {
        uDiffType2=0;
    }
    else
    {
        uDiffType2=1;
        getDiffType2AddrInfo(u16FBlock);
    }

    mClrMlcMoBit(u16FBlock);

    u16WproInfoFreePagePtr=getWproFreePage(u16FBlock, &usBlkSprInfo, uDiffType2);

    if((u16WproInfoFreePagePtr==0)||(u16WproInfoFreePagePtr==0xFFFF))
    {
        uGood=0;
    }
    else
    {
        if(mGetMetaWord3(usBlkSprInfo)!=gsRdlinkInfo.uWproActIdx)
        {
            debugLoop(cChkLastWproIsQBoot1);
        }

        sortFoundWproQ(mGetMetaBlkSn(usBlkSprInfo), u16FBlock, u16WproInfoFreePagePtr,
                       mGetMetaEraseCnt(usBlkSprInfo), mGetMetaWord3(usBlkSprInfo), uDiffType2);

        u16StartPage=u16WproInfoFreePagePtr-gsQBootInfo.uSavePgCnt;
        uGood=1;

        for(uPgCnt=0; uPgCnt<gsQBootInfo.uSavePgCnt; uPgCnt++, u16StartPage++)
        {
            if(getWproPageInfo(u16FBlock, u16StartPage, c16Tsb0SIdx, &usBlkSprInfo, uDiffType2, cBit0)&3)
            {
                if(((mGetMetaTabIdx(usBlkSprInfo)!=cWproQBootPg)&&(mGetMetaTabIdx(usBlkSprInfo)!=cWproQBWithDumyW))||
                   (mGetMetaWproPgOfst(usBlkSprInfo)!=uPgCnt)||
                   (mGetMetaWord6(usBlkSprInfo)==cOnPcieErr)||
                   (mGetMetaWord6(usBlkSprInfo)==cDevicePs3)||
                   (mGetMetaWord6(usBlkSprInfo)==cUGSD)||    // 20190131_Louis
                   ((mGetMetaWord6(usBlkSprInfo)==cDevicePs4)&&(!gsRdlinkInfo.uResumeFromPs4)))
                {
                    uGood=0;
                    NLOG(cLogBuild, REBUWPROINFO_C, 1, "Have Qboot, but it's an invalid Qboot, gPowerDownMode: 0x%04X ",
                         mGetMetaWord6(usBlkSprInfo));
                    break;
                }
            }
            else
            {
                uGood=0;
                break;
            }
        }
    }

    if(uGood)
    {
        if(mGetMetaTabIdx(usBlkSprInfo)==cWproQBWithDumyW)
        {
            gsFtlDbg.u16DummyFailType=mGetMetaWord6(usBlkSprInfo);
            NLOG(cLogBuild, REBUWPROINFO_C, 1, "mSetDummyWrite! FailType=0x%04x", gsFtlDbg.u16DummyFailType);
            mSetDummyWrite;
        }

        gsWproInfo.uActIdx=gsRdlinkInfo.uWproActIdx;
        gsWproInfo.u16arWproBlk[gsWproInfo.uActIdx]=u16FBlock;
        gsWproInfo.u16WproFreePagePtr=u16WproInfoFreePagePtr;
        setWproPagePtrInRdlink(mGetMetaTabIdx(usBlkSprInfo), mGetMetaWproIdxPg(usBlkSprInfo));
        gsRdlinkInfo.uQBootFailId=0;
        gsQBootInfo.ubQBootValid=1;
    }

#if (C_Log_SaveMask&C_Debug_P1)    // 20181031_Bill wpro
    NLOG(cLogBuild, REBUWPROINFO_C, 2, " chkLastWproIsQBoot() u16WproInfoFreePagePtr = 0x%04X ,uGood = 0x%04X", u16WproInfoFreePagePtr, uGood);
#endif
    return uGood;
}    /* chkLastWproIsQBoot */

BYTE chkWproPageIsGood(BYTE uWproIdx, WORD u16FBlock, WORD u16StartPage)
{
    BYTE uDiffType2, uPgCnt, uGood;
    WORD u16TotalPlaneOfWproPage;
    WORD u16WproPagePtr=u16StartPage;
    WORD u16BufPtr=c16Tsb0SIdx;
    LWORD u32SrcAddr;
    BLKSPRINFO usBlkSprInfo;

    if(chkDiffType2(u16FBlock)==0xFF)
    {
        uDiffType2=0;
    }
    else
    {
        uDiffType2=1;
        getDiffType2AddrInfo(u16FBlock);
    }

    uGood=1;

    switch(uWproIdx)
    {
        case cWproCacheInfo:
#if _EN_VPC_SWAP
            u16TotalPlaneOfWproPage=(c16CacheInfoVPCSize+c16CacheInfoTabSize+c16CacheInfoRECntSize+c16CacheInfoAnotherSize+gSectorPerPlaneH-1)/
                                     gSectorPerPlaneH;
            u32SrcAddr=(c32Tsb0SAddr+c32ProgCacheInfo_CacheBlkVpCntSize+(c16CacheInfoTabSize-1)*0x200);
#else
            u16TotalPlaneOfWproPage=((c16CacheInfoTabSize/cSctrPer4k)/g4kNumPerPlane)+1;
            u32SrcAddr=(c32Tsb0SAddr+(c16CacheInfoTabSize-1)*0x200);
#endif
            break;

        case cWproBadInfo:
            u16TotalPlaneOfWproPage=1+((cDiffMixTableHalfKb+cTotalRTDiffPoolHalfKb)/gSectorPerPlaneH);
            u32SrcAddr=(c32Tsb0SAddr+(gSectorPerPlaneH+(cDiffMixTableHalfKb+cTotalRTDiffPoolHalfKb)-1)*0x200);
            break;

        case cWproEventLog:
        case cWproSecurityId:
        case cWproTcgIeee1667InfoId:
        case cWproTcgInfoId:
        case cWproTcgInfoDevslpId:
        case cWproTcgIeee1667InfoDevslpId:
        case cWproTcgIeee1667InfoTransDevslpId:
        case cWproTcgRecvbuf1DevslpId:
        case cWproTcgRecvbuf2DevslpId:
        case cWproTcgRecvbuf3DevslpId:
        case cWproTcgRecvbuf4DevslpId:
#if _EN_WUNCTable    // WUNCTable Chief_21081121
        case cWproWriteUNC:
#endif
        case cWproRpmbInfoId:
#if _EN_KEEP_RW_ON_ERROR
        case cWproErrorInfo:
#endif
            u16TotalPlaneOfWproPage=1;
            u32SrcAddr=(c32Tsb0SAddr+(gSectorPerPlaneH-1)*0x200);
            break;

        case cWproFeaturePg:
            u16TotalPlaneOfWproPage=(((sizeof(NVMEFEATVAR)-0x1000)/(gSectorPerPlaneH*0x200))+1);
            u32SrcAddr=(c32Tsb0SAddr+(u16TotalPlaneOfWproPage*gSectorPerPlaneH-1)*0x200);

            break;

        case cWproGetLogPg:
            u16TotalPlaneOfWproPage=((sizeof(GETLOGINFO)/(gSectorPerPlaneH*0x200))+1);
            u32SrcAddr=(c32Tsb0SAddr+(u16TotalPlaneOfWproPage*gSectorPerPlaneH-1)*0x200);
            break;

        case cWproSecurityBackupAllTsb:
            u16TotalPlaneOfWproPage=c16Tsb0Size/gSectorPerPlaneH;
            u32SrcAddr=(c32Tsb0SAddr+(u16TotalPlaneOfWproPage*gSectorPerPlaneH-1)*0x200);
            break;

        default:
#if _EN_KEEP_RW_ON_ERROR
            if(gsRdlinkInfo.ubCacheInfoValid)
            {
                relinkKeepRwonError(cChkWproPageIsGood, (WORD)uWproIdx, u16FBlock, u16StartPage);
            }

            uGood=0;
            return uGood;
#else
            relinkSaveDummyQBAnalysis((WORD)uWproIdx, u16FBlock, u16StartPage, 0);
            relinkSaveQBDummy(cChkWproPageIsGood);
#endif
    }    /* switch */

    for(uPgCnt=0; uPgCnt<u16TotalPlaneOfWproPage; uPgCnt++, u16WproPagePtr++, u16BufPtr+=gSectorPerPlaneH)
    {
        if(getWproPageInfo(u16FBlock, u16WproPagePtr, u16BufPtr, &usBlkSprInfo, uDiffType2, cBit0)&3)
        {
            if((mGetMetaTabIdx(usBlkSprInfo)!=uWproIdx)||(mGetMetaWproPgOfst(usBlkSprInfo)!=uPgCnt))
            {
                uGood=0;
                break;
            }
        }
        else
        {
            uGood=0;
            break;
        }
    }

    if(uGood)
    {
        WPROINFO *upWproInfo=(WPROINFO *)u32SrcAddr;

        for(uPgCnt=cWproCacheInfo; uPgCnt<cWproGcDesF2hTab00; uPgCnt++)
        {
            gsWproInfo.u16arWproIdxPagePtr[uPgCnt]=upWproInfo->u16arWproIdxPagePtr[uPgCnt];
            gsWproInfo.uarWproIdxPtr[uPgCnt]=upWproInfo->uarWproIdxPtr[uPgCnt];

            if(gsWproInfo.u16arWproIdxPagePtr[uPgCnt]!=c16BitFF)
            {
                if(gsWproInfo.u16arWproBlk[gsWproInfo.uarWproIdxPtr[uPgCnt]]==c16BitFF)
                {
                    debugLoop(cChkWproPageIsGood1);
                }
            }
        }
    }

    return uGood;
}    /* chkWproPageIsGood */

void rebuWproInfo()
{
    ADDRINFO usTmpAddrInfo;
    BLKSPRINFO usBlkSprInfo;
    WORD u16FBlock, u16WproInfoFreePagePtr,    /*u16RiskyPagePtr,*/ u16WproPagePtr;
    BYTE uLoop;    // , uBlkID;    // , uQBootPgCnt=0;
    BYTE uIdx=0xFF;

    BYTE uCh, uStartCh, uEndCh, uDiffType2;
    BYTE uIntlvAddr1, uPlaneAddr1, uCurWproType;
    BYTE uFinish=0;
    BYTE uPgOfst;

/*
   * new re build WPRO flow
   */
    gsRdlinkInfo.uReBuWproCnt=0;

    if(chkLastWproIsQBoot())
    {
        return;
    }
    else
    {
        for(uLoop=0; uLoop<cMaxWproBlkCnt; uLoop++)
        {
            if(uLoop==gsRdlinkInfo.uWproActIdx)
            {
                continue;
            }

            u16FBlock=gsRdlinkInfo.u16arWproBlk[uLoop];

            if(u16FBlock!=c16BitFF)
            {
                if(chkDiffType2(u16FBlock)==0xFF)
                {
                    uDiffType2=0;
                }
                else
                {
                    uDiffType2=1;
                    // getDiffType2AddrInfo(u16FBlock);
                }

                mClrMlcMoBit(u16FBlock);
                // get1stPageInfo(gsRdlinkInfo.u16arWproBlk[uLoop], cReadOnePage|cReadWithoutRetry, &usBlkSprInfo);
                u16WproInfoFreePagePtr=getWproFreePage(u16FBlock, &usBlkSprInfo, uDiffType2);

                if((u16WproInfoFreePagePtr==c16BitFF)||(!u16WproInfoFreePagePtr))    // page ptr 0 ecc fail or empty case
                {}
                else
                {
                    sortFoundWproQ(mGetMetaBlkSn(usBlkSprInfo), u16FBlock, u16WproInfoFreePagePtr,
                                   mGetMetaEraseCnt(usBlkSprInfo), mGetMetaWord3(usBlkSprInfo), uDiffType2);
                }
            }
        }

        if(!gsRdlinkInfo.uReBuWproCnt)
        {
            return;
        }

/*
   *  setSelMulFL(1);
   *  rmEnUnCorrErrStop;
   *  resetEcc();
   *  setSelMulFL(0);
   *  ctrlOnesCntStop(3);
   */

        for(uLoop=gsRdlinkInfo.uReBuWproCnt; (uLoop>0)&&(!uFinish); )
        {
            uLoop--;
            u16FBlock=garFoundWproQ[garFoundWproIdx[uLoop]].u16FBlock;
            u16WproInfoFreePagePtr=garFoundWproQ[garFoundWproIdx[uLoop]].u16FreePtr;
            uIdx=garFoundWproQ[garFoundWproIdx[uLoop]].uIndex;
            // gsWproInfo.u16arWproBlk[uIdx]=u16FBlock;
            // g16arWproBlkEraseCnt[uIdx]=garFoundWproQ[garFoundWproIdx[uLoop]].u16EraseCnt;
            uDiffType2=garFoundWproQ[garFoundWproIdx[uLoop]].uDiffType2;

            if(gsWproInfo.u32Serial==c32InitSerialVal)
            {
                gsWproInfo.u32Serial=garFoundWproQ[garFoundWproIdx[uLoop]].u32Serial;
                gsWproInfo.uActIdx=uIdx;
                gsWproInfo.u16WproFreePagePtr=u16WproInfoFreePagePtr;
            }

            if(uDiffType2)
            {
                getDiffType2AddrInfo(u16FBlock);
            }

            if(u16WproInfoFreePagePtr)
            {
                u16WproPagePtr=u16WproInfoFreePagePtr-1;
            }

            do
            {
                usTmpAddrInfo.u16FBlock=u16FBlock;
                usTmpAddrInfo.u16FPage=u16WproPagePtr;

                tranAddrInfoTo2Ch(&usTmpAddrInfo);

                uIntlvAddr1=usTmpAddrInfo.uIntlvAddr;
                uPlaneAddr1=usTmpAddrInfo.uPlaneAddr;

                uStartCh=usTmpAddrInfo.uCh;

                uEndCh=uStartCh+cWriteChNum;

                for(uCh=uStartCh; uCh<uEndCh; uCh++)
                {
                    usTmpAddrInfo.uCh=uCh;    // (H)WPRO

                    // Diff Type 2 block
                    if(uDiffType2)
                    {
                        getDiffAddr2InRdlink(&usTmpAddrInfo, u16FBlock, uCh, uIntlvAddr1, uPlaneAddr1);
                    }

                    setFLAddrActCh(usTmpAddrInfo.uCh, &usTmpAddrInfo);
                    rstUNCSts1PlaneCore0(gCh, gPlaneAddr);

                    if(uDiffType2)
                    {
                        g16AbstrFBlock=usTmpAddrInfo.u16FBlock;
                        g16FBlock=u16FBlock;
                    }

                    gSectorH=0;
                    mSetFRwParam(c16Tsb0SIdx, gSectorPerPlaneH, c16Bit4|c16Bit5|c16Bit10|c16Bit14|c16Bit15, cReadData);

                    assignFreeBtSrcAddrInfo();
                    waitCmdAllDone(cWaitTrigRCnt|cWaitCmdBz);

                    if(!mChkBitMask(gPlaneUNCSts[gCh], gPlaneAddr))
                    {
                        getSprByte(&usBlkSprInfo, gPlaneAddr);

                        if((mGetMetaWord7(usBlkSprInfo)!=u16WproPagePtr))
                        {
                            debugLoop(cRebuWproInfo3);
                        }

                        if(mGetMetaBlockId(usBlkSprInfo)==cWPROBlockID)
                        {
                            uCurWproType=mGetMetaTabIdx(usBlkSprInfo);

                            if((uCurWproType>=cWproCacheInfo)&&(uCurWproType<=cWproRpmbInfoId))
                            {
                                switch(uCurWproType)
                                {
                                    case cWproCacheInfo:
#if _EN_VPC_SWAP
                                        uPgOfst=c16CacheInfoVPCSize+c16CacheInfoTabSize;
                                        uPgOfst=uPgOfst+c16CacheInfoRECntSize+c16CacheInfoAnotherSize;
                                        uPgOfst=(((uPgOfst+gSectorPerPlaneH-1)/gSectorPerPlaneH)-1);
#else
                                        uPgOfst=(((c16CacheInfoTabSize/cSctrPer4k)/g4kNumPerPlane+1)-1);
#endif
                                        break;

                                    case cWproBadInfo:
                                        uPgOfst=(((gSectorPerPlaneH+(cDiffMixTableHalfKb+cTotalRTDiffPoolHalfKb))/gSectorPerPlaneH)-1);
                                        break;

                                    case cWproEventLog:
                                    case cWproSecurityId:
                                    case cWproTcgIeee1667InfoId:
                                    case cWproTcgInfoId:
                                    case cWproTcgInfoDevslpId:
                                    case cWproTcgIeee1667InfoDevslpId:
                                    case cWproTcgIeee1667InfoTransDevslpId:
                                    case cWproTcgRecvbuf1DevslpId:
                                    case cWproTcgRecvbuf2DevslpId:
                                    case cWproTcgRecvbuf3DevslpId:
                                    case cWproTcgRecvbuf4DevslpId:
#if _EN_WUNCTable    // WUNCTable Chief_21081121
                                    case cWproWriteUNC:
#endif
#if _EN_KEEP_RW_ON_ERROR
                                    case cWproErrorInfo:
#endif
                                    case cWproRpmbInfoId:
                                        uPgOfst=0;
                                        break;

                                    case cWproFeaturePg:
                                        uPgOfst=((((sizeof(NVMEFEATVAR)-0x1000)/(gSectorPerPlaneH*0x200))+1)-1);
                                        break;

                                    case cWproGetLogPg:
                                        uPgOfst=(((sizeof(GETLOGINFO)/(gSectorPerPlaneH*0x200))+1)-1);
                                        break;

#if 0
// Don't need to rebuild.
                                    case cWproSecurityBackupAllTsb:
                                        uPgOfst=(c16Tsb0Size/gSectorPerPlaneH-1);
                                        break;
#endif
                                    default:
                                        break;
                                }    /* switch */

                                if((uPgOfst==mGetMetaWproPgOfst(usBlkSprInfo))&&
                                   (chkWproPageIsGood(uCurWproType, u16FBlock, mGetMetaWproIdxPg(usBlkSprInfo))))
                                {
                                    uFinish=1;
                                    break;
                                }
                            }
                            else if(uCurWproType>cMaxWproPageType)    // cMaxWproPageType == padding
                            {
#if _EN_KEEP_RW_ON_ERROR    // Chief_20190305
                                relinkKeepRwonError(cRebuWproInfo1, uCurWproType, 0x00, 0x00);
#else
                                // debugRdlinkDeadLock();
                                relinkSaveDummyQBAnalysis(uCurWproType, 0, 0, 0);
                                relinkSaveQBDummy(cRebuWproInfo1);    // debugRdlinkDeadLock();
#endif
                            }
                        }
                        else if(mGetMetaBlockId(usBlkSprInfo)!=0xFF)
                        {
#if _EN_KEEP_RW_ON_ERROR    // Chief_20190305
                            relinkKeepRwonError(cRebuWproInfo2, mGetMetaBlockId(usBlkSprInfo), 0x00, 0x00);
#else
                            // debugRdlinkDeadLock();
                            relinkSaveDummyQBAnalysis(mGetMetaBlockId(usBlkSprInfo), 0, 0, 0);
                            relinkSaveQBDummy(cRebuWproInfo2);    // debugRdlinkDeadLock();
#endif
                        }

                        u16WproPagePtr-=mGetMetaWproPgOfst(usBlkSprInfo);
                        uCh=gTotalChNum;
                    }
                    else
                    {
                        addRdlinkLog(0x1111);
                        addRdlinkLog(u16WproPagePtr);
                        addRdlinkLog(u16FBlock);
                        addRdlinkLog((usTmpAddrInfo.uIntlvAddr<<10)|usTmpAddrInfo.u16FPage);
                        addRdlinkLog((usTmpAddrInfo.uCh<<8)|usTmpAddrInfo.uPlaneAddr);

                        gsRdlinkInfo.ubMultiCopiesErr=1;
                    }

                    usTmpAddrInfo.uIntlvAddr=uIntlvAddr1;
                    usTmpAddrInfo.uPlaneAddr=uPlaneAddr1;
                }

                if(u16WproPagePtr)
                {
                    u16WproPagePtr--;
                }
                else
                {
                    break;
                }
            }
            while(!uFinish);
        }

        for(uCurWproType=cWproCacheInfo; uCurWproType<cWproGcDesF2hTab00; uCurWproType++)
        {
            if(gsWproInfo.u16arWproIdxPagePtr[uCurWproType]!=c16BitFF)
            {
                gsWproInfo.u16arVpCnt[gsWproInfo.uarWproIdxPtr[uCurWproType]]++;
            }
        }
    }
}    /* rebuWproInfo */

void setQBootInvalid(BYTE *upQBootPgCnt, BYTE uFailId)
{
    if(gsQBootInfo.ubQBootValid)
    {
        *upQBootPgCnt=0;
        gsRdlinkInfo.uQBootFailId=uFailId;
        gsWproInfo.uarWproIdxPtr[cWproQBootPg]=0xFF;
        gsWproInfo.u16arWproIdxPagePtr[cWproQBootPg]=c16BitFF;
        gsQBootInfo.ubQBootValid=0;
    }
}







