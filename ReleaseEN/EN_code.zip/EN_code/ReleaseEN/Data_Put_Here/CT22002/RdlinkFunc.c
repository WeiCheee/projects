







#if (C_Log_SaveMask&C_Debug_P1)    // 20181102_Bill rdlink
#include "inc/DebugLog.h"
#include "inc/EventLogIDX.h"
#include "inc/EventLogFunctionIDX.h"
#endif

void restoH2fTabPtr()
{
    WORD u16Idx;

    for(u16Idx=0; u16Idx<g16HmbMaxTableNum; u16Idx++)
    {
        if(g16arH2fBackup[u16Idx]!=c16BitFF)
        {
            if(g16arH2fTabPtr[u16Idx+g16TotalHBlock]!=c16BitFF)
            {
                g16arH2fTabPtr[g16arH2fBackup[u16Idx]]=g16arH2fTabPtr[u16Idx+g16TotalHBlock];
            }

            g16arH2fBackup[u16Idx]=c16BitFF;
            g16arH2fTabPtr[u16Idx+g16TotalHBlock]=c16BitFF;
        }
    }
}    /* restoH2fTabPtr */

/* // move to core 0 main
   * void saveRdTimeStamp(BYTE state)
   * {
   *  if(gsRdlinkInfo.u32RdlinkTimeStamp[state]==c32BitFF)
   *  {
   *      gsRdlinkInfo.u32RdlinkTimeStamp[state]=rmGetRtc32kTick;
   *  }
   * }
   */

void initVarInCacheInfoTab()
{
    WORD u16Fblock, u16Idx;
    BYTE uType2Ptr;

    // set original bad block information
#if _WO_INFOB
    bopClrRam(c32Tsb0SAddr, c16MaxBlockNum/8, 0x00000000, cClrTsb|cBopWait);
#else
    if(loadInfoPage(gBadBlockBitMapStartPage, ((c16MaxBlockNum/8)+0x01FF)/0x0200, c16Tsb0SIdx, 0, cSysBlock1stInfo, 0)!=0)
    {
        // Latter Bad Bitmap (Org+Other-Diff)
        debugDeadLock(0x0002|c16Bit15);
    }
#endif

#if _PRJ_ISP|_ByPassRdLink
#if _FIX_SLC_Boundary
    gsCacheInfo.u16SpareBlockCnt=gMinStaticSlcCnt;
    gsCacheInfo.u16TLCSprBlockCnt=g16TotalFBlock-gMinStaticSlcCnt-g16FirstFBlock;
#else
    gsCacheInfo.u16SpareBlockCnt=g16TotalFBlock;
    gsCacheInfo.u16TLCSprBlockCnt=0;
#endif
    gsCacheInfo.uDiffType2SprBlkCnt=0;
#endif
    // g16arGlobEraseCnt=&g16arTempGlobEraseCnt[0] ;//for core0 use temp globEraseCnt but don't need modify macro
    // bopClrRam((LWORD)g32arGlobEraseCnt, c16MaxBlockNum*2, 0x00000000, cClrTsb|cBopWait);
    bopClrRam((LWORD)g16arTempGlobEraseCnt, c16MaxBlockNum*2, 0x00000000, cClrTsb|cBopWait);

#if _EN_VPC_SWAP
    bopClrRam((LWORD)g16arGlobReadCnt, c16MaxBlockNum*2, 0x00000000, cClrTsb|cBopWait);
    bopClrRam((LWORD)garGlobReadCntHighByte, c16MaxBlockNum, 0x00000000, cClrTsb|cBopWait);
#endif

    for(u16Idx=0; u16Idx<(c16MaxBlockNum/8); u16Idx++)
    {
        g32arPopDeniedFlag[u16Idx]=0x00000000;
    }

    for(u16Fblock=0; u16Fblock<g16FirstFBlock; u16Fblock++)
    {
#if _PRJ_ISP|_ByPassRdLink
#if _FIX_SLC_Boundary
        if(u16Fblock<gMinStaticSlcCnt)
        {
            gsCacheInfo.u16SpareBlockCnt--;
        }
        else
        {
            gsCacheInfo.u16TLCSprBlockCnt--;
        }
#else
        gsCacheInfo.u16SpareBlockCnt--;
#endif
#endif

        mSetPoppedBitRL(u16Fblock);

        if(mChkBitMask(garTsb0[0][u16Fblock>>3], u16Fblock&0x07))
        {
            mSetGlobEraseCntRL(u16Fblock, c16BitFF);
        }

        setGlobEraseCnt1Blk(u16Fblock, g16arTempGlobEraseCnt[u16Fblock], 1);
    }

    // test sample......
    // mSetBitMask(garTsb0[0][0x0A>>3], 0x0A&0x07);    // ?????????????????????

#if (_GREYBOX)
    mSetBitMask(garTsb0[0][g16FirstFBlock>>3], g16FirstFBlock&0x07);
#endif

    for(; u16Fblock<g16TotalFBlock; u16Fblock++)
    {
        if(mChkBitMask(garTsb0[0][u16Fblock>>3], u16Fblock&0x07))
        {
#if _PRJ_ISP|_ByPassRdLink
#if _FIX_SLC_Boundary
            if(u16Fblock<gMinStaticSlcCnt)
            {
                gsCacheInfo.u16SpareBlockCnt--;
            }
            else
            {
                gsCacheInfo.u16TLCSprBlockCnt--;
            }
#else
            gsCacheInfo.u16SpareBlockCnt--;
#endif
#endif
            mSetPoppedBitRL(u16Fblock);
            mSetGlobEraseCntRL(u16Fblock, c16BitFF);
            setGlobEraseCnt1Blk(u16Fblock, g16arTempGlobEraseCnt[u16Fblock], 1);
        }
    }

    getDiffType2Offset();

    for(uType2Ptr=0; uType2Ptr<gDiffType2Num; uType2Ptr++)    // let popSpareBlock not get Type2Block
    {
        mSetPoppedBitRL(g16arTempDiffType2Offset[uType2Ptr]);
#if _PRJ_ISP|_ByPassRdLink
#if _FIX_SLC_Boundary
        if(g16arTempDiffType2Offset[uType2Ptr]<gMinStaticSlcCnt)
        {
            gsCacheInfo.u16SpareBlockCnt--;
        }
        else
        {
            gsCacheInfo.u16TLCSprBlockCnt--;
        }
#else
        gsCacheInfo.u16SpareBlockCnt--;
#endif
#endif
        setGlobEraseCnt1Blk(g16arTempDiffType2Offset[uType2Ptr], g16arTempGlobEraseCnt[g16arTempDiffType2Offset[uType2Ptr]], 1);
    }

#if _PRJ_ISP|_ByPassRdLink
    gsCacheInfo.uDiffType2SprBlkCnt=gDiffType2Num;
    // setGlobEraseCnt();
#endif

    // 4K valid cout
#if _EN_VPC_SWAP
    g32arCacheBlkVpCnt=(volatile LWORD *)cCacheBlkVpCntBootStrAddr;
    bopClrRam((LWORD)g32arMlcMoBit, c16MaxBlockNum/8, 0x00000000, cClrTsb|cBopWait);
    bopClrRam((LWORD)g32arSkipGcSrch, c16MaxBlockNum/8, 0xFFFFFFFF, cClrTsb|cBopWait);
    bopClrRam((LWORD)g32arVPCntValid, c16MaxBlockNum/8, 0x00000000, cClrTsb|cBopWait);
    bopClrRam((LWORD)g32arCacheBlkVpCnt, c16MaxBlockNum*4, 0x00000000, cClrTsb|cBopWait);
#else
    bopClrRam((LWORD)g32arCacheBlkVpCnt, c16MaxBlockNum*4, c32Bit31, cClrTsb|cBopWait);
#endif
    // bopClrRam((LWORD)g32arH2fTabBlkSn, (LWORD)g16PushSpareCnt-(LWORD)g32arH2fTabBlkSn, 0xFFFFFFFF, cClrTsb|cBopWait);
    bopClrRam((LWORD)g32arH2fTabBlkSn, (LWORD)garPushSpareQ-(LWORD)g32arH2fTabBlkSn, 0xFFFFFFFF, cClrTsb|cBopWait);
    bopClrRam((LWORD)g16arH2fTabBlkVpCnt, c16MaxH2fTabBlkNum*2, 0x0, cClrTsb|cBopWait);

    initSlcQCore0();

    gsCacheInfo.u32arDiffType2PopBit[0]=0;
    gsCacheInfo.u32arDiffType2PopBit[1]=0;

    gsRdlinkInfo.u16BkActiveCacheBlock=c16FBlockInitValue;
    gsRdlinkInfo.u16BkActiveGcDesBlock=c16FBlockInitValue;
    gsRdlinkInfo.u16BkFluCacheBlock=c16FBlockInitValue;
    gsRdlinkInfo.u16BkPrePopCacheBlock=c16FBlockInitValue;
    gsRdlinkInfo.u16BkGcDesSlcBlock=c16FBlockInitValue;
    gsRdlinkInfo.u16BkGcDesTlcBlock=c16FBlockInitValue;
    gsRdlinkInfo.uPreRdLkMigrateTyp=0xFF;
    g16BkRdActiveCacheBlock=c16FBlockInitValue;
    g16BkRdFlushCacheBlock=c16FBlockInitValue;
    g16BkH2fTabFreePagePtr=c16BitFF;
    g16BkActH2fTabFblk=c16BitFF;

    gsFtlDbg.u32PowerOnCnt=0x0;
    gsFtlDbg.u32UGSDPwrOnCnt=0;
    gsFtlDbg.u32GSDPwrOnCnt=0;
    g16PushSpareCnt=0;
    gPowerDownMode=cUGSD;
    g16PushSpareTail=g16PushSpareHead=0;
    g32MaxRebuTime=0;

    // gsFtlDbg.u16MaxPushSpareCnt= 0;
    gsGcInfo.u32TotalSlcVpc=0;
    gsGcInfo.u32TotalTlcVpc=0;
    g16CurrSlcCacheBlockThr=g16MaxSlcCacheBlockThr=(g16TotalFBlock-g16FirstFBlock-gDiffType2Num)>>1;
    // gsCacheInfo.u64TotalTlcOneShotCnt=0x8000000;    // 12T /(one shot sector count)
    // gsFtlDbg.u64TotalTlcOneShotCnt=0x8000000;    // 12T /(one shot sector count)
    gsFtlDbg.u64TotalSlcProgCnt=0;
    g32WearLevelCnt=0;
    gsFtlDbg.u32ForceCleanCnt=0;
    g16BkGcDesSlcBlock=c16FBlockInitValue;
    g16BkGcDesTlcBlock=c16FBlockInitValue;
    g32BkTotalSlcVpc=0;
    g32BkTotalTlcVpc=0;
    g32BkCacheBlkSerial=c32InitSerialVal;
    gBkFidBlock=0xFF;
    mRstCacheInfoSpf;
    g16WLCheckBlk=g16StaticBound;    // g16FirstFBlock; //20190218_Louis

    for(uType2Ptr=0; uType2Ptr<cMaxGcPrioBlkNum; uType2Ptr++)
    {
        gsGcInfo.u16Gc1stPrioTlcBlock[uType2Ptr]=0xFFFF;
        gsGcInfo.uGc1stPrioTlcBlockTyp[uType2Ptr]=0xFF;
        gsGcInfo.u16GcRCSlcBlock[uType2Ptr]=0xFFFF;
    }

    g16TotalProgFailCnt=0;
    g16RaidDecTotalCnt=0;
    g16RaidDecSkipCnt=0;
    gsFtlDbg.u16RaidDecH2fPassCnt=0;
    gsFtlDbg.u16RaidDecH2fFailCnt=0;
    gsFtlDbg.u16RaidDecDataPassCnt=0;
    gsFtlDbg.u16RaidDecDataFailCnt=0;
    gRaidMaxPopEngCnt=0;

    gsRdlinkInfo.ubSaveCacheInfo=1;
    g32MaxS2TGCtime=0;
    g32MaxT2TGCtime=0;
    gsFtlDbg.uStaticMode=cDynamicMode;

#if _EN_IDLEGC_DELAY
    gBgdGCWakeUp=0;
    g32IdleGcDelayTime=0;
#endif

#if _EN_Dynamic_Fix_Boundary
    BYTE uSLCBlkCnt=0;

    for(u16Fblock=g16FirstFBlock; u16Fblock<g16TotalFBlock; u16Fblock++)
    {
        if(!mChkPoppedBitRL(u16Fblock))
        {
            uSLCBlkCnt++;

            if(uSLCBlkCnt==gMinStaticSlcCnt)
            {
                break;
            }
        }
    }

    g16StaticBound=u16Fblock+1;
    g32StaticSLCTotalEC=0;
    g32DynamicSLCTotalEC=0;
#else/* if _EN_Dynamic_Fix_Boundary */
    BYTE uSLCBlkCnt=0;
    gsFtlDbg.uStaticMode=cEndStaticMode;

    for(u16Fblock=g16FirstFBlock; u16Fblock<g16TotalFBlock; u16Fblock++)
    {
        mClrMlcMoBit(u16Fblock);

        if(!mChkPoppedBitRL(u16Fblock))
        {
            uSLCBlkCnt++;

            if(uSLCBlkCnt==gMinStaticSlcCnt)
            {
                break;
            }
        }
    }

    g16StaticBound=u16Fblock+1;

    for(u16Fblock=g16StaticBound; u16Fblock<g16TotalFBlock; u16Fblock++)
    {
        mSetMlcMoBit(u16Fblock);
    }
#endif/* if _FIX_SLC_Boundary */
    // gPCIEerrCnt=0;
}    /* initVarInCacheInfoTab */

#if 0    // BUG_VPCNT //move to FtlPub.c
void chkVpCnt()
{
    WORD u16Hblock, u16H4k, u16Fblock;
    UCLWORD *u32pTsb0=(UCLWORD *)garTsb0[0];
    UCLWORD *u32pH2f=(UCLWORD *)garTsb0[c16Tsb0SIdx+cH2fTabSctrSize];
    BLKSPRINFO usBlkSprInfo;

    bopClrRam(c32Tsb0SAddr, g16TotalFBlock*4, 0x00000000, cClrTsb|cBopWait);

    for(u16Hblock=0; u16Hblock<g16TotalHBlock; u16Hblock++)
    {
        if(g16arH2fTabPtr[u16Hblock]!=c16H2FTabInitValue)    // !mChkH2fTabNullF(u16Hblock))
        {
            swapH2fTable(u16Hblock, c16Tsb0SIdx+cH2fTabSctrSize, 1);
            // waitCmdAllDone(cWaitTrigRCnt|cWaitCmdBz);    // (F) Ecc Fail use /*|c16Bit15*/ to do

            for(u16H4k=0; u16H4k<g16PagePerH2fTab; u16H4k++)
            {
                u16Fblock=mGetSrcFBlkAddr(u32pH2f[u16H4k]);

                if(u16Fblock!=c16FBlockInitValue)
                {
                    if((u16Fblock>=g16TotalFBlock)||(u16Fblock<g16FirstFBlock))
                    {
                        debugLoop();
                    }

                    u32pTsb0[u16Fblock]++;

                    if(mChkMlcMoBit(u16Fblock))
                    {
                        if(u32pTsb0[u16Fblock]>g32VpcPerTlcBlk)
                        {
                            // debugRdlinkDeadLock();
                            debugLoop();
                        }
                    }
                    else
                    {
                        if(u32pTsb0[u16Fblock]>g32VpcPerSlcBlk)
                        {
                            // debugRdlinkDeadLock();
                            debugLoop();
                        }
                    }
                }
            }
        }
    }

    for(u16Fblock=g16FirstFBlock; u16Fblock<g16TotalFBlock; u16Fblock++)
    {
        if(u32pTsb0[u16Fblock]!=mGetCacheBlkVpCnt(u16Fblock))
        {
            debugLoop();
        }
    }
}    /* chkVpCnt */

#endif/* if _DEBUG_VPCNT */

#if _DEBUG_PWRCYL
void debugPwrCyl(WORD u16DebugId)
{
    if(!gsRdlinkInfo.u16DebugId)
    {
        gsRdlinkInfo.u16DebugId=u16DebugId;
    }

    waitAllChCeBzCore0();

    // temporarily remove
    // rmEnFwp;
    // mSetDummyReadWrite;
}

#else
void debugPwrCyl(WORD u16DebugId)
{
    gsRdlinkInfo.u16DebugId=u16DebugId;
}

#endif/* if _DEBUG_PWRCYL */

#if _ENABLE_RAID
void setRaidPara()
{
    WORD u16RaidSize;
    BYTE uIdx;

    // for raid test, set para to raid use
    g16ValidPgPerF2hTab-=c4kNumPerRaidPty;
#if _EN_RAID_GC
    g16TlcValidPgPerF2hTab-=c4kNumPerRaidPty;
#endif
    gsCacheInfo.uRaidPtr=0;
    gsCacheInfo.uRaidPtrGc=0;
    gsCacheInfo.u16PartialParityPtr=0;
    gsCacheInfo.u16PartialParityPtrGc=0;
    gsCacheInfo.uRaidF2HBank=0;
    gsCacheInfo.uRaidF2HBankGc=0;

    // skip last channel when raid parity program
    g16ProgRaidUnit=(gTotalIntlvChNum*g4kNumPerPage);
    g16Raid4KStrInPage=g16ProgRaidUnit-g4kNumPerPage;

    // Partial Raid
    g16PartialRaidUnit=((cRaidTotalEng/(g4kNumPerPage/cRaidEngineBuf4KSize))*(gTotalIntlvChNum*g4kNumPerPage));

    g16TlcPartialParityNum=(g16TotalTlcPgPerF2hTab/(cProgCntPerWL*gTotalIntlvChNum*g4kNumPerPage))-cRaidParityNum;
    g16SlcPartialParityNum=(g16TotalPgPerF2hTab/(gTotalIntlvChNum*g4kNumPerPage))-cRaidParityNum;

    // TLC Raid
    u16RaidSize=
        (((cRaidParityNum-1)*(cProgCntPerWL)*gTotalIntlvChNum*g4kNumPerPage)+((cProgCntPerWL-1)*gTotalIntlvChNum*g4kNumPerPage)+g4kNumPerPage);
    g16TlcProgRaidChStr4K=g16TotalTlcPgPerF2hTab-u16RaidSize;

    for(uIdx=0; uIdx<cRaidParityNum; uIdx++)
    {
        u16RaidSize=(((cRaidParityNum-1-uIdx)*(cProgCntPerWL)*gTotalIntlvChNum*g4kNumPerPage));
        g16RaidStrAddr[uIdx]=g16TotalTlcPgPerF2hTab-(u16RaidSize+((cProgCntPerWL-1)*gTotalIntlvChNum*g4kNumPerPage)+g4kNumPerPage);
    }

    // SLC Raid
    u16RaidSize=(((cRaidParityNum-1)*gTotalIntlvChNum*g4kNumPerPage)+g4kNumPerPage);
    g16SlcProgRaidChStr4K=g16TotalPgPerF2hTab-u16RaidSize;

    for(uIdx=0; uIdx<cRaidParityNum; uIdx++)
    {
        u16RaidSize=(((cRaidParityNum-1-uIdx)*gTotalIntlvChNum*g4kNumPerPage));
        g16SlcRaidStrAddr[uIdx]=g16TotalPgPerF2hTab-(u16RaidSize+g4kNumPerPage);
    }
}    /* setRaidPara */

#endif/* if _ENABLE_RAID */

void setF2hPadPara()
{
    LWORD u32SORTF2HTAB;
    WORD u16StarIdx=0;    // , u16DesStrOffset;

    // prevent SORTF2HTAB struct overflow
    u32SORTF2HTAB=sizeof(SORTF2HTAB);

    while(u32SORTF2HTAB>cSortF2HTabSise)
        ;

#if _ENABLE_RAID
    setRaidPara();
#endif

    // if(g16TotalTlcPgPerF2hTab>g16TotalPgPerF2hTab)
    // {
    //    gsCacheInfo.u16MaxTotalPgPerF2hTab=g16TotalTlcPgPerF2hTab;
    // }
    // else
    // {
    gsCacheInfo.u16MaxTotalPgPerF2hTab=g16TotalPgPerF2hTab;
    // }

#if _EN_RDLINK_PF
    // TODO: for start flush points are the same in ever bank.
    g16ChkFlushSize=gTotalIntlvChNum*4*g4kNumPerPage;
#else
    // g16ChkFlushSize=gTotalIntlvChNum*8*g4kNumPerPage;
    g16ChkFlushSize=gTotalIntlvChNum*cProgCntPerWL*g4kNumPerPage;
#endif

    if(g16ChkFlushSize<(c16WriteBufSize>>3))
    {
        g16ChkFlushSize=(c16WriteBufSize>>3);
    }

    g16FlushStr4K=0;
    g16FlushRem4K=0;

    g16FlushStr4K=g16ChkFlushSize-(c16WriteBufSize>>3);

    if(g16FlushStr4K)
    {
        g16FlushRem4K=(c16WriteBufSize>>3);
        g16FlushChkStart=g16ChkFlushSize;
    }
    else
    {
        g16FlushRem4K=0;
        g16FlushChkStart=g16ChkFlushSize*2;
    }

    // TLC

    if(g16FlushStr4K)
    {
        g16TlcF2hChkStart=g16ChkFlushSize*2;
    }
    else
    {
        g16TlcF2hChkStart=g16ChkFlushSize*3;
    }

    g16TlcF2hChkSize=g16ChkFlushSize*2;

    if(g16TotalTlcPgPerF2hTab%g16ChkFlushSize)
    {
        g16TlcF2hChkStart+=g16ChkFlushSize;
        g16TlcF2hChkSize+=g16ChkFlushSize;
    }

    // u16DesStrOffset=((cProgCntPerWL-1)*gTotalChNum*g4kNumPerPage);

    gTlc4KNumToPadF2h=mod(((g16TotalTlcPgPerF2hTab>>10)+c4kNumPerRaidPty), g4kNumPerPage);
    gTlcPadF2h4KNum=div(gTlc4KNumToPadF2h+(g4kNumPerPlane-1), g4kNumPerPlane)*g4kNumPerPlane;
    gTlc4KNumToPadF2h=g4kNumPerPage-gTlcPadF2h4KNum;

    if(!gTlc4KNumToPadF2h)
    {
        gTlc4KNumToPadF2h=g4kNumPerPage;
        gTlcPadF2h4KNum=0;
    }

    g16PadF2hTabPgEnd=g16TlcValidPgPerF2hTab;    // -u16DesStrOffset;
    g16PadF2hTabPgStr=g16PadF2hTabPgEnd-gTlc4KNumToPadF2h;

    gTlcProgF2HRem4KNum=(gTlcTotal4kNumOfF2hTab+c4kNumPerRaidPty-gTlcPadF2h4KNum);

    g16ProgF2hTabStr=g16PadF2hTabPgStr+g4kNumPerPage;
    g16ProgF2hTabEnd=g16ProgF2hTabStr+gTlcProgF2HRem4KNum;

    gTlcSecNumPadF2h_1=gTlcPadF2h4KNum*cSctrPer4k;
    gTlcSecNumPadF2h_2=gTlcProgF2HRem4KNum*cSctrPer4k;    // g4kNumPerPage*cSctrPer4k;

    if(gTlcSecNumPadF2h_2>(g4kNumPerPage*cSctrPer4k))
    {
        gTlcSecNumPadF2h_2=g4kNumPerPage*cSctrPer4k;
    }

    if(gTlcPadF2h4KNum)
    {
        u16StarIdx=div((g16TotalTlcPgPerF2hTab>>10), g4kNumPerPage)*g4kNumPerPage*cSctrPer4k;
    }
    else
    {
        u16StarIdx=0;
    }

    g16TlcF2hPadStartAddr_2=c16CacheF2hTabSIdx;
    g16TlcF2hPadStartAddr_1=c16CacheF2hTabSIdx+u16StarIdx;

    gTlcSecNumDummyF2h=(g16TotalTlcPgPerF2hTab>>7);
    gTlcSecNumDummyF2h=(gTlcTotal4kNumOfF2hTab<<3)-gTlcSecNumDummyF2h;

    // SLC

    if(g16FlushStr4K)
    {
        g16SlcF2hChkStart=g16ChkFlushSize*2;
    }
    else
    {
        g16SlcF2hChkStart=g16ChkFlushSize*3;
    }

    g16SlcF2hChkSize=g16ChkFlushSize*2;

    if(g16TotalPgPerF2hTab%g16ChkFlushSize)
    {
        g16SlcF2hChkStart+=g16ChkFlushSize;
        g16SlcF2hChkSize+=g16ChkFlushSize;
    }

    gSlc4KNumToPadF2h=mod(((g16TotalPgPerF2hTab>>10)+c4kNumPerRaidPty), g4kNumPerPage);
    gSlcPadF2h4KNum=div(gSlc4KNumToPadF2h+(g4kNumPerPlane-1), g4kNumPerPlane)*g4kNumPerPlane;
    gSlc4KNumToPadF2h=g4kNumPerPage-gSlcPadF2h4KNum;

    if(!gSlc4KNumToPadF2h)
    {
        gSlc4KNumToPadF2h=g4kNumPerPage;
        gSlcPadF2h4KNum=0;
    }

    g16SlcPadF2hTabPgEnd=g16ValidPgPerF2hTab;
    g16SlcPadF2hTabPgStr=g16SlcPadF2hTabPgEnd-gSlc4KNumToPadF2h;

    gSlcProgF2HRem4KNum=(gTotal4kNumOfF2hTab+c4kNumPerRaidPty-gSlcPadF2h4KNum);

    g16SlcProgF2hTabStr=g16SlcPadF2hTabPgStr+g4kNumPerPage;
    g16SlcProgF2hTabEnd=g16SlcProgF2hTabStr+gSlcProgF2HRem4KNum;

    gSlcSecNumPadF2h_1=gSlcPadF2h4KNum*cSctrPer4k;
    gSlcSecNumPadF2h_2=gSlcProgF2HRem4KNum*cSctrPer4k;    // g4kNumPerPage*cSctrPer4k;

    if(gSlcSecNumPadF2h_2>(g4kNumPerPage*cSctrPer4k))
    {
        gSlcSecNumPadF2h_2=g4kNumPerPage*cSctrPer4k;
    }

    if(gSlcPadF2h4KNum)
    {
        u16StarIdx=div((g16TotalPgPerF2hTab>>10), g4kNumPerPage)*(g4kNumPerPage-c4kNumPerRaidPty)*cSctrPer4k;
    }
    else
    {
        u16StarIdx=0;
    }

#if _ENABLE_RAID
    if(gSlcPadF2h4KNum)
    {
        g16SlcF2hPadStartAddr_2=c16CacheF2hTabSIdx+u16StarIdx;
        g16SlcF2hPadStartAddr_1=c16CacheF2hTabSIdx;
    }
    else
    {
        g16SlcF2hPadStartAddr_2=c16CacheF2hTabSIdx;
        g16SlcF2hPadStartAddr_1=c16CacheF2hTabSIdx+u16StarIdx;
    }
#else
    g16SlcF2hPadStartAddr_2=c16CacheF2hTabSIdx;
    g16SlcF2hPadStartAddr_1=c16CacheF2hTabSIdx+u16StarIdx;
#endif

    gSlcSecNumDummyF2h=(g16TotalPgPerF2hTab>>7);
    gSlcSecNumDummyF2h=(gTotal4kNumOfF2hTab<<3)-gSlcSecNumDummyF2h;

    gsCacheInfo.uChkF2hRegion=0;
}    /* setF2hPadPara */

#if _EN_WUNCTable    // WUNCTable Chief_21081121
void initWuncTableVar()
{
    NLOG(cLogHost, RDLINKFUNC_C, 0, "initWuncTableVar");

    for(BYTE uIdx=0; uIdx<C_MaxWUNCLAACnt; uIdx++)
    {
        gsWUNCInfo.uWuncCnt=0;
        gsWUNCInfo.u16HBlock[uIdx]=c16BitFF;
        gsWUNCInfo.u16HPage[uIdx]=c16BitFF;
        gsWUNCInfo.uBitMap[uIdx]=0;
    }
}

#endif

void initWproVar()
{
    fillCcmVal((BYTE *)&gsWproInfo, sizeof(gsWproInfo), 0xFF);
    gsWproInfo.uCnt=0;
    gsWproInfo.uWPROFull=0;
    gsWproInfo.uSwap=0;
    fillCcmVal((BYTE *)&gsWproInfo.u16arVpCnt, cMaxWproBlkCnt*2, 0x0);
    fillCcmVal((BYTE *)&gsRdlinkInfo.u16arWproBlk, cMaxWproBlkCnt*2, 0xFF);

    /*
       *  Hynix V3, write 2 ch one time
       *  4ch, 1 way, page count = page number * plane number * 2 = 3072
       *  4ch, 2 way, page count = 3072 * 2 = 6144;
       *  4ch, 4 way, page count = 3072 * 2 = 12288;
       */

    gsWproInfo.u16PagePerBlock3=g16PagePerBlock3_SLC>>1;    // cWriteChNum);
    gsWproInfo.u16CacheInfoPlaneSize=0;
#if _EN_WUNCTable    // WUNCTable Chief_21081121
    initWuncTableVar();
#endif
}

void addRdlinkLog(WORD u16LogData)
{
#if (!_ICE_DEBUG)
    if(g16RdlinkLogUpdPtr<(c16RdlinkLogSize/2))
    {
        g16arRdlinkLog[g16RdlinkLogUpdPtr]=u16LogData;
        g16RdlinkLogUpdPtr++;
    }
#endif
}

void setGcInfoThr()
{
#if 1
    // WORD u16Sprb4Cacheb, u16Sprb4NonCacheb;
    BYTE uTotalH2fbCnt;

    // WORD u16FBlock, u16FBlockCnt=0;

    // gsGcInfo.u16GcSrcBlock=0xFFFF;
    for(BYTE uBlkCnt=0; uBlkCnt<cMaxGcSrcBlkNum; uBlkCnt++)
    {
        gsGcInfo.u16GcSrcBlock[uBlkCnt]=0xFFFF;
        gsGcInfo.uGcSrcBlkIdx[uBlkCnt]=uBlkCnt;
        // gsGcInfo.u32GcSrcBlkInvldVpc[uBlkCnt]=0x00000000;
    }

    gsGcInfo.u16GcDesBlock=c16FBlockInitValue;
    gsGcInfo.u16GcDesSLCBlock=c16FBlockInitValue;
    gsGcInfo.u16GcDesTLCBlock=c16FBlockInitValue;
    gsGcInfo.uGcH2fTabBlkIdx=0xFF;
    gsGcInfo.u32GcDesSerial=c32InitSerialVal;

    gsGcInfo.u16EntryInPlane=gSectorPerPlaneH<<7;    // *512/4
    gsGcInfo.u16GapOfMoveTab=gSectorPerPlaneH<<10;    // *512*2

    // gsGcInfo.upDesF2hTabStPtr=(_Uncached F2HTABLE *)garTsb0[c16GcDesF2hSIdx];
    // mSetGcFlag(cGcInfobFull);
    mSetGcFlag(cGcDesFull);
    // gsGcInfo.ubGcSrcValid=0;
    // mClrGcFlag(cWaitLastDesfullB4S2T);
    // gsGcInfo.uTlcUpdataH2FSdGrp=0;
    // gsGcInfo.uTlcPostWrRdSdGrp=0;
    // mClrGcFlag(cForQBoot);
    // gsGcInfo.u16FlushDesTabCnt=0;
    // gsGcInfo.u32CloseDesCnt=0;
    uTotalH2fbCnt=((g16TotalHBlock*gTotalPlaneOfH2fTab)+(g16PagePerBlock3_SLC-1))/g16PagePerBlock3_SLC;
    gsGcInfo.uPwrOnGcTimeLimit=8;
    gsGcInfo.u32PwrOnExtraGcTimeLimit=2;    // test

    if(uTotalH2fbCnt<4)
    {
        gsGcInfo.uGcH2fTabbHiThr=uTotalH2fbCnt+2;
        gsGcInfo.uGcH2fTabbLoThr=uTotalH2fbCnt+1;
    }
    else
    {
        gsGcInfo.uGcH2fTabbHiThr=uTotalH2fbCnt+div(uTotalH2fbCnt, 2)+1;
        gsGcInfo.uGcH2fTabbLoThr=uTotalH2fbCnt+div(uTotalH2fbCnt, 4)+1;
    }

    while(gMaxH2fTabBlkNum<=gsGcInfo.uGcH2fTabbHiThr)
        ;

    // gsGcInfo.u16GcTotalSrchUnit=g16TotalPgPerF2hTab;    // *2;
    // gsGcInfo.u16GcS2tMinThr=(uTotalH2fbCnt>>1)+cT2sObpBlkNum3+cSprbCnt2ExitGc;    // suppose H2f table double

    // gsGcInfo.u16S2TVpcThr=div(g32VpcPerSlcBlk*800, 1000);
    // gsGcInfo.u16S2TVpcThr=g16VpcPerSlcBlk;    // 32736
    gsGcInfo.u32PWRFailCnt=0;
// #if _FIX_SLC_Boundary
//    gsGcInfo.u16GcCachebActThr=cMaxGcSrcBlkNum*2;
// #else
    // gsGcInfo.u16GcCachebActThr=(g16TotalFBlock>>5)+cSprbCnt2ExitGc+gsGcInfo.uGcH2fTabbHiThr;    // redef later???????????????????????
    // gsGcInfo.u16GcCachebActThr=(g16TotalFBlock-g16TlcFullCachebGcThr)+g16LaterBadBlockCnt+gDiffType2Num+2+3;    // 2:system block num 3: WPRO
    // gsGcInfo.u16GcCachebActThr=((gMinStaticSlcCnt-gsGcInfo.uGcH2fTabbHiThr-3)*1/3);    // 3: WPRO
    // gsGcInfo.u16BgdGcCachebActThr=gMinStaticSlcCnt/2;
    gsGcInfo.uRsvSLCBlkInBgdCln=cMinS2SSrcBlkNum;
    // gsGcInfo.u16GcCachebActThr=28;    // 107(MinStatic)-11(System)-6(RsvSLC)-66(2GB+2Blk)=24
    gsGcInfo.u16GcCachebActThr=30;    // 20;    // 107(MinStatic)-11(System)-6(RsvSLC)-66(2GB+2Blk)=24

#if _EN_VPC_SWAP
    if(g16TotalFBlock>1024)
    {
        gsGcInfo.u16GcCachebActThr=50;
    }
#endif

    gsGcInfo.u16BgdGcCachebActThr=gMinStaticSlcCnt-gsGcInfo.uGcH2fTabbHiThr-3;
/*
   *  if(gIntlvWay==1)
   *  {
   *      gsGcInfo.u16BgdGcCachebActThr=gMinStaticSlcCnt-gsGcInfo.uGcH2fTabbHiThr-3;
   *  }
   *  else
   *  {
   *      gsGcInfo.u16BgdGcCachebActThr=gsGcInfo.u16GcCachebActThr;
   *      gsGcInfo.u16BgdGcCachebActThr+=(((4096*(2048/gSectorPerPlaneH))+g16PagePerBlock3_SLC-1)/g16PagePerBlock3_SLC);    // 3GB reserve
   *      gsGcInfo.u16BgdGcCachebActThr+=2;    // pop block and invalid block
   *
   *      while(gsGcInfo.u16BgdGcCachebActThr>=(gMinStaticSlcCnt-gsGcInfo.uGcH2fTabbHiThr-3))
   *          ;
   *  }
   */
// #endif
    // gsGcInfo.u16GcCachebActThr=923;    // -112;// for test
    // gsGcInfo.u16BgdClnStopSprblkThr=gsGcInfo.u16GcCachebActThr+12*1024*1024/4/10/(g32VpcPerSlcBlk)+1;    // gsGcInfo.u16GcCachebActThr+1.2GB
    // gsGcInfo.u16BgdClnStartSprblkThr=div((gsGcInfo.u16GcCachebActThr+gsGcInfo.u16BgdClnStopSprblkThr), 2);

    // gsGcInfo.u32HostWr4kCnt=0;
    // gsGcInfo.u32Wr4kCnt4Gc=0;
    // gsGcInfo.uDoGcPerNMB=0;
    // gsGcInfo.u32LastHostWr4kCnt=0;
    gsGcInfo.uPushSprbHiThr=32/4;
    mSetGcFlag(cStopBgdClean);
    // gsGcInfo.u16MaxMtCacheBlkCnt=32/2;    // 64;//128;
    // g100msCnt=0;
    // mClrGcFlag(cUnderSlcGc);

    // for(u16Idx=0; u16Idx<cMaxGcSkipSrchBlkCnt; u16Idx++)
    // {
    // g16GcSkipSrchActBlk[u16Idx]=0xFFFF;
    // }

    // gGcSkipSrchActBlkCnt=0;

    // gsGcInfo.u32AvgSlcVpcPerBlk=0;
    // gsGcInfo.u32AvgTlcVpcPerBlk=0;
    // gsGcInfo.u32SlcAvgVpcPtg=0;
    // gsGcInfo.u32TlcAvgVpcPtg=0;
    // gsGcInfo.uSdGrpOvrS2TThrBlkCnt=0;

    // gsGcInfo.uTlcF2hTabBank=cPartialCleanTmer20ms;
    mSetGcFlow(cGcFlowIdl);
    // gsGcInfo.u16arSrcSlcBlock=0xFFFF;

    bopClrRam((LWORD)&g32GcSkipSrcHblkSrch, c16MaxH2fTabNum/8, 0x00000000, cClrTsb|cBopWait);
    // bopClrRam((LWORD)&g32GcS2tH2fSkpSrcHblkSrch, c16MaxH2fTabNum/8, 0x00000000, cClrTsb|cBopWait);
    // bopClrRam((LWORD)&g32S2tUpdH2fPlnBtFlg, 2*c16CacheF2hSize/4/4/8, 0x0000_0000, cClrTsb|cBopWait);

    // bopClrRam((LWORD)&g32S2tUpdH2fPlnBtFlg, 2, 0x0000_0000, cClrTsb|cBopWait);
    // g32S2tUpdH2fPlnBtFlg[0]=0x0000_0000;
    // g32S2tUpdH2fPlnBtFlg[1]=0x0000_0000;

    // g16RRCnt=0;
    // g16RCCnt=0;
    // gsGcInfo.u16GcPer4kCnt=cGcPerBufSize4kBase;

    // gsGcInfo.uPwrOnGcTimeLimit=cbCidTable[0x27];
    // uTotalH2fbCnt=(gTotalChNum*gIntlvWay)>>8;
    // gsGcInfo.uPwrOnGcTimeLimit=cPwrOnGcTimeInSec;
    // gsGcInfo.u32PwrOnExtraGcTimeLimit=cPwrOnExtraGcTimeInSec;

    // if(uTotalH2fbCnt)
    // {
    // uTotalH2fbCnt>>=1;
    // gsGcInfo.uPwrOnGcTimeLimit<<=1;
    // }

    gsGcInfo.u32GcLeastBudget=c32PartialCleanRtc20ms;    // c32PartialCleanRtc10ms;
    // gsGcInfo.u16ReadScrubPage=0;
    // gsGcInfo.u32ReadScrubTime=cReadScrbTmrVal;
#if _EN_SLCOpenBlkReadScrub
    gsGcInfo.u16FlushBlk=c16FBlockInitValue;
    gsGcInfo.u16H2FReclaimBlk=c16FBlockInitValue;
    gsCacheInfo.u16BakF2HTabFlushStart=0;
    gsCacheInfo.u16BakF2HTabFlushEnd=g16ChkFlushSize;
#endif

    // gsGcInfo.uBgdGcTimeLimit=cbCidTable[0x28];
    mClrGcFlag(cPwOnGcF);
    mClrGcFlag(cPwOnExtraGcF);
    mClrGcFlag(cPwOnH2FGcF);
    // gsGcInfo.uReBldSrcBlk=0;
    mClrGcFlag(cGcSrchWearF);
    // mClrGcFlag(cGcSrchTlcWearF);
    mClrGcFlag(cGcSkipPrgCacheInfo);
    gsGcInfo.u32Prog4kCntPerChPg=gTotalChNum*g4kNumPerPage;
    gsGcInfo.uHMBchg=cFalse;
#endif/* if 1 */
}    /* setGcInfoThr */

/*
   * void getMaxProgPageCnt()
   * {
   #if 0    // temporarily remove
   *  gsRwCtrl.uMaxProgFifoTrigCnt=div((c16WriteBufSize/2)/cSctrPer4k, g4kNumPerPage);
   *  gsRwCtrl.uMinProgFifoUpdCnt=div(32, g4kNumPerPage);
   *
   *  gsRwCtrl.uMaxFLChFifoDpt=div(c16WriteBufSize, cSctrPer4k*gTotalChNum);
   *
   *  gsRwCtrl.u16MaxBufFree4kCnt=c16ReadBufSize/cSctrPer4k;
   *  gsRwCtrl.u16BufOvfl4kThr=div(gSectorPerPageH, cSctrPer4k);
   *  // gsIsrCtrl.u16BufFree4kCnt=gsRwCtrl.u16MaxBufFree4kCnt;
   *  gsPrdInfo.uQCmdCnt=cPrdDepth;
   *  // gsRwCtrl.uMaxReadPageCnt=64;    // gTotalCeChNum*4;
   *  gsRwCtrl.uFreeHSgmtCnt=cMaxRH2fTabNum;
   *  gsRwCtrl.u16SeqWriteSizeThr=div(g16ValidPgPerF2hTab*cSctrPer4k, 2);
   #endif
   * }
   */

void clrErrorBlock()
{
    WORD u16Loop;

    if(gsRdlinkInfo.u16ErrBlkCnt!=0)
    {
        for(u16Loop=0; u16Loop<gsRdlinkInfo.u16ErrBlkCnt; u16Loop++)
        {
            if(garErrBlock[u16Loop].u16Id&c16Bit15)
            {
                // if(!mChkSlcSkipBit(garErrBlock[u16Loop].u16FBlock))
#if !_EN_Always_DynamicMode
                if(!mChkMlcMoBit(garErrBlock[u16Loop].u16FBlock))    // incorrect
                {
                    gsCacheInfo.u16SpareBlockCnt++;
                }
                else
                {
                    gsCacheInfo.u16TLCSprBlockCnt++;
                }
#endif
#if _EN_Dynamic_Fix_Boundary
                if(gsFtlDbg.uStaticMode!=cEndStaticMode)
                {
                    if(garErrBlock[u16Loop].u16FBlock<g16StaticBound)
                    {
                        gsCacheInfo.u16SLCSpareCnt++;
                    }
                    else
                    {
                        gsCacheInfo.u16DynamicSpareCnt++;
                    }

#if _EN_Always_DynamicMode
                    gsCacheInfo.u16SpareBlockCnt++;
#endif
                }
#endif
            }
            else
            {
                debugPwrCyl(c16Bit4);
            }
        }
    }

    // bopClrRam((LWORD)&garRetryFailRec, cDgRetryFailCntRamSize, 0x00, cClrTsb|cBopWait);
}    /* clrErrorBlock */

void setRebuAbnorInfo(WORD u16AbnorId)
{
    if(!gsRdlinkInfo.ubAbnorScenario&&!(u16AbnorId&c16Bit15))
    {
        gsRdlinkInfo.ubAbnorScenario=1;
        gsRdlinkInfo.u16AbnorId=u16AbnorId;
    }

    debugRdlinkDeadLock();
    // debugLoop();
}

#if 1    // !_ICE_DEBUG
BYTE chkPwrOnByQBootInfo()
{
    // WORD u16Fblock= cInvldFBlk;
    BYTE uLoop;
    // HMBINFO *upHmbInfo=(HMBINFO *)(c32Tsb0SAddr+c32HMBInfoVarAddr);
    // WPROINFO *upWproInfo=(WPROINFO *)(c32Tsb0SAddr+c32WproInfoVarAddr);
    RWCTRL *upRwCtrl=(RWCTRL *)(c32Tsb0SAddr+c32RwCtrlVarAddr);

    mSetCalWriteSctr2ChgBlk;
#if (!_EN_D3Hot_PS4)
#if _EN_IDLEGC_DELAY
    gBgdGCWakeUp=1;

    if(!gsQBootInfo.ubQBootValid)
    {
        g32IdleGcDelayTime=0;
    }
#endif
#endif    // _EN_D3Hot_PS4
#if (!_DEBUG_QBOOT)
#if (C_Log_SaveMask&C_Debug_P1)    // 20181102_Bill rdlink
    NLOG(cLogBuild, RDLINKFUNC_C, 1, "chkPwrOnByQBootInfo() Start  gsQBootInfo.ubQBootValid = 0x%04X", gsQBootInfo.ubQBootValid);    // 20181102_Bill
#endif

    if(gsQBootInfo.ubQBootValid)
    {
#if _EN_VPC_SWAP
        BYTE uQbootTyp;

        if(mChkDummyWrite)
        {
            uQbootTyp=cWproQBWithDumyW;
        }
        else
        {
            uQbootTyp=cWproQBootPg;
        }

        g32arCacheBlkVpCnt=(volatile LWORD *)cCacheBlkVpCntBootStrAddr;
        readWproPageCore0(uQbootTyp, c16Tsb0SIdx, 0);    // readWproPage(cWproQBootPg, c16Tsb0SIdx, 0);
#else
        readWproPageCore0(mChkDummyWrite?cWproQBWithDumyW:cWproQBootPg, c16Tsb0SIdx, 0);    // readWproPage(cWproQBootPg, c16Tsb0SIdx, 0);
#endif
        /*
           * #if !_Dis_F2hPBit
           * gsCacheInfo.uCacheF2hPBitTabCnt=0;
           * #endif
           */
        // fillRegVal(&garRsvUCBYTE[0][0], cMaxChNum*cMaxCePinNum*cMaxIntIntlvNum, 0x00);

        // while (gsRwCtrl.u16ProgPageOfst!=0);
        // while (gsRwCtrl.uCacheStartSctr!=0);
        // while (gsRwCtrl.uCacheEndSctr!=cSctrPer4k);
        // while (gsCacheInfo.u16CacheInfoBlk!=gsRdlinkInfo.u16CacheInfoBlk);
        // while (gsCacheInfo.u16CacheInfoSerial!=gsRdlinkInfo.u16CacheInfoSerial);
        // while (gsCacheInfo.u16CacheInfoFreePagePtr!=gsRdlinkInfo.u16CacheInfoFreePagePtr);

        // while(upHmbInfo->uHmbCache4kCnt)
        //    ;

        while(upRwCtrl->u32UpdFifoPtr!=upRwCtrl->u32ProgFifoHead&&!mChkDummyWrite)
            ;

#if _EN_D3Hot_PS4
        if(!gsRdlinkInfo.uResumeFromPs4)
        {
            NLOG(cLogBuild, RDLINKFUNC_C, 2, " gPowerDownMode = 0x%04X, uResumeFromPs4 = 0x%04X", gPowerDownMode, gsRdlinkInfo.uResumeFromPs4);
            gsWproInfo.u16arWproIdxPagePtr[cWproQBootPg]=c16BitFF;
            gsWproInfo.uarWproIdxPtr[cWproQBootPg]=0xFF;
            gsWproInfo.u16arWproIdxPagePtr[cWproInvQBootPg]=c16BitFF;
            gsWproInfo.uarWproIdxPtr[cWproInvQBootPg]=0xFF;
        }

// #if _EN_D3Hot_PS4    // For D3 Qboot
        if(((gPowerDownMode!=cGSD)&&(gPowerDownMode!=cDevicePsD3))&&(!gsRdlinkInfo.uResumeFromPs4))
#else
        if((gPowerDownMode!=cGSD)&&(!gsRdlinkInfo.uResumeFromPs4))    // 20181213_SamHu_02
#endif
        {
            gsFtlDbg.u32UGSDPwrOnCnt++;
        }

        NLOG(cLogBuild, RDLINKFUNC_C, 3, " gPowerDownMode = 0x%02X, uResumeFromPs4 = 0x%02X, u32UGSDPwrOnCnt = 0x%08X",
             (gPowerDownMode<<8|gsRdlinkInfo.uResumeFromPs4), gsFtlDbg.u32UGSDPwrOnCnt>>16, gsFtlDbg.u32UGSDPwrOnCnt);

        if(gsRdlinkInfo.uResumeFromPs4)
        {
            bopCopyRam((LWORD)&gsHmbInfo, ((LWORD)garTsb0[0])+c32HMBInfoVarAddr, sizeof(gsHmbInfo), cCopyTsb2Dccm|cBopWait);
            bopCopyRam((LWORD)&g32arSrcInCacheFlag, c32Tsb0SAddr+c32SrcInCacheFlagAddr, sizeof(g32arSrcInCacheFlag), cCopyTsb2Dccm|cBopWait);
            rstH2F1KInfo();
#if _EN_D3Hot_PS4
            gsRdlinkInfo.uPowerDownMode=gPowerDownMode;
#else
            gsRdlinkInfo.uPowerDownMode=cDevicePs4;

#if _EN_IDLEGC_DELAY
            if(g32IdleGcDelayTime)
            {
                LWORD u32TimeDiffMs=getRtcCurrentMs();

                if(g32IdleGcDelayTime<=u32TimeDiffMs)    // Revise BgdGC timer, Eason_20190326_01
                {
                    u32TimeDiffMs=u32TimeDiffMs-g32IdleGcDelayTime;
                }
                else
                {
                    u32TimeDiffMs=0xFFFFFFFF-g32IdleGcDelayTime+u32TimeDiffMs;
                }

                if((u32TimeDiffMs)<cIdleGCDelayTime)
                {
                    gBgdGCWakeUp=0;
                    g32BgdGCSkipResetCnt=cBgdGcResetSctr;
                }
            }
#endif/* if _EN_IDLEGC_DELAY */
#endif    // _EN_D3Hot_PS4
        }
        else if(gPowerDownMode==cUGSD)
        {
            debugLoop(cChkPwrOnByQBootInfo1);
        }

#if _EN_D3Hot_PS4
        else if((gPowerDownMode==cGSD)||(gPowerDownMode==cDevicePsD3))
#else
        else if(gPowerDownMode==cGSD)
#endif    // _EN_D3Hot_PS4
        {
            restoH2fTabPtr();
            bopCopyRam((LWORD)&g32arSrcInCacheFlag, c32Tsb0SAddr+c32SrcInCacheFlagAddr, sizeof(g32arSrcInCacheFlag), cCopyTsb2Dccm|cBopWait);
            gsFtlDbg.u32PowerOnCnt++;
            rstH2F1KInfo();
            rstWrpoInHmb();
            gsRdlinkInfo.uPowerDownMode=cGSD;
        }
        else
        {
            // in Ps4 or Ps3 state encounter power off
            restoH2fTabPtr();
            bopCopyRam((LWORD)&g32arSrcInCacheFlag, c32Tsb0SAddr+c32SrcInCacheFlagAddr, sizeof(g32arSrcInCacheFlag), cCopyTsb2Dccm|cBopWait);
            gsFtlDbg.u32PowerOnCnt++;
            rstH2F1KInfo();
            rstWrpoInHmb();
            gsRdlinkInfo.uPowerDownMode=cGSD;
        }

        if(gPowerDownMode==cOnPcieErr)
        {
            gsHmbInfo.uHmbStsChg=cTrue;
        }

        gPowerDownMode=cUGSD;
        g16WriteBufPtr=g16BkWriteBufPtr;
        g16FlashWBufPtr=g16BkFlashWBufPtr;

        gsHmbInfo.uHmbStsChg=gsGcInfo.uHMBchg;
        gsGcInfo.uHmbEnGcCache=gsHmbInfo.uHmbEnGcCache;
        gsGcInfo.uHmbEnPtCache=gsHmbInfo.uHmbEnPtCache;
        gsGcInfo.uHMBchg=cFalse;

        getGlobEraseCnt();
        restoreSlcQCore0(cFromQBoot);
#if 0
        if((upWproInfo->uActIdx!=gsWproInfo.uActIdx)||
           (upWproInfo->u16WproFreePagePtr!=gsWproInfo.u16WproFreePagePtr)||
           (gsWproInfo.uarWproIdxPtr[cWproQBootPg]!=gsWproInfo.uActIdx))
        {
            debugLoop();
        }

        if((upWproInfo->uarWproIdxPtr[cWproQBootPg]!=gsWproInfo.uarWproIdxPtr[cWproQBootPg])||
           (upWproInfo->u16arWproIdxPagePtr[cWproQBootPg]!=gsWproInfo.u16arWproIdxPagePtr[cWproQBootPg]))
        {
            debugLoop();
        }

        for(uLoop=0; uLoop<cMaxWproBlkCnt; uLoop++)
        {
            if((upWproInfo->u16arWproBlk[uLoop]!=c16BitFF)&&!mChkPoppedBitRL(upWproInfo->u16arWproBlk[uLoop]))
            {
                debugLoop();
            }
        }

        for(uLoop=cWproCacheInfo; uLoop<cWproGcDesF2hTab00; uLoop++)
        {
            if((upWproInfo->uarWproIdxPtr[uLoop]!=gsWproInfo.uarWproIdxPtr[uLoop])||
               (upWproInfo->u16arWproIdxPagePtr[uLoop]!=gsWproInfo.u16arWproIdxPagePtr[uLoop]))
            {
                debugLoop();
            }
        }

        for(uLoop=cWproTcgInfo00; uLoop<cMaxWproPageType; uLoop++)
        {
            if((upWproInfo->uarWproIdxPtr[uLoop]!=gsWproInfo.uarWproIdxPtr[uLoop])||
               (upWproInfo->u16arWproIdxPagePtr[uLoop]!=gsWproInfo.u16arWproIdxPagePtr[uLoop]))
            {
                debugLoop();
            }
        }
#endif/* if 0 */
        // while(upWproInfo->u16arWproIdxPagePtr[cWproQBootPg]!=c16BitFF);
        // while(upWproInfo->uarWproIdxPtr[cWproQBootPg]!=0xFF);
        // while(upWproInfo->u16arWproIdxPagePtr[cWproInvQBootPg]!=c16BitFF);
        // while(upWproInfo->uarWproIdxPtr[cWproInvQBootPg]!=0xFF);

        // bopCopyRam((LWORD)&gsWproInfo, c32Tsb0SAddr+c32WproInfoVarAddr, sizeof(gsWproInfo), cCopyTsb2Stcm|cBopWait);
#if (!_EN_D3Hot_PS4)
        gsWproInfo.u16arWproIdxPagePtr[cWproQBootPg]=c16BitFF;
        gsWproInfo.uarWproIdxPtr[cWproQBootPg]=0xFF;
        gsWproInfo.u16arWproIdxPagePtr[cWproInvQBootPg]=c16BitFF;
        gsWproInfo.uarWproIdxPtr[cWproInvQBootPg]=0xFF;
#endif
        // setWproBlkPopBit();

        // calWproBlkCnt();

        gsRdlinkInfo.ubSaveIdxBlk=0;

        for(uLoop=0; uLoop<cMaxWproBlkCnt; uLoop++)
        {
            if(gsWproInfo.u16arWproBlk[uLoop]!=gsRdlinkInfo.u16arWproBlk[uLoop])
            {
                gsRdlinkInfo.ubSaveIdxBlk=1;
                break;
            }
        }

        // setGlobEraseCnt();

        // if(gsWproInfo.u16WproFreePagePtr>=gsWproInfo.u16PagePerBlock3)
        // {
        //    gsQBootInfo.ubQBootValid=0;
        // }
        // else
        // there are sevrial WPROKs, must save invalid qboot

        /* //fix ffu mode0 bug
           * {
           *  progWproPageCore0(cWproInvQBootPg, c16Tsb0SIdx);    // progWproPage(cWproInvQBootPg, c16Tsb0SIdx);
           * }
           *
           * gsWproInfo.u16arWproIdxPagePtr[cWproQBootPg]=c16BitFF;
           * gsWproInfo.uarWproIdxPtr[cWproQBootPg]=0xFF;
           * gsWproInfo.u16arWproIdxPagePtr[cWproInvQBootPg]=c16BitFF;
           * gsWproInfo.uarWproIdxPtr[cWproInvQBootPg]=0xFF;
           *
           * progCacheInfoTab();
           */
#if 0
        // quickly change WPRO block, for debug
        while(gsWproInfo.u16WproFreePagePtr<((g16PagePerBlock1_SLC-4)*(gIntlvWay*gPlaneNum*cWriteChNum)))
        {
            progWproPageCore0(cMaxWproPageType, c16Tsb0SIdx);
        }

        // quickly change Index block, for debug
        while(g16IdxBlkFreePagePtr<(g16PagePerBlock1_SLC-1))
        {
            saveIndexBlockCore0();
        }
#endif
#if (C_Log_SaveMask&C_Debug_P1)    // 20181102_Bill rdlink
        NLOG(cLogBuild, RDLINKFUNC_C, 0, "chkPwrOnByQBootInfo() End  return True");    // 20181102_Bill
#endif
        return cTrue;
    }
    else
    {
#if (C_Log_SaveMask&C_Debug_P1)    // 20181102_Bill rdlink
        NLOG(cLogBuild, RDLINKFUNC_C, 0, "chkPwrOnByQBootInfo() End  return False");    // 20181102_Bill
#endif
        return cFalse;
    }
#else/* if !_DEBUG_QBOOT */
#if (C_Log_SaveMask&C_Debug_P1)    // 20181102_Bill rdlink
    NLOG(cLogBuild, RDLINKFUNC_C, 0, "chkPwrOnByQBootInfo() End  return False");    // 20181102_Bill
#endif
    return cFalse;
#endif/* if !_DEBUG_QBOOT */
}    /* chkPwrOnByQBootInfo */

#else/* if !_ICE_DEBUG */
BYTE chkPwrOnByQBootInfo()
{
    return cFalse;
}

#endif/* if !_ICE_DEBUG */

void initQBoot()
{
    fillCcmVal((BYTE *)&gsQBootInfo, sizeof(gsQBootInfo), 0xFF);
    gsQBootInfo.ubQBootValid=0;

    gsQBootInfo.uQBVarPgCnt=(c32QBVarSctrSize/gSectorPerPlaneH)+((c32QBVarSctrSize%gSectorPerPlaneH)?1:0);
    gsQBootInfo.u16QBVarPgSectorCnt=(WORD)(gsQBootInfo.uQBVarPgCnt*gSectorPerPlaneH);
    gsQBootInfo.uSavePgCnt=gsQBootInfo.uQBVarPgCnt+(cCacheF2hSctrSize/gSectorPerPlaneH)+(cCacheInfoTabSctrSize/gSectorPerPlaneH);
#if _EN_RAID_GSD
    gsQBootInfo.uSavePgCnt+=cRaidTotalEng;
#endif
}    /* initQBoot */

void initFwDlInfo()
{
    fillCcmVal((BYTE *)&gsFwDlInfo, sizeof(gsFwDlInfo), 0x00);
    gsFwDlInfo.uSysRsvFwDlImageBlk=0xFF;
}

#if 0
void testEasySetCacheRead(WORD u16FlashPagePrtr)
{
    g16FPage=u16FlashPagePrtr;
    rmSelData;
    setAutoFBlock(gIntlvAddr, gPlaneAddr);
    setAutoAleReg(gPageSelCmd);
    rmCeOn(mSetIntlvCe(gIntlvAddr));

    chkRlibMoCmd();
    rmCle(gPageReadCmd1);
    rmSetPlaneBit(gPlaneAddr);
    rmAle5;
    rmCle(0x31);    // cache read
}

void testEasyCacheDataOut(BYTE uSctr)
{
    rmCeOn(mSetIntlvCe(gIntlvAddr));
    pollStatus(cBit6);
    mSetFRwParam(0, uSctr, (c16Bit2|c16Bit4|c16Bit10|c16Bit15), cReadData);
    flashReadPage();
}

void testEasySetCacheHalfRead(WORD u16FlashPagePrtr)
{
    g16FPage=u16FlashPagePrtr;
    rmSelData;
    setAutoFBlock(gIntlvAddr, gPlaneAddr);
    setAutoAleReg(gPageSelCmd);
    rmCeOn(mSetIntlvCe(gIntlvAddr));

    chkRlibMoCmd();
    rmCle(gPageReadCmd1);
    rmSetPlaneBit(gPlaneAddr);
    rmAle5;
    rmCle(0x21);    // cache read
}

void testFlashCmd_Q_Q()
{
    ADDRINFO usTmpAddrInfo;

    // normal SLC read

    tranRsvBlkAddr(garSysBlock[cSysBlock1stInfo], &usTmpAddrInfo);
    usTmpAddrInfo.u16FPage=0;
    usTmpAddrInfo.uSectorH=0;
    setFLAddrActCh(usTmpAddrInfo.uCh, &usTmpAddrInfo);
    // tranCeNum(&usTmpAddrInfo);

    waitCmdFifoDpt(gActiveCh, &usTmpAddrInfo);
    mSetFRwParam(0, 8, (c16Bit4|c16Bit10|c16Bit13), cReadData);
    waitChCeBz(gActiveCh, gIntlvAddr, 0);
    flashReadPage();

    // normal SLC cache read
#if 0
    usTmpAddrInfo.u16FPage=0;
    waitCmdFifoDpt(gActiveCh, &usTmpAddrInfo);
    mSetFRwParam(0, 16, (c16Bit10|c16Bit12|c16Bit13|c16Bit15), cReadData);
    waitChCeBz(gActiveCh, gIntlvAddr, 0);
    flashReadPage();

    testEasySetCacheRead(1);

    testEasyCacheDataOut(16);

    testEasySetCacheRead(2);

    testEasyCacheDataOut(16);

    rmCeOn(mSetIntlvCe(gIntlvAddr));
    chkRlibMoCmd();
    rmCle(0x3F);

    testEasyCacheDataOut(16);
#endif/* if 0 */

    // end of cache

    waitCmdFifoDpt(gActiveCh, &usTmpAddrInfo);
    mSetFRwParam(0, 8, (c16Bit4|c16Bit10|c16Bit13), cReadData);
    flashReadPage();

    // half SLC read

    g16FPage=0;
    rmSelData;
    setAutoFBlock(gIntlvAddr, gPlaneAddr);
    setAutoAleReg(gPageSelCmd);
    rmCeOn(mSetIntlvCe(gIntlvAddr));

    chkRlibMoCmd();
    rmCle(gPageReadCmd1);
    rmSetPlaneBit(gPlaneAddr);
    rmAle5;
    rmCle(0x20);    // half read

    pollStatus(cPollMaskNor);
    mSetFRwParam(0, 8, (c16Bit2|c16Bit4|c16Bit10|c16Bit13), cReadData);
    flashReadPage();

    // half SLC cache Read
#if 0
    g16FPage=0;
    rmSelData;
    setAutoFBlock(gIntlvAddr, gPlaneAddr);
    setAutoAleReg(gPageSelCmd);
    rmCeOn(mSetIntlvCe(gIntlvAddr));

    chkRlibMoCmd();
    rmCle(gPageReadCmd1);
    rmSetPlaneBit(gPlaneAddr);
    rmAle5;
    rmCle(0x20);    // half read
    pollStatus(cPollMaskNor);
    testEasySetCacheHalfRead(1);
    testEasyCacheDataOut(8);
    testEasySetCacheHalfRead(2);
    testEasyCacheDataOut(8);
    testEasySetCacheHalfRead(3);
    testEasyCacheDataOut(8);
    rmCeOn(mSetIntlvCe(gIntlvAddr));
    rmCle(0x3F);

    testEasyCacheDataOut(8);
#endif/* if 0 */
    // fast read
    setFLActCh(gActiveCh);

    rmCeOn(mSetIntlvCe(gIntlvAddr));

    rmCle(0xEF);
    rmAle(0xF5);
    writeFourData(0x02, 0, 0, 0);
    // writeFourData(0x02, 0x2, 0x2, 0x2);

    while(rmChkCmdFifoBz)
        ;

    if(1)
    {
        rmCle(0x70);
        rmStsFailMask(0x00);
        rmRdStatus(0x60);

        while(rmChkCmdFifoBz)
            ;
    }

    // normal SLC read

    rmCeOn(mSetIntlvCe(gIntlvAddr));

    tranRsvBlkAddr(garSysBlock[cSysBlock1stInfo], &usTmpAddrInfo);
    usTmpAddrInfo.u16FPage=0;
    usTmpAddrInfo.uSectorH=0;
    setFLAddrActCh(usTmpAddrInfo.uCh, &usTmpAddrInfo);
    // tranCeNum(&usTmpAddrInfo);

    waitCmdFifoDpt(gActiveCh, &usTmpAddrInfo);
    mSetFRwParam(0, 16, (c16Bit10|c16Bit12|c16Bit13|c16Bit15), cReadData);
    flashReadPage();

    testEasyCacheDataOut(16);

    // half SLC read

    g16FPage=2;
    rmSelData;
    setAutoFBlock(gIntlvAddr, gPlaneAddr);
    setAutoAleReg(gPageSelCmd);
    rmCeOn(mSetIntlvCe(gIntlvAddr));

    chkRlibMoCmd();
    rmCle(gPageReadCmd1);
    rmSetPlaneBit(gPlaneAddr);
    rmAle5;
    rmCle(0x20);    // half read

    mSetFRwParam(0, 8, (c16Bit2|c16Bit4|c16Bit10|c16Bit13), cReadData);
    pollStatus(cPollMaskNor);
    flashReadPage();
}    /* testFlashCmd_Q_Q */

#endif/* if 0 */
void rdlinkStep1()
{
    // WORD u16Fblock;
    BYTE uIdx;

#if 0    // _INITDRAM
    outCS("CS. rdlinkStep1()");
#endif
    gsDiffTyp2AddrInfo.u16FBlock=0xFFFF;
    gsRdlinkInfo.ubSaveIdxBlk=0;
    // gsRdlinkInfo.ubPwrWrIdxBlk=0;
    // gsRdlinkInfo.ubPwrWrLogInfo=0;

    // clear RdLink variable
    bopClrRam((LWORD)c32RdLinkVarStartAddr, c32RdLinkVarRamSize, 0x00000000, cClrTsb|cBopWait);
    g16FoundCachebCnt=0;

    for(uIdx=0; uIdx<40; uIdx++)
    {
        gsRdlinkInfo.u32RdlinkTimeStamp[uIdx]=c32BitFF;
    }

    saveRdTimeStamp(0);
#if _DEBUG_StopUntilTotalWCnt
    g64DebugHostStopWr=0xFFFF_FFFF_FFFF_FFFF;
#endif
    // g16DgFifoFullCnt=0;
    g16CopyFblockCnt=0;

#if _PRJ_BOOT
    rebuSysBlk();
#endif

#if 1    // _PRJ_BOOT
    if(!gsRdlinkInfo.uResumeFromPs4)
    {
        initWproVar();
    }

    initQBoot();

    if(gsRdlinkInfo.uResumeFromPs4)
    {
        gsQBootInfo.ubQBootValid=1;
    }

    initFwDlInfo();

    findIndexBlock(gsRdlinkInfo.uResumeFromPs4);
    findLogBlock(gsRdlinkInfo.uResumeFromPs4);
    // findCacheInfoBlock();
    loadDiffTabCore0();

    getDiffType2Offset();

#if (!_ByPassRdLink)
    if(gsRdlinkInfo.ubWproBlkFound&&(!gsRdlinkInfo.uResumeFromPs4))
    {
        gsRdlinkInfo.ubDoNotPushSpare=1;
        rebuWproInfo();
        gsRdlinkInfo.ubDoNotPushSpare=0;
    }
#else
    gsRdlinkInfo.ubWproBlkFound=0;
#endif

#if _EN_VPC_SWAP
    g32VPCSwapFlag=cVPCntInBoot;
    g32arCacheBlkVpCnt=(volatile LWORD *)cCacheBlkVpCntBootStrAddr;
#endif

    // setSprOnesCntCondition(cEnSprOnesCntSetting);
    saveRdTimeStamp(1);

    if(gsWproInfo.u16arWproIdxPagePtr[cWproCacheInfo]!=0xFFFF)
    {
        gsRdlinkInfo.u16CacheInfoWproBlock=gsWproInfo.u16arWproBlk[gsWproInfo.uarWproIdxPtr[cWproCacheInfo]];
        gsRdlinkInfo.u16CacheInfoWproPagePtr=gsWproInfo.u16arWproIdxPagePtr[cWproCacheInfo];
        gsRdlinkInfo.uCacheInfoWproIdx=gsWproInfo.uarWproIdxPtr[cWproCacheInfo];
        gsRdlinkInfo.ubCacheInfoValid=1;

        // restoCacheInfo();
        readWproPageCore0(cWproCacheInfo, c16Tsb0SIdx, cBit7);    // cache info + global erase count+read cnt   , rstH2F1KInfo() at rdlinkStep2
#if _EN_VPC_SWAP
        bopCopyRam((LWORD)g32arCacheBlkVpCnt,
                   c32Tsb0SAddr+c32ProgCacheInfo_CacheBlkVpCntStAddr,
                   c32ProgCacheInfo_CacheBlkVpCntSize,
                   cCopyTsb2Tsb|cBopWait);
        bopCopyRam(c32Tsb2SAddr, c32Tsb0SAddr+c32ProgCacheInfo_CacheInfoTabStAddr, c32CacheInfoTabRamSize, cCopyTsb2Tsb|cBopWait);
        bopCopyRam((LWORD)&g16arTempGlobEraseCnt,
                   c32Tsb0SAddr+c32ProgCacheInfo_EraseCntStAddr,
                   sizeof(g16arTempGlobEraseCnt),
                   cCopyTsb2Tsb|cBopWait);
#else
        bopCopyRam(c32Tsb2SAddr, c32Tsb0SAddr, c32CacheInfoTabRamSize, cCopyTsb2Tsb|cBopWait);
        bopCopyRam((LWORD)&g16arTempGlobEraseCnt, c32Tsb0SAddr+c32CacheInfoTabRamSize, sizeof(g16arTempGlobEraseCnt), cCopyTsb2Tsb|cBopWait);
#endif/* if _EN_VPC_SWAP */
        bopCopyRam((LWORD)&g32arPopDeniedFlag, (LWORD)&g32arPopBit, (c16MaxBlockNum/8), cCopyTsb2Tsb|cBopWait);
        restoreSlcQCore0(cFromCacheInfo);
#if (_GREYBOX)
        g16arTempGlobEraseCnt[g16FirstFBlock]=c16BitFF;
        mSetPoppedBitRL(g16FirstFBlock);
        mClrMlcMoBit(g16FirstFBlock);
#endif

        setGlobEraseCnt();

        gsRdlinkInfo.u16ActH2fTabFblk=g16BkActH2fTabFblk;
        gsRdlinkInfo.u16H2fTabFreePagePtr=g16BkH2fTabFreePagePtr;
        restoH2fTabPtr();

        NLOG(cLogBuild,
             RDLINKFUNC_C,
             4,
             "cWproCacheInfo exist! u16ActH2fTabFblk=0x%04x, u16H2fTabFreePagePtr=0x%04x, g32BkH2fTabBlkSerial=0x%08x",
             (WORD)gsRdlinkInfo.u16ActH2fTabFblk,
             (WORD)gsRdlinkInfo.u16H2fTabFreePagePtr,
             g32BkH2fTabBlkSerial>>16,
             g32BkH2fTabBlkSerial);

        // move to rdlinkfunc
#if 0
        if(gBkFidBlock!=0xFF)
        {
            // check Fid block and swap isp block and Reset CPU
            gsFwDlInfo.uSysRsvFwDlImageBlk=gBkFidBlock;

            if(mChkCacheInfoSpf(cFwCommit))    // judge if DM block and swap flow is ok
            {
                judgeSwapIspCore0();

                if(mChkJudgeSwapIsp)
                {
                    activateIspCore0();

                    if(!mChkActivateFail)
                    {
                        waitAllChCeBzCore0();    // wait all busy instead of reset by Rom code
                        // garSmiVndrArg[0]=0;    // gSmiVndrArg0=0;
                        resetCpuFwCommit(cResetCpuAll);
                    }
                }
            }

            if((!(mChkCacheInfoSpf(cFwCommit)))||(!mChkJudgeSwapIsp)||mChkActivateFail)
            {
                // pushSysSprBlk(gsFwDlInfo.uSysRsvFwDlImageBlk);
                gsFwDlInfo.uSysRsvFwDlImageBlk=0xFF;
                gBkFidBlock=0xFF;
                gsRdlinkInfo.ubSaveCacheInfo=1;
            }

            if(!mChkCacheInfoSpf(cFwCommit))
            {
                chkIspBlockCore0();
            }
            else
            {
                mClrCacheInfoSpf(cFwCommit);
            }
        }
#endif/* if 0 */
// #endif
    }

#if (!_WO_ISPB)
    /* temp remove
       *  refreshISPBlock();
       */
#endif

/*
   *  // rebuild bad info should after QBoot info setup
   *  if(gsWproInfo.u16arWproIdxPagePtr[cWproBadInfo]!=0xFFFF)
   *  {
   *      gsRdlinkInfo.ubBadInfoValid=1;
   *      chkBadInfo();
   *  }
   *  else
   *  {
   *      gsBadInfo.u16TotalNewBadCnt=0;
   *      gsBadInfo.u16NewBadInBufPtr=1;
   *      gsBadInfo.u16TotalTLCEccFailCnt=0;
   *      gsBadInfo.u16ProgFailFblkCnt=0;
   *  }
   */

    if(mChkMPInfoInFL)
    {
        chkMPInfo();
    }
    else
    {
        debugLoop(cRdlinkStep1);
        gsMPInfo.u32MPInfoSerial=0xFFFFFFFF;
        gsMPInfo.u16MPInfoPageFreePtr=0;
        mSetCacheInfoFlag(cMPInfoBlockFull);
    }
#else/* if _PRJ_BOOT */
    mClrIndexbInFL;
    mClrBadInfoInFL;
    gsBadInfo.u16TotalNewBadCnt=0;
    gsBadInfo.u16NewBadInBufPtr=1;
    gsBadInfo.u16TotalTLCEccFailCnt=0;
    gsBadInfo.u16ProgFailFblkCnt=0;
    // gsBadInfo.uBadInfoBlkSerial=0xFF;
    gsBadInfo.u32BadInfoBlkSerial=0xFF;
    gsBadInfo.u16BadInfoPageFreePtr=0;
    initWproVar();
    initQBoot();
    initFwDlInfo();
#endif/* if _PRJ_BOOT */
}    /* rdlinkStep1 */

void rdlinkStep2()
{
// #if !_Dis_F2hPBit
    WORD u16Idx;

// #endif

    initFtlVar();

    if(gsRdlinkInfo.ubCacheInfoValid)
    {
        gsRdlinkInfo.u16BkActiveCacheBlock=g16BkActiveCacheBlock;
        gsRdlinkInfo.u16BkActiveGcDesBlock=g16BkActiveGcDesBlock;
        gsRdlinkInfo.u16BkFluCacheBlock=g16BkFluCacheBlock;
        gsRdlinkInfo.u16BkPrePopCacheBlock=g16BkPrePopCacheBlock;
        gsRdlinkInfo.u16BkGcDesSlcBlock=g16BkGcDesSlcBlock;
        gsRdlinkInfo.u16BkGcDesTlcBlock=g16BkGcDesTlcBlock;
        gsRdlinkInfo.uPowerDownMode=gPowerDownMode;

        gsCacheInfo.u32CacheBlkSerial=g32BkCacheBlkSerial;
        gsGcInfo.u32TotalSlcVpc=g32BkTotalSlcVpc;
        gsGcInfo.u32TotalTlcVpc=g32BkTotalTlcVpc;

        gsCacheInfo.u32TotalEraseCnt=g32TotalEraseCnt;
        gsCacheInfo.u32DynamicTotalEraseCnt=g32DynamicTotalEraseCnt;
        gsCacheInfo.u32SLCTotalEraseCnt=g32SLCTotalEraseCnt;
        // gsFtlDbg.u16TLCGcWLCnt=g16TLCGcWLCnt;
        // gsFtlDbg.u16SLCReclaimCnt=g16SLCReclaimCnt;
#if _EN_SLCOpenBlkReadScrub
        // gsFtlDbg.u16SLCFlushCnt=g16SLCFlushCnt;
        // gsFtlDbg.u16H2FScrubCnt=g16H2FReadScrubCnt;
#endif
        // gsFtlDbg.u16ReclaimCnt=g16ReclaimCnt;

        gsGcInfo.u32GcMaxS2TProcTime=g32MaxS2TGCtime;
        gsGcInfo.u32GcMaxT2TProcTime=g32MaxT2TGCtime;

        if(!gsQBootInfo.ubQBootValid)
        {
            gsGcInfo.u32GcLastS2TProcTime=g32MaxS2TGCtime;
            gsGcInfo.u32GcLastT2TProcTime=g32MaxT2TGCtime;
        }
    }
    else
    {
        for(u16Idx=0; u16Idx<(0x400); u16Idx++)
        {
            r32SkipRam[u16Idx]=0x00000000;
        }

        initVarInCacheInfoTab();
#if _EN_VPC_SWAP
        initSlcQCore0();    // 20190419_Louis
#endif
    }

    // for pop spare clear variable
    gsGcInfo.uGcSkipPopSrcBlockCnt=0;

    gsFtlDbg.u32PowerOnCnt++;

    /*
       * #if !_Dis_F2hPBit
       * for(u16Idx=0; u16Idx<cMaxF2hPBitTabNum; u16Idx++)
       * {
       *  gsCacheInfo.uarCacheF2hPBitTabIdx[u16Idx]=u16Idx;
       * }
       * #endif
       */
    setF2hPadPara();

    // rstH2F1KInfo(); //set in initFtlVar
    // gsCacheInfo.u16ActiveH2fTab= c16BitFF; //set in initFtlVar
    // gsCacheInfo.ubPrep=1; //set in initFtlVar

    // gsRwCtrl.u16ProgPageOfst=0;
    // bopClrRam((LWORD)g32arGcSrcBlkBitMap, (LWORD)gSetMaxPassWord-(LWORD)g32arGcSrcBlkBitMap, 0x00000000, cClrTsb|cBopWait);

    // bopClrRam((LWORD)garCacheF2hTab, c32CacheF2hRamSize, c32BitFF, cClrTsb|cBopWait); // init at initSram
    // mSetCacheInfoFlag(cCacheBlockFull);

    // for(u16Idx=0; u16Idx<(0x400); u16Idx++)
    // {
    //    r32SkipRam[u16Idx]=0x00000000;
    // }

#if (!_BypassEraseFlag)
    for(u16Idx=0; u16Idx<(c16MaxBlockNum/32); u16Idx++)
    {
        g32arEraseFlag[u16Idx]=0;
    }
#endif
/*
   #if _FIX_SLC_Boundary
   *  for(u16Idx=0; u16Idx<c16MaxBlockNum; u16Idx++)
   *  {
   *      if(u16Idx<gMinStaticSlcCnt)
   *      {
   *          mSetMlcSkipBit(u16Idx);
   *          mSetMlcSkipRam(u16Idx);
   *          mClrMlcMoBit(u16Idx);
   *      }
   *      else
   *      {
   *          mSetSlcSkipBit(u16Idx);
   *          mSetSlcSkipRam(u16Idx);
   *          mSetMlcMoBit(u16Idx);
   *      }
   *  }
   #endif
   */
/*
   *  if(gsRdlinkInfo.ubBadInfoBlkFull)
   *  {
   *      mSetBadInfoFlag(cBadInfoBlkFull);
   *  }
   */
    // gsRwCtrl.uCacheStartSctr=0;  // initial in initFtlVar()
    // gsRwCtrl.uCacheEndSctr=cSctrPer4k;
    // gsRwCtrl.u32LastLbaW=0xFFFFFFFF;
    // gsRwCtrl.u32LastTrimLba=c32BitFF;

    // getMaxProgPageCnt();
    setGcInfoThr();
    // setCmdFifoDpt();

    /*
       *
       *  for(uTemp=0; uTemp<cMaxSeqLinkH2fTab; uTemp++)
       *  {
       *      gsCacheInfo.usSeqLinkIdx[uTemp].uPre=(uTemp-1)&(cMaxSeqLinkH2fTab-1);
       *      gsCacheInfo.usSeqLinkIdx[uTemp].uNxt=(uTemp+1)&(cMaxSeqLinkH2fTab-1);
       *  }
       *
       *  gsCacheInfo.uSeqLinkHead=cMaxSeqLinkH2fTab-1;
       *
       *  gsRwCtrl.uarPost4kPrd[0].uPre=cPost4kDept-1;
       *  gsRwCtrl.uarPost4kPrd[0].uNxt=1;
       *
       *  for(uTemp=1; uTemp<cPost4kDept; uTemp++)
       *  {
       *      gsRwCtrl.uarPost4kPrd[uTemp].uPre=(uTemp-1)%cPost4kDept;
       *      gsRwCtrl.uarPost4kPrd[uTemp].uNxt=(uTemp+1)%cPost4kDept;
       *  }
       *
       *  gsRwCtrl.uPost4kPrdHead=cPost4kDept-1;
       *
       *  if(gsRdlinkInfo.ubCacheInfoValid)
       *  {
       *      // (Finn) It seems nowhere using this variabl.
       *      gsRdlinkInfo.u16MaxGrpDist=0x0008;
       *  }
       *  else
       *  {
       *      gsRdlinkInfo.u16MaxGrpDist=0x8000;
       *  }
       */
#if 0    // !_ICE_DEBUG
    g16RdlinkLogUpdPtr=(sizeof(gsSmartTblExt.uDevicePowerCycleCnt)+sizeof(gsRdlinkInfo))/2;    // reserve space
    bopClrRam((LWORD)g16arRdlinkLog, c16RdlinkLogSize, 0x0000_0000, cClrTsb|cBopWait);
    g16arRdlinkLog[g16RdlinkLogUpdPtr]=gsCacheInfo.u16CacheInfoBlk;    // log the finally used CacheInfoBlk
    g16RdlinkLogUpdPtr++;
#endif
    // gsCacheInfo.ubSLCCacheEnable=1;
    // gsRwCtrl.u32BkOneShotChPtr=cInvaildCh;
}    /* rdlinkStep2 */

void rdlinkStep3()
{
    WORD u16FBlock;
    WORD u16TotalSpareCnt=0;
    WORD u16SLCSpareCnt=0;
    WORD u16DynamicSpareCnt=0;

    saveRdTimeStamp(10);
    // gsCacheInfo.u16MotherBlockCnt=0;

    if(g16PushSpareCnt)
    {
        chkPushSpareQCore0(1);
        gsRdlinkInfo.ubSaveCacheInfo=1;
    }

    getGlobEraseCnt();

    // for(u16Fblock=0; u16Fblock<(c16MaxBlockNum/32); u16Fblock++)
    // {
    //    r32SkipRam[u16Fblock]=0xFFFFFFFF;
    // }

    gsCacheInfo.u16MlcMoSkipCnt=0;
    gsCacheInfo.u16SlcMoSkipCnt=0;
    gsCacheInfo.u16FullCacheBlockCnt=0;
    gsCacheInfo.u16TLCFullCacheBlockCnt=0;

    for(u16FBlock=g16FirstFBlock; u16FBlock<g16TotalFBlock; u16FBlock++)
    {
        if(g16arTempGlobEraseCnt[u16FBlock]!=c16BitFF)
        {
            if(mChkMlcMoBit(u16FBlock))
            {
                gsCacheInfo.u16SlcMoSkipCnt++;
            }

#if !_EN_Dynamic_Fix_Boundary
            if(!mChkMlcMoBit(u16FBlock))
            {
                gsCacheInfo.u16MlcMoSkipCnt++;
            }
#endif

            if(!mChkPoppedBitRL(u16FBlock))
            {
#if _EN_VPC_SWAP
                if(mChkVPCntValid(u16FBlock))
#else
                if(mGetCacheBlkVpCnt(u16FBlock))
#endif
                {
#if _EN_KEEP_RW_ON_ERROR
                    setEraseBadBlockCore0(u16FBlock, 0x0000|c16Bit14);
                    relinkKeepRwonError(cRdlinkStep3_1, u16FBlock, (WORD)(mGetCacheBlkVpCnt(u16FBlock)&0xFFFF),
                                        (WORD)(mGetCacheBlkVpCnt(u16FBlock)>>16));
                    continue;
#else
                    debugPwrCyl(c16Bit1);
                    relinkSaveDummyQBAnalysis(u16FBlock,
                                              (WORD)(g32arCacheBlkVpCnt[u16FBlock]>>16),
                                              (WORD)(g32arCacheBlkVpCnt[u16FBlock]&0xFFFF),
                                              0);
                    relinkSaveQBDummy(cRdlinkStep3_1);
#endif
                }
                else
                {
                    if(!mChkSkipGcSrch(u16FBlock))    // while(!mChkSkipGcSrch(u16FBlock));
                    {
#if _EN_KEEP_RW_ON_ERROR    // Chief_20190305
                        if(!mChkSkipGcSrch(u16FBlock))
                        {
                            mSetSkipGcSrch(u16FBlock);
                        }

                        if(mChkGcSrcBlkBmap(u16FBlock))
                        {
                            mClrGcSrcBlkBmap(u16FBlock);
                        }

                        relinkKeepRwonError(cChkSkipGcSrchFail1, u16FBlock, mGetCacheBlkVpCnt(u16FBlock),
                                            mChkSkipGcSrch(u16FBlock));
#else
                        relinkSaveDummyQBAnalysis(u16FBlock, (WORD)(g32arCacheBlkVpCnt[u16FBlock]>>16),
                                                  (WORD)(g32arCacheBlkVpCnt[u16FBlock]&0xFFFF), 0);
                        relinkSaveQBDummy(cChkSkipGcSrchFail1);
#endif
                    }
                }

                if(u16FBlock<g16StaticBound)
                {
                    u16SLCSpareCnt++;
                }
                else
                {
                    u16DynamicSpareCnt++;
                }

                u16TotalSpareCnt++;
            }
            else
            {
#if _EN_VPC_SWAP
                if(mChkVPCntValid(u16FBlock))
#else
                if(mGetCacheBlkVpCnt(u16FBlock))
#endif
                {
#if _EN_RDLINK_PF
                    if((u16FBlock==gsCacheInfo.u16ActiveCacheBlock)||(u16FBlock==gsCacheInfo.u16FluCacheBlock))
#else
                    if(u16FBlock==gsCacheInfo.u16ActiveCacheBlock)
#endif
                    {
                        if(!mChkSkipGcSrch(u16FBlock))    // while(!mChkSkipGcSrch(u16FBlock));
                        {
#if _EN_KEEP_RW_ON_ERROR    // Chief_20190305
                            if(!mChkSkipGcSrch(u16FBlock))
                            {
                                mSetSkipGcSrch(u16FBlock);
                            }

                            if(mChkGcSrcBlkBmap(u16FBlock))
                            {
                                mClrGcSrcBlkBmap(u16FBlock);
                            }

                            relinkKeepRwonError(cChkSkipGcSrchFail2, u16FBlock, mGetCacheBlkVpCnt(u16FBlock),
                                                mChkSkipGcSrch(u16FBlock));
#else
                            relinkSaveDummyQBAnalysis(u16FBlock, (WORD)(g32arCacheBlkVpCnt[u16FBlock]>>16),
                                                      (WORD)(g32arCacheBlkVpCnt[u16FBlock]&0xFFFF), 0);
                            relinkSaveQBDummy(cChkSkipGcSrchFail2);
#endif
                        }
                    }
                    else
                    {
                        mClrSkipGcSrch(u16FBlock);
                    }
                }
                else
                {
                    if(!mChkSkipGcSrch(u16FBlock))    // while(!mChkSkipGcSrch(u16FBlock));
                    {
#if _EN_KEEP_RW_ON_ERROR    // Chief_20190305
                        setZeroVpcBlock(u16FBlock);
                        relinkKeepRwonError(cChkSkipGcSrchFail3, u16FBlock, mGetCacheBlkVpCnt(u16FBlock),
                                            mChkSkipGcSrch(u16FBlock));
#else
                        relinkSaveDummyQBAnalysis(u16FBlock, (WORD)(g32arCacheBlkVpCnt[u16FBlock]>>16),
                                                  (WORD)(g32arCacheBlkVpCnt[u16FBlock]&0xFFFF), 0);
                        relinkSaveQBDummy(cChkSkipGcSrchFail3);
#endif
                    }
                }
            }
        }
    }

    addRdlinkLog(c16FuncRdlinkStep3);
    addRdlinkLog(u16SLCSpareCnt);
    addRdlinkLog(u16DynamicSpareCnt);
    addRdlinkLog(u16TotalSpareCnt);

    if(gsRdlinkInfo.ubAbnorScenario)
    {
        // debugPwrCyl(c16Bit2);
        relinkSaveQBDummy(cRdlinkStep3_2);
    }
    else if(gsCacheInfo.u16SLCSpareCnt!=u16SLCSpareCnt)
    {
#if _EN_KEEP_RW_ON_ERROR
        relinkKeepRwonError(cRdlinkStep3_3, gsCacheInfo.u16SLCSpareCnt, u16SLCSpareCnt, 0);

        if(gsCacheInfo.u16SLCSpareCnt>u16SLCSpareCnt)
        {
            gsCacheInfo.u16SLCSpareCnt=u16SLCSpareCnt;
        }
#else
        debugPwrCyl(c16Bit3);
        relinkSaveDummyQBAnalysis(gsCacheInfo.u16SLCSpareCnt, u16SLCSpareCnt, 0, 0);
        relinkSaveQBDummy(cRdlinkStep3_3);
#endif
    }
    else if(gsCacheInfo.u16DynamicSpareCnt!=u16DynamicSpareCnt)
    {
#if _EN_KEEP_RW_ON_ERROR
        relinkKeepRwonError(cRdlinkStep3_4, gsCacheInfo.u16DynamicSpareCnt, u16DynamicSpareCnt, 0);

        if(gsCacheInfo.u16DynamicSpareCnt>u16DynamicSpareCnt)
        {
            gsCacheInfo.u16DynamicSpareCnt=u16DynamicSpareCnt;
        }
#else
        debugPwrCyl(c16Bit5);
        relinkSaveDummyQBAnalysis(gsCacheInfo.u16DynamicSpareCnt, u16DynamicSpareCnt, 0, 0);
        relinkSaveQBDummy(cRdlinkStep3_4);
#endif
    }

    g16BkActiveGcDesBlock=c16FBlockInitValue;
    g16BkGcDesSlcBlock=c16FBlockInitValue;
    g16BkGcDesTlcBlock=c16FBlockInitValue;
}    /* rdlinkStep3 */

BYTE chkDiffType2(WORD u16FBlock)
{
    BYTE uDiffType2Ptr;

    for(uDiffType2Ptr=0; uDiffType2Ptr<gDiffType2Num; uDiffType2Ptr++)
    {
        if(u16FBlock==g16arTempDiffType2Offset[uDiffType2Ptr])
        {
            return uDiffType2Ptr;
        }
    }

    return 0xFF;
}

void setWproBlkPopBit()
{
    BYTE uIdx;
    BYTE uDiffType2Ptr;
    WORD u16FBlock;

    gsCacheInfo.u32arDiffType2PopBit[0]=0;
    gsCacheInfo.u32arDiffType2PopBit[1]=0;
    gsCacheInfo.uDiffType2SprBlkCnt=gDiffType2Num;

    if(!gsRdlinkInfo.ubWproBlkFound)
    {
        return;
    }

    for(uIdx=0; uIdx<cMaxWproBlkCnt; uIdx++)
    {
        u16FBlock=gsWproInfo.u16arWproBlk[uIdx];

        if(u16FBlock!=c16BitFF)
        {
            mSetPoppedBitRL(u16FBlock);
            uDiffType2Ptr=chkDiffType2(u16FBlock);

            if(uDiffType2Ptr!=0xFF)
            {
                mSetBitMask(gsCacheInfo.u32arDiffType2PopBit[uIdx>>5], uDiffType2Ptr&0x1F);
                gsCacheInfo.uDiffType2SprBlkCnt--;
            }

            mSetGlobEraseCntRL(u16FBlock, g16arWproBlkEraseCnt[uIdx]);
            setGlobEraseCnt1Blk(u16FBlock, g16arTempGlobEraseCnt[u16FBlock], 1);
        }
    }
}    /* setWproBlkPopBit */

void calWproBlkCnt()
{
    BYTE uIdx;
    BYTE uDiffType2Ptr;

    gsWproInfo.uCnt=0;

    if(!gsRdlinkInfo.ubWproBlkFound)
    {
        return;
    }

    /*
       *  set wpro count, should after restore cache info table then push spare block
       */

    for(uIdx=0; uIdx<cMaxWproBlkCnt; uIdx++)
    {
        if((uIdx!=gsWproInfo.uActIdx)&&(gsWproInfo.u16arWproBlk[uIdx]!=c16BitFF)&&(!gsWproInfo.u16arVpCnt[uIdx]))
        {
            uDiffType2Ptr=chkDiffType2(gsWproInfo.u16arWproBlk[uIdx]);

            if(uDiffType2Ptr!=0xFF)
            {
                mClrBitMask(gsCacheInfo.u32arDiffType2PopBit[uDiffType2Ptr>>5], uDiffType2Ptr&0x1F);
                gsCacheInfo.uDiffType2SprBlkCnt++;
            }
            else
            {
                pushSpareBlockCore0(gsWproInfo.u16arWproBlk[uIdx], cPushNotErase);
            }

            gsWproInfo.u16arWproBlk[uIdx]=c16BitFF;
        }

        if(gsWproInfo.u16arWproBlk[uIdx]!=c16BitFF)
        {
            gsWproInfo.uCnt++;
        }
    }

    while(gsTskFifoCtrl.u32HeadPtr!=gsTskFifoCtrl.u32TailPtr)
        ;// 20190508_Bill

    if(!gsWproInfo.uCnt)    //    while(!gsWproInfo.uCnt);
    {
#if _EN_KEEP_RW_ON_ERROR    // Chief_20190305
        mSetCacheInfoSpf(crelinkWhileFormat);
        relinkKeepRwonError(cCalWproBlkCntFail1, 0x00, 0x00, 0x00);
#else
        relinkSaveQBDummy(cCalWproBlkCntFail1);
#endif
    }

    // gsRdlinkInfo.ubSaveIdxBlk=0;

    for(uIdx=0; uIdx<cMaxWproBlkCnt; uIdx++)
    {
        if(gsWproInfo.u16arWproBlk[uIdx]!=gsRdlinkInfo.u16arWproBlk[uIdx])
        {
            gsRdlinkInfo.ubSaveIdxBlk=1;
            break;
        }
    }
}    /* calWproBlkCnt */

BYTE chkReBuedWproBlock(WORD u16FBlock)
{
    BYTE uLoop;
    BYTE uHit=0;

    for(uLoop=0; uLoop<gsRdlinkInfo.uRebuCachebCnt; uLoop++)
    {
        if(u16FBlock==garFoundWproQ[garFoundWproIdx[uLoop]].u16FBlock)
        {
            uHit=1;
            break;
        }
    }

    return uHit;
}

void setDiffType2BlkEraseCnt()
{
    BYTE uDiffType2Ptr, uPageStatus;
    WORD u16FBlock;
    BLKSPRINFO usBlkSprInfo;

    ctrlOnesCntStop(0);

    for(uDiffType2Ptr=0; uDiffType2Ptr<gDiffType2Num; uDiffType2Ptr++)
    {
        u16FBlock=g16arTempDiffType2Offset[uDiffType2Ptr];

        if(!chkReBuedWproBlock(u16FBlock))
        {
            // getDiffType2AddrInfo(u16FBlock);
            uPageStatus=getWproPageInfo(u16FBlock, 0, c16Tsb0SIdx, &usBlkSprInfo, 1, 0);

            if(uPageStatus)
            {
                if((mChkBitMask(uPageStatus, 0)||mChkBitMask(uPageStatus, 1)))
                {
                    mSetGlobEraseCntRL(u16FBlock, mGetMetaEraseCnt(usBlkSprInfo));
                    setGlobEraseCnt1Blk(u16FBlock, g16arTempGlobEraseCnt[u16FBlock], (mChkPoppedBitRL(u16FBlock))?1:0);
                }
            }
        }
    }

    ctrlOnesCntStop(3);
}    /* setDiffType2BlkEraseCnt */







