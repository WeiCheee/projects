







void chkPfFblock(BYTE uCh)
{
#if _EN_PROGFAILLOG
    LWORD u32TmpRRCnt, u32PfProcTime=getRtcCurrent32k();
    // BYTE uOriCh, uIntlv;

#if _EN_WRHWPRDCORE1
    if(gsPrdInfo.u32TrigWrCmdTail!=gsPrdInfo.u32TrigWrCmdTrig)
    {
        setHwPrdCore1();
    }
#endif

    setMarkPfFblock(uCh);

    NLOG(cLogCore1,
         PROGFAIL_C,
         4,
         "PFBlock: 0x%04X, PFPage: 0x%04X, PFCh: 0x%04X, PFIntlv: 0x%04X",
         gsProgFailInfo.u16FBlock,
         gsProgFailInfo.u16FPage,
         gsProgFailInfo.uCh,
         gsProgFailInfo.uIntlv);

    NLOG(cLogCore1, PROGFAIL_C, 1, "g16LdpcDmaIdCnt= 0x%04X", g16LdpcDmaIdCnt);
#if _DEBUG_LOG
    debugTSBflag(1);
#endif

    NLOG(cLogCore1,
         PROGFAIL_C,
         3,
         "gsRwCtrl.u32FreeSrcIndexHead: 0x%04X, u32FreeSrcIndexTrig: 0x%04X, u32FreeSrcIndexTail: 0x%04X",
         (WORD)(gsRwCtrl.uarFreeSrcQue[gsRwCtrl.u32FreeSrcFifoHead]),
         (WORD)(gsRwCtrl.uarFreeSrcQue[gsRwCtrl.u32FreeSrcFifoTrig]),
         (WORD)(gsRwCtrl.uarFreeSrcQue[gsRwCtrl.u32FreeSrcFifoTail]));

    NLOG(cLogCore1,
         PROGFAIL_C,
         3,
         "gsRwCtrl.u32ProgFifoHead: 0x%04X, u32ProgFifoTrig: 0x%04X, u32ProgFifoTail: 0x%04X",
         (WORD)(gsRwCtrl.u32ProgFifoHead),
         (WORD)(gsRwCtrl.u32ProgFifoTrig),
         (WORD)(gsRwCtrl.u32ProgFifoTail));

    NLOG(cLogCore1,
         PROGFAIL_C,
         2,
         "gsGcInfo.uGcState: 0x%04X, garDesAddrInfo[gsRwCtrl.u32ProgFifoTail].uAddrOpt: 0x%04X",
         (WORD)(gsGcInfo.uGcState),
         (WORD)(garDesAddrInfo[gsRwCtrl.u32ProgFifoTail].uAddrOpt));

    if(mChkProgFailFlag(cPfCacheBlk|cPfH2fTabBlk))
    {
        if(g16LdpcDmaIdCnt!=0)
        {
            NLOG(cLogCore1,
                 PROGFAIL_C,
                 2,
                 "rEccDec[0xE0]: 0x%04X, r16EccDec[0xE6/2]: 0x%04X",
                 (WORD)(rEccDec[0xE0]),
                 (WORD)(r16EccDec[0xE6/2]));
        }

#if _DEBUG_LOG
        debugAllChReadFifo(1);
#endif

        while(rmChkBopNbsBz)
            ;

        while(rmChkBopCmdFifoFull)
            ;

        while(rmChkBopBz)
            ;

        rmChSoftReset;
        mWaitCmdFifoBz;

        gsProgFailInfo.uFailedStatus=getProgFailSts(gsProgFailInfo.uIntlv);
        resetFlashAtIntlv(uCh, gsProgFailInfo.uIntlv);

        if(g16LdpcDmaIdCnt!=0)
        {
            NLOG(cLogCore1,
                 PROGFAIL_C,
                 2,
                 "After rmChSoftReset =>rEccDec[0xE0]: 0x%04X, r16EccDec[0xE6/2]: 0x%04X",
                 (WORD)(rEccDec[0xE0]),
                 (WORD)(r16EccDec[0xE6/2]));
        }

#if _DEBUG_LOG
        debugAllChReadFifo(1);
#endif
        rstChFifoPtrR(uCh);
        rstChFifoPtrW(uCh);
        rstH2F1KInfo();
        NLOG(cLogCore1, PROGFAIL_C, 1, "After rstChFifoPtrR()_g16LdpcDmaIdCnt= 0x%04X", g16LdpcDmaIdCnt);
#if _ENABLE_LDPCPIPELINE
        waitAllChCeBz();
        NLOG(cLogCore1, PROGFAIL_C, 1, "After waitAllChCeBz()_g16LdpcDmaIdCnt= 0x%04X", g16LdpcDmaIdCnt);
        NLOG(cLogCore1,
             PROGFAIL_C,
             2,
             "After waitAllChCeBz() =>rEccDec[0xE0]: 0x%04X, r16EccDec[0xE6/2]: 0x%04X",
             (WORD)(rEccDec[0xE0]),
             (WORD)(r16EccDec[0xE6/2]));
        funcTskDisLdpcPipe(0);

        NLOG(cLogCore1, PROGFAIL_C, 1, "Case1_g16LdpcDmaIdCnt= 0x%04X", g16LdpcDmaIdCnt);
        NLOG(cLogCore1,
             PROGFAIL_C,
             2,
             "After funcTskDisLdpcPipe(0) =>rEccDec[0xE0]: 0x%04X, r16EccDec[0xE6/2]: 0x%04X",
             (WORD)(rEccDec[0xE0]),
             (WORD)(r16EccDec[0xE6/2]));
#if _DEBUG_LOG
        debugAllChReadFifo(1);
#endif

        if(g16LdpcDmaIdCnt!=0)
        {
            if(rmChkLdpcInfoFifoFull)
            {
#if 1
                asm ("DSB");
                rmTsbDisTsb0Flg;
                rmTsbDisTsb1Flg;
                sysDelay(0x10);
                rmTsbEnTsb0Flg;
                rmTsbEnTsb1Flg;
                sysDelay(0x10);
                asm ("DSB");
                rmResetkLdpcInfoFifo;
#endif
            }

            while(rmChkLdpcInfoFifoReady)
            {
                sysDelay(16);
                rmPopLdpcInfo;
                sysDelay(16);

                if(rmChkLdpcInfoFifoEmpty)
                {
#if 0
                    asm ("DSB");
                    rmTsbDisTsb0Flg;
                    rmTsbDisTsb1Flg;
                    sysDelay(0x10);
                    rmTsbEnTsb0Flg;
                    rmTsbEnTsb1Flg;
                    sysDelay(0x10);
                    asm ("DSB");
#endif
                    break;
                }
            }

            g16LdpcDmaIdCnt=0;
        }
#endif/* if _ENABLE_LDPCPIPELINE */
        u32TmpRRCnt=gsFtlDbg.u32RRCnt;

#if (_EN_Fake_ProgramFail_Check)
        if(chkPfChPageRead())
        {
            movePfChPageData();
        }
#else
        movePfChPageData();
#endif

        NLOG(cLogCore1, PROGFAIL_C, 0, "cPfCacheBlk Or cPfH2fTabBlk");
#if _DEBUG_LOG
        debugTSBflag(1);
#endif

        if(gsFtlDbg.u32RRCnt>u32TmpRRCnt)
        {
            gsFtlDbg.u32PfRehCnt+=gsFtlDbg.u32RRCnt-u32TmpRRCnt;
            NLOG(cLogCore1, PROGFAIL_C, 2, "PfRehCnt= : 0x%08X ", (gsFtlDbg.u32PfRehCnt>>16),
                 (gsFtlDbg.u32PfRehCnt));
        }

#if _ENABLE_LDPCPIPELINE
        waitAllChCeBz();
        funcTskEnLdpcPipe(0);
#endif
        rstOpIndex(uCh);
        mClrCacheInfoFlag(cDataProgramFail|cMoveProgramFail);
    }
    else if(mChkProgFailFlag(cPfGcDesBlk))
    {
        NLOG(cLogCore1, PROGFAIL_C, 1, "Case2_g16LdpcDmaIdCnt= 0x%04X", g16LdpcDmaIdCnt);

        if((mGetGcState==cGcMoveData)&&(gsRwCtrl.u32ProgFifoHead!=gsRwCtrl.u32ProgFifoTail)&&
           ((garDesAddrInfo[gsRwCtrl.u32ProgFifoTail].uAddrOpt&0x0F)==cGcDesBlockID))
        {
            sysDelay(0x1000);
            // Reset all flash cmd que and status.
            NLOG(cLogCore1, PROGFAIL_C, 0, "cPfGcDesBlk && cGcMoveData && cGcDesBlockID");
            setSelMulFL(1);
            rmChSoftReset;
            setSelMulFL(0);
            rstChFifoPtrW(uCh);
        }
        else
        {
            // Not in Gc moveData program flow, ex. Gc moveData read, and flushGcDes ....
            // Only reset the PF ch status
            NLOG(cLogCore1, PROGFAIL_C, 0, "cPfGcDesBlk");
            rmResetEccSts;
            rmCmdQueResume;
            sysDelay(16);
            // mWaitCmdFifoBz;

            sysDelay(0x1000);
            // Reset all flash cmd que and status.
            setSelMulFL(1);
            rmChSoftReset;
            setSelMulFL(0);
            rstChFifoPtrW(uCh);

            setFLActCh(uCh);

            while(rmChkCmdFifoBz)
            {
                if(gsRwCtrl.u32ProgFifoHead!=gsRwCtrl.u32ProgFifoTail)
                {
                    rmChSoftReset;
                    rstChFifoPtrW(uCh);
                    setFLActCh(uCh);
                }
            }
        }

        rstOpIndex(gTotalChNum);
        resetFlashAtIntlv(uCh, gsProgFailInfo.uIntlv);
        NLOG(cLogCore1, PROGFAIL_C, 0, "rstOpIndex(gTotalChNum) & resetFlashAtIntlv done!!");
        NLOG(cLogCore1,
             PROGFAIL_C,
             2,
             "rEccDec[0xE0]: 0x%04X, r16EccDec[0xE6/2]: 0x%04X",
             (WORD)(rEccDec[0xE0]),
             (WORD)(r16EccDec[0xE6/2]));
#if _DEBUG_LOG
        debugAllChReadFifo(1);
        debugTSBflag(1);
#endif
    }
    else
    {
        NLOG(cLogCore1, PROGFAIL_C, 1, "Case3_g16LdpcDmaIdCnt= 0x%04X", g16LdpcDmaIdCnt);
        rmResetEccSts;
        rmCmdQueResume;
        sysDelay(16);
        mWaitCmdFifoBz;
        resetFlashAtIntlv(uCh, gsProgFailInfo.uIntlv);
        NLOG(cLogCore1, PROGFAIL_C, 0, "CmdQueResume and resetFlashAtIntlv");
        NLOG(cLogCore1,
             PROGFAIL_C,
             2,
             "rEccDec[0xE0]: 0x%04X, r16EccDec[0xE6/2]: 0x%04X",
             (WORD)(rEccDec[0xE0]),
             (WORD)(r16EccDec[0xE6/2]));
#if _DEBUG_LOG
        debugAllChReadFifo(1);
        debugTSBflag(1);
#endif
    }

#if _EN_CHRONUS_UART_DEBUG
    NLOG(cLogCore1, PROGFAIL_C, 0, "Pf End");
    NLOG(cLogCore1,
         PROGFAIL_C,
         3,
         "gsRwCtrl.u32FreeSrcIndexHead: 0x%04X, u32FreeSrcIndexTrig: 0x%04X, u32FreeSrcIndexTail: 0x%04X",
         (WORD)(gsRwCtrl.uarFreeSrcQue[gsRwCtrl.u32FreeSrcFifoHead]),
         (WORD)(gsRwCtrl.uarFreeSrcQue[gsRwCtrl.u32FreeSrcFifoTrig]),
         (WORD)(gsRwCtrl.uarFreeSrcQue[gsRwCtrl.u32FreeSrcFifoTail]));

    NLOG(cLogCore1,
         PROGFAIL_C,
         3,
         "gsRwCtrl.u32ProgFifoHead: 0x%04X, u32ProgFifoTrig: 0x%04X, u32ProgFifoTail: 0x%04X",
         (WORD)(gsRwCtrl.u32ProgFifoHead),
         (WORD)(gsRwCtrl.u32ProgFifoTrig),
         (WORD)(gsRwCtrl.u32ProgFifoTail));
    NLOG(cLogCore1, PROGFAIL_C, 1, "Case4_g16LdpcDmaIdCnt= 0x%04X", g16LdpcDmaIdCnt);
#endif/* if _EN_CHRONUS_UART_DEBUG */
#if _DEBUG_LOG
    debugAllChReadFifo(1);
    getPfRtcTime(u32PfProcTime);
#endif
#endif/* if _EN_PROGFAILLOG */
}    /* chkPfFblock */

void setPfBadBlock(ADDRINFO *upAddrInfo, BYTE uFailID)
{
    BYTE uPlaneAddr;

    for(uPlaneAddr=0; uPlaneAddr<gPlaneNum; uPlaneAddr++)
    {
        upAddrInfo->uPlaneAddr=uPlaneAddr;
#if _EN_CHRONUS_UART_DEBUG
        upAddrInfo->u16FBlock=upAddrInfo->u16AbstractFBlock;
#endif
        setMarkBadBlock(upAddrInfo, uFailID);
    }
}

void setMarkPfFblock(BYTE uCh)
{
    BYTE uIntlvAddr, uChProgFifoTrig=gsRwCtrl.uChProgFifoTrig[uCh];
    WORD u16FBlock;
    ADDRINFO usTmpAddrInfo;

    u16FBlock=(((WORD)rFLCtrl[rcAleQBlkAddrHi]<<8)|rFLCtrl[rcAleQBlkAddrLo]);
    usTmpAddrInfo.u16FPage=(((WORD)rFLCtrl[rcAleQPgAddrHi]<<8)|rFLCtrl[rcAleQPgAddrLo]);
    usTmpAddrInfo.uIntlvAddr=uIntlvAddr=(rFLCtrl[rcAleQSctrAddr]>>5)&0x07;
    usTmpAddrInfo.uPlaneAddr=0;    // rFLCtrl[rcAleQPlaneAddr]&0x03;
    usTmpAddrInfo.uCh=uCh;
    usTmpAddrInfo.uAddrOpt|=cProgFail;
    gsProgFailInfo.u16FBlock=u16FBlock;
    gsProgFailInfo.u16FPage=usTmpAddrInfo.u16FPage;
    gsProgFailInfo.uCh=uCh;
    gsProgFailInfo.uIntlv=uIntlvAddr;
    gsProgFailInfo.uPlaneAddr=usTmpAddrInfo.uPlaneAddr;
    gsProgFailInfo.u32ProgFailFlag=0;

#if 1
    g16EccFailChAndCe=((uCh<<8)|mGetCEAddr(uIntlvAddr));
    g16EccFailDieAndPlane=((mGetDieAddr(uIntlvAddr)<<8)|usTmpAddrInfo.uPlaneAddr);

    g16EccFailBlkAddr=u16FBlock;

    if(g16arDiffOffset[u16FBlock]!=0xffff)
    {
        g16EccFailBlkAddr=getDiffAddr(u16FBlock, uCh, uIntlvAddr, usTmpAddrInfo.uPlaneAddr);
    }

    if((!(mChkMlcMoBit(u16FBlock))))
    {
        if(mChkFLParam(cWithRlibMo))
        {
            g16EccFailPageAddr=usTmpAddrInfo.u16FPage;
        }
        else if(mChkCardMode(cWithSlcMo))
        {
            g16EccFailPageAddr=(usTmpAddrInfo.u16FPage<<1);
        }
    }
    else
    {
#if (_HYNIX_V3|_TSB_BiCS3|_SANDISK_3D_GEN2|_SANDISK_3D_GEN3)
        g16EccFailPageAddr=((cProgCntPerWL*usTmpAddrInfo.u16FPage)+mGetPageSelCmdS(usTmpAddrInfo)-1);
#endif
    }

    g16EccFailRegInfo=((rFLCtrl[rcEccResultSts]<<8)|rFLCtrl[rcOnceCntstatus]);    // 0x118 & 0x11D
    g16EccFailChunkBitMap=0;    // g16DebugLastFailChunkBitMap
    updateLogNandQueue();
#endif/* if 1 */

#if _EN_CHRONUS_UART_DEBUG
    NLOG(cLogCore1, PROGFAIL_C, 0, "Pf Start");
    NLOG(cLogCore1,
         PROGFAIL_C,
         5,
         "Pf FBlock = 0x%04X, FPage = 0x%04X, CH = 0x%04X, CE = 0x%04X, Plane = 0x%04X",
         gsProgFailInfo.u16FBlock,
         gsProgFailInfo.u16FPage,
         gsProgFailInfo.uCh,
         gsProgFailInfo.uIntlv,
         gsProgFailInfo.uPlaneAddr);
#endif

    if(chkProgFailBlock(&usTmpAddrInfo, g16arH2fTabBlk[gsCacheInfo.uActH2fTabBlkIdx]))
    {
        mSetCacheInfoFlag(cH2fProgramFail);
        mSetProgFailFlag(cPfH2fTabBlk);
        setPfBadBlock(&usTmpAddrInfo, cProgFailH2fID);
        gsFtlDbg.uPfH2fCnt++;
#if _EN_CHRONUS_UART_DEBUG
        NLOG(cLogCore1, PROGFAIL_C, 0, "H2f");
#endif
    }
    else if(chkProgFailBlock(&usTmpAddrInfo, gsWproInfo.u16arWproBlk[gsWproInfo.uActIdx]))
    {
        mSetCacheInfoFlag(cWproProgramFail);
        mSetProgFailFlag(cPfWproBlk);
        setPfBadBlock(&usTmpAddrInfo, cProgFailWproID);
        gsFtlDbg.uPfWproCnt++;
#if _EN_CHRONUS_UART_DEBUG
        NLOG(cLogCore1, PROGFAIL_C, 0, "Wpro");
#endif
    }
    else if(chkProgFailBlock(&usTmpAddrInfo, g16arRaidParityBlk[gsCacheInfo.uRaidGcPtyBlkIdx]))
    {
        mSetGcFlag(cGcDesFailAbort);
        mSetProgFailFlag(cPfGcDesBlk);
        rmResetBufFlg;
        setPfBadBlock(&usTmpAddrInfo, cProgFailParityID);
        gsFtlDbg.uPfRaidCnt++;
#if _EN_CHRONUS_UART_DEBUG
        NLOG(cLogCore1, PROGFAIL_C, 0, "Raid");
#endif
    }
    else if(chkProgFailBlock(&usTmpAddrInfo, gsGcInfo.u16GcDesBlock)||chkProgFailBlock(&usTmpAddrInfo, gsGcInfo.u16GcDesPfBlock))
    {
        mSetGcFlag(cGcDesFailAbort);
        mSetProgFailFlag(cPfGcDesBlk);
        rmResetBufFlg;
        setPfBadBlock(&usTmpAddrInfo, cProgFailGcDesID);
        gsFtlDbg.uPfGcDesCnt++;
#if _EN_CHRONUS_UART_DEBUG
        NLOG(cLogCore1, PROGFAIL_C, 0, "Des");
#endif
    }
    else if(chkProgFailBlock(&usTmpAddrInfo, gsCacheInfo.u16ActiveCacheBlock)||chkProgFailBlock(&usTmpAddrInfo, gsCacheInfo.u16FluCacheBlock))
    {
        mSetCacheInfoFlag(cDataProgramFail);
        mSetProgFailFlag(cPfCacheBlk);
#if _EN_CHRONUS_UART_DEBUG
        NLOG(cLogCore1, PROGFAIL_C, 0, "Data");
#endif
    }
    else
    {
        mSetProgFailFlag(cPfNotFound);
        gsFtlDbg.u16DummyFailType=cSetMarkPfFblock2;
        debugWhile();
    }
}    /* setMarkPfFblock */

BYTE chkProgFailBlock(ADDRINFO *upTmpAddrInfo, WORD u16ChkFBlock)
{
    WORD u16FBlock;

    if(u16ChkFBlock<c16FBlockInitValue)
    {
        u16FBlock=upTmpAddrInfo->u16AbstractFBlock=u16ChkFBlock;

        if(u16FBlock==gsProgFailInfo.u16FBlock)
        {
            return cTrue;
        }
    }

    return cFalse;
}    /* chkProgFailBlock */

void rstChFifoPtrW(BYTE uCh)
{
    // BYTE uIntlvAddr, uProgFifoTail;
    BYTE uIntlvAddr;
    volatile BYTE uProgFifoTail;
    ADDRINFO *upTmpAddrInfo;

    if(mChkProgFailFlag(cPfGcDesBlk))
    {
        for(uCh=0; uCh<gTotalChNum; uCh++)
        {
            if(gsRwCtrl.uOpIdxAccCntW[uCh])
            {
                chkOpIdxAccCntW(uCh);
            }

            while(gsRwCtrl.uChProgFifoTrig[uCh]!=gsRwCtrl.uChProgFifoHead[uCh])
            {
                sortProgFifoIdx(uCh, gsRwCtrl.uChProgFifoTrig[uCh]);
                gsRwCtrl.uChProgFifoTrig[uCh]=addChPgFfPtrBy1(gsRwCtrl.uChProgFifoTrig[uCh]);
            }

            gsRwCtrl.uChProgFifoTail[uCh]=gsRwCtrl.uChProgFifoTrig[uCh];

            for(uIntlvAddr=0; uIntlvAddr<gIntlvWay; uIntlvAddr++)
            {
                gsRwCtrl.uRdyTyp[uCh][uIntlvAddr]=0;
                gsRwCtrl.usWaitInfo[uCh][uIntlvAddr].uWaitFlag=cNoOp;
                gsRwCtrl.usWaitInfo[uCh][uIntlvAddr].uStatusErrStop=0;
            }
        }

        gsRwCtrl.u32ProgFifoTail=gsRwCtrl.u32ProgFifoTrig=gsRwCtrl.u32ProgFifoHead;
    }
    else
    {
        gsProgFailInfo.uLastChProgFifoTail=gsRwCtrl.uChProgFifoTail[uCh];
        gsProgFailInfo.uLastChProgFifoTrig=gsRwCtrl.uChProgFifoTrig[uCh];
        gsProgFailInfo.uLastChProgFifoHead=gsRwCtrl.uChProgFifoHead[uCh];

        ADDRINFO *upAddrInfo=&garDesAddrInfo[gsRwCtrl.uChProgFifoIdx[uCh][gsRwCtrl.uChProgFifoTail[uCh]]];

        if(upAddrInfo->u16FPage==gsProgFailInfo.u16FPage)
        {
            LWORD u32TmpBufStatus;
            WORD u16BufIdx=(upAddrInfo->u16BufPtr>>5);
            BYTE uSctrCnt=(upAddrInfo->uRwHalfKb>>5);

            while(uSctrCnt)
            {
                u32TmpBufStatus=rm32BufStatus(u16BufIdx);

                if(u32TmpBufStatus)
                {
#if _DEBUG_LOG
                    debugTSBflag(1);
#endif
                    rmSetBuf32Sts(u16BufIdx, u32TmpBufStatus);
                    NLOG(cLogCore1, PROGFAIL_C, 1, "rstChFifoPtrW(), u16BufPtr: 0x%04X", upAddrInfo->u16BufPtr);
#if _DEBUG_LOG
                    debugTSBflag(1);
#endif

                    while(rm32BufStatus(u16BufIdx))
                        ;
                }

                u16BufIdx++;
                uSctrCnt--;
            }
        }

        while(gsRwCtrl.uChProgFifoTail[uCh]!=gsRwCtrl.uChProgFifoTrig[uCh])
        {
            setReproFifoPtr(gsRwCtrl.uChProgFifoIdx[uCh][gsRwCtrl.uChProgFifoTail[uCh]]);
            gsRwCtrl.uChProgFifoTail[uCh]=addChPgFfPtrBy1(gsRwCtrl.uChProgFifoTail[uCh]);
            gsRwCtrl.uOpIdxAccCntW[uCh]--;
#if _EnSpareFunc
            upTmpAddrInfo=&garDesAddrInfo[gsRwCtrl.uChProgFifoIdx[uCh][gsRwCtrl.uChProgFifoTail[uCh]]];

            if(gSpareCnt[uCh]>=mGetSprUseCnt(upTmpAddrInfo))
            {
                gSpareCnt[uCh]-=mGetSprUseCnt(upTmpAddrInfo);
            }
#endif
        }

        NLOG(cLogCore1, PROGFAIL_C, 3,
             "rstChFifoPtrW(), gsRwCtrl.u32ProgFifoHead: 0x%04X, u32ProgFifoTrig: 0x%04X, u32ProgFifoTail: 0x%04X",
             (WORD)(gsRwCtrl.u32ProgFifoHead),
             (WORD)(gsRwCtrl.u32ProgFifoTrig),
             (WORD)(gsRwCtrl.u32ProgFifoTail));

        uProgFifoTail=gsRwCtrl.u32ProgFifoTail;

        while((uProgFifoTail!=gsRwCtrl.u32ProgFifoTrig)&&(garDesAddrInfo[uProgFifoTail].uAddrOpt&cDone))
        {
            uProgFifoTail=addWrFfPtrBy1(uProgFifoTail);
            NLOG(cLogCore1,
                 PROGFAIL_C,
                 3,
                 "rstChFifoPtrW(), Move uProgFifoTail: 0x%04X ,gsRwCtrl.u32ProgFifoTrig:  0x%04X , garDesAddrInfo[uProgFifoTail].uAddrOpt:  0x%04X ",
                 uProgFifoTail,
                 gsRwCtrl.u32ProgFifoTrig,
                 (garDesAddrInfo[uProgFifoTail].uAddrOpt));
        }

        gsProgFailInfo.uLastProgFifoTail=uProgFifoTail;

        while(gsRwCtrl.uChProgFifoTrig[uCh]!=gsRwCtrl.uChProgFifoHead[uCh])
        {
            setReproFifoPtr(gsRwCtrl.uChProgFifoIdx[uCh][gsRwCtrl.uChProgFifoTrig[uCh]]);
            sortProgFifoIdx(uCh, gsRwCtrl.uChProgFifoTrig[uCh]);
            gsRwCtrl.uChProgFifoTrig[uCh]=addChPgFfPtrBy1(gsRwCtrl.uChProgFifoTrig[uCh]);
            NLOG(cLogCore1, PROGFAIL_C, 1, "rstChFifoPtrW(), Move gsRwCtrl.uChProgFifoTrig[uCh]: 0x%04X", gsRwCtrl.uChProgFifoTrig[uCh]);
        }

        gsRwCtrl.uChProgFifoTail[uCh]=gsRwCtrl.uChProgFifoTrig[uCh];
    }
}    /* rstChFifoPtrW */

void rstChFifoPtrR(BYTE uCh)
{
    ADDRINFO *upTmpAddrInfo;
    BYTE uChFifoPtr;

    NLOG(cLogCore1,
         PROGFAIL_C,
         4,
         "CH: 0x%04X, Intlv: 0x%04X, gsRwCtrl.uChPreFifoHead: %04d, gsRwCtrl.uChPreFifoTail: %04d",
         uCh,
         gsProgFailInfo.uIntlv,
         gsRwCtrl.uChPreFifoHead[uCh][gsProgFailInfo.uIntlv],
         gsRwCtrl.uChPreFifoTail[uCh][gsProgFailInfo.uIntlv]);

    //// ReadNop Case - Reset to ChPreReadFifo
    if(gsRwCtrl.uChReadFifoTail[uCh]!=gsRwCtrl.uChReadFifoHead[uCh])
    {
        uChFifoPtr=gsRwCtrl.uChReadFifoHead[uCh];

        while(gsRwCtrl.uChReadFifoTrig[uCh]!=uChFifoPtr)
        {
            uChFifoPtr=(uChFifoPtr-1)&(cMaxChFifoRDepth-1);
            upTmpAddrInfo=&garSrcAddrInfo[gsRwCtrl.uChReadFifoIdx[uCh][uChFifoPtr]];

            // while((upTmpAddrInfo->uOpTyp!=cPreReadData)&&(upTmpAddrInfo->uOpTyp!=cLastReadData));

            if(upTmpAddrInfo->u16RwOpt&cBit2)
            {
                upTmpAddrInfo->u16RwOpt&=(~cBit2);
            }

            gsRwCtrl.uChReadFifoCnt[uCh]--;
            gsRwCtrl.uChPreFifoCnt[uCh]++;
            gsRwCtrl.uChPreFifoTail[uCh][gsProgFailInfo.uIntlv]=(gsRwCtrl.uChPreFifoTail[uCh][gsProgFailInfo.uIntlv]-1)&
                                                                 (cMaxChFifoRDepth-1);
            NLOG(cLogCore1,
                 PROGFAIL_C,
                 1,
                 "1. Move gsRwCtrl.uChPreFifoTail: %04d",
                 gsRwCtrl.uChPreFifoTail[uCh][gsProgFailInfo.uIntlv]);
        }

        uChFifoPtr=gsRwCtrl.uChReadFifoTrig[uCh];

        while(gsRwCtrl.uChReadFifoTail[uCh]!=uChFifoPtr)
        {
            uChFifoPtr=(uChFifoPtr-1)&(cMaxChFifoRDepth-1);
            upTmpAddrInfo=&garSrcAddrInfo[gsRwCtrl.uChReadFifoIdx[uCh][uChFifoPtr]];

            // while((upTmpAddrInfo->uOpTyp!=cPreReadData)&&(upTmpAddrInfo->uOpTyp!=cLastReadData));

            upTmpAddrInfo->uPlaneAddr=upTmpAddrInfo->uStartPlaneAddr;
            // upTmpAddrInfo->uSectorH=upTmpAddrInfo->uOrgSectorH;

            NLOG(cLogCore1,
                 PROGFAIL_C,
                 2,
                 "2. pTmpAddrInfo->uDmaCnt: 0x%04X, g16LdpcDmaIdCnt: %04d",
                 upTmpAddrInfo->uDmaCnt,
                 g16LdpcDmaIdCnt);

            g16LdpcDmaIdCnt-=mGetDmaCnt(upTmpAddrInfo);
            mClrDmaCnt(upTmpAddrInfo);

            if(upTmpAddrInfo->u16RwOpt&cBit2)
            {
                upTmpAddrInfo->u16RwOpt&=(~cBit2);
            }

            gsRwCtrl.u32AllReadFifoCnt++;
            gsRwCtrl.uChPreFifoCnt[uCh]++;
            gsRwCtrl.uChPreFifoTail[uCh][gsProgFailInfo.uIntlv]=(gsRwCtrl.uChPreFifoTail[uCh][gsProgFailInfo.uIntlv]-1)&
                                                                 (cMaxChFifoRDepth-1);
            NLOG(cLogCore1,
                 PROGFAIL_C,
                 1,
                 "3. Move gsRwCtrl.uChPreFifoTail: %04d",
                 gsRwCtrl.uChPreFifoTail[uCh][gsProgFailInfo.uIntlv]);
        }

        gsRwCtrl.uChReadFifoHead[uCh]=gsRwCtrl.uChReadFifoTrig[uCh]=gsRwCtrl.uChReadFifoTail[uCh];
        gsRwCtrl.u16LastFBlockR[uCh][upTmpAddrInfo->uIntlvAddr]=cInvalid16Bit;
        gsRwCtrl.u16LastFPageR[uCh][upTmpAddrInfo->uIntlvAddr]=cInvalid16Bit;
    }

    g16LastRdCntFBlock=cInvalid16Bit;
    g16LastRdCntFPage=cInvalid16Bit;
}    /* rstChFifoPtrRw */

void rstOpIndex(BYTE uChNum)
{
    BYTE uCh;

    if(uChNum==gTotalChNum)
    {
        for(uCh=0; uCh<uChNum; uCh++)
        {
            gsRwCtrl.uOpIdxSerial[uCh]=0x00;
            gsRwCtrl.uOpIdxAccCntR[uCh]=0x00;
            gsRwCtrl.uOpIdxAccCntW[uCh]=0x00;

            gWaitSpareTyp[uChNum]=0xFF;
            gSpareCnt[uChNum]=0;
            gSparePtrHead[uChNum]=0;
            gSparePtrTail[uChNum]=0;
        }
    }
    else
    {
        gsRwCtrl.uOpIdxSerial[uChNum]=0x00;
        gsRwCtrl.uOpIdxAccCntR[uChNum]=0x00;
        gsRwCtrl.uOpIdxAccCntW[uChNum]=0x00;

        gWaitSpareTyp[uChNum]=0xFF;
        gSpareCnt[uChNum]=0;
        gSparePtrHead[uChNum]=0;
        gSparePtrTail[uChNum]=0;
    }
}    /* rstOpIndex */

void setRecovWrPara(BYTE uValue)
{
    rmCle(0x56);
    rmAle(uValue);
    rmNop(11);
    rmCmdMaskCleAleEnable;
    rmCle(0x01);
    rmCmdMaskCleAleDisable;
    rmNop(11);
}

void recovPfPageData(ADDRINFO *upAddrInfo, BYTE uPlaneAddr, BYTE uRecovPage)
{
#if 1
    // bopClrRam((LWORD)(c32Tsb0SAddr+(upAddrInfo->u16BufPtr<<9)), gSectorPerPlaneH<<9, 0x50665066, cClrTsb|cBopWait);
    fillCcmVal((BYTE *)(c32Tsb0SAddr+(upAddrInfo->u16BufPtr<<9)), gSectorPerPlaneH<<9, 0x50);
#else
    setFLAddrActCh(upAddrInfo->uCh, upAddrInfo);
    rmCeOn(mGetCEAddr(gIntlvAddr));
    flashChangeDieCmd(mGetDieAddr(gIntlvAddr));

    if(uRecovPage==cCurrPage)
    {
        gPlaneAddr=uPlaneAddr;
        setAutoFBlock(gIntlvAddr, gPlaneAddr);
        setAutoAleReg(mGetPageSelCmd(gpFlashAddrInfo));
        setRandomoutCmd(0);
        rmSetBufSAddr(gpFlashAddrInfo->u16BufPtr);
        setAutoRead(gSectorPerPlaneH, 0);
        rmRdSpr;
        mWaitCmdFifoBz;
    }
    else
    {
        gPlaneAddr=uPlaneAddr;
        setAutoFBlock(gIntlvAddr, gPlaneAddr);
        setAutoAleReg(mGetPageSelCmd(gpFlashAddrInfo));

        rmEnAleCleDoubleCycle;
        rmEnACle2Cycle;
        rmCle(0x5C);
        rmCle(0xC5);
        setRecovWrPara(0x00);
        setRecovWrPara(0x01);
        rmEnAleCleDoubleCycle;
        rmEnACle1Cycle;

        rmCle(0x00);
        rmSetPlaneBit(gPlaneAddr);
        rmAle5;
        rmCle(0xCA);
        pollStatus(cPollMaskNor);
        rmCle(gReadMoCmd);
        setRandomoutCmd(0);
        rmSetBufSAddr(gpFlashAddrInfo->u16BufPtr);
        setAutoRead(gSectorPerPlaneH, 0);
        rmRdSpr;
        mWaitCmdFifoBz;
        rmCle(0xFB);
        pollStatus(cPollMaskNor);
        mWaitCmdFifoBz;
    }
    rmCeOff(gCe);
#endif/* if 1 */
}    /* recovPfPageData */

BYTE getProgFailSts(BYTE uIntlvAddr)
{
    BYTE uStatus;

    rmCeOn(mGetCEAddr(uIntlvAddr));
    flashChangeDieCmd(mGetDieAddr(uIntlvAddr));
    rmCle(gReadStatusCmd);
    rFLCtrl[rcStsFailMask]=0;
    rmRdStatus(cPollMaskNor);
    rmManRd(2);
    mWaitCmdFifoBz;
    uStatus=rFLCtrl[rcRd0];

#if _GREYBOX
    if((gsGbInfo.uGreyBoxItem==cErrHdlProgCacheBlk)||(gsGbInfo.uGreyBoxItem==cErrHdlProgWPROID)||
       (gsGbInfo.uGreyBoxItem==cErrHdlProgH2fTableID)||(gsGbInfo.uGreyBoxItem==cErrHdlProgS2TGcDesID)||
       (gsGbInfo.uGreyBoxItem==cErrHdlProgT2TGcDesID)||(gsGbInfo.uGreyBoxItem==cErrHdlProgS2SGcDesID))
    {
#if _EN_CACHEPROG
        if(mChkFLOption(cEnCacheProg))
        {
            uStatus|=cBit3;
        }
        else
        {
            uStatus|=cBit2;
        }
#else
        uStatus|=cBit2;
#endif
    }
#endif/* if _GREYBOX */

    rmAllCeOff;

    return uStatus;
}    /* getProgFailSts */

void setReproFifoPtr(BYTE uChProgFifoIdx)
{
    ADDRINFO *upAddrInfo=&garDesAddrInfo[uChProgFifoIdx];

    NLOG(cLogCore1, PROGFAIL_C, 1, "setReproFifoPtr, uChProgFifoIdx: %04d", uChProgFifoIdx);
#if _DEBUG_LOG
    printNandPhyAddr(upAddrInfo);
#endif
    upAddrInfo->uAddrOpt|=(cDone|cProgFail);
    upAddrInfo->uOpTyp=cReProgData;

    if(upAddrInfo->u16FPage>gsProgFailInfo.u16FPage)
    {
        gsProgFailInfo.uarPfProgFifoPtr[gsProgFailInfo.uReProgCnt]=uChProgFifoIdx;
        gsProgFailInfo.uReProgCnt++;
    }
}    /* setReproFifoPtr */

BYTE chkBufRaidFlag(WORD u16BufPtr)
{
    if(rm32BufStatus(u16BufPtr>>5)||rm32BufStatus((u16BufPtr+gSectorPerPlaneH)>>5)||rm32BufRaidStatus(u16BufPtr>>5)||
       rm32BufRaidStatus((u16BufPtr+gSectorPerPlaneH)>>5))
    {
        if((u16BufPtr+gSectorPerPageH)<=cTsb0Size)
        {
            return cTrue;
        }
    }

    return cFalse;
}

BYTE eraseDiffPoolBlk(BYTE uCh, BYTE uIntlvAddr)
{
    ADDRINFO usTmpAddrInfo;
    BYTE uPlaneAddr, uEraseStatus=0;

    setFLAddrActCh(uCh, &usTmpAddrInfo);
    waitChCeBz(uCh, uIntlvAddr, 0);

    rmSetPageAddr(0x00);
    rmSetSctrAddr(0x00);
    rmResetEccSts;    // resetECC();

    rmCeOn(mGetCEAddr(uIntlvAddr));
    flashChangeDieCmd(mGetDieAddr(uIntlvAddr));

    for(uPlaneAddr=0; uPlaneAddr<gPlaneNum; uPlaneAddr++)
    {
        g16FBlock=gsProgFailInfo.u16DiffPoolFBlk[uPlaneAddr];
        mClrMlcMoBit(g16FBlock);

        if(!uPlaneAddr)
        {
            chkRlibMoCmd();
        }

        setAutoFBlock(uIntlvAddr, uPlaneAddr);
        rmCle(gBlockEraseCmd1);    // 60h
        rmSetPlaneBit(uPlaneAddr);
        rmAle3;
    }

    rmCle(gBlockEraseCmd2);    // D0h
    rmAllCeOff;
    setBzInfo(cEraseBlk, uCh, uIntlvAddr);
    gsRwCtrl.u16LastFBlockR[uCh][uIntlvAddr]=cInvalid16Bit;
    g16LastRdCntFBlock=cInvalid16Bit;
    g16LastRdCntFPage=cInvalid16Bit;

    waitChCeBz(uCh, uIntlvAddr, 0);
    mWaitCmdFifoBz;

    if(rmChkStatusFail)
    {
        rmResetEccSts;    // Status fail can happen in both plane
        rmCmdQueResume;
        sysDelay(16);    // wait cmd fifo resume
        uEraseStatus=1;
        mWaitCmdFifoBz;
    }

    return uEraseStatus;
}    /* eraseDiffPoolBlk */

BYTE initPfFblkProc(WORD u16SbufPtr)
{
    BYTE uPlaneAddr, uAddr, uEraseStatus=0;
    WORD *u16DiffBlkPtr=(WORD *)(c32Tsb0SAddr+(u16SbufPtr<<9));

#if _EN_CHRONUS_UART_DEBUG
    WORD u16FBlock;
#endif

    if((gsProgFailInfo.uFailedStatus&cBit3)||gsRwCtrl.usSrcCmdList.u16Cnt)
    {
        gsProgFailInfo.uDiffPool=0;
    }
    else
    {
        gsProgFailInfo.uDiffPool=1;

        for(uPlaneAddr=0; uPlaneAddr<gPlaneNum; uPlaneAddr++)
        {
            uAddr=(gsProgFailInfo.uCh*gIntlvWay+gsProgFailInfo.uIntlv)*gPlaneNum+uPlaneAddr;

            if(!garRtDiffPoolPtr[uAddr])
            {
                gsProgFailInfo.uDiffPool=0;
                break;
            }
        }
    }

    if(gsProgFailInfo.uDiffPool)
    {
        readWproPage(cWproBadInfo, u16SbufPtr, 2);    // load Diff pool

        for(uPlaneAddr=0; uPlaneAddr<gPlaneNum; uPlaneAddr++)
        {
            uAddr=(gsProgFailInfo.uCh*gIntlvWay+gsProgFailInfo.uIntlv)*gPlaneNum+uPlaneAddr;
            garRtDiffPoolPtr[uAddr]--;
            gsProgFailInfo.u16DiffPoolFBlk[uPlaneAddr]=u16DiffBlkPtr[uAddr*gDiffType3Num+garRtDiffPoolPtr[uAddr]];

#if _EN_CHRONUS_UART_DEBUG
            NLOG(cLogCore1, PROGFAIL_C, 2, "DiffPool: new block Plane%04X=0x%04X ", uPlaneAddr, gsProgFailInfo.u16DiffPoolFBlk[uPlaneAddr]);
#endif
        }

        uEraseStatus=eraseDiffPoolBlk(gsProgFailInfo.uCh, gsProgFailInfo.uIntlv);
        gsProgFailInfo.u16PopPfFBlk=0xFFFF;
    }
    else
    {
        gsProgFailInfo.u16PopPfFBlk=popSpareBlock(cPopMinErsCnt|cPopSlcBlock);
        gsProgFailInfo.u16SparePoolFBlk[gsProgFailInfo.uPopPfFBlkCnt]=gsProgFailInfo.u16PopPfFBlk;
        gsProgFailInfo.uPopPfFBlkCnt++;

#if _EN_CHRONUS_UART_DEBUG
        for(uPlaneAddr=0; uPlaneAddr<gPlaneNum; uPlaneAddr++)
        {
            u16FBlock=getDiffFBlock(gsProgFailInfo.u16PopPfFBlk, gsProgFailInfo.uCh, gsProgFailInfo.uIntlv, uPlaneAddr);
            NLOG(cLogCore1, PROGFAIL_C, 2, "SparePool: new block Plane%04X=0x%04X ", uPlaneAddr, (LWORD)u16FBlock);
        }
#endif

        while(gsProgFailInfo.uPopPfFBlkCnt>=cPopPfFBlkCnt)
            ;
    }

    return uEraseStatus;
}    /* initPfFblkProc */

void updateDiffAddrTab(BYTE uCh, BYTE uIntlvIdx, BYTE uPlaneIdx)
{
    LWORD u32OrgDiffBitMap;
    WORD u16SrchRst, u16DiffAddrFreePtr=0;
    BYTE uIdx, uIdx1, uLoop, uDiffOfst;

    u16SrchRst=bopSrchRam((LWORD)g16arDiffOffset, c15BitFF, c32BitFF, 0, g16TotalFBlock, cBopSrchMax|cBopWordMo|cBopWait|cBopSrchDccm);

    if(u16SrchRst!=cSrchNotFound)
    {
        u16DiffAddrFreePtr=getDiffAddrOffset(u16SrchRst);

        for(uDiffOfst=0; uDiffOfst<gDiffBitMapOfst; uDiffOfst++)
        {
            for(uIdx=0; uIdx<16; uIdx++)
            {
                if(mChkBitMask(g16arDiffAddr[getDiffAddrOffset(u16SrchRst)+uDiffOfst], uIdx))
                {
                    u16DiffAddrFreePtr++;
                }
            }
        }

        u16DiffAddrFreePtr+=gDiffBitMapOfst;
    }

    u16SrchRst=gsProgFailInfo.u16FBlock;

    if(g16arDiffOffset[u16SrchRst]==0xffff)
    {
        u32OrgDiffBitMap=0;
    }
    else
    {
        u32OrgDiffBitMap=(LWORD)g16arDiffAddr[getDiffAddrOffset(u16SrchRst)];

        if(gDiffBitMapOfst==2)
        {
            u32OrgDiffBitMap|=(LWORD)(g16arDiffAddr[getDiffAddrOffset(u16SrchRst)+1]<<16);
        }
    }

    g16arDiffAddr[u16DiffAddrFreePtr]=0;

    if(gDiffBitMapOfst==2)
    {
        g16arDiffAddr[u16DiffAddrFreePtr+1]=0;
    }

    while(uPlaneIdx<gPlaneNum)
    {
        uIdx=(uCh*gIntlvWay+uIntlvIdx)*gPlaneNum+uPlaneIdx;
        g16arDiffAddr[u16DiffAddrFreePtr+(uIdx>>4)]|=cb32BitTab[uIdx&0x0F];

        if(gsProgFailInfo.u16PopPfFBlk!=0xFFFF)
        {
            gsProgFailInfo.u16DiffPoolFBlk[uPlaneIdx]=getDiffFBlock(gsProgFailInfo.u16PopPfFBlk, uCh, uIntlvIdx, uPlaneIdx);
        }

        uPlaneIdx++;
    }

    uPlaneIdx=uIdx=uIdx1=0;

    for(uDiffOfst=0; uDiffOfst<gDiffBitMapOfst; uDiffOfst++)
    {
        for(uLoop=0; uLoop<16; uLoop++)
        {
            if(mChkBitMask(g16arDiffAddr[u16DiffAddrFreePtr+uDiffOfst], uLoop))
            {
                g16arDiffAddr[u16DiffAddrFreePtr+gDiffBitMapOfst+uIdx]=gsProgFailInfo.u16DiffPoolFBlk[uPlaneIdx];
                uPlaneIdx++;
                uIdx++;

                if(mChkBitMask(u32OrgDiffBitMap, uLoop))
                {
                    uIdx1++;
                }
            }
            else if(mChkBitMask(u32OrgDiffBitMap, uLoop))
            {
                g16arDiffAddr[u16DiffAddrFreePtr+gDiffBitMapOfst+uIdx]=
                    g16arDiffAddr[getDiffAddrOffset(u16SrchRst)+gDiffBitMapOfst+uIdx1];
                g16arDiffAddr[u16DiffAddrFreePtr+uDiffOfst]|=cb32BitTab[uLoop&0x0F];
                uIdx++;
                uIdx1++;
            }
        }

        u32OrgDiffBitMap>>=16;
    }

    g16arDiffOffset[u16SrchRst]=u16DiffAddrFreePtr;
    (*(BYTE *)&g16arDiffOffset[(g16TotalFBlock+(gTotalIntlvChPlaneNum*2))+2])++;    // update diff counter
}    /* updateDiffAddrTab */

void updateDiffPoolTab(WORD u16SbufPtr)
{
    BYTE uCh, uIntlv, uPlaneAddr, uIdx, uNum;
    WORD *u16DiffBlkPtr=(WORD *)(c32Tsb0SAddr+(u16SbufPtr<<9));

    for(uPlaneAddr=0; uPlaneAddr<gPlaneNum; uPlaneAddr++)
    {
        uIdx=(gsProgFailInfo.uCh*gIntlvWay+gsProgFailInfo.uIntlv)*gPlaneNum+uPlaneAddr;
        uNum=garRtDiffPoolPtr[uIdx];

        while(u16DiffBlkPtr[uIdx*gDiffType3Num+uNum]!=0xFFFF)
        {
            u16DiffBlkPtr[uIdx*gDiffType3Num+uNum]=0xFFFF;
            uNum++;

            if(uNum>=gDiffType3Num)
            {
                break;
            }
        }
    }

    while(gsProgFailInfo.uPopPfFBlkCnt)
    {
        gsProgFailInfo.uPopPfFBlkCnt--;

        for(uCh=0; uCh<gTotalChNum; uCh++)
        {
            for(uIntlv=0; uIntlv<gIntlvWay; uIntlv++)
            {
                if((uCh!=gsProgFailInfo.uCh)||(uIntlv!=gsProgFailInfo.uIntlv))
                {
                    for(uPlaneAddr=0; uPlaneAddr<gPlaneNum; uPlaneAddr++)
                    {
                        uIdx=(uCh*gIntlvWay+uIntlv)*gPlaneNum+uPlaneAddr;
                        uNum=++garRtDiffPoolPtr[uIdx];

                        if(uNum<gDiffType3Num)
                        {
                            u16DiffBlkPtr[uIdx*gDiffType3Num+uNum-1]=getDiffFBlock(
                                gsProgFailInfo.u16SparePoolFBlk[gsProgFailInfo.uPopPfFBlkCnt],
                                uCh,
                                uIntlv,
                                uPlaneAddr);
                        }
                    }
                }
            }
        }

        mSetPoppedBit(gsProgFailInfo.u16SparePoolFBlk[gsProgFailInfo.uPopPfFBlkCnt]);
        mSetGlobEraseCnt(gsProgFailInfo.u16SparePoolFBlk[gsProgFailInfo.uPopPfFBlkCnt], c16BitFF);
    }
}    /* updateDiffPoolTab */

void reprogH2fTable(BYTE uPfCh)
{
    ADDRINFO usTmpAddrInfo;
    WORD u16SbufPtr, u16FreePagePtr;
    BYTE uH2FTabNum, uPageOfst;

    uH2FTabNum=gsProgFailInfo.uProgH2fCnt;
    u16FreePagePtr=gsCacheInfo.u16H2fTabFreePagePtr;

    while(uH2FTabNum)
    {
        uH2FTabNum--;
        gsCacheInfo.u16H2fTabFreePagePtr--;

        for(uPageOfst=0; uPageOfst<gPage4kPerH2fTab; uPageOfst+=g4kNumPerPage)
        {
            setWriteDes(uPageOfst, &usTmpAddrInfo, cWriteH2fTab);

            if((usTmpAddrInfo.uCh==uPfCh)&&(usTmpAddrInfo.u16FPage>gsProgFailInfo.u16FPage))
            {
                /// prog dummy page !!!!
                setFLAddrActCh(uPfCh, &usTmpAddrInfo);
                gSectorH=0;
                gPlaneCnt=gPlaneNum;
                mSetTabSpr(gpFlashAddrInfo, cBit6);
                mSetFRwParam(c16Tsb0SIdx, gSectorPerPageH, c16Bit0|c16Bit2|c16Bit15, cErrHdlDummyProg);

                if((gSparePtrHead[gActiveCh]&(cSpareRegisterCnt-1))<4)
                {
                    rmSelSprGroup(0);
                }
                else
                {
                    rmSelSprGroup(1);
                }

                setSprByteOfTabBlk(cH2fTableID,
                                   c16Null,
                                   gsCacheInfo.u16H2fTabFreePagePtr,
                                   gsCacheInfo.uActH2fTabBlkIdx,
                                   gsCacheInfo.u32H2fTabBlkSerial,
                                   gSparePtrHead[gActiveCh]&3,
                                   cInhandleProgramFail_00);
                flashProgPage(mGetWriteBuf, mGetProgSctrCnt, mGetWriteOpt);
                setBzInfo(gOpTyp, uPfCh, gIntlvAddr);
                gsRwCtrl.usWaitInfo[uPfCh][gIntlvAddr].uStatusErrStop=0;    // 1;

                waitChCeBz(uPfCh, gIntlvAddr, 0);
                mWaitCmdFifoBz;
                // chkStatusFail(uPfCh);

                gsProgFailInfo.u16Hblock[uH2FTabNum]|=c16Bit15;    // Need HTab re-porg !!
            }
        }
    }

    gsCacheInfo.u16H2fTabFreePagePtr=u16FreePagePtr;

    for(uH2FTabNum=0; uH2FTabNum<gsProgFailInfo.uProgH2fCnt; uH2FTabNum++)
    {
        if(gsProgFailInfo.u16Hblock[uH2FTabNum]&c16Bit15)
        {
            u16SbufPtr=gsProgFailInfo.u16SbufPtr[uH2FTabNum];

            if(rm32BufStatus((u16SbufPtr+cRaidHTabTotalSctrCnt)>>5)==0xFFFFFFFF)
            {
                rmSetBuf32Sts((u16SbufPtr+cRaidHTabTotalSctrCnt)>>5, 0xFFFFFFFF);
            }

            mSetCacheInfoChangeFlag(cH2fChg);
            progH2fTable(u16SbufPtr,
                         gsProgFailInfo.u16Hblock[uH2FTabNum]&c15BitFF,
                         c16Bit0|c16Bit2,
                         cInhandleProgramFail_00,
                         cInBootWaitAllDie);
        }
    }
}    /* reprogH2fTable */

void progUpdDiffAddrTab(BYTE uCh, BYTE uIntlvIdx, BYTE uPlaneIdx)
{
    WORD u16SbufPtr=c16PfMoveDataSIdx;

    updateDiffAddrTab(uCh, uIntlvIdx, uPlaneIdx);

    if(gsTskFifoCtrl.usProgH2fPara.uWaitChBitMap)
    {
        reprogH2fTable(uCh);
    }

    while(gsRwCtrl.usSrcCmdList.u16Cnt)
    {
        trigFlCmdFfStep2();
    }

    readWproPage(cWproBadInfo, u16SbufPtr, 0);
    updateDiffPoolTab(u16SbufPtr+gSectorPerPlaneH+cDiffMixTableHalfKb);
    bopCopyRam(c32Tsb0SAddr+((u16SbufPtr+gSectorPerPlaneH)<<9), (LWORD)g16arTotalDiffAddr, cTotalDiffAddrTableSize, cCopyCpu1Dccm2Tsb|cBopWait);
    progWproPage(cWproBadInfo, u16SbufPtr);
    saveIndexBlock();
}    /* progUpdDiffAddrTab */

void chkRaidParityInBuf(BYTE uType)
{
    WORD u16BufPtr=c16ParitySIdx;

    if(uType==cBakParity)
    {
        mClrProgFailFlag(cPfRaidEngTemp);

        if(rm32BufStatus(u16BufPtr>>5))
        {
            hdmaEncRam(u16BufPtr, cRaidDataSctrNum, 0, cHdmaWait|cHdmaTsbFlag, cRaidEngTemp, cSLC);
            mSetProgFailFlag(cPfRaidEngTemp);
        }
    }
    else
    {
        if(mChkProgFailFlag(cPfRaidEngTemp))
        {
            hdmaGetRaidPty(u16BufPtr, cHdmaWait|cHdmaTsbFlag, cRaidPtyClr|cRaidEngTemp, 0, cSLC);
        }
    }
}    /* chkRaidParityInBuf */

void movePfChPageData()
{
    ADDRINFO usTmpAddrInfo;
    WORD u16FPage, u16SbufPtr;
    BYTE uCh, uIntlvAddr, uPlaneAddr, uReProgPtr, uPfProgFifoPtr;
    BLKSPRINFO usBlkSprInfo[cPfSprAll];

    uCh=gsProgFailInfo.uCh;
    uIntlvAddr=gsProgFailInfo.uIntlv;
    usTmpAddrInfo.u16AbstractFBlock=usTmpAddrInfo.u16FBlock=gsProgFailInfo.u16FBlock;
    usTmpAddrInfo.uCh=uCh;
    usTmpAddrInfo.uIntlvAddr=uIntlvAddr;
    usTmpAddrInfo.uCe=(BYTE)mGetCEAddr(uIntlvAddr);
    usTmpAddrInfo.uDieAddr=mGetDieAddr(uIntlvAddr);
    usTmpAddrInfo.uSectorH=0;

    mClrCacheInfoFlag(cMoveProgramFail);
    chkRaidParityInBuf(cBakParity);

#if _EN_PROGFAILRECOV
    for(uPlaneAddr=0; uPlaneAddr<gPlaneNum; uPlaneAddr++)
    {
        usTmpAddrInfo.u16FPage=gsProgFailInfo.u16FPage;

        if(gsProgFailInfo.uFailedStatus&(cBit2|cBit3))
        {
            usTmpAddrInfo.u16BufPtr=c16PfRecovCurSIdx+(uPlaneAddr*gSectorPerPlaneH);
            recovPfPageData(&usTmpAddrInfo, uPlaneAddr, cCurrPage);
            getSprByte(&usBlkSprInfo[cPfSprRecovCur+uPlaneAddr], uPlaneAddr);

            if(gsProgFailInfo.uFailedStatus&cBit3)
            {
                usTmpAddrInfo.u16BufPtr=c16PfRecovPreSIdx+(uPlaneAddr*gSectorPerPlaneH);
                usTmpAddrInfo.u16FPage--;
                recovPfPageData(&usTmpAddrInfo, uPlaneAddr, cPrevPage);
                getSprByte(&usBlkSprInfo[cPfSprRecovPre+uPlaneAddr], uPlaneAddr);
            }
        }
    }
#endif/* if _EN_PROGFAILRECOV */

    do
    {
#if _EN_PROGFAILRECOV
        u16SbufPtr=c16PfMoveDataSIdx;
#else
        u16SbufPtr=c16PfRecovPreSIdx;
#endif

        if(mChkCacheInfoFlag(cMoveProgramFail))
        {
            setFLActCh(uCh);
            rmChSoftReset;
            mWaitCmdFifoBz;

            if(gsProgFailInfo.u16PopPfFBlk!=0xFFFF)
            {
                usTmpAddrInfo.u16AbstractFBlock=gsProgFailInfo.u16PopPfFBlk;
                setPfBadBlock(&usTmpAddrInfo, cProgFailReProgID);
            }

            mClrCacheInfoFlag(cMoveProgramFail);
        }

        if(initPfFblkProc(u16SbufPtr))
        {
            mSetCacheInfoFlag(cMoveProgramFail);
            continue;
        }

        for(uPlaneAddr=0; uPlaneAddr<gPlaneNum; uPlaneAddr++)
        {
#if _EN_PROGFAILRECOV
            u16SbufPtr=c16PfMoveDataSIdx;
#else
            u16SbufPtr=c16PfRecovPreSIdx;
#endif

            for(u16FPage=0; u16FPage<=gsProgFailInfo.u16FPage; u16FPage++)
            {
                gpFlashAddrInfo=&usTmpAddrInfo;
                g16AbstrFBlock=g16FBlock=gsProgFailInfo.u16FBlock;
                g16FPage=u16FPage;
                gCh=uCh;
                gIntlvAddr=uIntlvAddr;
                gCe=(BYTE)mGetCEAddr(uIntlvAddr);
                gDieAddr=mGetDieAddr(uIntlvAddr);
                gPlaneAddr=uPlaneAddr;
                gSectorH=0;

#if !_EN_PROGFAILRECOV
                if((u16FPage==gsProgFailInfo.u16FPage)||((u16FPage==(gsProgFailInfo.u16FPage-1))&&(gsProgFailInfo.uFailedStatus&cBit3)))
                {
                    if(mChkProgFailFlag(cPfCacheBlk))
                    {
                        setMarkBadBlock(gpFlashAddrInfo, cProgFailSLCID);
                    }
                }
#else
                if((u16FPage==(gsProgFailInfo.u16FPage-1))&&(gsProgFailInfo.uFailedStatus&cBit3))
                {
                    u16SbufPtr=c16PfRecovPreSIdx+(uPlaneAddr*gSectorPerPlaneH);
                    copyCcmVal((BYTE *)&usBlkSprInfo[cPfSprActive], (BYTE *)&usBlkSprInfo[cPfSprRecovPre+uPlaneAddr], sizeof(BLKSPRINFO));

                    if(mChkProgFailFlag(cPfCacheBlk))
                    {
                        setMarkBadBlock(gpFlashAddrInfo, cProgFailSLCID);
                    }
                }
                else if(u16FPage==gsProgFailInfo.u16FPage)
                {
                    u16SbufPtr=c16PfRecovCurSIdx+(uPlaneAddr*gSectorPerPlaneH);
                    copyCcmVal((BYTE *)&usBlkSprInfo[cPfSprActive], (BYTE *)&usBlkSprInfo[cPfSprRecovCur+uPlaneAddr], sizeof(BLKSPRINFO));

                    if(mChkProgFailFlag(cPfCacheBlk))
                    {
                        setMarkBadBlock(gpFlashAddrInfo, cProgFailSLCID);
                    }
                }
                else
#endif/* if !_EN_PROGFAILRECOV */
                {
                    setFLAddrActCh(uCh, &usTmpAddrInfo);    // setFLActCh(uCh);
                    mSetFRwParam(u16SbufPtr, gSectorPerPlaneH, c16Bit4, cMoveReadData);
                    waitChCeBz(uCh, uIntlvAddr, 0);

                    if(u16FPage==gsProgFailInfo.u16FPage)
                    {
                        NLOG(cLogCore1, PROGFAIL_C, 1, "movePfChPageData()->1.flashReadPage() Data only _ g16RwOpt=0x%04X", g16RwOpt);
#if _DEBUG_LOG
                        printNandPhyAddr(gpFlashAddrInfo);
#endif
                    }

                    flashReadPage();

                    // RAID DECODE will change gpFlashAddrInfo, so need reset "gpFlashAddrInfo" to usTmpAddrInfo
                    // NLOG(cLogCore1, PROGFAIL_C, 1, "movePfChPageData()->2.flashReadPage()_g16RwOpt=0x%04X", g16RwOpt);
                    // printNandPhyAddr(gpFlashAddrInfo);

                    setFLAddrActCh(uCh, &usTmpAddrInfo);
                    setBzInfo(gOpTyp, uCh, uIntlvAddr);
                    mSetFRwParam(u16SbufPtr, gSectorPerPlaneH, c16Bit5, cReadData);
                    waitChCeBz(uCh, uIntlvAddr, 0);

                    if(u16FPage==gsProgFailInfo.u16FPage)
                    {
                        NLOG(cLogCore1, PROGFAIL_C, 1, "movePfChPageData()->3.flashReadPage()Spr Only _ g16RwOpt=0x%04X", g16RwOpt);
#if _DEBUG_LOG
                        printNandPhyAddr(gpFlashAddrInfo);
#endif
                    }

                    flashReadPage();
                    setBzInfo(gOpTyp, uCh, uIntlvAddr);
                    gsRwCtrl.usWaitInfo[uCh][uIntlvAddr].uStatusErrStop=0;
                    getSprByte(&usBlkSprInfo[cPfSprActive], uPlaneAddr);
                }

                setFLAddrActCh(uCh, &usTmpAddrInfo);    // setFLActCh(uCh);
                g16AbstrFBlock=g16FBlock=gsProgFailInfo.u16PopPfFBlk;
                g16FPage=u16FPage;
                gCh=uCh;
                gIntlvAddr=uIntlvAddr;
                gCe=(BYTE)mGetCEAddr(uIntlvAddr);
                gDieAddr=mGetDieAddr(uIntlvAddr);
                gPlaneAddr=uPlaneAddr;
                gSectorH=0;
                mSetTabSpr(gpFlashAddrInfo, cBit5);
                // setFLActCh(uCh);
                mSetFRwParam(u16SbufPtr, gSectorPerPlaneH, c16Bit2|c16Bit15, cReProgData);
                usBlkSprInfo[cPfSprActive].u16Spr8.us2BYTE.HighByte=cReProgData;
                setSprByte(&usBlkSprInfo[cPfSprActive], uPlaneAddr);
                waitChCeBz(uCh, uIntlvAddr, 0);

                if(u16FPage==gsProgFailInfo.u16FPage)
                {
                    NLOG(cLogCore1, PROGFAIL_C, 1, "movePfChPageData()->4.flashProgPage()_g16RwOpt=0x%04X", g16RwOpt);
#if _DEBUG_LOG
                    printNandPhyAddr(gpFlashAddrInfo);
#endif
                }

                flashProgPage(mGetWriteBuf, mGetProgSctrCnt, mGetWriteOpt);
                setBzInfo(gOpTyp, uCh, uIntlvAddr);
                gsRwCtrl.usWaitInfo[uCh][uIntlvAddr].uStatusErrStop=1;

                if(mChkCacheInfoFlag(cMoveProgramFail))
                {
                    NLOG(cLogCore1, PROGFAIL_C, 2, "MoveProgramFail!!! gsCacheInfo.u32CacheInfoFlag= : 0x%08X ",
                         (gsCacheInfo.u32CacheInfoFlag>>16), (gsCacheInfo.u32CacheInfoFlag));
                    break;
                }
            }
        }

        chkRaidParityInBuf(cResParity);

        for(uReProgPtr=0; uReProgPtr<gsProgFailInfo.uReProgCnt; uReProgPtr++)
        {
            uPfProgFifoPtr=gsProgFailInfo.uarPfProgFifoPtr[uReProgPtr];
            gpFlashAddrInfo=&garDesAddrInfo[uPfProgFifoPtr];

            if(g16FBlock==gsProgFailInfo.u16FBlock)
            {
                g16AbstrFBlock=g16FBlock=gsProgFailInfo.u16PopPfFBlk;
            }

            gPlaneAddr=0;
            gSectorH=0;
            setFLActCh(uCh);
            waitChCeBz(uCh, uIntlvAddr, 0);
            setSprByteOfDataBlk(uPfProgFifoPtr);

            NLOG(cLogCore1,
                 PROGFAIL_C,
                 3,
                 "uReProgPtr: %04D, uReProgCnt: %04D, uPfProgFifoPtr: %04D",
                 uReProgPtr,
                 gsProgFailInfo.uReProgCnt,
                 uPfProgFifoPtr);
#if _DEBUG_LOG
            printNandPhyAddr(gpFlashAddrInfo);
#endif
            flashProgPage(mGetWriteBuf, mGetProgSctrCnt, mGetWriteOpt);
            gSpareCnt[uCh]-=mGetSprUseCnt(gpFlashAddrInfo);
            setBzInfo(gOpTyp, uCh, uIntlvAddr);
            gsRwCtrl.usWaitInfo[uCh][uIntlvAddr].uStatusErrStop=1;

            waitChCeBz(uCh, uIntlvAddr, 0);
            // waitCmdFifoDpt(uCh, gpFlashAddrInfo);

            while(rmChkCmdFifoBz)
            {
#if _EN_WRHWPRDCORE1
                if(gsPrdInfo.u32TrigWrCmdTail!=gsPrdInfo.u32TrigWrCmdTrig)
                {
                    setHwPrdCore1();
                }
#endif
            }

            if(mChkCacheInfoFlag(cMoveProgramFail))
            {
                WORD u16BufIdx=(mGetWriteBuf>>5);
                BYTE uCnt=(mGetProgSctrCnt>>5);

                while(uCnt)
                {
                    rmSetBuf32Sts(u16BufIdx, 0xFFFFFFFF);
                    u16BufIdx++;
                    uCnt--;
                }

                break;
            }
        }

        waitAllChCeBz();

        if(mChkCacheInfoFlag(cMoveProgramFail))
        {
            gsFtlDbg.u16PfB2bCnt++;
        }
    }
    while(mChkCacheInfoFlag(cMoveProgramFail))
    ;

    gsRwCtrl.u32ProgFifoTail=gsProgFailInfo.uLastProgFifoTail;
    progUpdDiffAddrTab(uCh, uIntlvAddr, gsProgFailInfo.uPlaneAddr);
    gsProgFailInfo.uReProgCnt=0;
}    /* movePfChPageData */

BYTE chkPfChPageRead()
{
    BYTE uCh, uIntlvAddr, uPlaneAddr, uReProgPtr, uPfProgFifoPtr;
    WORD u16FPage, u16SbufPtr;
    ADDRINFO usTmpAddrInfo;

    uCh=gsProgFailInfo.uCh;
    uIntlvAddr=gsProgFailInfo.uIntlv;
    u16SbufPtr=c16PfRecovPreSIdx;

    NLOG(cLogCore1,
         PROGFAIL_C,
         3,
         "chkPfChPageRead() Debug info, gsProgFailInfo.u16FBlock: 0x%04X, gsProgFailInfo.u16FPage: 0x%04X, gsProgFailInfo.uReProgCnt: 0x%04X",
         gsProgFailInfo.u16FBlock,
         gsProgFailInfo.u16FPage,
         gsProgFailInfo.uReProgCnt);

    for(uPlaneAddr=0; uPlaneAddr<gPlaneNum; uPlaneAddr++)
    {
        for(u16FPage=0; u16FPage<=gsProgFailInfo.u16FPage; u16FPage++)
        {
            gpFlashAddrInfo=&usTmpAddrInfo;
            g16AbstrFBlock=g16FBlock=gsProgFailInfo.u16FBlock;
            g16FPage=u16FPage;
            gCh=uCh;
            gIntlvAddr=uIntlvAddr;
            gCe=(BYTE)mGetCEAddr(uIntlvAddr);
            gDieAddr=mGetDieAddr(uIntlvAddr);
            gPlaneAddr=uPlaneAddr;
            gSectorH=0;

            setFLAddrActCh(uCh, &usTmpAddrInfo);    // setFLActCh(uCh);
            mSetFRwParam(u16SbufPtr, gSectorPerPlaneH, c16Bit4, cChkFakeSlcProgramFail);
            waitChCeBz(uCh, uIntlvAddr, 0);
            flashReadPage();

            if(mChkBitMask(gPlaneUNCSts[uCh], gPlaneAddr)||mChkBitMask(gPlaneCorrSts[uCh], gPlaneAddr))
            {
                NLOG(cLogCore1, PROGFAIL_C, 2, "chkPfChPageRead() Data Fail, FPage: 0x%04X, Plane: 0x%04X", u16FPage, uPlaneAddr);
                return cTrue;
            }

            setFLAddrActCh(uCh, &usTmpAddrInfo);
            setBzInfo(gOpTyp, uCh, uIntlvAddr);
            mSetFRwParam(u16SbufPtr, gSectorPerPlaneH, c16Bit5, cChkFakeSlcProgramFail);
            waitChCeBz(uCh, uIntlvAddr, 0);
            flashReadPage();
            setBzInfo(gOpTyp, uCh, uIntlvAddr);
            gsRwCtrl.usWaitInfo[uCh][uIntlvAddr].uStatusErrStop=0;

            if(mChkBitMask(gPlaneUNCSts[uCh], gPlaneAddr)||mChkBitMask(gPlaneCorrSts[uCh], gPlaneAddr))
            {
                NLOG(cLogCore1, PROGFAIL_C, 2, "chkPfChPageRead() Spare Fail, FPage: 0x%04X, Plane: 0x%04X", u16FPage, uPlaneAddr);
                return cTrue;
            }
        }
    }

    for(uReProgPtr=0; uReProgPtr<gsProgFailInfo.uReProgCnt; uReProgPtr++)
    {
        uPfProgFifoPtr=gsProgFailInfo.uarPfProgFifoPtr[uReProgPtr];
        gpFlashAddrInfo=&garDesAddrInfo[uPfProgFifoPtr];
        gPlaneAddr=0;
        gSectorH=0;
        setFLActCh(uCh);
        waitChCeBz(uCh, uIntlvAddr, 0);
        setSprByteOfDataBlk(uPfProgFifoPtr);
        flashProgPage(mGetWriteBuf, mGetProgSctrCnt, mGetWriteOpt);
        gSpareCnt[uCh]-=mGetSprUseCnt(gpFlashAddrInfo);
        setBzInfo(gOpTyp, uCh, uIntlvAddr);
        gsRwCtrl.usWaitInfo[uCh][uIntlvAddr].uStatusErrStop=1;
        waitChCeBz(uCh, uIntlvAddr, 0);

        while(rmChkCmdFifoBz)
        {
#if _EN_WRHWPRDCORE1
            if(gsPrdInfo.u32TrigWrCmdTail!=gsPrdInfo.u32TrigWrCmdTrig)
            {
                setHwPrdCore1();
            }
#endif
        }

        if(mChkCacheInfoFlag(cMoveProgramFail))
        {
            WORD u16BufIdx=(mGetWriteBuf>>5);
            BYTE uCnt=(mGetProgSctrCnt>>5);

            while(uCnt)
            {
                rmSetBuf32Sts(u16BufIdx, 0xFFFFFFFF);
                u16BufIdx++;
                uCnt--;
            }

            NLOG(cLogCore1, PROGFAIL_C, 2, "chkPfChPageRead() ReProg Fail, FPage: 0x%04X, ProgFifoPtr: 0x%04X", u16FPage, uPfProgFifoPtr);
            return cTrue;
        }
    }

    gsRwCtrl.u32ProgFifoTail=gsProgFailInfo.uLastProgFifoTail;
    gsProgFailInfo.uReProgCnt=0;
    NLOG(cLogCore1, PROGFAIL_C, 0, "chkPfChPageRead() Pass");

    return cFalse;
}    /* chkPfChPageRead */







