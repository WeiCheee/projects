







#include "inc/DebugLog.h"
#include "inc/EventLogIDX.h"
#include "inc/EventLogFunctionIDX.h"
#include "inc/ProType.h"
// #include "inc/FlashCtrl.h"
#include "inc/GlobVar0.h"
#include "inc/Const.h"
#include "inc/GlobVarS.h"
#include "inc/GlobVarT.h"
#include "inc/Reg.h"
#include "inc/FtlCtrl.h"
#include "inc/Mac.h"
#include "inc/BitDef.h"

void nvmeFlush()
{
    LWORD u32NsId=rmNvmeNsId;
    WORD u16CommandStatus=cStatusSuccess;

    NLOG(cLogHost, NVMEIOCMD_C, 0, " NVMe Flush Cmd ");

    if(u32NsId==cNamespaceAll)
    {
        if(((gsLightSwitch.usNvmeLs.uVwc>>1)&0x03)==cFlushBcNsidNotSupport)
        {
            u16CommandStatus=cStatusInvalidField;
        }
    }
    else if((u32NsId==cNamespaceNotSpecific)||(u32NsId>gsLightSwitch.usNvme2Ls.u32NamespaceNum))
    {
        u16CommandStatus=cStatusInvalidNsFormat;
    }
    else if(!(gsNamespace.uActiveBitMap&cbBitTab[u32NsId-1]))
    {
        u16CommandStatus=cStatusInvalidField;
    }

    manualCompletion(u16CommandStatus, 0, cNoRwCmd, 0);
}    /* nvmeFlush */

void nvmeWriteZero()
{
    LWORD u32NsId=rmNvmeNsId;
    WORD u16CommandStatus=cStatusSuccess;

    if(cCrcCheckEn)    // Oscar_20190311
    {
        gsWUNCInfo.uWZeroFlag=1;
    }

    NLOG(cLogHost, NVMEIOCMD_C, 1, " NVMe WZERO Cmd, Wzeroflag=0x%04X ", gsWUNCInfo.uWZeroFlag);

    if(gsWUNCInfo.uWZeroFlag)
    {
        bopCopyRam(((LWORD)garTsb0[0]), (LWORD)&gsWUNCInfo, sizeof(gsWUNCInfo), cCopyStcm2Tsb|cBopWait);
        progWproPageCore0(cWproWriteUNC, c16Tsb0SIdx);
    }

    if(gsLightSwitch.usNvmeLs.uOncs&cWriteZeroesCommand)
    {
        // Don't need check Nlb>Mdts case because there isn't data xfer
        if((u32NsId==cNamespaceNotSpecific)||(u32NsId>gsLightSwitch.usNvme2Ls.u32NamespaceNum)||
           (!(gsNamespace.uActiveBitMap&cbBitTab[u32NsId-1])))
        {
            u16CommandStatus=(cStatusMore|cStatusInvalidNsFormat);    // WD Jira-87
        }
        else if(rmNvmeWriteZerosPrInfo)
        {
            u16CommandStatus=(cStatusDoNotRetry|cStatusInvalidField);    // 20190503_SamHu_01 IOL 10.0d fail, sync CA5
        }
        else
        {
            u16CommandStatus=chkLbaRange(rmNvmeWriteZerosSLbaHigh, rmNvmeWriteZerosSLbaLow, rmNvmeWriteZerosNlb, u32NsId, cNvmeCmdWriteZero);
        }

        if(u16CommandStatus)
        {
            manualCompletion(u16CommandStatus, 0, cNoRwCmd, 0);
        }
        else
        {
            enableLdpcPipe();
            processTrim(cNvmeCmdWriteZero);
            disableLdpcPipe();
        }
    }
    else
    {
        manualCompletion(cStatusInvalidOpCode, 0, cNoRwCmd, 0);
    }
}    /* nvmeWriteZero */







