







#include "inc/DebugLog.h"
#include "inc/EventLogIDX.h"
#include "inc/EventLogFunctionIDX.h"
#include "inc/ArmCp15.h"
#include "inc/Asm.h"
#include "inc/BitDef.h"
#include "inc/Const.h"
#include "inc/FtlCtrl.h"
#include "inc/GlobVar0.h"
#include "inc/GlobVarS.h"
#include "inc/GlobVarT.h"
#include "inc/Mac.h"
#include "inc/NvmeCtrl.h"
#include "inc/Option.h"
#include "inc/ProType.h"
#include "inc/Reg.h"
#include "inc/Table.h"
#include "inc/TypeDef.h"
#include "inc/GreyBox.h"
#include "Common/Model.h"

// #include "inc/Rdlink.h"

#include "Bop.c"
#include "Hdma.c"
#include "Isr0.c"
#include "TaskFuncForMain.c"
#include "FtlComFunc.c"
#include "NvmeCmd.c"
#include "NvmeCtrl.c"
#include "PhyCtrl.c"
#include "PowerState.c"
#include "PrdMgr.c"
#include "StbLib.c"
#include "SysCtrl.c"
#include "Table.c"
#include "RdlinkVar.c"
#include "FlashPub.c"
#include "DebugLog.c"
// #include "Core0TempInvFunc.c"
// #include "BootFshCmdHS.c"
#include "FlashCtrl.c"
#include "FtlPub.c"
// #include "InitDRAM.c"

#if _ENABLE_SECAPI
extern volatile funcptr_st SFP;
#endif

#if (!_ICE_LOAD_ALL)
#pragma default_function_attributes = @ ".CORE0_MAIN"
#endif
void saveQBInfowithDummyCore0(BYTE uFailType)
{
    if(mChkDummyWrite)
    {
        return;
    }

    if((uFailType!=0xFF)&&!mChkunSaveDummyInfo)
    {
        gsFtlDbg.u16DummyFailType=uFailType;
    }

    g32Rtc32kStartVal=getRtcCurrent32k();

    while(!chkRtc32kTimeout(c32PartialCleanRtc100ms))
        ;

#if 0

    if(rmAllFreezeBusy)
    {
        setSelMulFL(1);
        rmChSoftReset;
        setSelMulFL(0);
        resetAllFlashCore0();
    }
#endif
    gsCacheInfo.ubEnDualCoreFlush=cFalse;
    bopClrRam((LWORD)0x40000000, 384*1024, 0x00000000, cBopWait|cClrTsb);
    gPowerDownMode=cGSD;
    g16BkWriteBufPtr=g16WriteBufPtr;
    g16BkFlashWBufPtr=g16FlashWBufPtr;
    /*
       * bopCopyRam(((LWORD)garTsb0[0])+c32HMBInfoVarAddr, (LWORD)&gsHmbInfo, sizeof(gsHmbInfo), cCopyDccm2Tsb|cBopWait);
       * bopCopyRam(((LWORD)garTsb0[0])+c32SrcInCacheFlagAddr, (LWORD)&g32arSrcInCacheFlag, sizeof(g32arSrcInCacheFlag),
       *         cCopyDccm2Tsb|cBopWait);
       * bopCopyRam(((LWORD)garTsb0[0])+c32DebugInfoAddr, (LWORD)&gsDebugInfo, sizeof(gsDebugInfo), cCopyDccm2Tsb|cBopWait);
       * bopCopyRam(((LWORD)garTsb0[0])+c32CmdHistoryAddr, (LWORD)&garCmdHistory, sizeof(garCmdHistory), cCopyDccm2Tsb|cBopWait);
       * bopCopyRam(((LWORD)garTsb0[0])+c32CmdHistoryAddr+0x500, (LWORD)&g16CmdHistoryPtr, sizeof(g16CmdHistoryPtr), cCopyDccm2Tsb|cBopWait);
       * bopCopyRam(((LWORD)garTsb0[0])+c32DummyAddr, (LWORD)&gpFlashAddrInfo, sizeof(gpFlashAddrInfo), cCopyDccm2Tsb|cBopWait);
       */
    progWproPageCore0(cWproQBWithDumyW, c16Tsb0SIdx);

    waitAllChCeBzCore0();
    mClrSaveDummyInfo;
    rmResetRaidFlg;
    rmResetBufFlg;
    rmResetOccupyFlg;
    mSetGcFlag(cBrkBgdGcF);

    while(1)
        ;
}    /* saveQBInfowithDummyCore0 */

void saveQBInfo(BYTE uMode)
{
    // if(((gsSmart.u64PowerOnSec-g64LastTime)>5)&&(!gsQBootInfo.ubQBootValid))
#if (C_Log_SaveMask&C_Debug_P1)
    NLOG(cLogSYS, MAINCORE0_C, 1, "saveQBInfo() Start uMode = 0x%04X", uMode);    // 20181102_Bill
#endif
    {
#if _EN_RAID_GSD

        if((uMode!=cOnPcieErr)&&(uMode!=cDevicePsD3))    // Sync SMI_S0425C,20190507_Eason
        {
            mCallFuncPtr(cfuncSaveParity);
        }
#endif

        while(gsRwCtrl.u32UpdFifoPtr!=gsRwCtrl.u32ProgFifoHead)
            ;

        while(gsHmbInfo.uHmbCache4kCnt)
            ;

        if(uMode==cDevicePs3)
        {
            gsCacheInfo.u32RecRtcTime1s=getRtcDiff1s();
        }
        else
        {
            gsCacheInfo.u32RecRtcTime1s=getRtcDiff1s();
            gsCacheInfo.u32RecEntryPS4RtcStartTime1s=getRtcCurrent1s();
        }

        g16BkWriteBufPtr=g16WriteBufPtr;
        g16BkFlashWBufPtr=g16FlashWBufPtr;
        waitAllChCeBzCore0();
        gPowerDownMode=uMode;
        bopCopyRam(((LWORD)garTsb0[0])+c32HMBInfoVarAddr, (LWORD)&gsHmbInfo, sizeof(gsHmbInfo), cCopyDccm2Tsb|cBopWait);
        bopCopyRam(((LWORD)garTsb0[0])+c32SrcInCacheFlagAddr, (LWORD)&g32arSrcInCacheFlag, sizeof(g32arSrcInCacheFlag), cCopyDccm2Tsb|cBopWait);
#if _GREYBOX

        if((gsGbInfo.uGreyBoxItem==cUGSDProgWPROID)&&(gsGbInfo.uGreyBoxOpt==cVOpProgQboot)&&(gsGbInfo.uStag==cVsIdl))
        {
            trigGreyBox(cTrue);
        }
#endif
#if _EN_VPC_SWAP

        if(gsWproInfo.u16arWproIdxPagePtr[cWproCacheBlkVpCnt]==c16BitFF)
        {
            g32arCacheBlkVpCnt=(volatile LWORD *)(cCacheBlkVpCntQBootStrAddr);
            readWproPageCore0(cWproCacheBlkVpCnt, cCacheBlkVpCntQBootStrIdx, 0);
            progWproPageCore0(cWproCacheBlkVpCnt, cCacheBlkVpCntQBootStrIdx);
        }
#endif
        progWproPageCore0(cWproQBootPg, c16Tsb0SIdx);    // codeFuncPtr5[cfuncProgWpro](cWproQBootPg, c16Tsb0SIdx);
        // g64LastTime=gsSmart.u64PowerOnSec;  //gsSmart.u64PowerOnSec may be clear after 1hr
        waitAllChCeBzCore0();
        rstH2F1KInfo();

        while(gsTskFifoCtrl.u32HeadPtr!=gsTskFifoCtrl.u32TailPtr)
            ;// wait flash ready
    }
#if (C_Log_SaveMask&C_Debug_P1)
    NLOG(cLogSYS, MAINCORE0_C, 1, "saveQBInfo() End  uMode = 0x%04X", uMode);    // 20181102_Bill
#endif
}    /* saveQBInfo */

#if _2260PCIE_WORKAROUND
BYTE beforeHandlingCmd()
{
    // disable L1 and L1.2 before sending L0 LTR
    BYTE uEnablL12;

    uEnablL12=disableL12();    // for better performance in RW
    waitPclkRdy();    // force link leave L1/L1.2

    rmSetL1Entry(7);
#if _PHYCHG4_LTR

    if(gLtrEnabled)
    {
        srvLtrSend(0x00);
    }
#endif
    return uEnablL12;
}

void afterHandlingCmd(BYTE uEnablL12)
{
    rmSetL1Entry((gsLightSwitch.usPcieLs.usLinkStateEntranceIdleTime.u32All&0x38000000));    // ubL1EnternaceIdleTime

    if(uEnablL12)
    {
        enableL12();
    }
}

#endif/* if _2260PCIE_WORKAROUND */

BYTE judgeSerial(LWORD u32Serial1, LWORD u32Serial2)
{
    if(u32Serial1==u32Serial2)
    {
        return cSerialEqual;
    }
    else if(u32Serial1>u32Serial2)
    {
        if((u32Serial1-u32Serial2)<c32CacheSerialTH)
        {
            return cSerialLarger;
        }
        else
        {
            return cSerialSmaller;
        }
    }
    else
    {
        if((u32Serial2-u32Serial1)<c32CacheSerialTH)
        {
            return cSerialSmaller;
        }
        else
        {
            return cSerialLarger;
        }
    }
}    /* judgeSerial */

void prog1stInvQBootInWpro()
{
    if(gsQBootInfo.ubQBootValid)
    {
        progWproPageCore0(cWproInvQBootPg, c16Tsb0SIdx);
    }
}

void runTimeKeepSmartInfo()
{
    if(((getRtcCurrentMs()-gsSmart.usStatus.u32KeepSmartRtcTimeStamp)>600000)||gSmartBackup)
    {
        gSmartBackup=0;
        gsSmart.usStatus.u32KeepSmartRtcTimeStamp=getRtcCurrentMs();
        NLOG(cLogSYS, MAINCORE0_C, 0, " Run Time Keep Smart ");
        saveSmartInfo(cReadWpro);
#if ((OEM==VERIFY)||(OEM==STD))

        if(!chkHostIdle(1))
        {
            NLOG(cLogSYS, MAINCORE0_C, 1, " AuxNvmeIdle = 0x%04X(0=cmd don't cpl)", rmChkAuxNvmeIdle);
            NLOG(cLogSYS, MAINCORE0_C, 1, " CqDbMatch = 0x%04X(0=CQ mismatch) ", rmChkCqDbMatch);
            NLOG(cLogSYS, MAINCORE0_C, 1, " CmdRdy = 0x%04X(1=Hw fetch,Fw don't handle) ", rmChkCmdRdy);
        }
        else
        {
            NLOG(cLogSYS,
                 MAINCORE0_C,
                 3,
                 " NvmeCondition = 0x%08X ,UartHold=0x%04X",
                 g32NvmeCondition>>16,
                 g32NvmeCondition,
                 mChkUartHoldActiveMo);
            NLOG(cLogSYS,
                 MAINCORE0_C,
                 3,
                 " SanitizeInProgress = 0x%04X,AsyncEvent= 0x%04X,DstInProgress= 0x%04X ",
                 mChkSanitizeInProgress,
                 pendingAsyncEvent(),
                 chkDstInProgress());
            NLOG(cLogSYS,
                 MAINCORE0_C,
                 3,
                 " gApstPs3ToPs4 = 0x%04X,PsChg= 0x%04X,ShnFlag= 0x%04X ",
                 gApstPs3ToPs4,
                 gsPowerState.uPsChg,
                 gFWShnFlag);
            NLOG(cLogSYS,
                 MAINCORE0_C,
                 3,
                 " IspCodePerEndOffset = 0x%04X,AuthPass= 0x%04X, cc =0x%04X",
                 gsFwDlInfo.u32IspCodePerEndOffset,
                 gsFwDlInfo.uAuthPass, rmChkCcRdy);
        }
#endif /* if ((OEM==VERIFY)||(OEM==STD)) */
    }
} /* runTimeKeepSmartInfo */

void dummyFunc()
{
    _nop();    // while (1);
}

BYTE dummyFunc1()
{
    _nop();    // while (1);

    return 0;
}

void dummyFunc2(BYTE uTemp)
{
    _nop();    // while (1);
}

void dummyFunc3(WORD u16Temp, BYTE uTemp1, BYTE uTemp2)
{
    _nop();    // while (1);
}

#if _GREYBOX
__arm void main() @ ".GREYBOX_ENTRY"
#else
void main()
#endif
{
#if !_INITDRAM
    LWORD u32Time, u32IdleTime, u32IdleState=0;

#if _LOAD_OPROM
    LWORD u32Page;
#endif

#if _2260PCIE_WORKAROUND
    BYTE uEnablL12, uHostExtSync;    // , uDoorbellPatch;
#endif

// #if _EN_RAID_GSD
    BYTE uRestoPty=0;
#if _EN_EarlyBdGC
    LWORD u32EarTimer;
#endif

#if (_EN_PERST_WAKEINLOWPOWER)
    gHandlePerstInIsrForLowPower=0;
#endif
    BYTE uCmd1s=1;
// #endif
#if _EN_WriteZeroNonAlign    // WriteZeroNonAlign_20181031_Chief
    gsWZCnt=0;
#endif

#if _EN_DisHMBInReset    // 20190424_Chief_DisHMB
    gDisHMBCnt_NormalBehavior=0;
    gDisHMBCnt_AbnormalBehavior=0;
    mClrDisHMBCondition;    // 20190424_Bruce_inti for PS4
    g32DisHMBTimer=0;
#endif

#if (!_GREYBOX)
    // codeFuncPtr[cfuncBootFunc]();    // bootFunc();
    mCallFuncPtr(cfuncBootFunc1);
    loadISPCodeCore0(cBoot2Isp, 0);
    mCallFuncPtr(cfuncBootFunc2);
#else
    g32GreyBoxSwapOffset=((LWORD)cSwapCodeSize<<cSingleSectorShift)*(cBootIsp-1);
    mCallFuncPtr(cfuncBootFunc1);
    loadISPCodeCore0(cBoot2Isp, 0);
    mCallFuncPtr(cfuncBootFunc2);
#endif/* if (!_GREYBOX) */

#if (C_Log_SaveMask&C_Debug_P1)    // 20181031_Bill MainCore0 BootTime
    LWORD u32TimeStamp=0;
    u32TimeStamp=getRtcCurrentMs();

    if(gsRdlinkInfo.uResumeFromPs4)
    {
        u32TimeStamp-=g32PS4BootTimeStamp;
    }

    if((u32TimeStamp>=400)&&gsRdlinkInfo.uResumeFromPs4)    // 20190304_Bill
    {
        NLOG(cLogSYS, MAINCORE0_C, 2, "Ps4ResumeTime>=400ms ,Ps4ResumeTime = %08d ms", u32TimeStamp>>16, u32TimeStamp);
    }
    else if(gsRdlinkInfo.uResumeFromPs4)
    {
        NLOG(cLogSYS, MAINCORE0_C, 2, "Ps4ResumeTime = %08d ms", u32TimeStamp>>16, u32TimeStamp);
    }
    else if(u32TimeStamp>=400)
    {
        NLOG(cLogSYS, MAINCORE0_C, 2, "BootTime>=400ms ,BootTime = %08d ms", u32TimeStamp>>16, u32TimeStamp);
    }
    else
    {
        NLOG(cLogSYS, MAINCORE0_C, 2, "BootTime = %08d ms", u32TimeStamp>>16, u32TimeStamp);
    }
#endif/* if (C_Log_SaveMask&C_Debug_P1) */

#if (!_ICE_LOAD_ALL)
#if _GREYBOX
    __flushCache();
    __enableDataCache();
    __enableInstCache();
#endif

    bopClrRam((LWORD)0x40000000, 384*1024, 0xFFFFFFFF, cBopWait|cClrTsb);    // TSB0//256*1024, 0xFFFFFFFF, cBopWait|cClrTsb); //TSB0

    loadISPCodeCore0(cRwIsp, 0);
    bopClrRam((LWORD)0x40000000, 384*1024, 0xFFFFFFFF, cBopWait|cClrTsb);    // TSB0//256*1024, 0xFFFFFFFF, cBopWait|cClrTsb); //TSB0
    forceInvCpu1DCache();
#endif/* if (!_ICE_LOAD_ALL) */

#if _EN_Liteon_ErrHandle

    if(gsCacheInfo.uH2fTabBlockCnt>=(gMaxH2fTabBlkNum*3/4))
    {
        // mPushGcQue(cGcTypH2fTab);
        // mSetGcFlag(cPwOnGcF);
        saveRdTimeStamp(14);
        chkPwrOnForceClnProc();
        saveRdTimeStamp(18);
        mClrGcFlag(cBrkBgdGcF);
        // mClrGcFlag(cPwOnGcF);
        NLOG(cLogGC, MAINCORE0_C, 1, "H2fTabBlockCnt over Threhold, Cnt: 0x%04X ", gsCacheInfo.uH2fTabBlockCnt);
    }
    else
    {
        gJdgBootGCFlag&=~(cBootH2FGC);
    }
#endif

    if(!gsRdlinkInfo.ubPwrOnByQBoot)
    {
        mSetGcFlag(cPwOnGcF);
        saveRdTimeStamp(14);
        chkPwrOnForceClnProc();
        saveRdTimeStamp(18);
        mClrGcFlag(cBrkBgdGcF);
        mClrGcFlag(cPwOnGcF);
#if _EN_FW_DEBUG_UART
        NLOG(cLogGC, MAINCORE0_C, 0, "Set Power On Gc, Spare information:");
        NLOG(cLogGC, MAINCORE0_C, 1, "gsCacheInfo.u16DynamicSpareCnt: 0x%04X ", gsCacheInfo.u16DynamicSpareCnt);
        NLOG(cLogGC, MAINCORE0_C, 1, "gsCacheInfo.u16SLCSpareCnt: 0x%04X ", gsCacheInfo.u16SLCSpareCnt);
        NLOG(cLogGC, MAINCORE0_C, 1, "gsCacheInfo.u16TLCFullCacheBlockCnt: 0x%04X ", gsCacheInfo.u16TLCFullCacheBlockCnt);
        NLOG(cLogGC, MAINCORE0_C, 1, "gsGcInfo.u32GcLeastBudget: 0x%04X ", gsGcInfo.u32GcLeastBudget);
#endif
    }

#if Power_slcQoverflow
#if _EN_VPC_SWAP

    if((g16SlcSortQCnt>(cIOMeterMaxSlcBlkQ-cSLCQ_ExtraGcThrd))&&gsRdlinkInfo.ubPwrOnByQBoot)
#else

    if((g16SlcSortQCnt>(cMaxSlcBlkQ-cSLCQ_ExtraGcThrd))&&gsRdlinkInfo.ubPwrOnByQBoot)
#endif
    {
#if _EN_Liteon_ErrHandle
#if _EN_VPC_SWAP

        if(g16SlcSortQCnt<(cIOMeterMaxSlcBlkQ-2))    // remain 2 SLC blk
#else

        if(g16SlcSortQCnt<(cMaxSlcBlkQ-2))    // remain 2 SLC blk
#endif
        {
            gJdgBootGCFlag&=~(cBootSLCQGC);
        }
#endif
        mSetGcFlag(cPwOnGcF);
        saveRdTimeStamp(14);
        chkPwrOnForceClnProc();
        saveRdTimeStamp(18);
        mClrGcFlag(cBrkBgdGcF);
        mClrGcFlag(cPwOnGcF);
        NLOG(cLogGC, MAINCORE0_C, 1, "SLCQ over Threhold SLCQ Cnt: 0x%04X ", g16SlcSortQCnt);
    }
#endif/* if Power_slcQoverflow */

#if _EN_RAID_GSD
    else
    {
        uRestoPty=1;
    }
#endif

#if _EN_Liteon_ErrHandle

    if(g16SlcSortQCnt<=(cMaxSlcBlkQ-cSLCQ_ExtraGcThrd))
    {
        gJdgBootGCFlag&=~(cBootSLCQGC);
    }
#endif

#if 1    // (S_PS35toPS4DoNotWakeLink)

    if(!rmChkKeepPcieLinkSleep)    // New cmd in, recover link setting
#endif
    {
        rmSetPcieDoNotEnterL1;    // Keep PCIe link in L0
    }

#if _EN_WuncInNand    // WUNCTable Chief_21081121

    if(gsWproInfo.u16arWproIdxPagePtr[cWproWriteUNC]!=c16BitFF)
    {
        BYTE uIdx=0;
        readWproPageCore0(cWproWriteUNC, c16Tsb0SIdx, 0);
        bopCopyRam((LWORD)&gsWUNCInfo, ((LWORD)garTsb0[0]), sizeof(gsWUNCInfo), cCopyTsb2Stcm|cBopWait);

        for(uIdx=0; uIdx<gsWUNCInfo.uWuncCnt; uIdx++)
        {
            NLOG(cLogHost,
                 MAINCORE0_C,
                 4,
                 "uWuncCnt=0x%04X, HBlock=0x%04X, u16HPage=0x%04X, uBitMap=0x%04X",
                 uIdx,
                 gsWUNCInfo.u16HBlock[uIdx],
                 gsWUNCInfo.u16HPage[uIdx],
                 gsWUNCInfo.uBitMap[uIdx]);
            gsWUNCInfo.uWuncCnt=0;
            gsWUNCInfo.u16HBlock[uIdx]=c16BitFF;
            gsWUNCInfo.u16HPage[uIdx]=c16BitFF;
            gsWUNCInfo.uBitMap[uIdx]=0;
        }

        if(gsWUNCInfo.uWuncCnt>C_MaxWUNCLAACnt)
        {
            for(uIdx=0; uIdx<C_MaxWUNCLAACnt; uIdx++)
            {
                gsWUNCInfo.uWuncCnt=0;
                gsWUNCInfo.u16HBlock[uIdx]=c16BitFF;
                gsWUNCInfo.u16HPage[uIdx]=c16BitFF;
                gsWUNCInfo.uBitMap[uIdx]=0;
            }

            NLOG(cLogHost, MAINCORE0_C, 0, "over MaxUNCLAACnt Clr Wunc Table");
        }
    }
#endif/* if _EN_WUNCTable */

    if(rmChkPp)    // 20181213_SamHu_01 after firmware commit activation, the CSTS.PP
    {
        NLOG(cLogBuild, MAINCORE0_C, 0, " rmClrPp ");
        rmClrPp;
    }

    while(1)
    {
#if _ENABLE_SECAPI

        if(gbEnTCG)
        {
            SecAPI_ChkStackOverFlow();
            SecAPI_ChkSessionTimeout();
        }
#endif
#if (_EN_WDT)
        rmResetWdtTimer;
        gWdtTOExtensionCnt=0;
#endif
#if (_EN_CHRONUS_UART_DEBUG)

        if(mChkUartCMDRdy)
        {
            // processing CMD
            nvmeHandleAdmin();
        }
        else if(mChkUartRxRdy)
        {
            loadISPCodeCore0(cUartTsbBank, 2);
            chkUartDebugCmd();
        }

        if(!mChkUartHndShkRdy)
#endif
        {
            if((g32NvmeCondition||gsPowerState.uPsChg||mChkInitPlpScp)&&(!gVuMode))    // Reset or Error handle
            {
#if _2260PCIE_WORKAROUND
                uHostExtSync=setExtSync(cEnabled);    // Gen3 config
#endif
                rmClrNvmeFwRqRdyInt;
                rmClrNvmeDoorBellInt;

                if((mNvmeChkShn&&(gPowerDownMode!=cGSD))||mChkInitPlpScp)
                {
#if _ENABLE_SCP_PLP

                    if(mChkInitPlpScp)
                    {
                        gsFtlDbg.u32PlpScpCompleteCnt++;
                        progCacheInfoTab();    // 20190417_Jesse_01, Save PLP(SCP) Cnt
                    }
#endif
                    NLOG_SAVE(cLogHost, MAINCORE0_C, 0, cSaveIdSafeShutdown, " Host ShutDown notification");
                    tracePcieEvent(0x55);
                    saveEventLog(0);
                    mPSChgClrPs34;
                    g32ApstEnable=0;
                    gLowPowerStateRetryCnt=3;
                    gsSmart.usStatus.u32KeepSmartRtcTimeStamp=getRtcCurrentMs();
                    saveSmartInfo(cReadWpro);
                    saveNvmeFeatInfo(cReadWpro);
                    saveQBInfo(cGSD);
                    mNvmeSetShnEntry;    // for Qboot
#if _EN_DisHMBInReset    // 20190424_Chief_DisHMB
                    gChkFlag|=cPcieSHNState;    // 20190808_Bruce_DisHMB
#endif

#if (C_Log_SaveMask&C_Debug_P1)    // 20181031_Bill MainCore0 ShutDown
                    NLOG(cLogSYS,
                         MAINCORE0_C,
                         4,
                         " SLCSpareBlockCnt = 0x%04X ,TLCSpareBlockCnt = 0x%04X ,SLCFullCacheBlockCnt = 0x%04X ,TLCFullCacheBlockCnt = 0x%04X",
                         gsCacheInfo.u16SLCSpareCnt,
                         gsCacheInfo.u16DynamicSpareCnt,
                         gsCacheInfo.u16FullCacheBlockCnt,
                         gsCacheInfo.u16TLCFullCacheBlockCnt);
                    NLOG(cLogSYS,
                         MAINCORE0_C,
                         4,
                         " ActiveCacheBlock = 0x%04X ,CacheFreePagePtr = 0x%08X ,CacheF2hTabFreePtr = 0x%04X",
                         gsCacheInfo.u16ActiveCacheBlock,
                         gsCacheInfo.u32CacheFreePagePtr>>16,
                         gsCacheInfo.u32CacheFreePagePtr,
                         gsCacheInfo.u16CacheF2hTabFreePtr);
#endif/* if (C_Log_SaveMask&C_Debug_P1) */
                    NLOG(cLogHost, MAINCORE0_C, 0, " Host Shutdown notification End ");
#if _ENABLE_SCP_PLP    // 20190102_Ken_Bill

                    if(mChkInitPlpScp)
                    {
                        mClrGpioInitPlpScp;
                        NLOG(cLogHost, MAINCORE0_C, 3, " Plp/Scp Assert Done! RtcTimeCnt=0x%04X, PlpScpCompleteCnt=%08d",
                             chkRtc32kProcTime(g32arPlpScpTimeStamp), gsFtlDbg.u32PlpScpCompleteCnt>>16, gsFtlDbg.u32PlpScpCompleteCnt&0xffff);
                        rmGpioP20PlpFBackDeAssert;
                    }
#endif
                }

                // disable interrupt to prevent CPU read-modify-write
                __disable_irq();

                if(g32NvmeCondition||gsPowerState.uPsChg)
                {
                    handleNvmeCondition();
                }

                __enable_irq();
#if _2260PCIE_WORKAROUND

                if(!uHostExtSync)
                {
                    // waitPclkRdy();
                    setExtSync(cDisabled);    // Gen3 config
                }
#endif
            }

#if _LOAD_OPROM

            if(gOpRomRead)
            {
                bopClrRam(c32Tsb0SAddr, 0x40000, 0x00000000, cClrTsb|cBopWait);

                for(u32Page=0; u32Page<3; u32Page++)
                {
                    loadInfoPage(gOPRomStrPage, gSectorPerPlaneH, (c16WriteSIdx+(u32Page*gSectorPerPlaneH)), 0, cSysBlock1stInfo, cBit1);
                }

                setBufStatus(c16Tsb0SIdx, 0x200, cTsb0);
                rmClrEpromDpp;
                sysDelay(0x10FFFF);
                setBufStatus(c16Tsb0SIdx, 0x200, cTsb0);
                rmSetEpromDpp;
                gOpRomRead=0;
            }
#endif/* if _LOAD_OPROM */

            chkDphyPatch();

#if _FW_HANDLE_L12

            // L1 time out
            if(!gL1TimeOutEnabled&&gChgtoD0&&(gsLightSwitch.usPcieLs.uL1SubExtCapLs.u32All&0x00000001))
            {
                if(chkEnClkReq())
                {
                    gL1TimeOutEnabled=1;
                    // Sam L1 timeout
                    rmClrL1Timeout;    // clr int
                    rmSetL1TimeoutEn;
                    // Enable L1 time out
                    NLOG(cLogPS, MAINCORE0_C, 0, " L1 time out ");
                }
            }
#endif

            if(gsHmbInfo.uHmbStsChg)    // 20190220_Louis
            {
                enableLdpcPipe();
                // codeFuncPtr[cfuncServRwCmdQue]();    // servRwCmdQue();
                mCallFuncPtr(cfuncServRwCmdQue);
                disableLdpcPipe();
            }

#if _EN_KEEP_RW_ON_ERROR
            else if(gJdgBootGCFlag&cVpcNeedRebuild)    // 20190618_Louis_01
            {
                mCallFuncPtr(cfuncChkVPc);
                gJdgBootGCFlag&=~cVpcNeedRebuild;
                gGCOpt&=~gbGCVpcMismatch;
            }
#endif
            else if((rmChkCmdRdy)&&(rmChkCcRdy))
            {
                disSysTmr();
                u32IdleTime=0;
                gLowPowerStateRetryCnt=0;
                gApstRetryCnt=0;
                mClrHandlePcieRstF;    // gHandlePcieRstInIsr=0;

#if (_RR_WORKAROUND)
                // if(!gFWRQOk)
                // {
                //   HW_ChkFWRQ();
                // }
#endif
                // if(gsLightSwitch.usNvmeLs.uDoorBellPatch)    // if(uDoorbellPatch)
                // {
                //    updateCqMask();
                //    checkDbInvalid();    // CSSD-2086
                // }
#if _2260PCIE_WORKAROUND
                uEnablL12=beforeHandlingCmd();
#endif

#if 1    // (S_PS35toPS4DoNotWakeLink)

                if(rmChkKeepPcieLinkSleep)
                {
                    disPcieLowPwrMo(1);
                    rmClrKeepPcieLinkSleep;    // clear flag
                    rmSetPcieDoNotEnterL1;    // Force link keep in L0
                }
#endif

                if(rmNvmeSqId&&(!gVuMode))
                {
                    // Handle IO cmd must be PS0/1/2
                    gsPowerState.uFeatVal.u32Current&=cPowerStateMaskClr;
                    gsPowerState.uFeatVal.u32Current|=gsPowerState.uHostLastPs;
                    gsPowerState.uDevLastPs=gsPowerState.uDevCurPs;
                    gsPowerState.uDevNextPs=gsPowerState.uDevCurPs;
                    mPSChgClrPs34;
                    gApstPs3ToPs4=0;
#if _ENABLE_ATA_PASSTHROUGH

                    if(rmChkSecurityErasePrepare)
                    {
                        rmClrSecurityErasePrepare;
                        gbSecAPIClearATASecurityPrepare=1;
                    }
#endif

#if (_RR_WORKAROUND)
                    // if(gATAErase) // CSSD-3246, ATA Security Erase Unit Command should be followed by securityErasePrepare command
                    // {
                    //    gATAErase = 0;
                    // }
#endif

#if _ENABLE_ATA_PASSTHROUGH

                    if(rmChkSecurityLock)
                    {
                        NLOG_SAVE(cLogSecApiBaseFw,
                                  MAINCORE0_C,
                                  1,
                                  cSaveIdSecurity,
                                  " ATA Security Locked, Opcode = 0x%04X. ",
                                  (WORD)rmNvmeOpCode);
                        manualCompletion((cStatusDoNotRetry|cStatusCmdSequenceErr), 0, cNoRwCmd, 0);
                    }
                    else
#endif

                    if(mChkSanitizeCommandAbort)
                    {
                        if(mChkSanitizeInProgress)
                        {
                            NLOG(cLogHost, MAINCORE0_C, 1, " Sanitize in progress, IO OP=0x%04X ", rmNvmeOpCode);
                            manualCompletion(cStatusSanitizeInProgress, 0, cNoRwCmd, 0);
                        }
                        else if(mChkSanitizeCommandErr)
                        {
                            NLOG(cLogHost, MAINCORE0_C, 1, " Sanitize failed, IO OP=0x%04X ", rmNvmeOpCode);
                            manualCompletion(cStatusSanitizeFailed, 0, cNoRwCmd, 0);
                        }
                    }

#if _EN_WriteZeroNonAlign    // WriteZeroNonAlign_20181031_Chief
                    else if((rmNvmeOpCode==cNvmeCmdWrite)||(rmNvmeOpCode==cNvmeCmdRead)||(rmNvmeOpCode==cNvmeCmdWriteZero))
#else
                    else if((rmNvmeOpCode==cNvmeCmdWrite)||(rmNvmeOpCode==cNvmeCmdRead))
#endif
                    {
#if _EN_RAID_GSD

                        if(uRestoPty)
                        {
                            mCallFuncPtr(cfuncRestoParity);
                            waitAllChCeBzCore0();
                            uRestoPty=0;
                        }
#endif

                        if(mChkGcFlag(cPwOnExtraGcF)||mChkGcFlag(cPwOnH2FGcF))
                        {
                            gGCOpt|=gbPwOnGC;    // 20190508_ChrisSu_01
                            chkPwrOnExtraClnProc();
                            gGCOpt&=~gbPwOnGC;
                        }

                        if(rmChkShstComplete)
                        {
                            rmSetShstNormal;
                        }

#if _EN_WriteZeroNonAlign    // WriteZeroNonAlign_20181031_Chief

                        if(rmNvmeOpCode==cNvmeCmdWriteZero)
                        {
                            mCallFuncPtr(cfuncNvmeWriteZero);

                            if(gsWZCnt)
                            {
                                NLOG(cLogHost, MAINCORE0_C, 0, " serRwCmdQue cNvmeCmdWriteZero Strat");
                            }
                        }
#endif/* if _EN_WriteZeroNonAlign */
#if _ENABLE_RDWR_FLOW
                        gsDebugInfo.u32SrvRwCmdTime=getRtcCurrent32k();

                        u32Time=getRtcCurrentMs();
                        enableLdpcPipe();
                        // codeFuncPtr[cfuncServRwCmdQue]();    // servRwCmdQue();
                        mCallFuncPtr(cfuncServRwCmdQue);
                        disableLdpcPipe();
                        gsSmart.usCnt.u64ControllerBusyTimeMs+=(getRtcCurrentMs()-u32Time);
#if _EN_WriteZeroNonAlign    // WriteZeroNonAlign_20181031_Chief

                        if(gsWZCnt==cBitFF)
                        {
                            gsWZCnt=0;
                            NLOG(cLogHost, MAINCORE0_C, 0, " serRwCmdQue Clear garNonAlignZero");
                            manualCompletion(cStatusSuccess, 0, cNoRwCmd, 0);
                        }
                        else if(gsWZCnt)
                        {
                            NLOG(cLogHost, MAINCORE0_C, 1, " garNonAlignZero not clear gsWZCnt=0x%04X", gsWZCnt);
                        }
#endif/* if _EN_WriteZeroNonAlign */
#if _EN_WUNCTable    // WriteZeroNonAlign_20181031_Chief

                        if(gsWUNCInfo.uWuncCnt&cBit4)
                        {
                            gsWUNCInfo.uWuncCnt&=~cBit4;
                            NLOG(cLogHost, MAINCORE0_C, 1, "WUNC Save To Wpro Delete uWuncCnt=0x%04X", gsWUNCInfo.uWuncCnt);
                            bopCopyRam(((LWORD)garTsb0[0]), (LWORD)&gsWUNCInfo, sizeof(gsWUNCInfo), cCopyStcm2Tsb|cBopWait);
                            progWproPageCore0(cWproWriteUNC, c16Tsb0SIdx);
                        }
#endif

                        // gsDebugInfo.u32SrvRwCmdTime=0;
#else/* if _ENABLE_RDWR_FLOW */
                        manualCompletion(cStatusSuccess, 0, cNoRwCmd, 0);
#endif/* if _ENABLE_RDWR_FLOW */
                    }
                    else
                    {
                        addCmdHistory();

                        switch(rmNvmeOpCode)
                        {
                            case cNvmeCmdFlush:
                                // NLOG(cLogHost, MAINCORE0_C, 0, " NVMe Flush Cmd ");    // move from NvmeIoCmd.c
                                mCallFuncPtr(cfuncNvmeFlush);
                                break;

                            case cNvmeCmdWriteUnc:
                                nvmeIoCommandSwap(cfuncNvmeWriteUnc);
                                break;

                            case cNvmeCmdCompare:
                                nvmeIoCommandSwap(cfuncNvmeCompare);
                                break;

#if !_EN_WriteZeroNonAlign    // WriteZeroNonAlign_20181031_Chief
                            case cNvmeCmdWriteZero:
                                mCallFuncPtr(cfuncNvmeWriteZero);
                                break;
#endif/* if _EN_WriteZeroNonAlign */

                            case cNvmeCmdDataSetMgm:
                                mCallFuncPtr(cfuncNvmeDataSetMgm);
                                break;

                            default:
                                manualCompletion(cStatusInvalidOpCode, 0, cNoRwCmd, 0);
                                break;
                        }    /* switch */
                    }

                    u32IdleState=1;
                    // enSysTmr(cIdleTmrVal-cRwIdleTmrVal);    // Idle time to standy
                    // The controller is idle when there are no commands outstanding to any I/O Submission Queue.
                    startRtcCountingMs();    // follow NVMe 1.3 spec 8.4.2 APST;20181127_Eason_01
                }
                else
                {
                    gsDebugInfo.u32SrvAdminCmdTime=getRtcCurrent32k();

                    if(!gsDebugInfo.u32SrvAdminCmdFirstTime)
                    {
                        gsDebugInfo.u32SrvAdminCmdFirstTime=gsDebugInfo.u32SrvAdminCmdTime;
                    }

                    nvmeHandleAdmin();

                    u32IdleState=2;
                    // gsDebugInfo.u32SrvRwCmdTime=0;
                    // if(gsPowerState.uPsChg)
                    // {
                    //    u32IdleTime=rmGetRtc32kTick;    // Idle time to PS3/4, default 120us
                    // }
                    // else
                    // {
                    //    enSysTmr(cRwIdleTmrVal);    // RW idle time to standy
                    // }
                }

#if _EN_EarlyBdGC    // 20190620_ChrisSu
                u32EarTimer=rmGetRtc1sTick;
                u32EarTimer=u32EarTimer-g32EarGCTimer;

                if(g32EarIOcnt>cScnt500M)
                {
                    if(gEarGCflag)
                    {
                        NLOG(cLogHost, MAINCORE0_C, 0, "Early GC OFF");
                    }

                    gEarGCflag=0;
                    g32EarIOcnt=0;
                    g32EarGCTimer=rmGetRtc1sTick;
                }
                else if(u32EarTimer>60)
                {
                    if(!gEarGCflag)
                    {
                        NLOG(cLogHost,
                             MAINCORE0_C,
                             4,
                             " Early GC ON ,g32EarIOcnt =0x%08x , u32EarTimer=%08x",
                             g32EarIOcnt>>16,
                             g32EarIOcnt,
                             u32EarTimer>>16,
                             u32EarTimer);
                    }

                    gEarGCflag=1;
                    g32EarIOcnt=0;
                    g32EarGCTimer=rmGetRtc1sTick;
                }
#endif/* if _EN_EarlyBdGC */

#if _2260PCIE_WORKAROUND
                afterHandlingCmd(uEnablL12);
#endif
                mSetHandlePcieRstF;    // gHandlePcieRstInIsr=1;
#if _EN_CmdDelayBGC    // 20190724_ChrisSu
                g32CmdNoGC1s=getRtcCurrentMs();
                uCmd1s=0;
#endif
                // rmClrPcieDoNotEnterL1;
            }
            else if(((gLowPowerStateRetryCnt<3)&&(!mPSChgChkPs34)&&(!mPSChgChkThrottling)&&(rmChkCcRdy))
                    &&(((gsPowerState.uFeatVal.u32Current&cPowerStateMask)>cPs2)&&chkHostEnAspm()))
            {
                gsPowerState.uDevNextPs=gsPowerState.uFeatVal.u32Current&cPowerStateMask;
                mPSChgSetPs34;
#if (_ENABLE_PM_BACKUP_SMART)

                if(!gSmartBackup)
#endif
                {
                    gLowPowerStateRetryCnt++;    // max 3 to retry enter low power state
                }

                u32IdleState=3;    // add idle 120us,20181207_Eason
                NLOG(cLogPS, MAINCORE0_C, 1, " LowPower RetryCnt =%04d ", gLowPowerStateRetryCnt);
            }
            else
            {
                u32IdleState=0;
                enSysTmr(cIdleTmrVal);
            }

#if _EN_Liteon_ErrHandle

            if(gJdgBootGCFlag&cWproNeedSwap)    // 20180328_Louis
            {
                swapWproBlkCore0();
                gJdgBootGCFlag&=(~cWproNeedSwap);
            }
#endif

#if _EN_PopBlk0    // Chief_20190104

            if(g16PushSpareCnt&&(gsCacheInfo.u16SpareBlockCnt<=C_BlkEmergencyTh))
            {
                chkPushSpareQCore0(0);
                NLOG(cLogPS, MAINCORE0_C, 0, "Emergency chkPushSpareQCore0");
            }

            if(gBlkEmergencyflag==cBit0)
            {
                NLOG(cLogPS, MAINCORE0_C, 0, "Emergency progCacheInfoTab");
                progCacheInfoTab();
                gBlkEmergencyflag=0;
            }
#endif

            // ===== Start Idle Time =====
            if(u32IdleState)
            {
                // startRtcCountingMs();

                if(g32ApstEnable||gsPowerState.uPsChg)
                {
                    // Idle time to PS3/4, default 120us
                    // Or enable APST
                    u32IdleTime=getRtcCurrent32k();
                }
                else if(u32IdleState==1)
                {
                    enSysTmr(cIdleTmrVal-cRwIdleTmrVal);
                }
                else    // time to standby
                {
                    enSysTmr(cRwIdleTmrVal);    // RW idle time to standy
                }

                u32IdleState=0;
            }

            // checkDbInvalid();    // CSSD-2086

            // check Pcie error event count
            chkPcieErrorEvent();

#if _ENABLE_SECAPI

            if((gPowerDownMode!=cGSD)&&(gbSecAPIPendingPCIeReset||gbSecAPIPendingNSSR||gbSecAPIPendingInitATA||gbSecAPIClearATASecurityPrepare))    //
                                                                                                                                                    // 20190605_SamHu
                                                                                                                                                    // Jira1143
                                                                                                                                                    // Lenovo
                                                                                                                                                    // reboot
                                                                                                                                                    // security
                                                                                                                                                    // status
            {
                handleSecFlag();
            }
#endif
#if _EN_CmdDelayBGC    // 20190724_ChrisSu

            if(!uCmd1s)
            {
                if((getRtcCurrentMs()-g32CmdNoGC1s)>1000)
                {
                    uCmd1s=1;
                }
            }
#endif

#if _EN_LenovoPFail    // Chief_20190129

            if(gCpu0TOFlag||mPSChgChkThrottling||pendingAsyncEvent()
               ||(gsPowerState.uPsChg&&(chkRtc32kProcTime(u32IdleTime)>=cRwIdle32kTmrVal))
               ||(g32ApstEnable&&
                  ((chkRtc32kProcTime(u32IdleTime)>=cAPSTIdle32kTmrVal)||
                   (getRtcDiffMs()>=garApstCurrent[gsPowerState.uFeatVal.u32Current&cPowerStateMask].uItpt))
                  ))    // LeverYu_20190418
#else

            if(gCpu0TOFlag||mPSChgChkThrottling||pendingAsyncEvent()
               ||((gsPowerState.uPsChg||g32ApstEnable)&&(chkRtc32kProcTime(u32IdleTime)>=cRwIdle32kTmrVal)))
#endif
            {
                // codeFuncPtr[cfuncBgdClnBlk]();//debug??????????????????
                // u32IdleTime=0; //Fixed Host notice DR_CQ_Head slowly for edevx,20181207_Eason
                disSysTmr();
#if _EN_BgdGc
#if _EN_IDLEGC_DELAY

                if(((gsLightSwitch.usOem3Ls.uFtlCtrl&cFtlBgdGc)&&(!gFWShnFlag)&&(gBgdGCWakeUp)&&(!uRestoPty)&&(uCmd1s))||
                   (mJudgeRecoverychkTrig&&rmChkPcieD0State))                                                                                                            //
                                                                                                                                                                         // Bruce_20190613
                                                                                                                                                                         // for
                                                                                                                                                                         // Lenovo
                                                                                                                                                                         // Performance
                                                                                                                                                                         // Recovery
                                                                                                                                                                         // Check
                                                                                                                                                                         // Test
#else

                if(((gsLightSwitch.usOem3Ls.uFtlCtrl&cFtlBgdGc)&&(!gFWShnFlag)&&(!uRestoPty)&&(uCmd1s))||
                   (mJudgeRecoverychkTrig&&rmChkPcieD0State))
#endif
                {
                    tracePcieEvent(0x80);
#if (C_Log_SaveMask&C_Debug_P1)
                    NLOG(cLogGC, MAINCORE0_C, 0, " Start Background GC ");
#endif
                    mSetGcFlag(cUnderBgdGc);
                    waitAllChCeBzCore0();
                    enableLdpcPipe();
                    mClrHandlePcieRstF;
                    codeFuncPtr[cfuncBgdClnBlk]();
                    mSetHandlePcieRstF;
                    waitAllChCeBzCore0();
                    disableLdpcPipe();
                    mClrGcFlag(cUnderBgdGc);
#if _EN_IDLEGC_DELAY
                    g32IdleGcDelayTime=0;
                    gBgdGCWakeUp=0;                        // 20190724_ChrisSu
#endif

#if (C_Log_SaveMask&C_Debug_P1)
                    NLOG(cLogGC, MAINCORE0_C, 0, " End Background GC ");
#endif
                    tracePcieEvent(0x81);
                }
                else if(uCmd1s)    // 20190724_ChrisSu
#endif/* if _EN_BgdGc */
                {
#if _EN_IDLEGC_DELAY
                    gBgdGCWakeUp=0;
#endif
                }

#if _ENABLE_THERMAL

                if(gChkTemperature)
                {
                    if((!mPSChgChkThrottling)&&(!mPSChgChkPs34))
                    {
                        chkThrottlingPowerState(0);
                    }

                    gChkTemperature=0;
                }

                if(mPSChgChkThrottling)
                {
                    tran2ThermalThrottlingState();
                    mPSChgClrThrottling;
                }
#endif/* if _ENABLE_THERMAL */

                if(chkDstInProgress()&&(!rmChkShstComplete))    // 20181228_SamHu_01 eDEVX
                {
                    loadISPCodeCore0(cNvmeIsp, 0);
                    mCallFuncPtr(cfuncHandleDst);
                    loadISPCodeCore0(cRwIsp, 0);
                }

                if(!mChkTelemetryCtlrInfoLoaded)
                {
                    if(gsWproInfo.u16arWproIdxPagePtr[cWproEventLog]!=0xFFFF)
                    {
                        readWproPageCore0(cWproEventLog, c16Tsb0SIdx, 0);
                        gTelemetryCtlrGenNum=garTsb0[(c32GcInfoVarLogPageAddr/512)-1][0x1FF];
                        gTelemetryCtlrInfo=garTsb0[(c32GcInfoVarLogPageAddr/512)-1][0x1FE];
                    }

                    if(mChkAerTelemtryLogNoticeEn&&mChkTelemetryCtlrInfoAvail)
                    {
                        mSetAerTelemetryLog;
                    }

                    mSetTelemetryCtlrInfoLoaded;
                }

                if(mChkSanitizeInProgress||mChkCacheInfoSpf(cSanitize))
                {
                    loadISPCodeCore0(cNvmeIsp, 0);
                    mCallFuncPtr(cfuncSanitizeContinueOp);
                    loadISPCodeCore0(cRwIsp, 0);
                }

                while(pendingAsyncEvent()&&rmChkCcRdy)
                {
                    loadISPCodeCore0(cNvmeIsp, 0);
                    mCallFuncPtr(cfuncHandleAsyncEvent);
                    loadISPCodeCore0(cRwIsp, 0);
                }

                updateInvalidDbErrLog();
                runTimeKeepSmartInfo();

                // HIPM
#if (_EN_AUTHENTICATION)

                if(gsPowerState.uPsChg&&(!mChkSanitizeInProgress)&&((!gsFwDlInfo.u32IspCodePerEndOffset)||(gsFwDlInfo.uAuthPass)))
#else

                if(gsPowerState.uPsChg&&(!mChkSanitizeInProgress))
#endif
                {
#if _ENABLE_NVME_PM

                    if(chkHostIdle(1))
                    {
#if (_EN_CHRONUS_UART_DEBUG)

                        if(!mChkUartHoldActiveMo)
#endif
                        {
                            hdlHipmProc();
                        }
                    }
#endif
                }

                // DIPM
                // if(!(g32NvmeCondition||gsPowerState.uPsChg))

#if (_EN_AUTHENTICATION)    // 20181226_SamHu_01

                if((!g32NvmeCondition)&&(!gBgdGCWakeUp)&&idleFunction(0)&&((!gsFwDlInfo.u32IspCodePerEndOffset)||(gsFwDlInfo.uAuthPass)))
#else

                if((!g32NvmeCondition)&&(!gBgdGCWakeUp)&&idleFunction(0))
#endif
                {
#if _ENABLE_STANDBY_MODE

                    // Idle sleep
                    if((!gApstPs3ToPs4)&&(!gsPowerState.uPsChg)&&(!gFWShnFlag))    // Fixed Host notice DR_CQ_Head slowly for
                                                                                   // edevx,20181207_Eason
                    {
                        // Shutdown don,t enter Standby;20190103_Eason
#if (_EN_CHRONUS_UART_DEBUG)

                        if(!mChkUartHoldActiveMo)
#endif
                        {
                            hdlStandbyProc();
                        }
                    }
#endif/* if _ENABLE_STANDBY_MODE */
#if _ENABLE_NVMEFEAT_APST

                    // Host enable APST PS3/PS4
                    if(g32ApstEnable&&(rmChkCcRdy)&&(gApstRetryCnt<3))
                    {
#if (_EN_CHRONUS_UART_DEBUG)

                        if(!mChkUartHoldActiveMo)
#endif
                        {
                            hdlHostApstProc();
                        }
                    }
#endif/* if _ENABLE_NVMEFEAT_APST */
                }
            }
        }
    }

#else/* if !_INITDRAM */
    initUart();
    void (*ISPPretestFunPtr)(unsigned char)=0;
    unsigned int u32JumpAddr=c32MainCodeDramAddr;
    ISPPretestFunPtr=(void (*)(unsigned char))(u32JumpAddr);
    ISPPretestFunPtr(0);
#endif/* if !_INITDRAM */
}    /* main */

void chkPwrOnForceClnProc()
{
    // if(chkBgdClnCacheBlk()||(gsCacheInfo.uH2fTabBlockCnt>=gsGcInfo.uGcH2fTabbHiThr))
    // {
    /*
       * gsRdlinkInfo.ubPwrOnGcF=1;
       * waitAllChCeBzCore0();
       * enableLdpcPipe();
       * mCallFuncPtr(cfuncBgdClnBlk);
       * waitAllChCeBzCore0();
       * disableLdpcPipe();
       */
    if(chkBgdClnCacheBlk())
    {
        if(!mChkGcQue(cGcTypForeGrnd))
        {
            mPushGcQue(cGcTypForeGrnd);
        }
    }

    if(gsCacheInfo.uH2fTabBlockCnt>=gsGcInfo.uGcH2fTabbHiThr)
    {
        if(!mChkGcQue(cGcTypH2fTab))
        {
            mPushGcQue(cGcTypH2fTab);
        }

#if _EN_Liteon_ErrHandle

        if((gJdgBootGCFlag&(cBootH2FGC))&&(gsCacheInfo.uH2fTabBlockCnt>=(gMaxH2fTabBlkNum*3/4)))
        {
            mSetGcFlag(cPwOnH2FGcF);
        }
#endif
    }

    /*
       * // If block is still insufficient, excute power on extra GC.
       * if(chkBgdClnCacheBlk()||(gsCacheInfo.uH2fTabBlockCnt>=gsGcInfo.uGcH2fTabbHiThr))
       * {
       *  mSetGcFlag(cPwOnExtraGcF);
       *  mClrGcFlag(cStopBgdClean);
       *  gsRdlinkInfo.uPowerOnExtraGcCnt++;
       *  return;
       * }
       */
    // }

    WORD u16TLCSpareCnt;
    u16TLCSpareCnt=g16MinStaticTlcCnt-g16TlcFullCachebGcThr;

    if(gsCacheInfo.u16SpareBlockCnt<gsGcInfo.u16GcCachebActThr)
    {
        gsGcInfo.u32GcLeastBudget=c32PartialCleanRtc30ms*(gsGcInfo.u16GcCachebActThr/gsCacheInfo.u16SpareBlockCnt);
    }
    else if(gsCacheInfo.u16DynamicSpareCnt<u16TLCSpareCnt)
    {
        gsGcInfo.u32GcLeastBudget=c32PartialCleanRtc30ms*(u16TLCSpareCnt/gsCacheInfo.u16DynamicSpareCnt);
    }

#if Power_slcQoverflow
#if _EN_VPC_SWAP

    if((gsCacheInfo.u16SpareBlockCnt<(gsGcInfo.u16GcCachebActThr/2))||(gsCacheInfo.u16DynamicSpareCnt<(u16TLCSpareCnt/2))||
       (g16SlcSortQCnt>(cIOMeterMaxSlcBlkQ-cSLCQ_ExtraGcThrd)))
#else

    if((gsCacheInfo.u16SpareBlockCnt<(gsGcInfo.u16GcCachebActThr/2))||(gsCacheInfo.u16DynamicSpareCnt<(u16TLCSpareCnt/2))||
       (g16SlcSortQCnt>(cMaxSlcBlkQ-cSLCQ_ExtraGcThrd)))
#endif
#else

    if((gsCacheInfo.u16SpareBlockCnt<(gsGcInfo.u16GcCachebActThr/2))||(gsCacheInfo.u16DynamicSpareCnt<(u16TLCSpareCnt/2)))
#endif
    {
        mSetGcFlag(cPwOnExtraGcF);

#if Power_slcQoverflow
#if _EN_VPC_SWAP

        if((gsCacheInfo.u16SpareBlockCnt<(cMinGCSprCnt/2))||(gsCacheInfo.u16DynamicSpareCnt<(cMinGCSprCnt/2))||
           (g16SlcSortQCnt>(cIOMeterMaxSlcBlkQ-cSLCQ_ForceCleanThrd)))
#else

        if((gsCacheInfo.u16SpareBlockCnt<(cMinGCSprCnt/2))||(gsCacheInfo.u16DynamicSpareCnt<(cMinGCSprCnt/2))||
           (g16SlcSortQCnt>(cMaxSlcBlkQ-cSLCQ_ForceCleanThrd)))
#endif
#else

        if((gsCacheInfo.u16SpareBlockCnt<(cMinGCSprCnt/2))||(gsCacheInfo.u16DynamicSpareCnt<(cMinGCSprCnt/2)))
#endif
        {
            mSetGcFlag(cGcForceClean);
        }
    }
    else
    {
        mClrGcFlag(cPwOnExtraGcF);
    }
}    /* chkPwrOnForceClnProc */

BYTE chkBgdGCWakeup()
{
    BYTE uBgdCln=0;

#if _EN_IDLEGC_DELAY

    if((gsLightSwitch.usOem3Ls.uFtlCtrl&cFtlBgdGc)&&(!gFWShnFlag)&&(!mChkGcFlag(cStopBgdClean)))
    {
        mSetGcFlag(cUnderBgdGc);

        if(chkBgdClnCacheBlk()||(gsCacheInfo.uH2fTabBlockCnt>=gsGcInfo.uGcH2fTabbHiThr))
        {
            uBgdCln=1;
        }
    }
    mClrGcFlag(cUnderBgdGc);
#endif
    return uBgdCln;
}    /* chkBgdGCWakeup */

void chkPwrOnExtraClnProc()
{
    if(chkBgdClnCacheBlk()||(gsCacheInfo.uH2fTabBlockCnt>=gsGcInfo.uGcH2fTabbHiThr))
    {
        NLOG(cLogGC, MAINCORE0_C, 0, " Start PowerOnExtra GC ");
        // NLOG(cLogGC, MAINCORE0_C, 1, "SLC spare block count: 0x%04X ", gsCacheInfo.u16SLCSpareCnt);
        // NLOG(cLogGC, MAINCORE0_C, 1, "TLC full cache block count: 0x%04X ", gsCacheInfo.u16TLCFullCacheBlockCnt);
        mClrGcFlag(cStopBgdClean);

        if(mChkGcFlag(cGcForceClean))
        {
            NLOG(cLogGC, MAINCORE0_C, 0, " Need to do Force Clean ");
        }

        gsGcInfo.u32PwrOnGcStartTime=getRtcCurrent1s();
        waitAllChCeBzCore0();
        enableLdpcPipe();
        mCallFuncPtr(cfuncBgdClnBlk);
        waitAllChCeBzCore0();
        disableLdpcPipe();
        gsGcInfo.u32PwrOnGcEndTime=getRtcCurrent1s();
        mClrGcFlag(cPwOnExtraGcF);
        mClrGcFlag(cPwOnH2FGcF);
        mClrGcFlag(cStopBgdClean);
        NLOG(cLogGC, MAINCORE0_C, 0, " End PowerOnExtra GC ");
        // NLOG(cLogGC, MAINCORE0_C, 1, "SLC spare block count: 0x%04X ", gsCacheInfo.u16SLCSpareCnt);
        // NLOG(cLogGC, MAINCORE0_C, 1, "TLC full cache block count: 0x%04X ", gsCacheInfo.u16TLCFullCacheBlockCnt);
    }

    if(chkBgdClnCacheBlk())
    {
        if(!mChkGcQue(cGcTypForeGrnd))
        {
            mPushGcQue(cGcTypForeGrnd);
        }
    }

    if(gsCacheInfo.uH2fTabBlockCnt>=gsGcInfo.uGcH2fTabbHiThr)
    {
        if(!mChkGcQue(cGcTypH2fTab))
        {
            mPushGcQue(cGcTypH2fTab);
        }
    }

    mClrGcFlag(cPwOnExtraGcF);
    mClrGcFlag(cPwOnH2FGcF);
    mClrGcFlag(cStopBgdClean);

    // while(mChkGcFlag(cPwOnExtraGcF))
    //    ;
}    /* pwrOnForceClnProc */

void saveRdTimeStamp(BYTE state)
{
    if(gsRdlinkInfo.u32RdlinkTimeStamp[state]==c32BitFF)
    {
        // gsRdlinkInfo.u32RdlinkTimeStamp[state]=getRtcCurrentMs();
        gsRdlinkInfo.u32RdlinkTimeStamp[state]=getRtcCurrent32k();
    }
}

BYTE Check_EEPROM_Tag(WORD u16BufIdx)
{
    if((garTsb0[u16BufIdx][0x0]!='A')||(garTsb0[u16BufIdx][0x1]!='G')||(garTsb0[u16BufIdx][0x2]!='I')||(garTsb0[u16BufIdx][0x3]!='N'))
    {
        return cFail;
    }

    if((garTsb0[u16BufIdx][0x100]!='T')||(garTsb0[u16BufIdx][0x101]!='S')||(garTsb0[u16BufIdx][0x102]!='T')||(garTsb0[u16BufIdx][0x103]!='1'))
    {
        return cFail;
    }

    if((garTsb0[u16BufIdx][0x110]!='T')||(garTsb0[u16BufIdx][0x111]!='S')||(garTsb0[u16BufIdx][0x112]!='T')||(garTsb0[u16BufIdx][0x113]!='2'))
    {
        return cFail;
    }

    return cSuccess;
}    /* Check_EEPROM_Tag */

#if _ENABLE_SECAPI
void handleSecFlag()
{
    loadISPCodeCore0(cSecTsbBank, 3);
    SecAPI_NoticeSecCodeSwap(0);
    handleSecFlagSub();
    SecAPI_NoticeSecCodeSwap(1);
}

void handleSecFlagSub()
{
    if(gbSecAPIPendingPCIeReset)
    {
        SecAPI_NoticeReset_Request(cPCIeRst);
        gbSecAPIPendingPCIeReset=0;
        gbSecAPIPendingNSSR=0;
    }
    else if(gbSecAPIPendingNSSR)
    {
        SecAPI_NoticeReset_Request(cNSSR);
        gbSecAPIPendingNSSR=0;
    }

#if _ENABLE_ATA_PASSTHROUGH

    if(gbSecAPIPendingInitATA)
    {
        SecAPI_InitATASecurity(cInitForce);
        gbSecAPIPendingInitATA=0;
        mClrCacheInfoSpf(cChangeSecurityState);
        progCacheInfoTab(    /*cInfuncTskEraseUnitProc_02*/);
    }
#endif
}    /* handleSecFlagSub */

void SecAPI_ChkStackOverFlow()
{
    // LWORD *stack_check_point_svcstack=(LWORD *)(cSVCStackEnd+0x40);
    LWORD *stack_check_point_svcstack=(LWORD *)(cSVCStackEnd+0x20);
    LWORD *stack_check_point_irqstack=(LWORD *)(cIRQStackEnd+0x25);

    if(*stack_check_point_svcstack!=0x5A5A5A5A)
    {
        NLOG(cLogSecApiBaseFw, MAINCORE0_C, 0, "  SecAPI_ChkStackOverFlow() svc stack.");
    }

    if(*stack_check_point_irqstack!=0x5A5A5A5A)
    {
        NLOG(cLogSecApiBaseFw, MAINCORE0_C, 0, "  SecAPI_ChkStackOverFlow() irq stack.");
    }
}

void SecAPI_ChkSessionTimeout()
{
    LWORD u32TimerDiff;

    if(gbEnSessionTimer)
    {
        if(g32MaxSessionTimeout)
        {
            LWORD u32SessionTimer;
            u32SessionTimer=getRtcCurrentMs();

            if(u32SessionTimer<g32SessionTimerStart)
            {
                u32TimerDiff=(0xFFFFFFFF-g32SessionTimerStart)+u32SessionTimer;
            }
            else
            {
                u32TimerDiff=u32SessionTimer-g32SessionTimerStart;
            }

            if(u32TimerDiff>g32MaxSessionTimeout)
            {
                loadISPCodeCore0(cSecTsbBank, 3);
                SecAPI_NoticeSecCodeSwap(0);
                SFP.gfpSecIntf_SessionTimeoutCall(u32TimerDiff, g32MaxSessionTimeout);    // Session timeout -> Abort the session
                SecAPI_NoticeSecCodeSwap(1);
            }
        }
    }
}    /* SecAPI_ChkSessionTimeout */

#endif/* if _ENABLE_SECAPI */

#if (!_ICE_LOAD_ALL)
#pragma default_function_attributes =
#endif







