







#include "inc/DebugLog.h"
#include "inc/EventLogIDX.h"
#include "inc/EventLogFunctionIDX.h"
#include "inc/GlobVarT.h"
#include "inc/NvmeCtrl.h"
#include "inc/Mac.h"
#include "inc/ProType.h"
#include "inc/Reg.h"
#include "inc/TypeDef.h"
#if (_CPUID==0)
#include "inc/GlobVar0.h"
#else    // CPUID==1
#include "inc/GlobVar1.h"
#include "inc/BitDef.h"
#endif

#if (!_ICE_LOAD_ALL)
#pragma default_function_attributes = @ ".DBG_LOG"
#endif

#if _DEBUG_LOG
#if (_CPUID==0)
void fillEventLog(WORD u16RecordData)
{
#if (!_TSB_BiCS4_WR)
    if(g16EventLogPtr>=cEventLogSize)
    {
        g16EventLogPtr=0;
    }

    g16arEventLog[g16EventLogPtr]=u16RecordData;
    g16EventLogPtr++;
#endif
}

void fillLinkLog(WORD u16RecordData)
{
    if(g16LinkLogPtr>=cLinkLogSize)
    {
        g16LinkLogPtr=0;
    }

    g16arLinkLog[g16LinkLogPtr]=u16RecordData;
    g16LinkLogPtr++;
}

void debugLink(BYTE uPriority, BYTE uIdx, BYTE uParaCnt, ...)
{
    va_list argPtr;
    LWORD u32Idx;
    LWORD u32TimeStamp=0;

    u32TimeStamp=getRtcCurrentMs();

    fillLinkLog((uPriority<<8)|uIdx);

    // Record Time Stamp
    fillLinkLog(u32TimeStamp>>16);

    fillLinkLog(u32TimeStamp);
    // =====================

    va_start(argPtr, uParaCnt);

    for(u32Idx=0; u32Idx<uParaCnt; u32Idx++)
    {
        fillLinkLog(va_arg(argPtr, WORD));
    }

    va_end(argPtr);

    // output Uart Log
    if(g32OutputUART)
    {
        setLock(&gsMutexInfo);

        while(rmUartChkTxBusy)
            ;// wait uart tx fifo is empty

        rmUartTxWord((uPriority<<8)|uIdx);    // send ID and Index
        rmUartTxLword(u32TimeStamp);    // send time stamp
        // send data
        va_start(argPtr, uParaCnt);

        for(u32Idx=0; u32Idx<uParaCnt; u32Idx++)
        {
            rmUartTxWord(va_arg(argPtr, WORD));
        }

        va_end(argPtr);
        clrLock(&gsMutexInfo);
    }
}    /* debugLink */

void debugLinkSave(BYTE uPriority, BYTE uIdx, BYTE uParaCnt, WORD u16SaveLogID, ...)
{
    va_list argPtr;
    LWORD u32Idx;
    LWORD u32TimeStamp=0;

    u32TimeStamp=getRtcCurrentMs();

    fillLinkLog((uPriority<<8)|uIdx);

    // Record Time Stamp
    fillLinkLog(u32TimeStamp>>16);

    fillLinkLog(u32TimeStamp);
    // =====================

    va_start(argPtr, u16SaveLogID);

    for(u32Idx=0; u32Idx<uParaCnt; u32Idx++)
    {
        fillLinkLog(va_arg(argPtr, WORD));
    }

    va_end(argPtr);

    if(u16SaveLogID)
    {
        if(!g16SaveEventLog)
        {
            g16SaveEventLog=u16SaveLogID;
        }
        else
        {
            g16SaveEventLog2=u16SaveLogID;
        }

        g16EventLogPtrBK=g16EventLogPtr;
        // ChkBackupLog(u16SaveLogID);
    }

    // output Uart Log
    if(g32OutputUART)
    {
        setLock(&gsMutexInfo);

        while(rmUartChkTxBusy)
            ;// wait uart tx fifo is empty

        rmUartTxWord((uPriority<<8)|uIdx);    // send ID and Index
        rmUartTxLword(u32TimeStamp);    // send time stamp
        // send data
        va_start(argPtr, u16SaveLogID);

        for(u32Idx=0; u32Idx<uParaCnt; u32Idx++)
        {
            rmUartTxWord(va_arg(argPtr, WORD));
        }

        va_end(argPtr);
        clrLock(&gsMutexInfo);
    }
}    /* debugLinkSave */

#else    // CPUID==1
void fillEventLog(WORD u16RecordData)
{
    if(g16Core1EventLogPtr>=cCore1EventLogSize)
    {
        g16Core1EventLogPtr=0;
    }

    g16arCore1EventLog[g16Core1EventLogPtr]=u16RecordData;
    g16Core1EventLogPtr++;
}

#endif/* if (_CPUID==0) */
/*
   * void ChkBackupLog(WORD u16SaveLogID)
   * {
   *  LWORD u32Idx;
   *
   *  if(!g16SaveEventLog)    g16SaveEventLog=u16SaveLogID;
   *  else                    g16SaveEventLog2=u16SaveLogID;
   *
   *  // backup event log
   *  for (u32Idx=0; u32Idx<cEventLogSize; u32Idx++)
   *  {
   *      g16arEventLogBK[u32Idx]=g16arEventLog[u32Idx];
   *  }
   *  g16EventLogPtrBK=g16EventLogPtr;
   * }
   */

void debugLog(BYTE uPriority, BYTE uIdx, BYTE uParaCnt, ...)
{
    va_list argPtr;
    LWORD u32Idx;
    LWORD u32TimeStamp=0;

    if(gByPassSecApiLog)
    {
        return;
    }

    u32TimeStamp=getRtcCurrentMs();

    fillEventLog((uPriority<<8)|uIdx);

    // Record Time Stamp
    fillEventLog(u32TimeStamp>>16);

    fillEventLog(u32TimeStamp);
    // =====================

    va_start(argPtr, uParaCnt);

    for(u32Idx=0; u32Idx<uParaCnt; u32Idx++)
    {
        fillEventLog(va_arg(argPtr, WORD));
    }

    va_end(argPtr);

    // output Uart Log
    if(g32OutputUART)
    {
        setLock(&gsMutexInfo);

        while(rmUartChkTxBusy)
            ;// wait uart tx fifo is empty

        rmUartTxWord((uPriority<<8)|uIdx);    // send ID and Index
        rmUartTxLword(u32TimeStamp);    // send time stamp
        // send data
        va_start(argPtr, uParaCnt);

        for(u32Idx=0; u32Idx<uParaCnt; u32Idx++)
        {
            rmUartTxWord(va_arg(argPtr, WORD));
        }

        va_end(argPtr);
        clrLock(&gsMutexInfo);
    }
}    /* debugLog */

void debugLogSave(BYTE uPriority, BYTE uIdx, BYTE uParaCnt, WORD u16SaveLogID, ...)
{
    va_list argPtr;
    LWORD u32Idx;
    LWORD u32TimeStamp=0;

    u32TimeStamp=getRtcCurrentMs();

    fillEventLog((uPriority<<8)|uIdx);

    // Record Time Stamp
    fillEventLog(u32TimeStamp>>16);

    fillEventLog(u32TimeStamp);
    // =====================

    va_start(argPtr, u16SaveLogID);

    for(u32Idx=0; u32Idx<uParaCnt; u32Idx++)
    {
        fillEventLog(va_arg(argPtr, WORD));
    }

    va_end(argPtr);

    if(u16SaveLogID)
    {
#if (_CPUID==0)
        if(!g16SaveEventLog)
        {
            g16SaveEventLog=u16SaveLogID;
        }
        else
        {
            g16SaveEventLog2=u16SaveLogID;
        }

        g16EventLogPtrBK=g16EventLogPtr;
        // ChkBackupLog(u16SaveLogID);
#else
        if(!g16Core1SaveEventLog)
        {
            g16Core1SaveEventLog=u16SaveLogID;
        }
        else
        {
            g16Core1SaveEventLog2=u16SaveLogID;
        }
        g16Core1EventLogPtrBK=g16Core1EventLogPtr;
#endif/* if (_CPUID==0) */
    }

    // output Uart Log
    if(g32OutputUART)
    {
        setLock(&gsMutexInfo);

        while(rmUartChkTxBusy)
            ;// wait uart tx fifo is empty

        rmUartTxWord((uPriority<<8)|uIdx);    // send ID and Index
        rmUartTxLword(u32TimeStamp);    // send time stamp
        // send data
        va_start(argPtr, u16SaveLogID);

        for(u32Idx=0; u32Idx<uParaCnt; u32Idx++)
        {
            rmUartTxWord(va_arg(argPtr, WORD));
        }

        va_end(argPtr);
        clrLock(&gsMutexInfo);
    }
}    /* debugLogSave */

#endif/* if _DEBUG_LOG */

#if (_CPUID==0)

void calEraseCnt(LWORD *up32Max, LWORD *up32Min, LWORD *up32Avg, BYTE uMode)
{
    LWORD u32SumOfGlobEraseCnt=0;
    WORD u16Fblock, u16FblkStart, u16FblkEnd, u16TotalofGlobErasedBlkCnt=0;

    *up32Max=0;
    *up32Min=c32BitFF;

    if(uMode==1)    // SLC
    {
        u16FblkStart=g16FirstFBlock;
        u16FblkEnd=g16StaticBound;
    }
    else if(uMode==2)    // TLC
    {
        u16FblkStart=g16StaticBound;
        u16FblkEnd=g16TotalFBlock;
    }
    else    // all
    {
        u16FblkStart=g16FirstFBlock;
        u16FblkEnd=g16TotalFBlock;
    }

    for(u16Fblock=u16FblkStart; u16Fblock<u16FblkEnd; u16Fblock++)
    {
        getGlobEraseCntOfSpecFblock(u16Fblock);

        if(g16OneFblockGlobEraseCnt!=c16BitFF)
        {
            if((*up32Max)<g16OneFblockGlobEraseCnt)
            {
                *up32Max=g16OneFblockGlobEraseCnt;
            }

            if((*up32Min)>g16OneFblockGlobEraseCnt)
            {
                *up32Min=g16OneFblockGlobEraseCnt;
            }

            u32SumOfGlobEraseCnt+=g16OneFblockGlobEraseCnt;
            u16TotalofGlobErasedBlkCnt+=1;
        }
    }

    if(u32SumOfGlobEraseCnt!=0)
    {
        *up32Avg=div(u32SumOfGlobEraseCnt, u16TotalofGlobErasedBlkCnt);
    }
    else
    {
        *up32Avg=0;
    }
}    /* calEraseCnt */

#if _EN_SAVEEVTLOG
void saveEventLog(BYTE uDeadLock)
{
    BYTE uLogOffset;
    WORD u16Idx, u16PtrTemp;
    LWORD u32CmdHistoryPtrBK;
    volatile BYTE *ucpDesPtr;
    volatile LWORD *u32cpDesPtr;
    LWORD u32MaxEraseCnt, u32MinEraseCnt, u32AvgEraseCnt;

    NLOG(cLogBuild, DEBUGLOG_C, 0, " Save Event Log ");

    fillCcmVal((BYTE *)&garTsb0[0][0], gSectorPerPlaneH*512, cZero);

    uLogOffset=(cEventLogSize*2)/512;
    u16PtrTemp=g16EventLogPtrBK;

    ucpDesPtr=&(garTsb0[uLogOffset][0]);

    u16Idx=0;

    while(u16Idx<cEventLogSize)
    {
        if(u16PtrTemp==0)
        {
            u16PtrTemp=cEventLogSize-1;
        }
        else
        {
            u16PtrTemp--;
        }

        ucpDesPtr-=2;

        // swap byte
        ucpDesPtr[0]=g16arEventLog[u16PtrTemp]>>8;
        ucpDesPtr[1]=g16arEventLog[u16PtrTemp];

        u16Idx++;
    }

    // save Core1 Event Log
    uLogOffset=(cEventLogSize*2)/512;
    u16PtrTemp=g16Core1EventLogPtrBK;

    ucpDesPtr=&(garTsb0[uLogOffset][0]);

    u16Idx=0;

    bopCopyRam((LWORD)&garTsb0[uLogOffset][0], cCore1EventLogSAddr, cCore1EventLogSize*2, cCopyCpu1Dccm2Tsb|cBopWait);

    while(u16Idx<cCore1EventLogSize)
    {
        // swap byte
        ucpDesPtr[0]=ucpDesPtr[0]^ucpDesPtr[1];
        ucpDesPtr[1]=ucpDesPtr[0]^ucpDesPtr[1];
        ucpDesPtr[0]=ucpDesPtr[0]^ucpDesPtr[1];

        ucpDesPtr+=2;
        u16Idx++;
    }

    uLogOffset=((cEventLogSize+cCore1EventLogSize+cLinkLogSize)*2)/512;
    u16PtrTemp=g16LinkLogPtr;

    ucpDesPtr=&(garTsb0[uLogOffset][0]);

    u16Idx=0;

    while(u16Idx<cLinkLogSize)
    {
        if(u16PtrTemp==0)
        {
            u16PtrTemp=cLinkLogSize-1;
        }
        else
        {
            u16PtrTemp--;
        }

        ucpDesPtr-=2;

        // swap byte
        ucpDesPtr[0]=g16arLinkLog[u16PtrTemp]>>8;
        ucpDesPtr[1]=g16arLinkLog[u16PtrTemp];

        u16Idx++;
    }

    uLogOffset=((cEventLogSize+cCore1EventLogSize+cLinkLogSize)*2)/512;
    CMDSTRUCT *upCmd=(CMDSTRUCT *)((void *)(&(garTsb0[uLogOffset][0])));
    u32CmdHistoryPtrBK=g32CmdHistoryPtr;

    do
    {
        if(!u32CmdHistoryPtrBK)
        {
            u32CmdHistoryPtrBK=cCmdHistorySize-1;
        }
        else
        {
            u32CmdHistoryPtrBK--;
        }

        upCmd->u32Dword0=garCmdHistory[u32CmdHistoryPtrBK].u32Dword0;
        upCmd->u32Dword10=garCmdHistory[u32CmdHistoryPtrBK].u32Dword10;
        upCmd->u32Dword11=garCmdHistory[u32CmdHistoryPtrBK].u32Dword11;
        upCmd->u32Dword12=garCmdHistory[u32CmdHistoryPtrBK].u32Dword12;
        upCmd++;
    }
    while(u32CmdHistoryPtrBK!=g32CmdHistoryPtr);

    // add Back End Log here
    uLogOffset=((cEventLogSize+cCore1EventLogSize+cLinkLogSize+cCmdListLogSize)*2)/512;

    ucpDesPtr=&(garTsb0[uLogOffset][0]);
    bopCopyRam(((LWORD)&garTsb0[uLogOffset][0]), g32RamAddrRetryTablePassIndex, (cMaxChNum*cMaxIntlvWay*2), cCopyCpu1Dccm2Tsb|cBopWait);
    bopCopyRam((((LWORD)&garTsb0[uLogOffset][0])+(cMaxChNum*cMaxIntlvWay*2)), g32RamAddrLastPassVthCenter,
               (cMaxChNum*cMaxIntlvWay*cMaxRetryRegisterCnt), cCopyCpu1Dccm2Tsb|cBopWait);

    // Jira 110
    // SLC erase count
    calEraseCnt(&u32MaxEraseCnt, &u32MinEraseCnt, &u32AvgEraseCnt, 1);
    ucpDesPtr[0x140]=u32AvgEraseCnt&0xFF;
    ucpDesPtr[0x141]=u32AvgEraseCnt>>8;
    ucpDesPtr[0x142]=u32MinEraseCnt&0xFF;
    ucpDesPtr[0x143]=u32MinEraseCnt>>8;
    ucpDesPtr[0x144]=u32MaxEraseCnt&0xFF;
    ucpDesPtr[0x145]=u32MaxEraseCnt>>8;
    // TLC erase count
    calEraseCnt(&u32MaxEraseCnt, &u32MinEraseCnt, &u32AvgEraseCnt, 2);
    ucpDesPtr[0x146]=u32AvgEraseCnt&0xFF;
    ucpDesPtr[0x147]=u32AvgEraseCnt>>8;
    ucpDesPtr[0x148]=u32MinEraseCnt&0xFF;
    ucpDesPtr[0x149]=u32MinEraseCnt>>8;
    ucpDesPtr[0x14A]=u32MaxEraseCnt&0xFF;
    ucpDesPtr[0x14B]=u32MaxEraseCnt>>8;
    // Jira 114
    // WAI erase count
    ucpDesPtr[0x14C]=((gsFtlDbg.u64TotalSlcProgCnt*gSectorPerPageH*100)/gsFtlDbg.u64TotalHostWrSecCnt)&0xFF;
    ucpDesPtr[0x14D]=((gsFtlDbg.u64TotalSlcProgCnt*gSectorPerPageH*100)/gsFtlDbg.u64TotalHostWrSecCnt)>>8;
    ucpDesPtr[0x14E]=((gsFtlDbg.u64TotalTlcOneShotCnt*gSectorPerPageH*100)/gsFtlDbg.u64TotalHostWrSecCnt)&0xFF;
    ucpDesPtr[0x14F]=((gsFtlDbg.u64TotalTlcOneShotCnt*gSectorPerPageH*100)/gsFtlDbg.u64TotalHostWrSecCnt)>>8;

    // Jira 111
    ucpDesPtr[0x160]=(((r32EfuseCtrl[0x40+0x3D]&0x01FF)<<21)|((r32EfuseCtrl[0x40+0x3C]&0xFFFFF800)>>11))&0xFF;
    ucpDesPtr[0x161]=((((r32EfuseCtrl[0x40+0x3D]&0x01FF)<<21)|((r32EfuseCtrl[0x40+0x3C]&0xFFFFF800)>>11))>>8)&0xFF;
    ucpDesPtr[0x162]=((((r32EfuseCtrl[0x40+0x3D]&0x01FF)<<21)|((r32EfuseCtrl[0x40+0x3C]&0xFFFFF800)>>11))>>16)&0xFF;
    ucpDesPtr[0x163]=((((r32EfuseCtrl[0x40+0x3D]&0x01FF)<<21)|((r32EfuseCtrl[0x40+0x3C]&0xFFFFF800)>>11))>>24)&0xFF;
    ucpDesPtr[0x164]=(r32EfuseCtrl[0x40+0x3C]>>6)&0x1F;
    ucpDesPtr[0x165]=r32EfuseCtrl[0x40+0x3C]&0x3F;
    ucpDesPtr[0x166]=(r32EfuseCtrl[0x40+0x3B]>>24)&0x7F;

    // Jira 112
    ucpDesPtr[0x170]=gChMap;
    ucpDesPtr[0x171]=gCeMap;
    ucpDesPtr[0x172]=gIntlvWay;
    ucpDesPtr[0x173]=gPlaneNum;
    ucpDesPtr[0x174]=gTotalChNum;
    ucpDesPtr[0x175]=gTotalCeNum;
    ucpDesPtr[0x176]=gTotalIntlvChNum;
    ucpDesPtr[0x177]=gTotalDiePerCe;
    ucpDesPtr[0x178]=gDataECCLevel;
    ucpDesPtr[0x179]=gSprECCLevel;
    // Abnormal event Table Oscar_20190410
    uLogOffset=((cEventLogSize+cCore1EventLogSize+cLinkLogSize+cCmdListLogSize)*2)/512;
    u32cpDesPtr=&(g32arTsb0[uLogOffset][0]);

    // ---PercentageUsed---
    WORD u16AvgOfGlobEraseCnt, u16DriveUsedPercentage;
    LWORD u32CRCFailCnt;
    u16AvgOfGlobEraseCnt=GetAvgECCore0(1);
    u16DriveUsedPercentage=div((u16AvgOfGlobEraseCnt*100), g32GrtPeCycle);

    if(u16DriveUsedPercentage>254)
    {
        u16DriveUsedPercentage=255;
    }

    // ---CRC Error Count---
    for(BYTE utype=0; utype<cE2eMaxType; utype++)
    {
        u32CRCFailCnt=gsE2eInfo.u32InternalDataCrcCnt[utype]++;
    }

    // ---NandWrite---
    LENOVOLOGDF *usLenovoDFhLogPtr=(void *)(&gpGetLog->usLenovoDFhLog);
    BYTE uShift;
    WORD u16AVGSLC=0, u16AVGTLC=0;
    WORD u16SLCBlock=0, u16TLCBlock=0;
    WORD u16NANDWriteInGB=0;
    LWORD u32_Temp_L=0, u32_Temp_M=0;

    usLenovoDFhLogPtr->NANDWriteIn512KBLower=0;
    usLenovoDFhLogPtr->NANDWriteIn512KBMiddle=0;
    usLenovoDFhLogPtr->SLCNANDWriteIn512KBLower=0;
    usLenovoDFhLogPtr->SLCNANDWriteIn512KBMiddle=0;

    u16AVGSLC=GetAvgECCore0(0);
    u16AVGTLC=GetAvgECCore0(1);
    u16SLCBlock=g16StaticBound-1;
    u16TLCBlock=g16TotalFBlock-g16OrgBadBlockCnt-g16LaterBadBlockCnt-g16FirstFBlock-gMinStaticSlcCnt+1;

    // SLC : (30000(SLC P/E Cycle)*Total SLC Block*SLC Block Size)/(512*1024)
    // --->30000*58*48*1024*1024/(512*1024)
    // --->30000*58*3*(2^4)*1024*1024/(512*1024)
    // --->30000*58*3*(2^5)

    // TLC : 3000(TLC P/E Cycle)*Total TLC Block*TLC Block size/(512*1024)
    // --->3000*870*144MB/(512*1024)
    // --->3000*870*9*(2^4)*1024*1024/(512*1024)
    // --->3000*870*9*2^5

    // For SLC NAND Write
    for(WORD u16idx=0; u16idx<u16SLCBlock*3; u16idx++)
    {
        u32_Temp_L=usLenovoDFhLogPtr->SLCNANDWriteIn512KBLower;
        usLenovoDFhLogPtr->SLCNANDWriteIn512KBLower+=u16AVGSLC;

        if(usLenovoDFhLogPtr->SLCNANDWriteIn512KBLower<u32_Temp_L)
        {
            usLenovoDFhLogPtr->SLCNANDWriteIn512KBMiddle++;
        }
    }

    // For TLC	NAND Write
    u32_Temp_L=0;

    for(WORD u16idx=0; u16idx<u16TLCBlock; u16idx++)
    {
        u32_Temp_L=usLenovoDFhLogPtr->NANDWriteIn512KBLower;
        usLenovoDFhLogPtr->NANDWriteIn512KBLower+=9*u16AVGTLC;

        if(usLenovoDFhLogPtr->NANDWriteIn512KBLower<u32_Temp_L)
        {
            usLenovoDFhLogPtr->NANDWriteIn512KBMiddle++;
        }
    }

    if((gTotalChNum==4)&&(gTotalCeNum==1))    // 128GB 2^5
    {
        uShift=5;
    }
    else if((gTotalChNum==4)&&(gTotalCeNum==2))    // 256GB 2^6
    {
        uShift=6;
    }
    else    // 512GB 2^7
    {
        uShift=7;
    }

    u32_Temp_L=0;
    u32_Temp_M=0;

    u32_Temp_L=usLenovoDFhLogPtr->SLCNANDWriteIn512KBLower<<uShift;
    u32_Temp_M=((usLenovoDFhLogPtr->SLCNANDWriteIn512KBMiddle<<uShift)|(usLenovoDFhLogPtr->SLCNANDWriteIn512KBLower>>(32-uShift)));
    usLenovoDFhLogPtr->SLCNANDWriteIn512KBLower=u32_Temp_L;
    usLenovoDFhLogPtr->SLCNANDWriteIn512KBMiddle=u32_Temp_M;

    u32_Temp_L=usLenovoDFhLogPtr->NANDWriteIn512KBLower<<uShift;
    u32_Temp_M=((usLenovoDFhLogPtr->NANDWriteIn512KBMiddle<<uShift)|(usLenovoDFhLogPtr->NANDWriteIn512KBLower>>(32-uShift)));
    usLenovoDFhLogPtr->NANDWriteIn512KBLower=u32_Temp_L;
    usLenovoDFhLogPtr->NANDWriteIn512KBMiddle=u32_Temp_M;

    u32_Temp_L=usLenovoDFhLogPtr->NANDWriteIn512KBLower;
    usLenovoDFhLogPtr->NANDWriteIn512KBLower+=usLenovoDFhLogPtr->SLCNANDWriteIn512KBLower;

    if(u32_Temp_L>usLenovoDFhLogPtr->NANDWriteIn512KBLower)
    {
        usLenovoDFhLogPtr->NANDWriteIn512KBMiddle++;
    }

    usLenovoDFhLogPtr->NANDWriteIn512KBMiddle+=usLenovoDFhLogPtr->SLCNANDWriteIn512KBMiddle;
    u16NANDWriteInGB=usLenovoDFhLogPtr->NANDWriteIn512KBLower>>11;    // 512KB->GB

    if(u16NANDWriteInGB>65534)
    {
        u16NANDWriteInGB=65535;
    }

    u32cpDesPtr[0x60]=gsBadInfo.u16ProgFailFblkCnt;    // Program Fail Count
    u32cpDesPtr[0x61]=gsBadInfo.u16EraseFailFblkCnt;    // Erase Fail Count
    u32cpDesPtr[0x62]=u16DriveUsedPercentage;    // Wear Leveling Count
    u32cpDesPtr[0x63]=g16TLCGCSpareCnt_Run*2;    // ReservedBlockCountTotal
    u32cpDesPtr[0x64]=gsFtlDbg.u32SlcRetryTableFailCnt+gsFtlDbg.u32TlcRetryTableFailCnt+gsFtlDbg.u32SlcVthTrackingFailCnt+
                       gsFtlDbg.u32TlcVthTrackingFailCnt;    // ECC Fail Count
    u32cpDesPtr[0x65]=u32CRCFailCnt;    // ECRC Error Count
    u32cpDesPtr[0x66]=gsBadInfo.u16TotalNewBadCnt;    // Grown Bad Blocks
    u32cpDesPtr[0x67]=u16NANDWriteInGB;    // Nand GB written
    u32cpDesPtr[0x68]=gsDebugInfo.u32PcieErrCnt3;    // PCIE Link Down
    u32cpDesPtr[0x69]=gsDebugInfo.u32PcieErrCnt4;    // PCIE CPL
    u32cpDesPtr[0x6A]=gsDebugInfo.u32PcieErrCnt5;    // PCIE Malformed TLP
    u32cpDesPtr[0x6B]=0x45544541;    // TAG-Abnormal event table end (AETE)

    // add FTL Log here
    uLogOffset=((cEventLogSize+cCore1EventLogSize+cLinkLogSize+cCmdListLogSize+cBackEndLogSize)*2)/512;
    garTsb0[uLogOffset][0]=gsRdlinkInfo.ubPwrOnByQBoot;
    garTsb0[uLogOffset][1]=gsRdlinkInfo.ubPwrOnGcF;
    garTsb0[uLogOffset][2]=gSysOpFlag;
    bopCopyRam((LWORD)&garTsb0[uLogOffset][0]+1024-sizeof(DBGLOG), (LWORD)&gsFtlDbg, sizeof(DBGLOG), cCopyTsb2Tsb|cBopWait);
#if 0
    upFtlDebug->u32RRCnt=g32RRCnt;

    // reclaim
    upFtlDebug->u32TotalScrubBlkCnt=g32TotalScrubBlkCnt;

    // Gc
    upFtlDebug->u16MinSpareBlockCnt=g16MinSpareBlockCnt;
    upFtlDebug->u16TlcMinSpareBlockCnt=g16TlcMinSpareBlockCnt;
    upFtlDebug->u32ForceCleanCnt=g32ForceCleanCnt;
    upFtlDebug->u16MaxPushSpareCnt=g16MaxPushSpareCnt;

    // relink
    upFtlDebug->u32PowerOnCnt=g32PowerOnCnt;
    upFtlDebug->u32UGSDPwrOnCnt=g32UGSDPwrOnCnt;
    upFtlDebug->u32GSDPwrOnCnt=g32GSDPwrOnCnt;
    upFtlDebug->ubPwrOnByQBoot=gsRdlinkInfo.ubPwrOnByQBoot;
    upFtlDebug->ubPwrOnGcF=gsRdlinkInfo.ubPwrOnGcF;

    // RW
    upFtlDebug->uStaticMode=gStaticMode;
    // upFtlDebug.u16DummyFailType=g16DummyFailType
    upFtlDebug->uSysOpFlag=gSysOpFlag;    // chk dummy W/R
    upFtlDebug->u64TotalSlcProgCnt=g64TotalSlcProgCnt;
    upFtlDebug->u64TotalTlcOneShotCnt=g64TotalTlcOneShotCnt;
    upFtlDebug->u64TotalHostWrSecCnt=g64TotalHostWrSecCnt;

    // program fail
    upFtlDebug->uPfH2fCnt=gsProgFailInfo.uDgTestCnt[0];
    upFtlDebug->uPfWproCnt=gsProgFailInfo.uDgTestCnt[1];
    upFtlDebug->uPfRaidCnt=gsProgFailInfo.uDgTestCnt[2];
    upFtlDebug->uPfGcDesCnt=gsProgFailInfo.uDgTestCnt[3];
    upFtlDebug->uPfActCacheCnt=gsProgFailInfo.uDgTestCnt[4];

    // raid
    upFtlDebug->u16RaidDecH2fPassCnt=g16RaidDecH2fPassCnt;
    upFtlDebug->u16RaidDecH2fFailCnt=g16RaidDecH2fFailCnt;
    upFtlDebug->u16RaidDecDataPassCnt=g16RaidDecDataPassCnt;
    upFtlDebug->u16RaidDecDataFailCnt=g16RaidDecDataFailCnt;

    // VDT
    upFtlDebug->u32Vdt23FailCnt=g32Vdt23FailCnt;
    upFtlDebug->u32Vdt18FailCnt=g32Vdt18FailCnt;

    // erase fail
    upFtlDebug->u16EraseFailCount=g16EraseFailCount;

    upFtlDebug->u32PfRehCnt=g32PfRehCnt;
    upFtlDebug->u16PfB2bCnt=g16PfB2bCnt;
    upFtlDebug->u16EfB2bCnt=g16EfB2bCnt;
    upFtlDebug->u16MarkBadCount=g16MarkBadCount;
    upFtlDebug->u64BgdClnProcCnt=g64BgdClnProcCnt;
#endif/* if 0 */
    // add Front End Log here
    uLogOffset=(c32FrontEndVarLogPageAddr)/512;
    FRONTENDDBGLOG *upFELog=(FRONTENDDBGLOG *)((void *)(&(garTsb0[uLogOffset][0])));

    bopCopyRam(((LWORD)garTsb0[0])+c32FrontEndVarLogPageAddr, (LWORD)&gsDebugInfo, sizeof(DEBUGINFO), cCopyDccm2Tsb|cBopWait);

    // to-do: assign NAND thermal cnt and asic MT0 cnt
    upFELog->u32NandThermalMT1TranCnt=g32ThermalMT1TranCnt;
    upFELog->u32NandThermalMT1TransitionCount=g32ThermalMT1TransitionCount;
    upFELog->u32NandThermalMT2TranCnt=g32ThermalMT2TranCnt;
    upFELog->u32NandThermalMT2TransitionCount=g32ThermalMT2TransitionCount;

    upFELog->u32NandThermalMT3TranCnt=g32ThermalMT3TranCnt;
    upFELog->u32NandThermalMT3TransitionCount=g32ThermalMT3TransitionCount;
    upFELog->u32AsicThermalMT3TranCnt=g32AsicThermalMT3TranCnt;
    upFELog->u32AsicThermalMT3TransitionCount=g32AsicThermalMT3TransitionCount;

    upFELog->u64PwrOnPs3Cnt=g64PwrOnPs3Cnt;
    upFELog->u64PwrOnPs4Cnt=g64PwrOnPs4Cnt;
    upFELog->u32PwrOnAbortPs3Cnt=g32PwrOnAbortPs3Cnt;
    upFELog->u32PwrOnAbortPs4Cnt=g32PwrOnAbortPs4Cnt;
    upFELog->u32Vdt27FailCnt=g32Vdt27FailCnt;
    upFELog->uTelemetryControllerDataAvail=mChkTelemetryCtlrInfoAvail;
    upFELog->uTelemetryControllerDataGenNum=gTelemetryCtlrGenNum;

    /*
       * g16arTsb0[uLogOffset][0]=g16SaveEventLog;
       * g16arTsb0[uLogOffset][1]=g16SaveEventLog2;
       * g16arTsb0[uLogOffset][2]=g16EventLogPtrBK;
       * g16arTsb0[uLogOffset][3]=g16LinkLogPtrBK;
       * g16arTsb0[uLogOffset][4]=g32CmdHistoryPtr;
       */

    bopCopyRam(((LWORD)garTsb0[0])+c32GcInfoVarLogPageAddr, (LWORD)&gsGcInfo, sizeof(GCINFO), cCopyStcm2Tsb|cBopWait);
    bopCopyRam(((LWORD)garTsb0[0])+c32CacheInfoVarLogPageAddr, (LWORD)&gsCacheInfo, sizeof(CACHEINFO), cCopyStcm2Tsb|cBopWait);
    bopCopyRam(((LWORD)garTsb0[0])+c32BadInfoVarLogPageAddr, (LWORD)&gsBadInfo, sizeof(BADINFO), cCopyStcm2Tsb|cBopWait);

    uLogOffset=gSectorPerPlaneH-1;
    g16arTsb0[uLogOffset][0x1EC/2]=cEventLogBadInfo;
    g16arTsb0[uLogOffset][0x1EE/2]=cEventLogCacheInfo;
    g16arTsb0[uLogOffset][0x1F0/2]=cEventLogGcInfo;
    g16arTsb0[uLogOffset][0x1F2/2]=(cFrontEndLogSize*2);
    g16arTsb0[uLogOffset][0x1F4/2]=(cFTLLogSize*2);
    g16arTsb0[uLogOffset][0x1F6/2]=(cBackEndLogSize*2);
    g16arTsb0[uLogOffset][0x1F8/2]=(cCmdListLogSize*2);
    g16arTsb0[uLogOffset][0x1FA/2]=(cLinkLogSize*2);
    g16arTsb0[uLogOffset][0x1FC/2]=((cCore1EventLogSize)*2);
    g16arTsb0[uLogOffset][0x1FE/2]=((cEventLogSize)*2);

    if(!uDeadLock)
    {
        progWproPageCore0(cWproEventLog, c16Tsb0SIdx);
    }
}    /* saveEventLog */

#endif/* if _EN_SAVEEVTLOG */
#else    // CPUID==1
#if _DEBUG_LOG
void printNandPhyAddr(ADDRINFO *upTmpAddrInfo)
{
    WORD u16FPage;

    /*
       * NLOG(cLogCore1, DEBUGLOGCORE1_C, 1, "Channel #: 0x%04X ", garChMapTable[upTmpAddrInfo->uCh]);
       * NLOG(cLogCore1, DEBUGLOGCORE1_C, 1, "Intlv: 0x%04X ", upTmpAddrInfo->uIntlvAddr);
       * NLOG(cLogCore1, DEBUGLOGCORE1_C, 1, "CE: 0x%04X ", garCeMapTable[upTmpAddrInfo->uCe]);
       * NLOG(cLogCore1, DEBUGLOGCORE1_C, 1, "Die address: 0x%04X ", upTmpAddrInfo->uDieAddr);
       * NLOG(cLogCore1, DEBUGLOGCORE1_C, 1, "Plane address: 0x%04X ", upTmpAddrInfo->uPlaneAddr);
       * NLOG(cLogCore1, DEBUGLOGCORE1_C, 1, "Block address: 0x%04X ",
       *  getDiffFBlock(upTmpAddrInfo->u16FBlock,upTmpAddrInfo->uCh,upTmpAddrInfo->uIntlvAddr,upTmpAddrInfo->uPlaneAddr));
       */

    if((!(mChkMlcMoBit(upTmpAddrInfo->u16FBlock))))
    {
        // SLC
        NLOG(cLogCore1, DEBUGLOG_C, 0, "SLC mode");

        if(mChkFLParam(cWithRlibMo))
        {
            u16FPage=upTmpAddrInfo->u16FPage;
            // NLOG(cLogCore1, DEBUGLOGCORE1_C, 1, "Page: 0x%04X ", upTmpAddrInfo->u16FPage);
        }
        else if(mChkCardMode(cWithSlcMo))
        {
            u16FPage=upTmpAddrInfo->u16FPage<<1;
            // NLOG(cLogCore1, DEBUGLOGCORE1_C, 1, "Page: 0x%04X ", (upTmpAddrInfo->u16FPage<<1));
        }
    }
    else
    {
        // TLC
        NLOG(cLogCore1, DEBUGLOG_C, 0, "TLC mode");
#if (_TSB_BiCS3|_SANDISK_3D_GEN2|_SANDISK_3D_GEN3|_TSB_BiCS4)
        u16FPage=(cProgCntPerWL*(upTmpAddrInfo->u16FPage))+mGetPageSelCmd(upTmpAddrInfo)-1;
        // NLOG(cLogCore1, DEBUGLOGCORE1_C, 1, "Page: 0x%04X ", ((cProgCntPerWL*(upTmpAddrInfo->u16FPage))+mGetPageSelCmd(upTmpAddrInfo)-1));
#endif
    }

    // NLOG(cLogCore1, DEBUGLOGCORE1_C, 1, "Sector address: 0x%04X ", (upTmpAddrInfo->uOrgSectorH));
    // NLOG(cLogCore1, DEBUGLOGCORE1_C, 1, "PE Cnt: 0x%04X ", mGetGlobEraseCnt(upTmpAddrInfo->u16AbstractFBlock));
    NLOG(cLogCore1, DEBUGLOG_C, 4,
         "Ch: 0x%04X,Intlv: 0x%04X,CE: 0x%04X,Die: 0x%04X",
         garChMapTable[upTmpAddrInfo->uCh],
         upTmpAddrInfo->uIntlvAddr,
         garCeMapTable[upTmpAddrInfo->uCe],
         upTmpAddrInfo->uDieAddr);
    NLOG(cLogCore1, DEBUGLOG_C, 4,
         "Plane:0x%04X,Block: 0x%04X,Page: 0x%04X,Sector: 0x%04X",
         upTmpAddrInfo->uPlaneAddr,
         getDiffFBlock(upTmpAddrInfo->u16FBlock, upTmpAddrInfo->uCh, upTmpAddrInfo->uIntlvAddr, upTmpAddrInfo->uPlaneAddr),
         u16FPage,
         upTmpAddrInfo->uSectorH);    // uOrgSectorH);

    NLOG(cLogCore1, DEBUGLOG_C, 4,
         "uOpTyp: 0x%04X,uRwHalfKb: 0x%04X,u16BufPtr: 0x%04X,uSrcIdx: 0x%04X",
         upTmpAddrInfo->uOpTyp,
         upTmpAddrInfo->uRwHalfKb,
         upTmpAddrInfo->u16BufPtr,
         upTmpAddrInfo->uSrcIdx);

    NLOG(cLogCore1, DEBUGLOG_C, 1,
         "PE Cnt: 0x%04X",
         mGetGlobEraseCnt(upTmpAddrInfo->u16AbstractFBlock));
}    /* printNandPhyAddr */

void debugAllChReadFifo(BYTE uOpt)
{
    BYTE uCh=0;
    BYTE uSrcIndexHead;
    BYTE uSrcIndexTrig;
    BYTE uSrcIndexTail;

    if(uOpt==0)
    {
        return;
    }

    for(uCh=0; uCh<gTotalChNum; uCh++)
    {
        uSrcIndexHead=(gsRwCtrl.uChReadFifoIdx[uCh][(gsRwCtrl.uChReadFifoHead[uCh])]);
        NLOG(cLogCore1,
             DEBUGLOG_C,
             5,
             "____gsRwCtrl.uChReadFifoHead[(CH:0x%04X)]: %04d ,SrcIndex= %04d ,RwHalfKb&SectorH= 0x%04X ,uDmaCnt= 0x%04X",
             uCh,
             gsRwCtrl.uChReadFifoHead[uCh],
             uSrcIndexHead,
             (WORD)((garSrcAddrInfo[uSrcIndexHead].uRwHalfKb<<8)|garSrcAddrInfo[uSrcIndexHead].uSectorH),
             garSrcAddrInfo[uSrcIndexHead].uDmaCnt
             );

        uSrcIndexTrig=(gsRwCtrl.uChReadFifoIdx[uCh][(gsRwCtrl.uChReadFifoTrig[uCh])]);
        NLOG(cLogCore1, DEBUGLOG_C, 5, "gsRwCtrl.uChReadFifoTrig[(CH:0x%04X)]: %04d ,SrcIndex= %04d ,RwHalfKb&SectorH= 0x%04X ,uDmaCnt= 0x%04X",
             uCh,
             gsRwCtrl.uChReadFifoTrig[uCh],
             uSrcIndexTrig,
             (WORD)((garSrcAddrInfo[uSrcIndexTrig].uRwHalfKb<<8)|garSrcAddrInfo[uSrcIndexTrig].uSectorH),
             garSrcAddrInfo[uSrcIndexTrig].uDmaCnt
             );

        uSrcIndexTail=(gsRwCtrl.uChReadFifoIdx[uCh][(gsRwCtrl.uChReadFifoTail[uCh])]);
        NLOG(cLogCore1, DEBUGLOG_C, 5, "gsRwCtrl.uChReadFifoTail[(CH:0x%04X)]: %04d ,SrcIndex= %04d ,RwHalfKb&SectorH= 0x%04X ,uDmaCnt= 0x%04X",
             uCh,
             gsRwCtrl.uChReadFifoTail[uCh],
             uSrcIndexTail,
             (WORD)((garSrcAddrInfo[uSrcIndexTail].uRwHalfKb<<8)|garSrcAddrInfo[uSrcIndexTail].uSectorH),
             garSrcAddrInfo[uSrcIndexTail].uDmaCnt
             );

        ///PrCmdAle Q

        uSrcIndexHead=(gsRwCtrl.uChPreFifoIdx[uCh][0][(gsRwCtrl.uChPreFifoHead[uCh][0])]);
        NLOG(cLogCore1, DEBUGLOG_C, 5, "gsRwCtrl.uChPreFifoHead[(CH:0x%04X)]: %04d ,SrcIndex= %04d ,RwHalfKb&SectorH= 0x%04X ,uDmaCnt= 0x%04X",
             uCh,
             gsRwCtrl.uChPreFifoHead[uCh][0],
             uSrcIndexHead,
             (WORD)((garSrcAddrInfo[uSrcIndexHead].uRwHalfKb<<8)|garSrcAddrInfo[uSrcIndexHead].uSectorH),
             garSrcAddrInfo[uSrcIndexHead].uDmaCnt
             );

        uSrcIndexTail=(gsRwCtrl.uChPreFifoIdx[uCh][0][(gsRwCtrl.uChPreFifoTail[uCh][0])]);
        NLOG(cLogCore1, DEBUGLOG_C, 5, "gsRwCtrl.uChPreFifoTail[(CH:0x%04X)]: %04d ,SrcIndex= %04d ,RwHalfKb&SectorH= 0x%04X ,uDmaCnt= 0x%04X",
             uCh,
             gsRwCtrl.uChPreFifoTail[uCh][0],
             uSrcIndexTail,
             (WORD)((garSrcAddrInfo[uSrcIndexTail].uRwHalfKb<<8)|garSrcAddrInfo[uSrcIndexTail].uSectorH),
             garSrcAddrInfo[uSrcIndexTail].uDmaCnt
             );

        NLOG(cLogCore1,
             DEBUGLOG_C,
             4,
             "***gSpareCnt: 0x%04X, gWaitSpareTyp: 0x%04X, gSparePtrHead: 0x%04X, gSparePtrTail: 0x%04X",
             gSpareCnt[uCh],
             gWaitSpareTyp[uCh],
             gSparePtrHead[uCh],
             gSparePtrTail[uCh]);

        uSrcIndexHead=(gsRwCtrl.uChProgFifoIdx[uCh][(gsRwCtrl.uChProgFifoHead[uCh])]);
        NLOG(cLogCore1, DEBUGLOG_C, 5, "gsRwCtrl.uChProgFifoHead[(CH:0x%04X)]: %04d ,DesIndex= %04d ,RwHalfKb&SectorH= 0x%04X ,uSprOpt= 0x%04X",
             uCh,
             gsRwCtrl.uChProgFifoHead[uCh],
             uSrcIndexHead,
             (WORD)((garDesAddrInfo[uSrcIndexHead].uRwHalfKb<<8)|garDesAddrInfo[uSrcIndexHead].uSectorH),
             garDesAddrInfo[uSrcIndexHead].uSprOpt
             );

        uSrcIndexTrig=(gsRwCtrl.uChProgFifoIdx[uCh][(gsRwCtrl.uChProgFifoTrig[uCh])]);
        NLOG(cLogCore1, DEBUGLOG_C, 5, "gsRwCtrl.uChProgFifoTrig[(CH:0x%04X)]: %04d ,DesIndex= %04d ,RwHalfKb&SectorH= 0x%04X ,uSprOpt= 0x%04X",
             uCh,
             gsRwCtrl.uChProgFifoTrig[uCh],
             uSrcIndexTrig,
             (WORD)((garDesAddrInfo[uSrcIndexTrig].uRwHalfKb<<8)|garDesAddrInfo[uSrcIndexTrig].uSectorH),
             garDesAddrInfo[uSrcIndexTrig].uSprOpt
             );

        uSrcIndexTail=(gsRwCtrl.uChProgFifoIdx[uCh][(gsRwCtrl.uChProgFifoTail[uCh])]);
        NLOG(cLogCore1, DEBUGLOG_C, 5, "gsRwCtrl.uChProgFifoTail[(CH:0x%04X)]: %04d ,DesIndex= %04d ,RwHalfKb&SectorH= 0x%04X ,uSprOpt= 0x%04X",
             uCh,
             gsRwCtrl.uChProgFifoTail[uCh],
             uSrcIndexTail,
             (WORD)((garDesAddrInfo[uSrcIndexTail].uRwHalfKb<<8)|garDesAddrInfo[uSrcIndexTail].uSectorH),
             garDesAddrInfo[uSrcIndexTail].uSprOpt
             );
    }
}    /* debugAllChReadFifo */

void debugTSBflag(BYTE uOpt)
{
    WORD u16Index;

    if(uOpt==0)
    {
        return;
    }

    for(u16Index=0; u16Index<0x60; u16Index++)
    {
        if(rTsbCtrl[rcBuf0Flag+(u16Index)]!=0)
        {
            NLOG(cLogCore1, DEBUGLOG_C, 2, "rTsbCtrl[rcBuf0Flag+( 0x%04X)] : 0x%04X", u16Index, rTsbCtrl[rcBuf0Flag+(u16Index)]);
        }
    }

    for(u16Index=0; u16Index<0x60; u16Index++)
    {
        if(rTsbCtrl[rcBuf0RaidFlag+(u16Index)]!=0)
        {
            NLOG(cLogCore1, DEBUGLOG_C, 2, "rTsbCtrl[rcBuf0RaidFlag+( 0x%04X)] : 0x%04X", u16Index, rTsbCtrl[rcBuf0RaidFlag+(u16Index)]);
        }
    }
}    /* debugTSBflag */

void getPfRtcTime(LWORD u32PfProcTime)
{
    if(u32PfProcTime)
    {
        u32PfProcTime=getRtcCurrent32k()-u32PfProcTime;

        if(u32PfProcTime>gsProgFailInfo.u32MaxPfProcTime)
        {
            gsProgFailInfo.u32MaxPfProcTime=u32PfProcTime;
            NLOG(cLogCore1, DEBUGLOG_C, 0, "Max Pf Proc Time");
        }

        NLOG(cLogCore1, DEBUGLOG_C, 2, "u32PfProcTime: %08D", u32PfProcTime>>16, u32PfProcTime);
    }
}

#endif/* if _DEBUG_LOG */
#endif/* if (_CPUID==0) */

#if (!_ICE_LOAD_ALL)
#pragma default_function_attributes =
#endif







