







#include "inc/ProType.h"
// #include "inc/FlashCtrl.h"
#include "inc/GlobVar0.h"
#include "inc/Const.h"
#include "inc/GlobVarS.h"
#include "inc/GlobVarT.h"
#include "inc/Reg.h"
#include "inc/FtlCtrl.h"
#include "inc/Mac.h"
#include "inc/BitDef.h"

/*
   * BYTE chkBgdClnH2fTabBlk()    // BYTE uCaller)
   * {
   *  if(gsCacheInfo.uH2fTabBlockCnt<gsGcInfo.uGcH2fTabbHiThr)
   *  {
   *      return cFalse;
   *  }
   *  else if(mChkSataWriteAbort)
   *  {
   *      return cFalse;
   *  }
   *  else
   *  {
   *      return cTrue;
   *  }
   * }
   */
/*
   * LWORD bopSrhH2fTabBlkIdx(BYTE uBlkIdx, WORD u16StOfst, LWORD u32MskTargt)
   * {
   *  BYTE uSrhPtr;
   *  BYTE uSrhCnt=(1<<(gsCacheInfo.uH2fTabPagePtrShift-8));
   *
   *  rmRstBopParam;
   *  rmSetBopDataDir(cBopTsb2Bvci);
   *  rmSetBopSrcAddr((LWORD)g16arH2fTabPtr);
   *  rmSetBopDesAddr(u16StOfst);
   *  rmSetBopXfrLen(g16TotalHBlock+c16HmbMaxTableNum);
   *  rmSetSrchMode(cBopSrchDat|cBopWordMo);
   *  // rmSetSrchMsk(cSrchLword1); //check 2263
   *  rmSetSrchMsk(0x0000FF00);
   *  rmDisSrchSkip;
   *  rmClrSrchRslVal;
   *
   *  for(uSrhPtr=0; uSrhPtr<uSrhCnt; uSrhPtr++)
   *  {
   *      if((u32MskTargt&cb32BitTab[uSrhPtr])!=0)
   *      {
   *          rmSetSrchRslVal(uSrhPtr, (LWORD)((uBlkIdx<<(gsCacheInfo.uH2fTabPagePtrShift-8)|uSrhPtr)<<8));
   *      }
   *  }
   *
   *  rmTrigBopOp(0, cBopSrchOp);
   *
   *  while(rmChkBopBz)
   *      ;
   *
   *  rmRstSrchMsk;
   *  return r32BopCtrl[rcSrchBitMap];
   * }
   */

WORD addReadBufPtrH2fGc(WORD u16SbufPtr, LWORD u32AddCnt)
{
    // u32AddCnt=mod(u32AddCnt, c16ReadBufSize);    // u32AddCnt&(c16ReadBufSize-1);
    while(u32AddCnt>=c16GcH2fBufSize)
    {
        u32AddCnt-=c16GcH2fBufSize;
    }

    u16SbufPtr+=u32AddCnt;

    if(u16SbufPtr>=(c16ReadSIdx+c16GcH2fBufSize))
    {
        u16SbufPtr-=c16GcH2fBufSize;
    }

    return u16SbufPtr;
}

void trigH2FProg()
{
    gsRwCtrl.u32FreeSrcFifoHead=gsGcInfo.uPreSrcFifo;

    while((gsRwCtrl.u32FreeSrcFifoTail!=gsRwCtrl.u32FreeSrcFifoHead)||g32DecodeWait)
        ;

    ;

    gsRwCtrl.u32ProgFifoHead=gsGcInfo.uPreProgFifo;

    while(gsRwCtrl.u32ProgFifoTail!=gsRwCtrl.u32ProgFifoHead)
        ;
}

void bgdClnH2fTabblkProc()
{
    WORD u16RbufPtr, u16WbufPtr, u16Hblock, u16SrchRst, u16SaveHMBIdx, u16MinVpc;
    BYTE uPageOfst, uPlaneCnt, uH2fBlkCnt, uH2fBlkIdx;
    BYTE uBreak;

    // g32Rtc32kStartVal=rmGetRtc32kTick;  //sync from fw2, if fw1 need to caluate GcH2fTableProcTimer

#if _GREYBOX
    outCS(cbTagbgdClnH2fTabblkProc);

    if((gsGbInfo.uGreyBoxItem==cUGSDGcH2fTableID)&&(gsGbInfo.uGreyBoxOpt==cVOpProgCacheInfoH2fFull)&&(gsGbInfo.uStag==cVsIdl))
    {
        while(gsCacheInfo.u16H2fTabFreePagePtr<(gsCacheInfo.u16H2fTabPagePerBlk3-6))    //
        {
            // dummy page
            mSetCacheInfoChangeFlag(cH2fChg);
            progH2fTableCore0(c16Tsb0SIdx, c16BitFF, c16Bit0|c16Bit2|c16Bit15, cInupdateH2fTabWindow_00, cInBoot|cInBootWaitAllDie);
        }
    }
#endif

    while(gsRwCtrl.u16ProgPageOfst)
        ;

    save1stCacheInfoBefW();
    // mSetInGcFlow;
    prog1stInvQBootInWpro();
    rstRdyTyp();

    if((gsCacheInfo.uH2fTabBlockCnt/4)>=1)
    {
        gsGcInfo.u32BgdGcEndTime=gsGcInfo.u32BgdGcEndTime*(gsCacheInfo.uH2fTabBlockCnt/4);
    }

    // getBrkBgdGcF();
    mSetGcFlag(cUnderGcH2fTab);
    gsGcInfo.uPreProgFifo=gsRwCtrl.u32ProgFifoHead;
    gsGcInfo.uPreSrcFifo=gsRwCtrl.u32FreeSrcFifoHead;
    // bkOneShotChPtr();
    u16RbufPtr=u16WbufPtr=c16CopySIdx;

    while((getBrkBgdGcF()!=cTrue)&&(chkExitGcH2fTabProc()!=cTrue))
    {
        uH2fBlkCnt=gsCacheInfo.uH2fTabBlockCnt;
        uH2fBlkIdx=0;
        u16MinVpc=0xFFFF;

        while(uH2fBlkCnt!=0)
        {
            if(g16arH2fTabBlk[uH2fBlkIdx]!=0xFFFF)
            {
#if _EN_SLCOpenBlkReadScrub
                if(mChkGcFlag(cReadScrubH2F))
                {
                    if(gsGcInfo.u16H2FReclaimBlk==c16FBlockInitValue)
                    {
                        gsFtlDbg.u16DummyFailType=cBgdClnH2fTabblkProc;
                        debugWhile();
                    }
                    else if(g16arH2fTabBlk[uH2fBlkIdx]==gsGcInfo.u16H2FReclaimBlk)
                    {
                        gsGcInfo.uGcH2fTabBlkIdx=uH2fBlkIdx;
                    }
                }
                else
#endif
                {
                    if((uH2fBlkIdx!=gsCacheInfo.uActH2fTabBlkIdx)&&(g16arH2fTabBlkVpCnt[uH2fBlkIdx]<u16MinVpc))
                    {
                        u16MinVpc=g16arH2fTabBlkVpCnt[uH2fBlkIdx];
                        gsGcInfo.uGcH2fTabBlkIdx=uH2fBlkIdx;
                    }
                }

                uH2fBlkCnt--;
            }

            uH2fBlkIdx++;
        }

#if _GREYBOX
        LWORD u32SaveVpcBefore=cb32BitNumTab[cZero];
        // BYTE uH2fBlkIdx;

        if((gsGbInfo.uGreyBoxItem==cTabHdlGcH2f)&&(gsGbInfo.uStag==cVsIdl))
        {
            outInfo(cGbH2fInfo);

            for(uH2fBlkIdx=0; uH2fBlkIdx<gMaxH2fTabBlkNum; uH2fBlkIdx++)
            {
                u32SaveVpcBefore+=g16arH2fTabBlkVpCnt[uH2fBlkIdx];
            }
        }
#endif
        u16SrchRst=0;
        uBreak=0;

        while((!mChkGcFlag(cBrkBgdGcF)&&
               (bopSrchRam((LWORD)g16arH2fTabPtr, (LWORD)gsGcInfo.uGcH2fTabBlkIdx<<gsCacheInfo.uH2fTabPagePtrShift,
                           (LWORD) ~gsCacheInfo.u16H2fTabPagePtrMsk, u16SrchRst, g16TotalHBlock+g16HmbMaxTableNum,
                           cBopSrchDat|cBopWordMo|cBopWait)!=0xFFFF))&&(!uBreak))
        {
            u16SrchRst=rmGetSrchRslOfst;    // r32BopCtrl[rcSrhTgt0+uSrhPtr];
            u16Hblock=u16SrchRst;

            if(u16Hblock>=g16TotalHBlock)
            {
                u16SaveHMBIdx=u16Hblock-g16TotalHBlock;
                u16Hblock=g16arH2fBackup[u16SaveHMBIdx];
            }

            if(mChkCacheInfoFlag(cH2fTabBlockFull)||mChkCacheInfoFlag(cH2fProgramFail))
            {
                initH2fTabFblock(0);
                // rstRdyTyp();
            }

            postReadH2fPage(u16RbufPtr, u16Hblock);
#if _GREYBOX
            if((gsGbInfo.uGreyBoxItem==cTabHdlGcH2f)&&(gsCacheInfo.uH2fTabBlockCnt>gsGcInfo.uGcH2fTabbLoThr))
            {
                *(BYTE *)(c32GreyBoxBuf+u16Hblock)=cTrue;
            }
#endif
            u16RbufPtr=addReadBufPtrH2fGc(u16RbufPtr, ((LWORD)gTotalPlaneOfH2fTab*gSectorPerPlaneH));

            for(uPageOfst=0; uPageOfst<gPage4kPerH2fTab; uPageOfst+=g4kNumPerPage)
            {
                gpFlashAddrInfo=&garDesAddrInfo[gsGcInfo.uPreProgFifo];
                mSetTabSpr(gpFlashAddrInfo, cBit5);    // gpFlashAddrInfo->uTabSpar=1;

                setWriteDes(uPageOfst, gpFlashAddrInfo, cWriteH2fTab);
                gSectorH=0;

                gpFlashAddrInfo->uPlaneCnt=gPlaneNum;

                for(uPlaneCnt=gPlaneAddr; uPlaneCnt<gpFlashAddrInfo->uPlaneCnt; uPlaneCnt++)
                {
                    garDesF2hInfo[gsGcInfo.uPreProgFifo].u16arHBlock[uPlaneCnt]=u16Hblock;
                }

                mSetFRwParam(u16WbufPtr,
                             gSectorPerPlaneH*gpFlashAddrInfo->uPlaneCnt,
                             c16Bit0|c16Bit1|c16Bit2|c16Bit6|c16Bit15,
                             cMoveProgData);

                // gpFlashAddrInfo->u16OneShotBufPtr[cLSB]=u16WbufPtr;
                gpFlashAddrInfo->u16BufPtr=u16WbufPtr;

                mSetH2fSpr1;
                mSetH2fSpr2;
                // mSetH2fSprSerial;
                gpFlashAddrInfo->uAddrOpt&=~(cDone|cProgFail);
                gsGcInfo.uPreProgFifo=addWrFfPtrBy1(gsGcInfo.uPreProgFifo);
                u16WbufPtr=addReadBufPtrH2fGc(u16WbufPtr, gpFlashAddrInfo->uRwHalfKb);
            }

            setH2fTabPagePtr(u16Hblock, gsCacheInfo.uActH2fTabBlkIdx, gsCacheInfo.u16H2fTabFreePagePtr);

            gsCacheInfo.u16H2fTabFreePagePtr++;

#if _EN_SLCOpenBlkReadScrub
            if(gsCacheInfo.uActH2fTabBlkIdx==gsGcInfo.uGcH2fTabBlkIdx)
            {
                if((g16TotalHBlock+g16HmbMaxTableNum-1)==u16SrchRst)
                {
                    uBreak=1;
                    u16RbufPtr=c16CopySIdx;
                }
                else
                {
                    u16SrchRst++;
                }
            }
#endif

            if(jdgH2fTabBlockFull()||(u16RbufPtr==c16CopySIdx))
            {
                u16RbufPtr=c16CopySIdx;
                u16WbufPtr=c16CopySIdx;
                trigH2FProg();

                if(mChkCacheInfoFlag(cH2fTabBlockFull))
                {
#if _GREYBOX
                    if((gsGbInfo.uGreyBoxItem==cUGSDGcH2fTableID)&&(gsGbInfo.uGreyBoxOpt==cVOpProgCacheInfoH2fFull)&&(gsGbInfo.uStag==cVsIdl))
                    {
                        trigGreyBox(cTrue);
                    }
#endif
                    progCacheInfoTab();
#if _EN_VPC_SWAP
                    // for vpc swap, readwpro will change gsRwCtrl.u32FreeSrcFifoHead, initial gsGcInfo.uPreSrcFifo
                    gsGcInfo.uPreSrcFifo=gsRwCtrl.u32FreeSrcFifoHead;
#endif
                }

                getBrkBgdGcF();
            }
        }

#if _GREYBOX
        if((gsGbInfo.uGreyBoxItem==cTabHdlGcH2f)&&(gsGbInfo.uStag==cVsIdl))
        {
            outInfo(cGbH2fInfo);
            LWORD u32SaveVpcAfter=cb32BitNumTab[cZero];

            for(uH2fBlkIdx=0; uH2fBlkIdx<gMaxH2fTabBlkNum; uH2fBlkIdx++)
            {
                u32SaveVpcAfter+=g16arH2fTabBlkVpCnt[uH2fBlkIdx];
            }

            if(u32SaveVpcBefore!=u32SaveVpcAfter)
            {
                gsGbInfo.uResult=cFail;
            }

            if((gsCacheInfo.uH2fTabBlockCnt<=gsGcInfo.uGcH2fTabbLoThr))
            {
                trigGreyBox(cFalse);
            }
        }
#endif/* if _GREYBOX */
#if _EN_SLCOpenBlkReadScrub
        if(gsCacheInfo.uActH2fTabBlkIdx==gsGcInfo.uGcH2fTabBlkIdx)
        {
            trigH2FProg();
        }
#endif
    }

    trigH2FProg();
    gsRwCtrl.u32UpdFifoPtr=gsRwCtrl.u32ProgFifoTail;
    gsRwCtrl.u32SrchFifoPtr=gsRwCtrl.u32UpdFifoPtr;    // align  gsRwCtrl.u32SrchFifoPtr & gsRwCtrl.u32UpdFifoPtr

    // restoOneShotChPtr();
    waitAllChCeBzCore0();

    if(mChkGcFlag(cBrkBgdGcF))
    {
        mClrGcFlag(cBrkBgdGcF);
    }

#if _GREYBOX
    if((gsGbInfo.uGreyBoxItem==cUGSDGcH2fTableID)&&(gsGbInfo.uGreyBoxOpt==cVOpBeforePushSpareQ)&&(gsGbInfo.uStag==cVsIdl))
    {
        triggerUGSD(cFalse);
    }
#endif
    chkPushSpareQCore0(0);
#if _GREYBOX
    if((gsGbInfo.uGreyBoxItem==cUGSDGcH2fTableID)&&(gsGbInfo.uGreyBoxOpt==cVOpAfterPushSpareQ)&&(gsGbInfo.uStag==cVsIdl))
    {
        triggerUGSD(cFalse);
    }
#endif
    // mClrInGcFlow;
    rstRdyTyp();
    mClrGcFlag(cUnderGcH2fTab);

    // gsGcInfo.u32CurrGcH2fTabProcTime+=chkRtc32kProcTime(g32Rtc32kStartVal);  //sync from fw2, if fw1 need to caluate GcH2fTableProcTimer
}    /* bgdClnH2fTabblkProc */

void postReadH2fPage(WORD u16SbufPtr, WORD u16Hblock)
{
    WORD u16FBlock, u16NowNodeIdx;
    BYTE uRead4kCnt;
    LWORD u32FPage;

    if(mChkHmbLink(u16Hblock))
    {
        u16FBlock=g16arH2fTabBlk[mGetH2fTabBlkIndex(g16TotalHBlock+mGetHmbLink(u16Hblock))];
        u32FPage=(mGetH2fTabPagePtr(g16TotalHBlock+mGetHmbLink(u16Hblock)))*gPage4kPerH2fTab;
    }
    else
    {
        u16FBlock=g16arH2fTabBlk[mGetH2fTabBlkIndex(u16Hblock)];
        u32FPage=(mGetH2fTabPagePtr(u16Hblock))*gPage4kPerH2fTab;
    }

    uRead4kCnt=gPage4kPerH2fTab;

    while(uRead4kCnt!=0)
    {
        u16NowNodeIdx=gsRwCtrl.uarFreeSrcQue[gsGcInfo.uPreSrcFifo];
        gpFlashAddrInfo=&garSrcAddrInfo[u16NowNodeIdx];
        g16FBlock=u16FBlock;
        g32FPageNoTran=u32FPage;
        g16FPage=g32FPageNoTran;
        gpFlashAddrInfo->uTsb4kIdx=0xFF;
        gpFlashAddrInfo->uSrcIdx=u16NowNodeIdx;
        tranAddrInfo(gpFlashAddrInfo);
        // tranCeNum(gpFlashAddrInfo);
        gSectorH=0;
        mSetFRwParam(u16SbufPtr, g4kNumPerPage*cSctrPer4k, c16Bit0|c16Bit1|c16Bit4|c16Bit6|c16Bit7|c16Bit15, cH2fReadTab);
        gpFlashAddrInfo->uPrdPtr=cBit6;
        // gsCacheInfo.ubPrep++;
        gsGcInfo.uPreSrcFifo=(gsGcInfo.uPreSrcFifo+1)&(cReadFifoDpt-1);
        u32FPage+=g4kNumPerPage;
        u16SbufPtr+=g4kNumPerPage*cSctrPer4k;
        uRead4kCnt-=g4kNumPerPage;
    }
}    /* postReadH2fPage */

BYTE chkExitGcH2fTabProc()
{
    if(!mChkGcQue(cGcTypH2fTab)&&!mChkGcFlag(cReadScrubH2F))    // gsCacheInfo.uH2fTabBlockCnt<=gsGcInfo.uGcH2fTabbLoThr)
    {}
    else if(gsCacheInfo.u16SpareBlockCnt<=cSprbCnt2ExitGcTab)
    {}
    else
    {
        return cFalse;
    }

    return cTrue;
}    /* chkExitGcProc */







