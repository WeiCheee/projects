







void genInternalDataCrc(WORD u16BufPtr, WORD u16SctCnt, LWORD u32Lba, BYTE uType)
{
    gsE2eInfo.u32GenerateCnt[uType]++;

#if (_GREYBOX)
    if((gsGbInfo.uGreyBoxItem==cErrHdlE2EHostData)&&(gsGbInfo.uGreyBoxOpt==cVOpE2EBopGenChkErr))
    {
        gsE2eInfo.u32GenerateLba=u32Lba+1;
    }
    else
#endif
    {
        gsE2eInfo.u32GenerateLba=u32Lba;
    }

#if (_CPUID==1)
    hdmaCopyRam((LWORD)(c32Tsb0SAddr+(u16BufPtr*0x0200)),
                (LWORD)(c32Tsb0SAddr+(u16BufPtr*0x0200)),
                (LWORD)(u16SctCnt*0x0200),
                cCopyTsb2Tsb|cHdmaWait|cHdmaEnCrc|cHdmaGenCrc);
#else
    bopCopyRam((LWORD)(c32Tsb0SAddr+(u16BufPtr*0x0200)),
               (LWORD)(c32Tsb0SAddr+(u16BufPtr*0x0200)),
               (LWORD)(u16SctCnt*0x0200),
               cCopyTsb2Tsb|cBopWait|cBopEnCrc|cBopGenCrc);
#endif
}    /* genInternalDataCrc */

#if _ENABLE_E2E_TAB
BYTE chkInternalDataCrc(WORD u16BufPtr, WORD u16SctCnt, LWORD u32Lba, BYTE uType)
{
    // LWORD u32CrcFailSector;
    BYTE uCrcFailCnt;

    gsE2eInfo.u32CompareCnt[uType]++;
    gsE2eInfo.u32CompareLba=u32Lba;
#if (_CPUID==1)
    hdmaCopyRam((LWORD)(c32Tsb0SAddr+(u16BufPtr*0x0200)),
                (LWORD)(c32Tsb0SAddr+(u16BufPtr*0x0200)),
                (LWORD)(u16SctCnt*0x0200),
                cCopyTsb2Tsb|cHdmaWait|cHdmaEnCrc|cHdmaCmpCrc);
    uCrcFailCnt=rmGetHdmaCrcFailCnt;
    // u32CrcFailSector=rmGetHdmaCrcFailSector;
#else
    bopCopyRam((LWORD)(c32Tsb0SAddr+(u16BufPtr*0x0200)),
               (LWORD)(c32Tsb0SAddr+(u16BufPtr*0x0200)),
               (LWORD)(u16SctCnt*0x0200),
               cCopyTsb2Tsb|cBopWait|cBopEnCrc|cBopCmpCrc);
    uCrcFailCnt=rmGetBopCrcFailCnt;
    // u32CrcFailSector=rmGetBopCrcFailSector;
#endif

    if(uCrcFailCnt)
    {
        gsE2eInfo.u32InternalDataCrcCnt[uType]++;

        // NLOG(cLogError, E2E_C, 7, "Internal Data happened E2E, Type:0x%01X, Cnt:0x%04X, Start Addr:0x%04X ,E2E Addr:0x%04X",
        //    uType, gsE2eInfo.u32InternalDataCrcCnt[uType]>>16, gsE2eInfo.u32InternalDataCrcCnt[uType], u32Lba>>16, u32Lba,
        // u32CrcFailSector>>16, u32CrcFailSector);

#if _ENABLE_E2E_WHILE
        while(gsE2eInfo.u32InternalDataCrcCnt[uType])
            ;
#endif
    }

    return uCrcFailCnt;
}    /* chkInternalDataCrc */

BYTE chkReadTableCrcCnt(ADDRINFO *upRdSrcAddr)
{
    BYTE uTabCrcCnt=0;

    if((upRdSrcAddr->uOpTyp==cH2fReadTab)||(upRdSrcAddr->uOpTyp==cH2fRead1kTab))
    {
#if _ENABLE_E2E_WHILE
        while(gsE2eInfo.uTableType!=cE2eUserDataBlk)
            ;
#endif
        uTabCrcCnt=chkInternalDataCrc(upRdSrcAddr->u16BufPtr, upRdSrcAddr->uRwHalfKb,
                                      (upRdSrcAddr->u32FPageNoTran<<cSctrTo4kShift)+(upRdSrcAddr->uOrgSectorH&(cSctrPer4k-1)),
                                      (upRdSrcAddr->uOpTyp==cH2fReadTab)?cE2eH2fBlk:cE2eH2f1kBlk);
    }
    else if(upRdSrcAddr->uOpTyp==cReadData)
    {
        if(gsE2eInfo.uTableType==cE2eInfoBlk)
        {
            uTabCrcCnt=chkInternalDataCrc(upRdSrcAddr->u16BufPtr, upRdSrcAddr->uRwHalfKb,
                                          upRdSrcAddr->u16FPage*gSectorPerPlaneH+upRdSrcAddr->uSectorH, gsE2eInfo.uTableType);
        }
        else if(gsE2eInfo.uTableType==cE2eWproBlk)
        {
            uTabCrcCnt=chkInternalDataCrc(upRdSrcAddr->u16BufPtr, upRdSrcAddr->uRwHalfKb,
                                          upRdSrcAddr->u32FPageNoTran*gSectorPerPlaneH, gsE2eInfo.uTableType);
        }
    }

    return uTabCrcCnt;
}    /* chkReadTableCrcCnt */

#endif/* if _ENABLE_E2E_TAB */







