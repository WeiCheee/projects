







/*
   ****************************************************
   *      Interrupt Service Routine
   ****************************************************
   */
#include "inc/DebugLog.h"
#include "inc/EventLogIDX.h"
#include "inc/EventLogFunctionIDX.h"
#include "inc/Option.h"
#include "inc/NvmeCtrl.h"
#include "inc/ProType.h"
#include "inc/GlobVarS.h"
#include "inc/Reg.h"

#if (!_ICE_LOAD_ALL)
#pragma default_function_attributes = @ ".ISR"
#endif

CBYTE cbTsbErrPcieLdpcMap[4]=
{
    0x10, 0x11, 0x12, 0x13,
};

CBYTE cbTsbErrCpuDmaMap[8]=
{
    0x0A, 0x08, 0x0B, 0x09, 0x0C, 0x0D, 0x0E, 0x0F,
};

// SVC exception handler is implemented here
__irq __arm void SVCHandler()
{
    while(1)
        ;// not implemented
}

// IRQ handler is implemented here, this handler will be instead by asm handler in the future
__irq __arm void IRQHandler()
{
    while(1)
        ;// not implemented
}

// FIQ exception handler is implemented here, this handler will be instead by asm handler in the future
__irq __arm void FIQHandler()
{
    while(1)
        ;// not implemented
}

// Undefined instruction exception handler is implemented here
__irq __arm void UndefinedHandler()
{
    errorHandler(cSaveIdUndefinedErr);
}

// Abort exception handler is implemented here
__irq __arm void AbortHandler()
{
#if _WHILE4ECC_ISR
    errorHandler(cSaveIdAbortErr);
#else

    if(rmChkTsbErr||rmChkTsb4Err)
    {
        g32abortcnt++;    // for break point,useless
    }
    else
    {
        while(1)
            ;// not implemented
    }
#endif
}

// Prefetch exception handler is implemented here
__irq __arm void PrefetchHandler()
{
#if _WHILE4ECC_ISR
    errorHandler(cSaveIdPrefetchErr);
#else
    asm ("MRC p15, 0, r1, c5, c0, 1 ");    // Read IFSR
    asm ("MOV r1, #0");
    asm ("MCR p15, 0, r1, c5, c0, 1 ");    // Read IFSR
    asm ("MRC p15, 0, r1, c5, c0, 1 ");    // Read IFSR
    asm ("SUB PC, LR, #0");
#endif
}

// Anytime to call this function means want to drive hang for logging
void errorHandler(BYTE uErrorSaveId)
{
    LWORD u32Info, u32Addr=0xFFFFFFFF, u32Loop;
    BYTE uType;

    // rmSysEnFwp;

    // RequestCore1Hang();

    // if((uErrorSaveId==cSaveIdVdt23Fsh1Fail)||(uErrorSaveId==cSaveIdVdt27Fsh2Fail)||(uErrorSaveId==cSaveIdVdt12FioFail))
    // {
    //    sysDelay(400000);    // ~ 1 to 3 ms
    //
    // wait for VDT back
    //   while(!(rmChkVdt23Fsh1Good&&rmChkVdt27Fsh2Good&&rmChkVdt12FioGood))
    //       ;
    // }

    // rmSysDisFwp;

    if((uErrorSaveId==cSaveIdUndefinedErr)||(uErrorSaveId==cSaveIdPrefetchErr))
    {
        // steve Read IFAR
        NLOG(cLogError, ISR0_C, 2, "ARM error handler IFAR: 0x%08X ", __MRC(15, 0, 6, 0, 2)>>16, __MRC(15, 0, 6, 0, 2));
        // steve Read IFSR
        NLOG(cLogError, ISR0_C, 4, "ARM error handlerr IFSR: 0x%08X, 1 bit error cpu status: 0x%04X, 2 bits error cpu status: 0x%04X",
             __MRC(15, 0, 5, 0, 2)>>16, __MRC(15, 0, 5, 0, 2), rmCohEccCorFail, rmCohEccErrFail);
    }
    else if(uErrorSaveId==cSaveIdAbortErr)
    {
        // steve Read DFAR
        NLOG(cLogError, ISR0_C, 2, "ARM error handler DFAR: 0x%08X ", __MRC(15, 0, 6, 0, 0)>>16, __MRC(15, 0, 6, 0, 0));
        // steve Read DFSR
        NLOG(cLogError, ISR0_C, 4, "ARM error handlerr DFSR: 0x%08X, 1 bit error cpu status: 0x%04X, 2 bits error cpu status: 0x%04X",
             __MRC(15, 0, 5, 0, 0)>>16, __MRC(15, 0, 5, 0, 0), rmCohEccCorFail, rmCohEccErrFail);

        if(__MRC(15, 0, 6, 0, 0)==(LWORD)(&gsOccuMutexInfo.u32Lock))
        {
            return;
        }
    }
    else if(uErrorSaveId==cSaveIdDmaError)
    {
        NLOG_SAVE(cLogError, ISR0_C, 1, cSaveIdDmaError, " NVMe DMA error, DMA error bitmap=0x%04X ", rmChkNvmeDmaErrorInt);
#if 1

        for(uType=0; uType<4; uType++)
        {
            NLOG(cLogError, ISR0_C, 4, " DMA Status [x]=0x%08X, [X+1]=0x%08X ", rmGetDmaStatus(uType*2)>>16, rmGetDmaStatus(
                     uType*2), rmGetDmaStatus(
                     uType*2+1)>>16, rmGetDmaStatus(uType*2+1));
        }

#else
        NLOG(cLogError, ISR0_C, 4, " DMA Status [0]=0x%08X, [1]=0x%08X ", rmGetDmaStatus(0)>>16, rmGetDmaStatus(0), rmGetDmaStatus(
                 1)>>16, rmGetDmaStatus(1));
        NLOG(cLogError, ISR0_C, 4, " DMA Status [2]=0x%08X, [3]=0x%08X ", rmGetDmaStatus(2)>>16, rmGetDmaStatus(2), rmGetDmaStatus(
                 3)>>16, rmGetDmaStatus(3));
        NLOG(cLogError, ISR0_C, 4, " DMA Status [4]=0x%08X, [5]=0x%08X ", rmGetDmaStatus(4)>>16, rmGetDmaStatus(4), rmGetDmaStatus(
                 5)>>16, rmGetDmaStatus(5));
        NLOG(cLogError, ISR0_C, 4, " DMA Status [6]=0x%08X, [7]=0x%08X ", rmGetDmaStatus(6)>>16, rmGetDmaStatus(6), rmGetDmaStatus(
                 7)>>16, rmGetDmaStatus(7));
#endif
    }
    else if(uErrorSaveId==cSaveIdTsbBusTimeout)
    {
        // sysDelay(30);
        if(!rmChkTsbErr)
        {
            // TSB error
            return;
        }

        if(rmChkTsbErrPcieLdpc)
        {
            for(u32Loop=0; u32Loop<4; u32Loop++)
            {
                if(rmGetTsbSelErrPcieLdpc&cbBitTab[u32Loop])
                {
                    rmSetTsbMSel(cbTsbErrPcieLdpcMap[u32Loop]);
                    u32Loop=4;
                }
            }

#if 0    // for code size

            if(rmGetTsbSelErrPcieLdpc&cBit0)
            {
                rmSetTsbMSel(0x10);
            }
            else if(rmGetTsbSelErrPcieLdpc&cBit1)
            {
                rmSetTsbMSel(0x11);
            }
            else if(rmGetTsbSelErrPcieLdpc&cBit2)
            {
                rmSetTsbMSel(0x12);
            }
            else if(rmGetTsbSelErrPcieLdpc&cBit3)
            {
                rmSetTsbMSel(0x13);
            }
#endif/* if 0 */
            NLOG(cLogError,
                 ISR0_C,
                 4,
                 " TSB_Bus_TIMEOUT(PCIE OR LDPC), Address = 0x%08X, Package Length = 0x%04X, Source = 0x%04X ",
                 rmGetTsbDebugAddress>>16,
                 rmGetTsbDebugAddress,
                 rmGetTsbDebugTsfCnt,
                 rmGetTsbSelErrFlash);
        }
        else if(rmChkTsbErrCpuDma)
        {
            for(u32Loop=0; u32Loop<8; u32Loop++)
            {
                if(rmGetTsbSelErrCpuDma&cbBitTab[u32Loop])
                {
                    rmSetTsbMSel(cbTsbErrCpuDmaMap[u32Loop]);
                    u32Loop=8;
                }
            }

#if 0    // for code size

            if(rmGetTsbSelErrCpuDma&cBit0)
            {
                rmSetTsbMSel(0x0A);
            }
            else if(rmGetTsbSelErrCpuDma&cBit1)
            {
                rmSetTsbMSel(0x08);
            }
            else if(rmGetTsbSelErrCpuDma&cBit2)
            {
                rmSetTsbMSel(0x0B);
            }
            else if(rmGetTsbSelErrCpuDma&cBit3)
            {
                rmSetTsbMSel(0x09);
            }
            else if(rmGetTsbSelErrCpuDma&cBit4)
            {
                rmSetTsbMSel(0x0C);
            }
            else if(rmGetTsbSelErrCpuDma&cBit5)
            {
                rmSetTsbMSel(0x0D);
            }
            else if(rmGetTsbSelErrCpuDma&cBit6)
            {
                rmSetTsbMSel(0x0E);
            }
            else if(rmGetTsbSelErrCpuDma&cBit7)
            {
                rmSetTsbMSel(0x0F);
            }
#endif/* if 0 */
            NLOG(cLogError,
                 ISR0_C,
                 4,
                 " BVAC_Bus_TIMEOUT, Address = 0x%08X, Package Length = 0x%04X, Source = 0x%04X ",
                 rmGetTsbDebugAddress>>16,
                 rmGetTsbDebugAddress,
                 rmGetTsbDebugTsfCnt,
                 rmGetTsbSelErrFlash);
        }
        else if(rmChkTsbErrFlash)
        {
            for(u32Loop=0; u32Loop<8; u32Loop++)
            {
                if(rmGetTsbSelErrFlash&cbBitTab[u32Loop])
                {
                    rmSetTsbMSel(u32Loop);
                    u32Loop=8;
                }
            }

#if 0    // for code size

            if(rmGetTsbSelErrFlash&cBit0)
            {
                rmSetTsbMSel(0x00);
            }
            else if(rmGetTsbSelErrFlash&cBit1)
            {
                rmSetTsbMSel(0x01);
            }
            else if(rmGetTsbSelErrFlash&cBit2)
            {
                rmSetTsbMSel(0x02);
            }
            else if(rmGetTsbSelErrFlash&cBit3)
            {
                rmSetTsbMSel(0x03);
            }
            else if(rmGetTsbSelErrFlash&cBit4)
            {
                rmSetTsbMSel(0x04);
            }
            else if(rmGetTsbSelErrFlash&cBit5)
            {
                rmSetTsbMSel(0x05);
            }
            else if(rmGetTsbSelErrFlash&cBit6)
            {
                rmSetTsbMSel(0x06);
            }
            else if(rmGetTsbSelErrFlash&cBit7)
            {
                rmSetTsbMSel(0x07);
            }
#endif/* if 0 */
            NLOG(cLogError,
                 ISR0_C,
                 4,
                 " TSB_Bus_TIMEOUT(FLASH), Address = 0x%08X, Package Length = 0x%04X, Source = 0x%04X ",
                 rmGetTsbDebugAddress>>16,
                 rmGetTsbDebugAddress,
                 rmGetTsbDebugTsfCnt,
                 rmGetTsbSelErrFlash);
        }
    }
    else if(uErrorSaveId==cSaveIdCpuBusTimeout)
    {
        // sysDelay(30);
        if(!rmChkCpuErr)
        {
            // AHB error
            return;
        }

        // rmGetCfgErrAddr; //get error address
        // rmClrCpuErr;    //clean error flag
        NLOG(cLogError, ISR0_C, 2, " CPU_Bus_TIMEOUT, Address = 0x%08X ", rmGetCfgErrAddr>>16, rmGetCfgErrAddr);
    }
    else if(uErrorSaveId==cSaveIdTsbEccErr)
    {
        if(rmGetTsbEccErrDack)
        {
            u32Info=rmGetTsbEccErrDack;    // (T) Read TSB have 2-bit unc err, see info to know read master
            u32Addr=rmGetTsbEccErrAddr;
            NLOG(cLogError,
                 ISR0_C,
                 4,
                 "TSB ECC 2-bit uncorrectable error, Info=0x%08x, Addr(8byte align)=0x%08x",
                 u32Info>>16,
                 u32Info,
                 u32Addr>>16,
                 u32Addr);
        }

        if(rmGetTsbEccRmwErrDack)
        {
            u32Info=rmGetTsbEccRmwErrDack;
            u32Addr=rmGetTsbEccRmwErrAddr;
            NLOG(cLogError,
                 ISR0_C,
                 4,
                 "TSB ECC RMW 2-bit uncorrectable error, Info=0x%08x, Addr(8byte align)=0x%08x",
                 u32Info>>16,
                 u32Info,
                 u32Addr>>16,
                 u32Addr);
        }

        if(rmGetTsb4EccErrDack)
        {
            u32Info=rmGetTsb4EccErrDack;
            u32Addr=rmGetTsb4EccErrAddr;
            NLOG(cLogError,
                 ISR0_C,
                 4,
                 "TSB4 ECC 2-bit uncorrectable error, Info=0x%08x, Addr(8byte align)=0x%08x",
                 u32Info>>16,
                 u32Info,
                 u32Addr>>16,
                 u32Addr);
        }

        if(rmGetTsb4EccRmwErrDack)
        {
            u32Info=rmGetTsb4EccRmwErrDack;
            u32Addr=rmGetTsb4EccRmwErrAddr;
            NLOG(cLogError,
                 ISR0_C,
                 4,
                 "TSB4 ECC RMW 2-bit uncorrectable error, Info=0x%08x, Addr(8byte align)=0x%08x",
                 u32Info>>16,
                 u32Info,
                 u32Addr>>16,
                 u32Addr);
        }

        g16SramTwoBitErrCnt++;
        // (T) DACK value explanation
        // TSB need 32bit align to encode
        // NOTE *1 if any write non-align, TSB will have internal read 32bit and merge the write bytes and write 32bits into TSB to encode
        // NOTE *2 If write align 32bit, directly write to TSB mem without read
        //
        // Bit17: piw.	PCIe Host DMA engine read modify write, should not happen because this write always align *2
        // Bit16: pir.	PCIe Host DMA engine read
        // Bit15: hda.	hdma read or read modify write
        // Bit14: fs0.	flash channel 0 read, i.e., flash prog from tsb
        // Bit13: fs1.
        // Bit12: fs2.
        // Bit11: fs3.
        // Bit10: fs4.
        // Bit9: fs5.
        // Bit8: fs6.
        // Bit7: fs7.
        // Bit6: axwm0.	cpu core 0 write, may happen because *1
        // Bit5: axwm1.	core 1 write, may happen because *1
        // Bit4: axrm0.	core 0 read
        // Bit3: axrm1.	core 1 read
        // Bit2: cs0.	ldpc write, i.e., flash read to TSB, should not happen because this write always align and *2
        // Bit1: i2c.	external thermal chip interface => this chip to measure board tempture and can R/W data to TSB
        // Bit0: bop.	bop read ro read modify write
    }

    sysDelay(10000);

    // resetAllFlashCore0();

    // 2263XT HW workaround for TSB 0x40080000 and TSB CRC 0x40142000.
#if 0    // For release version

    if(((u32Addr>=0x000000)&&(u32Addr<0x080000))    // TSB0&1
       ||((u32Addr>=0x100000)&&(u32Addr<0x102000))    // TSB3
       ||((u32Addr>=0x140000)&&(u32Addr<0x142000))    // TSB5&6
       ||((u32Addr>=0x144000)&&(u32Addr<0x144080))    // TSB9
       ||((u32Addr>=0x180000)&&(u32Addr<0x188000))    // TSB4
       )
#else

    if((u32Addr!=0x080000)&&(u32Addr!=0x142000))
#endif
    {
        rmSysEnFwp;

        while(1)
            ;// freeze all activity as Intel's request //KW#277, design FW assert
    }
}    /* errorHandler */

void tracePcieEvent(BYTE uIdx)
{
    gsDebugInfo.uarPcieDebugTrace[gsDebugInfo.uPcieDebugCnt]=uIdx;
    gsDebugInfo.uar32PcieDebugTraceTimeStamp[gsDebugInfo.uPcieDebugCnt]=getRtcCurrent32k();
    gsDebugInfo.uPcieDebugCnt++;

    gsDebugInfo.uPcieDebugCnt&=0x1F;
    // if(gsDebugInfo.uPcieDebugCnt>=32)
    // {
    //    gsDebugInfo.uPcieDebugCnt=0;
    // }
}    /* tracePcieEvent */

void debugTSBflagCpu0(BYTE uOpt)
{
    WORD u16Index;

    if(uOpt==0)
    {
        return;
    }

    for(u16Index=0; u16Index<0x60; u16Index++)
    {
        if(rTsbCtrl[rcBuf0Flag+(u16Index)]!=0)
        {
            NLOG(cLogTempDebug, ISR0_C, 2, "rTsbCtrl[rcBuf0Flag+( 0x%04X)] : 0x%04X", u16Index, rTsbCtrl[rcBuf0Flag+(u16Index)]);
        }
    }

    for(u16Index=0; u16Index<0x60; u16Index++)
    {
        if(rTsbCtrl[rcBuf0RaidFlag+(u16Index)]!=0)
        {
            NLOG(cLogTempDebug, ISR0_C, 2, "rTsbCtrl[rcBuf0RaidFlag+( 0x%04X)] : 0x%04X", u16Index, rTsbCtrl[rcBuf0RaidFlag+(u16Index)]);
        }
    }
}    /* debugTSBflagCpu0 */

// Move traceLastIntSrc to tran2Active(), for code size
// void traceLastIntSrc(BYTE uIdx)
// {
//    gsDebugInfo.uarLastIntSrc[gsDebugInfo.uLastIntSrcCnt]=uIdx;
//    gsDebugInfo.uar32LastIntSrcTimeStamp[gsDebugInfo.uLastIntSrcCnt]=rmGetRtc32kTick;
//    gsDebugInfo.uLastIntSrcCnt++;
//
//    gsDebugInfo.uLastIntSrcCnt&=0x1F;
//    //if(gsDebugInfo.uLastIntSrcCnt>=32)
//    //{
//    //    gsDebugInfo.uLastIntSrcCnt=0;
//    //}
// }

BYTE chkUnderRwProc()
{
    if(mChkHandlePcieRstF)    // (!gsRdlinkInfo.uResumeFromPs4&&mChkHandlePcieRstF)
    {
        return cNotUnderRw;
    }
    else if(gsPrdInfo.uTotalPrdTaskCnt||rmChkCmdRdy||(gsPrdInfo.uFreeHwPrdCnt<cHwPrdDepth)||
            (gsRwCtrl.u32ProgFifoTail!=gsRwCtrl.u32ProgFifoHead)||(mChkGcFlag(cUnderBgdGc)))
    {
#if _EN_Delay_Dis_LTSSM

        if(((!rmChkHmbPrdEmpty)||(mChkGcFlag(cUnderBgdGc)&&(rmHmbPrdQueTrigIdx!=rmHmbPrdQueHeadIdx)))||(gGCRestFlg==1))
#else

        if((!rmChkHmbPrdEmpty)||(mChkGcFlag(cUnderBgdGc)&&(rmHmbPrdQueTrigIdx!=rmHmbPrdQueHeadIdx)))
#endif
        {
            mSetGcFlag(cGcDesFailAbort);

#if 0
            NLOG(cLogTempDebug,
                 ISR0_C,
                 2,
                 "chkUnderRwProc(), abort GC, rmChkHmbPrdEmpty: 0x%04X,mChkGcFlag(cUnderBgdGc): 0x%04X",
                 rmChkHmbPrdEmpty,
                 mChkGcFlag(cUnderBgdGc));

            NLOG(cLogTempDebug,
                 ISR0_C,
                 3,
                 "chkUnderRwProc(), abort GC, rmHmbPrdQueTrigIdx: 0x%04X, rmHmbPrdQueHeadIdx: 0x%04X, rNvmeHmb[0x4240]: 0x%04X",
                 rmHmbPrdQueTrigIdx,
                 rmHmbPrdQueHeadIdx, rNvmeHmb[0x4240]);
#endif
        }
        else
        {
            mSetGcFlag(cGcDesFailAbort);

#if 0
            NLOG(cLogTempDebug,
                 ISR0_C,
                 2,
                 "chkUnderRwProc(), not abort GC, rmChkHmbPrdEmpty: 0x%04X,mChkGcFlag(cUnderBgdGc): 0x%04X",
                 rmChkHmbPrdEmpty,
                 mChkGcFlag(cUnderBgdGc));

            NLOG(cLogTempDebug,
                 ISR0_C,
                 3,
                 "chkUnderRwProc(), not abort GC, rmHmbPrdQueTrigIdx: 0x%04X, rmHmbPrdQueHeadIdx: 0x%04X, rNvmeHmb[0x4240]: 0x%04X",
                 rmHmbPrdQueTrigIdx,
                 rmHmbPrdQueHeadIdx, rNvmeHmb[0x4240]);
#endif
        }

#if 0

        if(mChkHandlePcieErrF)
        {
            volatile BYTE uBufferLoop=0;

            while(uBufferLoop<((c16Tsb0Size+c16Tsb1Size)>>5))
            {
                NLOG(cLogTempDebug,
                     ISR0_C,
                     5,
                     "uBufferLoop=0x%04X, rm32BufStatus=0x%08X, rm32BufRaidStatus=0x%08X",
                     uBufferLoop*4, (r32TsbCtrl[(rcBuf0Flag/4)+(uBufferLoop)])>>16, r32TsbCtrl[(rcBuf0Flag/4)+(uBufferLoop)],
                     ((r32TsbCtrl[(rcBuf0RaidFlag/4)+(uBufferLoop)]))>>16, (r32TsbCtrl[(rcBuf0RaidFlag/4)+(uBufferLoop)]));
                uBufferLoop++;
            }
        }
#endif
        return cUnderRWHdlErr;
    }
    else if(gsRwCtrl.u32SeqRdFlag)
    {
        return cUnderRWNoHdlErr;
    }
    else if(mChkHandlePcieErrF)
    {
        return cUnderAlreadyHdlErr;
    }
    else
    {
        return cFreeToResetPcie;
    }
}    /* chkUnderRwProc */

__irq __arm void isrClkReqLatQ(void)
{
    tran2ActiveMo(0x01);
    // waitPclkRdy(); //Wait_PCLK_Ready for 2260, because 2262 don't wait PCLK ready to accress below MAC register. force link leave L1/L1.2

    // traceLastIntSrc(0x01);
    NLOG(cLogPS, ISR0_C, 0, " Assert ClkReq(ISR) ");

    // Disable interrupt source
    rmClrEletricIdleWake;
    rmDisClkReqAssertWake;

    rmClrCdiInt;    // need clear for PS4 self-wake up issue
    rmClrEletricIdleInt;

    // __DSB();
    rmVic0IrqClr;
}    /* isrClkReqLatQ */

// void VDT_Handler(BYTE uVDT_SaveID)
// {
//    while(1)
//        ;// freeze all activity as Intel's request
// }

__irq __arm void isrPwFail18(void)
{
    tran2ActiveMo(0x02);

    // traceLastIntSrc(0x02);
    // gsFtlDbg.u32Vdt18FailCnt++;

    NLOG(cLogHost, ISR0_C, 0, " VDT18 Fail(ISR) ");

    rmClrPwFail18Dram;

    // __DSB();
    rmVic0IrqClr;

    while(1)
        ;
}    /* isrPwFail18 */

__irq __arm void isrPwFail23(void)
{
    rmSysEnFwp;    // manual enable flash write protect
    tran2ActiveMo(0x03);
    NLOG(cLogHost, ISR0_C, 0, " VDT23 Fail(ISR) ");
    // traceLastIntSrc(0x03);

    while(!rmChkVdt23Fsh1Good)
        ;

    rmSysDisFwp;
    handleVDET(1);
    // returnPopHwPrdErr();

    rmClrPwFail23Fsh1;

    // __DSB();
    rmVic0IrqClr;

    while(1)
        ;
}    /* isrPwFail23 */

__irq __arm void isrWdtIntPwFail27(void)
{
    BYTE uDetectVDT23=1;

    tran2ActiveMo(0x04);

    // traceLastIntSrc(0x04);

    if(rmChkPwFail27Fsh2)
    {
        g32Vdt27FailCnt++;
        NLOG(cLogHost, ISR0_C, 0, " VDT 2.7 Fail (ISR) ");

        while(!rmChkVdt27Fsh2Good)
        {
            if(!rmChkVdt23Fsh1Good&&uDetectVDT23)
            {
                NLOG(cLogHost, ISR0_C, 0, " VDT23 inVDT27 Fail ");
                uDetectVDT23=0;
            }
        }

        rmClrPwFail27Fsh2;
    }
    else if(rmChkWdtTimeOut)
    {
        NLOG_SAVE(cLogHost, ISR0_C, 0, cSaveIdWdt, " WDT Timeout !! (ISR)");
        rmDisWdt;
        sysDelay(46);
        rmClrWdtTimeOut;
        sysDelay(46);
#if (_EN_WDT)
        rmResetWdtTimer;
        gWdtTOExtensionCnt++;

        if(gWdtTOExtensionCnt&0xFC)    // counter >= 4
        {
            NLOG_SAVE(cLogHost, ISR0_C, 0, cSaveIdWdt, " WDT Extension Timeout !! (ISR)");

            if(mChkCacheInfoFlag(cLogInfoBlockFull))
            {
                // halt if log block is full for now...
                NLOG_SAVE(cLogHost, ISR0_C, 0, cSaveIdWdt, " Log Block full. halt... ");

                while(1)
                    ;
            }

            mSetWdtRstFlash;
            __SEV();

            while(mChkWdtRstFlash)
                ;

            mSetTelemetryCtlrInfoAvail;
            gTelemetryCtlrGenNum++;
            saveEventLog(1);
            mSetWdtSaveLog;

            while(mChkWdtSaveLog)
                ;

            if(gsFtlDbg.u16DummyFailType==0)
            {
                mCallFuncPtr2(cfuncResetCpu, cResetCpuAll);
            }

            while(1)
                ;
        }
        else
        {
            rmEnWdt;
        }
#endif/* if (_EN_WDT) */
    }
    else
    {
        // NLOG(cLogHost, ISR0_C, 0, " VDT 4.0 Fail WDT (ISR)");
    }

    // __DSB();
    rmVic0IrqClr;
}    /* isrWdtIntPwFail27 */

__irq __arm void isrPwFail40IntPwFail10(void)
{
    tran2ActiveMo(0x05);

    // traceLastIntSrc(0x05);

    if(rmChkVdt10Good)
    {
        while(1)
            ;
    }

    // __DSB();
    rmVic0IrqClr;
}    /* isrPwFail40IntPwFail10 */

__irq __arm void isrPwFailEx(void)
{
    tran2ActiveMo(0x06);

    // traceLastIntSrc(0x06);

    // __DSB();
    rmVic0IrqClr;

    while(1)
        ;
}    /* isrPwFailEx */

__irq __arm void isrPwFailPor1(void)
{
    tran2ActiveMo(0x07);

    // traceLastIntSrc(0x07);

    rmClrPcieDstateChangeIntr;
    rmVic0Addr;    // what is this doing???

    // __DSB();
    rmVic0IrqClr;

    while(1)
        ;
}    /* isrPwFailPor1 */

__irq __arm void isrThsorValue(void)
{
    tran2ActiveMo(0x08);

    // traceLastIntSrc(0x08);

    // __DSB();
    rmVic0IrqClr;
}

__irq __arm void isrJtag(void)
{
    tran2ActiveMo(0x09);

    // traceLastIntSrc(0x09);

    // __DSB();
    rmVic0IrqClr;
}

__irq __arm void isrGpioAll(void)    // P1.0
{
    tran2ActiveMo(0x0A);

    // traceLastIntSrc(0x0A);
    if(mGpioP1GetIsrState(cGpioB1))
    {
        if(mChkFidUnderProcess)
        {
            mSetFidReset;
        }

        if(mChkFwCommitSuccess)    // 20190212_SamHu_01
        {
#if (OEM==VERIFY)

            if(1)
#else

            if(!rmChkShstComplete)
#endif
            {
                NLOG(cLogTempDebug, ISR0_C, 0, " W Commit Interrupt Entry PERST");
                rmSetFwCommitPeIsr;
                mSetFwActivate;
            }
            else
            {
                NLOG(cLogTempDebug, ISR0_C, 0, " Update FW at next time");
                mClrFidReset;
            }
        }

#if _EN_Delay_Dis_LTSSM

        // PERST Reset
        if(!(mChkGcFlag(cUnderBgdGc)||mChkGcFlag(cUnderFgdGc)||IORestFlg)&&(!mChkHandlePcieErrF))
        {
            gGCRestFlg=2;
            rmPcieAppLtssmDis;    // CSSD-2652
        }
        else
        {
            LLOG(cLogHost, ISR0_C, 2, " Delay_Dis_Reset, BgdGC=0x%04X ,FGdGC=0x%04X", (mChkGcFlag(cUnderBgdGc)?1:0),
                 (mChkGcFlag(cUnderFgdGc)?1:0));
            gGCRestFlg=1;
        }

#else
        rmPcieAppLtssmDis;    // CSSD-2652
#endif
        mPcieSetPerst;    // set flag
        LLOG(cLogHost, ISR0_C, 1, " PCIe Reset P11(ISR), Link State=0x%02X ,CurPs=%02d", (rmDetectLinkState<<8)|gsPowerState.uDevCurPs);
        gpioClrIsr(rcGpioIntSetP1, cGpioB1);    // Clear Int status

#if (_EN_PERST_WAKEINLOWPOWER)

        if((!chkUnderRwProc()&&gHandlePerstInIsrForLowPower)&&(!mPcieChkFlr))
#else

        if((!chkUnderRwProc())&&(!mPcieChkFlr))    // mChkHandlePcieRstF)    // CSSD-3023 CSSD-3048
#endif
        {
            handlePcieReset(cPciePerstReset);
            rmClrNvmeNSSRO;
        }
        else
        {
            mSetHandlePcieErrF;
            gsDebugInfo.u32PcieErrCnt0++;
            // gPCIEerrCnt++;
#if _EN_PCIE_ERR_HANG
            __SEV();

            while(mChkHandlePcieErrF)
                ;
#endif
        }

#if _ENABLE_SECAPI

        if(gbEnTCG||gbEnATAPassThrough)    // for BlockSID Hardware Reset Entry
        {
#if _ENABLE_ATA_PASSTHROUGH

            if(gbEnATAPassThrough)
            {
                gSecurityStatus&=0xE7;    // if Hardware reset received, clear security freeze and CountExpired

                if(rmChkSecurityEnable)
                {
                    rmSetSecurityLock;
                }
            }
#endif

            // [D.H] Avoid increasing UGSD count. If gPowerDownMode equal cGSD, drive will be shutdown down soon.
            // if(gPowerDownMode!=cGSD) //20190605_SamHu Jira1143 Lenovo reboot security status
            // {
            gbSecAPIPendingPCIeReset=1;
            // }
        }
#endif/* if _ENABLE_SECAPI */
    }

#if (_EN_CHRONUS_UART_DEBUG)
    LWORD uDebounce;
    uDebounce=getRtcCurrentMs();

    while(getRtcCurrentMs()-uDebounce<1)
        ;

    if(mGpioP1GetIsrState(cGpioB3))
    {
        mSetUartHoldActiveMo;
        gpioClrIsr(rcGpioIntSetP1, cGpioB3);
    }
    else if(!mGpioP1GetIsrState(cGpioB3))
    {
        mClrUartHoldActiveMo;
    }
#endif
#if _ENABLE_SCP_PLP

    // in future, Plp of  device sleep will be designed
    if(mChkNvmeEnPlpScp)
    {
        hdlPlpScpFlow(0);    // Sync SMI_0418,20190419_Eason
    }
    else if(mGpioP2GetIsrState(cGpioB5))    // GPIO25 detect
    {
        gpioClrIsr(rcGpioIntSetP2, cGpioB5);

        if(mGpioP2GetIsrState(cGpioB5))    // hw read check confirm
        {
            gpioClrIsr(rcGpioIntSetP2, cGpioB5);
        }

        NLOG(cLogHost, ISR0_C, 1, " GPIO25 Detect but PLP disable, gHandlePlpScpFlow=0x%04X ", gHandlePlpScpFlow);
    }
#endif    // #if _ENABLE_SCP_PLP

    // __DSB();
    rmVic0IrqClr;
}    /* isrGpioAll */

__irq __arm void isrFshIoPwFail(void)    // Flash IO VDT
{
    tran2ActiveMo(0x0B);

    // traceLastIntSrc(0x0B);

    NLOG_SAVE(cLogHost, ISR0_C, 0, cSaveIdVdt12FioFail, " VDT FIO 1.2V Fail(ISR) ");

    while(!rmChkVdt12FioGood)
        ;

    handleVDET(0);
    rmClrPwFail12Fio;

    // __DSB();
    rmVic0IrqClr;
}    /* isrFshIoPwFail */

void recovNvmePrdISR()
{
    BYTE uIdx0, uIdx1;

    // reset Nvme Hw
    for(uIdx0=0; uIdx0<cHwPrdDepth; uIdx0++)
    {
        for(uIdx1=0; uIdx1<cHwPrdEntryCnt; uIdx1++)
        {
            r32NvmeDesc[uIdx0][uIdx1]=0;
            r32NvmePrd[uIdx0][uIdx1]=0;
        }

        gsPrdInfo.uarFreeHwPrdQue[uIdx0]=uIdx0;
    }

    gsPrdInfo.uFreeHwPrdHead=0;
    gsPrdInfo.uFreeHwPrdTail=0;
    gsPrdInfo.uFreeHwPrdCnt=cHwPrdDepth;

    for(uIdx0=0; uIdx0<8; uIdx0++)
    {
        rmDisDmaEngine(uIdx0);
    }

    // return;
    rmBgRstEn;
    _nop();
    _nop();
    _nop();
    _nop();
    _nop();
    rmBgRstOff;

    rmResetRaidFlg;
    rmResetOccupyFlg;
    rmResetBufFlg;

    while(rmChkDpsDppFifoNotEmpty)
    {
        // prevent next time to get wrong HwIdx
        rmPopNextValue;
    }
}    /* recovNvmePrd */

void postRwTaskToPrdInfo_VDT()
{
    PRDQUEUE *upPrdInfo;
    volatile LINKINFO *upInsLlInfo;
    CMDSTRUCT *upIOCmd;
    LWORD u32Dword0, u32Dword2, u32Dword10, u32Dword11, u32Dword12;
    WORD u16SqId, u16PrevNodeIdx, u16NextNodeIdx, u16NowNodeIdx;
    BYTE uOpCode, uTotalPrdTaskCnt;

#if _GREYBOX
    CMDSTRUCT *upGbIOCmd;
#endif

    chkReleaseFreeHwPrd();

    uTotalPrdTaskCnt=gsPrdInfo.uTotalPrdTaskCnt;

    if(rmChkCmdRdy)
    {
        if(uTotalPrdTaskCnt<cPrdDepth)
        {
            u32Dword0=r32Nvme1[rcFwRqCmd0/4];
            u32Dword2=r32Nvme1[rcFwRqCmd2/4];
            u16SqId=(WORD)(u32Dword2>>16);    // rmNvmeSqId;
            uOpCode=(BYTE)u32Dword0;    // rmNvmeOpCode;
        }
        else
        {
            return;
        }
    }
    else
    {
        return;
    }

    while(u16SqId&&((uOpCode==cNvmeCmdRead)||(uOpCode==cNvmeCmdWrite)))
    {
        u32Dword10=r32Nvme1[rcFwRqCmd10/4];
        u32Dword11=r32Nvme1[rcFwRqCmd11/4];
        u32Dword12=r32Nvme1[rcFwRqCmd12/4];

        upIOCmd=&garCmdHistory[g32CmdHistoryPtr];
        g32CmdHistoryPtr++;

        if(g32CmdHistoryPtr>=cCmdHistorySize)
        {
            g32CmdHistoryPtr=0;
        }

        upIOCmd->u32Dword0=u32Dword0|c32Bit10;
        upIOCmd->u32Dword10=u32Dword10;
        upIOCmd->u32Dword11=u32Dword11;
        upIOCmd->u32Dword12=u32Dword12;
        upIOCmd->u32TimeStamp=getRtcCurrent32k();

#if _GREYBOX
        upGbIOCmd=&garGbCmdHistory[g32GbCmdHistoryPtr];
        g32GbCmdHistoryPtr++;

        if(g32GbCmdHistoryPtr>=(cCmdHistorySize*cCmdHistorySize))
        {
            g32GbCmdHistoryPtr=0;
        }

        upGbIOCmd->u32Dword0=u32Dword0|c32Bit10;
        upGbIOCmd->u32Dword10=u32Dword10;
        upGbIOCmd->u32Dword11=u32Dword11;
        upGbIOCmd->u32Dword12=u32Dword12;
        upGbIOCmd->u32TimeStamp=rmGetRtc32kTick;
#endif

        u16NowNodeIdx=gsPrdInfo.uarFreePrdQue[gsPrdInfo.uFreePrdHead];    // gsPrdInfo.usFreePrdList.u16Tail;
        upPrdInfo=&gsPrdInfo.uarPrdQue[u16NowNodeIdx];

        upPrdInfo->u32LbaAddr=u32Dword10;
        upPrdInfo->u32SctrCnt=(u32Dword12&0x0000FFFF)+1;
        upPrdInfo->u32NsId=rmNvmeNsId;

        // if(chkCmdInfoError(upPrdInfo->u32SctrCnt, u32Dword10, upPrdInfo->u32NsId))
        // {}
        // else
        {
            upPrdInfo->u32Prp1H=rmNvmePrp1High;
            upPrdInfo->u32Prp1L=rmNvmePrp1Low;
            upPrdInfo->u32Prp2H=rmNvmePrp2High;
            upPrdInfo->u32Prp2L=rmNvmePrp2Low;
            upPrdInfo->u32LbaAddr+=gsNamespace.usInfo[upPrdInfo->u32NsId-1].u32StartLba;
#if _EN_MAGICCODE
            rmPopNextCmd;
#endif
            upPrdInfo->uOpCode=uOpCode;

#if _GREYBOX

            if((u32Dword12&c32Bit30)&&(uOpCode==cNvmeCmdWrite))
#else

            if(((u32Dword12&c32Bit30)||(!mChkCacheEnable))&&(uOpCode==cNvmeCmdWrite))
#endif
            {
                upPrdInfo->uFua=cHdlNvmeFlush;    // 20190417_ChrisSu
                upPrdInfo->uFuaDone=0;
            }
            else
            {
                upPrdInfo->uFua=0;
            }

            // upPrdInfo->uFua=(u32Dword12&c32Bit30)||(!mChkCacheEnable);    // rmNvmeFua; ?????????????????????
            upPrdInfo->u16Cid=(WORD)(u32Dword0>>16);    // rmNvmeCid;
            upPrdInfo->u16CqId=(WORD)(u32Dword2);    // rmNvmeCqId;
            upPrdInfo->u16SqId=u16SqId;
            upPrdInfo->uSgl=(BYTE)((u32Dword0&0x0000C000)>>8);    // rmNvmeSgl;
            upPrdInfo->ubQRdCmd=0;
            upPrdInfo->ubSetOccF=0;
            upPrdInfo->uHwPrdIdx=cNull;
            upPrdInfo->uUncFlag=0;
            upPrdInfo->uE2eRetry=0;

#if _ENABLE_SECAPI
            upPrdInfo->uSecFlag=0;

            if(gbEnTCG)
            {
                if(gMBRShadow&&gMbrRangeHit)
                {
                    // if host data region is not aligned to 4K, there will be several unused sectors added to make it aligned
                    upPrdInfo->u32LbaAddr+=g32HostTotalDataSectorCnt+gTcgReservedSecShiftCnt;
                    gMbrRangeHit=0;
                    // gMbrRedirectPassAes=1;
                    upPrdInfo->uSecFlag|=cMbrRedirectPassAes;
                }
                else if(gMBRShadow&&gMbrReturnZero)
                {
                    gMbrReturnZero=0;
                    // gMbrDummyReturn=1;
                    // gMbrRedirectPassAes=1;
                    upPrdInfo->uSecFlag|=(cMbrRedirectPassAes|cMbrDummyReturn);
                }
            }
#endif/* if _ENABLE_SECAPI */

            if(uOpCode==cNvmeCmdRead)
            {
                upInsLlInfo=&gsPrdInfo.usReadPrdList;
            }
            else
            {
                upInsLlInfo=&gsPrdInfo.usWritePrdList;
            }

            mInsNode(u16PrevNodeIdx, upInsLlInfo, u16NextNodeIdx, gsPrdInfo.uarPrdLink, u16NowNodeIdx);
            uTotalPrdTaskCnt++;
            gsPrdInfo.uFreePrdHead=(gsPrdInfo.uFreePrdHead+1)&(cPrdDepth-1);

            gFWShnFlag=0;
#if !_EN_MAGICCODE
            rmPopNextCmd;
#endif
        }

        if(rmChkCmdRdy)
        {
            if(uTotalPrdTaskCnt<cPrdDepth)
            {
                u32Dword0=r32Nvme1[rcFwRqCmd0/4];
                u32Dword2=r32Nvme1[rcFwRqCmd2/4];
                u16SqId=(WORD)(u32Dword2>>16);    // rmNvmeSqId;
                uOpCode=(BYTE)u32Dword0;    // rmNvmeOpCode;
            }
            else
            {
                break;
            }
        }
        else
        {
            break;
        }
    }

    gsPrdInfo.uTotalPrdTaskCnt=uTotalPrdTaskCnt;
}    /* postRwTaskToPrdInfo */

void handleVDET(BYTE uOpt)
{
    volatile LINKINFO *upDelLlInfo;
    BYTE uIdx0, uIdx1;
    WORD u16PrevNodeIdx, u16NextNodeIdx, u16PrdInfoIdx;

    if(uOpt)
    {
        rmSetFVdt23;    // set flag for Rdlink
        gsFtlDbg.u16FtlEventReason=0x0001;
    }
    else
    {
        rmSetFVdt18;
        gsFtlDbg.u16FtlEventReason=0x0002;
    }

    // handle RW PRD
    // returnPopHwPrdErr();

    if(chkUnderRwProc())
    {
        rmSetAllQueStopFetchCmd;

        while(rmChkCmdRdy)
        {
            postRwTaskToPrdInfo_VDT();

            upDelLlInfo=&gsPrdInfo.usReadPrdList;
            uIdx0=2;

            while(uIdx0)
            {
                while(upDelLlInfo->u16Cnt)
                {
                    u16PrdInfoIdx=upDelLlInfo->u16Tail;
                    uIdx1=gsPrdInfo.uarPrdQue[u16PrdInfoIdx].uHwPrdIdx;

                    manualCompletion(cStatusDataXfrErr, 0, cRwCmd, u16PrdInfoIdx);

                    mDelNode(u16PrevNodeIdx, gsPrdInfo.uarPrdLink, u16PrdInfoIdx, u16NextNodeIdx, upDelLlInfo);
                    gsPrdInfo.uarFreePrdQue[gsPrdInfo.uFreePrdTail]=u16PrdInfoIdx;
                    gsPrdInfo.uFreePrdTail=(gsPrdInfo.uFreePrdTail+1)&(cPrdDepth-1);
                    gsPrdInfo.uTotalPrdTaskCnt--;

                    if(uIdx1!=cNull)
                    {
                        gsPrdInfo.uarFreeHwPrdQue[gsPrdInfo.uFreeHwPrdHead]=uIdx1;
                        gsPrdInfo.uFreeHwPrdHead=(gsPrdInfo.uFreeHwPrdHead+1)&(cHwPrdDepth-1);
                        gsPrdInfo.uFreeHwPrdCnt++;
                    }
                }

                upDelLlInfo->u16Trig=cNull;
                upDelLlInfo=&gsPrdInfo.usWritePrdList;
                uIdx0--;
            }
        }

        while((!rmChkSqEmpty||!rmChkFwRqEmpty||rmChkCmdRdy))
        {
            while(rmChkCmdRdy)
            {
                rmPopNextCmd;
            }
        }
    }

    recovNvmePrdISR();

    mSetWdtRstFlash;
    __SEV();

    while(mChkWdtRstFlash)
        ;

    // gsFtlDbg.u32Vdt23FailCnt++;
    saveEventLog(1);
    mSetWdtSaveLog;

    while(mChkWdtSaveLog)
        ;

    mCallFuncPtr2(cfuncResetCpu, cResetCpuSrst);

    while(1)
        ;
}    /* handleVDET */

__irq __arm void isrAllTimer(void)
{
    BYTE uTimerIntType=rmTimerIntType;

    if(uTimerIntType&0x09)    // System Timer(Bit 0), RTC 1S(Bit3)
    {
        tran2ActiveMo(0x0C);
    }

    // traceLastIntSrc(0x0C);

    if(uTimerIntType&cBit0)    // SystemTimer_25M
    {
        rmTimerDisable;    // (A) will auto reset and clear interrupt

        if(g32SysTmrOn==1)
        {
            gCpu0TOFlag=1;
        }
        else
        {
            g32Cpu1TOFlag=1;
        }

        // NLOG(cLogSYS, ISR0_C, 0, " Sys timer timeout ");
        // HW timer is edge trigger, so we don't need to clear int source
        while(rmChkTimerEnable)
            ;

        sysDelay(5);
    }

    // if(uTimerIntType&cBit1)    // RTC_1S
    // {
    //    // gSensorPollingInterval++;
    //    // gsDebugInfo.u32PowerOnSec++;
    //    //
    //    // if((gsLightSwitch.usThermalLs.uSensorPollingThres)&&(gSensorPollingInterval>=gsLightSwitch.usThermalLs.uSensorPollingThres))
    //    // {
    //    //    gChkTemperature=1;
    //    //    gSensorPollingInterval=0;
    //    // }
    //
    //    rmRtc1sClearInt;
    //    while(!rmChkRtc1sInt);
    //    // NLOG(cLogPS, ISR_C, 0, " RTC timer timeout ");
    // }

    if(uTimerIntType&cBit3)    // RTC_500Ms, per 1 sec
    {
        g32arRWTickCnt[gRWTickCntPtr]=g32RWTickCnt;
        gRWTickCntPtr=(gRWTickCntPtr+1)&0x07;
        gSensorPollingInterval++;
        gsDebugInfo.u32PowerOnSec++;

        if((gsLightSwitch.usThermalLs.uSensorPollingThres)&&(gSensorPollingInterval>=gsLightSwitch.usThermalLs.uSensorPollingThres)&&
           mChkStartThrottlingSt)
        {
            gChkTemperature=1;
            // chkThrottlingPowerState(cIsr1s);
            gSensorPollingInterval=0;
        }

        rmRtc2HzClearInt;

        // NLOG(cLogPS, ISR_C, 0, " RTC timer timeout ");
        while(rmChkRtc2HzInt)
            ;
    }

    if(uTimerIntType&cBit2)    // RTC_32K
    {
#if (_ENABLE_DASP_LED)
        mToggleDaspLed;
        rmRtc32kClearInt;
#else
        rmRtc32kClearInt;
#endif

        while(rmChkRtc32kInt)
            ;
    }

    // __DSB();
    rmVic0IrqClr;
}    /* isrAllTimer */

__irq __arm void isrI2cSlave(void)
{
    tran2ActiveMo(0x0D);

    // traceLastIntSrc(0x0D);

    // __DSB();
    rmVic0IrqClr;
}

__irq __arm void isrI2cMaster(void)
{
    tran2ActiveMo(0x0E);

    // traceLastIntSrc(0x0E);

    // __DSB();
    rmVic0IrqClr;
}

__irq __arm void isrUart(void)
{
#if (!_EN_CHRONUS_UART_DEBUG)
    tran2ActiveMo(0x0F);

    // traceLastIntSrc(0x0F);

    if(!g32RxTrigStartmsTime||((getRtcCurrentMs()-g32RxTrigStartmsTime)>6000))
    {
        g32RxTrigStartmsTime=getRtcCurrentMs();    // (A) reset start time
    }

    if(rmChkRxOK&&((getRtcCurrentMs()-g32RxTrigStartmsTime)>5000))    // (s) wait 5s for trigger UART RX pin
    {
        while(1)
        {
            if((getRtcCurrentMs()-g32RxTrigStartmsTime)>5005)    // (s) wait 5ms for cmdfifo
            {
                break;
            }
        }

        NLOG_SAVE(cLogError, ISR0_C, 0, CKeepSaveEventLog, " Uart trigger save log ");

        if(rmAllFreezeBusy)
        {
            saveEventLog(1);
        }
        else
        {
            saveEventLog(0);
        }

        g32RxTrigStartmsTime=0;
        // while(1);
    }

    rmUartRxPop;
#else/* if (!_EN_CHRONUS_UART_DEBUG) */
    LWORD uLastRxTime;

    while(rmChkRxOK)
    {
        g32UartCMDDW=g32UartCMDDW>>8;
        g32UartCMDDW|=(rmUartRxByte<<24);
        rmUartRxPop;

        if(mChkUartHndShkRdy)
        {
            if(g32UartCMDofst&0x3==0x3)
            {
                *(gp32UartCMDStartAddress+mUartDWofst)=g32UartCMDDW;
            }
        }
        else
        {
            if(g32UartCMDofst&0x3==0x3)
            {
                g32arUartHndShkCMD[mUartDWofst&0x3]=g32UartCMDDW;
            }

            uLastRxTime=getRtcCurrentMs();

            while(!rmChkRxOK&&(getRtcCurrentMs()-uLastRxTime<1))
                ;
        }

        g32UartCMDofst++;
        mSetUartRxRdy;
    }

    if(!mChkUartHndShkRdy)
    {
        if(mUartDWofst<3)
        {
            g32UartCMDofst=0;
            mClrUartRxRdy;
        }
    }
    tran2ActiveMo(0x0F);
#endif/* if (!_EN_CHRONUS_UART_DEBUG) */
    rmUartClrAllInt;

    // __DSB();
    rmVic0IrqClr;
}    /* isrUart */

__irq __arm void isrRng(void)
{
    tran2ActiveMo(0x10);

    // traceLastIntSrc(0x10);

    // __DSB();
    rmVic0IrqClr;
}

__irq __arm void isrPcieAppIrq0(void)
{
    BYTE uCheck=0;

    tran2ActiveMo(0x11);

    // traceLastIntSrc(0x11);

    gsDebugInfo.u32ResumeFromPcieAppIrq0Time=getRtcCurrent32k();

    // Nvme CMD In
    // for sleep mode wake up, Need to enable this IRQ before enter sleep
    if(rmChkNvmeFwRqRdyInt)
    {
        tracePcieEvent(0x10);
        rmNvmeDisFwRqRdyInt;    // command in
        rmNvmeDisSqDbInt;    // When power 1 off, need to check Sq doorbell
        rmClrNvmeFwRqRdyInt;
        rmClrNvmeDoorBellInt;
        NLOG(cLogHost, ISR0_C, 0, " FWRQ_RDY(ISR) ");
        debugTSBflagCpu0(1);
        uCheck=1;

        // while(rmChkNvmeFwRqRdyInt)
        //    ;

        // while(rmChkNvmeDoorBellInt);
    }

    if(rmChkNvmeDoorBellInt)
    {
        tracePcieEvent(0x11);
        rmNvmeDisSqDbInt;    // When power 1 off, need to check Sq doorbell
        rmClrNvmeDoorBellInt;
        NLOG(cLogHost, ISR0_C, 0, " Doorbell(ISR) ");
        uCheck=2;

        // while(rmChkNvmeDoorBellInt);
    }

    // if(!rmChkCcRdy)                             //remove for 2263
    // {
    //    BYTE uIoNum;
    //
    //    for(uIoNum=0; uIoNum<9; uIoNum++)
    //    {
    //        rmClrSqTailDoorBell(uIoNum);
    //        rmClrCqHeadDoorBell(uIoNum);
    //    }
    // }

    if(uCheck==0)
    {
        tracePcieEvent(0x12);
        NLOG(cLogHost, ISR0_C, 0, " ISR16-Other(ISR) ");
    }

    // __DSB();
    rmVic0IrqClr;
}    /* isrPcieAppIrq0 */

__irq __arm void isrPcieAppIrq1(void)    // NVMP DPS related ISR
{
    tran2ActiveMo(0x12);

    // traceLastIntSrc(0x12);

    // Nvme DPS
    if(rmChkNvmeDpsDppInt)
    {
        if(rmChkDpp)
        {
            rmClrDppAll;
        }

        if(rmChkDps)
        {
            rmClrDpsAll;
        }

        rmClrNvmeDpsDppInt;
    }

    // __DSB();
    rmVic0IrqClr;
}    /* isrPcieAppIrq1 */

__irq __arm void isrPcieAppIrq2(void)    // Nvme related ISR, 18
{
    BYTE uBackupStatus=0;

    tran2ActiveMo(0x13);

    // traceLastIntSrc(0x13);

    // NVMe Reset: CC_EN transition from 1 to 0 or NSSR=1 // for win7 turn off
    if(rmChkNvmeResetInt)
    {
        tracePcieEvent(0x20);

        if(mChkFidUnderProcess)
        {
            mSetFidReset;
        }

        if(mChkFwCommitSuccess)    // 20190212_SamHu_01
        {
#if (OEM==VERIFY)

            if(1)
#else

            if(!rmChkShstComplete)
#endif
            {
                NLOG(cLogTempDebug, ISR0_C, 0, " W Commit Interrupt Entry NVMe Reset");
                mSetFwActivate;
            }
            else
            {
                NLOG(cLogTempDebug, ISR0_C, 0, " Update FW at next time");
                mClrFidReset;
            }
        }

        if(rmChkCcEn)    // CC_EN is still '1', imply this interrupt is caused by NSSR
        {
            tracePcieEvent(0x21);
            // NVMe NSSR(ISR)
            LLOG(cLogHost, ISR0_C, 1, " NVMe NSSR(ISR), Link State=0x%04X ", rmDetectLinkState);

            mNvmeSetNssr;    // NSSR and PERST share the same flow

            if(!chkUnderRwProc())
            {
                handlePcieReset(cPciePerstReset);
            }

#if _ENABLE_SECAPI

            if(gbEnTCG||gbEnATAPassThrough)    // for BlockSID Hardware Reset Entry
            {
                /* NSSR shall not affect the ATA Security state */
                gbSecAPIPendingNSSR=1;
            }
#endif/* if _ENABLE_SECAPI */
        }
        else
        {
            tracePcieEvent(0x22);
            // NVMe reset(ISR)
            debugTSBflagCpu0(1);
            LLOG(cLogHost, ISR0_C, 1, " NVMe Reset(ISR), Link State=0x%04X ", rmDetectLinkState);
            mNvmeSetRst;    // set flag
            // rmClrNvmeNSSRO;

            if(chkUnderRwProc())    // (!mChkHandlePcieRstF)
            {
                tracePcieEvent(0x23);
                mSetHandlePcieErrF;
                gsDebugInfo.u32PcieErrCnt1++;
                // gPCIEerrCnt++;
#if _EN_PCIE_ERR_HANG
                __SEV();

                while(mChkHandlePcieErrF)
                    ;
#endif
            }
        }

        rmClrNvmeResetInt;    // Clear int status to release int
    }

    // NVMe Enable: CC_EN transition from 0 to 1
    if(rmChkNvmeCcEnOnInt)
    {
        tracePcieEvent(0x24);
        // NVMe EN (cc_en on)(ISR)
        LLOG(cLogHost, ISR0_C, 1, " NVMe EN (cc_en on)(ISR), Link State=0x%04X ", rmDetectLinkState);
        mNvmeSetCcEnOn;    // set flag
        rmClrNvmeCcEnOnInt;
        gsDebugInfo.u32CcEnTime=getRtcCurrent32k();

        if(!gsDebugInfo.u32CcEnFirstTime)    // for debug
        {
            gsDebugInfo.u32CcEnFirstTime=gsDebugInfo.u32CcEnTime;
        }
    }

#if _PCIE_FUN_LVL_RST

    if(rmChkNvmeFlrInt)
    {
        tracePcieEvent(0x25);
        uBackupStatus=rmChkPcieDoNotEnterL1;    // Sync 2262HH
        rmSetPcieDoNotEnterL1;    // Sync 2262HH

        if(mChkFidUnderProcess)
        {
            mSetFidReset;
        }

        if(mChkFwCommitSuccess)    // 20190212_SamHu_01
        {
#if (OEM==VERIFY)

            if(1)
#else

            if(!rmChkShstComplete)
#endif
            {
                NLOG(cLogTempDebug, ISR0_C, 0, " W Commit Interrupt Entry Function Level Reset");
                mSetFwActivate;
            }
            else
            {
                NLOG(cLogTempDebug, ISR0_C, 0, " Update FW at next time");
                mClrFidReset;
            }
        }

        // TODO:handle function levle reset
        // PCIe Function Level RST(ISR)
        LLOG(cLogHost, ISR0_C, 1, " PCIe Function Level RST(ISR), Link State=0x%04X ", rmDetectLinkState);
        mPcieSetFlr;    // CSSD-5676 FLR + NVME reset
        handleFlr();    // CSSD-2605
        rmClrNvmeFlrInt;
        // rmClrNvmeNSSRO;

        if(chkUnderRwProc())    // (!mChkHandlePcieRstF)
        {
            tracePcieEvent(0x26);
            mSetHandlePcieErrF;
            gsDebugInfo.u32PcieErrCnt2++;
            // gPCIEerrCnt++;
#if _EN_PCIE_ERR_HANG
            __SEV();

            while(mChkHandlePcieErrF)
                ;
#endif
        }

        if(!uBackupStatus)    // Sync 2262HH
        {
            rmClrPcieDoNotEnterL1;    // Sync 2262HH
        }
    }
#endif/* if _PCIE_FUN_LVL_RST */

    // NVMe Shutdown Notification // = flush cache
    if(rmChkNvmeShnChangeInt)
    {
        if(rmChkShutdownNotify)
        {
#if (!_EN_SHN_SUPPORT_CMD)
            rmSetAllQueStopFetchCmd;    // 20190215_Bill
#endif
            tracePcieEvent(0x27);
            // NVMe Shut Down Notification(ISR)
            LLOG(cLogHost, ISR0_C, 1, " NVMe Shut Down Notification(ISR), Link State=0x%04X ", rmDetectLinkState);
            mNvmeSetShn;    // set flag
            rmSetShstOccuring;    // inform host shutdown in progress, will set M_SET_SHST_COMPLETE outside
        }
        else
        {
#if (!_EN_SHN_SUPPORT_CMD)
            rmClrAllQueStopFetchCmd;    // 20190215_Bill
#endif
            tracePcieEvent(0x28);
            // NVMe Shut Down Notification(ISR)
            LLOG(cLogHost, ISR0_C, 1, " NVMe SHN Change 1->0 Clr Interrput(ISR), Link State=0x%04X ", rmDetectLinkState);
        }

        rmClrNvmeShnChangeInt;
    }

    // __DSB();
    rmVic0IrqClr;
}    /* isrPcieAppIrq2 */

__irq __arm void isrPcieAppIrq3(void)
{
    LWORD u32SqInv, u32InvSqDb;
    LWORD u32CqInv, u32InvCqDb;
    LWORD u32SqEn, u32CqEn;
    BYTE uIdx;

    tran2ActiveMo(0x14);

    // traceLastIntSrc(0x14);

    // Host Invalid DoorBell Write Value
    if(rmChkNvmeInvDbWriteInt)    // CSSD-1740
    {
        tracePcieEvent(0x30);

        u32SqInv=u32InvSqDb=rmGetNvmeInvSqDb;
        u32CqInv=u32InvCqDb=rmGetNvmeInvCqDb;
        // Invalid DoorBell, SQ bitmap=0x%04X, CQ bitmap=0x%04X

        if(rmChkCcEn)    // only handle invalid db events if controller is enabled
        {
            NLOG_SAVE(cLogSYS, ISR0_C, 2, cSaveIdInvalidDoorbell, " Invalid Doorbell, CQ bitmap=0x%04X, SQ bitmap=0x%04X ", u32CqInv, u32SqInv);

            // check Admin
            if(u32SqInv&0x01)
            {
                rmSetNvmeMisc5((((gsLightSwitch.usNvmeLs.usControllerCapLo.u32All&0x00010000)>>16)<<3)    // CQR
                               |0x04    // set CFS bit
                               |(((gsLightSwitch.usNvmeLs.usControllerCapLo.u32All&0x00020000)>>17)<<1)    // AMS
                               |((gsLightSwitch.usNvmeLs.usControllerCapHi.u32All&0x00000010)>>4));    // NSSR
            }

            if(u32CqInv&0x01)
            {
                // rmSetNvmeMisc5(0x0D | (((gsLightSwitch.usNvmeLs.usControllerCapLo.u32All&0x00040000)>>17)<<1));//set CFS bit,
                rmSetNvmeMisc5(0x0B|(((gsLightSwitch.usNvmeLs.usControllerCapLo.u32All&0x00040000)>>17)<<1));    // set CFS bit,
            }

            // check IO
            // u32CqInv=u32CqInv>>1;
            // u32SqInv=u32SqInv>>1;
            u32CqEn=rmGetNvmeCqEn;
            u32SqEn=rmGetNvmeSqEn;
            // Because Bit0 is AdminQ that is always enable but HW enable bit is zero,
            // need to setB0 for below loop check.
            u32CqEn=(u32CqEn<<1)|c32Bit0;
            u32SqEn=(u32SqEn<<1)|c32Bit0;

            for(uIdx=0; uIdx<(cMaxIoSqCqCnt+1); uIdx++)
            {
                if(u32SqInv&cb32BitTab[uIdx])
                {
                    if(u32SqEn&cb16BitTab[uIdx])    // Host software attempted to write an invalid doorbell value.
                    {
                        mSetAerInvalidDbWrite;    // Set async event bit
                    }
                    else    // Host software wrote the doorbell of a queue that was not created.
                    {
                        mSetAerWriteInvalidDbReg;    // Set async event bit
                    }

                    gsInvalidDbInfo.uarErrQid[gsInvalidDbInfo.uErrLogHead]=uIdx;
                    gsInvalidDbInfo.uErrLogHead=addPtrBy1(gsInvalidDbInfo.uErrLogHead, cMaxIoSqCqCnt);
                }

                if(u32CqInv&cb32BitTab[uIdx])
                {
                    if(u32CqEn&cb16BitTab[uIdx])    // Host software attempted to write an invalid doorbell value.
                    {
                        mSetAerInvalidDbWrite;    // Set async event bit
                    }
                    else    // Host software wrote the doorbell of a queue that was not created.
                    {
                        mSetAerWriteInvalidDbReg;    // Set async event bit
                    }

                    gsInvalidDbInfo.uarErrQid[gsInvalidDbInfo.uErrLogHead]=c16BitFF;
                    gsInvalidDbInfo.uErrLogHead=addPtrBy1(gsInvalidDbInfo.uErrLogHead, cMaxIoSqCqCnt);
                }
            }
        }

        rmClrNvmeInvSqDb(u32InvSqDb);
        rmClrNvmeInvCqDb(u32InvCqDb);
        rmClrNvmeInvDbWriteInt;    // clear interrupt status bit in NVME domain
    }

    // NVMe DMA engine error
    if(rmChkNvmeDmaErrorInt)
    {
        tracePcieEvent(0x31);
        errorHandler(cSaveIdDmaError);
    }

    // __DSB();
    rmVic0IrqClr;
}    /* isrPcieAppIrq3 */

__irq __arm void isrPcieIrq0(void)    // PCIE related ISR, 20
{
#if _EN_D3Hot_PS4
    BYTE uPcieDoNotEnterL1;
#else
    BYTE uBackupStatus=0;
#endif    // #if _EN_D3Hot_PS4
    tran2ActiveMo(0x15);

    // traceLastIntSrc(0x15);

    if(rmChkBusMasterChangeIntr)    // happened before nvme reset
    {
        tracePcieEvent(0x40);
        waitPclkRdy();

        if(rmChkBusMasterDis)
        {
            // don't do anything
        }

        rmClrBusMasterChangeIntr;
    }

    // before using P11, HW use link down(lost) as PCIe reset signal (PERST)
    // in fact, link lost will retrain by itself, so we don't need it anymore
    // but some host may not issue PCIe reset, so FW still keep it
    if(rmChkLinkRstDetect)
    {
        tracePcieEvent(0x41);

        if(mChkFidUnderProcess)
        {
            mSetFidReset;
        }

        if(mChkFwCommitSuccess)    // 20190212_SamHu_01
        {
#if (OEM==VERIFY)

            if(1)
#else

            if(!rmChkShstComplete)
#endif
            {
                NLOG(cLogTempDebug, ISR0_C, 0, " W Commit Interrupt Entry PCIe Link down");
                mSetFwActivate;
            }
            else
            {
                NLOG(cLogTempDebug, ISR0_C, 0, " Update FW at next time");
                mClrFidReset;
            }
        }

        LLOG(cLogHost, ISR0_C, 1, "PCIe Link down(ISR) , Link State=0x%04X ", rmDetectLinkState);
        // rmPcieAppLtssmDis;  //CSSD-4700
        rmClrLinkRstDetect;
        rmCcEnClr;

        if(!chkUnderRwProc())    // (mChkHandlePcieRstF)    // CSSD-3023 CSSD-3048
        {
            tracePcieEvent(0x42);
            handlePcieReset(cPcieLinkDownReset);    // change for 2263 //cPciePerstReset);
            rmClrNvmeNSSRO;
        }
        else
        {
            tracePcieEvent(0x43);
            mPcieSetRst;    // set flag
            mSetHandlePcieErrF;
            gsDebugInfo.u32PcieErrCnt3++;
            // gPCIEerrCnt++;
#if _EN_PCIE_ERR_HANG
            __SEV();

            while(mChkHandlePcieErrF)
                ;
#endif
        }
    }

    // L1 timeout
    if(rmChkL1Timeout)
    {
        tracePcieEvent(0x44);
        rmClrL1Timeout;    // clr int

#if _FW_HANDLE_L12

        if(rmChkL1TimeoutEn)    // 2263
        {
            if(chkEnClkReq())
            {
                if(rmChkClkReqDeassert)
                {
                    NLOG(cLogPS, ISR0_C, 0, " L1 time out, CLKREQ-Deassert ");

                    while(1)
                        ;
                }
                else
                {
                    NLOG(cLogPS, ISR0_C, 0, " L1 time out, CLKREQ-Assert ");

                    while(1)
                        ;
                }

                enablePcieL12();
            }
        }
#endif/* if _FW_HANDLE_L12 */
    }

    if(rmChkLtrEnChangeIntr)    // only happend on enumeration, both LTR enabled or disabled controlled by host
    {
        tracePcieEvent(0x45);
        gLtrEnabled=0;

        if(!rmChkLtrMsgReg0LtrMsgActiveEn)
        {
            waitPclkRdy();

            if(rmChkLtrEnable)
            {
#if _PCIE_D3HOT_D0_LTR_WORKAROUND
                gLtrEnabled=1;    // need to check max snoop
                g32LtrValue0=0;    // need reassign
                g32LtrValue2=0;    // need reassign
                srvLtrSend(0x00);
#endif
            }
        }

        rmClrLtrEnChangeIntr;
    }

    if(rmChkRadmDebugIntr)    // CSSD-2883
    {
        rmSetAllQueStopFetchCmd;
        rmBgRstEn;

        tracePcieEvent(0x46);
        // CPL time out(ISR), Link
        LLOG_SAVE(cLogHost, ISR0_C, 1, cSaveIdCPLTimeOut, " CPL time out(ISR), Link State=0x%04X ", rmDetectLinkState);
        LLOG(cLogHost, ISR0_C, 1, " CPL TO Stop Fetch CMD, ChkBridgeAxiRwFlushBsy=0x%04X ", rmChkBridgeAxiRwFlushBsy);
        LLOG(cLogHost, ISR0_C, 1, " PRD PDTR0=0x%04X ", rmPrdPdtr0);
        LLOG(cLogHost, ISR0_C, 1, " PRD PDTR1=0x%04X ", rmPrdPdtr1);
        LLOG(cLogHost, ISR0_C, 2, " LCRC=0x%04X%04X ", rmLcrcCnt>>16, rmLcrcCnt);
        // _nop();
        // _nop();
        // _nop();
        // _nop();
        // _nop();
        // rmBgRstOff;
        // _nop();
        // _nop();
        // rmAllDmaEngineDis;
        rmClrRadmDebugIntr;

        // if(chkUnderRwProc())    // !mChkHandlePcieRstF)
        {
            mSetHandlePcieErrF;
            gsDebugInfo.u32PcieErrCnt4++;
            // gPCIEerrCnt++;
#if _EN_PCIE_ERR_HANG
            __SEV();

            while(mChkHandlePcieErrF)
                ;
#endif
        }
    }

    if(rmChkPcieDstateChangeIntr)    // LTRIssue
    {
        tracePcieEvent(0x47);
        // only happend on enumeration, both LTR enabled or disabled controlled by host
        // if(!rmChkLtrMsgReg0LtrMsgActiveEn)
        {
            waitPclkRdy();
#if _EN_D3Hot_PS4
            uPcieDoNotEnterL1=rmChkPcieDoNotEnterL1^(0xFD);
            rmSetPcieDoNotEnterL1;    // for rmChkLtrEnable

            // if(rmChkD0state)
            if(rmChkPcieD0State)
            {
                gChgtoD0=1;
                rmSetPcieDoNotEnterL1;
                LLOG(cLogHost, ISR0_C, 1, " Dx to D0 (ISR), Link State=0x%04X ", rmDetectLinkState);

                if(rmChkLtrEnable)
                {
#if _PCIE_D3HOT_D0_LTR_WORKAROUND
                    gLtrEnabled=1;    // need to check max snoop
                    g32LtrValue0=0;    // need reassign
                    g32LtrValue2=0;    // need reassign
                    srvLtrSend(0x00);
#endif
                }

                rmSetAutoSendL1SubLtr;
                rmSetAutoEnterL1SubState;

// #if (!_ENABLE_STANDBY_KEEP_L1)    // [Momo] LiteOn request, do not entry L1Sub at standby mode
//                    rmSetAutoEnterL1SubState;
// #endif

                // Mark rmSetAppReadyEntry123 for Lenovo Y530 S4, but need to confirm Z270+ reboot test
                // rmClrAppReadyEntry123;    // for Z270M+ reboot fail(cfg not response) patch

                rmRestorePiceDoNotEnterL1(uPcieDoNotEnterL1);
                mNvmeClrD3;
                mNvmeSetD0;
            }
            else if(rmChkPcieD3State)
            {
                LLOG(cLogHost, ISR0_C, 2, " D0 to Dx=0x%04X (ISR), Link State=0x%04X ", rmChkPcieDxstate, rmDetectLinkState);
#if _EN_DisHMBInReset    // 20190424_Chief_DisHMB
                gChkFlag|=cPcieD3State;
#endif
                gChgtoD0=0;
                rmClrAutoSendL1SubLtr;
                rmClrAutoEnterL1SubState;

                if(rmChkHostEnPmL12)
                {
                    rmSetAutoEnterL1SubState;
                }

                // Mark rmSetAppReadyEntry123 for Lenovo Y530 S4, but need to confirm Z270+ reboot test
                // rmSetAppReadyEntry123;    // for Z270M+ reboot fail(cfg not response) patch
                mNvmeSetD3;    // set firmware flag to focre drive to enter PS4
                rmClrPcieDoNotEnterL1;    // Prevent periodic wake up
            }

#else    // #if _EN_D3Hot_PS4

            if(rmChkD0state)
            {
                gChgtoD0=1;

                if(rmChkLtrEnable)
                {
                    uBackupStatus=rmChkPcieDoNotEnterL1;    // Sync 2262
                    rmSetPcieDoNotEnterL1;
                    LLOG(cLogHost, ISR0_C, 1, " Dx to D0 (ISR), Link State=0x%04X ", rmDetectLinkState);

#if _PCIE_D3HOT_D0_LTR_WORKAROUND
                    gLtrEnabled=1;    // need to check max snoop
                    g32LtrValue0=0;    // need reassign
                    g32LtrValue2=0;    // need reassign
                    srvLtrSend(0x00);
#endif
                    rmSetAutoSendL1SubLtr;

#if (!_ENABLE_STANDBY_KEEP_L1)    // [Momo] LiteOn request, do not entry L1Sub at standby mode
                    rmSetAutoEnterL1SubState;
#endif

                    // Mark rmSetAppReadyEntry123 for Lenovo Y530 S4, but need to confirm Z270+ reboot test
                    // rmClrAppReadyEntry123;    // for Z270M+ reboot fail(cfg not response) patch
                    if(!uBackupStatus)    // Sync 2262
                    {
                        rmClrPcieDoNotEnterL1;
                    }
                }
            }
            else
            {
                uBackupStatus=rmChkPcieDoNotEnterL1;
                rmSetPcieDoNotEnterL1;
                LLOG(cLogHost, ISR0_C, 2, " D0 to Dx=0x%04X (ISR), Link State=0x%04X ", rmChkPcieDxstate, rmDetectLinkState);
#if _EN_DisHMBInReset    // 20190812_Bruce_DisHMB
                gChkFlag|=cPcieD3State;
#endif
                gChgtoD0=0;
#if _EN_D3Hot_L12    // For Modern standby request,20190121_Eason
                LLOG(cLogHost, ISR0_C, 0, " D3Hot Enable L1 Substate ");
                rmClrPcieDoNotEnterL1;    // Enable L1
                rmSetAutoSendL1SubLtr;
                rmSetAutoEnterL1SubState;    // Enable L1 substate
#else
                rmClrAutoSendL1SubLtr;
                rmClrAutoEnterL1SubState;

                // Mark rmSetAppReadyEntry123 for Lenovo Y530 S4, but need to confirm Z270+ reboot test
                // rmSetAppReadyEntry123;    // for Z270M+ reboot fail(cfg not response) patch
                if(!uBackupStatus)    // Sync 2262
                {
                    rmClrPcieDoNotEnterL1;
                }
#endif    // _EN_D3Hot_L12

#if _EN_D3Hot_DisPS34
                mNvmeSetD3;    // set firmware flag to focre drive to clear PS3/4
#endif
            }
#endif    // _EN_D3Hot_PS4
        }

        // NLOG(cLogTempDebug, ISR0_C, 2, " Act0=0x%04X, gChgtoD0=0x%04X ", R_PCIeDev.DevMacLTRSwtich->LTR_Msg_Active_En, gChgtoD0);
        rmClrPcieDstateChangeIntr;
    }

    // __DSB();
    rmVic0IrqClr;
}    /* isrPcieIrq0 */

__irq __arm void isrPcieIrq1(void)
{
    tran2ActiveMo(0x16);

    // traceLastIntSrc(0x16);

#if _2260PCIE_WORKAROUND
    gen3ConfigPatch();
#endif

#if _ACER_ESD_ONELANE    // Sam Test Code for Acer platform

    if(rmChkLtssmTraceIntr0)
    {
        // bit12
        // NLOG_SMI_LINK_1(C_LOG_Host, " LTSSM_Trace0(ISR),  Link State=0x%04X ",  M_Chk_LTSSM_Cur_State, 0, "LTSSM_t0"); //
        if(rmChkLtssmStateTimeoutIntr0)
        {
            if(gLaneNumAcceptTimeoutCnt==0)
            {
                rmSetLinkCapable(0x03);    // to 2 lane
                gLaneNumAcceptTimeoutCnt=1;
            }
            else
            {
                rmSetLinkCapable(0x01);    // to 1 lane
            }

            rmClrLtssmStateTimeoutIntr0;
        }

        rmClrLtssmTraceIntr0;
    }

#else/* if _ACER_ESD_ONELANE */

    if(rmChkLtssmTraceIntr0)
    {
        // bit12
        LLOG(cLogHost, ISR0_C, 1, " LTSSM_Trace0(ISR), Link Stare=0x%04X ", rmDetectLinkState);
        rmClrLtssmTraceIntr0;
        rmClrLtssmTraceIntr0En;
    }
#endif/* if _ACER_ESD_ONELANE */

    if(rmChkLtssmTraceIntr1)    // BSOD
    {
        // bit13
        LLOG(cLogHost, ISR0_C, 1, " LTSSM_Trace1(ISR), Link State=0x%04X ", rmDetectLinkState);
#if (_EN_PCIE_DEBUG)
        BYTE uLaneNum;
        WORD u16CrData0, u16CrData1;

        for(uLaneNum=0; uLaneNum<4; uLaneNum++)
        {
            u16CrData0=crRead((cAddrAphyLane0|(uLaneNum<<8)|cAddrDm0))&0x1F;
            u16CrData1=crRead((cAddrAphyLane0|(uLaneNum<<8)|cAddrDm2))&0x1F;
            LLOG(cLogHost, ISR0_C, 3, " Lane Num=0x%04X, DM0=0x%04X, DM2=0x%04X ", uLaneNum, u16CrData0, u16CrData1);
        }

        u16CrData1=rmGetPresetValue;
        LLOG(cLogHost, ISR0_C, 1, " Host Tx Preset value=0x%04X ", u16CrData1);

        for(uLaneNum=0; uLaneNum<4; uLaneNum++)
        {
#if _EN_CPLtimeouttest    // OscarTsai_20190418 sync SMI CPL timeout test issue code
            // CDR parameter
            u16CrData0=crRead((cAddrAphyLane0|(uLaneNum<<8)|cAddrKis));
            LLOG(cLogHost, ISR0_C, 2, " Lane Num=0x%04X, KIS=0x%04X ", uLaneNum, u16CrData0);

            // RX parameter
            u16CrData0=crRead((cAddrAphyLane0|(uLaneNum<<8)|cAddrEqc))&cSmbEqc;
            LLOG(cLogHost, ISR0_C, 2, " Lane Num=0x%04X, EQC=0x%04X ", uLaneNum, (u16CrData0>>4));

            u16CrData0=crRead((cAddrAphyLane0|(uLaneNum<<8)|cAddrTap1))&cSmbTap1;
            LLOG(cLogHost, ISR0_C, 2, " Lane Num=0x%04X, TAP1=0x%04X ", uLaneNum, u16CrData0);

            u16CrData0=crRead((cAddrAphyLane0|(uLaneNum<<8)|cAddrTap2))&cSmbTap2;
            LLOG(cLogHost, ISR0_C, 2, " Lane Num=0x%04X, TAP2=0x%04X ", uLaneNum, u16CrData0);

            u16CrData0=crRead((cAddrAphyLane0|(uLaneNum<<8)|cAddrTap3))&cSmbTap3;
            LLOG(cLogHost, ISR0_C, 2, " Lane Num=0x%04X, TAP3=0x%04X ", uLaneNum, u16CrData0);

            u16CrData0=crRead((cAddrAphyLane0|(uLaneNum<<8)|cAddrOffv))&cSmbOffv;
            LLOG(cLogHost, ISR0_C, 2, " Lane Num=0x%04X, OFFV=0x%04X ", uLaneNum, u16CrData0);

            // Squelch   level
            u16CrData0=crRead((cAddrAphyLane0|(uLaneNum<<8)|cAddrSqa))&cSmbSqa;
            LLOG(cLogHost, ISR0_C, 2, " Lane Num=0x%04X, SQA=0x%04X ", uLaneNum, u16CrData0);

            // Rx offset
            u16CrData0=crRead((cAddrAphyLane0|(uLaneNum<<8)|cAddrRxOffc))&cSmbRxOffc;
            LLOG(cLogHost, ISR0_C, 2, " Lane Num=0x%04X, RX OFFC=0x%04X ", uLaneNum, u16CrData0);
#endif/* if 0 */
            // Rx termination
            u16CrData0=crRead((cAddrAphyLane0|(uLaneNum<<8)|cAddrRt))&cSmbRt;
            LLOG(cLogHost, ISR0_C, 2, " Lane Num=0x%04X, RT=0x%04X ", uLaneNum, u16CrData0);
        }

        rmSetLtssmTimeoutValue(0x00010000);    // 1ms
        rmClrLtssmTraceIntr1;
#else/* if (_EN_PCIE_DEBUG) */
        rmClrLtssmTraceIntr1;
        rmClrLtssmTraceIntr1En;
#endif/* if (_EN_PCIE_DEBUG) */
    }

    if(rmChkFormDebugInt)    // CSSD-2883
    {
        // bit2
        waitPclkRdy();

        // Advanced Error Log(ISR)
        NLOG(cLogHost,
             ISR0_C,
             4,
             " Malform TLP(ISR), log0=0x%08X, log1=0x%08X ",
             rmAerHeaderLog0>>16,
             rmAerHeaderLog0,
             rmAerHeaderLog1>>16,
             rmAerHeaderLog1);
        NLOG(cLogHost,
             ISR0_C,
             4,
             " Malform TLP(ISR), log2=0x%08X, log3=0x%08X ",
             rmAerHeaderLog2>>16,
             rmAerHeaderLog2,
             rmAerHeaderLog3>>16,
             rmAerHeaderLog3);
        // Malform TLP(ISR), Link State=0x%04X
        LLOG_SAVE(cLogHost, ISR0_C, 1, cSaveIdMalformTLP, " Malform TLP(ISR), Link State=0x%04X ", rmDetectLinkState);

        rmBgRstEn;
        _nop();
        _nop();
        _nop();
        _nop();
        _nop();
        rmBgRstOff;
        _nop();
        _nop();
        rmAllDmaEngineDis;
        rmClrFormDebugInt;

        if(chkUnderRwProc())    // (!mChkHandlePcieRstF)
        {
            mSetHandlePcieErrF;
            gsDebugInfo.u32PcieErrCnt5++;
            // gPCIEerrCnt++;
#if _EN_PCIE_ERR_HANG
            __SEV();

            while(mChkHandlePcieErrF)
                ;
#endif
        }
    }

    if(rmChkLtssmIntr0)    // reserved for others
    {
        // bit8
        // DPHY src0(ISR)
        LLOG(cLogHost, ISR0_C, 1, " DHY src0(ISR), Link State=0x%04X ", rmDetectLinkState);
        gLtssmIntr0=1;
        rmClrLtssmIntr0;
        rmClrLtssmIntr0En;
    }

    if(rmChkLtssmIntr1)    // reserved for others
    {
        // bit9
        // DPHY src1(ISR)
        LLOG(cLogHost, ISR0_C, 1, " DHY src1(ISR), Link State=0x%04X ", rmDetectLinkState);
        gLtssmIntr1=1;
        rmClrLtssmIntr1;
        rmClrLtssmIntr1En;
    }

    if(rmChkLtssmIntr2)    // DPHY workaround use source 2
    {
        // bit11
        // DPHY src3(ISR)
        LLOG(cLogHost, ISR0_C, 1, " DHY src2(ISR), Link State=0x%04X ", rmDetectLinkState);
        gLtssmIntr2=1;
        rmClrLtssmIntr2;

        if(gsLightSwitch.usPhyLs.u16CustomizeF&cEarlyPCIeResetEn)    // remove for 2263  // EarlyPCIeResetEn
        {
            if(!chkUnderRwProc())    // (mChkHandlePcieRstF)
            {
#if 0
                mPcieSetLinkDis;
                handlePcieReset(cPciePerstReset);
#else
                rmSetAuxToPipe0Debug;
                mPcieSetLinkDis;
                // NLOG_SMI_1(C_LOG_Sys, "Chk Electrical Idle 0x%04X", M_Chk_EletricalIdleDetect,0);
                rmSetPortFroceLinkLtssm(0x05);
                rmSetForceEn;
                // NLOG_SMI_1(C_LOG_Sys, "Chk Electrical Idle 0x%04X", M_Chk_EletricalIdleDetect,0);
                rmClrAuxDebug;
#endif
            }
        }
        else
        {
            rmClrLtssmIntr2En;
        }
    }

    if(rmChkLtssmIntr3)    // DPHY workaround use source 3
    {
        // DHY src3(ISR)
        LLOG(cLogHost, ISR0_C, 1, " DPHY src3(ISR), Link State=0x%04X ", rmDetectLinkState);
        rmClrLtssmIntr3;    // clear pending status
        rmClrLtssmIntr3En;    // clear enable, because CPU already wake up
    }

    // __DSB();
    rmVic0IrqClr;

    if(rmChkPcieVpdIntr)
    {
        rmClrPcieVpdIntr;
    }
}    /* isrPcieIrq1 */

__irq __arm void isrPcieIrq2(void)
{
    tran2ActiveMo(0x17);

    // traceLastIntSrc(0x17);

    if(rmChkExpansionRomDps)
    {
        gOpRomRead=1;
        rmClrExpansionRomDps;
    }

    // __DSB();
    rmVic0IrqClr;
}

__irq __arm void isrPcieIrq3(void)
{
    tran2ActiveMo(0x18);

    // traceLastIntSrc(0x18);
#if (_EN_PCIE_DEBUG)
    BYTE uLaneNum;
    WORD u16CrData0;
    LWORD u32Loop;

    if(rmChkLtssmStateTimeoutIntr1||rmChkLtssmStateTimeoutIntr2)
    {
        // Check RX KIS
        for(uLaneNum=0; uLaneNum<4; uLaneNum++)
        {
            u16CrData0=crRead((cAddrAphyLane0|(uLaneNum<<8)|cAddrKis));
            LLOG(cLogHost, ISR0_C, 2, " Lane Num=0x%04X, KIS=0x%04X ", uLaneNum, u16CrData0);
        }

        // Check RX error count >> start
        for(uLaneNum=0; uLaneNum<4; uLaneNum++)
        {
            setPhyError(uLaneNum);
        }

        for(u32Loop=0; u32Loop<8; u32Loop++)
        {
            for(uLaneNum=0; uLaneNum<4; uLaneNum++)
            {
                u16CrData0=chkPhyError(uLaneNum);
                LLOG(cLogHost,
                     ISR0_C,
                     3,
                     " APHY Error Cnt (ISR), Link State=0x%04X, Lane=0x%04X, Error Counts=0x%04X ",
                     rmDetectLinkState,
                     uLaneNum,
                     u16CrData0);
                u16CrData0=chkDphyError(uLaneNum);
                LLOG(cLogHost,
                     ISR0_C,
                     3,
                     " DPHY Error Cnt (ISR), Link State=0x%04X, Lane=0x%04X, Error Counts=0x%04X ",
                     rmDetectLinkState,
                     uLaneNum,
                     u16CrData0);
            }

            sysDelay(200000);    // Delay 1msec 200*1000*5 nsec.
        }

        // Check RX error count >> End
        rmClrLtssmStateTimeoutIntr1;
        rmClrLtssmStateTimeoutIntr2;
    }
#endif/* if (_EN_PCIE_DEBUG) */

#if _ENABLE_BUS_ERR_HANDLE

    if(rmChkAxiWrTimeoutErr)
    {
        // AXI write error
        rmClrAxiWrTimeoutErr;    // clean error flag
        rmClrAxiWrWaitCnt;    // clean timer
        NLOG_SAVE(cLogError, ISR0_C, 0, cSaveIdPcieAxiWTimeout, " PCIE_AXI_W_TIMEOUT ");
    }

    if(rmChkAxiRdTimeoutErr)
    {
        // AXI write error
        rmClrAxiRdTimeoutErr;    // clean error flag
        rmClrAxiRdWaitCnt;    // clean timer
        NLOG_SAVE(cLogError, ISR0_C, 0, cSaveIdPcieAxiRTimeout, " PCIE_AXI_R_TIMEOUT ");
    }

    if(rmChkAes2TsbWrTimeoutErr)
    {
        // AXI write error
        rmClrAes2TsbWrTimeoutErr;    // clean error flag
        rmClrAes2TsbWrWaitCnt;    // clean timer
        NLOG_SAVE(cLogError, ISR0_C, 0, cSaveIdAes2TsbWTimeout, " AES2TSB_W_TIMEOUT ");
    }

    if(rmChkAes2TsbRdDramTimeoutErr)
    {
        // AXI write error
        rmClrAes2TsbRdDramTimeoutErr;    // clean error flag
        rmClrAes2TsbRdWaitCnt;    // clean timer
        NLOG_SAVE(cLogError, ISR0_C, 0, cSaveIdAes2TsbRDramTimeout, " AES2TSB_R_DRAM_TIMEOUT ");
    }

    if(rmChkAes2TsbRdSramTimeoutErr)
    {
        // AXI write error
        rmClrAes2TsbRdSramTimeoutErr;    // clean error flag
        rmClrAes2TsbRdWaitCnt;    // clean timer
        NLOG_SAVE(cLogError, ISR0_C, 0, cSaveIdAes2TsbRSramTimeout, " AES2TSB_R_SRAM_TIMEOUT ");
    }
#endif/* if _ENABLE_BUS_ERR_HANDLE */
#if 0

    if(rmChkAxiWrTimeoutErr)
    {
        // AXI write error
        NLOG_SAVE(cLogError, ISR0_C, 0, cSaveIdPcieAxiWTimeout, " PCIE_AXI_W_TIMEOUT ");

        while(1)
            ;
    }

    if(rmChkAxiRdTimeoutErr)
    {
        // AXI write error
        NLOG_SAVE(cLogError, ISR0_C, 0, cSaveIdPcieAxiRTimeout, " PCIE_AXI_R_TIMEOUT ");

        while(1)
            ;
    }

    if(rmChkAes2TsbWrTimeoutErr)
    {
        // AXI write error
        NLOG_SAVE(cLogError, ISR0_C, 0, cSaveIdAes2TsbWTimeout, " AES2TSB_W_TIMEOUT ");

        while(1)
            ;
    }

    if(rmChkAes2TsbRdDramTimeoutErr)
    {
        // AXI write error
        NLOG_SAVE(cLogError, ISR0_C, 0, cSaveIdAes2TsbRDramTimeout, " AES2TSB_R_DRAM_TIMEOUT ");

        while(1)
            ;
    }

    if(rmChkAes2TsbRdSramTimeoutErr)
    {
        // AXI write error
        NLOG_SAVE(cLogError, ISR0_C, 0, cSaveIdAes2TsbRSramTimeout, " AES2TSB_R_SRAM_TIMEOUT ");

        while(1)
            ;
    }
#endif/* if _ENABLE_BUS_ERR_HANDLE */

    // __DSB();
    rmVic0IrqClr;
}    /* isrPcieIrq3 */

__irq __arm void isrSetBvb2CfgTmoFlag(void)
{
    tran2ActiveMo(0x19);

    // traceLastIntSrc(0x19);

#if _ENABLE_BUS_ERR_HANDLE
    LWORD u32Info, u32Addr, u32ErrBitmapL, u32ErrBitmapH;

    if(rmGetTsbEccRmwCorrDack)
    {
        // (T) TSB RMW 1-bit corr err
        g16SramOneBitErrCnt++;
        u32Info=rmGetTsbEccRmwCorrDack;
        u32Addr=rmGetTsbEccRmwCorrAddr;
        u32ErrBitmapL=rmGetTsbEccRmwCorrWdataL;
        u32ErrBitmapH=rmGetTsbEccRmwCorrWdataH;
        NLOG(cLogError,
             ISR0_C,
             4,
             "TSB ECC RMW 1-bit correctable error, Info=0x%08x, Addr(8byte align)=0x%08x",
             u32Info>>16,
             u32Info,
             u32Addr>>16,
             u32Addr);
        NLOG(cLogError, ISR0_C, 4, "Error Bitmap=0x%08x%08x", u32ErrBitmapH>>16, u32ErrBitmapH, u32ErrBitmapL>>16, u32ErrBitmapL);
    }

    if(rmGetTsbEccCorrDack)
    {
        // (T) TSB 1-bit corr err
        g16SramOneBitErrCnt++;
        u32Info=rmGetTsbEccCorrDack;
        u32Addr=rmGetTsbEccCorrAddr;
        u32ErrBitmapL=rmGetTsbEccCorrRdataL;
        u32ErrBitmapH=rmGetTsbEccCorrRdataH;
        NLOG(cLogError,
             ISR0_C,
             4,
             "TSB ECC 1-bit correctable error, Info=0x%08x, Addr(8byte align)=0x%08x",
             u32Info>>16,
             u32Info,
             u32Addr>>16,
             u32Addr);
        NLOG(cLogError, ISR0_C, 4, "Error Bitmap=0x%08x%08x", u32ErrBitmapH>>16, u32ErrBitmapH, u32ErrBitmapL>>16, u32ErrBitmapL);
    }

    if(rmGetTsb4EccRmwCorrDack)
    {
        // (T) TSB4 RMW 1-bit corr err
        g16SramOneBitErrCnt++;
        u32Info=rmGetTsb4EccRmwCorrDack;
        u32Addr=rmGetTsb4EccRmwCorrAddr;
        u32ErrBitmapL=rmGetTsb4EccRmwCorrWdataL;
        u32ErrBitmapH=rmGetTsb4EccRmwCorrWdataH;
        NLOG(cLogError,
             ISR0_C,
             4,
             "TSB4 ECC RMW 1-bit correctable error, Info=0x%08x, Addr(8byte align)=0x%08x",
             u32Info>>16,
             u32Info,
             u32Addr>>16,
             u32Addr);
        NLOG(cLogError, ISR0_C, 4, "Error Bitmap=0x%08x%08x", u32ErrBitmapH>>16, u32ErrBitmapH, u32ErrBitmapL>>16, u32ErrBitmapL);
    }

    if(rmGetTsb4EccCorrDack)
    {
        // (T) TSB4 1-bit corr err
        g16SramOneBitErrCnt++;
        u32Info=rmGetTsb4EccCorrDack;
        u32Addr=rmGetTsb4EccCorrAddr;
        u32ErrBitmapL=rmGetTsb4EccCorrRdataL;
        u32ErrBitmapH=rmGetTsb4EccCorrRdataH;
        NLOG(cLogError,
             ISR0_C,
             4,
             "TSB4 ECC 1-bit correctable error, Info=0x%08x, Addr(8byte align)=0x%08x",
             u32Info>>16,
             u32Info,
             u32Addr>>16,
             u32Addr);
        NLOG(cLogError, ISR0_C, 4, "Error Bitmap=0x%08x%08x", u32ErrBitmapH>>16, u32ErrBitmapH, u32ErrBitmapL>>16, u32ErrBitmapL);
    }

    if(rmGetTsbEccErrDack&c32Bit16)    // (Steve) Dack bit16 PCIE Read don't hang
    {
        g32E2eDetectCnt++;
        u32Info=rmGetTsbEccErrDack;
        u32Addr=rmGetTsbEccErrAddr;
        NLOG(cLogError,
             ISR0_C,
             4,
             "TSB ECC 2-bit uncorrectable error, Info=0x%08x, Addr(8byte align)=0x%08x",
             u32Info>>16,
             u32Info,
             u32Addr>>16,
             u32Addr);
    }

    if(rmGetTsbEccRmwErrDack&c32Bit16)    // (Steve)  Dack bit16 PCIE Read don't hang
    {
        g32E2eDetectCnt++;
        u32Info=rmGetTsbEccRmwErrDack;
        u32Addr=rmGetTsbEccRmwErrAddr;
        NLOG(cLogError,
             ISR0_C,
             4,
             "TSB ECC RMW 2-bit uncorrectable error, Info=0x%08x, Addr(8byte align)=0x%08x",
             u32Info>>16,
             u32Info,
             u32Addr>>16,
             u32Addr);
    }

    if((rmGetTsbEccErrDack&(~c32Bit16))||rmGetTsb4EccErrDack||(rmGetTsbEccRmwErrDack&(~c32Bit16))||rmGetTsb4EccRmwErrDack)
    {
        // TSB 2-bit uncorrectable err
        errorHandler(cSaveIdTsbEccErr);    // hang inside
    }

    if(rmGetTsbEccRmwCorrDack||rmGetTsbEccCorrDack||rmGetTsb4EccRmwCorrDack||rmGetTsb4EccCorrDack)
    {
        rmClrTsbEccCorr;
    }

    if(rmGetTsbEccRmwErrDack||rmGetTsbEccErrDack||rmGetTsb4EccRmwErrDack||rmGetTsb4EccErrDack)
    {
        rmClrTsbEccErr;
    }

    // Bus Timeout
    if((rmChkTsbErr||rmChkTsb4Err))
    {
        errorHandler(cSaveIdTsbBusTimeout);
        rmClrBvaDmaErr;
    }

    if(rmChkCpuErr)
    {
        NLOG(cLogError,
             ISR0_C,
             3,
             "rmChkCpuErr=0x%04x, rmGetCfgErrAddr=0x%08x", rmChkCpuErr, rmGetCfgErrAddr>>16, rmGetCfgErrAddr);
        NLOG(cLogError,
             ISR0_C,
             2,
             "gMasterState=0x%04x, gXadmldle=0x%04x", gMasterState, gXadmldle>>16, rmGetCfgErrAddr);

        // AHB error
        while(rmChkCpuErr)
        {
            rmClrCpuErr;
        }

        errorHandler(cSaveIdCpuBusTimeout);
    }
#endif/* if _ENABLE_BUS_ERR_HANDLE */

    // __DSB();
    rmVic0IrqClr;
}    /* isrSetBvb2CfgTmoFlag */

__irq __arm void isrRsa(void)
{
    tran2ActiveMo(0x1A);

    // traceLastIntSrc(0x1A);

    // __DSB();
    rmVic0IrqClr;
}

__irq __arm void isrFakeFailStop(void)    // Dram Ecc fail, fake engine fail
{
    tran2ActiveMo(0x1B);

    // traceLastIntSrc(0x1B);

    // __DSB();
    rmVic0IrqClr;
}

__irq __arm void isrCmdFifoFull(void)
{
    tran2ActiveMo(0x1C);

    // traceLastIntSrc(0x1C);

    // __DSB();
    rmVic0IrqClr;
}

__irq __arm void isrFlash(void)
{
    tran2ActiveMo(0x1D);

    // traceLastIntSrc(0x1D);

    // __DSB();
    rmVic0IrqClr;
}

__irq __arm void isrHdaDone(void)
{
    tran2ActiveMo(0x1E);

    // traceLastIntSrc(0x1E);

    // __DSB();
    rmVic0IrqClr;
}

__irq __arm void isrBopDone(void)
{
    tran2ActiveMo(0x1F);

    // traceLastIntSrc(0x1F);

    rmBopResume;    // Resume BOP once Pause mode is set

    // __DSB();
    rmVic0IrqClr;
}    /* isrBopDone */

__irq __arm void isrVIC31(void)
{
    tran2ActiveMo(0x20);

    // traceLastIntSrc(0x20);

    // __DSB();
    rmVic0IrqClr;
}

#if (!_ICE_LOAD_ALL)
#pragma default_function_attributes =
#endif







