







// #if (_CPUID!=1)
#include "inc/Const.h"
#include "inc/TypeDef.h"
#include "inc/Option.h"
#include "inc/ProType.h"
#include "inc/GlobVarS.h"
#include "inc/GlobVar1.h"
#include "inc/GlobVarT.h"
#include "inc/NvmeCtrl.h"
#include "inc/BitDef.h"
#include "inc/NvmeCtrl.h"
#include "inc/Reg.h"
#include "inc/Mac.h"
#include "inc/Rdlink.h"
#if (_GREYBOX)
#include "inc/GreyBox.h"
#endif

#include "inc/DebugLog.h"
#include "inc/EventLogIDX.h"
#include "inc/EventLogFunctionIDX.h"

#pragma default_function_attributes = @ ".CORE1_ISP"

#include "GcCore1.c"
#include "ProgFail.c"
// #include "RaidDec.c"

#pragma default_function_attributes =







