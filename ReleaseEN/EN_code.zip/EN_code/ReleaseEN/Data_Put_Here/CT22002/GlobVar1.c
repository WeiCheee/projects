







#include "inc/Option.h"
#include "inc/TypeDef.h"
#include "inc/Const.h"
// #include "inc/NvmeCtrl.h"

// -----------------Domain0----------------//
#pragma default_variable_attributes = @ ".R8_SysCtrl0"
volatile BYTE rSysCtrl0[0x400];
#pragma default_variable_attributes =

#pragma default_variable_attributes = @ ".R16_SysCtrl0"
volatile WORD r16SysCtrl0[0x200];
#pragma default_variable_attributes =

#pragma default_variable_attributes = @ ".R32_SysCtrl0"
volatile LWORD r32SysCtrl0[0x100];
#pragma default_variable_attributes =

#pragma default_variable_attributes = @ ".R8_EfuseCtrl"
volatile BYTE rEfuseCtrl[0x200];
#pragma default_variable_attributes =

#pragma default_variable_attributes = @ ".R16_EfuseCtrl"
volatile WORD r16EfuseCtrl[0x100];
#pragma default_variable_attributes =

#pragma default_variable_attributes = @ ".R32_EfuseCtrl"
volatile LWORD r32EfuseCtrl[0x80];
#pragma default_variable_attributes =

#pragma default_variable_attributes = @ ".R8_Tsb4Ctrl"
volatile BYTE rTsb4Ctrl[0x100];
#pragma default_variable_attributes =

#pragma default_variable_attributes = @ ".R16_Tsb4Ctrl"
volatile WORD r16Tsb4Ctrl[0x80];
#pragma default_variable_attributes =

#pragma default_variable_attributes = @ ".R32_Tsb4Ctrl"
volatile LWORD r32Tsb4Ctrl[0x40];
#pragma default_variable_attributes =

#pragma default_variable_attributes = @ ".R8_PCIe"
volatile BYTE rPcie[0x2000];
#pragma default_variable_attributes =

#pragma default_variable_attributes = @ ".R16_PCIe"
volatile WORD r16Pcie[0x1000];
#pragma default_variable_attributes =

#pragma default_variable_attributes = @ ".R32_PCIe"
volatile LWORD r32Pcie[0x800];
#pragma default_variable_attributes =

#pragma default_variable_attributes = @ ".R8_NVMe0"
volatile BYTE rNvme0[0x2000];
#pragma default_variable_attributes =

#pragma default_variable_attributes = @ ".R16_NVMe0"
volatile WORD r16Nvme0[0x1000];
#pragma default_variable_attributes =

#pragma default_variable_attributes = @ ".R32_NVMe0"
volatile LWORD r32Nvme0[0x800];
#pragma default_variable_attributes =

// -----------------Domain2----------------//
#pragma default_variable_attributes = @ ".R8_BvacCtrl"
volatile BYTE rBvacCtrl[0x100];
#pragma default_variable_attributes =

#pragma default_variable_attributes = @ ".R16_BvacCtrl"
volatile WORD r16BvacCtrl[0x80];
#pragma default_variable_attributes =

#pragma default_variable_attributes = @ ".R32_BvacCtrl"
volatile LWORD r32BvacCtrl[0x40];
#pragma default_variable_attributes =

#pragma default_variable_attributes = @ ".R8_VIC0"
volatile BYTE rSvic0[0x1000];
#pragma default_variable_attributes =

#pragma default_variable_attributes = @ ".R16_VIC0"
volatile WORD r16Svic0[0x800];
#pragma default_variable_attributes =

#pragma default_variable_attributes = @ ".R32_VIC0"
volatile LWORD r32Svic0[0x400];
#pragma default_variable_attributes =

#pragma default_variable_attributes = @ ".R64_VIC0"
volatile QWORD r64Svic0[0x200];
#pragma default_variable_attributes =

#pragma default_variable_attributes = @ ".R8_VIC1"
volatile BYTE rSvic1[0x1000];
#pragma default_variable_attributes =

#pragma default_variable_attributes = @ ".R16_VIC1"
volatile WORD r16Svic1[0x800];
#pragma default_variable_attributes =

#pragma default_variable_attributes = @ ".R32_VIC1"
volatile LWORD r32Svic1[0x400];
#pragma default_variable_attributes =

#pragma default_variable_attributes = @ ".R64_VIC1"
volatile QWORD r64Svic1[0x200];
#pragma default_variable_attributes =

#pragma default_variable_attributes = @ ".R8_AUX"
volatile BYTE rAux[0x1000];
#pragma default_variable_attributes =

#pragma default_variable_attributes = @ ".R16_AUX"
volatile WORD r16Aux[0x800];
#pragma default_variable_attributes =

#pragma default_variable_attributes = @ ".R32_AUX"
volatile LWORD r32Aux[0x400];
#pragma default_variable_attributes =

#pragma default_variable_attributes = @ ".R8_COH"
volatile BYTE rCoh[0x1000];
#pragma default_variable_attributes =

#pragma default_variable_attributes = @ ".R16_COH"
volatile WORD r16Coh[0x800];
#pragma default_variable_attributes =

#pragma default_variable_attributes = @ ".R32_COH"
volatile LWORD r32Coh[0x400];
#pragma default_variable_attributes =

#pragma default_variable_attributes = @ ".R8_DramCtrl"
volatile BYTE rDramCtrl[0x2000];
#pragma default_variable_attributes =

#pragma default_variable_attributes = @ ".R16_DramCtrl"
volatile WORD r16DramCtrl[0x1000];
#pragma default_variable_attributes =

#pragma default_variable_attributes = @ ".R32_DramCtrl"
volatile LWORD r32DramCtrl[0x800];
#pragma default_variable_attributes =

#pragma default_variable_attributes = @ ".APB_REG"
volatile BYTE rAPB[0x100000];
#pragma default_variable_attributes =

// -----------------Domain1----------------//
#pragma default_variable_attributes = @ ".R8_SysCtrl1"
volatile BYTE rSysCtrl1[0x100];
#pragma default_variable_attributes =

#pragma default_variable_attributes = @ ".R16_SysCtrl1"
volatile WORD r16SysCtrl1[0x80];
#pragma default_variable_attributes =

#pragma default_variable_attributes = @ ".R32_SysCtrl1"
volatile LWORD r32SysCtrl1[0x40];
#pragma default_variable_attributes =

#pragma default_variable_attributes = @ ".R8_BvaCtrl"
volatile BYTE rBvaCtrl[0x100];
#pragma default_variable_attributes =

#pragma default_variable_attributes = @ ".R16_BvaCtrl"
volatile WORD r16BvaCtrl[0x80];
#pragma default_variable_attributes =

#pragma default_variable_attributes = @ ".R32_BvaCtrl"
volatile LWORD r32BvaCtrl[0x40];
#pragma default_variable_attributes =

#pragma default_variable_attributes = @ ".R8_RsaCtrl"
volatile BYTE rRsaCtrl[0x200];
#pragma default_variable_attributes =

#pragma default_variable_attributes = @ ".R16_RsaCtrl"
volatile WORD r16RsaCtrl[0x100];
#pragma default_variable_attributes =

#pragma default_variable_attributes = @ ".R32_RsaCtrl"
volatile LWORD r32RsaCtrl[0x80];
#pragma default_variable_attributes =

#pragma default_variable_attributes = @ ".R8_I2cCtrl"
volatile BYTE rI2cCtrl[0x40];
#pragma default_variable_attributes =

#pragma default_variable_attributes = @ ".R16_I2cCtrl"
volatile WORD r16I2cCtrl[0x20];
#pragma default_variable_attributes =

#pragma default_variable_attributes = @ ".R32_I2cCtrl"
volatile LWORD r32I2cCtrl[0x10];
#pragma default_variable_attributes =

#pragma default_variable_attributes = @ ".R8_TsbCtrl"
volatile BYTE rTsbCtrl[0x800];
#pragma default_variable_attributes =

#pragma default_variable_attributes = @ ".R16_TsbCtrl"
volatile WORD r16TsbCtrl[0x400];
#pragma default_variable_attributes =

#pragma default_variable_attributes = @ ".R32_TsbCtrl"
volatile LWORD r32TsbCtrl[0x200];
#pragma default_variable_attributes =

#pragma default_variable_attributes = @ ".R8_ShaCtrl"
volatile BYTE rShaCtrl[0x80];
#pragma default_variable_attributes =

#pragma default_variable_attributes = @ ".R16_ShaCtrl"
volatile WORD r16ShaCtrl[0x40];
#pragma default_variable_attributes =

#pragma default_variable_attributes = @ ".R32_ShaCtrl"
volatile LWORD r32ShaCtrl[0x20];
#pragma default_variable_attributes =

#pragma default_variable_attributes = @ ".R8_TrngCtrl"
volatile BYTE rTrngCtrl[0x100];
#pragma default_variable_attributes =

#pragma default_variable_attributes = @ ".R16_TrngCtrl"
volatile WORD r16TrngCtrl[0x80];
#pragma default_variable_attributes =

#pragma default_variable_attributes = @ ".R32_TrngCtrl"
volatile LWORD r32TrngCtrl[0x40];
#pragma default_variable_attributes =

#pragma default_variable_attributes = @ ".R8_UartCtrl"
volatile BYTE rUartCtrl[0x100];
#pragma default_variable_attributes =

#pragma default_variable_attributes = @ ".R16_UartCtrl"
volatile WORD r16UartCtrl[0x80];
#pragma default_variable_attributes =

#pragma default_variable_attributes = @ ".R32_UartCtrl"
volatile LWORD r32UartCtrl[0x40];
#pragma default_variable_attributes =

#pragma default_variable_attributes = @ ".R8_EccDec"
volatile BYTE rEccDec[0x100];
#pragma default_variable_attributes =

#pragma default_variable_attributes = @ ".R16_EccDec"
volatile WORD r16EccDec[0x80];
#pragma default_variable_attributes =

#pragma default_variable_attributes = @ ".R32_EccDec"
volatile LWORD r32EccDec[0x40];
#pragma default_variable_attributes =

#pragma default_variable_attributes = @ ".R8_NBS"
volatile BYTE rNbs[0x200];
#pragma default_variable_attributes =

#pragma default_variable_attributes = @ ".R16_NBS"
volatile WORD r16Nbs[0x100];
#pragma default_variable_attributes =

#pragma default_variable_attributes = @ ".R32_NBS"
volatile LWORD r32Nbs[0x80];
#pragma default_variable_attributes =

#pragma default_variable_attributes = @ ".R8_BopCtrl"
volatile BYTE rBopCtrl[0x200];
#pragma default_variable_attributes =

#pragma default_variable_attributes = @ ".R16_BopCtrl"
volatile WORD r16BopCtrl[0x100];
#pragma default_variable_attributes =

#pragma default_variable_attributes = @ ".R32_BopCtrl"
volatile LWORD r32BopCtrl[0x80];
#pragma default_variable_attributes =

#pragma default_variable_attributes = @ ".R8_HdmaCtrl"
volatile BYTE rHdmaCtrl[0x200];
#pragma default_variable_attributes =

#pragma default_variable_attributes = @ ".R16_HdmaCtrl"
volatile WORD r16HdmaCtrl[0x100];
#pragma default_variable_attributes =

#pragma default_variable_attributes = @ ".R32_HdmaCtrl"
volatile LWORD r32HdmaCtrl[0x80];
#pragma default_variable_attributes =

#pragma default_variable_attributes = @ ".R8_LbaChk"
volatile BYTE rLbaChk[0x100];
#pragma default_variable_attributes =

#pragma default_variable_attributes = @ ".R16_LbaChk"
volatile WORD r16LbaChk[0x80];
#pragma default_variable_attributes =

#pragma default_variable_attributes = @ ".R32_LbaChk"
volatile LWORD r32LbaChk[0x40];
#pragma default_variable_attributes =

#pragma default_variable_attributes = @ ".R8_AesCtrl"
volatile BYTE rAesCtrl[0x800];
#pragma default_variable_attributes =

#pragma default_variable_attributes = @ ".R16_AesCtrl"
volatile WORD r16AesCtrl[0x400];
#pragma default_variable_attributes =

#pragma default_variable_attributes = @ ".R32_AesCtrl"
volatile LWORD r32AesCtrl[0x200];
#pragma default_variable_attributes =

#pragma default_variable_attributes = @ ".R8_SkipRam"
volatile BYTE rSkipRam[0x1000];
#pragma default_variable_attributes =

#pragma default_variable_attributes = @ ".R16_SkipRam"
volatile WORD r16SkipRam[0x800];
#pragma default_variable_attributes =

#pragma default_variable_attributes = @ ".R32_SkipRam"
volatile LWORD r32SkipRam[0x400];
#pragma default_variable_attributes =

#pragma default_variable_attributes = @ ".R8_FwAes"
volatile BYTE rFwAes[0x800];
#pragma default_variable_attributes =

#pragma default_variable_attributes = @ ".R16_FwAes"
volatile WORD r16FwAes[0x400];
#pragma default_variable_attributes =

#pragma default_variable_attributes = @ ".R32_FwAes"
volatile LWORD r32FwAes[0x200];
#pragma default_variable_attributes =

#pragma default_variable_attributes = @ ".R8_FakeCtrl"
volatile BYTE rFakeCtrl[0x1000];
#pragma default_variable_attributes =

#pragma default_variable_attributes = @ ".R16_FakeCtrl"
volatile WORD r16FakeCtrl[0x800];
#pragma default_variable_attributes =

#pragma default_variable_attributes = @ ".R32_FakeCtrl"
volatile LWORD r32FakeCtrl[0x400];
#pragma default_variable_attributes =

#pragma default_variable_attributes = @ ".R8_BvfORam"
volatile BYTE rBvfORam[0x4000];
#pragma default_variable_attributes =

#pragma default_variable_attributes = @ ".R16_BvfORam"
volatile WORD r16BvfORam[0x2000];
#pragma default_variable_attributes =

#pragma default_variable_attributes = @ ".R32_BvfORam"
volatile LWORD r32BvfORam[0x1000];
#pragma default_variable_attributes =

#pragma default_variable_attributes = @ ".R8_BvfBRam"
volatile BYTE rBvfBRam[0x4000];
#pragma default_variable_attributes =

#pragma default_variable_attributes = @ ".R16_BvfBRam"
volatile WORD r16BvfBRam[0x2000];
#pragma default_variable_attributes =

#pragma default_variable_attributes = @ ".R32_BvfBRam"
volatile LWORD r32BvfBRam[0x1000];
#pragma default_variable_attributes =

#pragma default_variable_attributes = @ ".R8_NVMe1"
volatile BYTE rNvme1[0x2800];
#pragma default_variable_attributes =

#pragma default_variable_attributes = @ ".R16_NVMe1"
volatile WORD r16Nvme1[0x1400];
#pragma default_variable_attributes =

#pragma default_variable_attributes = @ ".R32_NVMe1"
volatile LWORD r32Nvme1[0xA00];
#pragma default_variable_attributes =

#pragma default_variable_attributes = @ ".R8_NVMePrd"
volatile BYTE rNvmePrd[64][32];
#pragma default_variable_attributes =

#pragma default_variable_attributes = @ ".R16_NVMePrd"
volatile WORD r16NvmePrd[64][16];
#pragma default_variable_attributes =

#pragma default_variable_attributes = @ ".R32_NVMePrd"
volatile LWORD r32NvmePrd[64][8];
#pragma default_variable_attributes =

#pragma default_variable_attributes = @ ".R8_NVMeDesc"
volatile BYTE rNvmeDesc[64][32];
#pragma default_variable_attributes =

#pragma default_variable_attributes = @ ".R16_NVMeDesc"
volatile WORD r16NvmeDesc[64][16];
#pragma default_variable_attributes =

#pragma default_variable_attributes = @ ".R32_NVMeDesc"
volatile LWORD r32NvmeDesc[64][8];
#pragma default_variable_attributes =

#pragma default_variable_attributes = @ ".R8_NVMeHMB"
volatile BYTE rNvmeHmb[0xC000];
#pragma default_variable_attributes =

#pragma default_variable_attributes = @ ".R16_NVMeHMB"
volatile WORD r16NvmeHmb[0x6000];
#pragma default_variable_attributes =

#pragma default_variable_attributes = @ ".R32_NVMeHMB"
volatile LWORD r32NvmeHmb[0x3000];
#pragma default_variable_attributes =

#pragma default_variable_attributes = @ ".R8_FSHA"
volatile BYTE rFSHA[9][0x2000];
#pragma default_variable_attributes =

#pragma default_variable_attributes = @ ".R16_FSHA"
volatile WORD r16FSHA[9][0x1000];
#pragma default_variable_attributes =

#pragma default_variable_attributes = @ ".R32_FSHA"
volatile LWORD r32FSHA[9][0x800];
#pragma default_variable_attributes =

#pragma default_variable_attributes = @ ".R8_LDPcDsp"
volatile BYTE rLdpcDspCtrl[0x100000];
#pragma default_variable_attributes =

#pragma default_variable_attributes = @ ".R16_LDPcDsp"
volatile WORD r16LdpcDspCtrl[0x80000];
#pragma default_variable_attributes =

#pragma default_variable_attributes = @ ".R32_LDPcDsp"
volatile LWORD r32LdpcDspCtrl[0x40000];
#pragma default_variable_attributes =

#pragma default_variable_attributes = @ ".R8_LDPcDec"
volatile BYTE rLdpcDec[0x20000];
#pragma default_variable_attributes =

#pragma default_variable_attributes = @ ".R16_LDPcDec"
volatile WORD r16LdpcDec[0x10000];
#pragma default_variable_attributes =

#pragma default_variable_attributes = @ ".R32_LDPcDec"
volatile LWORD r32LdpcDec[0x8000];
#pragma default_variable_attributes =

#pragma default_variable_attributes = @ ".SLC_queue"
#if _EN_VPC_SWAP
LWORD g32DataBlockBitmap[64];    // 256/4
WORD g16GcSLCStartBlk;
WORD g16GcTLCStartBlk;
WORD g16DataBlkCnt;
#else
WORD g16SlcSortQFBlk[cMaxSlcBlkQ];    // 1k
BYTE gSlcSortQIdx[c16MaxBlockNum];    // 2k
LINKNODE garSlcSortQLink[cMaxSlcBlkQ];    // 1k
volatile LINKINFO gsSlcSortQList;
BYTE garFreeSlcSortQ[cMaxSlcBlkQ];    // 256B
LWORD g32FreeSlcSortQHead;
LWORD g32FreeSlcSortQTail;
#endif

#pragma default_variable_attributes =

// #pragma default_variable_attributes = @ ".RDCNT"

// LWORD g32arGlobReadCnt[c16MaxBlockNum];    // 8kb
// LWORD g32arPushReclaimQ[c16MaxBlockNum/32];    // 256b

// #pragma default_variable_attributes =

#pragma default_variable_attributes = @ ".ERASECNT"
#if (!_EN_VPC_SWAP)
WORD g16arGlobEraseCnt[c16MaxBlockNum];    // 2kb
#endif
#pragma default_variable_attributes =

#pragma default_variable_attributes = @ ".EVENTLOGBUF"
volatile WORD g16arCore1EventLog[cCore1EventLogSize];    // 1KB
#pragma default_variable_attributes =

#pragma default_variable_attributes = @ ".CORE1_VAR"
volatile LWORD *r32FLCtrl;
volatile LWORD *r32LdpcDsp;
// volatile LWORD *g32arEraseFlag;
// volatile LWORD *r32SkipRam2;
volatile WORD *r16FLCtrl;
volatile WORD *r16LdpcDsp;
volatile BYTE *rFLCtrl;
volatile BYTE *rLdpcDsp;    // 0x51200000
ADDRINFO *gpFlashAddrInfo;
SYSRSVINFO gsSysRsvInfo;
// WORD g16arCurrSysBlkEsCnt[cRsvSysBlkNum];    // current system block erased count
// WORD g16IdxBlkFreePagePtr;
BYTE gActiveCe;
BYTE garSprSel[cMaxChNum];
BYTE gErrInjectFlag;    // Bit 0: Read;Bit 1: Write
// WORD g16LastRdCntFBlock[cMaxChNum][cMaxIntlvWay];
BYTE gSysOpC1Flag;
WORD g16LastRdCntFBlock;
WORD g16LastRdCntFPage;

// Read Retry
RETRYINFO gsReadRetryInfo;
WORD g16RCCnt;    // Cwh, For Debug, can be removed.
WORD g16DebugLastFailChunkBitMap;
WORD g16DebugEnterFailChunkBitMap;
BYTE gRetryTablePassIndex[cMaxChNum][cMaxIntlvWay][2];    // [CH][Intlv][SLC/TLC]  4*32*2=256
BYTE garLastPassVthCenter[cMaxChNum][cMaxIntlvWay][cMaxRetryRegisterCnt];
BYTE garVthOffsetValue[cMaxRetryRegisterCnt];
BYTE garTrackVthCenter[cMaxRetryRegisterCnt];
RETRYINFO gsTestReadRetryInfo;
BYTE gCore1SeqFlag;
// BYTE garReadBufOccpyFlag[c16ReadBufSize4K];
BYTE garReadBufOrderHead[c16ReadBufSize4K];
BYTE garReadBufOrderTail[c16ReadBufSize4K];
WORD *g16arDiffOffset;
WORD *g16arDiffAddr;
WORD *g16arDiffType2Offset;
BYTE *garRtDiffPoolPtr;
WORD g16LdpcDmaIdCnt;
BYTE gEnableLdpcPipe;
WORD g16DebugDoubleLockCnt;
BYTE gNandVersion;

BYTE gPSWstate;

// RAID related
HDMAINFO gsHdmaCtrl;
RAIDINFO gsRaidInfo;

Tracking TrackingPara[cMaxChNum];
BYTE u8VthLowerShiftStep;
BYTE u8VthUpperShiftStep;
BYTE u8LowerShiftLeft;
BYTE u8UpperShiftLeft;
BYTE u8TLClimit;
BYTE u8ARlimit;
BYTE u8SLClimit;
BYTE u8GRlimit;
BYTE SetSpeciailRR;

LWORD g32PreCmdAleDebugCnt[3];

LWORD g32Cpu1CycleCnt0;
LWORD g32Cpu1CycleCnt1;
LWORD g32RetryTime;    // ns
LWORD g32RaidTime;    // ns

WORD g16EccFailNormalQueIndex;
WORD g16EccFailAuxQueIndex;
WORD g16EccFailChAndCe;
WORD g16EccFailDieAndPlane;
WORD g16EccFailBlkAddr;
WORD g16EccFailPageAddr;
WORD g16EccFailRegInfo;    // 0x118 & 0x11D
WORD g16EccFailChunkBitMap;    // g16DebugLastFailChunkBitMap
WORD g16WdVuEraseProgramSts;
PROGFAILINFO gsProgFailInfo;
LWORD g32arPushReclaimQ[c16MaxBlockNum/32];    // 256b
WORD g16MaxECInSpare;    // test by yhlin

#pragma default_variable_attributes =







