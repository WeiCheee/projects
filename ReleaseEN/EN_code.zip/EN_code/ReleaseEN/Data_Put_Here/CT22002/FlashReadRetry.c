







#include "inc/TypeDef.h"
#include "inc/Const.h"
#include "inc/table.h"
#include "inc/GlobVarS.h"
#include "inc/GlobVarT.h"
#include "inc/GlobVar1.h"
#include "inc/ProType.h"
#include "inc/Reg.h"
#include "inc/ProType.h"
#include "inc/Mac.h"
#include "inc/BitDef.h"
#include "inc/GreyBox.h"

#if (!_ICE_LOAD_ALL)
#pragma default_function_attributes = @ ".CORE1_CODE"
#endif
#include "inc/DebugLog.h"
#include "inc/EventLogIDX.h"
#include "inc/EventLogFunctionIDX.h"

// #include "FlashCmdDir.c"
void printVthCenter(BYTE *uDesVthTab)
{
#if 1
    NLOG(cLogCore1, FLASHREADRETRY_C, 4, "Vth Center AR: 0x%04X BR: 0x%04X CR: 0x%04X DR: 0x%04X ", (uDesVthTab[cAR]), (uDesVthTab[cBR]),
         (uDesVthTab[cBR]), (uDesVthTab[cDR]));
    // NLOG(cLogCore1, FLASHREADRETRY_C, 1, "Vth Center BR: 0x%04X ", (uDesVthTab[cBR]));
    // NLOG(cLogCore1, FLASHREADRETRY_C, 1, "Vth Center CR: 0x%04X ", (uDesVthTab[cCR]));
    // NLOG(cLogCore1, FLASHREADRETRY_C, 1, "Vth Center DR: 0x%04X ", (uDesVthTab[cDR]));
    NLOG(cLogCore1, FLASHREADRETRY_C, 4, "Vth Center ER: 0x%04X FR: 0x%04X GR: 0x%04X SLC: 0x%04X ", (uDesVthTab[cER]), (uDesVthTab[cFR]),
         (uDesVthTab[cGR]), (uDesVthTab[cSLC]));
    // NLOG(cLogCore1, FLASHREADRETRY_C, 1, "Vth Center FR: 0x%04X ", (uDesVthTab[cFR]));
    // NLOG(cLogCore1, FLASHREADRETRY_C, 1, "Vth Center GR: 0x%04X ", (uDesVthTab[cGR]));
    // NLOG(cLogCore1, FLASHREADRETRY_C, 1, "Vth Center SLC: 0x%04X ", (uDesVthTab[cSLC]));
#endif
}

void updateLogNandQueue()
{
#if (!_TSB_BiCS4_WR)
#if 0
    g16EccFailNormalQueIndex=rmGetCe0QueReadIndex;
    g16EccFailAuxQueIndex=rmGetAUXQueReadIndex;

    if(g16EccFailNormalQueIndex>=gWordCntOfLogNandQueue)
    {
        copyReg2Tsb32((volatile LWORD *)(&g32arLogNandQueue[0]),
                      &r32FLCtrl[(0x1000+2*(g16EccFailNormalQueIndex-gWordCntOfLogNandQueue))/4],
                      gDwordCntOfLogNandQueue);
    }
    else
    {
        copyReg2Tsb32((volatile LWORD *)(&g32arLogNandQueue[0]),
                      &r32FLCtrl[(0x1000+2*(cNorQEndAddr-(gWordCntOfLogNandQueue-g16EccFailNormalQueIndex)))/4],
                      (gDwordCntOfLogNandQueue-(g16EccFailNormalQueIndex/2)));
        copyReg2Tsb32((volatile LWORD *)(&g32arLogNandQueue[0+(gDwordCntOfLogNandQueue-(g16EccFailNormalQueIndex/2))]),
                      &r32FLCtrl[0x1000/4],
                      (g16EccFailNormalQueIndex/2));
    }
#else/* if 0 */
    WORD u16Index, u16QueIndex;
    WORD *upTempLogNandQueue=((WORD *)(&g32arLogNandQueue[0]));

    g16EccFailNormalQueIndex=u16QueIndex=rmGetCe0QueReadIndex;
    g16EccFailAuxQueIndex=rmGetAUXQueReadIndex;

    for(u16Index=0; u16Index<(gWordCntOfLogNandQueue); u16Index++)
    {
        if(u16QueIndex==0)
        {
            upTempLogNandQueue[(gWordCntOfLogNandQueue-1)-u16Index]=r16FLCtrl[(0x1000+2*u16QueIndex)/2];
            u16QueIndex=cNorQEndAddr;
        }
        else
        {
            upTempLogNandQueue[(gWordCntOfLogNandQueue-1)-u16Index]=r16FLCtrl[(0x1000+2*u16QueIndex)/2];
            u16QueIndex--;
        }
    }
#endif/* if 0 */
#endif/* if (!_TSB_BiCS4_WR) */
}    /* updateLogNandQueue */

void setReadRetryInfo(RETRYINFO *upRetryInfo)
{
    upRetryInfo->uRetryTabTyp=cbRetryTable[cRetryTabTypAddrOfst];    // chose X vendor Y nm Nand : reserve
    upRetryInfo->uRetryOpt=rmChkUNC;    // rFLCtrl[rcOPResultFlag]&(cRetryDat|cRetrySpr);
}

BYTE find1stUNCPlane(RETRYINFO *upRetryInfo)
{
    BYTE u1stUncPlane;
    WORD u16FLRegAddr;

    if(rmChkEccFail)
    {
        u16FLRegAddr=rcEccResultSts;
    }
    else if(rmChkOnesCntFail)
    {
        u16FLRegAddr=rcOnceCntstatus;
    }

    for(u1stUncPlane=0; u1stUncPlane<gPlaneNum; u1stUncPlane++)
    {
        if(rFLCtrl[u16FLRegAddr]&((WORD)cb32BitTab[u1stUncPlane+((upRetryInfo->uRetryOpt&cRetryDat)?0:4)]))
        {
            break;
        }
    }

    while(u1stUncPlane==gPlaneNum)
        ;

    return u1stUncPlane;
}    /* find1stUNCPlane */

#if _ENABLE_SOFTDECODE
void setBufferFlag(ADDRINFO *upRdRetryAddr)
{
    WORD u16StartBufIdx;
    BYTE uStartSctrH;

    u16StartBufIdx=upRdRetryAddr->u16BufPtr;
    uStartSctrH=upRdRetryAddr->uSectorH;

    for(BYTE uLoop=0; uLoop<upRdRetryAddr->uRwHalfKb; uLoop++)
    {
        if(mChkBitMask(rmGetChunkEccStsCurrentMap, uStartSctrH>>2))
        {
#if _ENABLE_RAID
#if _EN_RAID_GC
            if((upRdRetryAddr->uOpTyp==cPreReadData)||(upRdRetryAddr->uOpTyp==cLastReadData)||
               (!gsGcInfo.uHmbEnGcCache&&((upRdRetryAddr->uOpTyp==cMoveReadData)||(upRdRetryAddr->u16RwOpt&cReadGcDesF2h))))
#else
            if((upRdRetryAddr->uOpTyp==cPreReadData)||(upRdRetryAddr->uOpTyp==cLastReadData))
#endif
            {
                rmSetBufRaid8Sts(u16StartBufIdx>>3, (BYTE)cb32BitTab[u16StartBufIdx&7]);
            }
            else
#endif
            {
                rmSetBuf8Sts(u16StartBufIdx>>3, (BYTE)cb32BitTab[u16StartBufIdx&7]);
            }
        }

        if(u16StartBufIdx<c16Tsb1SIdx)
        {
            u16StartBufIdx=addReadBufPtr(u16StartBufIdx, 1);
        }
        else
        {
            u16StartBufIdx+=1;
        }

        uStartSctrH++;
    }
}    /* setBufferFlag */

void doLDPCSeparateTrack(BYTE uStepSize, RETRYINFO *upRetryInfo)
{
    BYTE uSoftMode, uLoop;
    BYTE uReadCnt, uTotalReadTimes;

    // rmRstFLSts;
    // rmRstOnesCnt;

    uSoftMode=1;    // Use N4 Tracking
    rmSetLdpcSoftMode(uSoftMode*2);
    uTotalReadTimes=uSoftMode*2+1;

    uLoop=0;
    rmSetUNC;

    while((uLoop<2)&&rmChkUNC)
    {
        rmResetEccSts;
        rmResetOnesCnt;
        rmDisWaitDMADone;

        for(uReadCnt=0; uReadCnt<uTotalReadTimes; uReadCnt++)
        {
            rmSetLdpcSoftIdx(uReadCnt);

            replaceVthTabForSeparateTrack(garVthOffsetValue,
                                          TrackingPara[gActiveCh].u8arTrackVthCenter,
                                          uLoop,
                                          TrackingPara[gActiveCh].u8arSoftStep,
                                          uReadCnt);

            if(uReadCnt==(uTotalReadTimes-1))
            {
                // Last read at this Loop
                rmEnWaitDMADone;
            }

            flashReadRetry(upRetryInfo);

            TrackingPara[gActiveCh].u8RetryCnt=uReadCnt;    // 0: first read, //1: second read, // 2: third read....,etc
            TrackingPara[gActiveCh].u8CurPageType=upRetryInfo->uRetryPageTyp;    // (1) LSB=0, (2) CSB=1, (3 )MSB=2, (4) SLC=4, (5)
                                                                                 // SLCPageOnTLC=8, (6) MLCPageOnTLC=12
            TrackingPara[gActiveCh].u8SoftMode=(uSoftMode*2);    // N4: 1,//N6: 2,//N8: 3
            TrackingPara[gActiveCh].ubEnSeparateTrack=1;    // 0:disable //1:enable

            if(uLoop)
            {
                TrackingPara[gActiveCh].ubEnSeparateUpper=0;    // 0: tracking DR and FR, //1: tracking BR and DR
            }
            else
            {
                TrackingPara[gActiveCh].ubEnSeparateUpper=1;    // 0: tracking DR and FR, //1: tracking BR and DR
            }

            gLDPC_Vth_tracking(&TrackingPara[gActiveCh]);
        }

        uLoop++;
    }
}    /* doLDPCSeparateTrack */

void setRRCmdAle(RETRYINFO *upRetryInfo, BYTE uUnderRetry)
{
    rmSelData;

    flashChangeDieCmd(upRetryInfo->usReadRetryAddr.uDieAddr);
    chkRlibMoCmd();
    setAutoAleReg(mGetPageSelCmdS(upRetryInfo->usReadRetryAddr));    // upRetryInfo->usReadRetryAddr.uPageSelCmd);

    if(upRetryInfo->usReadRetryAddr.u16RwOpt&c16Bit0)
    {
        setMultiPlaneRead();
        mWaitCmdFifoBz;
        setAutoFBlock(gIntlvAddr, gPlaneAddr);
    }
    else
    {
        setSinglePlaneRead(0);
    }

    pollStatus(cPollMaskNor);
    rmCle(gReadMoCmd);

    if((uUnderRetry&cRetryForceSpr)&&(upRetryInfo->usReadRetryAddr.u16RwOpt&c16Bit5)&&(upRetryInfo->uRetryOpt&(cRetryDat)))
    {
        // for one plane read data + spare
        gPlaneAddr=upRetryInfo->usReadRetryAddr.uPlaneAddr;
        rmSelSpr;
        setRandomoutCmd(0);
        rmSelData;
    }

    mWaitCmdFifoBz;
}    /* setRRCmdAle */

void dataIn1Byte(BYTE uValue)
{
    BYTE uBackUp=rFLCtrl[rcRwMode];

    rmNop(cTwhr);

    // mWaitCmdFifoBz;
    if(rmChkToggleMo||rmChkOnfi2Mo)
    {
        rFLCtrl[rcRd0]=uValue;
        rFLCtrl[rcRd1]=uValue;
        rmManWr(1);
        rmNop(cTwhr);
        mWaitCmdFifoBz;
    }
    else
    {
        rFLCtrl[rcRd0]=uValue;
        rmManWr(1);
        rmNop(cTwhr);
        mWaitCmdFifoBz;
    }

    rFLCtrl[rcRwMode]=uBackUp;
}    /* dataIn1Byte */

void setRetryCmd(RETRYINFO *upRetryInfo, BYTE uWait)
{
// #if !_EN_DDR400MBs
    if(!mChkFLOption(cONFIMo))    // if (!gbONFIMo)
    {
        rmEnAleCleDoubleCycle;
        rmEnACle2Cycle;
    }

// #endif

#if (_TSB_BiCS3||_SANDISK_3D_GEN2||_SANDISK_3D_GEN3||_TSB_BiCS4)
    inputBiCS3TLCRRCmd(upRetryInfo, uWait);
#endif

    if(!mChkFLOption(cONFIMo))    // if (!gbONFIMo)
    {
#if 1
        if(rmGpioP06SelToggle||mChkFLParam(cManToTogMo))
        {
            rmEnToggleMo;
            sysDelay(16);
        }
        else
        {
            rmEnBusEDOMo;
        }
#endif
// #if !_EN_DDR400MBs
        rmEnAleCleDoubleCycle;
        rmEnACle2Cycle;
// #endif
    }
}    /* setRetryCmd */

void flashReadRetry(RETRYINFO *upRetryInfo)
{
    // BYTE uMode;
    WORD u16TempChunkEccStsMap;

#if _EN_CacheR
    upRetryInfo->usReadRetryAddr.u16RwOpt&=~c16Bit3;
#endif

    gpFlashAddrInfo=(ADDRINFO *)&(upRetryInfo->usReadRetryAddr);
    // uMode=(BYTE)(mChkMlcMoBit(g16FBlock)>>30);

    // if((mChkFLParam(cMPlaneMo))&&(mChkFLOption(cEnMPlaneRead)))
    // {}
    // else
    // {
    //    upRetryInfo->usReadRetryAddr.u16RwOpt&=~c16Bit0;
    // }

    setAutoFBlock(gIntlvAddr, gPlaneAddr);
    setRetryCmd(upRetryInfo, c16Bit0);    // FIFO Depth = 15
    setRRCmdAle(upRetryInfo, 0);    // FIFO Depth = F

    if(upRetryInfo->uRetryOpt&cRetryForceSpr)
    {
        trigReadSpare(upRetryInfo->usReadRetryAddr.u16RwOpt&c16Bit0);
    }
    else
    {
        setRandomoutCmd(upRetryInfo->usReadRetryAddr.u16RwOpt&c16Bit0);    // FIFO Depth= 4
        rmSetBufSAddr(upRetryInfo->usReadRetryAddr.u16BufPtr);
        setAutoRead2(upRetryInfo->usReadRetryAddr.uRwHalfKb, upRetryInfo->usReadRetryAddr.u16RwOpt);    // FIFO Depth = 5

        while(rmGetChunkEccStsUpdateFlag)
            ;

        while(rmChkCmdFifoBz)
            ;

        sysDelay(cRetryRegDelayCnt);
        rmDisReadRetry;
        sysDelay(cRetryRegDelayCnt);
        u16TempChunkEccStsMap=rmGetChunkEccStsMap;

        while(rmChkCmdFifoBz)
            ;

        rmEnReadRetry;
        sysDelay(cRetryRegDelayCnt);

        if(rmChkEccFail)
        {
            if(upRetryInfo->uRetryOpt&cRetryForceSpr)
            {}
            else
            {
                if(u16TempChunkEccStsMap==0x00)
                {
                    while(rFLCtrl[0x0118])
                        ;
                }
            }
        }

        while(rmChkCmdFifoBz)
            ;
    }
}    /* flashReadRetry */

// *****************************************************************************/
// Idx  5   3   1
//                 0   2   4   6
// ----|---|---|---|---|---|---|----->
//
//             LowerDis[]                               UpperDis[]
//
// 1to0 [4] [2] [0]                                          [1] [3] [5]
// ----|---|---|---|---|---|---|----------------|---|---|---|---|---|---|----->
// 0to1             [1] [3] [5]                  [4] [2] [0]
// ******************************************************************************/
void doLDPCSoftDecode(BYTE uStepSize, BYTE uSoftMode, RETRYINFO *upRetryInfo)    // uSoftMode=1:N4, 2:N6, 3:N8
{
    BYTE uReadCnt, uTotalReadTimes;
    BYTE uProtectOver;

    rmResetEccSts;
    rmResetOnesCnt;
    rmGetLdpcEccBit=0x00;
    rmSetLdpcSoftMode(uSoftMode*2);    // 0:N2, 1:N4, 2:N6, 3:N8

    if(uSoftMode>0)    // do LDPC
    {
        uProtectOver=cRetryLDPC;
    }
    else
    {
        uProtectOver=0;
    }

    rmDisWaitDMADone;    // LDPC retry only
    uTotalReadTimes=uSoftMode*2+1;
    uReadCnt=0;

    while(uReadCnt<uTotalReadTimes)
    {
        rmSetLdpcSoftIdx(uReadCnt);

        if(uSoftMode!=0)    // do LDPC
        {
            replaceVthTabForTrackingPara(garVthOffsetValue,
                                         TrackingPara[gActiveCh].u8arTrackVthCenter,
                                         (upRetryInfo->uRetryPageTyp|uProtectOver),
                                         TrackingPara[gActiveCh].u8arSoftStep,
                                         uReadCnt);
        }
        else
        {
            replaceVthTab(garVthOffsetValue, garTrackVthCenter, (upRetryInfo->uRetryPageTyp|uProtectOver), 0);
        }

        if(uReadCnt==(uTotalReadTimes-1))
        {
            rmEnWaitDMADone;
        }

        flashReadRetry(upRetryInfo);    // trigger read command and read data

        if(uSoftMode>0)
        {
            TrackingPara[gActiveCh].u8RetryCnt=uReadCnt;    // 0: first read, //1: second read, // 2: third read ,etc
            TrackingPara[gActiveCh].u8SoftMode=(uSoftMode*2);    // N4: 1,//N6: 2,//N8: 3
            TrackingPara[gActiveCh].PageKSize=
                getTrackingPageKSize(upRetryInfo->usReadRetryAddr.uSectorH, upRetryInfo->usReadRetryAddr.uRwHalfKb);
            gLDPC_Vth_tracking(&TrackingPara[gActiveCh]);
        }

        uReadCnt++;
    }

#if _EN_RAID_DECODE
    if(rmChkUNC&&(uSoftMode==3)&&(uStepSize>1)&&(upRetryInfo->uRetryPageTyp==cCSB)&&
       ((!mChkRaidDecF(cRaidUnderDecode))||(!rmChkEccFailForceXfr)))
#else
    if(rmChkUNC&&(uSoftMode==3)&&(uStepSize>1)&&(upRetryInfo->uRetryPageTyp==cCSB))
#endif
    {
        doLDPCSeparateTrack(uStepSize, upRetryInfo);
    }
}    /* doLDPCSoftDecode */

/***************************/
//
// 80    C0    0    40    7F
// -|----------|-----------|->
/**************************/
void replaceVthTab(BYTE *uDesVthTab, BYTE *uSrcVthTab, BYTE uPageTyp, BYTE uShiftCnt)
{
    BYTE uLoop, uTempVth;
    BYTE uPageSel, uPageMod;

    uPageSel=uPageTyp&cRetryTypMsk;
    uPageMod=uPageTyp&cRetryModMsk;

    for(uLoop=0; uLoop<cRetryRegNum; uLoop++)
    {
        uTempVth=uSrcVthTab[uLoop]+uShiftCnt;

        if(uPageSel!=cAllWL)
        {
            if(uPageSel==cLSB)
            {
#if (_TSB_BiCS3||_SANDISK_3D_GEN2||_SANDISK_3D_GEN3||_TSB_BiCS4)
                if(!((uLoop==cAR)||(uLoop==cER)))
#endif
                {
                    continue;
                }
            }
            else if(uPageSel==cCSB)
            {
                if(!((uLoop==cBR)||(uLoop==cDR)||(uLoop==cFR)))
                {
                    continue;
                }
            }
            else if(uPageSel==cMSB)
            {
                // MSB
#if (_TSB_BiCS3||_SANDISK_3D_GEN2||_SANDISK_3D_GEN3||_TSB_BiCS4)
                if(!((uLoop==cCR)||(uLoop==cGR)))
#endif
                {
                    continue;
                }
            }
            else
            {
                // SLC
                if(!(uLoop==cSLCR))
                {
                    continue;
                }
            }

            if(uPageMod==cRetryLDPC)
            {
                // protect Vth overflow
                if((!(uSrcVthTab[uLoop]&cBit7))&&(!(uShiftCnt&cBit7)))
                {
                    //       "+"                                          "+"
                    if(uTempVth&cBit7)
                    {
                        //        "-"
                        uTempVth=cRetryMaxShiftRStep;
                    }
                }
                else if((uSrcVthTab[uLoop]&cBit7)&&(uShiftCnt&cBit7))
                {
                    //                      "-"                        "-"
                    if(!(uTempVth&cBit7))
                    {
                        //         "+"
                        uTempVth=cRetryMaxShiftLStep;
                    }
                }
            }
        }

        uDesVthTab[uLoop]=uTempVth;
    }
}    /* replaceVthTab */

void setTestRetryCmd()
{
    BYTE uIndex, uTempVth[cMaxRetryRegisterCnt];
    RETRYINFO *upRetryInfo;

#if _GREYBOX
    if((gsGbInfo.uGreyBoxItem==cReadRetryDecodeTestID)||(gsGbInfo.uGreyBoxItem==cErrHdlReadUncInSlcDataID)\
       ||(gsGbInfo.uGreyBoxItem==cErrHdlReadUncInTlcDataID)||(gsGbInfo.uGreyBoxItem==cRAIDDecOnH2fTab)\
       ||(gsGbInfo.uGreyBoxItem==cRAIDDecOnH2f1kTab)||(gsGbInfo.uGreyBoxItem==cRAIDDecOnNormData)\
       ||(gsGbInfo.uGreyBoxItem==cRAIDDecOnOpenData)||(gsGbInfo.uGreyBoxItem==cRAIDDecOnPreReadData)\
       ||(gsGbInfo.uGreyBoxItem==cRAIDDecOnLastReadData)||(gsGbInfo.uGreyBoxItem==cRAIDDecOnMoveReadData)\
       ||(gsGbInfo.uGreyBoxItem==cErrHdlProgWPROID)||(gsGbInfo.uGreyBoxItem==cErrHdlGcFingerFailTestID))
    {
        outCS(cbTagsetTestRetryCmd);
    }
#endif

    // gsTestReadRetryInfo.usReadRetryAddr=gsFlashAddrInfoTemp;    // .u16FBlock=g16FBlock;
    copyCcmVal((BYTE *)&(gsTestReadRetryInfo.usReadRetryAddr), (BYTE *)&gsFlashAddrInfoTemp, sizeof(ADDRINFO));
    upRetryInfo=&gsTestReadRetryInfo;
#if 1
    if(!mChkMlcMoBit(upRetryInfo->usReadRetryAddr.u16FBlock))
    {
        upRetryInfo->uRetryPageTyp=cSLC;
    }
    else
    {
        upRetryInfo->uRetryPageTyp=mGetPageSelCmdS(gsTestReadRetryInfo.usReadRetryAddr)-1;    // upRdRetryAddr->uPageSelCmd-1;
    }

    if(gEnableLdpcPipe==cLdpcPipeLineDisableMode)
    {
        upRetryInfo->uRetryOpt=rmChkUNC;    // rFLCtrl[rcOPResultFlag]&(cRetryDat|cRetrySpr);
    }
    else
    {
        upRetryInfo->uRetryOpt=cRetryDat;
    }
#endif/* if 1 */

    for(uIndex=0; uIndex<cMaxRetryRegisterCnt; uIndex++)
    {
        uTempVth[uIndex]=garVthOffsetValue[uIndex];
        garVthOffsetValue[uIndex]=garVuCmdVthCenter[uIndex];
    }

    if(!mChkFLOption(cONFIMo))    // if (!gbONFIMo)
    {
        rmEnAleCleDoubleCycle;
        rmEnACle2Cycle;
    }

#if (_TSB_BiCS3||_SANDISK_3D_GEN2||_SANDISK_3D_GEN3||_TSB_BiCS4)
    inputBiCS3TLCRRCmd(upRetryInfo, 1);
#endif

    if(!mChkFLOption(cONFIMo))    // if (!gbONFIMo)
    {
        if(rmGpioP06SelToggle||mChkFLParam(cManToTogMo))
        {
            rmEnToggleMo;
            sysDelay(16);
        }
        else
        {
            rmEnBusEDOMo;
        }

        rmEnAleCleDoubleCycle;    // rmDisAleCleDoubleCycle;
        rmEnACle2Cycle;
    }

    for(uIndex=0; uIndex<cMaxRetryRegisterCnt; uIndex++)
    {
        garVthOffsetValue[uIndex]=uTempVth[uIndex];
    }
}    /* setTestRetryCmd */

#if (_TSB_BiCS3||_SANDISK_3D_GEN2||_SANDISK_3D_GEN3||_TSB_BiCS4)
void inputBiCS3TLCRRCmd(RETRYINFO *upRetryInfo, BYTE uWaitCmdFifo)
{
    BYTE uFeatureAddr, uFeaturePara[4];
    BYTE uRetryRegNum;
    BYTE uRegCnt;
    BYTE uFeatureDataCnt;

    if(!mChkMlcMoBit(upRetryInfo->usReadRetryAddr.u16FBlock))
    {
        uFeatureAddr=cRetryFeatureAddrSLC;
        uRetryRegNum=cRetryRegNumSLC;
    }
    else
    {
        uFeatureAddr=cRetryFeatureAddrTLC;
        uRetryRegNum=cRetryRegNumTLC;
    }

    uRegCnt=0;

    while(uRetryRegNum>uRegCnt)
    {
        // SM2256 HW DQS_N BUG
#if 1    // _EN_DDR400MBs
        pollStatus(cPollMaskNor);
        rmCmdEnCeMsk;
        rmManWr(1);
        mWaitCmdFifoBz;
        rmCmdDisCeMsk;
#endif
        // --> SM2256 HW DQS_N BUG END

        if(mChkCardMode(cMultiDie))
        {
            rmCle(0xD5);
            rmAle(upRetryInfo->usReadRetryAddr.uDieAddr);
        }
        else
        {
            rmCle(gSetFeatureCmd);
        }

        rmAle(uFeatureAddr);
        mWaitCmdFifoBz;
        rmNop(cTwhr);

        for(uFeatureDataCnt=0; uFeatureDataCnt<4; uFeatureDataCnt++)
        {
            if(uRegCnt>=uRetryRegNum)
            {
                uFeaturePara[uFeatureDataCnt]=0x00;    // invalid data byte, for align 4 bytes
            }
            else if(!mChkMlcMoBit(upRetryInfo->usReadRetryAddr.u16FBlock))
            {
                uFeaturePara[uFeatureDataCnt]=garVthOffsetValue[cSLCR];
            }
            else
            {
                uFeaturePara[uFeatureDataCnt]=garVthOffsetValue[uRegCnt];
            }

            uRegCnt++;
        }

        writeFourData(uFeaturePara[0], uFeaturePara[1], uFeaturePara[2], uFeaturePara[3]);
        rmNop(cTwhr);
        pollStatus(cPollMaskNor);
        // mWaitCmdFifoBz;

        uFeatureAddr++;
    }

#if (_SANDISK_3D_GEN2||_SANDISK_3D_GEN3)
    rmCle(0x5D);    // dynamic read
#endif

    if(uWaitCmdFifo)
    {
        mWaitCmdFifoBz;
    }
}    /* inputSNDK1yTLCRRCmd */

#endif/* if (_TSB_BiCS3) */

#if _EN_RAID_DECODE
void setRaidDecInfo(ADDRINFO *upRetryInfo, BYTE uRdEccFailIdx)
{
    if(!mChkRaidDecF(cRaidUnderDecode)&&(gsRaidInfo.uRaidDecQueCnt<gTotalIntlvChNum))
    {
        gsRaidInfo.u16arErrChunkMap[gsRaidInfo.uRaidDecFifoHead]=rmGetChunkEccStsMap;
        gsRaidInfo.uarRaidDecQue[gsRaidInfo.uRaidDecFifoHead].u16FBlock=upRetryInfo->u16FBlock;
        gsRaidInfo.uarRaidDecQue[gsRaidInfo.uRaidDecFifoHead].u32FPageNoTran=upRetryInfo->u32FPageNoTran;
        gsRaidInfo.uarRaidDecQue[gsRaidInfo.uRaidDecFifoHead].u16FPage=upRetryInfo->u16FPage;
        gsRaidInfo.uarRaidDecQue[gsRaidInfo.uRaidDecFifoHead].u16BufPtr=upRetryInfo->u16BufPtr;
        gsRaidInfo.uarRaidDecQue[gsRaidInfo.uRaidDecFifoHead].u16RwOpt=upRetryInfo->u16RwOpt;
        gsRaidInfo.uarRaidDecQue[gsRaidInfo.uRaidDecFifoHead].uRwHalfKb=upRetryInfo->uRwHalfKb;
        gsRaidInfo.uarRaidDecQue[gsRaidInfo.uRaidDecFifoHead].uIntlvAddr=upRetryInfo->uIntlvAddr;
        gsRaidInfo.uarRaidDecQue[gsRaidInfo.uRaidDecFifoHead].uCh=upRetryInfo->uCh;
        gsRaidInfo.uarRaidDecQue[gsRaidInfo.uRaidDecFifoHead].uDieAddr=upRetryInfo->uDieAddr;
        gsRaidInfo.uarRaidDecQue[gsRaidInfo.uRaidDecFifoHead].uPlaneAddr=upRetryInfo->uPlaneAddr;
        gsRaidInfo.uarRaidDecQue[gsRaidInfo.uRaidDecFifoHead].uSectorH=upRetryInfo->uSectorH;
        gsRaidInfo.uarRaidDecQue[gsRaidInfo.uRaidDecFifoHead].uOpTyp=upRetryInfo->uOpTyp;
        gsRaidInfo.uarRaidDecQue[gsRaidInfo.uRaidDecFifoHead].uPrdPtr=upRetryInfo->uPrdPtr;
        gsRaidInfo.uarRaidDecQue[gsRaidInfo.uRaidDecFifoHead].uPageSelCmd=mGetPageSelCmd(upRetryInfo);
        gsRaidInfo.uarRaidDecQue[gsRaidInfo.uRaidDecFifoHead].uRdEccFailIdx=uRdEccFailIdx;
        gsRaidInfo.uRaidDecFifoHead=addPtrBy1(gsRaidInfo.uRaidDecFifoHead, cRaidDecQueDepth);
        gsRaidInfo.uRaidDecQueCnt++;

        if(!mChkRaidDecF(cRaidEnableDecode))
        {
            mSetRaidDecF(cRaidEnableDecode);
            g32DecodeWait=cTrue;
        }
    }
}    /* setRaidDecInfo */

#endif/* if _EN_RAID_DECODE */

void readRetryMarkBad(ADDRINFO *upRdRetryAddr)
{
    if(!(mChkMlcMoBit(upRdRetryAddr->u16FBlock)))
    {
        if(!(gsReadRetryInfo.usReadRetryAddr.u16RwOpt&c16Bit10))
        {
#if _GREYBOX
            if((gsGbInfo.uGreyBoxItem==cReadRetryDecodeTestID)||(gsGbInfo.uGreyBoxItem==cErrHdlReadUncInSlcDataID)\
               ||(gsGbInfo.uGreyBoxItem==cErrHdlReadUncInTlcDataID)||(gsGbInfo.uGreyBoxItem==cRAIDDecOnH2fTab)\
               ||(gsGbInfo.uGreyBoxItem==cRAIDDecOnH2f1kTab)||(gsGbInfo.uGreyBoxItem==cRAIDDecOnNormData)\
               ||(gsGbInfo.uGreyBoxItem==cRAIDDecOnOpenData)||(gsGbInfo.uGreyBoxItem==cRAIDDecOnPreReadData)\
               ||(gsGbInfo.uGreyBoxItem==cRAIDDecOnLastReadData)||(gsGbInfo.uGreyBoxItem==cRAIDDecOnMoveReadData)\
               ||(gsGbInfo.uGreyBoxItem==cErrHdlProgWPROID)||(gsGbInfo.uGreyBoxItem==cErrHdlGcFingerFailTestID)\
               ||((gsGbInfo.uGreyBoxItem==cSecurityRW)&&((gsGbInfo.uGreyBoxOpt&0x01)&&(gsGbInfo.uGreyBoxOpt&0x2))))
            {
                gErrInjectFlag=0x00;
                gReadErrinjectEn=cFalse;
            }
            else
#endif
            {
#if _DEBUG_UECC
                while(g32Core1State>=cCore1BootState_Finished)
                    ;
#endif
            }

            // markRdEccFailBlock
            gsFtlDbg.u16MarkBadCount++;
            setMarkBadBlock(&gsReadRetryInfo.usReadRetryAddr, cRdEccFailID+gsReadRetryInfo.uRetryStartLevel);
        }
    }
    else
    {
        // TLC
        if(!(gsReadRetryInfo.usReadRetryAddr.u16RwOpt&c16Bit10))
        {
            // c16Bit10--pass Ecc fail MarkBad
#if _GREYBOX
            if((gsGbInfo.uGreyBoxItem==cReadRetryDecodeTestID)||(gsGbInfo.uGreyBoxItem==cErrHdlReadUncInSlcDataID)\
               ||(gsGbInfo.uGreyBoxItem==cErrHdlReadUncInTlcDataID)||(gsGbInfo.uGreyBoxItem==cRAIDDecOnH2fTab)\
               ||(gsGbInfo.uGreyBoxItem==cRAIDDecOnH2f1kTab)||(gsGbInfo.uGreyBoxItem==cRAIDDecOnNormData)\
               ||(gsGbInfo.uGreyBoxItem==cRAIDDecOnOpenData)||(gsGbInfo.uGreyBoxItem==cRAIDDecOnPreReadData)\
               ||(gsGbInfo.uGreyBoxItem==cRAIDDecOnLastReadData)||(gsGbInfo.uGreyBoxItem==cRAIDDecOnMoveReadData)\
               ||(gsGbInfo.uGreyBoxItem==cErrHdlProgWPROID)||(gsGbInfo.uGreyBoxItem==cErrHdlGcFingerFailTestID)\
               ||((gsGbInfo.uGreyBoxItem==cSecurityRW)&&((gsGbInfo.uGreyBoxOpt&0x01)&&(gsGbInfo.uGreyBoxOpt&0x2))))
            {
                gErrInjectFlag=0x00;
                gReadErrinjectEn=cFalse;
            }
#endif

            if(gPSWstate==1)
            {
                setMarkBadBlock(&gsReadRetryInfo.usReadRetryAddr, cS2TPWRFailID);
            }
            else
            {
                setMarkBadBlock(&gsReadRetryInfo.usReadRetryAddr, cTLCRdEccFailID);
            }

            gsFtlDbg.u16MarkBadCount++;
        }
    }
}    /* readRetryMarkBad */

void doReadRetry(ADDRINFO *upRdSrcAddr, BYTE uEccFailPlaneIndex, BYTE uOpt)
{
    ADDRINFO *upRdRetryAddr;
    BYTE uSoftStep=0, uN8Loop=0, uSoftMode=0, uRetryTableSet=0, uRetryTabLoop=0;
    BYTE uPlaneIndex=0, uEccFailPlane=0, uPipeLineMode=0;
    WORD u16UncBitMap;
    BYTE uEccChunk;
    BYTE uRdEccFailIdx;
    WORD u16FPage;
    BYTE u8Type=0;

#if _LiteOn_RR_MdfyDrv
    BYTE uTranDrvingLoop=0;
    BYTE uRecov=0;
#endif

    setFLActCh(upRdSrcAddr->uCh);

#if _ENABLE_CPU_CYCLE_COUNTER
    if(mChkRaidDecF(cRaidDecOptMsk)&cRaidUnderDecode)
    {}
    else
    {
        initCyclecounter();
        g32Cpu1CycleCnt0=getCycleCounter();
    }
#endif

    uPipeLineMode=(uOpt&cLdpcPipeLineEnableMode);

    if(uPipeLineMode==cLdpcPipeLineDisableMode)
    {
        for(uPlaneIndex=0; uPlaneIndex<gPlaneNum; uPlaneIndex++)
        {
            if(rmGetPlaneUNCBit&cbBitTab[uPlaneIndex])
            {
                uEccFailPlane=uPlaneIndex;
                break;
            }
        }
    }
    else
    {
        uEccFailPlane=uEccFailPlaneIndex;
    }

#if _DEBUG_READECC
    ctrlErrInject(0, 0, 0, 0, 0);    // rmDisErrInject;
#endif
#if _EN_CacheR
    upRdSrcAddr->u16RwOpt&=~c16Bit3;
#endif

    if(uPipeLineMode==cLdpcPipeLineEnableMode)
    {
        rmDisDmaPipe;
    }

    ctrlAuxQue(cIntoAuxQue);

    calRetryPara(&gsReadRetryInfo, upRdSrcAddr, uEccFailPlane, uPipeLineMode);
    upRdRetryAddr=&(gsReadRetryInfo.usReadRetryAddr);
    setFLAddrActCh(upRdSrcAddr->uCh, upRdRetryAddr);

    if(gOpTyp!=cVenderRead)
    {
        gsFtlDbg.u32RRCnt++;
    }

#if _ENABLE_CPU_CYCLE_COUNTER
    if(mChkRaidDecF(cRaidDecOptMsk)&cRaidUnderDecode)
    {
#if (!_EN_LiteonRetryLog)
        NLOG(cLogCore1, FLASHREADRETRY_C, 0, "## Retry in Raid Decode ##");
#endif
    }
    else
    {
#if (!_EN_LiteonRetryLog)
        NLOG(cLogCore1, FLASHREADRETRY_C, 0, "## Retry ##");
#endif
        initCyclecounter();
        g32Cpu1CycleCnt0=getCycleCounter();
    }
#endif
#if _DEBUG_LOG
#if (!_EN_LiteonRetryLog)
    printNandPhyAddr(gpFlashAddrInfo);
#else
    if(!(mChkMlcMoBit(gpFlashAddrInfo->u16FBlock)))
    {
        // SLC
        u8Type=0;

        if(mChkFLParam(cWithRlibMo))
        {
            u16FPage=gpFlashAddrInfo->u16FPage;
            // NLOG(cLogCore1, DEBUGLOGCORE1_C, 1, "Page: 0x%04X ", upTmpAddrInfo->u16FPage);
        }
        else if(mChkCardMode(cWithSlcMo))
        {
            u16FPage=gpFlashAddrInfo->u16FPage<<1;
            // NLOG(cLogCore1, DEBUGLOGCORE1_C, 1, "Page: 0x%04X ", (upTmpAddrInfo->u16FPage<<1));
        }
    }
    else
    {
        // TLC
        u8Type=1;
#if (_TSB_BiCS3|_SANDISK_3D_GEN2|_SANDISK_3D_GEN3|_TSB_BiCS4)
        u16FPage=(cProgCntPerWL*(gpFlashAddrInfo->u16FPage))+mGetPageSelCmd(gpFlashAddrInfo)-1;
        // NLOG(cLogCore1, DEBUGLOGCORE1_C, 1, "Page: 0x%04X ", ((cProgCntPerWL*(upTmpAddrInfo->u16FPage))+mGetPageSelCmd(upTmpAddrInfo)-1));
#endif
    }
#endif/* if (!_EN_LiteonRetryLog) */
#endif/* if _DEBUG_LOG */
#if (!_EN_LiteonRetryLog)
    if(gOpTyp==cHostReadData)
    {
        NLOG(cLogCore1, FLASHREADRETRY_C, 2, "LBA : 0x%08X ", ((gsPrdInfo.uarPrdQue[gpFlashAddrInfo->uPrdPtr].u32LbaAddr)>>16),
             ((gsPrdInfo.uarPrdQue[gpFlashAddrInfo->uPrdPtr].u32LbaAddr)));
    }
#endif

    if(uPipeLineMode==cLdpcPipeLineEnableMode)
    {
        rmCeOn(gCe);
    }

#if _EN_CacheR
#if  _EN_MutiWayCacheRImprove
    if(gsRwCtrl.uEnCacheR&&
       ((gsRwCtrl.usWaitInfo[upRdSrcAddr->uCh][upRdSrcAddr->uIntlvAddr].uWaitFlag==cCacheRCmd)||
        (gsRwCtrl.usWaitInfo[upRdSrcAddr->uCh][upRdSrcAddr->uIntlvAddr].uWaitFlag==cCacheRCmd1)||
        (gsRwCtrl.usWaitInfo[upRdSrcAddr->uCh][upRdSrcAddr->uIntlvAddr].uWaitFlag==cCache3FCmd)))
#else
    if(gsRwCtrl.uEnCacheR&&
       ((gsRwCtrl.usWaitInfo[upRdSrcAddr->uCh][upRdSrcAddr->uIntlvAddr].uWaitFlag==cCacheRCmd)||
        (gsRwCtrl.usWaitInfo[upRdSrcAddr->uCh][upRdSrcAddr->uIntlvAddr].uWaitFlag==cCacheRCmd1)))
#endif

    {
        rmSetDieBit(mGetDieAddr(upRdSrcAddr->uIntlvAddr));
        pollStatus(cPollMaskNor);
#if  _EN_MutiWayCacheRImprove
        if(gsRwCtrl.usWaitInfo[upRdSrcAddr->uCh][upRdSrcAddr->uIntlvAddr].uWaitFlag!=cCache3FCmd)
#endif
        {
            rmCle(gLastPageCacheReadCmd);
            pollStatus(cPollMaskNor);
        }

        mWaitCmdFifoBz;
    }
#endif/* if _EN_CacheR */

#if _USE_LAST_PASS_VTHTRACKING
    uRetryTabLoop=0;

    if(gRetryTablePassIndex[upRdSrcAddr->uCh][upRdSrcAddr->uIntlvAddr][gbLsbOnly]==0)
    {
        replaceVthTab(garTrackVthCenter, garLastPassVthCenter[upRdSrcAddr->uCh][upRdSrcAddr->uIntlvAddr], cAllWL, 0);
#if (!_EN_LiteonRetryLog)
        NLOG(cLogCore1, FLASHREADRETRY_C, 0, "Use LastPass Vthtracking Center");
        printVthCenter(garTrackVthCenter);
#endif
    }
    else
    {
        uRetryTableSet=((gRetryTablePassIndex[upRdSrcAddr->uCh][upRdSrcAddr->uIntlvAddr][gbLsbOnly]+uRetryTabLoop)%(gTotalRetryTimes+1));
        replaceVthTab(garTrackVthCenter,
                      (BYTE *)&(cbRetryTable[(WORD)cRetryValAddrOfst+uRetryTableSet*cRetryRegNum+gNandVersion*cRetryVerAddrOfst]), cAllWL, 0);
#if (!_EN_LiteonRetryLog)
        NLOG(cLogCore1, FLASHREADRETRY_C, 1, "LastPass RetryTable PassIndex: 0x%04X ", (uRetryTableSet));
#endif
    }
#else/* if _USE_LAST_PASS_VTHTRACKING */
    uRetryTabLoop=0;
    uRetryTableSet=((gRetryTablePassIndex[upRdSrcAddr->uCh][upRdSrcAddr->uIntlvAddr][gbLsbOnly]+uRetryTabLoop)%(gTotalRetryTimes+1));
    replaceVthTab(garTrackVthCenter,
                  (BYTE *)&(cbRetryTable[(WORD)cRetryValAddrOfst+uRetryTableSet*cRetryRegNum+gNandVersion*cRetryVerAddrOfst]),
                  cAllWL,
                  0);
#endif/* if _USE_LAST_PASS_VTHTRACKING */

    if(upRdSrcAddr->uOpTyp==cChkFakeSlcProgramFail)
    {
        gTotalRetryTimes=cFakeProgramFailRetryTableCheckIndex;
        uRetryTabLoop=0;
        uRetryTableSet=0;
        replaceVthTab(garTrackVthCenter,
                      (BYTE *)&(cbRetryTable[(WORD)cRetryValAddrOfst+uRetryTableSet*cRetryRegNum+gNandVersion*cRetryVerAddrOfst]), cAllWL, 0);
        NLOG(cLogCore1, FLASHREADRETRY_C, 0, "OpTyp==cChkFakeSlcProgramFail !! Force Normal Read Vth LV");
    }

    // initial Vth shift table
    fillCcmVal(garVthOffsetValue, cRetryRegNum, 0);

    if(uPipeLineMode==cLdpcPipeLineDisableMode)
    {
        g16DebugEnterFailChunkBitMap=rmGetChunkEccStsMap;
    }
    else
    {
        g16DebugEnterFailChunkBitMap=rmGetLdpcErrInfoBitMap;
        rmDisReadRetry;
        sysDelay(cRetryRegDelayCnt);
        rmSetChunkEccStsMap(g16DebugEnterFailChunkBitMap);
        rmEnReadRetry;
    }

    if((upRdSrcAddr->u16RwOpt&c16Bit4)&&(gsReadRetryInfo.uRetryOpt&(cRetryDat)))
    {
#if (!_EN_LiteonRetryLog)
        NLOG(cLogCore1, FLASHREADRETRY_C, 0, "Read Data Space Start");
        NLOG(cLogCore1, FLASHREADRETRY_C, 1, "FailChunkBitMap: 0x%04X ", g16DebugEnterFailChunkBitMap);
#endif

        // using LDPC to Read data space
        if(gsReadRetryInfo.uRetryPageTyp!=cSLC)
        {
            rmSetLdpcPageType(gsReadRetryInfo.uRetryPageTyp);
            uSoftStep=cLDPCSoftStep;    // fixing shift step no mater SLC/TLC
            uN8Loop=0;
        }
        else
        {
            rmSetLdpcPageType(cLSB);
            uN8Loop=cLDPCN8LoopCnt-1;    // SLC do N8 once
            uSoftStep=cLDPCSlcMoSoftStep;
        }

#if _BypassRetryTable
        uSoftMode=1;    // MIKEY:start from N4, uSoftMode=1:N4, 2:N6, 3:N8
        uRetryTabLoop=gTotalRetryTimes+1;
#else
        uSoftMode=0;    // Finn: start from Retry table *** SanDisk request
#endif

// #if _DEBUG_RtyDataToN8
        g16DebugLastFailChunkBitMap=rmGetChunkEccStsMap;
// #endif

        rmSetUNC;

#if 0    // _ENABLE_E2E_TAB
        while((rmChkUNC||((!rmChkUNC&&uTableCrcCnt)&&(gSecurityOption&cEnE2e)))&&(uN8Loop<cLDPCN8LoopCnt))
#else
        while(rmChkUNC&&(uN8Loop<cLDPCN8LoopCnt))
#endif
        {
            if((uSoftMode==0)&&(uRetryTabLoop>0))
            {
                // retry table
#if _RetryTableContinue
                // uRetryTableSet=((gRetryTablePassIndex[upRdSrcAddr->uCh][upRdSrcAddr->uIntlvAddr][gbLsbOnly]+uRetryTabLoop)%(gTotalRetryTimes+1));
                uRetryTableSet=((uRetryTabLoop)%(gTotalRetryTimes+1));
#else
                uRetryTableSet=((uRetryTabLoop)%(gTotalRetryTimes+1));
#endif
                replaceVthTab(garTrackVthCenter,
                              (BYTE *)&(cbRetryTable[(WORD)cRetryValAddrOfst+uRetryTableSet*cRetryRegNum+gNandVersion*cRetryVerAddrOfst]),
                              cAllWL,
                              0);
                // debug trig retry set
            }
            else if(uSoftMode==1)
            {
                // LDPC
                // fillCcmVal(garTrackVthCenter,cRetryRegNum,0);
#if (_BypassRetryTable||_En_SoftDecodeFromVth0)
                gsReadRetryInfo.uRetryStartLevel=0;
#else
                gsReadRetryInfo.uRetryStartLevel=gRetryTablePassIndex[upRdSrcAddr->uCh][upRdSrcAddr->uIntlvAddr][gbLsbOnly]
#endif
                replaceVthTab(garTrackVthCenter,
                              (BYTE *)&(cbRetryTable[(WORD)cRetryValAddrOfst+gsReadRetryInfo.uRetryStartLevel*cRetryRegNum+gNandVersion*
                                                     cRetryVerAddrOfst]),
                              cAllWL,
                              0);

#if _ENABLE_ECC_TEAM_TRACKING_MODULE
                TrackingPara[gActiveCh].u8SoftMode=(uSoftMode*2);    // N4: 1,//N6: 2,//N8: 3
                TrackingPara[gActiveCh].ubFirstLoopInitalize=1;    // set to 1
                TrackingPara[gActiveCh].ubEnTracking=1;
                TrackingPara[gActiveCh].u8SoftNLoop=cLDPCN8LoopCnt;
                TrackingPara[gActiveCh].u8RetryCnt=0;    // set to 0
                TrackingPara[gActiveCh].ubEnSeparateTrack=0;    // set to 0
                TrackingPara[gActiveCh].u8ActiveCh=gActiveCh;    // active channel#

                if(gsReadRetryInfo.uRetryPageTyp==cSLC)
                {
                    TrackingPara[gActiveCh].u8CurPageType=4;    // (1) LSB=0, (2) CSB=1, (3 )MSB=2, (4) SLC=4, (5) SLCPageOnTLC=8, (6)
                    // MLCPageOnTLC=12
                }
                else
                {
                    TrackingPara[gActiveCh].u8CurPageType=gsReadRetryInfo.uRetryPageTyp;    // (1) LSB=0, (2) CSB=1, (3 )MSB=2, (4) SLC=4, (5)
                    // SLCPageOnTLC=8, (6) MLCPageOnTLC=12
                }
                gLDPC_Vth_tracking(&TrackingPara[gActiveCh]);
#endif/* if (_ENABLE_ECC_TEAM_TRACKING_MODULE) */
            }

#if 1    // !_BypassLdpcSoftDecode
            if((uN8Loop==(cLDPCN8LoopCnt-1))&&(uSoftMode==3))    // the last read retry
            {
#if _EN_RAID_DECODE
                if(mChkRaidDecF(cRaidUnderDecode))
                {
                    rmSetEccFailForceXfr;
                }
#else
                rmSetEccFailForceXfr;
#endif
            }
#else
            if(uRetryTabLoop==gTotalRetryTimes)
            {
                rmSetEccFailForceXfr;
            }
#endif

            doLDPCSoftDecode(uSoftStep, uSoftMode, &gsReadRetryInfo);

            if(rmChkUNC)
            {
                if(uSoftMode==3)    // MIKEY:In N8 state, fine tune the Vth shift step size
                {
                    uN8Loop++;

                    if((uN8Loop%cLDPCSoftLoopPerDecStep)==0)    // 4 loop decrease 1
                    {
                        uSoftStep--;    // fixing shift step no mater SLC/TLC
                    }
                }
                else
                {
                    if((upRdSrcAddr->uOpTyp==cChkFakeSlcProgramFail)&&(uRetryTabLoop==0))
                    {
                        NLOG(cLogCore1, FLASHREADRETRY_C, 1, "OpTyp==cChkFakeSlcProgramFail !! uRetryTabLoop: 0x%04X ", (uRetryTabLoop));
                        break;
                    }

#if _LiteOn_RR_MdfyDrv
                    if(uTranDrvingLoop<3)
                    {
                        uTranDrvingLoop++;
                        modifyDring(upRdSrcAddr->uCh, uTranDrvingLoop);

                        if(uTranDrvingLoop<3)
                        {
                            uRecov=1;
                        }
                        else
                        {
                            uRecov=0;
                        }
                    }

                    if((uTranDrvingLoop>=3)&&(uRetryTabLoop<=gTotalRetryTimes))
#else/* if _LiteOn_RR_MdfyDrv */
                    if(uRetryTabLoop<=gTotalRetryTimes)
#endif/* if _LiteOn_RR_MdfyDrv */
                    {
                        // retry table
                        uRetryTabLoop++;    // max
#if _GREYBOX
                        if((gsGbInfo.uGreyBoxItem==cReadRetryDecodeTestID)||(gsGbInfo.uGreyBoxItem==cErrHdlReadUncInSlcDataID)\
                           ||(gsGbInfo.uGreyBoxItem==cErrHdlReadUncInTlcDataID)||(gsGbInfo.uGreyBoxItem==cRAIDDecOnH2fTab)\
                           ||(gsGbInfo.uGreyBoxItem==cRAIDDecOnH2f1kTab)||(gsGbInfo.uGreyBoxItem==cRAIDDecOnNormData)\
                           ||(gsGbInfo.uGreyBoxItem==cRAIDDecOnOpenData)||(gsGbInfo.uGreyBoxItem==cRAIDDecOnPreReadData)\
                           ||(gsGbInfo.uGreyBoxItem==cRAIDDecOnLastReadData)||(gsGbInfo.uGreyBoxItem==cRAIDDecOnMoveReadData)\
                           ||(gsGbInfo.uGreyBoxItem==cErrHdlProgWPROID)||(gsGbInfo.uGreyBoxItem==cErrHdlGcFingerFailTestID)\
                           ||((gsGbInfo.uGreyBoxItem==cSecurityRW)&&((gsGbInfo.uGreyBoxOpt&0x01)&&(gsGbInfo.uGreyBoxOpt&0x2))))
                        {
                            if(uRetryTabLoop>g16GbRetryTabLoop)
                            {
                                gErrInjectFlag&=(~cBit0);
                            }
                        }
#endif
#if 0    // _DEBUG_RtyDataToN8
                        rmSetChunkEccStsMap(g16DebugLastFailChunkBitMap);
                        // r16FLCtrl[rcUNCBitmap]=g16DebugLastFailChunkBitMap;
                        rmSetUNC;
#endif
                    }

                    if(uRetryTabLoop>gTotalRetryTimes)    // after using "gTotalRetryTimes" set
                    {
                        // LDPC
                        uSoftMode++;
#if (!_EN_LiteonRetryLog)
                        NLOG(cLogCore1, FLASHREADRETRY_C, 1, "Soft Decode Start SoftMode=0x%04X", uSoftMode);
#endif

                        if(gOpTyp!=cVenderRead)
                        {
                            if(gbLsbOnly)
                            {
                                gsFtlDbg.u32SlcRetryTableFailCnt++;
                            }
                            else
                            {
                                gsFtlDbg.u32TlcRetryTableFailCnt++;
                            }
                        }

#if _GREYBOX
                        if((gsGbInfo.uGreyBoxItem==cReadRetryDecodeTestID)||(gsGbInfo.uGreyBoxItem==cErrHdlReadUncInSlcDataID)\
                           ||(gsGbInfo.uGreyBoxItem==cErrHdlReadUncInTlcDataID)||(gsGbInfo.uGreyBoxItem==cRAIDDecOnH2fTab)\
                           ||(gsGbInfo.uGreyBoxItem==cRAIDDecOnH2f1kTab)||(gsGbInfo.uGreyBoxItem==cRAIDDecOnNormData)\
                           ||(gsGbInfo.uGreyBoxItem==cRAIDDecOnOpenData)||(gsGbInfo.uGreyBoxItem==cRAIDDecOnPreReadData)\
                           ||(gsGbInfo.uGreyBoxItem==cRAIDDecOnLastReadData)||(gsGbInfo.uGreyBoxItem==cRAIDDecOnMoveReadData)\
                           ||(gsGbInfo.uGreyBoxItem==cErrHdlProgWPROID)||(gsGbInfo.uGreyBoxItem==cErrHdlGcFingerFailTestID)\
                           ||((gsGbInfo.uGreyBoxItem==cSecurityRW)&&((gsGbInfo.uGreyBoxOpt&0x01)&&(gsGbInfo.uGreyBoxOpt&0x2))))
                        {
                            if((uSoftMode==1)&&(gsGbInfo.uGreyBoxItem==cReadRetryDecodeTestID))
                            {
                                gErrInjectFlag&=(~cBit0);
                            }
                        }
#endif
                    }
                }

#if _BypassLdpcSoftDecode
                if(uSoftMode>0)
                {
                    break;
                }
#endif
            }
            else
            {
#if 0    // _ENABLE_E2E_TAB
                uTableCrcCnt=chkReadTableCrcCnt(upRdSrcAddr);
#endif
            }
        }

        if(upRdSrcAddr->u16RwOpt&c16Bit3)
        {
#if 0
            gpRDTBadInfo->SprECC=uRetryTableSet;
            gpRDTBadInfo->UECC=uSoftMode;
#else
            // Cache Read
            while(g32Core1State>=cCore1BootState_Finished)
                ;
#endif
        }

#if (!_EN_LiteonRetryLog)
        // end of using LDPC to Read data space
        NLOG(cLogCore1, FLASHREADRETRY_C, 0, "Read Data Space End");
#endif
    }
    else if((upRdSrcAddr->u16RwOpt&c16Bit5)&&(gsReadRetryInfo.uRetryOpt&(cRetrySpr))&&(uPipeLineMode==cLdpcPipeLineDisableMode))
    {
#if (!_EN_LiteonRetryLog)
        NLOG(cLogCore1, FLASHREADRETRY_C, 0, "Read Spare 26 Byte Start");
#endif
        enRetryDataOnesCnt(upRdSrcAddr->uOpTyp);
        // using retry set to read spare byte
        gsReadRetryInfo.uRetryOpt|=cRetryForceSpr;

        // uRetryTableSet=0;
        rmSetSprUNC;

        while((rmSprUNC&&(uRetryTabLoop<=gTotalRetryTimes)))
        {
            // set retry set
            if(uRetryTabLoop==0)
            {
                // using former read retry set
                replaceVthTab(garVthOffsetValue, (BYTE *)&garTrackVthCenter, cAllWL, 0);
            }
            else
            {
                // SPEC retry table
#if _RetryTableContinue
                // uRetryTableSet=((gRetryTablePassIndex[upRdSrcAddr->uCh][upRdSrcAddr->uIntlvAddr][gbLsbOnly]+uRetryTabLoop)%(gTotalRetryTimes+1));
                uRetryTableSet=((uRetryTabLoop)%(gTotalRetryTimes+1));
#else
                uRetryTableSet=((uRetryTabLoop)%(gTotalRetryTimes+1));
#endif
                replaceVthTab(garVthOffsetValue,
                              (BYTE *)&(cbRetryTable[(WORD)cRetryValAddrOfst+uRetryTableSet*cRetryRegNum+gNandVersion*cRetryVerAddrOfst]),
                              cAllWL,
                              0);
            }

            rmResetEccSts;
            rmResetOnesCnt;
            rFLCtrl[rcDatMaxErrCnt]=rFLCtrl[rcSpareMaxErrCnt]=0;
            flashReadRetry(&gsReadRetryInfo);

            mWaitCmdFifoBz;

#if 0    // _DEBUG_RtyDataToN8
            rmSetSprUNC;
#endif

            if(!rmSprUNC)
            {
                // for record
                replaceVthTab(garTrackVthCenter, garVthOffsetValue, cAllWL, 0);
            }
            else
            {
                if((upRdSrcAddr->uOpTyp==cChkFakeSlcProgramFail)&&(uRetryTabLoop==0))
                {
                    NLOG(cLogCore1, FLASHREADRETRY_C, 1, "OpTyp==cChkFakeSlcProgramFail !! uRetryTabLoop: 0x%04X ", (uRetryTabLoop));
                    break;
                }

#if _LiteOn_RR_MdfyDrv
                if(uTranDrvingLoop<3)
                {
                    uTranDrvingLoop++;
                    modifyDring(upRdSrcAddr->uCh, uTranDrvingLoop);

                    if(uTranDrvingLoop<3)
                    {
                        uRecov=1;
                    }
                    else
                    {
                        uRecov=0;
                    }
                }

                if(uTranDrvingLoop>=3)
                {
                    uRetryTabLoop++;
                }
#else/* if _LiteOn_RR_MdfyDrv */
                uRetryTabLoop++;
#endif/* if _LiteOn_RR_MdfyDrv */
#if _GREYBOX
                if((gsGbInfo.uGreyBoxItem==cReadRetryDecodeTestID)||(gsGbInfo.uGreyBoxItem==cErrHdlReadUncInSlcDataID)\
                   ||(gsGbInfo.uGreyBoxItem==cErrHdlReadUncInTlcDataID)||(gsGbInfo.uGreyBoxItem==cRAIDDecOnH2fTab)\
                   ||(gsGbInfo.uGreyBoxItem==cRAIDDecOnH2f1kTab)||(gsGbInfo.uGreyBoxItem==cRAIDDecOnNormData)\
                   ||(gsGbInfo.uGreyBoxItem==cRAIDDecOnOpenData)||(gsGbInfo.uGreyBoxItem==cRAIDDecOnPreReadData)\
                   ||(gsGbInfo.uGreyBoxItem==cRAIDDecOnLastReadData)||(gsGbInfo.uGreyBoxItem==cRAIDDecOnMoveReadData)\
                   ||(gsGbInfo.uGreyBoxItem==cErrHdlProgWPROID)||(gsGbInfo.uGreyBoxItem==cErrHdlGcFingerFailTestID)\
                   ||((gsGbInfo.uGreyBoxItem==cSecurityRW)&&((gsGbInfo.uGreyBoxOpt&0x01)&&(gsGbInfo.uGreyBoxOpt&0x2))))
                {
                    if(uRetryTabLoop>g16GbRetryTabLoop)
                    {
                        gErrInjectFlag&=(~cBit0);
                    }
                }
#endif
            }
        }

        disRetryDataOnesCnt(upRdSrcAddr->uOpTyp);
#if (!_EN_LiteonRetryLog)
        NLOG(cLogCore1, FLASHREADRETRY_C, 0, "Read Spare 26 Byte End");
#endif
    }
    else
    {
        // Bug. it's not data or spare. who is this Error?
        while(g32Core1State>=cCore1BootState_Finished)
            ;
    }

#if _ENABLE_CPU_CYCLE_COUNTER
    if(mChkRaidDecF(cRaidDecOptMsk)&cRaidUnderDecode)
    {}
    else
    {
        g32Cpu1CycleCnt1=getCycleCounter();
        g32RetryTime=(g32Cpu1CycleCnt1-g32Cpu1CycleCnt0)*(1000/(tran2DecClk()/1000000));
#if (!_EN_LiteonRetryLog)
        NLOG(cLogCore1, FLASHREADRETRY_C, 2, "RetryTime(ns): 0x%08x", g32RetryTime>>16, g32RetryTime);
#endif
    }
#endif

#if _LiteOn_RR_MdfyDrv
    if(uRecov)
    {
        modifyDring(upRdSrcAddr->uCh, 0);
    }
#endif

    if(rmChkUNC)
    {
        gRetryTablePassIndex[upRdSrcAddr->uCh][upRdSrcAddr->uIntlvAddr][gbLsbOnly]=0;

        rmDisReadRetry;
        g16DebugLastFailChunkBitMap=rmGetChunkEccStsMap;
        sysDelay(cRetryRegDelayCnt);
#if (!_EN_LiteonRetryLog)
        NLOG(cLogCore1, FLASHREADRETRY_C, 0, "ECC Fail");
        NLOG(cLogCore1, FLASHREADRETRY_C, 1, "Last FailChunkBitMap: 0x%04X ", g16DebugLastFailChunkBitMap);
#else
        NLOG(cLogCore1,
             FLASHREADRETRY_C,
             6,
             "doReadRetry() ECC Fail !! ->TLCmode: 0x%04X,CH: 0x%04X,CE: 0x%04X,Plan: 0x%04X,Block: 0x%04X,Page: 0x%04X",
             u8Type,
             garChMapTable[gpFlashAddrInfo->uCh],
             garCeMapTable[gpFlashAddrInfo->uCe],
             gpFlashAddrInfo->uPlaneAddr,
             getDiffFBlock(gpFlashAddrInfo->u16FBlock, gpFlashAddrInfo->uCh, gpFlashAddrInfo->uIntlvAddr, gpFlashAddrInfo->uPlaneAddr),
             u16FPage);
#endif/* if (!_EN_LiteonRetryLog) */

        while(rmChkCmdFifoBz)
            ;

        rmEnReadRetry;

        for(uEccChunk=0; uEccChunk<16; uEccChunk++)
        {
            if(rmGetChunkEccStsCurrentMap&((WORD)cb32BitTab[uEccChunk]))
            {
                u16UncBitMap|=(WORD)cb32BitTab[div(((upRdRetryAddr->uPlaneAddr*16)+uEccChunk), 4)];
            }
        }

        rmDisReadRetry;
        sysDelay(cRetryRegDelayCnt);

        gbEccFail|=1;

        if(rmChkOnesCntFail)
        {
            gbOnesCntFail=1;
        }

        if(gsReadRetryInfo.uRetryOpt&cRetrySpr)
        {
            gbSprEccFail|=1;

            if(gOpTyp!=cVenderRead)
            {
                if(gbLsbOnly)
                {
                    gsFtlDbg.u32SlcRetryTableFailCnt++;
                }
                else
                {
                    gsFtlDbg.u32TlcRetryTableFailCnt++;
                }
            }
        }
        else
        {
            gbDataEccFail=1;    // gbReadRetryF=1;

            if(gOpTyp!=cVenderRead)
            {
                if(gbLsbOnly)
                {
                    gsFtlDbg.u32SlcVthTrackingFailCnt++;
                }
                else
                {
                    gsFtlDbg.u32TlcVthTrackingFailCnt++;
                }
            }
        }

        mSetBitMask(gPlaneUNCSts[upRdRetryAddr->uCh], upRdRetryAddr->uPlaneAddr);

        if(upRdSrcAddr->uOpTyp==cHostReadData)
        {
#if _DEBUG_UECC
            while(g32Core1State>=cCore1BootState_Finished)
                ;
#endif
#if (!_EN_RAID_DECODE)
            if(gsPrdInfo.uarPrdQue[gsReadRetryInfo.usReadRetryAddr.uPrdPtr].uHwPrdIdx!=cNull)
            {
                rmNvmeSetUncFlag(gsPrdInfo.uarPrdQue[gsReadRetryInfo.usReadRetryAddr.uPrdPtr].uHwPrdIdx);
                gsPrdInfo.uarPrdQue[gsReadRetryInfo.usReadRetryAddr.uPrdPtr].uUncFlag=cUncAfterTrig;
            }
            else
            {
                gsPrdInfo.uarPrdQue[gsReadRetryInfo.usReadRetryAddr.uPrdPtr].uUncFlag=cUncBeforeTrig;
            }

#if _GREYBOX
            if((gsGbInfo.uGreyBoxItem==cReadRetryDecodeTestID)||(gsGbInfo.uGreyBoxItem==cErrHdlReadUncInSlcDataID)\
               ||(gsGbInfo.uGreyBoxItem==cErrHdlReadUncInTlcDataID)||(gsGbInfo.uGreyBoxItem==cRAIDDecOnH2fTab)\
               ||(gsGbInfo.uGreyBoxItem==cRAIDDecOnH2f1kTab)||(gsGbInfo.uGreyBoxItem==cRAIDDecOnNormData)\
               ||(gsGbInfo.uGreyBoxItem==cRAIDDecOnOpenData)||(gsGbInfo.uGreyBoxItem==cRAIDDecOnPreReadData)\
               ||(gsGbInfo.uGreyBoxItem==cRAIDDecOnLastReadData)||(gsGbInfo.uGreyBoxItem==cRAIDDecOnMoveReadData)\
               ||(gsGbInfo.uGreyBoxItem==cErrHdlProgWPROID)||(gsGbInfo.uGreyBoxItem==cErrHdlGcFingerFailTestID)\
               ||((gsGbInfo.uGreyBoxItem==cSecurityRW)&&((gsGbInfo.uGreyBoxOpt&0x01)&&(gsGbInfo.uGreyBoxOpt&0x2))))
            {
                gErrInjectFlag=0x00;
                gReadErrinjectEn=cFalse;
            }
#endif
#endif/* if (!_EN_RAID_DECODE) */
            // codeFuncPtr4[cfuncChkTermReadAhead](upRdSrcAddr);
            // chkTermReadAhead(&upRdRetryAddr);
            // chkTermReadAhead(ADDRINFO *upRdSrcAddr)
        }
        else if((upRdSrcAddr->uOpTyp==cReclaimReadData)||(upRdSrcAddr->uOpTyp==cMoveReadData))
        {
#if _GREYBOX
            if((gsGbInfo.uGreyBoxItem==cReadRetryDecodeTestID)||(gsGbInfo.uGreyBoxItem==cErrHdlReadUncInSlcDataID)\
               ||(gsGbInfo.uGreyBoxItem==cErrHdlReadUncInTlcDataID)||(gsGbInfo.uGreyBoxItem==cRAIDDecOnH2fTab)\
               ||(gsGbInfo.uGreyBoxItem==cRAIDDecOnH2f1kTab)||(gsGbInfo.uGreyBoxItem==cRAIDDecOnNormData)\
               ||(gsGbInfo.uGreyBoxItem==cRAIDDecOnOpenData)||(gsGbInfo.uGreyBoxItem==cRAIDDecOnPreReadData)\
               ||(gsGbInfo.uGreyBoxItem==cRAIDDecOnLastReadData)||(gsGbInfo.uGreyBoxItem==cRAIDDecOnMoveReadData)\
               ||(gsGbInfo.uGreyBoxItem==cErrHdlProgWPROID)||(gsGbInfo.uGreyBoxItem==cErrHdlGcFingerFailTestID)\
               ||((gsGbInfo.uGreyBoxItem==cSecurityRW)&&((gsGbInfo.uGreyBoxOpt&0x01)&&(gsGbInfo.uGreyBoxOpt&0x2))))
            {
                gErrInjectFlag=0x00;
                gReadErrinjectEn=cFalse;
            }
            else
#endif
            {
#if _DEBUG_UECC
                while(g32Core1State>=cCore1BootState_Finished)
                    ;
#endif
            }

            // codeFuncPtr10[cfuncClrDesF2hInfo](upRdSrcAddr, u16UncBitMap);
            // clrDesF2hInfo(&upRdRetryAddr, u16UncBitMap);
        }

        // WD CMD Que Info
#if 1
        g16EccFailChAndCe=((garChMapTable[gCh]<<8)|garCeMapTable[gCe]);
        g16EccFailDieAndPlane=((gDieAddr<<8)|gStartPlaneAddr);
        // g16EccFailBlkAddr=g16AbstrFBlock;
        g16EccFailBlkAddr=getDiffAddr(g16AbstrFBlock, gCh, gIntlvAddr, gStartPlaneAddr);

        if(gbLsbOnly)
        {
            if(mChkFLParam(cWithRlibMo))
            {
                g16EccFailPageAddr=g16FPage;
            }
            else if(mChkCardMode(cWithSlcMo))
            {
                g16EccFailPageAddr=(g16FPage<<1);
            }
        }
        else
        {
#if (_TSB_BiCS3|_SANDISK_3D_GEN2|_SANDISK_3D_GEN3|_TSB_BiCS4)
            g16EccFailPageAddr=((cProgCntPerWL*g16FPage)+mGetPageSelCmd(gpFlashAddrInfo)-1);
#endif
        }

        g16EccFailRegInfo=((rFLCtrl[rcEccResultSts]<<8)|rFLCtrl[rcOnceCntstatus]);    // 0x118 & 0x11D
        g16EccFailChunkBitMap=g16DebugLastFailChunkBitMap;    // g16DebugLastFailChunkBitMap
        updateLogNandQueue();
#endif/* if 1 */
        //
        uRdEccFailIdx=0xFF;

#if (!_EN_RAID_DECODE)
        readRetryMarkBad(upRdRetryAddr);

        if(upRdRetryAddr->u16RwOpt&cRetryAutoBuf)
        {
            setBufferFlag(upRdRetryAddr);
        }
#else
#if _EN_CHK_FINGER_FAIL
        if((upRdRetryAddr->uOpTyp==cPreReadData)
           ||(upRdRetryAddr->uOpTyp==cLastReadData)
           ||(upRdRetryAddr->uOpTyp==cHostReadData)
           ||(upRdRetryAddr->uOpTyp==cMoveReadData)
           ||(upRdRetryAddr->uOpTyp==cH2fReadTab)
           ||(upRdRetryAddr->uOpTyp==cH2fRead1kTab)
           ||(upRdRetryAddr->uOpTyp==cSecReadData))
        {
            if((upRdRetryAddr->uOpTyp==cPreReadData)
               ||(upRdRetryAddr->uOpTyp==cLastReadData)
               ||(upRdRetryAddr->uOpTyp==cHostReadData))
            {
#if (!_EN_LiteonRetryLog)
                NLOG(cLogCore1, FLASHREADRETRY_C, 2, "LBA : 0x%08X ", ((gsPrdInfo.uarPrdQue[upRdRetryAddr->uPrdPtr].u32LbaAddr)>>16),
                     ((gsPrdInfo.uarPrdQue[upRdRetryAddr->uPrdPtr].u32LbaAddr)));
#endif
            }

#if (!_EN_LiteonRetryLog)
            NLOG(cLogCore1, FLASHREADRETRY_C, 0, "setRaidDecInfo");
#else
            NLOG(cLogCore1,
                 FLASHREADRETRY_C,
                 6,
                 "setRaidDecInfo!! ->TLC mode:0x%04X,CH: 0x%04X,CE: 0x%04X,Plan: 0x%04X,Block: 0x%04X,Page: 0x%04X",
                 u8Type,
                 garChMapTable[gpFlashAddrInfo->uCh],
                 garCeMapTable[gpFlashAddrInfo->uCe],
                 gpFlashAddrInfo->uPlaneAddr,
                 getDiffFBlock(gpFlashAddrInfo->u16FBlock, gpFlashAddrInfo->uCh, gpFlashAddrInfo->uIntlvAddr, gpFlashAddrInfo->uPlaneAddr),
                 u16FPage);
#endif/* if (!_EN_LiteonRetryLog) */

            setRaidDecInfo(upRdRetryAddr, uRdEccFailIdx);
        }
        else
        {
            if((upRdRetryAddr->uOpTyp==cReadRaidParity)&&(upRdRetryAddr->u16FBlock!=0))    // 20190305_Bill
            {
                mSetGcFlag(cGcDesFailAbort);
                readRetryMarkBad(upRdRetryAddr);
            }

            if(upRdRetryAddr->u16RwOpt&cRetryAutoBuf&&(upRdRetryAddr->u16FBlock!=0))    // 20190305_Bill
            {
                setBufferFlag(upRdRetryAddr);
            }
        }
#else/* if _EN_CHK_FINGER_FAIL */
        readRetryMarkBad(upRdRetryAddr);

        switch(upRdRetryAddr->uOpTyp)
        {
            case cPreReadData:
            case cLastReadData:
            case cHostReadData:
                NLOG(cLogCore1, FLASHREADRETRY_C, 2, "LBA : 0x%08X ", ((gsPrdInfo.uarPrdQue[upRdRetryAddr->uPrdPtr].u32LbaAddr)>>16),
                     ((gsPrdInfo.uarPrdQue[upRdRetryAddr->uPrdPtr].u32LbaAddr)));

            case cMoveReadData:
            case cH2fReadTab:
            case cH2fRead1kTab:
            case cSecReadData:
                NLOG(cLogCore1, FLASHREADRETRY_C, 0, "setRaidDecInfo");
                setRaidDecInfo(upRdRetryAddr, uRdEccFailIdx);
                break;

            case cReadRaidParity:
                mSetGcFlag(cGcDesFailAbort);

            default:

                if(upRdRetryAddr->u16RwOpt&cRetryAutoBuf)
                {
                    setBufferFlag(upRdRetryAddr);
                }
        }    /* switch */
#endif/* if _EN_CHK_FINGER_FAIL */
#endif/* if (!_EN_RAID_DECODE) */

#if _EN_READRECLAIM
        if(!(gsReadRetryInfo.usReadRetryAddr.u16RwOpt&c16Bit10)&&(upRdRetryAddr->u16FBlock!=0))
        {
            // alway reclaim ecc fail block (it's marked c16Bit11)
            pushWLReadReclaimQ(gsReadRetryInfo.usReadRetryAddr.u16FBlock, cDoRetryButFail);    // chkPushClnQue(&gsReadRetryInfo.usReadRetryAddr);
        }
#endif

        if(upRdSrcAddr->u16RwOpt&c16Bit3)
        {
            // Cache Read
            while(g32Core1State>=cCore1BootState_Finished)
                ;
        }

/*
   #if (!_EN_RAID_DECODE)
   *      if(gOpTyp!=cVenderRead)
   *      {
   *          while((g32Core1State>=cCore1BootState_Finished)&&(!mChkGcFlag(cGcReadF2h)))
   *              ;
   *      }
   #endif
   */
    }
    else
    {
#if (!_EN_LiteonRetryLog)
        // record successful Vth
        NLOG(cLogCore1, FLASHREADRETRY_C, 1, "ECC Pass SoftMode=0x%04X", uSoftMode);
#endif

        if((upRdSrcAddr->u16RwOpt)&c16Bit14)
        {
            if((gReadLinkRetrySlcVth[upRdSrcAddr->uCh][upRdSrcAddr->uPlaneAddr]==0)||
               ((garTrackVthCenter[cSLCR]<gReadLinkRetrySlcVth[upRdSrcAddr->uCh][upRdSrcAddr->uPlaneAddr])&&
                (gReadLinkRetrySlcVth[upRdSrcAddr->uCh][upRdSrcAddr->uPlaneAddr]&cBit7)&&(garTrackVthCenter[cSLCR]&cBit7)))
            {
                gReadLinkRetrySlcVth[upRdSrcAddr->uCh][upRdSrcAddr->uPlaneAddr]=garTrackVthCenter[cSLCR];
            }
        }

        if(uSoftMode==0)
        {
#if _RetryTableContinue
            gRetryTablePassIndex[upRdSrcAddr->uCh][upRdSrcAddr->uIntlvAddr][gbLsbOnly]=uRetryTableSet;
#else
            gRetryTablePassIndex[upRdSrcAddr->uCh][upRdSrcAddr->uIntlvAddr][gbLsbOnly]=0;
#endif
#if (!_EN_LiteonRetryLog)
            NLOG(cLogCore1, FLASHREADRETRY_C, 1, "HB Pass RetryTable Index: 0x%04X ", uRetryTableSet);
#else
            NLOG(cLogCore1,
                 FLASHREADRETRY_C,
                 7,
                 "doReadRetry() HardDecode Pass !! ->TLC mode:0x%04X,CH: 0x%04X,CE: 0x%04X,Plan: 0x%04X,Block: 0x%04X,Page: 0x%04X,RetryTable Index: 0x%04X",
                 u8Type,
                 garChMapTable[gpFlashAddrInfo->uCh],
                 garCeMapTable[gpFlashAddrInfo->uCe],
                 gpFlashAddrInfo->uPlaneAddr,
                 getDiffFBlock(gpFlashAddrInfo->u16FBlock, gpFlashAddrInfo->uCh, gpFlashAddrInfo->uIntlvAddr, gpFlashAddrInfo->uPlaneAddr),
                 u16FPage,
                 (gRetryTablePassIndex[upRdSrcAddr->uCh][upRdSrcAddr->uIntlvAddr][gbLsbOnly]));
#endif/* if (!_EN_LiteonRetryLog) */

            if(gOpTyp!=cVenderRead)
            {
                if(gbLsbOnly)
                {
                    gsFtlDbg.u32SlcRetryTablePassCnt++;

                    if(mChkFLParam(cWithRlibMo))
                    {
                        gsFtlDbg.u16LastHBPassPage=g16FPage;
                    }
                    else if(mChkCardMode(cWithSlcMo))
                    {
                        gsFtlDbg.u16LastHBPassPage=(g16FPage<<1);
                    }
                }
                else
                {
                    gsFtlDbg.u32TlcRetryTablePassCnt++;
#if (_TSB_BiCS3|_SANDISK_3D_GEN2|_SANDISK_3D_GEN3|_TSB_BiCS4)
                    gsFtlDbg.u16LastHBPassPage=((cProgCntPerWL*g16FPage)+mGetPageSelCmd(gpFlashAddrInfo)-1);
#endif
                }

                gsFtlDbg.u16LastHBPassChAndCe=((garChMapTable[gCh]<<8)|garCeMapTable[gCe]);
                gsFtlDbg.u16LastHBPassDieAndPlane=((gDieAddr<<8)|gStartPlaneAddr);
                gsFtlDbg.u16LastHBPassBlk=getDiffAddr(g16AbstrFBlock, gCh, gIntlvAddr, gStartPlaneAddr);
                gsFtlDbg.u16LastHBRetryDataAndSlc=((gsReadRetryInfo.uRetryOpt<<8)|gbLsbOnly);

                if(gsReadRetryInfo.uRetryOpt&(cRetrySpr))
                {
                    gsFtlDbg.u16LastHBEccBit=rmGetSprEcc;
                }

                if(gsReadRetryInfo.uRetryOpt&(cRetryDat))
                {
                    gsFtlDbg.u16LastHBEccBit=rmGetLdpcEccBit;
                }
            }
        }
        else
        {
            gRetryTablePassIndex[upRdSrcAddr->uCh][upRdSrcAddr->uIntlvAddr][gbLsbOnly]=0;
            replaceVthTabForTrackingPara(garLastPassVthCenter[upRdSrcAddr->uCh][upRdSrcAddr->uIntlvAddr],
                                         TrackingPara[gActiveCh].u8arTrackVthCenter,
                                         (gsReadRetryInfo.uRetryPageTyp|cRetryLDPC),
                                         TrackingPara[gActiveCh].u8arSoftStep,
                                         0);
#if (!_EN_LiteonRetryLog)
            NLOG(cLogCore1, FLASHREADRETRY_C, 0, "SB Pass Vthtracking Center");
#else
            NLOG(cLogCore1,
                 FLASHREADRETRY_C,
                 7,
                 "doReadRetry() SoftDecode Pass !! ->TLC mode:0x%04X,CH: 0x%04X,CE: 0x%04X,Plan: 0x%04X,Block: 0x%04X,Page: 0x%04X,SoftMode=0x%04X",
                 u8Type,
                 garChMapTable[gpFlashAddrInfo->uCh],
                 garCeMapTable[gpFlashAddrInfo->uCe],
                 gpFlashAddrInfo->uPlaneAddr,
                 getDiffFBlock(gpFlashAddrInfo->u16FBlock, gpFlashAddrInfo->uCh, gpFlashAddrInfo->uIntlvAddr, gpFlashAddrInfo->uPlaneAddr),
                 u16FPage,
                 uSoftMode);
#endif/* if (!_EN_LiteonRetryLog) */
            printVthCenter(garLastPassVthCenter[upRdSrcAddr->uCh][upRdSrcAddr->uIntlvAddr]);

            if(gOpTyp!=cVenderRead)
            {
                if(gbLsbOnly)
                {
                    gsFtlDbg.u32SlcVthTrackingPassCnt++;

                    if(mChkFLParam(cWithRlibMo))
                    {
                        gsFtlDbg.u16LastSBPassPage=g16FPage;
                    }
                    else if(mChkCardMode(cWithSlcMo))
                    {
                        gsFtlDbg.u16LastSBPassPage=(g16FPage<<1);
                    }
                }
                else
                {
                    gsFtlDbg.u32TlcVthTrackingPassCnt++;
#if (_TSB_BiCS3|_SANDISK_3D_GEN2|_SANDISK_3D_GEN3|_TSB_BiCS4)
                    gsFtlDbg.u16LastSBPassPage=((cProgCntPerWL*g16FPage)+mGetPageSelCmd(gpFlashAddrInfo)-1);
#endif
                }

                gsFtlDbg.u16LastSBPassChAndCe=((garChMapTable[gCh]<<8)|garCeMapTable[gCe]);
                gsFtlDbg.u16LastSBPassDieAndPlane=((gDieAddr<<8)|gStartPlaneAddr);
                gsFtlDbg.u16LastSBPassBlk=getDiffAddr(g16AbstrFBlock, gCh, gIntlvAddr, gStartPlaneAddr);
                gsFtlDbg.u16LastSBRetryDataAndSlc=((gsReadRetryInfo.uRetryOpt<<8)|gbLsbOnly);

                if(gsReadRetryInfo.uRetryOpt&(cRetrySpr))
                {
                    gsFtlDbg.u16LastSBEccBit=rmGetSprEcc;
                }

                if(gsReadRetryInfo.uRetryOpt&(cRetryDat))
                {
                    gsFtlDbg.u16LastSBEccBit=rmGetLdpcEccBit;
                }
            }
        }

        if(gsReadRetryInfo.uRetryOpt&(cRetrySpr))
        {
            gsReadRetryInfo.uSprEccBit=rmGetSprEcc;
#if (!_EN_LiteonRetryLog)
            NLOG(cLogCore1, FLASHREADRETRY_C, 1, "SprEccBit: 0x%04X ", gsReadRetryInfo.uSprEccBit);
#endif

            if((upRdSrcAddr->uOpTyp==cChkFakeSlcProgramFail)&&(rmGetSprEcc>=cFakeProgramFailRetryEccBitTh))
            {
                mSetBitMask(gPlaneUNCSts[upRdRetryAddr->uCh], upRdRetryAddr->uPlaneAddr);
            }
        }

        if(gsReadRetryInfo.uRetryOpt&(cRetryDat))
        {
            gsReadRetryInfo.uLdpcMode=uSoftMode;
            gsReadRetryInfo.u16DataEccBit=rmGetLdpcEccBit;
#if (!_EN_LiteonRetryLog)
            NLOG(cLogCore1, FLASHREADRETRY_C, 1, "LdpcMode: 0x%04X ", gsReadRetryInfo.uLdpcMode);
            NLOG(cLogCore1, FLASHREADRETRY_C, 1, "DataEccBit: 0x%04X ", gsReadRetryInfo.u16DataEccBit);
#endif

            if((upRdSrcAddr->uOpTyp==cChkFakeSlcProgramFail)&&(rmGetLdpcEccBit>=cFakeProgramFailRetryEccBitTh))
            {
                mSetBitMask(gPlaneUNCSts[upRdRetryAddr->uCh], upRdRetryAddr->uPlaneAddr);
            }
        }

#if _EN_READRECLAIM
        // bypass Vendor Read trigger Reclaim
        if(!(gsReadRetryInfo.usReadRetryAddr.u16RwOpt&c16Bit10))
        {
#if (!_DEBUG_EasyToREADRECLAIM)
            if(uSoftMode>0)
            {
                // do soft retry
                // 2015/08/24, JN, @Boot code, codeFuncPtr4 is a NOP function, need to check again
                pushWLReadReclaimQ(gsReadRetryInfo.usReadRetryAddr.u16FBlock, cDoSoftRetry);    // chkPushClnQue(&gsReadRetryInfo.usReadRetryAddr);
            }
#else/* if (!_DEBUG_EasyToREADRECLAIM) */
            pushWLReadReclaimQ(gsReadRetryInfo.usReadRetryAddr.u16FBlock, cDoSoftRetry);    // chkPushClnQue(&gsReadRetryInfo.usReadRetryAddr);
#endif/* if (!_DEBUG_EasyToREADRECLAIM) */
        }
#endif/* if _EN_READRECLAIM */

        if(upRdSrcAddr->u16RwOpt&c16Bit3)
        {
            // Cache Read
            while(g32Core1State>=cCore1BootState_Finished)
                ;
        }
    }

#if (!_EN_LiteonRetryLog)
    NLOG(cLogCore1, FLASHREADRETRY_C, 0, "## Retry End ##");
#endif

    // gErrInjectFlag|=cBit0;
    if(!mChkBitMask(gPlaneUNCSts[upRdSrcAddr->uCh], upRdRetryAddr->uPlaneAddr))
    {
        mSetBitMask(gPlaneCorrSts[upRdSrcAddr->uCh], upRdRetryAddr->uPlaneAddr);
    }

    if(1)
    {
        // reset all SLC/TLC Vth to Trigger next Read
        fillCcmVal(garVthOffsetValue, cRetryRegNum, 0);
    }
    else
    {
        // using Glod Vth to Trigger next Read
    }

    setRetryCmd(&gsReadRetryInfo, c16Bit0);

#if _ENABLE_NAND_TestReadVth
    if(gErrInjectFlag==0x80)
    {
        setTestRetryCmd();
    }
#endif
#if _GREYBOX
    if((gsGbInfo.uGreyBoxItem==cReadRetryDecodeTestID)||(gsGbInfo.uGreyBoxItem==cErrHdlReadUncInSlcDataID)\
       ||(gsGbInfo.uGreyBoxItem==cErrHdlReadUncInTlcDataID)||(gsGbInfo.uGreyBoxItem==cErrHdlProgWPROID)\
       ||(gsGbInfo.uGreyBoxItem==cErrHdlGcFingerFailTestID))
    {
        if(gErrInjectFlag&0x80)
        {
            setTestRetryCmd();
        }
    }
#endif

#if _GREYBOX
    ctrlErrInject(0x00, cErrInjectReadMode, 0x01, 0x30, 0xFFFF);
    gErrInjectFlag&=(~cBit0);
#endif

    mWaitCmdFifoBz;    // while (!rmChkCmdFifoDpt(0x3F));

    if(uPipeLineMode==cLdpcPipeLineDisableMode)
    {
        setRRCmdAle(&gsReadRetryInfo, cRetryForceSpr);
    }
    else
    {
        rmAllCeOff;
    }

    setFLAddrActCh(upRdSrcAddr->uCh, upRdSrcAddr);

#if _DEBUG_READECC
    ctrlErrInject(0, 0, 0, 0, 0);    // rmDisErrInject;
#endif

    ctrlAuxQue(cOutAuxQue);

    if(uPipeLineMode==cLdpcPipeLineEnableMode)
    {
        rmDisWaitDMADone;    // Maybe set rmEnWaitDMADone in soft decode.
        rmEnDmaPipe;    // rmEnDmaPipe;
    }
}    /* doReadRetry */

void calRetryPara(RETRYINFO *upRetryInfo, ADDRINFO *upRdSrcAddr, BYTE uPlaneNum, BYTE uPipeLineMode)
{
    BYTE uStartAddrH, uEccAddrH, uRetryBufOffset;
    ADDRINFO *upRdRetryAddr=&(upRetryInfo->usReadRetryAddr);

    copyCcmVal((BYTE *)upRdRetryAddr, (BYTE *)upRdSrcAddr, sizeof(ADDRINFO));

    if((!mChkMlcMoBit(upRdRetryAddr->u16FBlock))&&(!(upRdSrcAddr->u16RwOpt&c16Bit3)))
    {
        upRetryInfo->uRetryPageTyp=cSLC;
        gTotalRetryTimes=cbRetryTable[cRetrySlcLvAddrOfst];
    }
    else
    {
        upRetryInfo->uRetryPageTyp=mGetPageSelCmd(upRdRetryAddr)-1;    // upRdRetryAddr->uPageSelCmd-1;
        gTotalRetryTimes=cbRetryTable[cLSBLvAddrOfst+upRetryInfo->uRetryPageTyp+gNandVersion*cLvVerAddrOfst];
    }

    upRetryInfo->uRetryTabTyp=cbRetryTable[cRetryTabTypAddrOfst];    // chose X vendor Y nm Nand : reserve

    if(uPipeLineMode==cLdpcPipeLineDisableMode)
    {
        upRetryInfo->uRetryOpt=rmChkUNC;    // rFLCtrl[rcOPResultFlag]&(cRetryDat|cRetrySpr);
    }
    else
    {
        upRetryInfo->uRetryOpt=cRetryDat;
    }

    upRdRetryAddr->uPlaneAddr=uPlaneNum;

    if(upRdRetryAddr->uPlaneAddr==upRdSrcAddr->uStartPlaneAddr)
    {
        // upRdRetryAddr->uSectorH=upRdSrcAddr->uOrgSectorH;
    }
    else
    {
        upRdRetryAddr->uSectorH=0;
    }

    uStartAddrH=upRdSrcAddr->uStartPlaneAddr*gSectorPerPlaneH+upRdSrcAddr->uSectorH;    // uOrgSectorH;
    uEccAddrH=upRdRetryAddr->uPlaneAddr*gSectorPerPlaneH+upRdRetryAddr->uSectorH;
    uRetryBufOffset=uEccAddrH-uStartAddrH;

    if(upRdSrcAddr->u16BufPtr<c16Tsb1SIdx)
    {
        // Data
        upRdRetryAddr->u16BufPtr=addReadBufPtr(upRdRetryAddr->u16BufPtr, uRetryBufOffset);
    }
    else
    {
        // Table
        upRdRetryAddr->u16BufPtr=upRdRetryAddr->u16BufPtr+uRetryBufOffset;
    }

    upRdRetryAddr->uRwHalfKb=upRdSrcAddr->uRwHalfKb-uRetryBufOffset;

    if(upRdRetryAddr->uRwHalfKb>(gSectorPerPlaneH-upRdRetryAddr->uSectorH))
    {
        upRdRetryAddr->uRwHalfKb=gSectorPerPlaneH-upRdRetryAddr->uSectorH;
    }
}    /* calRetryPara */

void initRetryTablePassIndex()
{
    BYTE uCh, uIntlv;

    for(uCh=0; uCh<gTotalChNum; uCh++)
    {
        for(uIntlv=0; uIntlv<gIntlvWay; uIntlv++)
        {
            gRetryTablePassIndex[uCh][uIntlv][0]=0;    // TLC index
            gRetryTablePassIndex[uCh][uIntlv][1]=0;    // SLC index
            fillCcmVal(garLastPassVthCenter[uCh][uIntlv], cRetryRegNum, 0);
        }
    }

    g32RamAddrRetryTablePassIndex=((LWORD)&gRetryTablePassIndex[0][0][0]);
    g32RamAddrLastPassVthCenter=((LWORD)&garLastPassVthCenter[0][0][0]);
}

void initTrackingPara()
{
    BYTE uIndex;

    for(gActiveCh=0; gActiveCh<cMaxChNum; gActiveCh++)
    {
        for(uIndex=0; uIndex<6; uIndex++)
        {
            TrackingPara[gActiveCh].u8arFlashID[uIndex]=gFlashId[uIndex];
        }

        for(uIndex=0; uIndex<C_VthRegNum; uIndex++)
        {
            TrackingPara[gActiveCh].u8arTrackVthCenter[uIndex]=0;
            // TrackingPara[gActiveCh].u8arTrackVthCenter[uIndex]=cbRetryTable[cRetryValAddrOfst+uIndex];
        }

        TrackingPara[gActiveCh].PageKSize=gSectorPerPlaneF;
        TrackingPara[gActiveCh].ubEnTracking=0;
        // TrackingPara[gActiveCh].u8arEventLog[0]=0;
        // TrackingPara[gActiveCh].u8arEventLog[1]=0;
        // TrackingPara[gActiveCh].u8arEventLog[2]=0;
        // TrackingPara[gActiveCh].u8arEventLog[3]=0;
    }

    u8VthLowerShiftStep=0;
    u8VthUpperShiftStep=0;
    u8LowerShiftLeft=0;
    u8UpperShiftLeft=0;

    gActiveCh=0;
}    /* initTrackingPara */

BYTE getTrackingPageKSize(BYTE uSectorH, BYTE uRwHalfKb)
{
    BYTE uPageKSize=0;
    BYTE uStartChunk, uEndChunk, uDmaChunkNum;

    uStartChunk=uSectorH>>2;
    uEndChunk=(uSectorH+uRwHalfKb-1)>>2;
    uDmaChunkNum=uEndChunk-uStartChunk+1;
    uPageKSize=2*uDmaChunkNum;

    return uPageKSize;
}

void replaceVthTabForTrackingPara(BYTE *uDesVthTab, BYTE *uSrcVthTab, BYTE uPageTyp, BYTE *uSoftStep, BYTE uReadCnt)
{
    BYTE uLoop, uTempVth, uVThOffset;
    BYTE uPageSel, uPageMod;

    // u8arSoftStep[C_VthRegNum]         always A B C D E F G SLC
    // u8arTrackVthCenter[C_VthRegNum]   always A B C D E F G SLC
#if (_SANDISK_3D_GEN3||_SANDISK_3D_GEN2)
    // FW Table                                 A C E G B D F SLC
    // Index                                    0 1 2 3 4 5 6 7
    BYTE uarState[10]={0, 2, 4, 6, 1, 3, 5, 7, 0, 0};
#endif
#if (_TSB_BiCS3||_TSB_BiCS4)
    // FW Table                                 A C E G B D F SLC
    // Index                                    0 1 2 3 4 5 6 7
    BYTE uarState[10]={0, 2, 4, 6, 1, 3, 5, 7, 0, 0};
#endif

    uPageSel=uPageTyp&cRetryTypMsk;
    uPageMod=uPageTyp&cRetryModMsk;

    for(uLoop=0; uLoop<cRetryRegNum; uLoop++)
    {
        if(!(uReadCnt&cBit0))
        {
            uVThOffset=uSoftStep[uarState[uLoop]]*(uReadCnt>>1);
        }
        else
        {
            uVThOffset=0-(uSoftStep[uarState[uLoop]]*((uReadCnt+1)>>1));
        }

        uTempVth=uSrcVthTab[uarState[uLoop]]+uVThOffset;

        if(uPageSel!=cAllWL)
        {
            if(uPageSel==cLSB)
            {
#if (_TSB_BiCS3||_SANDISK_3D_GEN2||_SANDISK_3D_GEN3||_TSB_BiCS4)
                if(!((uLoop==cAR)||(uLoop==cER)))
#endif
                {
                    continue;
                }
            }
            else if(uPageSel==cCSB)
            {
                if(!((uLoop==cBR)||(uLoop==cDR)||(uLoop==cFR)))
                {
                    continue;
                }
            }
            else if(uPageSel==cMSB)
            {
                // MSB
#if (_TSB_BiCS3||_SANDISK_3D_GEN2||_SANDISK_3D_GEN3||_TSB_BiCS4)
                if(!((uLoop==cCR)||(uLoop==cGR)))
#endif
                {
                    continue;
                }
            }
            else
            {
                // SLC
                if(!(uLoop==cSLCR))
                {
                    continue;
                }
            }

            if(uPageMod==cRetryLDPC)
            {
                // protect Vth overflow
                if((!(uSrcVthTab[uarState[uLoop]]&cBit7))&&(!(uVThOffset&cBit7)))
                {
                    //       "+"                                          "+"
                    if(uTempVth&cBit7)
                    {
                        //        "-"
                        uTempVth=cRetryMaxShiftRStep;
                    }
                }
                else if((uSrcVthTab[uarState[uLoop]]&cBit7)&&(uVThOffset&cBit7))
                {
                    //                      "-"                        "-"
                    if(!(uTempVth&cBit7))
                    {
                        //         "+"
                        uTempVth=cRetryMaxShiftLStep;
                    }
                }
            }
        }

        uDesVthTab[uLoop]=uTempVth;
    }
}    /* replaceVthTab */

void replaceVthTabForSeparateTrack(BYTE *uDesVthTab, BYTE *uSrcVthTab, BYTE uEnSeparateUpper, BYTE *uSoftStep, BYTE uReadCnt)
{
    BYTE uLoop, uVThOffset;

    // u8arSoftStep[C_VthRegNum]         always A B C D E F G SLC
    // u8arTrackVthCenter[C_VthRegNum]   always A B C D E F G SLC
#if (_SANDISK_3D_GEN3||_SANDISK_3D_GEN2)
    // FW Table                                 A C E G B D F SLC
    // Index                                    0 1 2 3 4 5 6 7
    BYTE uarState[10]={0, 2, 4, 6, 1, 3, 5, 7, 0, 0};
#endif
#if (_TSB_BiCS3||_TSB_BiCS4)
    // FW Table                                 A C E G B D F SLC
    // Index                                    0 1 2 3 4 5 6 7
    BYTE uarState[10]={0, 2, 4, 6, 1, 3, 5, 7, 0, 0};
#endif

    for(uLoop=0; uLoop<cRetryRegNum; uLoop++)
    {
//
        if(!(uReadCnt&cBit0))
        {
            uVThOffset=uSoftStep[uarState[uLoop]]*(uReadCnt>>1);
        }
        else
        {
            uVThOffset=0-(uSoftStep[uarState[uLoop]]*((uReadCnt+1)>>1));
        }

        if((uEnSeparateUpper==1)&&(uLoop==cFR))
        {
            // Loop 0: adjust BR&DR, skip FR
            uDesVthTab[uLoop]=uSrcVthTab[uLoop];
        }
        else if((uEnSeparateUpper==0)&&(uLoop==cBR))
        {
            // Loop 1: adjust FR&DR, skip BR
            uDesVthTab[uLoop]=uSrcVthTab[uLoop];
        }
        else
        {
            uDesVthTab[uLoop]=uSrcVthTab[uLoop]+uVThOffset;
        }
    }
}    /* replaceVthTab */

#if _LiteOn_RR_MdfyDrv
// uTranDrvingLoop=0, last Pass Vth
// uTranDrvingLoop=1, last Pass Vth, use add drv
// uTranDrvingLoop=2, last Pass Vth, use sub drv
// uTranDrvingLoop=3, uRetryTabLoop=1, use org Drv
void modifyDring(BYTE uChLoop, BYTE uTranDrvingLoop)
{
    BYTE uCh, uCtrlDrv, uDataDrv, uSchmitWind;
    LWORD u32FshCtrlDrv, u32FshDataDrv;
    BYTE *upIntrfaceSetPtr=&gCh0FshODTAndDrv;

    uCtrlDrv=upIntrfaceSetPtr[uChLoop*4+0x01];
    uDataDrv=upIntrfaceSetPtr[uChLoop*4+0x02];
    uSchmitWind=(upIntrfaceSetPtr[uChLoop*4+0x03]&0x30);

    if((uCtrlDrv!=0xff)&&(uDataDrv!=0xff))
    {
        if(uTranDrvingLoop==1)
        {
            uCtrlDrv+=0x11;
            uDataDrv+=0x11;
        }
        else if(uTranDrvingLoop==2)
        {
            uCtrlDrv-=0x11;
            uDataDrv-=0x11;
        }
    }

    u32FshCtrlDrv=(LWORD)(uCtrlDrv|uSchmitWind<<8|uCtrlDrv<<16);
    u32FshDataDrv=(LWORD)(uDataDrv|uSchmitWind<<8|uDataDrv<<16|uSchmitWind<<24);
    uCh=garChMapTable[uChLoop];
    r32SysCtrl0[(rcCtrlIoCh0/4)+uCh*2]=u32FshCtrlDrv;
    r32SysCtrl0[(rcDataIoCh0/4)+uCh*2]=u32FshDataDrv;
}    /* modifyDring */

#endif/* if _LiteOn_RR_MdfyDrv */

#else/* if (_ENABLE_SOFTDECODE) */

#endif/* if (_ENABLE_SOFTDECODE) */

#if (!_ICE_LOAD_ALL)
#pragma default_function_attributes =
#endif







