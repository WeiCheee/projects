







#if _PRJ_BOOT1

#if _ENABLE_SRAM_ECC_PROTECTION
void initTsb0123Ecc()
{
    bopCopyRam((LWORD)c32Tsb2SAddr, (LWORD)c32Tsb0SAddr, (0x400+c16SeedTableSize*2), cCopyTsb2Tsb|cBopWait);    // parameter and seed table

    rmEnTsbEcc;
    rmEnTsbEccErrFlg;
    rmEnTsbEccCorrFlg;

    bopClrRam((LWORD)c32Tsb0SAddr, 256*1024, 0xFFFFFFFF, cBopWait|cClrTsb|cBopEnCrc|cBopGenCrc);
    bopClrRam((LWORD)c32Tsb0SAddr+(256*1024), 128*1024, 0xFFFFFFFF, cBopWait|cClrTsb|cBopEnCrc|cBopGenCrc);    // because 2263 rom buf wrap
    bopClrRam((LWORD)c32Tsb1SAddr, 128*1024, 0xFFFFFFFF, cBopWait|cClrTsb|cBopEnCrc|cBopGenCrc);    // Just generate ECC for CRC region

    bopCopyRam((LWORD)c32Tsb0SAddr, (LWORD)c32Tsb2SAddr, (0x400+c16SeedTableSize*2), cCopyTsb2Tsb|cBopWait);

    bopClrRam((LWORD)0x40100000, 8*1024, 0x00000000, cBopWait|cClrTsb|cBopEnCrc|cBopGenCrc);    // Just generate ECC for CRC region (Spec. TSB9)

    asm ("DSB");
}    /* initTsb0123Ecc */

void initTsb4Ecc(BYTE uInitBuf)
{
    rmEnTsb4Ecc;
    rmEnTsb4EccErrFlg;
    rmEnTsb4EccCorrFlg;
    asm ("DSB");

    if(uInitBuf)
    {
        bopClrRam((LWORD)c32Tsb2SAddr, 32*1024, 0x00000000, cBopWait|cClrTsb);    // TSB5(H2F_TAB1/MAPCACHE_TAB1)
    }

    asm ("DSB");
}

#endif/* if _ENABLE_SRAM_ECC_PROTECTION */

void initSram()
{
    // First fetch gSecurityOption variable from parameter page(TSB0).
    BYTE uSecurityOption=(BYTE)*((BYTE *)((LWORD)&gSecurityOption-cParaAddr+cTsb0Addr));

    bopClrRam((LWORD)cDtcmAddr, 28*1024, 0x00000000, cBopWait|cClrCore0Dccm);    // CORE0 DTCM
    bopClrRam((LWORD)cDtcmAddr, 32*1024, 0x00000000, cBopWait|cClrCore1Dccm);    // CORE1 DTCM
    bopClrRam((LWORD)cStcmAddr, (32*1024)-256, 0x00000000, cBopWait|cClrStcm);    // STCM
    gpBkPS4Data=(PS4BACKUP *)c32Tsb2SAddr;

    gSecurityOption=uSecurityOption;

    if(gSecurityOption&cEnE2e)
    {
        rmEnGlobalCrc;
        rmEnE2eCrc15;
    }
    else
    {
        bopClrRam((LWORD)c32TsbCrcAddr, 8*1024, 0xFFFFFFFF, cBopWait|cClrTsb);
    }

#if (!(_GREYBOX))
    // Restore backup data from PS4 resume
    if(rmChkInDevSlp)
    {
        // Restore PS4 Core0 DCCM
        bopCopyRam(c32DccmSAddr, c32Tsb2Ps4BkAddr, cPs4Core0DccmBkSize, cCopyTsb2Dccm|cBopWait);

        // Restore PS4 STCM
        bopCopyRam((cParaAddr+cSizeOfParaTab), (c32Tsb2Ps4BkAddr+cPs4Core0DccmBkSize), cPs4StcmBkSize, cCopyTsb2Stcm|cBopWait);

        // Restore parameter
        gsRdlinkInfo.u16DiffFBlock0=gpBkPS4Data->u16BkDiffFBlock0;
        gsRdlinkInfo.u16DiffFBlock1=gpBkPS4Data->u16BkDiffFBlock1;
        gsRdlinkInfo.u16DiffFPageNoTran=gpBkPS4Data->u16BkDiffFPageNoTran;
    }
#endif/* if (!(_GREYBOX)) */

#if _ENABLE_SECAPI
    // Reset last 1/4 for check stack overflow
    bopClrRam((LWORD)cSVCStackEnd, 0x160, 0x5A5A5A5A, cBopWait|cClrCore0Dccm);
    bopClrRam((LWORD)cIRQStackEnd, 0x100, 0x5A5A5A5A, cBopWait|cClrCore0Dccm);
    // resetRam((BYTE *)cSVCStackEnd, 0x160, 0x5A);
    // resetRam((BYTE *)cIRQStackEnd, 0x100, 0x5A);
#endif

#if _ENABLE_SRAM_ECC_PROTECTION
    if(gSecurityOption&cEnTsbEcc)
    {
        initTsb0123Ecc();
        initTsb4Ecc(1);
    }
    else
#endif
    {
        // bopClrRam((LWORD)c32Tsb0SAddr, 384*1024, 0xFFFFFFFF, cBopWait|cClrTsb); //TSB0
        // TSB0 bypass  parameter and seed table
        bopClrRam((LWORD)c32Tsb0SAddr+(0x400+c16SeedTableSize*2), 256*1024-(0x400+c16SeedTableSize*2), 0xFFFFFFFF, cBopWait|cClrTsb);
        bopClrRam((LWORD)c32Tsb0SAddr+(256*1024), 128*1024, 0xFFFFFFFF, cBopWait|cClrTsb);    // because 2263 rom buf wrap

        bopClrRam((LWORD)c32Tsb2SAddr, 32*1024, 0x00000000, cBopWait|cClrTsb);    // TSB5(H2F_TAB1/MAPCACHE_TAB1)
    }

    bopClrRam((LWORD)g16arH2fTabPtr, (c16MaxH2fTabNum+c16HmbMaxTableNum)*2, 0xFFFFFFFF, cBopWait|cClrTsb);    // TSB1(Cache INFO)
    bopClrRam((LWORD)g16arH2fBackup, (c16HmbMaxTableNum)*2, 0xFFFFFFFF, cBopWait|cClrTsb);
    bopClrRam((LWORD)g16arH2fTabBlk, c16MaxH2fTabBlkNum*2, 0xFFFFFFFF, cBopWait|cClrTsb);    // TSB1(Cache INFO)
    bopClrRam((LWORD)garCacheF2hTab, c32CacheF2hRamSize, 0xFFFFFFFF, cBopWait|cClrTsb);    // TSB1(F2H_TAB)
    bopClrRam((LWORD)g32arH2fTable, c32H2fTabRamSize, 0xFFFFFFFF, cBopWait|cClrTsb);    // TSB1(H2F_TAB0)
    bopClrRam((LWORD)g16arRaidParityPtr, cRaidParityPageNum*2, 0xFFFFFFFF, cBopWait|cClrTsb);    // TSB1(Cache INFO)
    bopClrRam((LWORD)g16arRaidParityBlk, cRaidParityBlockNum*2, 0xFFFFFFFF, cBopWait|cClrTsb);    // TSB1(Cache INFO)
    bopClrRam((LWORD)g16arRaidPtyBlkVpCnt, cRaidParityBlockNum*2, 0x00000000, cBopWait|cClrTsb);    // TSB1(Cache INFO)
    bopClrRam((LWORD)c32RaidBufSAddr, c32RaidBufRamSize, 0x00000000, cBopWait|cClrTsb);
    // bopClrRam((LWORD)garSrcAddrInfo, (sizeof(ADDRINFO)*cReadFifoDpt), 0x00000000, cBopWait|cClrStcm);
    // bopClrRam((LWORD)garDesAddrInfo, (sizeof(ADDRINFO)*cWriteFifoDpt), 0x00000000, cBopWait|cClrStcm);
    // bopClrRam((LWORD)garH2f1kTabSgmtExpire, cMaxRH2fTabNum, 0x00000000, cBopWait|cClrStcm);
    // bopClrRam((LWORD)g32arSrcInCacheFlag, c16MaxBlockNum/8, 0x00000000, cBopWait|cClrStcm);
}    /* initSram */

#if (!(_GREYBOX))
void initDramLowPower()
{
#if _BGA_SSD
    // 1. Set Dram PLL disable and ZQ Low Power
    rmpw2EnDramClkGate;

    // Dram PLL Power Down
    rmSysIdleDrmPllOff;

    while(rmChkSysChkDrmPllLock)
        ;
#else
    // Check the ASIC not at Dram low power mode
    if(!rmChkDfiLowPwr)
    {
        // 1. Set Dram Pll clock
        // 2. Init Dram setting
        // 3. Set Dram to Low Power Mode
        // 4. Set Dram PLL disable and ZQ Low Power

        // 1. Set Dram Pll clock
        rmSetDramClkPll(cDramFreq400Mhz);
        rmSysIdleDrmPllOn;

        while(!rmChkSysChkDrmPllLock)
            ;

        rmpw2DisDramClkGate;
        __asm("DSB");

        // 2. Init Dram setting
        rmSetDramPhySrst;
        rmSetDramMacSrst;
        rmClrDramPhySrst;
        rmClrDramMacSrst;

        rmSetPir(0x00000073);
        sysDelay(20);

        while(!((rmGetPgSr&0x0000000F)==0x0000000F))
            ;

        sysDelay(20);
        rmSetPir(0x00040001);
        sysDelay(20);

        while(!(rmGetPgSr&c32Bit0))
            ;

        // 3. Set Dram to Low Power Mode
        rmSetDfiEnaLowPwr(0xf);

        while(!rmChkDfiLowPwrAk)
            ;

        rmClrAcrefIen;
        sysDelay(20);
        rmClrAcrefSen;
        sysDelay(20);
        rmClrAcrefEen;
        sysDelay(20);

        rmClrDx0RefIen;
        sysDelay(20);
        rmClrDx0RefSen;
        sysDelay(20);
        rmClrDx0RefEen;
        sysDelay(20);

        rmClrDx1RefIen;
        sysDelay(20);
        rmClrDx1RefSen;
        sysDelay(20);
        rmClrDx1RefEen;
        sysDelay(20);

        rmClrZqrefIen;
        sysDelay(20);

        // Power down DQS
        rmPdDqs0se;
        sysDelay(20);
        rmPdDqs0nse;
        sysDelay(20);
        rmPdDqs1se;
        sysDelay(20);
        rmPdDqs1nse;
        sysDelay(20);

        rmPdErrOut;
        sysDelay(20);

        rmSetZq0DrDrvZd;
        sysDelay(20);
        rmSetZq0DrZdata(0x81);
        sysDelay(20);
        rmSetZq1DrDrvZd;
        sysDelay(20);
        rmSetZq1DrZdata(0x81);
        sysDelay(20);
        rmSetZqcrFrxZcalVtUpd;
        sysDelay(20);
        rmClrZqcrFrxZcalVtUpd;
        sysDelay(20);

        rmSetZqPd;
        sysDelay(20);
        // 4. Set Dram PLL disable and ZQ Low Power
        rmpw2EnDramClkGate;
        __asm("DSB");
        // Dram PLL Power Down
        rmSysIdleDrmPllOff;

        while(rmChkSysChkDrmPllLock)
            ;
    }
#endif/* if _BGA_SSD */
}    /* initDramLowPower */

#endif/* if (!(_GREYBOX)) */

void initTimer(WORD u16RtcTrim)
{
    rmTimerDisable;

    while(rmChkTimerEnable)
        ;

    g32SysTmrOn=0;
    gCpu0TOFlag=0;
    g32Cpu1TOFlag=0;

    rmRtcTrim(u16RtcTrim);

    // rmRtcTrim(0x1E); //AIP verification result
    // 0x27 => 877ms
    // 0x23 => 916ms
    // 0x1E => 966ms
    // HW team will provide a training sequence

    rSysCtrl0[rcRtcCtrl1]|=0xC0;    // RTC 1S/32K reset
    rSysCtrl0[rcRtcCtrl2]|=0x80;    // RTC 2Hz reset
    rmRtcPowerDown;
    rSysCtrl0[rcRtcCtrl1]&=0x3F;
    rSysCtrl0[rcRtcCtrl2]&=0x7F;
    rmRtcPowerUp;

    rmRtc32kIntEnable;

#if 0
    rmSetRtc1sMaskLo(0xFFFE);    // per 1 sec , for power on hour
    rmRtc1sIntDisable;    // rmRtc1sIntEnable;
#endif
    rmRtc1sClearInt;
    rmSetRtc2HzMaskLo(0xFFFE);    // per 1 sec
    rmRtc2HzIntEnable;    // rmRtc2HzIntDisable;

    rmSetRtc32kMaskLo(0xE000);    // interrupt per 250ms
    rmRtc32kIntDisable;

    // (Mark) sometime, see RTC unstable
    sysDelay(3000);
    rmRtc32kReset;
    rmRtc1sReset;
    rmRtc2HzReset;

    startRtcCounting1s();
}    /* initTimer */

void initGPIO()
{
    // GPIO P0.x
    rmGpioP0OeDis(cBit5|cBit1);

    // GPIO P1.x
#if _BuildIceLoadAllBin
    rmGpioP1OeEn(cBit6|cBit2);
    rmGpioP1OeDis(cBit7|cBit5|cBit1);
#else
    // P12 and P16 (LED) set input pull-high, like open-drain
    rmGpioP1OeDis(cBit7|cBit6|cBit5|cBit2|cBit1);
    rmGpioP1PuEnable(cBit6|cBit2);
#endif

    // GPIO P2.x
    rmGpioP2PdEnable(cBit4|cBit1);
    // Mark P20 and P25, setting by SCP or PLP;20181130_Eason_02
    // rmGpioP2OeEn(cBit0);    // SSD_FLUSH_FB#,output
    // rmGpioP2OutputVal(cBit0);
    // rmGpioP2PuEnable(cBit5);    // PLP_Flush use P25 as input.

#if (!(_INITDRAM||_GREYBOX))
    // rmGpioP26Lpddr2IoPwrDis;//kenneth
#endif
}    /* initGPIO */

void enableCore1()
{
    // MSB & Mask = HW compare pattern
    // In this case HW will compare 4 bit and ignore others(0x4XXXXXXX)
    rmCohMsbRegion0=0x40;
    rmCohMaskRegion0=0xF0;
    rmCohEnRegion0;

    // MSB & Mask = HW compare pattern
    // In this case HW will compare 4 bit and ignore others(0x5XXXXXXX)
    // rmCohMsbRegion1 = 0x50;
    // rmCohMaskRegion1 = 0xF0;
    // rmCohEnRegion1;

    // MSB & Mask = HW compare pattern
    // In this case HW will compare 4 bit and ignore others(0x8XXXXXXX)
    // rmCohMsbRegion2 = 0x80;
    // rmCohMaskRegion2 = 0x80;
    // rmCohEnRegion2;

    rmCohEnCpu1;
    rmAuxEnCpu1Wr;
    rmAuxEnDebug;
}    /* enableCore1 */

#endif/* if _PRJ_BOOT */

#if _PRJ_BOOT2

// GPIO set level mode
void gpioSetLevelMode(LWORD u32RegIdx, BYTE uPinIdx)
{
    LWORD u32ShiftCnt=0;

    u32ShiftCnt=((uPinIdx)<<2)+cGpioModeBitShift;
    setRegMask((void *)&r32SysCtrl0[u32RegIdx/4], 0x0, 0x1<<u32ShiftCnt);
}

void initThermal()
{
    // Thermal Sensor 0
    if(gsLightSwitch.usThermalLs.uSensorSel&cAsicSensor0)
    {
#if _ENABLE_THERMAL_SYNC_LPF    // TBD, need add to LS
        rmThermal0LpfDis;    // (Coby) correct procedure to init thermal sensor from HW. Without it, FW will read wrong temperature from PS3.5
                             // resume
        rmThermal0CollectDis;    // diable LPF(summation of 8 times data and then divided by 8)
        rmThermal0LpfEn;    // enble data sync. & collect function
        // only be changed when DisThermalCollectSyncMode
        rmThermal0CollectEn;    // enable LPF(summation of 8 times data and then divided by 8)
#endif
        rmThermal0PowerUp;    // Enable Thermo Sensor
    }

    // Thermal Sensor 1
    if(gsLightSwitch.usThermalLs.uSensorSel&cAsicSensor1)
    {
#if _ENABLE_THERMAL_SYNC_LPF    // TBD, need add to LS
        rmThermal1LpfDis;    // (Coby) correct procedure to init thermal sensor from HW. Without it, FW will read wrong temperature from PS3.5
                             // resume
        rmThermal1CollectDis;    // diable LPF(summation of 8 times data and then divided by 8)
        rmThermal1LpfEn;    // enble data sync. & collect function
        // only be changed when DisThermalCollectSyncMode
        rmThermal1CollectEn;    // enable LPF(summation of 8 times data and then divided by 8)
#endif
        rmThermal1PowerUp;    // Enable Thermo Sensor
    }

// #if (OEM==SAMSUNG)
//    gsLightSwitch.usThermalLs.usPs0.u16FlashClock=0x125;
//    gsLightSwitch.usThermalLs.usPs0.u16LdpcClock=0x125;
// #endif
    g16FlashClkForThermal=gsLightSwitch.usThermalLs.usPs0.u16FlashClock;
}    /* initThermal */

void core1ReleaseAndReset()
{
    rmCohCpu1ResetStart;
    rmCohDisCpu1;

    rmCohDisAllRegion;
    rmCohCpu1ResetEnd;

    // setCPUClock(30);    // FPGA ALL Clock use 30MHz

    // rmSetSysPllVcoSel(1);
    // while(!rmChkSysPllLock);

    // enableCore1();
}

#endif/* if _PRJ_BOOT2 */

#if (_PRJ_BOOT1||_PRJ_BOOT2)

// GPIO interrupt disable
void gpioIsrDisable(LWORD u32RegIdx, BYTE uPinIdx)
{
    LWORD u32ShiftCnt=0;

    u32ShiftCnt=((uPinIdx)<<2)+cGpioIrqBitShift;
    setRegMask((void *)&r32SysCtrl0[u32RegIdx/4], 0x0, 0x1<<u32ShiftCnt);
}

// GPIO set edge mode
void gpioSetEdgeMode(LWORD u32RegIdx, BYTE uPinIdx)
{
    LWORD u32ShiftCnt=0;

    u32ShiftCnt=((uPinIdx)<<2)+cGpioModeBitShift;
    setRegMask((void *)&r32SysCtrl0[u32RegIdx/4], 0x1<<u32ShiftCnt, 0x1<<u32ShiftCnt);
}

// GPIO enable low active
void gpioLoActiveEnable(LWORD u32RegIdx, BYTE uPinIdx)
{
    LWORD u32ShiftCnt=0;

    u32ShiftCnt=((uPinIdx)<<2);
    setRegMask((void *)&r32SysCtrl0[u32RegIdx/4], 0x1<<u32ShiftCnt, 0x1<<u32ShiftCnt);
}

// GPIO enable high active
void gpioHiActiveEnable(LWORD u32RegIdx, BYTE uPinIdx)
{
    LWORD u32ShiftCnt=0;

    u32ShiftCnt=((uPinIdx)<<2)+cGpioHiActiveBitShift;
    setRegMask((void *)&r32SysCtrl0[u32RegIdx/4], 0x1<<u32ShiftCnt, 0x1<<u32ShiftCnt);
}

// GPIO disable high active
void gpioHiActiveDisable(LWORD u32RegIdx, BYTE uPinIdx)
{
    LWORD u32ShiftCnt=0;

    u32ShiftCnt=((uPinIdx)<<2)+cGpioHiActiveBitShift;
    setRegMask((void *)&r32SysCtrl0[u32RegIdx/4], 0x0, 0x1<<u32ShiftCnt);
}

// GPIO interrupt enable
void gpioIsrEnable(LWORD u32RegIdx, BYTE uPinIdx)
{
    LWORD u32ShiftCnt=0;

    u32ShiftCnt=((uPinIdx)<<2)+cGpioIrqBitShift;
    setRegMask((void *)&r32SysCtrl0[u32RegIdx/4], 0x1<<u32ShiftCnt, 0x1<<u32ShiftCnt);
}

#endif/* if (_PRJ_BOOT||_PRJ_BOOT2) */







