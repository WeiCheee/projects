







#include "inc/TypeDef.h"
#include "inc/GlobVar0.h"
#include "inc/Const.h"
#include "inc/BitDef.h"
#include "inc/DebugLog.h"
#include "inc/EventLogIDX.h"
#include "inc/EventLogFunctionIDX.h"

#if (!_ICE_LOAD_ALL)
#pragma default_function_attributes = @ ".STD_LIB"
#endif

// >>> merge 58xt IM3D
void fillCcmVal(BYTE *upPtr, LWORD u32Size, BYTE uVal)
{
    LWORD u32Loop;
    LWORD u32Val;
    LWORD *up32TmpPtr;

    if((u32Size<64)||((LWORD)upPtr&0x03)||(u32Size&0x03))
    {
        for(u32Loop=0; u32Loop<u32Size; u32Loop++)
        {
            *upPtr++=uVal;
        }
    }
    else
    {
        up32TmpPtr=(LWORD *)upPtr;
        u32Size>>=2;
        u32Val=uVal;
        u32Val=(u32Val<<24)|(u32Val<<16)|(u32Val<<8)|u32Val;

        for(u32Loop=0; u32Loop<u32Size; u32Loop++)
        {
            *up32TmpPtr++=u32Val;
        }
    }
}    /* fillCcmVal */

// <<< merge 58xt IM3D

void sysDelay(LWORD u32DelayLoop)    // 1loop= 1/340M *3=10ns
{
    LWORD u32Loop;

    for(u32Loop=0; u32Loop<u32DelayLoop; u32Loop++)
    {
        _nop();
    }
}

LWORD mod(LWORD u32A, LWORD u32B)
{
    return u32A%u32B;
}

LWORD div(LWORD u32A, LWORD u32B)
{
    return u32A/u32B;
}

/*
   * QWORD mod64(QWORD u64A, QWORD u64B)
   * {
   *  return u64A%u64B;
   * }
   */
QWORD div64(QWORD u64A, QWORD u64B)
{
    return u64A/u64B;
}

WORD addWriteBufPtr(WORD u16SbufPtr, LWORD u32AddCnt)
{
    // u32AddCnt=mod(u32AddCnt, c16WriteBufSize);    // u32AddCnt&(c16WriteBufSize-1);
    while(u32AddCnt>=c16WriteBufSize)
    {
        u32AddCnt-=c16WriteBufSize;
    }

    u16SbufPtr+=u32AddCnt;

    if(u16SbufPtr>=(c16WriteSIdx+c16WriteBufSize))
    {
        u16SbufPtr-=c16WriteBufSize;
    }

    return u16SbufPtr;
}

WORD addReadBufPtr(WORD u16SbufPtr, LWORD u32AddCnt)
{
    // u32AddCnt=mod(u32AddCnt, c16ReadBufSize);    // u32AddCnt&(c16ReadBufSize-1);
    while(u32AddCnt>=c16ReadBufSize)
    {
        u32AddCnt-=c16ReadBufSize;
    }

    u16SbufPtr+=u32AddCnt;

    if(u16SbufPtr>=(c16ReadSIdx+c16ReadBufSize))
    {
        u16SbufPtr-=c16ReadBufSize;
    }

    return u16SbufPtr;
}

/*
   * BYTE addPrdPtrBy1(BYTE uA)
   * {
   *  if(uA==(cPrdDepth-1))
   *  {
   *      return 0;
   *  }
   *  else
   *  {
   *      return uA+1;
   *  }
   * }
   */
/*
   * WORD addHwPrdPtrBy1(WORD u16Ptr)
   * {
   *  if(u16Ptr==(cHwPrdDepth-1))
   *  {
   *      return 0;
   *  }
   *  else
   *  {
   *      return u16Ptr+1;
   *  }
   * }
   */
BYTE addWrFfPtrBy1(BYTE uA)
{
    if(uA==(cWriteFifoDpt-1))
    {
        return 0;
    }
    else
    {
        return uA+1;
    }
}

BYTE subWrFfPtrBy1(BYTE uA)
{
    if(uA>0)
    {
        return uA-1;
    }
    else
    {
        return cWriteFifoDpt-1;
    }
}

BYTE addChPgFfPtrBy1(BYTE uA)
{
    if(uA==(cMaxChFifoDepth-1))
    {
        return 0;
    }
    else
    {
        return uA+1;
    }
}

/*
   * BYTE addChRdFfPtrBy1(BYTE uA)
   * {
   *  if(uA==(cMaxChFifoRDepth-1))
   *  {
   *      return 0;
   *  }
   *  else
   *  {
   *      return uA+1;
   *  }
   * }
   *
   * BYTE addRdFfPtrBy1(BYTE uA)
   * {
   *  if(uA==(cReadFifoDpt-1))
   *  {
   *      return 0;
   *  }
   *  else
   *  {
   *      return uA+1;
   *  }
   * }
   *
   * BYTE subPrdPtrBy1(BYTE uA)
   * {
   *  if(uA==0)
   *  {
   *      return cPrdDepth-1;
   *  }
   *  else
   *  {
   *      return uA-1;
   *  }
   * }
   */

LWORD addPtrBy1(LWORD u32Ptr, LWORD u32Limit)
{
    if(u32Ptr==(u32Limit-1))
    {
        return 0;
    }
    else
    {
        return u32Ptr+1;
    }
}

LWORD subPtrBy1(LWORD u32Ptr, LWORD u32Limit)
{
    if(u32Ptr==0)
    {
        return u32Limit-1;
    }
    else
    {
        return u32Ptr-1;
    }
}

WORD getReadBufPtr(WORD u16ReadBufPtr)
{
    u16ReadBufPtr+=(cSctrPer4k-1);

    if(u16ReadBufPtr<(c16ReadSIdx+c16ReadBufSize))
    {
        // u16ReadBufPtr=(u16ReadBufPtr>>cSctrTo4kShift)<<cSctrTo4kShift;
        u16ReadBufPtr&=~(cSctrPer4k-1);
    }
    else
    {
        u16ReadBufPtr=c16ReadSIdx;
    }

    return u16ReadBufPtr;
}

/*
   * WORD calFreeRdBuf(WORD u16TailPtr)
   * {
   *  WORD u16ReadBufPtr=getReadBufPtr(g16ReadBufPtr);
   *
   *  u16TailPtr&=(WORD)(~(cSctrPer4k-1));
   *
   *  if(u16ReadBufPtr>u16TailPtr)
   *  {
   *      return (c16ReadBufSize-u16ReadBufPtr+u16TailPtr)>>cSctrTo4kShift;
   *  }
   *  else if(u16ReadBufPtr<u16TailPtr)
   *  {
   *      return (u16TailPtr-u16ReadBufPtr)>>cSctrTo4kShift;
   *  }
   *
   *  return 0;
   * }
   */

void initCache()
{
#if _DCache
    __enableDataCache();
#else
    __disableDataCache();
#endif

#if _ICache
    __enableInstCache();
#else
    __disableInstCache();
#endif
}

void flushDCache()
{
#if _DCache
    __flushCache();
#endif
}

void invalidateDCache()
{
#if _DCache
    __invalidateDataCache();
#endif
}

void disableCache()
{
    invalidateDCache();
    __disableDataCache();
    __disableInstCache();
}

void disableBranchPredict()
{
    __disableBranchPredict();
}

void disableVe()
{
    __disable_ve();
}

void invalidateInstCache()
{
    __invalidateInstCache();
}

/*
   * void resetRam(BYTE *ptr, LWORD size, BYTE uVal)
   * {
   *  LWORD i;
   *  LWORD u32Val;
   *  LWORD *u32Ptr;
   *
   *  if((size<64)||((LWORD)ptr&0x03)||(size&0x03))
   *  {
   *      for(i=0; i<size; i++)
   *      {
   * ptr++=uVal;
   *      }
   *  }
   *  else
   *  {
   *      u32Ptr=(LWORD *)ptr;
   *      size>>=2;
   *      u32Val=uVal;
   *      u32Val=(u32Val<<24)|(u32Val<<16)|(u32Val<<8)|u32Val;
   *
   *      for(i=0; i<size; i++)
   *      {
   * u32Ptr++=u32Val;
   *      }
   *  }
   * }
   */

void copyCcmVal(BYTE *upDes, BYTE *upSrc, WORD u16Len)
{
    while(u16Len!=0)
    {
        *upDes++=*upSrc++;
        u16Len--;
    }
}

/*
   * void copyCcm2Tsb(UCBYTE *upDes, BYTE *upSrc, WORD u16Len)
   * {
   *  while(u16Len!=0)
   *  {
   * *upDes++=*upSrc++;
   *      u16Len--;
   *  }
   * }
   */
/*
   * void copyTsb2Ccm(BYTE *upDes, UCBYTE *upSrc, WORD u16Len)
   * {
   *  while(u16Len!=0)
   *  {
   * *upDes++=*upSrc++;
   *      u16Len--;
   *  }
   * }
   */
/*
   * void copyTsb2Tsb(UCBYTE *upDes, UCBYTE *upSrc, WORD u16Len)
   * {
   *  while(u16Len!=0)
   *  {
   * *upDes++=*upSrc++;
   *      u16Len--;
   *  }
   * }
   */
void copyReg2Tsb(UCBYTE *upDes, volatile BYTE *upSrc, WORD u16Len)
{
    while(u16Len!=0)
    {
        *upDes++=*upSrc++;
        u16Len--;
    }
}

void copyReg2Tsb32(volatile LWORD *u32pDes, volatile LWORD *u32pSrc, WORD u16Len)
{
    while(u16Len!=0)
    {
        *u32pDes++=*u32pSrc++;
        u16Len--;
    }
}

/*
   * void copyTsb2Reg(volatile BYTE *upDes, BYTE *upSrc, WORD u16Len)
   * {
   *  while(u16Len!=0)
   *  {
   * upDes++=*upSrc++;
   *      u16Len--;
   *  }
   * }
   */

void copyTsb2Reg32(volatile LWORD *u32pDes, volatile LWORD *u32pSrc, WORD u16Len)
{
    while(u16Len!=0)
    {
        *u32pDes++=*u32pSrc++;
        u16Len--;
    }
}

#if ((_INITDRAM)||(_GREYBOX))
void copySdram2Tsb(volatile UCBYTE *upDes, BYTE *upSrc, LWORD u32Len)
{
    while(u32Len!=0)
    {
        *upDes++=*upSrc++;
        u32Len--;
    }
}

void copyTsb2Sdram(UCBYTE *upDes, volatile BYTE *upSrc, LWORD u32Len)
{
    while(u32Len!=0)
    {
        *upDes++=*upSrc++;
        u32Len--;
    }

#if (_GREYBOX)
    __flushCache();
#endif
}

#endif/* if (_InitDram) */

void setRegMask(LWORD *u32RegAddr, LWORD u32Data, LWORD u32Mask)
{
    *u32RegAddr=(*u32RegAddr&~u32Mask)|(u32Data&u32Mask);
}

void debugWhile()
{
    volatile BYTE uStop=1;

    NLOG(cLogTempDebug, STBLIB_C, 1, "debugwhile, DummyFailType : 0x%04X", gsFtlDbg.u16DummyFailType);

    if(!mChkDummyWrite)
    {
        while(uStop)
            ;
    }
}

void debugLoop(BYTE uFailType)
{
    volatile BYTE uStop;

    NLOG(cLogBuild, STBLIB_C, 1, " debugLoop! uFailType=0x%04x", uFailType);

    uStop=1;

    while(uStop)
        ;

#if (_CPUID==1)
    readWproPage(cWproCacheInfo, c16Tsb0SIdx, 0);
#else
    readWproPageCore0(cWproCacheInfo, c16Tsb0SIdx, 0);
#endif
}

#if _DEBUG_DEADLOCK
void debugDeadLock(WORD u16ErrCod)
{
    gsCacheInfo.u16ErrCod=u16ErrCod;
    NLOG(cLogTempDebug, STBLIB_C, 1, "debugDeadLock, u16ErrCod : 0x%04X", u16ErrCod);

    while(!(u16ErrCod&c16Bit14))
        ;
}

#else
void debugDeadLock(WORD u16ErrCod)
{
    if(gsCacheInfo.u16ErrCod==0)
    {
        gsCacheInfo.u16ErrCod=u16ErrCod;
        mSetDummyWrite;
    }
}

#endif/* if _DEBUG_DEADLOCK */
#if (_CPUID==1)
void setLock(volatile MUTEXINFO *usLock)
{
    /*
       * // Note: __LDREXW and __STREXW are CMSIS functions
       * BYTE uStatus=0;
       *
       * do
       * {
       *  while(__LDREXB(uLock)!=0)
       *      ;                         // Wait until
       *
       *  // Lock_Variable is free
       *  uStatus=__STREXB(1, uLock);    // Try to set
       *  // Lock_Variable
       * }
       * while(uStatus!=0);    // retry until lock successfully
       */
    usLock->u32CoreLock1=1;
    usLock->u32Lock=0;

    __DMB();    // Do not start any other memory access

    while((usLock->u32CoreLock0==1)&&!(usLock->u32Lock))
        ;

    // until memory barrier is completed
}    /* setLock */

void clrLock(volatile MUTEXINFO *usLock)
{
    __DMB();    // Ensure memory operations completed before
    usLock->u32CoreLock1=0;
}

#else/* if (_CPUID==1) */
void setLock(volatile MUTEXINFO *usLock)
{
    usLock->u32CoreLock0=1;
    usLock->u32Lock=1;

    __DMB();    // Do not start any other memory access

    while((usLock->u32CoreLock1==1)&&(usLock->u32Lock==1))
        ;

    // until memory barrier is completed
}    /* setLock */

void clrLock(volatile MUTEXINFO *usLock)
{
    __DMB();    // Ensure memory operations completed before
    usLock->u32CoreLock0=0;
}

// #endif/* if (_CPUID==1) */

BYTE compareByte(BYTE *SrcPtr, BYTE *DesPtr, LWORD u32Length)
{
    LWORD u32Idx;

    for(u32Idx=0; u32Idx<u32Length; u32Idx++)
    {
        if(SrcPtr[u32Idx]!=DesPtr[u32Idx])
        {
            return 0;
        }
    }

    return 1;
}

// BYTE compareVal(BYTE *upSrc, BYTE uPattern, LWORD u32Len)
// {
// BYTE uResult=0x00;
//
// while (u32Len!=0)
// {
// if((*upSrc)==uPattern)
// {
// u32Len--;
// }
// else
// {
// uResult=0x01;
// break;
// }
// }
//
// return uResult;
// }
#if 0
void copyMem(void *pDes, const void *pSrc, LWORD u32Len)
{
    BYTE *puDes;
    BYTE *puSrc;
    LWORD *pu32AlignSrc=(LWORD *)pSrc;
    LWORD *pu32AlignDes=(LWORD *)pDes;

    // If num is more than 4 bytes, and both dest. and source are aligned,
    // then copy dwords
    if((((LWORD)pu32AlignDes&0x3)==0)
       &&(((LWORD)pu32AlignSrc&0x3)==0)
       &&(u32Len>=4))
    {
        while(u32Len>=4)
        {
            *pu32AlignDes++=*pu32AlignSrc++;
            u32Len-=4;
        }
    }

    // Copy remaining bytes
    puDes=(BYTE *)pu32AlignDes;
    puSrc=(BYTE *)pu32AlignDes;

    while(u32Len--)
    {
        *puDes++=*puSrc++;
    }
}    /* copyMem */

#endif/* if 0 */
#endif/* if (_CPUID==1) */
#if _ENABLE_CPU_CYCLE_COUNTER

#define cPmcntensetCycleCounterEnable 31
#define cPmcrCycleCounterDivider 3
#define cPmcrCycleCounterReset 2
#define cPmcrCycleCounterEnable 0

__arm LWORD initCyclecounter()
{
    LWORD u32Value;

    // enable cyclecouner function
    u32Value=(unsigned long)(1<<cPmcntensetCycleCounterEnable);
    __MCR(15, 0, u32Value, 9, 12, 1);
    // configure the cyclecounter module
    u32Value=__MRC(15, 0, 9, 12, 0);
    u32Value|=((0<<cPmcrCycleCounterDivider)|(1<<cPmcrCycleCounterReset)|(1<<cPmcrCycleCounterEnable));
    __MCR(15, 0, u32Value, 9, 12, 0);
    // read current cyclecounter vlaue
    u32Value=__MRC(15, 0, 9, 13, 0);
    return u32Value;
}

__arm void resetCycleCounter()
{
    LWORD u32Value;

    u32Value=__MRC(15, 0, 9, 12, 0);
    u32Value|=(1<<cPmcrCycleCounterEnable);
    __MCR(15, 0, u32Value, 9, 12, 0);
}

__arm void enableDividerCycleCounter()
{
    LWORD u32Value;

    u32Value=__MRC(15, 0, 9, 12, 0);
    u32Value|=(1<<cPmcrCycleCounterDivider);
    __MCR(15, 0, u32Value, 9, 12, 0);
}

__arm LWORD getCycleCounter()
{
    // read the current cyclecounter value
    LWORD u32Value;

    u32Value=__MRC(15, 0, 9, 13, 0);
    return u32Value;
}

#endif/* if _ENABLE_CPU_CYCLE_COUNTER */

#if (!_ICE_LOAD_ALL)
#pragma default_function_attributes =
#endif







