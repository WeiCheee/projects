







#include "inc/ProType.h"
#include "inc/Reg.h"
#include "inc/BitDef.h"

#if (_PRJ_SMIVU||_ICE_LOAD_ALL)
WORD nonDataVendorCmdResetCpu()
{
    // for ver.SM2263
    BYTE uForceRom;

    uForceRom=rmNvmeSubCmdParam1&0x000000FF;

#if ((!_GREYBOX)&&_EN_AUTHENTICATION)
    if(gsLightSwitch.usSecLs.uHpAuthen&cBit0)
    {
        BYTE uCnt=0, uZeroCnt=0;

        while(uCnt<32)
        {
            if(    /*gsLightSwitch.uarHashOffSetTable[uCnt]*/ gHashOffsetBk[uCnt]==0)
            {
                uZeroCnt++;
            }

            uCnt++;
        }

        if(uZeroCnt!=32)
        {
            // manualCompletion(cStatusInvalidOpCode, 0, cNoRwCmd, 0);
            return cStatusInvalidOpCode;
        }
    }
#endif/* if ((!_GREYBOX)&&_EN_AUTHENTICATION) */
    // finish this non-data vendor command
    manualCompletion(cStatusSuccess, 0, cNoRwCmd, 0);

    chkAllIdle();
    // while(!rmSysIdle);

    // Pop Next Cmd, manual won't use SetDesc()fnction need to POP NEX
    rmPopNextCmd;
    _nop();
    _nop();
    _nop();
    _nop();

    /* Check force rom or not? */
    if(uForceRom==0)
    {
        rmClrSoftwareForceRom;
    }
    else
    {
        rmSetSoftwareForceRom;
    }

    mCallFuncPtr2(cfuncResetCpu, cResetCpuSrst);    // fix Linux reset CPU issue.

    while(1)
        ;
}    /* nonDataVendorCmdResetCpu */

#if 0
void nonDataVendorCmdJumpCode()
{
    LWORD u32JumpAddr;

    void (*ISPPretestFunPtr)(BYTE)=0;

    u32JumpAddr=rmNvmeSubCmdParam1;

    ManualCompletion(C_Status_Success, 0, C_Status_Generic);
    // Pop Next Cmd, manual won't use SetDesc()fnction need to POP NEX
    M_POP_NXT_CMD;

    ISPPretestFunPtr=(void (*)(BYTE))(u32JumpAddr);
    ISPPretestFunPtr(0);

    // Disabe_DICache();
    rmDisDCache;
    rmDisICache;
}    /* nonDataVendorCmdJumpCode */

#endif/* if 0 */
void nonDataVendorCmdErasePhysicalBlock()
{
#if 1
    insertVendorTask(cVendorCore1EraseFlash);
#else
    gpFlashAddrInfo=&gpVendorAddrInfo;

    /* Check Vendor command option */
    gOpTyp=cVenderErase;
    g16RwOpt=0;
    setVendorRwInfo();

    // flashErase(g16RwOpt);
    insertVendorTask(cVendorCore1EraseFlash);

    // if(gbEraseFail)
    // { }
#endif
}    /* nonDataVendorCmdErasePhysicalBlock */

void nonDataVendorCmdClearSmart()
{
    BYTE uErase=(rmNvmeSubCmdParam1&0xFF);

    readWproPageCore0(cWproGetLogPg, cNvmeGetLogSIdx, 0);

    bopClrRam((LWORD)(BYTE *)(&gpGetLog->usSmartLog), 0x200, 0x00, cBopWait|cClrTsb);
    bopClrRam((LWORD)(BYTE *)(&gpGetLog->usSmartLog.usSmart.usCnt), sizeof(SMARTCNT), 0x00, cBopWait|cClrTsb);
    bopClrRam((LWORD)(BYTE *)(&gsSmart.usCnt), sizeof(SMARTCNT), 0x00, cBopWait|cClrCore0Dccm);

#if _ENABLE_SMART_LS
    gpGetLog->usSmartLog.uAvailableSpareThreshold=gsLightSwitch.usSmartLs.uAvaliableSpareThres;
#else
    gpGetLog->usSmartLog.uAvailableSpareThreshold=0x10;
#endif
    gpGetLog->usSmartLog.u64arPowerCycles[0]++;
    g64TotalHostRdSecCnt=0;
    gsFtlDbg.u64TotalHostWrSecCnt=0;
    g64HostRdCmdCnt=0;
    g64HostWrCmdCnt=0;
    gsFtlDbg.u32PowerOnCnt=0;
    gsFtlDbg.u32UGSDPwrOnCnt=0;
    gsFtlDbg.u32SlcVthTrackingFailCnt=0;
    gsFtlDbg.u32TlcVthTrackingFailCnt=0;
    g32E2eDetectCnt=0;
    g32InternalDataPath=0;
    // progWproPageCore0(cWproGetLogPg, cNvmeGetLogSIdx);
    progWproPageCore0(cWproGetLogPg, cNvmeGetLogSIdx);

    // Check the TempThres already set new value or not
    readWproPageCore0(cWproFeaturePg, cNvmeFeatSIdx, 0);

    if(gpNvmeFeatVar->usFeat.usTemperatureThres[cOverTempTh][0].u32Current!=gsLightSwitch.usNvmeLs.u16WcTemp)
    {
        gsSmart.usStatus.u16OverTempThres=gpNvmeFeatVar->usFeat.usTemperatureThres[cOverTempTh][0].u32Current;
    }
    else
    {
        gsSmart.usStatus.u16OverTempThres=gsLightSwitch.usNvmeLs.u16WcTemp;
    }

    if(gpNvmeFeatVar->usFeat.usTemperatureThres[cUnderTempTh][0].u32Current!=0)
    {
        gsSmart.usStatus.u16UnderTempThres=gpNvmeFeatVar->usFeat.usTemperatureThres[cUnderTempTh][0].u32Current;
    }

    if(uErase)
    {
        // Abort NVMe DST if in Progress
        if(((gsCurrDstResult.uDstStatus>>4)==cOperationShortDstInProgress)||
           ((gsCurrDstResult.uDstStatus>>4)==cOperationExtendedDstInProgress))
        {
            if(!(gsCurrDstResult.uDstStatus&0x0F))
            {
                gsCurrDstResult.uDstStatus|=cOperationAbortUnknowReson;
            }

            updateNvmeDstData(cReadWpro, cDstLogResultUpdate);
        }

        handleCore0VarErase();
        eraseUnitProcCore0(1);

        // debug purpose
        while(gsRwCtrl.u32FreeSrcFifoHead!=gsRwCtrl.u32FreeSrcFifoTail)
            ;

        while(gsRwCtrl.u32ProgFifoTail!=gsRwCtrl.u32ProgFifoHead)
            ;

#if _ENABLE_SECAPI
        if(gbSecAPIPendingPCIeReset||gbSecAPIPendingNSSR||gbSecAPIPendingInitATA||gbSecAPIClearATASecurityPrepare)
        {
            handleSecFlag();
        }
#endif
    }

    progCacheInfoTab();
}    /* nonDataVendorCmdClearSmart */

void inputVthSet()
{
    volatile BYTE uDebug, VthIndex;

    while(gsTskFifoCtrl.u32HeadPtr!=gsTskFifoCtrl.u32TailPtr)
        ;

    while(gsRwCtrl.u32FreeSrcFifoHead!=gsRwCtrl.u32FreeSrcFifoTail)
        ;

    while(gsRwCtrl.u32ProgFifoTail!=gsRwCtrl.u32ProgFifoHead)
        ;

    gVuCmdSpFlag=(gVuCmdSpFlag|cVuCmdVthEnable);    // bit0->VthCenter

    garVuCmdVthCenter[cAR]=(BYTE)((rmNvmeSubCmdParam1&0x000000FF)>>0);
    garVuCmdVthCenter[cCR]=(BYTE)((rmNvmeSubCmdParam1&0x0000FF00)>>8);
    garVuCmdVthCenter[cER]=(BYTE)((rmNvmeSubCmdParam1&0x00FF0000)>>16);
    garVuCmdVthCenter[cGR]=(BYTE)((rmNvmeSubCmdParam1&0xFF000000)>>24);
    garVuCmdVthCenter[cBR]=(BYTE)((rmNvmeSubCmdParam2&0x000000FF)>>0);
    garVuCmdVthCenter[cDR]=(BYTE)((rmNvmeSubCmdParam2&0x0000FF00)>>8);
    garVuCmdVthCenter[cFR]=(BYTE)((rmNvmeSubCmdParam2&0x00FF0000)>>16);
    garVuCmdVthCenter[cSLCR]=(BYTE)((rmNvmeSubCmdParam2&0xFF000000)>>24);

    while(gsTskFifoCtrl.u32HeadPtr!=gsTskFifoCtrl.u32TailPtr)
        ;

    while(gsRwCtrl.u32FreeSrcFifoHead!=gsRwCtrl.u32FreeSrcFifoTail)
        ;

    while(gsRwCtrl.u32ProgFifoTail!=gsRwCtrl.u32ProgFifoHead)
        ;

    // fillUnknownVendorCmdPattern();
}    /* inputVthSet */

#endif    // (_PRJ_SMIVU)







