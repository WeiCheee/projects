







#include "inc/TypeDef.h"
#include "inc/Const.h"

// -----------------TSB----------------//
#pragma default_variable_attributes = @ ".TSBUF0"    // TSB0 384K
// volatile BYTE garTsb0[cTsb0Size][512];
#pragma default_variable_attributes =

#pragma default_variable_attributes = @ ".BADINFOBUF"
// volatile BYTE garBadInfoBuf[cTsb0Size*512];
#pragma default_variable_attributes =

#pragma default_variable_attributes = @ ".TSBUF0_16"
// volatile WORD g16arTsb0[cTsb0Size][512/2];
#pragma default_variable_attributes =

#pragma default_variable_attributes = @ ".BADINFOBUF_16"
// volatile WORD g16arBadInfoBuf[(cTsb0Size*512)/2];
#pragma default_variable_attributes =

#pragma default_variable_attributes = @ ".TSBUF0_32"
// volatile LWORD g32arTsb0[cTsb0Size][512/4];
#pragma default_variable_attributes =

#pragma default_variable_attributes = @ ".BADINFOBUF_32"
// volatile LWORD g32arBadInfoBuf[(cTsb0Size*512)/4];
#pragma default_variable_attributes =

#pragma default_variable_attributes = @ ".TSBUF0_64"
// volatile QWORD g64arTsb0[cTsb0Size][512/8];
#pragma default_variable_attributes =

#pragma default_variable_attributes = @ ".F2H_TAB"    // TSB1 total 128K : F2H 64K, H2F 64K
#pragma default_variable_attributes =

#pragma default_variable_attributes = @ ".RSV_SCT"
#pragma default_variable_attributes =

#pragma default_variable_attributes = @ ".H2F_TAB"
#pragma default_variable_attributes =

#pragma default_variable_attributes = @ ".TSB2"    // TSB2 256K
#pragma default_variable_attributes =

#pragma default_variable_attributes = @ ".TSB3"    // TSB3 256K
#pragma default_variable_attributes =

#pragma default_variable_attributes = @ ".TSB4_EVENTLOG"    // TSB4 EventLog block 4K
volatile WORD g16arEventLog[cEventLogSize];
// volatile WORD g16arCore1EventLog[cCore1EventLogSize];
#pragma default_variable_attributes =

#pragma default_variable_attributes = @ ".TSB4_GCDATACRC32"
#pragma default_variable_attributes =

#pragma default_variable_attributes = @ ".TSB4_Temp"    // TSB4 EventLog block 5K
LWORD g32arHmbCrc[c16HmbMaxTableNumAlign];    // 2kB
BYTE gCrcDataBuffer[cCrcDataBufferSize];    // 1K
LWORD g32arGcDataCrc[(cMaxHmbGcCacheNum*cTsb0Size/cHmbChunkSctrSize)*2];    // 1.5K, Crc32: Data+E2e
LWORD g32arGcInfoCrc[(cWproGcInfoPage-cWproGcDesF2hTab00+1)*(c32GcInfoTabSctrCnt/c16LoadPartTabStcrCnt)];    // <512b
LWORD g32arGcPtyCrc[cPartialParityNum*2];    // 3K
LWORD g32arTsbCrc[(cTsb0Size/cHmbChunkSctrSize)*2];    // 48b
#pragma default_variable_attributes =

#pragma default_variable_attributes = @ ".TSB4_RSVD"    // 4K
BYTE garTsb4Rsvd[4096];
#pragma default_variable_attributes =

// #pragma default_variable_attributes = @ ".CACHE_INFO"    // TSB5 32K
// #pragma default_variable_attributes =

// #pragma default_variable_attributes = @ ".LIGHTSWITCH"    // LightSwitch 384K
// LIGHTSWITCH gsLightSwitch;
// #pragma default_variable_attributes =

#pragma default_variable_attributes = @ ".NVMEFEATURE"    // TSB0
// NVMEFEATVAR gsNvmeFeatVar;
#pragma default_variable_attributes =

#pragma default_variable_attributes = @ ".GETLOGPAGE"    // TSB0
// GETLOGINFO gsGetLog;
#pragma default_variable_attributes =

// ===================================================================MIKEY

#pragma default_variable_attributes = @ ".F2H_TAB"
F2HTABLE garCacheF2hTab[c16CacheF2hSize];    // 32KB
#if (!_TSB_BiCS4)
LWORD g32arHmbCrc[c16HmbMaxTableNum];    // 2kB
LWORD g32arGlobReadCnt[c16MaxBlockNum];    // 6kB
LWORD g32arLogNandQueue[2048/4];    // 2kB
BYTE gCrcDataBuffer[cCrcDataBufferSize];    // 1K
LWORD g32arGcDataCrc[(cMaxHmbGcCacheNum*cTsb0Size/cHmbChunkSctrSize)*2];    // 1.5K, Crc32: Data+E2e
LWORD g32arGcInfoCrc[(cWproGcInfoPage-cWproGcDesF2hTab00+1)*(c32GcInfoTabSctrCnt/c16LoadPartTabStcrCnt)];    // <512b
LWORD g32arGcPtyCrc[cPartialParityNum*2];    // 3K
LWORD g32arTsbCrc[(cTsb0Size/cHmbChunkSctrSize)*2];    // 48b
#endif
#pragma default_variable_attributes =    // END OF .F2H_TAB

#pragma default_variable_attributes = @ ".RSV_SCT"
LWORD g32arGcInvaildPageBimap[c16RaidBufSize];    // 16KB
#pragma default_variable_attributes =

#pragma default_variable_attributes = @ ".H2F_TAB0"
LWORD g32arH2fTable[c32H2fTabRamSize/4];    // 64kb //H2FTABLE g32arH2fTable[c16H2fTabSize];
#pragma default_variable_attributes =    // END OF .H2F_TAB

#pragma default_variable_attributes = @ ".MAPCACHE_TAB0"
LWORD garH2f1kTable[cMaxRH2fTabNum][c16RH2fTabSize];    // 64kb
#pragma default_variable_attributes =    // END OF .H2F_TAB

// #pragma default_variable_attributes = @ ".BootTempVar"
// WORD g16arTempGlobEraseCnt[c16MaxBlockNum];    // 2kb
// WPROINFO gsTempWproInfo;
// #pragma default_variable_attributes =    // END OF .BootTempVar

// #pragma default_variable_attributes = @ ".CACHE_INFO"
// #pragma pack(1)
// UCLWORD g32arGlobEraseCnt[c16MaxBlockNum];    // 4kb
#if _EN_VPC_SWAP
__root __no_init LWORD g32arMlcMoBit[c16MaxBlockNum/32] @ cg32arMlcMoBit;
__root __no_init LWORD g32arSkipGcSrch[c16MaxBlockNum/32] @ cg32arSkipGcSrch;
__root __no_init LWORD g32arVPCntValid[c16MaxBlockNum/32] @ cg32arVPCntValid;
#else
__root __no_init LWORD g32arCacheBlkVpCnt[c16MaxBlockNum] @ cg32arCacheBlkVpCnt;    // 6kb
#endif

__root __no_init LWORD g32arPopBit[c16MaxBlockNum/32] @ cg32arPopBit;

__root __no_init LWORD g32arH2fTabBlkSn[c16MaxH2fTabBlkNum] @ cg32arH2fTabBlkSn;    // 32b
__root __no_init WORD g16arH2fTabBlk[c16MaxH2fTabBlkNum] @ cg16arH2fTabBlk;    // 16b
__root __no_init WORD g16arH2fTabBlkVpCnt[c16MaxH2fTabBlkNum] @ cg16arH2fTabBlkVpCnt;    // 16b
__root __no_init WORD g16arH2fTabPtr[c16MaxH2fTabNum+c16HmbMaxTableNum] @ cg16arH2fTabPtr;    // 18kb+1kb
__root __no_init WORD g16arH2fBackup[c16HmbMaxTableNum] @ cg16arH2fBackup;    // 1kb
// LWORD g32arH2fTabNullFlag[c16MaxH2fTabNum/32];    // 2kb
__root __no_init LWORD g32GcSkipSrcHblkSrch[c16MaxH2fTabNum/32] @ cg32GcSkipSrcHblkSrch;    // 1kb

__root __no_init WORD g16arRaidParityBlk[cRaidParityBlockNum] @ cg16arRaidParityBlk;
__root __no_init WORD g16arRaidParityPtr[cRaidParityPageNum] @ cg16arRaidParityPtr;
__root __no_init WORD g16arRaidPtyBlkVpCnt[cRaidParityBlockNum] @ cg16arRaidPtyBlkVpCnt;

// WORD g16arCacheBlock[c16MaxCacheBlkNumInF2hTab];    // 128b
__root __no_init PUSHSPRINFO garPushSpareQ[c16MaxPushSprbNum] @ cgarPushSpareQ;
__root __no_init LWORD g16PushSpareCnt @ cg16PushSpareCnt;
__root __no_init LWORD g16PushSpareTail @ cg16PushSpareTail;
__root __no_init LWORD g16PushSpareHead @ cg16PushSpareHead;
// WORD g16RebuGcDesF2hCnt;
__root __no_init WORD g16MaxSlcCacheBlockThr @ cg16MaxSlcCacheBlockThr;
__root __no_init WORD g16CurrSlcCacheBlockThr @ cg16CurrSlcCacheBlockThr;
__root __no_init LWORD g32WearLevelCnt @ cg32WearLevelCnt;
// rdlink
// __root __no_init LWORD g32BkRdCacheBlkSerial @ cg32BkRdCacheBlkSerial;
__root __no_init LWORD g32BkRdActCBlkSerial @ cg32BkRdActCBlkSerial;
__root __no_init LWORD g32BkRdCacheFreePagePtr @ cg32BkRdCacheFreePagePtr;
__root __no_init LWORD g32BkCacheBlkSerial @ cg32BkCacheBlkSerial;
__root __no_init LWORD g32BkFluBlkSerial @ cg32BkFluBlkSerial;
__root __no_init LWORD g32BkGcDesSerial @ cg32BkGcDesSerial;
__root __no_init LWORD g32BkH2fTabBlkSerial @ cg32BkH2fTabBlkSerial;
// LWORD g32BkGcSrcF4kPtr;
__root __no_init LWORD g32BkTotalSlcVpc @ cg32BkTotalSlcVpc;
__root __no_init LWORD g32BkTotalTlcVpc @ cg32BkTotalTlcVpc;
__root __no_init WORD g16BkCacheF2hTabFreePtr @ cg16BkCacheF2hTabFreePtr;
__root __no_init WORD g16BkRdActiveCacheBlock @ cg16BkRdActiveCacheBlock;
__root __no_init WORD g16BkGcDesSlcBlock @ cg16BkGcDesSlcBlock;
__root __no_init WORD g16BkGcDesTlcBlock @ cg16BkGcDesTlcBlock;
__root __no_init WORD g16BkFluCacheBlock @ cg16BkFluCacheBlock;
__root __no_init WORD g16BkPrePopCacheBlock @ cg16BkPrePopCacheBlock;
__root __no_init WORD g16BkActH2fTabFblk @ cg16BkActH2fTabFblk;
__root __no_init WORD g16BkH2fTabFreePagePtr @ cg16BkH2fTabFreePagePtr;

__root __no_init LWORD g32TotalEraseCnt @ cg32TotalEraseCnt;
__root __no_init LWORD g32DynamicTotalEraseCnt @ cg32DynamicTotalEraseCnt;
__root __no_init LWORD g32SLCTotalEraseCnt @ cg32SLCTotalEraseCnt;

__root __no_init LWORD g32SlcMaxEraseCnt @ cg32SlcMaxEraseCnt;
__root __no_init LWORD g32TlcMaxEraseCnt @ cg32TlcMaxEraseCnt;

__root __no_init WORD g16TLCGcWLCnt @ cg16TLCGcWLCnt;
__root __no_init WORD g16SLCReclaimCnt @ cg16SLCReclaimCnt;
__root __no_init WORD g16ReclaimCnt @ cg16ReclaimCnt;
__root __no_init WORD g16WLCheckBlk @ cg16WLCheckBlk;

__root __no_init WORD g16SLCFlushCnt @ cg16SLCFlushCnt;
__root __no_init WORD g16H2FReadScrubCnt @ cg16H2FReadScrubCnt;

__root __no_init BYTE gBkFidBlock @ cgBkFidBlock;    // for downloadmicrocode
// __root __no_init BYTE gBkF2hTabBank @ cgBkF2hTabBank; // The F2h bank of active cache block at last rdlink
__root __no_init BYTE gBkRdActF2hTabBank @ cgBkRdActF2hTabBank;

/*****************/
__root __no_init WORD g16BkActiveCacheBlock @ cg16BkActiveCacheBlock;
__root __no_init WORD g16BkCacheActWindow @ cg16BkCacheActWindow;
__root __no_init WORD g16BkCacheWindowGrp @ cg16BkCacheWindowGrp;
__root __no_init WORD g16BkActiveGcDesBlock @ cg16BkActiveGcDesBlock;
__root __no_init WORD g16BkGcDesActWindow @ cg16BkGcDesActWindow;
__root __no_init WORD g16BkGcDesWindowGrp @ cg16BkGcDesWindowGrp;

// LWORD g32BkWproSerial;
__root __no_init WORD g16TotalProgFailCnt @ cg16TotalProgFailCnt;

__root __no_init LWORD g32SpecFuncFlag @ cg32SpecFuncFlag;

__root __no_init WORD g16BkWriteBufPtr @ cg16BkWriteBufPtr;
__root __no_init WORD g16BkFlashWBufPtr @ cg16BkFlashWBufPtr;
__root __no_init LWORD g32MaxRebuTime @ cg32MaxRebuTime;

__root __no_init LWORD g32MaxS2TGCtime @ cg32MaxS2TGCtime;
__root __no_init LWORD g32MaxT2TGCtime @ cg32MaxT2TGCtime;
__root __no_init LWORD g32E2eDetectCnt @ cg32E2eDetectCnt;
__root __no_init QWORD g64HostWrCmdCnt @ cg64HostWrCmdCnt;
__root __no_init QWORD g64HostRdCmdCnt @ cg64HostRdCmdCnt;
__root __no_init QWORD g64TotalHostRdSecCnt @ cg64TotalHostRdSecCnt;
__root __no_init QWORD g64NandSlcTotalWriteSecCnt @ cg64NandSlcTotalWriteSecCnt;
__root __no_init QWORD g64NandTlcTotalWriteSecCnt @ cg64NandTlcTotalWriteSecCnt;
__root __no_init QWORD g64NandSlcTotalReadSecCnt @ cg64NandSlcTotalReadSecCnt;
__root __no_init QWORD g64NandTlcTotalReadSecCnt @ cg64NandTlcTotalReadSecCnt;

__root __no_init WORD g16RaidDecTotalCnt @ cg16RaidDecTotalCnt;
__root __no_init WORD g16RaidDecSkipCnt @ cg16RaidDecSkipCnt;
__root __no_init BYTE gRaidMaxPopEngCnt @ cgRaidMaxPopEngCnt;
__root __no_init BYTE gPowerDownMode @ cgPowerDownMode;

__root __no_init WORD g16StaticBound @ cg16StaticBound;

__root __no_init CACHEINFO gsBkPcieErrCacheInfo @ cgsBkPcieErrCacheInfo;

__root __no_init NAMESPACEINFO gsNamespace @ cgsNamespace;

__root __no_init WORD g16SramOneBitErrCnt @ cg16SramOneBitErrCnt;
__root __no_init WORD g16SramTwoBitErrCnt @ cg16SramTwoBitErrCnt;
__root __no_init LWORD g32InternalDataPath @ cg32InternalDataPath;
__root __no_init LWORD g32PrdCommandRetryCnt @ cg32PrdCommandRetryCnt;

__root __no_init LWORD g32Vdt27FailCnt @ cg32Vdt27FailCnt;
__root __no_init LWORD g32ThermalMT1TranCnt @ cg32ThermalMT1TranCnt;
__root __no_init LWORD g32ThermalMT2TranCnt @ cg32ThermalMT2TranCnt;
__root __no_init LWORD g32PwrOnAbortPs3Cnt @ cg32PwrOnAbortPs3Cnt;
__root __no_init LWORD g32PwrOnAbortPs4Cnt @ cg32PwrOnAbortPs4Cnt;
__root __no_init LWORD g32TotalPcieRdErrCnt @ cg32TotalPcieRdErrCnt;
__root __no_init QWORD g64PwrOnPs3Cnt @ cg64PwrOnPs3Cnt;
__root __no_init QWORD g64PwrOnPs4Cnt @ cg64PwrOnPs4Cnt;
__root __no_init LWORD g32TotalPcieWrErrCnt @ cg32TotalPcieWrErrCnt;
__root __no_init LWORD g32TotalPcieOthErrCnt @ cg32TotalPcieOthErrCnt;

__root __no_init LWORD g32BkRdFlsCBlkSerial @ cg32BkRdFlsCBlkSerial;
__root __no_init WORD g16BkRdFlushCacheBlock @ cg16BkRdFlushCacheBlock;
__root __no_init BYTE gBkRdFlsF2hTabBank @ cgBkRdFlsF2hTabBank;    // The F2h bank of flush  cache block at last rdlink
__root __no_init LWORD g32ThermalMT3TranCnt @ cg32ThermalMT3TranCnt;
__root __no_init LWORD g32AsicThermalMT3TranCnt @ cg32AsicThermalMT3TranCnt;

__root __no_init LWORD g32arCacheBlkSerial[cCacheBlkNum] @ cg32arCacheBlkSerial;
__root __no_init WORD g16arCacheBlock[cCacheBlkNum] @ cg16arCacheBlock;
__root __no_init BYTE garCacheBlkF2hTabBank[cCacheBlkNum] @ cgarCacheBlkF2hTabBank;

__root __no_init LWORD g32StaticSLCTotalEC @ cg32StaticSLCTotalEC;
__root __no_init LWORD g32DynamicSLCTotalEC @ cg32DynamicSLCTotalEC;
__root __no_init WORD g16DummyQBAnalysis[4] @ cg32DummyQBAnalysis;
#if _EN_VPC_SWAP
__root __no_init WORD g16arGlobReadCnt[c16MaxBlockNum] @ cg16arGlobReadCnt;
__root __no_init BYTE garGlobReadCntHighByte[c16MaxBlockNum] @ cgarGlobReadCntHighByte;
#endif

__root __no_init DBGLOG gsFtlDbg @ c32Tsb2SAddr+(c16CacheInfoTabSize-1)*512-sizeof(DBGLOG);
__root __no_init BYTE garWproQRebuild[512] @ c32Tsb2SAddr+(c16CacheInfoTabSize-1)*512;
//
// #pragma default_variable_attributes =    // END OF .CACHE_INFO

// #pragma default_variable_attributes = @ ".PS4_BACKUP_VAR"
// PS4BACKUP garBkPS4Data;
// #pragma default_variable_attributes =







