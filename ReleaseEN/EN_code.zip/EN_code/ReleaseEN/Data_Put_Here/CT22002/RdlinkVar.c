







#include "inc/TypeDef.h"
#include "inc/Const.h"
#include "inc/table.h"
// #include "inc/nvmectrl.h"
#include "inc/Rdlink.h"

// if (!_ICE_LOAD_ALL)
#pragma default_variable_attributes = @ ".RDLINK_VAR"
// #pragma default_variable_attributes = @ ".TSB4"
// #endif
// >>> for IAR 7.5 compiler change variable location
WORD g16arTempDiffType2Offset[cMaxDiffType2Num];    // 128B
WORD g16arTempGlobEraseCnt[c16MaxBlockNum];
LWORD g32arPopDeniedFlag[c16MaxBlockNum/32];
DIFFTYPE2ADDRINFO gsDiffTyp2AddrInfo;
FOUNDWPRO garFoundWproQ[cMaxWproBlkCnt];
BYTE garFoundWproIdx[cMaxWproBlkCnt];
WORD g16arWproBlkEraseCnt[cMaxWproBlkCnt];
// <<<

WORD g16FoundCachebCnt;
WORD g16arFoundCacheIdx[cMaxFoundCacheFBlockNum];
FOUNDQINFO garFoundCacheQ[cMaxFoundCacheFBlockNum];

RLH2FTABQINFO garH2fTabQ[c16MaxH2fTabBlkNum];
BYTE garH2fTabQIndex[c16MaxH2fTabBlkNum];
RLERRBLKINFO garErrBlock[c16MaxErrBlkNum];

// add for not exit F2H table SLC block
WORD g16CopyFblockCnt;
WORD g16arCopyFblockIdx[cMaxCopyBlockNum];    // only record index of FoundCacheQ
WORD g16arRdlinkLog[c16RdlinkLogSize/2];
WORD g16RdlinkLogUpdPtr;
LWORD g32arRdLkSrcVaildF2h[c16CacheF2hSize/32];    // 1k
LWORD g32arRdLkKeepRWBitmap[5];    // 32*5=160

// if (!_ICE_LOAD_ALL)
#pragma default_variable_attributes =    // @ ".RDLINK_VAR"
// #endif







