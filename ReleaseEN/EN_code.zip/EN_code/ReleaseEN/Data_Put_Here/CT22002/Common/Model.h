// -----------------------------------------------------------------------
//  hardcfg.A11 hardware and feature settings for CV1
//  (C)Copyrighit LiteOn IT By Sam Hu
// -----------------------------------------------------------------------
#ifndef _H_HARDCFG_
#define _H_HARDCFG_

//Projects Name
#define GEN_CL1  0x1000

//Form Factor
#define FORM_FACTOR   0x0F00
#define FF_ALL        0x0000
#define FF_M2_2230SS  0x0100
#define FF_M2_2242SS  0x0200
#define FF_M2_2280SS  0x0300

#define FF_IS_M2(x)     ((x&FORM_FACTOR)==FF_M2_2230SS)||((x&FORM_FACTOR)==FF_M2_2242SS)||((x&FORM_FACTOR)==FF_M2_2280SS))

//Size
#define DRIVE_SIZE_16   0x0010
#define DRIVE_SIZE_32   0x0020
#define DRIVE_SIZE_64   0x0030
#define DRIVE_SIZE_80   0x0040
#define DRIVE_SIZE_96   0x0050
#define DRIVE_SIZE_120  0x0060
#define DRIVE_SIZE_128  0x0070
#define DRIVE_SIZE_240  0x0080
#define DRIVE_SIZE_256  0x0090
#define DRIVE_SIZE_480  0x00A0
#define DRIVE_SIZE_512  0x00B0
#define DRIVE_SIZE_960  0x00C0
#define DRIVE_SIZE_1024 0x00D0

//Feature  Bit filed
#define FEATURE_TCG         0x0001 //Bit 0
#define FEATURE_AES         0x0002 //Bit 1
#define FEATURE_Enterprise  0x0004 //Bit 2
//Nand 512Gb per die
#define NAND512Gb_Per_Die        0x0008

// -----
//  CL1
// -----
#define CL1_ALL_M2                  (GEN_CL1|FF_M2_2230SS|FF_M2_2242SS|FF_M2_2280SS)
#define CL1_3D128                   (GEN_CL1|FF_M2_2230SS|DRIVE_SIZE_128)
#define CL1_3D256                   (GEN_CL1|FF_M2_2230SS|DRIVE_SIZE_256)
#define CL1_3D512_512Gb             (GEN_CL1|FF_M2_2230SS|DRIVE_SIZE_512|NAND512Gb_Per_Die)
#define CL1_3D_All                  (GEN_CL1|FF_M2_2230SS)
#define CL1_4D128                   (GEN_CL1|FF_M2_2242SS|DRIVE_SIZE_128)
#define CL1_4D256                   (GEN_CL1|FF_M2_2242SS|DRIVE_SIZE_256)
#define CL1_4D512_512Gb             (GEN_CL1|FF_M2_2242SS|DRIVE_SIZE_512|NAND512Gb_Per_Die)
#define CL1_4D_All                  (GEN_CL1|FF_M2_2242SS)
#define CL1_8D128                   (GEN_CL1|FF_M2_2280SS|DRIVE_SIZE_128)
#define CL1_8D256                   (GEN_CL1|FF_M2_2280SS|DRIVE_SIZE_256) 
#define CL1_8D512                   (GEN_CL1|FF_M2_2280SS|DRIVE_SIZE_512) 
#define CL1_8D512_512Gb             (GEN_CL1|FF_M2_2280SS|DRIVE_SIZE_512|NAND512Gb_Per_Die) 
#define CL1_8D_All                  (GEN_CL1|FF_M2_2280SS)



#define PRODUCT_NAME CL1_8D_All

// -----------------------------------------------------------------------
//  OEM definition
// -----------------------------------------------------------------------
#include "OEM.h"


// -----------------------------------------------------------------------
//  OEM selection,
//  Notice: don't touch the code below, or OEM maybe incorrect.
// -----------------------------------------------------------------------
#define  OEM        SAMSUNG


// -----------------------------------------------------------------------
//  Specific feature for vendors
// -----------------------------------------------------------------------
// ------
//  DELL
// ------
#if OEM == DELL
#define S_DELL_SCP                (1)
#define _SUPPORT_FEATURE_DITM


// --------
//  Lenovo
// --------
#elif OEM == LENOVO
#define _ENABLE_ATA_PASSTHROUGH_BY_OEM
#define _SUPPORT_FEATURE_DITM


// ----
//  HP
// ----
#elif OEM == HP


// ----
//  SAMSUNG
// ----
#elif OEM == SAMSUNG
#define _FDE_DRIVE
#define _ENABLE_ATA_PASSTHROUGH_BY_OEM


// ---------
//  Default  STD
// ---------
#else
#define _ENABLE_ATA_PASSTHROUGH_BY_OEM
#endif




// -----------------------------------------------------------------------
//  Notice: don't touch the code below, or OEM and REF code maybe error
//  for test code used only
// -----------------------------------------------------------------------
  #define OEM0    'C'                   // OEM CODE
  #define OEM1    'T'                   // OEM CODE
  #define OEM2    '2'                   // OEM CODE
  #define OEM3    '2'                   // OEM CODE
  #define OEM4    '0'                   // OEM CODE
  #define OEM5    '0'                   // OEM CODE
  #define OEM6    '2'                   // OEM CODE
  #define OEM7    '0'                   // OEM CODE

  #define REF0    ' '                   // REFLECTION CODE
  #define REF1    ' '                   // REFLECTION CODE
  #define REF2    ' '                   // REFLECTION CODE
  #define REF3    ' '                   // REFLECTION CODE
  #define REF4    ' '                   // REFLECTION CODE
  #define REF5    ' '                   // REFLECTION CODE
  #define REF6    ' '                   // REFLECTION CODE
  #define REF7    ' '                   // REFLECTION CODE

#endif
