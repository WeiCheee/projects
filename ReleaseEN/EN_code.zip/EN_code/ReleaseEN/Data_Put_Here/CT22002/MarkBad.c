







void updateFlashQueInfo()
{
#if (!_TSB_BiCS4_WR)
    g16arBadInfoBuf[cNandQueueWordOffset]=g16EccFailNormalQueIndex;
    g16arBadInfoBuf[cNandQueueWordOffset+1]=g16EccFailAuxQueIndex;
    g16arBadInfoBuf[cNandQueueWordOffset+2]=g16EccFailChAndCe;
    g16arBadInfoBuf[cNandQueueWordOffset+3]=g16EccFailDieAndPlane;
    g16arBadInfoBuf[cNandQueueWordOffset+4]=g16EccFailBlkAddr;
    g16arBadInfoBuf[cNandQueueWordOffset+5]=g16EccFailPageAddr;
    g16arBadInfoBuf[cNandQueueWordOffset+6]=g16EccFailRegInfo;    // 0x118 & 0x11D
    g16arBadInfoBuf[cNandQueueWordOffset+7]=g16EccFailChunkBitMap;    // g16DebugLastFailChunkBitMap
    copyCcmVal((BYTE *)(&(g16arBadInfoBuf[cNandQueueWordOffset+0x10])), (BYTE *)(&g32arLogNandQueue[0]), gByteCntOfLogNandQueue);
#endif
}

void assignStruCeNDie(ADDRINFO *upTmpAddrInfo, BYTE uIntlvAddr)
{
    upTmpAddrInfo->uCe=mGetCEAddr(uIntlvAddr);
    upTmpAddrInfo->uDieAddr=mGetDieAddr(uIntlvAddr);
}

void markEraseFailBlock()
{
    ADDRINFO usTmpAddrInfo;
    WORD u16Index, u16TempBlkAddr;
    BYTE uStrPlane, uLoop1;

    uLoop1=0;

    while(gsBadInfo.uEraseFailQueCnt)
    {
        if(!mChkBadBitTab(gsBadInfo.uarEsFailQue[uLoop1].u16EsFailFBlock))
        {
            mSetBadBitTab(gsBadInfo.uarEsFailQue[uLoop1].u16EsFailFBlock);
            gsBadInfo.u16TotalNewBadCnt++;

            for(u16Index=0; u16Index<32; u16Index++)    // 32 bit ch and Intlv status
            {
                if((mChkBitMask(gsBadInfo.uarEsFailQue[uLoop1].u32EsFailSts,
                                u16Index))&&(gsBadInfo.u16NewBadInBufPtr<(cBadInfoRamSize/cMarkBadSize)))
                {
                    usTmpAddrInfo.u16FBlock=gsBadInfo.uarEsFailQue[uLoop1].u16EsFailFBlock;

                    usTmpAddrInfo.uCh=u16Index/cMaxIntlvWay;
                    usTmpAddrInfo.uIntlvAddr=u16Index%cMaxIntlvWay;
                    assignStruCeNDie(&usTmpAddrInfo, usTmpAddrInfo.uIntlvAddr);
                    garBadInfoBuf[(gsBadInfo.u16NewBadInBufPtr*cMarkBadSize)+0]=gsBadInfo.uarEsFailQue[uLoop1].u16EsFailFBlock;
                    garBadInfoBuf[(gsBadInfo.u16NewBadInBufPtr*cMarkBadSize)+1]=gsBadInfo.uarEsFailQue[uLoop1].u16EsFailFBlock>>8;
                    garBadInfoBuf[(gsBadInfo.u16NewBadInBufPtr*
                                   cMarkBadSize)+2]=gsBadInfo.uarEsFailQue[uLoop1].u32EsFailSts>>(cMaxIntlvWay*usTmpAddrInfo.uCh);

                    garBadInfoBuf[(gsBadInfo.u16NewBadInBufPtr*cMarkBadSize)+3]=gsBadInfo.uarEsFailQue[uLoop1].u16EraseCnt;
                    garBadInfoBuf[(gsBadInfo.u16NewBadInBufPtr*cMarkBadSize)+4]=gsBadInfo.uarEsFailQue[uLoop1].u16EraseCnt>>8;
                    garBadInfoBuf[(gsBadInfo.u16NewBadInBufPtr*cMarkBadSize)+5]=((usTmpAddrInfo.uCh<<4)|(usTmpAddrInfo.uIntlvAddr&0x0F));
                    garBadInfoBuf[(gsBadInfo.u16NewBadInBufPtr*
                                   cMarkBadSize)+
                                  6]=(garChMapTable[usTmpAddrInfo.uCh])<<6|(garCeMapTable[usTmpAddrInfo.uCe])<<3|(usTmpAddrInfo.uDieAddr);
                    garBadInfoBuf[(gsBadInfo.u16NewBadInBufPtr*cMarkBadSize)+7]=cEraseFailID;

                    // 4 plane
                    for(uStrPlane=0; uStrPlane<gPlaneNum; uStrPlane++)
                    {
                        usTmpAddrInfo.uPlaneAddr=uStrPlane;
                        u16TempBlkAddr=getDiffAddr(usTmpAddrInfo.u16FBlock,
                                                   usTmpAddrInfo.uCh,
                                                   usTmpAddrInfo.uIntlvAddr,
                                                   usTmpAddrInfo.uPlaneAddr);
                        garBadInfoBuf[(gsBadInfo.u16NewBadInBufPtr*cMarkBadSize)+0x8+(uStrPlane<<1)]=u16TempBlkAddr;
                        garBadInfoBuf[(gsBadInfo.u16NewBadInBufPtr*cMarkBadSize)+0x9+(uStrPlane<<1)]=u16TempBlkAddr>>8;
                    }

                    gsBadInfo.u16NewBadInBufPtr++;
                }
            }

            gsBadInfo.u16EraseFailFblkCnt++;    // 20181213_KevinGG_01

            g16arBadInfoBuf[cMarkBadCntOfst]=gsBadInfo.u16TotalNewBadCnt;
            g16arBadInfoBuf[1]=gsBadInfo.u16ProgFailFblkCnt;    // 20181213_KevinGG_01
            g16arBadInfoBuf[2]=gsBadInfo.u16EraseFailFblkCnt;    // 20181213_KevinGG_01
            g16arBadInfoBuf[cMarkBadBufOfst]=gsBadInfo.u16NewBadInBufPtr;
            garBadInfoBuf[cMarkBadVerOfst]=0x01;
            gbUpdBadInfoF=1;
        }

        gsBadInfo.uEraseFailQueCnt--;
        uLoop1++;
    }
}    /* markEraseFailBlock */

BYTE chkSameEccFailBlkInBadInfo(WORD u16FBlk, BYTE uPlaneAddr, BYTE uType)
{
    WORD u16Lp=0;
    WORD u16BadInfoBufFBlk=0xFFFF;
    BYTE uRtVal=1;
    BYTE uTLCRdEccbad=0, uS2TPWRbad=0;

    for(u16Lp=1; u16Lp<gsBadInfo.u16NewBadInBufPtr; u16Lp++)
    {
        u16BadInfoBufFBlk=garBadInfoBuf[(u16Lp*cMarkBadSize)]|(garBadInfoBuf[(u16Lp*cMarkBadSize)+1]<<8);

        // Check the Block number & plane bit is the same
        if((u16BadInfoBufFBlk==u16FBlk)&&((garBadInfoBuf[(u16Lp*cMarkBadSize)+0x3]>>4)==uPlaneAddr))
        {
            if(garBadInfoBuf[(u16Lp*cMarkBadSize)+0x7]==cS2TPWRFailID)
            {
                uS2TPWRbad=1;
            }
            else
            {
                uRtVal=0;
            }

            if(uType&&(garBadInfoBuf[(u16Lp*cMarkBadSize)+0x7]==cTLCRdEccFailID))
            {
                uTLCRdEccbad=1;
            }
        }
    }

    if(uType&&(!uTLCRdEccbad)&&uS2TPWRbad)
    {
        uRtVal=1;
    }

    return uRtVal;
}    /* chkSameEccFailBlkInBadInfo */

void markRdEccFailBlock()
{
    BYTE uLoop1;
    WORD u16TempBlkAddr;
    ADDRINFO usTmpAddrInfo;

    uLoop1=0;

    while(gsBadInfo.uRdEccFailQueCnt)
    {
        if(((!mChkBadBitTab(gsBadInfo.uarEccFailQue[uLoop1].u16Fblock))&&
            (chkSameEccFailBlkInBadInfo(gsBadInfo.uarEccFailQue[uLoop1].u16Fblock, (gsBadInfo.uarEccFailQue[uLoop1].uPlaneAddr&0x0F), 0)))
           ||((gsBadInfo.uarEccFailQue[uLoop1].uFailID&cMarkBadID_Filter)==cProgFailHighID)
           ||((chkSameEccFailBlkInBadInfo(gsBadInfo.uarEccFailQue[uLoop1].u16Fblock, (gsBadInfo.uarEccFailQue[uLoop1].uPlaneAddr&0x0F),
                                          1))&&(gsBadInfo.uarEccFailQue[uLoop1].uFailID==cTLCRdEccFailID)))    //
                                                                                                               // leoo
        {
            if(gsBadInfo.u16NewBadInBufPtr<(cBadInfoRamSize/cMarkBadSize))
            {
                usTmpAddrInfo.u16FBlock=gsBadInfo.uarEccFailQue[uLoop1].u16Fblock;
                usTmpAddrInfo.uCh=gsBadInfo.uarEccFailQue[uLoop1].uCh;
                usTmpAddrInfo.uIntlvAddr=gsBadInfo.uarEccFailQue[uLoop1].uIntlvAddr;
                assignStruCeNDie(&usTmpAddrInfo, usTmpAddrInfo.uIntlvAddr);
                usTmpAddrInfo.uPlaneAddr=gsBadInfo.uarEccFailQue[uLoop1].uPlaneAddr;
                garBadInfoBuf[(gsBadInfo.u16NewBadInBufPtr*cMarkBadSize)+0]=gsBadInfo.uarEccFailQue[uLoop1].u16Fblock;
                garBadInfoBuf[(gsBadInfo.u16NewBadInBufPtr*cMarkBadSize)+1]=gsBadInfo.uarEccFailQue[uLoop1].u16Fblock>>8;
                garBadInfoBuf[(gsBadInfo.u16NewBadInBufPtr*cMarkBadSize)+2]=gsBadInfo.uarEccFailQue[uLoop1].u16Fpage;
                garBadInfoBuf[(gsBadInfo.u16NewBadInBufPtr*
                               cMarkBadSize)+
                              3]=((gsBadInfo.uarEccFailQue[uLoop1].u16Fpage>>8)&0x0F)|((gsBadInfo.uarEccFailQue[uLoop1].uPlaneAddr&0x0F)<<4);
                garBadInfoBuf[(gsBadInfo.u16NewBadInBufPtr*cMarkBadSize)+4]=gsBadInfo.uarEccFailQue[uLoop1].u16EraseCnt;
                garBadInfoBuf[(gsBadInfo.u16NewBadInBufPtr*cMarkBadSize)+5]=gsBadInfo.uarEccFailQue[uLoop1].u16EraseCnt>>8;
                garBadInfoBuf[(gsBadInfo.u16NewBadInBufPtr*
                               cMarkBadSize)+6]=(gsBadInfo.uarEccFailQue[uLoop1].uCh<<4)|(gsBadInfo.uarEccFailQue[uLoop1].uIntlvAddr&0x0F);
                garBadInfoBuf[(gsBadInfo.u16NewBadInBufPtr*cMarkBadSize)+7]=gsBadInfo.uarEccFailQue[uLoop1].uFailID;

                u16TempBlkAddr=getDiffAddr(usTmpAddrInfo.u16FBlock, usTmpAddrInfo.uCh, usTmpAddrInfo.uIntlvAddr, usTmpAddrInfo.uPlaneAddr);
                garBadInfoBuf[(gsBadInfo.u16NewBadInBufPtr*cMarkBadSize)+0x8]=u16TempBlkAddr;
                garBadInfoBuf[(gsBadInfo.u16NewBadInBufPtr*cMarkBadSize)+0x9]=u16TempBlkAddr>>8;
                garBadInfoBuf[(gsBadInfo.u16NewBadInBufPtr*cMarkBadSize)+0xA]=gsBadInfo.uarEccFailQue[uLoop1].uRaidDecFail;
                garBadInfoBuf[(gsBadInfo.u16NewBadInBufPtr*cMarkBadSize)+0xB]=0;

                garBadInfoBuf[(gsBadInfo.u16NewBadInBufPtr*cMarkBadSize)+0xC]=garChMapTable[usTmpAddrInfo.uCh];    // Physical Ch bit
                garBadInfoBuf[(gsBadInfo.u16NewBadInBufPtr*cMarkBadSize)+0xD]=garCeMapTable[usTmpAddrInfo.uCe];    // Physical CE bit
                garBadInfoBuf[(gsBadInfo.u16NewBadInBufPtr*cMarkBadSize)+0xE]=(usTmpAddrInfo.uDieAddr<<4)|(0x1<<usTmpAddrInfo.uPlaneAddr);
                garBadInfoBuf[(gsBadInfo.u16NewBadInBufPtr*cMarkBadSize)+0xF]=gsBadInfo.uarEccFailQue[uLoop1].uTemperture;    // temperture

                gsBadInfo.u16NewBadInBufPtr++;
            }

            if((gsBadInfo.uarEccFailQue[uLoop1].uFailID&cMarkBadID_Filter)==cProgFailHighID)
            {
                g16TotalProgFailCnt++;
                gsBadInfo.u16ProgFailFblkCnt++;
            }

#if (!_EN_PWR_EccOverThrChk)
            if(gsBadInfo.uarEccFailQue[uLoop1].uFailID!=cTLCRdEccFailID)
#else
            if(gsBadInfo.uarEccFailQue[uLoop1].uFailID!=cS2TPWRFailID)
#endif
            {
                if((gsBadInfo.uarEccFailQue[uLoop1].uFailID&cMarkBadID_Filter)==cProgFailHighID)
                {
                    mSetBadBitTab(gsBadInfo.uarEccFailQue[uLoop1].u16Fblock);
                }

                gsBadInfo.u16TotalNewBadCnt++;
#if _EN_BIWIN    // Biwin
                gsBadInfo.u16TotalSLCEccFailCnt++;
#endif
            }

            gbUpdBadInfoF=1;
        }

        g16arBadInfoBuf[cMarkBadCntOfst]=gsBadInfo.u16TotalNewBadCnt;
        g16arBadInfoBuf[1]=gsBadInfo.u16ProgFailFblkCnt;    // 20181213_KevinGG_01
        g16arBadInfoBuf[2]=gsBadInfo.u16EraseFailFblkCnt;    // 20181213_KevinGG_01
        g16arBadInfoBuf[cMarkBadBufOfst]=gsBadInfo.u16NewBadInBufPtr;
        garBadInfoBuf[cMarkBadVerOfst]=0x01;
        gsBadInfo.uRdEccFailQueCnt--;
        uLoop1++;
    }
}    /* markRdEccFailBlock */

void markBadBlock()
{
    prog1stInvQBootInWpro();

    waitAllChCeBz();

    WORD u16TotalTlcFblkCap;

    do
    {
        if(gsWproInfo.u16arWproIdxPagePtr[cWproBadInfo]==0xFFFF)    // gsBadInfo.u16BadInfoPageFreePtr==0)     //first program
        {
            bopClrRam(c32Tsb0SAddr, cBadInfoBufSctrCnt*512, 0, cClrTsb|cBopWait);
        }
        else
        {
            // loadBadInfoTab();
            readWproPage(cWproBadInfo, c16Tsb0SIdx, 0);
        }

        if(gsBadInfo.uEraseFailQueCnt!=0)
        {
            markEraseFailBlock();
            updateFlashQueInfo();
        }

        // record readEccfailcnt
        if(gsBadInfo.uRdEccFailQueCnt!=0)
        {
            markRdEccFailBlock();
            updateFlashQueInfo();
        }

        // save
        if(gbUpdBadInfoF)
        {
            // progBadInfoTab();
            progWproPage(cWproBadInfo, c16Tsb0SIdx);
            saveIndexBlock();
            gbUpdBadInfoF=0;
        }
    }
    while(gsBadInfo.uRdEccFailQueCnt);

    u16TotalTlcFblkCap=(g32TotalDatSector>>3)/g32VpcPerTlcBlk;
    g16TLCGCSpareCnt_Run=
        (g16TotalFBlock-g16OrgBadBlockCnt-g16LaterBadBlockCnt-gsBadInfo.u16TotalNewBadCnt-g16FirstFBlock-gMinStaticSlcCnt-u16TotalTlcFblkCap)/2;

    if(g16TLCGCSpareCnt_Run>g16TLCGCSpareCnt_Ori)
    {
        g16TLCGCSpareCnt_Run=0;
    }

    g16TlcFullCachebGcThr=u16TotalTlcFblkCap+g16TLCGCSpareCnt_Run;

    mClrBadInfoFlag(cBadInfoChg);    // gsBadInfo.ubBadInfoChg=0;
}    /* markBadBlock */







