







#if (!(_INITDRAM||_GREYBOX))

#include "inc/TypeDef.h"
#include "inc/Option.h"
#include "inc/ProType.h"
#include "inc/NvmeCtrl.h"
#include "inc/GlobVarS.h"
#include "inc/Reg.h"
#include "inc/BitDef.h"
#include "inc/Mac.h"

#if (!_ICE_DEBUG)
#pragma default_function_attributes = @ ".UartCmdApi"
#endif

#if (_EN_CHRONUS_UART_DEBUG)
LWORD uartCmdChecksum(LWORD *upDWStartAddress, LWORD u32DWlength, LWORD u32ACC)
{
    LWORD u32count;

    u32count=0;

    while(u32count<u32DWlength)
    {
        u32ACC=u32ACC+*(upDWStartAddress+u32count);
        u32count++;
    }

    return u32ACC;
}

void uartTxSendReverseLword(LWORD u32data)
{
    LWORD u32reverse=0;
    BYTE uCnt;

    for(uCnt=0; uCnt<4; uCnt++)
    {
        u32reverse=u32reverse<<8;
        u32reverse|=u32data&0xFF;
        u32data=u32data>>8;
    }

    rmUartClrAllInt;

    while(rmUartChkTxFull)
        rmResetWdtTimer;

    rmUartTxLword(u32reverse);

    while(rmUartChkTxBusy)
        rmResetWdtTimer;
}    /* uartTxSendReverseLword */

void sendUartCmdRsp(WORD u16BufSecIdx)
{
    LWORD u32Cnt;
    LWORD u32checksum;
    LWORD *upStartDWOffset;

    uartTxSendReverseLword(0xA5A55A5A);
    uartTxSendReverseLword(g32arUartCQEntryDW[0]);
    uartTxSendReverseLword(g32arUartCQEntryDW[1]);
    uartTxSendReverseLword(g32arUartCQEntryDW[2]);
    uartTxSendReverseLword(g32arUartCQEntryDW[3]);

    upStartDWOffset=(LWORD *)(g32arTsb0[0]+(u16BufSecIdx<<7));
    u32checksum=uartCmdChecksum((LWORD *)&g32arUartCQEntryDW[0], 4, 0);

    if((gpUartCMD->Opcode&cBit1)&&((g32arUartCQEntryDW[3]>>17)==cStatusSuccess))
    {
        u32checksum=uartCmdChecksum(upStartDWOffset, (gpUartCMD->DataSecLength)<<7, u32checksum);
        u32checksum=u32checksum+gpUartCMD->DataSecLength;
        uartTxSendReverseLword(gpUartCMD->DataSecLength);

        for(u32Cnt=0; u32Cnt<(gpUartCMD->DataSecLength)<<7; u32Cnt++)
        {
            uartTxSendReverseLword(*(upStartDWOffset+u32Cnt));
        }
    }
    else
    {
        rmUartTxLword(0);
    }

    uartTxSendReverseLword(u32checksum);
    uartTxSendReverseLword(0x3C3CC3C3);
    mClrUartCMDSOFofst;
    mClrUartCMDEOFofst;
    mClrUartHndShkRdy;
    mClrUartCMDRdy;
    mClrUartRxRdy;
    g32UartCMDofst=0;
    g32OutputUART=1;
}    /* sendUartCmdRsp */

void sendUartCmdAck(BYTE uAck)
{
    LWORD u32arRsp[3];
    BYTE uCnt;

    u32arRsp[0]=0xA5A55A5A;
    u32arRsp[1]=0x0;
    u32arRsp[2]=0x3C3CC3C3;

    if(!uAck)
    {
        u32arRsp[1]=0xFFFFFFFF;
        mClrUartCMDRdy;
        mClrUartHndShkRdy;
    }

    for(uCnt=0; uCnt<3; uCnt++)
    {
        uartTxSendReverseLword(u32arRsp[uCnt]);
    }

    rmUartClrAllInt;
    mClrUartRxRdy;
    mClrUartCMDSOFofst;
    mClrUartCMDEOFofst;
    g32UartCMDofst=0;
    g32UartCMDWaitTime=0;
}    /* sendUartCMDACK */

void chkUartDebugCmd()
{
    LWORD u32SOF, u32EOF, u32Idx;
    LWORD u32LengthOfst;
    LWORD u32checksum;
    BYTE uOpCode;

    u32SOF=0xA5A55A5A;
    u32EOF=0x3C3CC3C3;

    if(mChkUartHndShkRdy)
    {
        if(g32UartCMDWaitTime&&(getRtcCurrentMs()-g32UartCMDWaitTime>5000))
        {
            // 5s timeout since hndshk rdy
            sendUartCmdAck(cFail);
            g32OutputUART=1;
            return;
        }

        for(u32Idx=g32UartCMDSOFofst; u32Idx<mUartDWofst; u32Idx++)
        {
            if(*(gp32UartCMDStartAddress+u32Idx)==u32SOF)
            {
                break;
            }
        }

        if(u32Idx>=mUartDWofst)
        {
            return;
        }

        g32UartCMDSOFofst=u32Idx;
        uOpCode=*(gp32UartCMDStartAddress+g32UartCMDSOFofst+1)&0xFF;

        if(uOpCode&cBit0)
        {
            u32LengthOfst=g32UartCMDSOFofst+17;
            g32UartCMDEOFofst=u32LengthOfst+(*(gp32UartCMDStartAddress+u32LengthOfst)<<7)+2;
        }
        else
        {
            u32LengthOfst=g32UartCMDSOFofst+17;
            g32UartCMDEOFofst=u32LengthOfst+2;
        }

        if((g32UartCMDEOFofst>=mUartDWofst)||(u32EOF!=*(gp32UartCMDStartAddress+g32UartCMDEOFofst)))
        {
            return;
        }

        // check op code validity
        uOpCode=*(gp32UartCMDStartAddress+g32UartCMDSOFofst+1)&0xFF;

        if((uOpCode!=cNvmeCmdVendorDataIn)&&(uOpCode!=cNvmeCmdVendorDataOut)&&(uOpCode!=cNvmeCmdVendorNonData)&&(uOpCode!=cNvmeCmdIdentify)&&
           (uOpCode!=cNvmeCmdGetLogPage))
        {
            sendUartCmdAck(cFail);
            g32OutputUART=1;
            return;
        }

        // validate checksum
        u32checksum=uartCmdChecksum((LWORD *)(gp32UartCMDStartAddress+g32UartCMDSOFofst+1), g32UartCMDEOFofst-g32UartCMDSOFofst-2, 0);

        if(u32checksum!=*(gp32UartCMDStartAddress+g32UartCMDEOFofst-1))
        {
            sendUartCmdAck(cFail);
            g32OutputUART=1;
            return;
        }

        gpUartCMD=(sChronusUartCMD *)(gp32UartCMDStartAddress+g32UartCMDSOFofst);
        g32arUartCQEntryDW[0]=0;
        g32arUartCQEntryDW[1]=0;
        g32arUartCQEntryDW[2]=0;
        g32arUartCQEntryDW[3]=0;
        sendUartCmdAck(cSuccess);
        mSetUartCMDRdy;
    }
    else
    {
        if(mUartDWofst<3)
        {
            g32UartCMDofst=0;
            mClrUartRxRdy;
            return;
        }

        if((g32arUartHndShkCMD[0]!=u32SOF)
           ||(g32arUartHndShkCMD[1]!=0xFFFFFFFF)
           ||(g32arUartHndShkCMD[2]!=u32EOF))
        {
            g32UartCMDofst=0;
            mClrUartRxRdy;
            return;
        }

        g32OutputUART=0;
        mSetUartHndShkRdy;
        bopClrRam((LWORD)gp32UartCMDStartAddress, 0x10000, 0x00000000, cBopWait|cClrTsb);
        sendUartCmdAck(cSuccess);
        g32UartCMDWaitTime=getRtcCurrentMs();
        mClrUartRxRdy;
        mClrUartCMDSOFofst;
        mClrUartCMDEOFofst;
        rmUartClrAllInt;
    }
}    /* chkUartDebugCMD */

#endif/* if (_EN_CHRONUS_UART_DEBUG) */

#if (!_ICE_DEBUG)
#pragma default_function_attributes =
#endif

#endif/* if (!(_INITDRAM||_GREYBOX)) */







