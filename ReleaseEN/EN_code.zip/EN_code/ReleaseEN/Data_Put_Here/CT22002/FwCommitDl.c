







#include "inc/TypeDef.h"
#include "inc/Option.h"
#include "inc/ProType.h"
#include "inc/Reg.h"
#include "inc/NvmeCtrl.h"
#include "inc/table.h"
#include "inc/GlobVar0.h"
#include "inc/GlobVarS.h"
#include "inc/DebugLog.h"
#include "inc/EventLogIDX.h"
#include "inc/EventLogFunctionIDX.h"

void EMSAPKCS1_5(    /*BYTE *inputData,*/ LWORD inputLength, BYTE *outputResult)    // [R1012][Wade]Sync with ROM
{
    BYTE DERlength=19+32;    // DigestInfo + Hash value
    LWORD PaddingString=inputLength-DERlength-3;
    WORD i;

    // 1. Produce a hash value using message from CSS header
    // SHA_Encryption_DMA((BYTE *)(&inputData[0]), 0x80, outputResult, (C_SHA_Start));
    // SHA_Encryption_DMA((BYTE *)(&inputData[0x284]), 380, outputResult, (C_SHA_End));
    // 2. DER (Distinguished Encoding Rules)
    // 3. Generate EM
    // SHA-256 DigestInfo
    outputResult[32]=0x20;
    outputResult[32+1]=0x04;
    outputResult[32+2]=0x00;
    outputResult[32+3]=0x05;
    outputResult[32+4]=0x01;
    outputResult[32+5]=0x02;
    outputResult[32+6]=0x04;
    outputResult[32+7]=0x03;
    outputResult[32+8]=0x65;
    outputResult[32+9]=0x01;
    outputResult[32+10]=0x48;
    outputResult[32+11]=0x86;
    outputResult[32+12]=0x60;
    outputResult[32+13]=0x09;
    outputResult[32+14]=0x06;
    outputResult[32+15]=0x0d;
    outputResult[32+16]=0x30;
    outputResult[32+17]=0x31;
    outputResult[32+18]=0x30;

    outputResult[32+19]=0x00;

    for(i=20; i<(PaddingString+20); i++)
    {
        outputResult[32+i]=0xFF;
    }

    outputResult[32+20+PaddingString]=0x01;
    outputResult[32+20+PaddingString+1]=0x00;
}    /* EMSAPKCS1_5 */

BYTE CompareSignature_EMSAPKCS(BYTE *SHA, BYTE *RSA, WORD Len)    // [R1012][Wade]Sync with ROM
{
    LWORD i;
    BYTE rv=0;

    for(i=0; i<32; i++)    // check hash value
    {
        if(SHA[i]!=RSA[32-1-i])
        {
            rv=1;
        }
    }

    for(i=32; i<Len; i++)    // check EM message
    {
        if(SHA[i]!=RSA[i])
        {
            rv=1;
        }
    }

    return rv;
}    /* CompareSignature_EMSAPKCS */

void activateFwImm(LWORD u32StartTime, BYTE uFwSlot, BYTE uUpdateOpt)
{
    LWORD u32ActivatedTime=0, u32MaxTime=c32BitFF;

    if(gsLightSwitch.usNvmeLs.u16Mtfa)
    {
        u32MaxTime=((gsLightSwitch.usNvmeLs.u16Mtfa)*100);    // 100 ms unit
    }

    // rmSetPp;
    activateIspCore0();
    // rmClrPp;
    u32ActivatedTime=(getRtcCurrentMs()-u32StartTime);

    if(mChkActivateFail)
    {
        resetFwDlFlow(0x13);
        manualCompletion(cStatusInvalidFwImage, 0, cNoRwCmd, 0);
        return;
    }

    if(u32ActivatedTime>u32MaxTime)
    {
        mSetMftaExceed;
        // NLOG_SMI_2(C_LOG_Host, " FW Commit - Activate Timeout,  Time=0x%08X ",u32ActivatedTime>>16,u32ActivatedTime,0);
        // gSecurityErrorCode = C_SecuErr_AdminDLFWTimeOutErr;
        manualCompletion(cStatusFwReqMaxTimeViolation, 0, cNoRwCmd, 0);
        return;
    }

    rmSetPp;    // 20181218_SamHu_01
    NLOG(cLogBuild, FWCOMMITDL_C, 0, " rmSetPp ");
    gsSmart.usStatus.uCurrFwSlot=uFwSlot;
    saveSmartInfo(uUpdateOpt);
    resetFwDlFlow(0x14);
    waitAllChCeBzCore0();
    manualCompletion(cStatusSuccess, 0, cNoRwCmd, 0);

    if(mChkAerFwActivationNoticeEn)
    {
        mSetAerFwActive;
        handleAsyncEvent();
    }

    __disable_irq();
    resetCpuFwCommit(cResetCpuSrst);
}    /* activateFwImm */

void nvmeFwCommit()
{
    LWORD u32StartTime=0, u32PagePtr, u32NsId=rmNvmeNsId;
    WORD u16StatusCode=cStatusSuccess;
    BYTE uFwSlot=rmNvmeFwCommitFwSlot;
    BYTE uCommandFwSlot=rmNvmeFwCommitFwSlot;
    BYTE uAction=rmNvmeFwCommitAction;

    NLOG(cLogHost, FWCOMMITDL_C, 1, "  Firmware Commit: Slot=0x%02X, CA=0x%02X ", (WORD)(uFwSlot<<8|uAction));
#if _ENABLE_ATA_PASSTHROUGH
    if(gbEnATAPassThrough)
    {
        if(rmChkSecurityLock)
        {
            NLOG_SAVE(cLogSecApiBaseFw,
                      FWCOMMITDL_C,
                      1,
                      cSaveIdSecurity,
                      "NVMeFWCommit(), ATA Security Locked, status = 0x%04X. ",
                      gSecurityStatus);
            resetFwDlFlow(0xBB);
            manualCompletion((cStatusDoNotRetry|cStatusCmdSequenceErr), 0, cNoRwCmd, 0);
            return;
        }
    }
#endif

    if(uFwSlot)
    {
        uFwSlot-=1;
    }

    u32StartTime=getRtcCurrentMs();

    // check FW Slot supported.
    // DriveMaster fail 20181025_SamHu_01
    if((u32NsId==0x01)||(u32NsId==cNamespaceAll))
    {
        u16StatusCode=cStatusInvalidField;
    }
    else if(u32NsId!=cNamespaceNotSpecific)
    {
        u16StatusCode=cStatusInvalidNsFormat;
    }
    else if((uFwSlot+1)>cTotalFwSlotNum)
    {
        // DebugLog(C_LOG_Host, 0x4F, 1, uFWSlot, 0, 0, 0, 0);
        // gSecurityErrorCode= cSecuErrAdminDlSlotErr;
        u16StatusCode=cStatusInvalidFwSlot;
    }
    else if(mChkFidReset||(uAction>cImageUpdateActivateImm))
    {
        // pushSysSprBlk(gsFwDlInfo.uSysRsvFwDlImageBlk);
        // rstFwDlInfo(0xBB);
        u16StatusCode=cStatusInvalidFwImage;
    }
    else if((gsFwDlInfo.uRstTag==0xE0)&&(uAction==cImageUpdateActivateImm))    // DriveMaster fail Case 10: FIRMWARE COMMIT w/NSID = 00000000h
                                                                               // and Overlapped Range 20181112_SamHu_01
    {
        u16StatusCode=cStatusOverlappingRange;
    }

    if(u16StatusCode)
    {
        resetFwDlFlow(0x01);
        manualCompletion(u16StatusCode, 0, cNoRwCmd, 0);
        return;
    }

#if _EN_FWCommit_Protect
    if((gJustReturnPass)&&(uAction!=cSpecFwSlotActivateNextRst))
    {
        NLOG(cLogHost, FWCOMMITDL_C, 0, "  FWCommit: ReturnPass ");
        resetFwDlFlow(0xF0);
        manualCompletion(cStatusSuccess, 0, cNoRwCmd, 0);
        return;
    }
#endif

    // already program into Isp block successfully, this is second commit
    if(mChkMftaExceed)
    {
        mClrMftaExceed;

        if(gsSmart.usStatus.uCurrFwSlot!=uFwSlot)
        {
            if((uAction==cImageUpdateActivateNextRst)||(uAction==cSpecFwSlotActivateNextRst))
            {
                gsSmart.usStatus.uNextFwSlot=uFwSlot;
                mSetFwCommitSuccess;
                manualCompletion(cStatusSuccess, 0, cNoRwCmd, 0);
                return;
            }
            else if(uAction==cImageUpdateActivateImm)
            {
                manualCompletion(cStatusSuccess, 0, cNoRwCmd, 0);
                resetFwDlFlow(0x02);
                waitAllChCeBzCore0();    // wait all busy instead of reset by Rom code

                if(mChkAerFwActivationNoticeEn)
                {
                    mSetAerFwActive;
                    handleAsyncEvent();    // Response notice async event before fw active
                }

                gsSmart.usStatus.uCurrFwSlot=uFwSlot;
                gsSmart.usStatus.uSavedFwSlotBitMap|=cbBitTab[uFwSlot];
                saveSmartInfo(cUpdateFrs|cUpdateSlotInfo);

                __disable_irq();
                resetCpuFwCommit(cResetCpuSrst);
            }
        }
    }

    // ========== Activate/Update ===========
    if((uAction==cImageUpdateNotActivate)||(uAction==cImageUpdateActivateNextRst)
       ||(gsFwDlInfo.u32IspCodePerEndOffset&&(uAction==cImageUpdateActivateImm)))
    {
#if ((!_GREYBOX)&&_EN_AUTHENTICATION)
        if((gsFwDlInfo.u32IspCodePerEndOffset==cTotalIspCodeSize)&&gsFwDlInfo.uAuthPass)
#else
        if(gsFwDlInfo.u32IspCodePerEndOffset==cTotalIspCodeSize)
#endif
        {
            swapFwSlotIspCore0((uFwSlot+1));    // The uFwSlot already -1 at beginning for Index mapping
            SaveFWHistory(uCommandFwSlot, uAction);

            if(uAction==cImageUpdateActivateImm)
            {
                gsSmart.usStatus.uSavedFwSlotBitMap|=cbBitTab[uFwSlot];
                activateFwImm(u32StartTime, uFwSlot, cUpdateFrs|cUpdateSlotInfo);
                return;
            }
            else if((uAction==cImageUpdateActivateNextRst)||(gsSmart.usStatus.uCurrFwSlot==uFwSlot))
            {
                mSetCacheInfoSpf(cFwCommit);
                progCacheInfoTab();
            }

            if(uAction==cImageUpdateActivateNextRst)
            {
                gsSmart.usStatus.uNextFwSlot=uFwSlot;
                mSetFwCommitSuccess;
            }
            else
            {
                if(!mChkCacheInfoSpf(cFwCommit))
                {
                    resetFwDlFlow(0x03);
                }
            }

            gsSmart.usStatus.uSavedFwSlotBitMap|=cbBitTab[uFwSlot];
            saveSmartInfo(cUpdateFrs);
            manualCompletion(cStatusSuccess, 0, cNoRwCmd, 0);
            return;
        }
        else
        {
            u16StatusCode=cStatusInvalidFwImage;
        }
    }
    else if((uAction==cSpecFwSlotActivateNextRst)||
            ((!gsFwDlInfo.u32IspCodePerEndOffset)&&(uAction==cImageUpdateActivateImm)))
    {
        // if(uFwSlot!=gsSmart.usStatus.uCurrFwSlot)  //May have some flow mode0->mode2 that operate with same fw slot
        {
            if(gsSmart.usStatus.uSavedFwSlotBitMap&cbBitTab[uFwSlot])
            {
                // Retore Fid blk Isp contnent from specific fwslot in Isp blk
                resetFwDlFlow(0x04);

                if(!mChkFidUnderProcess    /*(gsFwDlInfo.uFidStatus&cFidUnderProcess)*/)
                {
                    progFwDlTempIspblockCore0(c16Tsb0SIdx);
                }

                u32PagePtr=(cTotalPlaneOfIsp*uFwSlot);

                while(gsFwDlInfo.u32IspCodePerEndOffset<cTotalIspCodeSize)
                {
                    if(loadIspPageCore0(u32PagePtr, cSysBlockIsp))
                    {
                        resetFwDlFlow(0x05);
                        manualCompletion(cStatusInvalidFwImage, 0, cNoRwCmd, 0);
                        return;
                    }
                    else
                    {
                        progFwDlTempIspblockCore0(c16Tsb0SIdx);
                        gsFwDlInfo.u32IspCodePerEndOffset+=gSectorPerPlaneH;
                        u32PagePtr++;
                    }
                }

                rmResetBufFlg;

                if(gsFwDlInfo.u32IspCodePerEndOffset==cTotalIspCodeSize)
                {
                    progFwDlTempIspblockCore0(c16Tsb0SIdx);
                }

                SaveFWHistory(uCommandFwSlot, uAction);

                // Activate
                if(uAction==cImageUpdateActivateImm)
                {
                    activateFwImm(u32StartTime, uFwSlot, cUpdateSlotInfo);
                    return;
                }
                else
                {
                    mSetCacheInfoSpf(cFwCommit);
                    progCacheInfoTab();
                    mSetFwCommitSuccess;
                    gsSmart.usStatus.uNextFwSlot=uFwSlot;
                    saveSmartInfo(cUpdateFrs);
                    manualCompletion(cStatusSuccess, 0, cNoRwCmd, 0);
                    return;
                }
            }
            else
            {
                u16StatusCode=cStatusInvalidFwImage;
            }
        }
    }
    else
    {
        u16StatusCode=cStatusInvalidFwImage;
    }

    resetFwDlFlow(0x06);
    manualCompletion(u16StatusCode, 0, cNoRwCmd, 0);
}    /* nvmeFwCommit */

void nvmeFwImageDl()
{
    // LIGHTSWITCH *upLightSwitch=(void *)cTsb0Addr;
    LWORD u32BufOffset, u32BufDwOffset, u32XfrDwCnt, u32XfrCnt, u32NsId=rmNvmeNsId;
    WORD u16BufPtr=0, u16SaveOffset=0, u16StatusCode=cStatusSuccess;
    BYTE uarFwVersion[8];
    BYTE uCount;
    LWORD u32IspCodePerEndDWOffset;
    BYTE uHwPrdIdx;
    BYTE uOffsetIdx;

#if ((!_GREYBOX)&&_EN_AUTHENTICATION)
    BYTE uCnt=0;
    // BYTE uHash[32], uTempHashOffset[32];
    BYTE *upHash=(BYTE *)cTrustedIfSendAddr;    // 32byte
    BYTE *upVerifyResult=(BYTE *)(cTrustedIfSendAddr+512);    // 256byte
    // BYTE *upTempIdx=(BYTE *)(cTrustedIfSendAddr+1024); // 256byte
#endif

#if _ENABLE_ATA_PASSTHROUGH
    if(gbEnATAPassThrough)
    {
        if(rmChkSecurityLock)
        {
            NLOG_SAVE(cLogSecApiBaseFw,
                      FWCOMMITDL_C,
                      1,
                      cSaveIdSecurity,
                      "NVMeFWImageDL(), ATA Security Locked, status = 0x%04X.",
                      gSecurityStatus);
            resetFwDlFlow(0xBB);
            manualCompletion((cStatusDoNotRetry|cStatusCmdSequenceErr), 0, cNoRwCmd, 0);
            return;
        }
    }
#endif

    if(mChkFwCommitSuccess)
    {
        gsSmart.usStatus.uNextFwSlot=cNoNextActiveFirmwareSlot;
        mClrFwCommitSuccess;
        resetFwDlFlow(0x07);
    }

    prog1stInvQBootInWpro();

    if(gsRdlinkInfo.ubSaveCacheInfo)
    {
        progCacheInfoTab();
    }

    u32XfrDwCnt=rmNvmeFwImageDlNumDw;
    u32XfrCnt=((u32XfrDwCnt+127)>>7);    // Block Count
    u32BufDwOffset=rmNvmeFwImageDlOffset;
    u32BufOffset=((u32BufDwOffset+127)>>7);    // Buffer Offset
    NLOG(cLogHost,
         FWCOMMITDL_C,
         4,
         "  Firmware Image Download: NUMD=0x%08X, Offset=0x%08X ",
         u32XfrDwCnt>>16,
         u32XfrDwCnt,
         u32BufDwOffset>>16,
         u32BufDwOffset);

    gsFwDlInfo.uFidStatus&=(~cMftaExceed);    // has a expect new FW // for Intel FW Commit-coby

// DriveMaster fail Case 09: FIRMWARE DOWNLOAD w/NSID = 00000000h and Overlapped Range 20181112_SamHu_01
    u32IspCodePerEndDWOffset=(gsFwDlInfo.u32IspCodePerEndOffset<<7);

    if((u32BufDwOffset<u32IspCodePerEndDWOffset)&&u32BufDwOffset)
    {
        // range overlap
        resetFwDlFlow(0xE0);    // 20190225_SamHu
        manualCompletion(cStatusOverlappingRange, 0, cNoRwCmd, 0);
        return;
    }

// DriveMaster fail 20181025_SamHu_01
    if((!u32XfrDwCnt)||mod(u32XfrDwCnt, 128)||mod(u32BufDwOffset, 128)||rmNvmeSgl||(u32NsId==0x01)||(u32NsId==cNamespaceAll))    // Not support
                                                                                                                                 // dw xfer
    // now
    {
        u16StatusCode=cStatusInvalidField;
    }
    else if(u32NsId!=cNamespaceNotSpecific)
    {
        u16StatusCode=cStatusInvalidNsFormat;
    }
    else if(validatePrp(cValidPrpFwImageDl))
    {
        NLOG(cLogAdmin, FWCOMMITDL_C, 0, " Firmware Download InvalidPrpOffset ");
        u16StatusCode=cStatusInvalidPrpOffset;
    }

    if(u16StatusCode)
    {
        resetFwDlFlow(0x08);
        manualCompletion(u16StatusCode, 0x0, cNoRwCmd, 0x0);
        return;
    }

    if((!u32BufDwOffset)&&(u32XfrCnt==(cTotalIspCodeSize+cSignatureSize)))
    {
        // download without offsets
        resetFwDlFlow(0x09);
    }
    else    // download offsets
    {
        if(mod(u32XfrCnt, gSectorPerPlaneH)    /*&&(gsFwDlInfo.u32IspCodePerEndOffset!=u16TotalIspCodeSizeSec)*/)
        {
            if(gsFwDlInfo.u32IspCodePerEndOffset==(cTotalIspCodeSize+cSignatureSize))
            {}
            else
            {
                resetFwDlFlow(0x0A);
                manualCompletion(cStatusInvalidField, 0x0, cNoRwCmd, 0x0);
                return;
            }
        }

        if((!u32BufDwOffset)&&(!gsFwDlInfo.u32IspCodePerEndOffset))
        {
            resetFwDlFlow(0x0B);
        }
        else if((u32BufOffset==gsFwDlInfo.u32IspCodePerEndOffset)&&(u32BufOffset<=(cTotalIspCodeSize+cSignatureSize)))
        {
            // Normal case
        }
        else if(u32BufOffset<gsFwDlInfo.u32IspCodePerEndOffset)
        {
            // range overlap
            resetFwDlFlow(0x0C);
            manualCompletion(cStatusOverlappingRange, 0, cNoRwCmd, 0);
            return;
        }
        else
        {
            // Issued offset larger the current offset case, don't support not in sequence download now
            resetFwDlFlow(0x0D);
            manualCompletion(cStatusInvalidField, 0, cNoRwCmd, 0);
            return;
        }
    }

    // =========Save==========
    rmResetBufFlg;
    rmResetOccupyFlg;

    // First time program, move Infoblock data before gISPCore1StartPage to temp block
    if(!(gsFwDlInfo.uFidStatus&cFidUnderProcess))
    {
        progFwDlTempIspblockCore0(c16Tsb0SIdx);
    }

    // trigNonRWCmd(c16Tsb0SIdx, u32XfrCnt, cTsb0, cNvmeWrite, cManualCq);
    if(u32XfrCnt>cTrustedRwBufferIdxSize)    // Data must be limited within 64KB if FW support FW auth.
    {
        uHwPrdIdx=trigNonRWCmd(cTsb0StartBufIdx, cTrustedRwBufferIdxSize, cTsb0, cNvmeWrite, cManualCq|cMultiPrdForFd);
    }
    else
    {
        uHwPrdIdx=trigNonRWCmd(cTsb0StartBufIdx, u32XfrCnt, cTsb0, cNvmeWrite, cManualCq);
    }

    if(gDLFWFail)
    {
        resetFwDlFlow(0xE1);
        manualCompletion(cStatusInvalidFwImage, 0, cNoRwCmd, 0);
        return;
    }

    while(u16SaveOffset<u32XfrCnt)
    {
        if(mChkHandlePcieErrF)
        {
            rmResetBufFlg;
            resetFwDlFlow(0x0E);
            manualCompletion(cStatusDataXfrErr, 0x0, cNoRwCmd, 0x0);
            return;
        }

        if(!gsFwDlInfo.u32IspCodePerEndOffset)
        {
#if ((!_GREYBOX)&&_EN_AUTHENTICATION)
            // if(gsLightSwitch.usSecLs.uHpAuthen&cBit0)
            {
                loadISPCodeCore0(cSecTsbBank, 3);
                SHA_Encryption_DMA((BYTE *)&garTsb0[u16BufPtr], gSectorPerPlaneH*512, &upHash[0], cShaStart);
                g32BaseFwShaTotalSize=g32SHATotalSize;    // 20181226_SamHu_01 sync Dennis code for R/W command insert DownloadFW
            }
#endif
            // ========prog to temp block======
            progFwDlTempIspblockCore0(u16BufPtr);

            // u16BufPtr=addWriteBufPtr(u16BufPtr, gSectorPerPlaneH);
            u16BufPtr=((u16BufPtr+gSectorPerPlaneH)&(cTrustedRwBufferIdxSize-1));
            u16SaveOffset+=gSectorPerPlaneH;
            gsFwDlInfo.u32IspCodePerEndOffset+=gSectorPerPlaneH;
        }
        else if(gsFwDlInfo.u32IspCodePerEndOffset<cTotalIspCodeSize)
        {
#if ((!_GREYBOX)&&_EN_AUTHENTICATION)
            // if(gsLightSwitch.usSecLs.uHpAuthen&cBit0)
            {
                loadISPCodeCore0(cSecTsbBank, 3);
                g32SHATotalSize=g32BaseFwShaTotalSize;    // 20181226_SamHu_01 sync Dennis code for R/W command insert DownloadFW
                SHA_Encryption_DMA((BYTE *)&garTsb0[u16BufPtr], gSectorPerPlaneH*512, &upHash[0], cShaMiddle);
                g32BaseFwShaTotalSize=g32SHATotalSize;    // 20181226_SamHu_01 sync Dennis code for R/W command insert DownloadFW
            }
#endif

            // 20181205_SamHu_01
            if(gsFwDlInfo.u32IspCodePerEndOffset==cSSDBinInfoSecAddr)    // 16K base
            {
                if(u32XfrCnt>cTrustedRwBufferIdxSize)    // Data must be limited within 64KB if FW support FW auth.
                {
                    uOffsetIdx=Div(cTrustedRwBufferIdxSize, gSectorPerPlaneH)-1;
                }
                else
                {
                    uOffsetIdx=Div(u32XfrCnt, gSectorPerPlaneH)-1;
                }

                if(garTsb0[(uOffsetIdx*0x20)+31][0x18A]!=cbRevision1[2])
                {
                    NLOG(cLogHost, FWCOMMITDL_C, 1, "  Nand is different : 0x%02X - 0x%02X",
                         (WORD)(garTsb0[(uOffsetIdx*0x20)+31][0x18A]<<8|cbRevision1[2]));

                    if(u32BufDwOffset||((!u32BufDwOffset)&&(u32XfrCnt==(cTotalIspCodeSize+cSignatureSize))))
                    {
                        resetFwDlFlow(0xE8);
                        manualCompletion(cStatusInvalidFwImage, 0, cNoRwCmd, 0);
                        return;
                    }
                    else
                    {
                        gDLFWFail=1;
                        NLOG(cLogHost, FWCOMMITDL_C, 0, "  return error at next command ");
                    }
                }
                else
                {
#if _EN_FWCommit_Protect    // 20190308_SamHu_01
// 1. Check OEM & External FW
                    if((garTsb0[(uOffsetIdx*0x20)+31][0x18B]=='R')&&(garTsb0[(uOffsetIdx*0x20)+31][0x18C]=='D'))    // RD FW
                    {
                        NLOG(cLogHost, FWCOMMITDL_C, 0, "  FWDL Step1: RD FW ");
                    }
                    else if((garTsb0[(uOffsetIdx*0x20)+31][0x190]==cbRevision2[0])&&
                            (garTsb0[(uOffsetIdx*0x20)+31][0x191]==cbRevision2[1])&&
                            (garTsb0[(uOffsetIdx*0x20)+31][0x193]==cbRevision2[3])&&
                            (garTsb0[(uOffsetIdx*0x20)+31][0x194]==cbRevision2[4])&&
                            (garTsb0[(uOffsetIdx*0x20)+31][0x195]==cbRevision2[5])&&
                            (garTsb0[(uOffsetIdx*0x20)+31][0x196]==cbRevision2[6])&&
                            (garTsb0[(uOffsetIdx*0x20)+31][0x197]==cbRevision2[7]))
                    {
                        NLOG(cLogHost, FWCOMMITDL_C, 0, "  FWDL Step1: Same EXT FW ");

// 2. Check Internal FW
                        if(garTsb0[(uOffsetIdx*0x20)+31][0x18D]==cbRevision1[5])
                        {
                            if((garTsb0[(uOffsetIdx*0x20)+31][0x18E]<cbRevision1[6])||
                               ((garTsb0[(uOffsetIdx*0x20)+31][0x18E]==cbRevision1[6])&&(garTsb0[(uOffsetIdx*0x20)+31][0x15F]<cbHeader[15])))
                            {
                                gJustReturnPass=1;
                                NLOG(cLogHost, FWCOMMITDL_C, 1, "  FWDL Step2: IFW2 is old :0x%02X-0x%02X ",
                                     (WORD)(garTsb0[(uOffsetIdx*0x20)+31][0x18E]<<8|garTsb0[(uOffsetIdx*0x20)+31][0x15F]));
                                NLOG(cLogHost, FWCOMMITDL_C, 0, "  FWDL Step3: ReturnPass ");
                            }
                        }
                    }
#endif/* if _EN_FWCommit_Protect */
                }

                for(uCount=0; uCount<8; uCount++)
                {
                    uarFwVersion[uCount]=garTsb0[(uOffsetIdx*0x20)+31][0x190+uCount];
                }

                copyCcmVal((BYTE *)gsSmart.usStatus.uarSaveIspRev, (BYTE *)uarFwVersion, 8);
            }

            // keep or update lightswitch
#if 0
            if(gsFwDlInfo.u32IspCodePerEndOffset==cLsCodeAddr)
            {
                // gkeepSerialModelNumFlag=1;

                upLightSwitch=(void *)(&garTsb0[0]+u16BufPtr);
                // keep model name/serial number; update fw version.
                bopCopyRam((LWORD)&upLightSwitch->usCidHeader.uarNameStr2[0],
                           (LWORD)&gsLightSwitch.usCidHeader.uarNameStr2[0],
                           (0x180-0xB0),
                           cCopyDccm2Tsb|cBopWait);

                // For Update Log Page
                bopCopyRam((LWORD)&gsSmart.usStatus.uarSaveIspRev, (LWORD)&upLightSwitch->usCidHeader.uarIspRev, 8, cCopyTsb2Dccm|cBopWait);

                // [D.H] SecAPI_HandleFWupdate

#if ((!_GREYBOX)&&_EN_AUTHENTICATION)
                // if(gsLightSwitch.usSecLs.uHpAuthen&cBit0)
                // {
                //    //backup hash offset
                //    for(uCnt=0;uCnt<32;uCnt++)
                //    {
                //        gHashOffsetBk[uCnt]=gsLightSwitch.uarHashOffSetTable[uCnt];
                //    }
                //
                //    //clear HashOffSetTable
                //    bopClrRam((LWORD)&gsLightSwitch.uarHashOffSetTable[0], 256, 0x00000000, cBopWait|cClrCore0Dccm);
                // }
#endif

                if(upLightSwitch->usThermalLs.uThermalCtrl&cEnKeepLs)    // keep lightswitch
                {
                    // gkeepSerialModelNumFlag=1;

                    // backup hash offset
                    // for(uCnt=0;uCnt<32;uCnt++)
                    // {
                    //    gHashOffsetBk[uCnt]=gsLightSwitch.uarHashOffSetTable[uCnt];
                    // }
                    // clear HashOffSetTable
                    // bopClrRam((LWORD)&gsLightSwitch.uarHashOffSetTable[0], 256, 0x00000000, cBopWait|cClrCore0Dccm);

                    // copy lightswitch to Tsb, except model name/serial number
                    bopCopyRam((LWORD)&upLightSwitch->usLegacy.uarOpt0[0],
                               (LWORD)&gsLightSwitch.usLegacy.uarOpt0[0],
                               (4096-384),
                               cCopyDccm2Tsb|cBopWait);
                }
            }
#endif/* if 0 */

            // ========prog to temp block======
            progFwDlTempIspblockCore0(u16BufPtr);

            // u16BufPtr=addWriteBufPtr(u16BufPtr, gSectorPerPlaneH);
            u16BufPtr=((u16BufPtr+gSectorPerPlaneH)&(cTrustedRwBufferIdxSize-1));
            u16SaveOffset+=gSectorPerPlaneH;
            gsFwDlInfo.u32IspCodePerEndOffset+=gSectorPerPlaneH;
        }
        else
        {
            // gkeepSerialModelNumFlag=0;

#if ((!_GREYBOX)&&_EN_AUTHENTICATION)
            loadISPCodeCore0(cSecTsbBank, 3);
            g32SHATotalSize=g32BaseFwShaTotalSize;    // 20181226_SamHu_01 sync Dennis code for R/W command insert DownloadFW
            SHA_Encryption_DMA((BYTE *)&garTsb0[u16BufPtr], 0, &upHash[0], cShaEnd);

            if(gsLightSwitch.usSecLs.uHpAuthen&cBit0)
            {
                // SHA_Encryption_DMA((BYTE *)&garTsb0[u16BufPtr], 0, &uHash[0], cShaEnd);

                ////if(gsLightSwitch.usThermalLs.uThermalCtrl&cEnKeepLs)  //keep lightswitch
                // {
                //    //restore hash offset
                //    for(uCnt=0;uCnt<32;uCnt++)
                //    {
                //        gsLightSwitch.uarHashOffSetTable[uCnt]=gHashOffsetBk[uCnt];
                //    }
                // }

                // check Hash offset table exist
                while(uCnt<32)
                {
                    if(    /*gsLightSwitch.uarHashOffSetTable[uCnt]*/ gHashOffsetBk[uCnt]==0)
                    {
                        gsFwDlInfo.uHashCmpCnt++;
                    }

                    uCnt++;
                }

                if(gsFwDlInfo.uHashCmpCnt>1)
                {
                    resetFwDlFlow(0x0F);
                    manualCompletion(cStatusInvalidFwImage, 0, cNoRwCmd, 0);
                    return;
                }

                // compare download image Hash value with fw count Hash value
                for(uCnt=0; uCnt<32; uCnt++)
                {
                    if(garTsb0[0][    /*gsLightSwitch.uarHashOffSetTable[uCnt]*/ gHashOffsetBk[uCnt]]!=upHash[uCnt])
                    {
                        resetFwDlFlow(0x10);
                        manualCompletion(cStatusInvalidFwImage, 0, cNoRwCmd, 0);
                        return;
                    }
                }
            }
            else
            {
                reverseArray((BYTE *)&garTsb0[0], 256);    // signature size 256 Byte, 2263XT signature must be inverse for RSA HW engine.
                rsa_ssa_verify((BYTE *)&cbSignFwPublicKey[0], upVerifyResult, (BYTE *)&garTsb0[0]);
                EMSAPKCS1_5(256, (BYTE *)upHash);
#if 1
                if(CompareSignature_EMSAPKCS((BYTE *)upHash, upVerifyResult, 256))
#else    // [D.H] test code, use sha256
                if(!compareByte(&garTsb0[0], &uHash[0], cShaOutputSize))
#endif
                {
                    rmResetBufFlg;

                    if(rmChkDpsDppFifoNotEmpty)
                    {
                        releaseFreeHwPrd2();
                    }

                    resetFwDlFlow(0x11);
                    manualCompletion(cStatusInvalidFwImage, 0, cNoRwCmd, 0);
                    return;
                }
                else
                {
                    gsFwDlInfo.uAuthPass=1;
                }
            }
#endif/* if ((!_GREYBOX)&&_EN_AUTHENTICATION) */
            // ========prog to temp block======
            u16SaveOffset+=gSectorPerPlaneH;    // break while(u16SaveOffset<u32XfrCnt)
        }

        if((((u16SaveOffset%cTrustedRwBufferIdxSize)==0)    /*&&(u32XfrCnt-u16SaveOffset)<cTrustedRwBufferIdxSize*/)&&
           (!(r32NvmePrd[uHwPrdIdx][0]&cLastPrd)))
        {
            rmResetBufFlg;

            // if((u16SaveOffset-gSectorPerPlaneH+cTrustedRwBufferIdxSize)>=u32XfrCnt)
            // {
            //    r32NvmePrd[uHwPrdIdx][0]|=cLastPrd;
            // }
            //     sectors
            //     128           128                     256 - else
            //                                           160 - if
            //                                           80 - if
            //                                           128 - not enter
            if((u16SaveOffset+cTrustedRwBufferIdxSize)>=u32XfrCnt)
            {
                r32NvmePrd[uHwPrdIdx][0]|=cLastPrd;
                r32NvmePrd[uHwPrdIdx][1]=cTsb0StartBufIdx;    // TSB Address
                r32NvmePrd[uHwPrdIdx][5]=u32XfrCnt-u16SaveOffset;
            }
            else
            {
                r32NvmePrd[uHwPrdIdx][1]=cTsb0StartBufIdx;    // TSB Address
                r32NvmePrd[uHwPrdIdx][5]=cTrustedRwBufferIdxSize;
            }

            rmClrDpp(rmCurrentEngine);    // Once clear Dpp will trig next data xfer
            rmPopNextValue;
            waitHostDone();
        }
    }    // --> End Of while (u16SaveOffset<u32XfrCnt)

    rmResetBufFlg;

    if(rmChkDpsDppFifoNotEmpty)
    {
        releaseFreeHwPrd2();
    }

    if(gsFwDlInfo.u32IspCodePerEndOffset==cTotalIspCodeSize)
    {
        progFwDlTempIspblockCore0(c16Tsb0SIdx);
    }

    if(gsFwDlInfo.u32IspCodePerEndOffset>cTotalIspCodeSize)    // oversize=> abort
    {
        resetFwDlFlow(0x12);
        manualCompletion(cStatusOverlappingRange, 0, cNoRwCmd, 0);
        return;
    }
    else
    {
        manualCompletion(cStatusSuccess, 0, cNoRwCmd, 0);
    }
}    /* nvmeFwImageDl */







