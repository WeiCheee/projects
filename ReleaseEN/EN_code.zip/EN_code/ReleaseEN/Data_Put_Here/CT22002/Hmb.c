







#include "inc/GlobVar0.h"
#include "inc/GlobVarT.h"
#include "inc/NvmeCtrl.h"
#include "inc/Mac.h"
#include "inc/ProType.h"
#if _EN_FW_DEBUG_UART
#include "inc/DebugLog.h"
#include "inc/EventLogIDX.h"
#include "inc/EventLogFunctionIDX.h"
#endif

void readHmbH2fTab(WORD u16BufIdx, WORD u16Hblock, WORD u16Sgmt, BYTE uSgmtIdx, BYTE uCnt)
{
    HMBPRDQ *upHmbPrdQ;
    WORD u16HmbIdx=mGetHmbLink(u16Hblock);

    invalidateDCache();
    upHmbPrdQ=&gsHmbInfo.uarHmbPrdQ[gsHmbInfo.uHmbHwPrdHead];

    upHmbPrdQ->u16BufPtr=u16BufIdx;
    upHmbPrdQ->u16HmbIdx=u16HmbIdx;
    upHmbPrdQ->uOpCode=cHmbRead2kTab;
    upHmbPrdQ->uSgmtIdx=uSgmtIdx;
    upHmbPrdQ->u32HmbAddrLow=((LWORD)u16HmbIdx<<gHmbH2FTableShift)+(u16Sgmt<<11);

#if _EN_PATCH_SM2263AA

    if(uCnt)
    {
        upHmbPrdQ->u32SctrCnt=uCnt*cSctrPerRH2fTab;
        trigHmbDataXfer(upHmbPrdQ, cHmbTsbPath|cHmbReadDir|cHmbBufflagChk|cHmbBufflagInv);
    }
    else
    {
        upHmbPrdQ->u32SctrCnt=cSctrPerRH2fTab;
        trigHmbDataXfer(upHmbPrdQ, cHmbTsbPath|cHmbReadDir);    // |cHmbBufflagChk|cHmbBufflagInv);
    }

#else
    upHmbPrdQ->u32SctrCnt=uCnt*cSctrPerRH2fTab;
    trigHmbDataXfer(upHmbPrdQ, cHmbTsbPath|cHmbReadDir);
#endif
}    /* readHmbH2fTab */

void writeHmbH2fTab(WORD u16BufIdx, WORD u16Hblock, WORD u16RwOpt)
{
    HMBPRDQ *upHmbPrdQ;
    volatile LINKINFO *upInsLlInfo;
    WORD u16PrevNodeIdx, u16NextNodeIdx, u16HmbIdx, u16HmbCnt;

    // QWORD u64HmbAddr;

#if _GREYBOX
    outCS(cbTagwriteHmbH2fTab);
#endif

    while(gsHmbInfo.uHmbFreeHwPrdCnt<=1)
        ;

    upInsLlInfo=&gsHmbInfo.usHmbList;

    if(mChkHmbLink(u16Hblock))
    {
        u16HmbIdx=mGetHmbLink(u16Hblock);
#if _ENABLE_HMB_FLUSH

        if(u16RwOpt&cHmbDirtyH2f)
        {
            while(!mChkHmbTabDirty(u16HmbIdx))
                ;
        }
#endif
    }
    else
    {
        u16HmbIdx=gsHmbInfo.u16arFreeHmbQ[gsHmbInfo.u16FreeHmbHead];
        gsHmbInfo.u16FreeHmbHead++;

        if(gsHmbInfo.u16FreeHmbHead>=g16HmbMaxTableNum)
        {
            gsHmbInfo.u16FreeHmbHead-=g16HmbMaxTableNum;
        }

        g16arH2fBackup[u16HmbIdx]=u16Hblock;
        // g16arH2fTabPtr[g16TotalHBlock+u16HmbIdx]=g16arH2fTabPtr[u16Hblock];
        // mSetH2fTabEntry(u16Hblock, c16MaxH2fTabBlkNum, u16HmbIdx);

#if _ENABLE_HMB_FLUSH

        if(u16RwOpt&cHmbDirtyH2f)
        {
            u16PrevNodeIdx=gsHmbInfo.u16HmbLastDirtyPtr;
            gsHmbInfo.u16HmbLastDirtyPtr=u16HmbIdx;
        }
        else
#endif
        {
            u16PrevNodeIdx=upInsLlInfo->u16Head;
        }

        // while((gsHmbInfo.usHmbList.u16Head!=c16Null)&&(gsHmbInfo.uarHmbLink[gsHmbInfo.usHmbList.u16Head].u16Next!=c16Null))
        //    ;

        // while((gsHmbInfo.usHmbList.u16Tail!=c16Null)&&(gsHmbInfo.uarHmbLink[gsHmbInfo.usHmbList.u16Tail].u16Prev!=c16Null))
        //    ;

        mInsNode16(u16PrevNodeIdx, upInsLlInfo, u16NextNodeIdx, gsHmbInfo.uarHmbLink, u16HmbIdx);
        // while((gsHmbInfo.usHmbList.u16Head!=c16Null)&&(gsHmbInfo.uarHmbLink[gsHmbInfo.usHmbList.u16Head].u16Next!=c16Null))
        //    ;

        // while((gsHmbInfo.usHmbList.u16Tail!=c16Null)&&(gsHmbInfo.uarHmbLink[gsHmbInfo.usHmbList.u16Tail].u16Prev!=c16Null))
        //    ;
    }

    // u16NowNodeIdx=gsHmbInfo.uarFreeHmbPrdQ[gsHmbInfo.uFreeHmbPrdHead];
    // gsHmbInfo.uFreeHmbPrdHead=(gsHmbInfo.uFreeHmbPrdHead+1)&(cMaxRH2fTabNum-1);
    upHmbPrdQ=&gsHmbInfo.uarHmbPrdQ[gsHmbInfo.uHmbHwPrdHead];    // u16NowNodeIdx];

#if _EN_RAID_H2F
    upHmbPrdQ->u32SctrCnt=g16H2fTabValidSctrSize;
#else
    upHmbPrdQ->u32SctrCnt=g16H2fTabSctrSize;
#endif
    upHmbPrdQ->u16BufPtr=u16BufIdx;
    upHmbPrdQ->uOpCode=cHmbWriteH2fTab;
    upHmbPrdQ->u16HmbIdx=u16HmbIdx;
    // upHmbPrdQ->u32TrigMo=c32AutoHmbTrigR;
    // u64HmbAddr=(u16HmbIdx<<16);
    upHmbPrdQ->u32HmbAddrLow=(LWORD)u16HmbIdx<<gHmbH2FTableShift;

    // upInsLlInfo=&gsHmbInfo.usHmbPrdList;
    // mInsNode(u16PrevNodeIdx, upInsLlInfo, u16NextNodeIdx, gsHmbInfo.uarHmbPrdLink, u16NowNodeIdx);

    if(!(u16RwOpt&c16Bit1))
    {
        u16BufIdx>>=5;
        u16HmbCnt=(upHmbPrdQ->u32SctrCnt>>5);

        while(u16HmbCnt)
        {
            rmSetBuf32Sts(u16BufIdx, 0xFFFFFFFF);    // 64k alignment
            u16BufIdx++;
            u16HmbCnt--;
        }
    }

    trigHmbDataXfer(upHmbPrdQ, cHmbTsbPath|cHmbBufflagChk|cHmbBufflagInv);
    // g16WriteHMBH2FTable[gWriteHMBIndex]=u16Hblock;
    // gWriteHMBIndex=(gWriteHMBIndex+1)&(cHmbRacingFreeCnt-1);
#if _GREYBOX

    if(gsGbInfo.uGreyBoxItem==cTabHdlH2fOnHmb)
    {
        // outString("+=@", u16Hblock);

        if(*(BYTE *)(c32GreyBoxBuf+u16Hblock))
        {
            gsGbInfo.uResult=cFail;
            outSta(cVFail);
        }
        else
        {
            *(BYTE *)(c32GreyBoxBuf+u16Hblock)=cTrue;
            trigGreyBox(cFalse);
        }
    }
    else if(gsGbInfo.uGreyBoxItem==cUGSDHmbID)
    {
        if((gsHmbInfo.usHmbList.u16Cnt>=(g16HmbMaxTableNum-2))&&(gsGbInfo.uStag==cVsTriggered))
        {
            trigGreyBox(cFalse);
            triggerUGSD(cFalse);
        }
    }
#endif/* if _GREYBOX */
}    /* writeHmbH2fTab */

void readHmbH2fTab2(WORD u16BufIdx, WORD u16Hblock, WORD u16RwOpt)
{
    HMBPRDQ *upHmbPrdQ;
    WORD u16HmbIdx=mGetHmbLink(u16Hblock);

#if (_GREYBOX)

    if((gsGbInfo.uGreyBoxItem==cHmbErrHandle)&&(gsGbInfo.uGreyBoxOpt==cVOpCrc)&&(gsGbInfo.u32BkValue==u16HmbIdx))
    {
        gsGbInfo.uStag=cVsTriggered;
    }
#endif

    invalidateDCache();
    mWaitHmbRelease(1);    // while(gsHmbInfo.uHmbFreeHwPrdCnt<1);

    upHmbPrdQ=&gsHmbInfo.uarHmbPrdQ[gsHmbInfo.uHmbHwPrdHead];

#if _EN_RAID_H2F
    upHmbPrdQ->u32SctrCnt=g16H2fTabValidSctrSize;
#else
    upHmbPrdQ->u32SctrCnt=g16H2fTabSctrSize;
#endif
    upHmbPrdQ->u16BufPtr=u16BufIdx;
    upHmbPrdQ->uOpCode=cHmbReadH2fTab;
    upHmbPrdQ->u16HmbIdx=u16HmbIdx;
    upHmbPrdQ->u32HmbAddrLow=(LWORD)u16HmbIdx<<gHmbH2FTableShift;

    rmHmbPrdDw10=g32arHmbCrc[u16HmbIdx];

    if(u16RwOpt&cSetBufferFlag)
    {
        upHmbPrdQ->uSgmtIdx=cSetBufferFlag;
        trigHmbDataXfer(upHmbPrdQ, cHmbTsbPath|cHmbReadDir|cHmbBufflagChk|cHmbBufflagInv);
    }
    else
    {
        upHmbPrdQ->uSgmtIdx=0;
        trigHmbDataXfer(upHmbPrdQ, cHmbTsbPath|cHmbReadDir);
    }
}    /* readHmbH2fTab2 */

#if _ENABLE_HMB_FLUSH
void writeHmbH2fTabSgmt(WORD u16BufIdx, WORD u16Hblock, WORD u16Sgmt, WORD u16RwOpt)
{
    HMBPRDQ *upHmbPrdQ;
    // WORD u16HmbIdx;
    WORD u16MaskOfs;
    LWORD u32HmbIdx;
    LWORD u32HsgmtOfs=(LWORD)u16Sgmt;

    // QWORD u64HmbAddr;

    while(!mChkHmbLink(u16Hblock))
        ;

    while(gsHmbInfo.uHmbFreeHwPrdCnt<=1)
        ;

    u32HmbIdx=mGetHmbLink(u16Hblock);
#if _ENABLE_HMB_FLUSH

    if(u16RwOpt&cHmbDirtyH2f)
    {
        while(!mChkHmbTabDirty(u32HmbIdx))
            ;
    }
#endif
    upHmbPrdQ=&gsHmbInfo.uarHmbPrdQ[gsHmbInfo.uHmbHwPrdHead];    // u16NowNodeIdx];
    upHmbPrdQ->u32SctrCnt=cSctrPerRH2fTab;
    upHmbPrdQ->u16BufPtr=u16BufIdx;    // c16RH2fTabSIdx+(uSgmtIdx<<2)
    upHmbPrdQ->uOpCode=cHmbWrite2kTab;
    upHmbPrdQ->u16HmbIdx=u32HmbIdx;
    upHmbPrdQ->u32HmbAddrLow=(u32HmbIdx<<gHmbH2FTableShift)+(u32HsgmtOfs<<11);

    // upInsLlInfo=&gsHmbInfo.usHmbPrdList;
    // mInsNode(u16PrevNodeIdx, upInsLlInfo, u16NextNodeIdx, gsHmbInfo.uarHmbPrdLink, u16NowNodeIdx);

    if(!(u16RwOpt&c16Bit1))
    {
        u16MaskOfs=(u16BufIdx&0x1F);
        u16BufIdx>>=5;
        rmSetBuf32Sts(u16BufIdx, 0xF<<u16MaskOfs);    // 2k alignment
    }

    trigHmbDataXfer(upHmbPrdQ, cHmbTsbPath|cHmbBufflagChk|cHmbBufflagInv);    // cHmbBufflagInv
#if _GREYBOX

    if(gsGbInfo.uGreyBoxItem==cTabHdlH2fOnHmb)
    {
        // outString("+=@", u16Hblock);

        if(*(BYTE *)(c32GreyBoxBuf+u16Hblock))
        {
            gsGbInfo.uResult=cFail;
            outSta(cVFail);
        }
        else
        {
            *(BYTE *)(c32GreyBoxBuf+u16Hblock)=cTrue;
            gsGbInfo.uStag=cVsTriggered;
        }
    }
    else if(gsGbInfo.uGreyBoxItem==cUGSDHmbID)
    {
        if((gsHmbInfo.usHmbList.u16Cnt>=(g16HmbMaxTableNum-2))&&(gsGbInfo.uStag==cVsTriggered))
        {
            triggerUGSD(cFalse);
        }
    }
#endif/* if _GREYBOX */
}    /* writeHmbH2fTabSgmt */

#endif/* if _ENABLE_HMB_FLUSH */

void writeHmbGcInfoTab(WORD u16BufIdx, WORD u16WproIdx, WORD u16RwOpt)
{
    HMBPRDQ *upHmbPrdQ;
    WORD u16HmbIdx;
    BYTE uTrigLoop=0;

    mWaitHmbRelease(c32GcInfoTabSctrCnt/c16LoadPartTabStcrCnt);

    if(!(u16RwOpt&c16Bit1))
    {
        WORD u16HmbCnt;
        BYTE uBufIdx;

        uBufIdx=u16BufIdx>>5;
        u16HmbCnt=(c32GcInfoTabSctrCnt>>5);

        while(u16HmbCnt)
        {
            rmSetBuf32Sts(uBufIdx, 0xFFFFFFFF);    // 16k alignment
            uBufIdx++;
            u16HmbCnt--;
        }
    }

    u16HmbIdx=(u16WproIdx-cWproGcDesF2hTab00)*(c32GcInfoTabSctrCnt/c16LoadPartTabStcrCnt);

    while(uTrigLoop<(c32GcInfoTabSctrCnt/c16LoadPartTabStcrCnt))
    {
        upHmbPrdQ=&gsHmbInfo.uarHmbPrdQ[gsHmbInfo.uHmbHwPrdHead];

        upHmbPrdQ->u32SctrCnt=c16LoadPartTabStcrCnt;
        upHmbPrdQ->u16BufPtr=u16BufIdx;
        upHmbPrdQ->uOpCode=cHmbWriteWpro;
        upHmbPrdQ->u16HmbIdx=u16HmbIdx;
        upHmbPrdQ->uSrcIdx=u16WproIdx;
        upHmbPrdQ->u32HmbAddrLow=c32HmbTotalH2fTableSize+(u16HmbIdx*c16LoadPartTabSize);

        trigHmbDataXfer(upHmbPrdQ, cHmbTsbPath|cHmbBufflagChk|cHmbBufflagInv);
        uTrigLoop++;
        u16HmbIdx++;
        u16BufIdx+=c16LoadPartTabStcrCnt;
    }
}    /* writeHmbWrpoTab */

void readHmbGcInfoTab(WORD u16BufIdx, WORD u16WproIdx, WORD u16RwOpt, BYTE uStartPageOffset)
{
    HMBPRDQ *upHmbPrdQ;
    WORD u16HmbIdx;
    BYTE uTrigLoop=0, uTigCnt;

    mWaitHmbRelease(c32GcInfoTabSctrCnt/c16LoadPartTabStcrCnt);

    if(uStartPageOffset&cBit7)
    {
        // load partial table only load 16k
        uStartPageOffset&=~cBit7;
        uTigCnt=1;
    }
    else if(uStartPageOffset&cBit6)
    {
        uStartPageOffset&=~cBit6;
        uTigCnt=(cGCF2HTableSctrSize)/c16LoadPartTabStcrCnt;
    }
    else
    {
        uTigCnt=c32GcInfoTabSctrCnt/c16LoadPartTabStcrCnt;
    }

    u16HmbIdx=((u16WproIdx-cWproGcDesF2hTab00)*(c32GcInfoTabSctrCnt/c16LoadPartTabStcrCnt))+uStartPageOffset;

    if(u16BufIdx&c16Bit15)
    {
        u16BufIdx&=~c16Bit15;
#if 1    // !_EN_RAID_GC
        u16RwOpt|=cSetBufferFlag;
#else
        // wait done due to no raid flag for hmb downstream
        u16RwOpt|=cSetRaidFlag|cWaitReadDone;
#endif
    }

    while(uTrigLoop<uTigCnt)
    {
        upHmbPrdQ=&gsHmbInfo.uarHmbPrdQ[gsHmbInfo.uHmbHwPrdHead];

        upHmbPrdQ->u32SctrCnt=c16LoadPartTabStcrCnt;
        upHmbPrdQ->u16BufPtr=u16BufIdx;
        upHmbPrdQ->uOpCode=cHmbReadWpro;
        upHmbPrdQ->u16HmbIdx=u16HmbIdx;
        upHmbPrdQ->uSrcIdx=u16WproIdx;
        upHmbPrdQ->u32HmbAddrLow=c32HmbTotalH2fTableSize+(u16HmbIdx*c16LoadPartTabSize);

        rmHmbPrdDw10=g32arGcInfoCrc[u16HmbIdx];

        if(u16RwOpt&cSetBufferFlag)
        {
            upHmbPrdQ->uSgmtIdx=cSetBufferFlag;
            trigHmbDataXfer(upHmbPrdQ, cHmbTsbPath|cHmbReadDir|cHmbBufflagChk|cHmbBufflagInv);
        }

#if 0    // _EN_RAID_GC
        else if(u16RwOpt&cSetRaidFlag)
        {
            trigHmbDataXfer(upHmbPrdQ, cHmbTsbPath|cHmbReadDir);

            LWORD u32SctrCnt=(upHmbPrdQ->u32SctrCnt>>3);
            uBufIdx=u16BufIdx>>3;

            while(u32SctrCnt)
            {
                rmSetBufRaid8Sts(uBufIdx, 0xFF);    // 4k alignment
                uBufIdx++;
                u32SctrCnt--;
            }
        }
#endif
        else
        {
            trigHmbDataXfer(upHmbPrdQ, cHmbTsbPath|cHmbReadDir);
        }

        uTrigLoop++;
        u16HmbIdx++;
        u16BufIdx+=c16LoadPartTabStcrCnt;
    }

    if(u16RwOpt&cWaitReadDone)
    {
        waitHmbPrdDone();
    }
}    /* readHmbGcInfoTab */

#if _ENABLE_HMB_FLUSH
void insertHmbDirtyLink(WORD u16Hblock, BYTE uDiryt)
{
    WORD u16PrevNodeIdx, u16NextNodeIdx, u16HmbIdx;
    volatile LINKINFO *upHmbLlInfo;

    while(!mChkHmbLink(u16Hblock))
        ;

    u16HmbIdx=mGetHmbLink(u16Hblock);
    upHmbLlInfo=&gsHmbInfo.usHmbList;

    if(uDiryt==cTrue)
    {
        mSetHmbTabDirty(u16HmbIdx);
        gsHmbInfo.u16HmbLastDirtyPtr=u16HmbIdx;
    }
    else
    {
        mClrHmbTabDirty(u16HmbIdx);
    }

    // if(((uDiryt)&&(u16HmbIdx!=gsHmbInfo.u16HmbLastDirtyPtr))||((!uDiryt)&&(u16HmbIdx!=upHmbLlInfo->u16Head)))
    {
        if(gsHmbInfo.u16HmbLastDirtyPtr==u16HmbIdx)
        {
            gsHmbInfo.u16HmbLastDirtyPtr=gsHmbInfo.uarHmbLink[u16HmbIdx].u16Prev;
        }

        while((gsHmbInfo.usHmbList.u16Head!=c16Null)&&(gsHmbInfo.uarHmbLink[gsHmbInfo.usHmbList.u16Head].u16Next!=c16Null))
            ;

        while((gsHmbInfo.usHmbList.u16Tail!=c16Null)&&(gsHmbInfo.uarHmbLink[gsHmbInfo.usHmbList.u16Tail].u16Prev!=c16Null))
            ;

        mDelNode16(u16PrevNodeIdx, gsHmbInfo.uarHmbLink, u16HmbIdx, u16NextNodeIdx, upHmbLlInfo);

        while((gsHmbInfo.usHmbList.u16Head!=c16Null)&&(gsHmbInfo.uarHmbLink[gsHmbInfo.usHmbList.u16Head].u16Next!=c16Null))
            ;

        while((gsHmbInfo.usHmbList.u16Tail!=c16Null)&&(gsHmbInfo.uarHmbLink[gsHmbInfo.usHmbList.u16Tail].u16Prev!=c16Null))
            ;

        u16PrevNodeIdx=((uDiryt==cTrue)&&(upHmbLlInfo->u16Cnt))?gsHmbInfo.u16HmbLastDirtyPtr:upHmbLlInfo->u16Head;

        mInsNode16(u16PrevNodeIdx, upHmbLlInfo, u16NextNodeIdx, gsHmbInfo.uarHmbLink, u16HmbIdx);

        while((gsHmbInfo.usHmbList.u16Head!=c16Null)&&(gsHmbInfo.uarHmbLink[gsHmbInfo.usHmbList.u16Head].u16Next!=c16Null))
            ;

        while((gsHmbInfo.usHmbList.u16Tail!=c16Null)&&(gsHmbInfo.uarHmbLink[gsHmbInfo.usHmbList.u16Tail].u16Prev!=c16Null))
            ;

        if(uDiryt==cTrue)
        {
            gsHmbInfo.u16HmbLastDirtyPtr=u16HmbIdx;
        }
    }
}    /* insertHmbDirtyLink */

#endif/* if _ENABLE_HMB_FLUSH */
/*
   * void flipOccFlag(WORD u16OccFSkipStBufPtr, WORD u16TotalFlipCnt, BYTE uAllOne)
   * {
   *  BYTE uFlipCnt;
   *  WORD u16BufIdx;
   *  LWORD u32BufOccSts;
   *
   *  while(u16TotalFlipCnt)
   *  {
   *      uFlipCnt=((~u16OccFSkipStBufPtr)&0x1F)+1;
   *
   *      if(uFlipCnt>u16TotalFlipCnt)
   *      {
   *          uFlipCnt=u16TotalFlipCnt;
   *      }
   *
   *      u16TotalFlipCnt-=uFlipCnt;
   *      u16BufIdx=u16OccFSkipStBufPtr>>5;
   *
   *      if(uFlipCnt!=32)
   *      {
   *          u32BufOccSts=0;
   *
   *          while(uFlipCnt)
   *          {
   *              if(!uAllOne)
   *              {
   *                  u32BufOccSts|=rm32BufOccStatus(u16BufIdx)&cb32BitTab[u16OccFSkipStBufPtr&0x1F];
   *              }
   *              else
   *              {
   *                  u32BufOccSts|=cb32BitTab[u16OccFSkipStBufPtr&0x1F];
   *              }
   *
   *              u16OccFSkipStBufPtr++;
   *              uFlipCnt--;
   *          }
   *
   *          rmSetBufOcc32Sts(u16BufIdx, u32BufOccSts);
   *      }
   *      else
   *      {
   *          if(!uAllOne)
   *          {
   *              rmSetBufOcc32Sts(u16BufIdx, rm32BufOccStatus(u16BufIdx));
   *          }
   *          else
   *          {
   *              rmSetBufOcc32Sts(u16BufIdx, 0xFFFFFFFF);
   *          }
   *
   *          u16OccFSkipStBufPtr+=32;
   *      }
   *
   *      if(u16OccFSkipStBufPtr==0x300)
   *      {
   *          u16OccFSkipStBufPtr=0;
   *      }
   *  }
   * }
   *
   * void workaroundHmb0()
   * {
   *  PRDQUEUE *upPrdInfo;
   *  WORD u16HmbCacheSize=0, u16HmbCacheBufPtr;
   *  LWORD u32SctrCnt=1;
   *
   *  while(gsPrdInfo.uFreeHwPrdCnt!=cHwPrdDepth)
   *  {
   *      if((gsPrdInfo.uFreeHwPrdCnt==(cHwPrdDepth-1))&&u32SctrCnt)
   *      {
   *          if(gsHmbInfo.usHmbPrdList.u16Cnt)
   *          {
   *              break;
   *          }
   *
   *          upPrdInfo=&gsPrdInfo.uarPrdQue[gsPrdInfo.u16arIdxToPrdInfo[gsPrdInfo.uarFreeHwPrdQue[gsPrdInfo.uFreeHwPrdHead]]];
   *          u32SctrCnt=upPrdInfo->u32SctrCnt;
   *
   *          if(u32SctrCnt)
   *          {
   *              while(u32SctrCnt>0x300)
   *                  ;// 226 temp solution
   *
   *              if(upPrdInfo->u16BufPtr!=gsGcInfo.u16OccFSkipStBufPtr)
   *              {
   *                  if(upPrdInfo->u16BufPtr>gsGcInfo.u16OccFSkipStBufPtr)
   *                  {
   *                      if(g16WriteBufPtr>=gsGcInfo.u16OccFSkipStBufPtr)
   *                      {
   *                          u16HmbCacheSize=g16WriteBufPtr-gsGcInfo.u16OccFSkipStBufPtr;
   *                      }
   *                  }
   *                  else
   *                  {
   *                      if((upPrdInfo->u16BufPtr+u32SctrCnt)>=gsGcInfo.u16OccFSkipStBufPtr)
   *                      {
   *                          u16HmbCacheSize=upPrdInfo->u16BufPtr+u32SctrCnt-gsGcInfo.u16OccFSkipStBufPtr;
   *                      }
   *                  }
   *              }
   *              else
   *              {
   *                  u16HmbCacheSize=u32SctrCnt;
   *              }
   *
   *              while(u16HmbCacheSize>0x300)
   *                  ;
   *
   *              if(u16HmbCacheSize)
   *              {
   *                  u16HmbCacheBufPtr=gsGcInfo.u16OccFSkipStBufPtr;
   *                  gsGcInfo.u16OccFSkipStBufPtr=addWriteBufPtr(gsGcInfo.u16OccFSkipStBufPtr, u16HmbCacheSize);
   *                  gsGcInfo.u16OccFSkipSize-=u16HmbCacheSize;
   *                  flipOccFlag(u16HmbCacheBufPtr, u16HmbCacheSize, 0);
   *              }
   *              else
   *              {
   *                  break;
   *              }
   *
   *              u32SctrCnt=0;
   *          }
   *      }
   *
   *      chkReleaseFreeHwPrd();
   *  }
   *
   *  if(u16HmbCacheSize)
   *  {
   *      while(gsRwCtrl.u32FreeSrcFifoTail!=gsRwCtrl.u32FreeSrcFifoHead)
   *          ;
   *
   *      while(!(rm32BufStatus(u16HmbCacheBufPtr>>5)&cb32BitTab[u16HmbCacheBufPtr&0x1F])&&u16HmbCacheSize)
   *      {
   *          u16HmbCacheBufPtr++;
   *          u16HmbCacheSize--;
   *      }
   *
   *      if(u16HmbCacheSize)
   *      {
   *          writeHmbData(u16HmbCacheBufPtr, u16HmbCacheSize, 0, cXXXX);
   *          gsHmbInfo.u16HmbCacheBufPtr=u16HmbCacheBufPtr;
   *          gsHmbInfo.u16HmbCacheSize=u16HmbCacheSize;
   *          gsHmbInfo.uHmbCacheCnt++;
   *      }
   *      else
   *      {
   *          while(1)
   *              ;
   *      }
   *
   *      while(gsHmbInfo.usHmbPrdList.u16Cnt)
   *      {
   *          chkReleaseFreeHwPrd();
   *      }
   *
   *      flipOccFlag(u16HmbCacheBufPtr, u16HmbCacheSize, 0);
   *  }
   * }
   *
   * void workaroundHmb1()
   * {
   *  // trig hmb data to tsb
   *  readHmbData(gsHmbInfo.u16HmbCacheBufPtr, gsHmbInfo.u16HmbCacheSize, 0, 0, cXXXX, cLastPrd|cTsb|cEnTsbBufFlag|cAutoBufflag);
   *  gsHmbInfo.uHmbCacheCnt--;
   *
   *  while(gsHmbInfo.uHmbCacheCnt)
   *      ;
   * }
   */

void txfrHmbData(BYTE uOpCode, WORD u16BufIdx, WORD u16SctrCnt, LWORD u32ByteOfst, WORD u16HmbIdx, BYTE uHmbFuncId, LWORD u32PrdMo,
                 LWORD u32Crc)
{
    HMBPRDQ *upHmbPrdQ;

    upHmbPrdQ=&gsHmbInfo.uarHmbPrdQ[gsHmbInfo.uHmbHwPrdHead];

    upHmbPrdQ->u32SctrCnt=u16SctrCnt;
    upHmbPrdQ->u16BufPtr=u16BufIdx;
    upHmbPrdQ->uOpCode=uOpCode;
    upHmbPrdQ->uFuncId=uHmbFuncId;
    upHmbPrdQ->u16HmbIdx=u16HmbIdx;
    upHmbPrdQ->u32HmbAddrLow=gsHmbInfo.u32HmbStAddr[uHmbFuncId]+u32ByteOfst;

    rmHmbPrdDw10=u32Crc;
    trigHmbDataXfer(upHmbPrdQ, u32PrdMo);
}    /* txfrHmbData */

/*
   * void postHmbReadData()
   * {
   *  BYTE uSrcIdx;
   *  ADDRINFO *upAddrInfo;
   *
   *  uSrcIdx=gsRwCtrl.uarTrigHmbPrd[gsRwCtrl.u32TrigHmbTail];
   *  upAddrInfo=&garSrcAddrInfo[uSrcIdx];
   *  readHmbData(upAddrInfo->u16BufPtr,
   *              upAddrInfo->uRwHalfKb,
   *              upAddrInfo->u32FPageNoTran,
   *              uSrcIdx,
   *              cHmbWrCache,
   *              cHmbTsbPath|cHmbReadDir|cHmbBufflagChk|cHmbBufflagInv, 1);
   *  gsRwCtrl.u32TrigHmbTail=(gsRwCtrl.u32TrigHmbTail+1)&(cPrdDepth-1);
   * }
   */

void chkHmbPrdDone()
{
#if (_EN_HMB&&(!_PRJ_BOOT||_ICE_LOAD_ALL))

    if(gsHmbInfo.uHmbFreeHwPrdCnt!=cHmbHwPrdDepth)
    {
        if(mChkHmbPrdTrigIdx)
        {
            releaseHmbHwPrd();
        }
    }
#endif
}

void waitHmbPrdDone()    // 20190531_ChirsSu
{
#if (_EN_HMB&&(!_PRJ_BOOT||_ICE_LOAD_ALL))

    while(gsHmbInfo.uHmbFreeHwPrdCnt!=cHmbHwPrdDepth)
    {
        if(mChkHmbPrdTrigIdx)
        {
            releaseHmbHwPrd();
        }
    }
#endif
}

void releaseHmbHwPrd()
{
    // WORD u16PrevNodeIdx, u16NextNodeIdx, u16HmbPrdQIdx;
    HMBPRDQ *upHmbPrdQ;
    LWORD u32Opt;
    WORD u16Hblock;
    BYTE uSgmtIdx, uHmbHwPrdDoneIdx;
    BYTE uBufFlagIdx;
    LWORD u32TempBufFlag;

    // volatile LINKINFO *upDelLlInfo;

    do
    {
        upHmbPrdQ=&gsHmbInfo.uarHmbPrdQ[gsHmbInfo.uHmbHwPrdTail];

#if 0

        if(mChkHandlePcieErrF)
        {
            NLOG(cLogTempDebug,
                 HMB_C,
                 4,
                 "releaseHmbHwPrd:mChkHandlePcieErrF,u16BufPtr=0x%04X, u32SctrCnt=0x%04X, u32HmbAddrLow=0x%04X_0x%04X",
                 upHmbPrdQ->u16BufPtr,
                 upHmbPrdQ->u32SctrCnt,
                 (LWORD)upHmbPrdQ->u32HmbAddrLow>>16,
                 (WORD)upHmbPrdQ->u32HmbAddrLow);
            NLOG(cLogTempDebug,
                 HMB_C,
                 4,
                 "releaseHmbHwPrd:mChkHandlePcieErrF,uHmbHwPrdHead=0x%04X, uHmbHwPrdTail=0x%04X, uOpCode=0x%04X, uFuncId=0x%04X",
                 gsHmbInfo.uHmbHwPrdHead,
                 gsHmbInfo.uHmbHwPrdTail,
                 upHmbPrdQ->uOpCode,
                 upHmbPrdQ->uFuncId);
        }
#endif/* if _EN_FW_DEBUG_UART */

        switch(upHmbPrdQ->uOpCode)
        {
#if _EN_HMBDWORDMO
            case cHmbRead4bTab:
                garSrchSrcTab[gsReadHAddrInfo[upHmbPrdQ->uSrcIdx].u16SrchSrcTabStIdx]=g32arGcInvaildPageBimap[gsHmbInfo.uHmbHwPrdTail];
                gsRwCtrl.uarSrcPrdPtr[gsRwCtrl.uSrcPrdHead]=upHmbPrdQ->uSrcIdx;
                gsRwCtrl.uSrcPrdHead=(gsRwCtrl.uSrcPrdHead+1)&(cPostSrcDept-1);
                gsRwCtrl.uSrcPrdCnt++;
                break;
#endif
            case cHmbRead2kTab:
                uSgmtIdx=upHmbPrdQ->uSgmtIdx;

#if (!(_PRJ_BOOT1||_PRJ_BOOT2))

                if(mChkHandlePcieErrF)
                {
                    while(gsRwCtrl.u32ProgFifoTail!=gsRwCtrl.u32ProgFifoHead)
                        ;

                    u16Hblock=g16arH2fBackup[upHmbPrdQ->u16HmbIdx];
                    readH2fSgmtTable(u16Hblock,
                                     (WORD)((upHmbPrdQ->u32HmbAddrLow-(upHmbPrdQ->u16HmbIdx<<gHmbH2FTableShift))>>11),
                                     uSgmtIdx,
                                     upHmbPrdQ->u32SctrCnt/cSctrPerRH2fTab);
#if _EN_RAID_DECODE

                    while((gsRwCtrl.u32H2fSgmtRdyTail==gsRwCtrl.u32H2fSgmtRdyHead)||g32DecodeWait)
                        ;

#else

                    while(gsRwCtrl.u32H2fSgmtRdyTail==gsRwCtrl.u32H2fSgmtRdyHead)
                        ;
#endif
                }
#endif/* if (!(_PRJ_BOOT1||_PRJ_BOOT2)) */

                mClrH2f1kTabSgmtPrep(uSgmtIdx);

                if(gsRwCtrl.uarTab2PrdPtr[uSgmtIdx]!=0xFF)
                {
                    delePrdTabLink(uSgmtIdx);
                }
                else
                {}

                break;

            case cHmbReadH2fTab:

                if((rmCrc32ErrFlag&cb32BitTab[gsHmbInfo.uRdCrcIdx])||mChkHandlePcieErrF)
                {
#if _EN_FW_DEBUG_UART

                    if(rmCrc32ErrFlag&cb32BitTab[gsHmbInfo.uRdCrcIdx])
                    {
#if (OEM==VERIFY)
                        NLOG(cLogTempDebug, HMB_C, 0, " debugDeadLock(0x001E)! rmCrc32ErrFlag&cb32BitTab[gsHmbInfo.uRdCrcIdx]");    // debugDeadLock(0x001E);
#endif
                    }
#endif
                    u32Opt=c16Bit0|c16Bit4|c16Bit15;

                    if(upHmbPrdQ->uSgmtIdx&cSetBufferFlag)
                    {
                        u32Opt|=c16Bit1;

                        while(((upHmbPrdQ->u16BufPtr%32)!=0)||((upHmbPrdQ->u32SctrCnt%32)!=0))
                            ;

                        for(uBufFlagIdx=((upHmbPrdQ->u16BufPtr)>>5);
                            uBufFlagIdx<((upHmbPrdQ->u16BufPtr+upHmbPrdQ->u32SctrCnt)>>5);
                            uBufFlagIdx++)
                        {
                            u32TempBufFlag=rm32BufStatus(uBufFlagIdx);
                            rmSetBuf32Sts(uBufFlagIdx, u32TempBufFlag);
                        }
                    }

                    u16Hblock=g16arH2fBackup[upHmbPrdQ->u16HmbIdx];

                    readNandH2fTab((LWORD)(mGetH2fTabPagePtr(g16TotalHBlock+mGetHmbLink(u16Hblock)))*gPage4kPerH2fTab,
                                   g16arH2fTabBlk[mGetH2fTabBlkIndex(g16TotalHBlock+mGetHmbLink(u16Hblock))],
                                   upHmbPrdQ->u16BufPtr, u32Opt, cWaitReadDone);

                    remHmbLink(u16Hblock);
#if (_GREYBOX)

                    if((gsGbInfo.uGreyBoxItem==cHmbErrHandle)&&(gsGbInfo.uGreyBoxOpt==cVOpCrc)&&(gsGbInfo.uStag==cVsTriggered))
                    {
                        gsGbInfo.uResult=cSuccess;
                        gsGbInfo.u32BkValue=u16Hblock;
                    }
#endif

                    gsFtlDbg.u16CrcH2fErrCnt++;
                }

                break;

            case cHmbReadWpro:

                if((rmCrc32ErrFlag&cb32BitTab[gsHmbInfo.uRdCrcIdx])||mChkHandlePcieErrF)
                {
#if _EN_FW_DEBUG_UART

                    if(rmCrc32ErrFlag&cb32BitTab[gsHmbInfo.uRdCrcIdx])
                    {
#if (OEM==VERIFY)
                        NLOG(cLogTempDebug, HMB_C, 0, " debugDeadLock(0x001E)! rmCrc32ErrFlag&cb32BitTab[gsHmbInfo.uRdCrcIdx");    // debugDeadLock(0x001E);
#endif
                    }
#endif
                    mSetGcFlag(cGcHmbGcInfoFail);

                    if(upHmbPrdQ->uSgmtIdx&cSetBufferFlag)
                    {
                        upHmbPrdQ->u16BufPtr|=c16Bit15;

                        while(((upHmbPrdQ->u16BufPtr%32)!=0)||((upHmbPrdQ->u32SctrCnt%32)!=0))
                            ;

                        for(uBufFlagIdx=((upHmbPrdQ->u16BufPtr)>>5);
                            uBufFlagIdx<((upHmbPrdQ->u16BufPtr+upHmbPrdQ->u32SctrCnt)>>5);
                            uBufFlagIdx++)
                        {
                            u32TempBufFlag=rm32BufStatus(uBufFlagIdx);
                            rmSetBuf32Sts(uBufFlagIdx, u32TempBufFlag);
                        }
                    }

                    gsFtlDbg.u16CrcGcInfoErrCnt++;
                }

                break;

            case cHmbReadCrcData:
            case cHmbReadData:

                if((rmCrc32ErrFlag&cb32BitTab[gsHmbInfo.uRdCrcIdx])||mChkHandlePcieErrF)
                {
#if _EN_FW_DEBUG_UART

                    if(rmCrc32ErrFlag&cb32BitTab[gsHmbInfo.uRdCrcIdx])
                    {
#if (OEM==VERIFY)
                        NLOG(cLogTempDebug, HMB_C, 0, " debugDeadLock(0x001E)! rmCrc32ErrFlag&cb32BitTab[gsHmbInfo.uRdCrcIdx");    // debugDeadLock(0x001E);
#endif
                    }
#endif

                    if(upHmbPrdQ->uFuncId==cHmbTsbCache)
                    {
                        gsFtlDbg.u16CrcDataErrCnt++;    // No Handle
                    }
                    else
                    {
                        mSetGcFlag(cGcDesFailAbort);

                        if(upHmbPrdQ->uFuncId==cHmbGcCache)
                        {
                            gsFtlDbg.u16CrcGcDataErrCnt++;

#if 0
                            NLOG(cLogTempDebug,
                                 HMB_C,
                                 4,
                                 "cHmbReadData:cHmbGcCache, gsHmbInfo.uHmbHwPrdTail: 0x%04X, gsHmbInfo.uHmbHwPrdHead: 0x%04X, rmHmbPrdQueTrigIdx: 0x%04X, rmHmbPrdQueHeadIdx: 0x%04X",
                                 gsHmbInfo.uHmbHwPrdTail,
                                 gsHmbInfo.uHmbHwPrdHead,
                                 rmHmbPrdQueTrigIdx,
                                 rmHmbPrdQueHeadIdx);

                            NLOG(cLogTempDebug,
                                 HMB_C,
                                 4,
                                 "cHmbReadData:cHmbGcCache, uOpCode: 0x%04X, uFuncId: 0x%04X, u16BufPtr: 0x%04X, u32SctrCnt: 0x%04X",
                                 upHmbPrdQ->uOpCode,
                                 upHmbPrdQ->uFuncId,
                                 upHmbPrdQ->u16BufPtr, upHmbPrdQ->u32SctrCnt);
#endif/* if _EN_FW_DEBUG_UART */
                        }
                        else if(upHmbPrdQ->uFuncId==cHmbGcPtCache)
                        {
                            gsFtlDbg.u16CrcGcPtErrCnt++;
#if _EN_FW_DEBUG_UART
                            NLOG(cLogTempDebug,
                                 HMB_C,
                                 4,
                                 "cHmbReadData:cHmbGcPtCache,u16BufPtr=0x%04X, u32SctrCnt=0x%04X, u32HmbAddrLow=0x%04X_%04X",
                                 upHmbPrdQ->u16BufPtr,
                                 upHmbPrdQ->u32SctrCnt,
                                 (LWORD)upHmbPrdQ->u32HmbAddrLow>>16,
                                 (WORD)upHmbPrdQ->u32HmbAddrLow);
                            NLOG(cLogTempDebug,
                                 HMB_C,
                                 4,
                                 "cHmbReadData:cHmbGcPtCache,uHmbHwPrdHead=0x%04X, uHmbHwPrdTail=0x%04X, g32arGcPtyCrc=0x%04X_0x%04X",
                                 gsHmbInfo.uHmbHwPrdHead,
                                 gsHmbInfo.uHmbHwPrdTail,
                                 (LWORD)g32arGcPtyCrc[upHmbPrdQ->u16HmbIdx*2]>>16,
                                 g32arGcPtyCrc[upHmbPrdQ->u16HmbIdx*2]);
#if (OEM==VERIFY)
                            NLOG(cLogTempDebug, HMB_C, 0, " debugDeadLock(0x0055)!");    // debugDeadLock(0x0055);
#endif
#endif/* if _EN_FW_DEBUG_UART */
                        }
                    }
                }

                break;

            case cHmbWriteH2fTab:
                u16Hblock=g16arH2fBackup[upHmbPrdQ->u16HmbIdx];
                g16arH2fTabPtr[g16TotalHBlock+upHmbPrdQ->u16HmbIdx]=g16arH2fTabPtr[u16Hblock];
                mSetH2fTabEntry(u16Hblock, gMaxH2fTabBlkNum, upHmbPrdQ->u16HmbIdx);
                rmSetCrc32GetAddr(gsHmbInfo.uWrCrcIdx);
                g32arHmbCrc[upHmbPrdQ->u16HmbIdx]=rmCrc32ChkFifoOut;

                if(mChkHandlePcieErrF)
                {
                    while(((upHmbPrdQ->u16BufPtr%32)!=0)||((upHmbPrdQ->u32SctrCnt%32)!=0))
                        ;

                    for(uBufFlagIdx=((upHmbPrdQ->u16BufPtr)>>5); uBufFlagIdx<((upHmbPrdQ->u16BufPtr+upHmbPrdQ->u32SctrCnt)>>5); uBufFlagIdx++)
                    {
                        u32TempBufFlag=rm32BufStatus(uBufFlagIdx);
                        rmSetBuf32Sts(uBufFlagIdx, u32TempBufFlag);
                    }
                }

                break;

            case cHmbWriteWpro:

                if(upHmbPrdQ->uSrcIdx<cWproQBWithDumyW)
                {
                    setGcInfoHmbLinkCore0(upHmbPrdQ->uSrcIdx);
                }

                rmSetCrc32GetAddr(gsHmbInfo.uWrCrcIdx);
                g32arGcInfoCrc[upHmbPrdQ->u16HmbIdx]=rmCrc32ChkFifoOut;

                if(mChkHandlePcieErrF)
                {
                    while(((upHmbPrdQ->u16BufPtr%32)!=0)||((upHmbPrdQ->u32SctrCnt%32)!=0))
                        ;

                    for(uBufFlagIdx=((upHmbPrdQ->u16BufPtr)>>5); uBufFlagIdx<((upHmbPrdQ->u16BufPtr+upHmbPrdQ->u32SctrCnt)>>5); uBufFlagIdx++)
                    {
                        u32TempBufFlag=rm32BufStatus(uBufFlagIdx);
                        rmSetBuf32Sts(uBufFlagIdx, u32TempBufFlag);
                    }
                }

                break;

            case cHmbWriteData:
                rmSetCrc32GetAddr(gsHmbInfo.uWrCrcIdx);

                if(upHmbPrdQ->uFuncId==cHmbGcCache)
                {
                    g32arGcDataCrc[upHmbPrdQ->u16HmbIdx*2]=rmCrc32ChkFifoOut;

                    if(mChkHandlePcieErrF)
                    {
                        rmResetBufFlg;
                    }
                    else
                    {
                        bopCopyRam((LWORD)gCrcDataBuffer,
                                   (LWORD)c32TsbCrcAddr+((upHmbPrdQ->u16HmbIdx%(cTsb0Size/cHmbChunkSctrSize))*(cHmbChunkSctrSize<<3)),
                                   cHmbChunkSctrSize<<3,
                                   cCopyTsb2Tsb|cBopNotWait|cBopDesAutoBuf);
                    }
                }
                else if(upHmbPrdQ->uFuncId==cHmbGcPtCache)
                {
                    g32arGcPtyCrc[upHmbPrdQ->u16HmbIdx*2]=rmCrc32ChkFifoOut;

                    // bop xfr should not cross 512b boundary or desbuf_f should be considered
                    if(mChkHandlePcieErrF)
                    {
                        rmResetBufFlg;
                    }
                    else
                    {
                        bopCopyRam((LWORD)gCrcDataBuffer,
                                   (LWORD)c32TsbCrcAddr+(c16GcParitySIdx<<3),
                                   cRaidDataSctrNum<<3,
                                   cCopyTsb2Tsb|cBopNotWait|cBopDesAutoBuf);
                    }
                }
                else
                {
                    g32arTsbCrc[upHmbPrdQ->u16HmbIdx*2]=rmCrc32ChkFifoOut;

                    if(mChkHandlePcieErrF)
                    {
                        rmResetBufFlg;
                    }
                    else
                    {
                        bopCopyRam((LWORD)gCrcDataBuffer,
                                   (LWORD)c32TsbCrcAddr+(upHmbPrdQ->u16HmbIdx*(cHmbChunkSctrSize<<3)),
                                   cHmbChunkSctrSize<<3,
                                   cCopyTsb2Tsb|cBopNotWait|cBopDesAutoBuf);
                    }
                }

                break;

            case cHmbWriteCrcData:
            {
                WORD u16BufIdx=upHmbPrdQ->uSrcIdx;
                WORD u16Loop;

                rmSetCrc32GetAddr(gsHmbInfo.uWrCrcIdx);

                if(upHmbPrdQ->uFuncId==cHmbCrcCache)
                {
                    g32arGcDataCrc[(upHmbPrdQ->u16HmbIdx*2)+1]=rmCrc32ChkFifoOut;
                    u16Loop=cHmbChunkSctrSize>>5;
                }
                else if(upHmbPrdQ->uFuncId==cHmbPtCrcCache)
                {
                    g32arGcPtyCrc[(upHmbPrdQ->u16HmbIdx*2)+1]=rmCrc32ChkFifoOut;
                    u16Loop=cRaidDataSctrNum>>5;
                }
                else
                {
                    g32arTsbCrc[(upHmbPrdQ->u16HmbIdx*2)+1]=rmCrc32ChkFifoOut;
                    u16Loop=cHmbChunkSctrSize>>5;
                }

                while(u16Loop)
                {
                    rmSetBuf32Sts(u16BufIdx, 0xFFFFFFFF);    // 64k alignment
                    u16BufIdx++;
                    u16Loop--;
                }

#if _EN_FW_DEBUG_UART

                if(mChkHandlePcieErrF)
                {
                    NLOG(cLogTempDebug,
                         HMB_C,
                         3,
                         "cHmbWriteCrcData, u16BufIdx=0x%04X, rm32BufStatus=0x%08X",
                         u16BufIdx,
                         rm32BufStatus(u16BufIdx>>5)>>16,
                         rm32BufStatus(u16BufIdx>>5));
                }
#endif

                break;
            }
            // case cHmbWrite2kTab:

            default:
                gsFtlDbg.u16DummyFailType=cReleaseHmbHwPrd;
                debugWhile();    // No such case
        }    /* switch */

        if(upHmbPrdQ->uOpCode&cHmbWrCmdBit)
        {
            gsHmbInfo.uWrCrcIdx=(gsHmbInfo.uWrCrcIdx+1)&(cHmbHwPrdDepth-1);
        }
        else
        {
            rmCrc32ErrFlag&=~cb32BitTab[gsHmbInfo.uRdCrcIdx];
            gsHmbInfo.uRdCrcIdx=(gsHmbInfo.uRdCrcIdx+1)&(cHmbHwPrdDepth-1);
        }

        gsHmbInfo.uHmbHwPrdTail=(gsHmbInfo.uHmbHwPrdTail+1)&(cHmbHwPrdDepth-1);
        gsHmbInfo.uHmbFreeHwPrdCnt++;

        if(gsHmbInfo.uHmbFreeHwPrdCnt>cHmbHwPrdDepth)    // DebugUse
        {
            NLOG(cLogTempDebug, HMB_C, 1, " HmbFreeHwPrdCnt over cHmbHwPrdDepth! HmbFreeHwPrdCnt=0x%04x,"gsHmbInfo.uHmbFreeHwPrdCnt);
            debugWhile();
        }

        if(mChkHandlePcieErrF)
        {
            uHmbHwPrdDoneIdx=gsHmbInfo.uHmbHwPrdHead;
        }
        else
        {
            uHmbHwPrdDoneIdx=rmHmbPrdQueTrigIdx;
        }
    }
    while(uHmbHwPrdDoneIdx!=gsHmbInfo.uHmbHwPrdTail);
}    /* releaseHmbHwPrd */

#if _EN_HMBDWORDMO
void readHmbH2f4B(WORD u16Hblock, WORD u16Hpage, BYTE uPrdIdx)
{
    HMBPRDQ *upHmbPrdQ;

    invalidateDCache();
    upHmbPrdQ=&gsHmbInfo.uarHmbPrdQ[gsHmbInfo.uHmbHwPrdHead];

    upHmbPrdQ->uOpCode=cHmbRead4bTab;
    upHmbPrdQ->uSrcIdx=uPrdIdx;
    // upHmbPrdQ->u32HmbAddrLow=(mGetHmbLink(u16Hblock)<<gHmbH2FTableShift)+(u16Hpage<<2);
    // upHmbPrdQ->u32SctrCnt=c32Hmb4bMo;

    // trigHmbDataXfer(upHmbPrdQ, cHmbTsbPath|cHmbReadDir);
    rmHmbPrdDw0=cHmbTsbPath|cHmbReadDir;
    rmHmbPrdDw1=(((LWORD)&g32arGcInvaildPageBimap[gsHmbInfo.uHmbHwPrdHead])&~c32Bit30)>>2;
    rmHmbPrdDw5=c32Hmb4bMo;
    rmHmbPrdDw8=((LWORD)mGetHmbLink(u16Hblock)<<gHmbH2FTableShift)+(u16Hpage<<2);    // upHmbPrdQ->u32HmbAddrLow;
    rmPushHmbPrd;

    gsHmbInfo.uHmbHwPrdHead=(gsHmbInfo.uHmbHwPrdHead+1)&(cHmbHwPrdDepth-1);
    gsHmbInfo.uHmbFreeHwPrdCnt--;
}    /* readHmbH2f4B */

#endif/* if _EN_HMBDWORDMO */

void trigHmbDataXfer(HMBPRDQ *upHmbPrdQ, LWORD u32PrdOpt)
{
    // HMBPRDQ *upHmbPrdQ;

    // upHmbPrdQ=&gsHmbInfo.uarHmbPrdQ[u16PrdInfoIdx];
    // gsHmbInfo.u16IdxToHmbPrdQ[rmHmbPrdQueHeadIdx]=u16PrdInfoIdx;
    gsHmbInfo.uHmbHwPrdHead=(gsHmbInfo.uHmbHwPrdHead+1)&(cHmbHwPrdDepth-1);
    gsHmbInfo.uHmbFreeHwPrdCnt--;
/*
   *  if(gbEnAes)
   *  {
   *      rmAesMode;
   *      u32PrdOpt|=cHmbAes;
   *      rmHmbPrdDw6=(upHmbPrdQ->u32HmbAddrLow>>9);
   *      rmHmbPrdDw7=0;
   *  }
   */
    rmHmbPrdDw0=u32PrdOpt;
    rmHmbPrdDw1=((upHmbPrdQ->u16BufPtr)<<7);
    rmHmbPrdDw5=upHmbPrdQ->u32SctrCnt;
    rmHmbPrdDw8=upHmbPrdQ->u32HmbAddrLow;

    // if(upHmbPrdQ->uOpCode==cHmbReadH2fTab)
    // {
    //    rmHmbPrdDw10=g32arHmbCrc[upHmbPrdQ->u16HmbIdx];
    // }
    // else
    // {
    //    rmHmbPrdDw10=0;
    // }

    if(!mChkHandlePcieErrF)
    {
        rmPushHmbPrd;
    }
}    /* trigHmbDataXfer */

void writeE2eCrc2Hmb(BYTE uStBufIdx)
{
    HMBPRDQ *upHmbPrdQ;

    upHmbPrdQ=&gsHmbInfo.uarHmbPrdQ[gsHmbInfo.uHmbHwPrdHead];
    upHmbPrdQ->u32SctrCnt=(cHmbChunkSctrSize<<3)>>9;
    upHmbPrdQ->u16BufPtr=((LWORD)gCrcDataBuffer-c32Tsb0SAddr)>>9;
    upHmbPrdQ->uOpCode=cHmbWriteCrcData;
    upHmbPrdQ->uFuncId=cHmbCrcCache;
    upHmbPrdQ->u16HmbIdx=gsGcInfo.uHmbGcCachePtr;
    upHmbPrdQ->uSrcIdx=uStBufIdx;
    upHmbPrdQ->u32HmbAddrLow=gsHmbInfo.u32HmbStAddr[cHmbCrcCache]+(gsGcInfo.uHmbGcCachePtr*(cHmbChunkSctrSize<<3));

    trigHmbDataXfer(upHmbPrdQ, cHmbTsbPath|cHmbBufflagChk|cHmbBufflagInv);
}

void readE2eCrcFromHmb()
{
    HMBPRDQ *upHmbPrdQ;

    upHmbPrdQ=&gsHmbInfo.uarHmbPrdQ[gsHmbInfo.uHmbHwPrdHead];
    upHmbPrdQ->u32SctrCnt=(cHmbChunkSctrSize<<3)>>9;
    upHmbPrdQ->u16BufPtr=((LWORD)gCrcDataBuffer-c32Tsb0SAddr)>>9;
    upHmbPrdQ->uOpCode=cHmbReadCrcData;
    upHmbPrdQ->uFuncId=cHmbCrcCache;
    upHmbPrdQ->u32HmbAddrLow=gsHmbInfo.u32HmbStAddr[cHmbCrcCache]+(gsGcInfo.uHmbGcCachePtr*(cHmbChunkSctrSize<<3));

    rmHmbPrdDw10=g32arGcDataCrc[(gsGcInfo.uHmbGcCachePtr*2)+1];

    trigHmbDataXfer(upHmbPrdQ, cHmbTsbPath|cHmbReadDir|cHmbBufflagChk|cHmbBufflagInv);

    if(!mChkHandlePcieErrF)
    {
        bopCopyRam((LWORD)c32TsbCrcAddr+((gsGcInfo.uHmbGcCachePtr%(cTsb0Size/cHmbChunkSctrSize))*(cHmbChunkSctrSize<<3)),
                   (LWORD)gCrcDataBuffer,
                   cHmbChunkSctrSize<<3,
                   cCopyTsb2Tsb|cBopNotWait|cBopSrcAutoBuf);
    }
}    /* readE2eCrcFromHmb */

void writeTsbE2e2Hmb(BYTE uStBufIdx, BYTE uTsbIdx)
{
    HMBPRDQ *upHmbPrdQ;

    upHmbPrdQ=&gsHmbInfo.uarHmbPrdQ[gsHmbInfo.uHmbHwPrdHead];
    upHmbPrdQ->u32SctrCnt=(cHmbChunkSctrSize<<3)>>9;
    upHmbPrdQ->u16BufPtr=((LWORD)gCrcDataBuffer-c32Tsb0SAddr)>>9;
    upHmbPrdQ->uOpCode=cHmbWriteCrcData;
    upHmbPrdQ->uFuncId=cHmbTsbCache;
    upHmbPrdQ->u16HmbIdx=uTsbIdx;
    upHmbPrdQ->uSrcIdx=uStBufIdx;
    upHmbPrdQ->u32HmbAddrLow=gsHmbInfo.u32HmbStAddr[cHmbTsbCache]+(c16Tsb0Size*cSectorSize)+(uTsbIdx*(cHmbChunkSctrSize<<3));

    trigHmbDataXfer(upHmbPrdQ, cHmbTsbPath|cHmbBufflagChk|cHmbBufflagInv);
}    /* writeTsbE2e2Hmb */

void readTsbE2eFromHmb(BYTE uTsbIdx)
{
    HMBPRDQ *upHmbPrdQ;

    upHmbPrdQ=&gsHmbInfo.uarHmbPrdQ[gsHmbInfo.uHmbHwPrdHead];
    upHmbPrdQ->u32SctrCnt=(cHmbChunkSctrSize<<3)>>9;
    upHmbPrdQ->u16BufPtr=((LWORD)gCrcDataBuffer-c32Tsb0SAddr)>>9;
    upHmbPrdQ->uOpCode=cHmbReadCrcData;
    upHmbPrdQ->uFuncId=cHmbTsbCache;
    upHmbPrdQ->u32HmbAddrLow=gsHmbInfo.u32HmbStAddr[cHmbTsbCache]+(c16Tsb0Size*cSectorSize)+(uTsbIdx*(cHmbChunkSctrSize<<3));

    rmHmbPrdDw10=g32arTsbCrc[(uTsbIdx*2)+1];

    trigHmbDataXfer(upHmbPrdQ, cHmbTsbPath|cHmbReadDir|cHmbBufflagChk|cHmbBufflagInv);

    if(!mChkHandlePcieErrF)
    {
        bopCopyRam((LWORD)c32TsbCrcAddr+(uTsbIdx*(cHmbChunkSctrSize<<3)),
                   (LWORD)gCrcDataBuffer,
                   cHmbChunkSctrSize<<3,
                   cCopyTsb2Tsb|cBopWait|cBopSrcAutoBuf);
    }
}    /* readTsbE2eFromHmb */

#if _EN_RAID_GC
void writePtyE2e2Hmb(BYTE uStBufIdx, WORD u16ParityIdx)
{
    HMBPRDQ *upHmbPrdQ;
    WORD u16SctrCnt=cRaidDataSctrNum<<3;

    if(u16SctrCnt<cSingleSectorByte)
    {
        u16SctrCnt=cSingleSectorByte;
    }

    upHmbPrdQ=&gsHmbInfo.uarHmbPrdQ[gsHmbInfo.uHmbHwPrdHead];
    upHmbPrdQ->u32SctrCnt=u16SctrCnt>>9;
    upHmbPrdQ->u16BufPtr=((LWORD)gCrcDataBuffer-c32Tsb0SAddr)>>9;
    upHmbPrdQ->uOpCode=cHmbWriteCrcData;
    upHmbPrdQ->uFuncId=cHmbPtCrcCache;
    upHmbPrdQ->u16HmbIdx=u16ParityIdx;
    upHmbPrdQ->uSrcIdx=uStBufIdx;
    upHmbPrdQ->u32HmbAddrLow=gsHmbInfo.u32HmbStAddr[cHmbPtCrcCache]+(u16ParityIdx*u16SctrCnt);

    trigHmbDataXfer(upHmbPrdQ, cHmbTsbPath|cHmbBufflagChk|cHmbBufflagInv);
}    /* writePtyE2e2Hmb */

void readPtyE2eFromHmb(WORD u16ParityIdx)
{
    HMBPRDQ *upHmbPrdQ;
    WORD u16SctrCnt=cRaidDataSctrNum<<3;

    if(u16SctrCnt<cSingleSectorByte)
    {
        u16SctrCnt=cSingleSectorByte;
    }

    upHmbPrdQ=&gsHmbInfo.uarHmbPrdQ[gsHmbInfo.uHmbHwPrdHead];
    upHmbPrdQ->u32SctrCnt=u16SctrCnt>>9;
    upHmbPrdQ->u16BufPtr=((LWORD)gCrcDataBuffer-c32Tsb0SAddr)>>9;
    upHmbPrdQ->uOpCode=cHmbReadCrcData;
    upHmbPrdQ->uFuncId=cHmbPtCrcCache;
    upHmbPrdQ->u32HmbAddrLow=gsHmbInfo.u32HmbStAddr[cHmbPtCrcCache]+(u16ParityIdx*u16SctrCnt);

    rmHmbPrdDw10=g32arGcPtyCrc[(u16ParityIdx*2)+1];

    trigHmbDataXfer(upHmbPrdQ, cHmbTsbPath|cHmbReadDir|cHmbBufflagChk|cHmbBufflagInv);

    if(!mChkHandlePcieErrF)
    {
        bopCopyRam((LWORD)c32TsbCrcAddr+(c16GcParitySIdx<<3), (LWORD)gCrcDataBuffer, cRaidDataSctrNum<<3, cCopyTsb2Tsb|cBopWait|cBopSrcAutoBuf);
    }

    WORD u16BufIdx=c16GcParitySIdx>>5;
    WORD u16Loop=cRaidDataSctrNum>>5;

    while(u16Loop)
    {
        while(rm32BufStatus(u16BufIdx))
            ;// Wait Core1 DMA for Pcie Err case

        rmSetBuf32Sts(u16BufIdx, 0xFFFFFFFF);    // 64k alignment
        u16BufIdx++;
        u16Loop--;
    }
}    /* readPtyE2eFromHmb */

#endif/* if _EN_RAID_GC */







