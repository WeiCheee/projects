







#if 0
void fillBlockDummyPage(WORD u16FBlock, WORD u16StarFPage, BYTE uLsbMode)
{
    BYTE uPlaneAddr, uProgPageCnt;
    LWORD u16EndFPage;
    WORD u16TotalDummyPageCnt;
    ADDRINFO usTmpAddrInfo;

    hdmaClrRam(c32Tsb0SAddr, gSectorPerPageH*0x0200, 0x55AA_55AA, cClrTsb|cHdmaNotWait);

    u16TotalDummyPageCnt=(LWORD)cbCidTable[0x06]*gTotalIntlvChPlaneNum;
    u16EndFPage=u16StarFPage+u16TotalDummyPageCnt;

    if(u16EndFPage>g16PagePerBlock2)
    {
        u16EndFPage=g16PagePerBlock2;
    }

    u16TotalDummyPageCnt=u16EndFPage-u16StarFPage;

    while(rmChkHdmaBz)
        ;

    while(u16TotalDummyPageCnt)
    {
        usTmpAddrInfo.u16FBlock=u16FBlock;
        usTmpAddrInfo.u16FPage=u16StarFPage;
        // usTmpAddrInfo.ubLsbOnly=0;
        usTmpAddrInfo.uOpTyp=cWriteCache;
        tranAddrInfo(&usTmpAddrInfo);
        // tranCeNum(&usTmpAddrInfo);
        setFLAddrActCh(gActiveCh, &usTmpAddrInfo);
        gSectorH=0;

        if((gPlaneAddr==0)&&(u16TotalDummyPageCnt>=gPlaneNum))
        {
            // prog dummy multi plane
            // if (!gbEnCacheProg||(g16FPage==(g16PagePerBlock1-1)))
            // {
            mSetFRwParam(c16Tsb0SIdx, gSectorPerPageH, c16Bit0, cProgData);
            // }
            // else
            // {
            // setFRwParam(c16Tsb0SIdx, gSectorPerPageH, c16Bit0|c16Bit2|c16Bit3|c16Bit15, cCacheProgData);
            // }
            waitCmdFifoDpt(gActiveCh, &usTmpAddrInfo);

            for(uPlaneAddr=0; uPlaneAddr<gPlaneNum; uPlaneAddr++)
            {
                setSprByteOfTabBlk(cDummyDataID, 0xFFFF, 0xFFFF, 0xFFFF, 0xFFFF_FFFF, uPlaneAddr, 0xFFFF);
            }

            waitChCeBz(gActiveCh, gIntlvAddr, 0);
            flashProgPage(mGetWriteBuf, mGetProgSctrCnt, mGetWriteOpt);
            // gsRwCtrl.uWaitFlag[gActiveCh][gActiveCe][gIntlvAddr]=gOpTyp;
            setBzInfo(gOpTyp, gActiveCh, gIntlvAddr);
            gsRwCtrl.usWaitInfo[gActiveCh][gIntlvAddr].uStatusErrStop=0;

            uProgPageCnt=gPlaneNum;
        }
        else
        {
            // prog dummy single plane
            mSetFRwParam(c16Tsb0SIdx, gSectorPerPlaneH, 0, cProgData);
            waitCmdFifoDpt(gActiveCh, &usTmpAddrInfo);
            setSprByteOfTabBlk(cDummyDataID, 0xFFFF, 0xFFFF, 0xFFFF, 0xFFFF_FFFF, gPlaneAddr, 0xFFFF);
            waitChCeBz(gActiveCh, gIntlvAddr, 0);
            flashProgPage(mGetWriteBuf, mGetProgSctrCnt, mGetWriteOpt);
            // gsRwCtrl.uWaitFlag[gActiveCh][gActiveCe][gIntlvAddr]=gOpTyp;
            setBzInfo(gOpTyp, gActiveCh, gIntlvAddr);
            gsRwCtrl.usWaitInfo[gActiveCh][gIntlvAddr].uStatusErrStop=0;

            uProgPageCnt=1;
        }

        u16StarFPage+=uProgPageCnt;
        u16TotalDummyPageCnt-=uProgPageCnt;
    }
}    /* fillBlockDummyPage */

#endif/* if 0 */

/*
   * WORD chkBlockLastPagePtr(WORD u16FBlock, BYTE uMode)
   * {
   *  ADDRINFO *upTmpAddrInfo;
   *  ADDRINFO *upDesAddrInfo;
   *  BLKSPRINFO usBlkSprInfo;
   *  WORD u16FPage;
   *  WORD u16FPageStr, u16FPageEnd, u16DivPart;
   *  BYTE uCh, uIntlv, uDoneMinDivPartFlag;
   *
   *  setSprOnesCntCondition(cDisSprOnesCntSetting);
   *  upTmpAddrInfo=&(garSrcAddrInfo[cReadFifoDpt-cMaxCombination]);    // for debuging, so it's not from [0]
   *
   *  if(uMode&cSrchBySlcMode)
   *  {
   *      u16FPageEnd=g16PagePerBlock1_SLC;
   *  }
   *  else
   *  {
   *      u16FPageEnd=g16PagePerBlock1;
   *  }
   *
   *  u16DivPart=div(u16FPageEnd, gTotalChNum*gIntlvWay);
   *
   *  // initialize Address info
   *  upTmpAddrInfo[0].u16FBlock=u16FBlock;
   *  // upTmpAddrInfo[0].ubLsbOnly=(uMode&cSrchBySlcMode);
   *  upTmpAddrInfo[0].u16FPage=0;
   *  u16FPage=0;
   *  tranAddrInfo(&upTmpAddrInfo[0]);
   *  //tranCeNum(&upTmpAddrInfo[0]);
   *
   *  for(uCh=0; uCh<gTotalChNum; uCh++)
   *  {
   *      for(uIntlv=0; uIntlv<gIntlvWay; uIntlv++)
   *      {
   *          if((uCh+uIntlv)!=0)
   *          {
   *              upDesAddrInfo=&upTmpAddrInfo[uIntlv*gTotalChNum+uCh];
   *              copyTsb2Tsb((UCBYTE *)(upDesAddrInfo), (UCBYTE *)&(upTmpAddrInfo[0]), sizeof(ADDRINFO));
   *              upDesAddrInfo->uCh=uCh;
   *              upDesAddrInfo->uIntlvAddr=uIntlv;
   *              upDesAddrInfo->uDieAddr=mGetDieAddr(uIntlv);
   *          }
   *      }
   *  }
   *
   *  u16FPageStr=0;
   *  u16FPageEnd=u16FPageEnd-1;
   *  uDoneMinDivPartFlag=0;
   *
   *  // check last page range
   *  while(((u16FPageEnd-u16FPageStr)>1)||(!uDoneMinDivPartFlag))
   *  {
   *      // Stage 1, trigger read ale
   *      // Stage 2, Get specific page in this die to judge Page Range
   *      u16FPage=u16FPageStr;
   *
   *      if((u16FPageEnd-u16FPageStr)<=1)
   *      {
   *          uDoneMinDivPartFlag=1;
   *      }
   *
   *      for(uIntlv=0; uIntlv<gIntlvWay; uIntlv++)
   *      {
   *          for(uCh=0; uCh<gTotalChNum; uCh++)
   *          {
   *              // trigger Read
   *              upDesAddrInfo=&upTmpAddrInfo[uIntlv*gTotalChNum+uCh];
   *              setFLAddrActCh(uCh, upDesAddrInfo);
   *              gSectorH=0;
   *              gPlaneAddr=0;
   *              u16FPage+=u16DivPart;
   *
   *              if(u16FPage>u16FPageEnd)
   *              {
   *                  u16FPage=u16FPageEnd;
   *              }
   *
   *              upDesAddrInfo->u16FPage=u16FPage;
   *              setFRwParam(0, 0, c16Bit0|c16Bit12|c16Bit15, cReadCmdAle);
   *              waitCmdFifoDpt(uCh, cChkLastPgWaitCmdThr, upDesAddrInfo);
   *              waitChCeBz(uCh, uIntlv, 0);
   *              flashReadPage();
   *              setBzInfo(cReadCmdAle, uCh, uIntlv);
   *          }
   *      }
   *
   *      for(uIntlv=0; uIntlv<gIntlvWay; uIntlv++)
   *      {
   *          for(uCh=0; uCh<gTotalChNum; uCh++)
   *          {
   *              // get Read
   *              upDesAddrInfo=&upTmpAddrInfo[uIntlv*gTotalChNum+uCh];
   *              setFLAddrActCh(uCh, upDesAddrInfo);
   *              gSectorH=0;
   *              gPlaneAddr=0;
   *              setFRwParam(0, 0, c16Bit5|c16Bit10|c16Bit14, cReadData);
   *              waitCmdFifoDpt(uCh, cChkLastPgWaitDataThr, upDesAddrInfo);
   *              waitChCeBz(uCh, uIntlv, 0);
   *              flashReadPage();
   *              getSprByte(&usBlkSprInfo, gPlaneAddr);
   *
   *              if((!mChkBitMask(gPlaneUNCSts[gActiveCh], gPlaneAddr))&&(mGetMetaBlockId(usBlkSprInfo)==0xFF))    // empty page
   *              {
   *                  if(upDesAddrInfo->u16FPage<u16FPageEnd)
   *                  {
   *                      u16FPageEnd=upDesAddrInfo->u16FPage;
   *                  }
   *              }
   *              else
   *              {
   *                  if(upDesAddrInfo->u16FPage>u16FPageStr)
   *                  {
   *                      u16FPageStr=upDesAddrInfo->u16FPage;
   *                  }
   *              }
   *          }
   *      }
   *
   *      u16DivPart=div((u16FPageEnd-u16FPageStr+gTotalChNum*gIntlvWay), gTotalChNum*gIntlvWay);
   *  }
   *
   *  setSprOnesCntCondition(cEnSprOnesCntSetting);
   *
   *  return u16FPageStr;
   * }
   */

#if (!_HwPlane2SprIssue)
void buildBlockF2hTab(WORD u16FBlock, WORD u16Fpage, WORD u16RdDataStrFPage, BYTE uMode, F2HTABLE *upF2hTab)
{
    ADDRINFO usTmpAddrInfo[cMaxChNum];
    BLKSPRINFO usBlkSprInfo;
    WORD *u16pBlkSprPtr;
    BYTE uIntlvAddr, uDieAddr, uPlaneAddr, uCh, u4kPtr, uValidF;
    WORD u16EndPageOfF2hBank, u16OneShotPage, u16OneShotEnd;
    BYTE uMtPageCnt=0, uMtPageThr;
    BYTE uMlcMode;

    F2HTABLE *upUpdateAddr;

    ctrlOnesCntStop(0);    // setSprOnesCntCondition(cDisSprOnesCntSetting);
#if 0
    if(uMode&cBuildF2hInGcSrcF2h)
    {
/* temp remove
   *      bopClrRam((LWORD)garTsb0[c16GcSrcF2hSIdx2], c32CacheF2hRamSize, 0xFFFFFFFF, cClrTsb|cBopWait);
   *
   *      //upF2hTab=(_Uncached F2HTABLE *)garTsb0[c16GcSrcF2hSIdx2]+g16TotalPgPerF2hTab-1;
   *      upF2hTab=(F2HTABLE *)garTsb0[c16GcSrcF2hSIdx2]+g16TotalPgPerF2hTab-1;
   */
    }
    else
    {
        bopClrRam((LWORD)garCacheF2hTab, c32CacheF2hRamSize, 0xFFFFFFFF, cClrTsb|cBopWait);
        upF2hTab=garCacheF2hTab+(g16TotalPgPerF2hTab-1);
    }
#endif

    bopClrRam((LWORD)upF2hTab, c32CacheF2hRamSize, 0xFFFFFFFF, cClrTsb|cBopWait);
    upUpdateAddr=upF2hTab+(g16TotalPgPerF2hTab-1);

    // u16EndPageOfF2hBank=u16Fpage+div(g16TotalPgPerF2hTab, gTotalIntlvChNum*g4kNumPerPage);
    u16EndPageOfF2hBank=u16Fpage+(g16TotalPgPerF2hTab/(gTotalIntlvChNum*g4kNumPerPage));

    if(!(uMode&cAsignEofPgToRdData))
    {
        u16RdDataStrFPage=0xFFFF;
    }

    uMtPageThr=gPlaneNum;

    uMlcMode=(mChkMlcMoBit(u16FBlock)?(cTrue):(cFalse));

    for(uIntlvAddr=0; uIntlvAddr<gIntlvWay; uIntlvAddr++)
    {
        uDieAddr=mGetDieAddr(uIntlvAddr);

        for(uCh=0; uCh<gTotalChNum; uCh++)
        {
            usTmpAddrInfo[uCh].u16FBlock=u16FBlock;
            // tranCeNum(&usTmpAddrInfo[uCh]);
        }

        trigNexReadCmd(u16Fpage, uIntlvAddr, uDieAddr, uMlcMode, &usTmpAddrInfo[0]);
    }

    while((u16Fpage<u16EndPageOfF2hBank)&&(uMtPageCnt<=uMtPageThr))
    {
        // u16OneShotPage=u16Fpage;

        if(uMlcMode)
        {
            u16OneShotEnd=u16Fpage+cProgCntPerWL;
            // u16OneShotEnd=u16OneShotEnd-mod(u16OneShotEnd, cProgCntPerWL);
            u16OneShotEnd=u16OneShotEnd-(u16OneShotEnd%cProgCntPerWL);
        }
        else
        {
            u16OneShotEnd=u16Fpage+1;
        }

        for(uIntlvAddr=0; uIntlvAddr<gIntlvWay; uIntlvAddr++)
        {
            uDieAddr=mGetDieAddr(uIntlvAddr);

            for(u16OneShotPage=u16Fpage; u16OneShotPage<u16OneShotEnd; u16OneShotPage++)
            {
                // fillCcmVal((BYTE *)&gPlaneUNCSts, cMaxChNum, 0);
                rstUNCStsCore0();

                for(uCh=0; uCh<gTotalChNum; uCh++)
                {
                    usTmpAddrInfo[uCh].u16FPage=((uMlcMode)?((u16OneShotPage/cProgCntPerWL)):(u16OneShotPage));
                    // usTmpAddrInfo[uCh].uPageSelCmd=(uMlcMode)?((u16Fpage%cProgCntPerWL)+1):(0xA2);
                    setPageSelCmd(&usTmpAddrInfo[uCh], uMlcMode?((u16Fpage%cProgCntPerWL)+1):(cSlcCmd));
                    usTmpAddrInfo[uCh].uIntlvAddr=uIntlvAddr;
                    usTmpAddrInfo[uCh].uDieAddr=uDieAddr;
                    usTmpAddrInfo[uCh].uCh=uCh;
                    usTmpAddrInfo[uCh].uCe=(BYTE)mGetCEAddr(usTmpAddrInfo[uCh].uIntlvAddr);

                    // setFLAddrActCh(uCh, &usTmpAddrInfo[uCh]);
                    gpFlashAddrInfo=&usTmpAddrInfo[uCh];
                    // waitChCeBz(uCh, uIntlvAddr, 0);

                    if((uMode&cReadSprOnly)&&(u16Fpage<u16RdDataStrFPage))
                    {
                        mSetFRwParam(c16Tsb0SIdx, gSectorPerPageH, c16Bit0|c16Bit2|c16Bit5|c16Bit10|c16Bit14|c16Bit15, cReadData);

                        for(uPlaneAddr=0; uPlaneAddr<gPlaneNum; uPlaneAddr++)
                        {
                            gSectorH=0;
                            gPlaneAddr=uPlaneAddr;
                            // flashReadPage();
                            assignFreeBtSrcAddrInfo();
                        }
                    }
                    else
                    {
                        mSetFRwParam(c16Tsb0SIdx, gSectorPerPlaneH, c16Bit2|c16Bit4|c16Bit5|c16Bit10|c16Bit14|c16Bit15, cReadData);
                        // mWaitCmdFifoBz;
                        gSectorH=0;
                        gPlaneAddr=0;    // uPlaneAddr;
                        // flashReadPage();
                        assignFreeBtSrcAddrInfo();
                    }

                    // setBzInfo(cReadData, uCh, uIntlvAddr);
                }

                // fillCcmVal(&(gReadLinkRetrySlcVth[0][0]), cMaxChNum*cMaxPlaneNum, 0);

                waitCmdAllDone(cWaitTrigRCnt|cWaitCmdBz);    // (F) Ecc Fail use /*|c16Bit15*/ to do
                // releaseBtSrcAddrInfo();

/*  retry finish in core 1
   *              for(uCh=0; uCh<gTotalChNum; uCh++)
   *              {
   *                  // gReadLinkRetrySlcVth[uCh]=0;
   *                  setFLActCh(uCh);
   *                  jdgReadRetry(&usTmpAddrInfo[uCh], 0);
   *              }    // --> End Of for (uCh=0; uCh<gTotalChNum; uCh++)
   */

                if((u16OneShotPage+1)<u16EndPageOfF2hBank)
                {
                    trigNexReadCmd(u16OneShotPage+1, uIntlvAddr, uDieAddr, uMlcMode, &usTmpAddrInfo[0]);
                }

                fillCcmVal((BYTE *)&gPlaneUNCSts, cMaxChNum, 0);
                fillCcmVal((BYTE *)&gReadLinkRetrySlcVth, sizeof(gReadLinkRetrySlcVth), 0);

                for(uCh=0; uCh<gTotalChNum; uCh++)
                {
                    setFLActCh(uCh);

                    for(uPlaneAddr=0; uPlaneAddr<gPlaneNum; uPlaneAddr++)
                    {
                        getSprByte(&usBlkSprInfo, uPlaneAddr);
                        uValidF=cFalse;

                        if((!mChkBitMask(gPlaneUNCSts[uCh], uPlaneAddr))&&(mChkBlkIdCorrect))
                        {
                            if(    /*(mChkSporRetryVth(uCh, uPlaneAddr))&&*/ (u16OneShotPage>=u16RdDataStrFPage))
                            {
                                gsRdlinkInfo.u16BreakPage=u16Fpage;
                                gsRdlinkInfo.uBreakIntv=uIntlvAddr;
                                gsRdlinkInfo.uBreakCh=uCh;
                                gsRdlinkInfo.uBreakPlane=uPlaneAddr;
                                uMtPageCnt=0xFF;
                                break;
                            }
                            else
                            {
                                uMtPageCnt=0;
                                uValidF=cTrue;
                                u16pBlkSprPtr=&usBlkSprInfo.u16Spr0.u16all;
                            }
                        }
                        // else if((uMode&cReadSprOnly)&&(u16OneShotPage<u16RdDataStrFPage))
                        // {
                        //    uMtPageCnt++;
                        // }
                        else
                        {
                            gsRdlinkInfo.u16BreakPage=u16Fpage;
                            gsRdlinkInfo.uBreakIntv=uIntlvAddr;
                            gsRdlinkInfo.uBreakCh=uCh;
                            gsRdlinkInfo.uBreakPlane=uPlaneAddr;
                            uMtPageCnt=0xFF;
                            break;
                        }

                        if(uMtPageCnt>=uMtPageThr)
                        {
                            break;
                        }

                        // plane 0 & 1 are same data, plane 2 & 3 are same data
                        for(u4kPtr=0; u4kPtr<g4kNumPerPlane; u4kPtr++)
                        {
                            if(uValidF==cTrue)
                            {
                                if(*(u16pBlkSprPtr+1)!=0xFFFF)
                                {
                                    upUpdateAddr->u16HBlock=*(u16pBlkSprPtr+1)&c15BitFF;
                                    upUpdateAddr->u16HPage=*u16pBlkSprPtr;    // |c16Bit15;

                                    while(upUpdateAddr->u16HBlock>=g16TotalHBlock)
                                        ;

                                    while(upUpdateAddr->u16HPage>=g16PagePerH2fTab)
                                        ;
                                }

                                u16pBlkSprPtr+=2;
                            }

                            upUpdateAddr--;
                        }

                        // u16ScanPagePtr++;
                    }

                    if(uMtPageCnt>uMtPageThr)
                    {
                        break;    // discard all CH data
                    }
                }

                if(uMtPageCnt>uMtPageThr)
                {
                    break;    // discard all CE data
                }
            }

            if(uMtPageCnt>uMtPageThr)
            {
                break;    // discard all CE data
            }
        }

        u16Fpage=u16OneShotEnd;
    }

    waitCmdAllDone(cWaitTrigRCnt|cWaitCmdBz);
    // releaseBtSrcAddrInfo();

    waitAllChCeBzCore0();

    ctrlOnesCntStop(cBit0|cBit1);    // setSprOnesCntCondition(cEnSprOnesCntSetting);
}    /* buildBlockF2hTab */

#else/* if (!_HwPlane2SprIssue) */

void setF2hTab(LWORD u32F4K, WORD *u16pBlkSprPtr, F2HTABLE *upF2hTab)
{
    BYTE u4kPtr;
    F2HTABLE *upUpdateAddr=upF2hTab+(g16TotalPgPerF2hTab-(u32F4K%g16TotalPgPerF2hTab))-1;

    for(u4kPtr=0; u4kPtr<g4kNumPerPlane; u4kPtr++)
    {
        if(*(u16pBlkSprPtr+1)!=0xFFFF)
        {
            upUpdateAddr->u16HBlock=*(u16pBlkSprPtr+1)&c15BitFF;
            upUpdateAddr->u16HPage=*u16pBlkSprPtr;    // |c16Bit15;

            while(upUpdateAddr->u16HBlock>=g16TotalHBlock)
                ;

            while(upUpdateAddr->u16HPage>=g16PagePerH2fTab)
                ;
        }

        u16pBlkSprPtr+=2;
        upUpdateAddr--;
    }
}    /* setF2hTab */

void buildBlockF2hTab(WORD u16FBlock, WORD u16Fpage, WORD u16RdDataStrFPage, BYTE uMode, F2HTABLE *upF2hTab)
{
    ADDRINFO usTmpAddrInfo[cMaxChNum];
    BLKSPRINFO usBlkSprInfo;
    WORD *u16pBlkSprPtr;
    BYTE uIntlvAddr, uDieAddr, uPlaneAddr, uCh, uValidF, uPlaneAddr1;
    WORD u16EndPageOfF2hBank, u16OneShotPage, u16OneShotEnd;
    BYTE uMtPageCnt=0, uMtPageThr;
    BYTE uMlcMode;
    LWORD u32F4K;

    // F2HTABLE *upUpdateAddr;

    ctrlOnesCntStop(0);    // setSprOnesCntCondition(cDisSprOnesCntSetting);
/* temp remove
   *      bopClrRam((LWORD)garTsb0[c16GcSrcF2hSIdx2], c32CacheF2hRamSize, 0xFFFFFFFF, cClrTsb|cBopWait);
   *
   *      //upF2hTab=(_Uncached F2HTABLE *)garTsb0[c16GcSrcF2hSIdx2]+g16TotalPgPerF2hTab-1;
   *      upF2hTab=(F2HTABLE *)garTsb0[c16GcSrcF2hSIdx2]+g16TotalPgPerF2hTab-1;
   */

    bopClrRam((LWORD)upF2hTab, c32CacheF2hRamSize, 0xFFFFFFFF, cClrTsb|cBopWait);
    // upUpdateAddr=upF2hTab+(g16TotalPgPerF2hTab-1);

    // u16EndPageOfF2hBank=u16Fpage+div(g16TotalPgPerF2hTab, gTotalIntlvChNum*g4kNumPerPage);
    u16EndPageOfF2hBank=u16Fpage+(g16TotalPgPerF2hTab/(gTotalIntlvChNum*g4kNumPerPage));

    if(!(uMode&cAsignEofPgToRdData))
    {
        u16RdDataStrFPage=0xFFFF;
    }

    uMtPageThr=gPlaneNum;

    uMlcMode=(mChkMlcMoBit(u16FBlock)?(cTrue):(cFalse));

    for(uIntlvAddr=0; uIntlvAddr<gIntlvWay; uIntlvAddr++)
    {
        uDieAddr=mGetDieAddr(uIntlvAddr);

        for(uCh=0; uCh<gTotalChNum; uCh++)
        {
            usTmpAddrInfo[uCh].u16FBlock=u16FBlock;
            // tranCeNum(&usTmpAddrInfo[uCh]);
        }

        trigNexReadCmd(u16Fpage, uIntlvAddr, uDieAddr, uMlcMode, &usTmpAddrInfo[0]);
    }

    while((u16Fpage<u16EndPageOfF2hBank)&&(uMtPageCnt<=uMtPageThr))
    {
        // u16OneShotPage=u16Fpage;

        if(uMlcMode)
        {
            u16OneShotEnd=u16Fpage+cProgCntPerWL;
            // u16OneShotEnd=u16OneShotEnd-mod(u16OneShotEnd, cProgCntPerWL);
            u16OneShotEnd=u16OneShotEnd-(u16OneShotEnd%cProgCntPerWL);
        }
        else
        {
            u16OneShotEnd=u16Fpage+1;
        }

        for(uIntlvAddr=0; uIntlvAddr<gIntlvWay; uIntlvAddr++)
        {
            uDieAddr=mGetDieAddr(uIntlvAddr);

            for(u16OneShotPage=u16Fpage; u16OneShotPage<u16OneShotEnd; u16OneShotPage++)
            {
                rstUNCStsCore0();

                for(uPlaneAddr1=0; uPlaneAddr1<gPlaneNum; uPlaneAddr1+=2)
                {
                    for(uCh=0; uCh<gTotalChNum; uCh++)
                    {
                        usTmpAddrInfo[uCh].u16FPage=((uMlcMode)?((u16OneShotPage/cProgCntPerWL)):(u16OneShotPage));
                        // usTmpAddrInfo[uCh].uPageSelCmd=(uMlcMode)?((u16Fpage%cProgCntPerWL)+1):(0xA2);
                        setPageSelCmd(&usTmpAddrInfo[uCh], uMlcMode?((u16Fpage%cProgCntPerWL)+1):(cSlcCmd));
                        usTmpAddrInfo[uCh].uIntlvAddr=uIntlvAddr;
                        usTmpAddrInfo[uCh].uDieAddr=uDieAddr;
                        usTmpAddrInfo[uCh].uCh=uCh;
                        usTmpAddrInfo[uCh].uCe=(BYTE)mGetCEAddr(usTmpAddrInfo[uCh].uIntlvAddr);

                        // setFLAddrActCh(uCh, &usTmpAddrInfo[uCh]);
                        gpFlashAddrInfo=&usTmpAddrInfo[uCh];
                        // waitChCeBz(uCh, uIntlvAddr, 0);

                        if((uMode&cReadSprOnly)&&(u16Fpage<u16RdDataStrFPage))
                        {
                            mSetFRwParam(c16Tsb0SIdx, gSectorPerPlaneH<<1, c16Bit0|c16Bit2|c16Bit5|c16Bit10|c16Bit14|c16Bit15, cReadData);

                            for(uPlaneAddr=uPlaneAddr1; uPlaneAddr<(uPlaneAddr1+2); uPlaneAddr++)
                            {
                                gSectorH=0;
                                gPlaneAddr=uPlaneAddr;
                                // flashReadPage();
                                assignFreeBtSrcAddrInfo();
                            }
                        }
                        else
                        {
                            mSetFRwParam(c16Tsb0SIdx, gSectorPerPlaneH<<1, c16Bit0|c16Bit2|c16Bit4|c16Bit5|c16Bit10|c16Bit14|c16Bit15,
                                         cReadData);
                            // mWaitCmdFifoBz;
                            gSectorH=0;
                            gPlaneAddr=uPlaneAddr1;    // uPlaneAddr;
                            // flashReadPage();
                            assignFreeBtSrcAddrInfo();
                        }

                        // setBzInfo(cReadData, uCh, uIntlvAddr);
                    }

                    waitCmdAllDone(cWaitTrigRCnt|cWaitCmdBz);    // (F) Ecc Fail use /*|c16Bit15*/ to do

                    for(uCh=0; uCh<gTotalChNum; uCh++)
                    {
                        setFLActCh(uCh);

                        for(uPlaneAddr=uPlaneAddr1; uPlaneAddr<(uPlaneAddr1+2); uPlaneAddr++)
                        {
                            getSprByte(&usBlkSprInfo, uPlaneAddr);
                            uValidF=cFalse;

                            if((!mChkBitMask(gPlaneUNCSts[uCh], uPlaneAddr))&&(mChkBlkIdCorrect))
                            {
                                if(    /*(mChkSporRetryVth(uCh, uPlaneAddr))&&*/ (u16OneShotPage>=u16RdDataStrFPage))
                                {
                                    gsRdlinkInfo.u16BreakPage=u16Fpage;
                                    gsRdlinkInfo.uBreakIntv=uIntlvAddr;
                                    gsRdlinkInfo.uBreakCh=uCh;
                                    gsRdlinkInfo.uBreakPlane=uPlaneAddr;
                                    uMtPageCnt=0xFF;
                                }
                                else
                                {
                                    uMtPageCnt=0;
                                    uValidF=cTrue;
                                    u16pBlkSprPtr=&usBlkSprInfo.u16Spr0.u16all;
                                }
                            }
                            // else if((uMode&cReadSprOnly)&&(u16OneShotPage<u16RdDataStrFPage))
                            // {
                            //    uMtPageCnt++;
                            // }
                            else
                            {
                                if(uPlaneAddr>=2)
                                {
                                    gsRdlinkInfo.u16BreakPage=u16Fpage;
                                    gsRdlinkInfo.uBreakIntv=uIntlvAddr;
                                    gsRdlinkInfo.uBreakCh=uCh;
                                    gsRdlinkInfo.uBreakPlane=uPlaneAddr;
                                    uMtPageCnt=0xFF;
                                    break;
                                }
                            }

                            if(uMtPageCnt>=uMtPageThr)
                            {
                                break;
                            }

                            // plane 0 & 1 are same data, plane 2 & 3 are same data
                            if(uValidF==cTrue)
                            {
                                if(!uMlcMode)
                                {
                                    u32F4K=(u16OneShotPage*gTotalIntlvChPlaneNum)+(uIntlvAddr*gTotalChPlaneNum)+(uCh*gPlaneNum)+uPlaneAddr;
                                }
                                else
                                {
                                    u32F4K=((u16OneShotPage/cProgCntPerWL)*cProgCntPerWL*gTotalIntlvChPlaneNum)+
                                            (uIntlvAddr*gTotalChPlaneNum*cProgCntPerWL)+
                                            ((u16OneShotPage%cProgCntPerWL)*gTotalChPlaneNum)+
                                            (uCh*gPlaneNum)+uPlaneAddr;
                                }

                                u32F4K*=g4kNumPerPlane;

                                // debug purpose
                                {
                                    WORD u16Hblock=(*(u16pBlkSprPtr+1)&c15BitFF);

                                    if((u16Hblock!=c15BitFF)&&(u16Hblock>g16TotalHBlock))
                                    {
                                        volatile BYTE uTestFlag=1;

                                        while(uTestFlag&&u16Hblock)
                                            ;
                                    }
                                }

                                setF2hTab(u32F4K, u16pBlkSprPtr, upF2hTab);
                            }
                        }

                        if(uMtPageCnt>=uMtPageThr)
                        {
                            break;
                        }
                    }

                    if(uMtPageCnt>=uMtPageThr)
                    {
                        break;
                    }
                }

                if((u16OneShotPage+1)<u16EndPageOfF2hBank)
                {
                    trigNexReadCmd(u16OneShotPage+1, uIntlvAddr, uDieAddr, uMlcMode, &usTmpAddrInfo[0]);
                }

                if(uMtPageCnt>uMtPageThr)
                {
                    break;    // discard all CE data
                }
            }

            if(uMtPageCnt>uMtPageThr)
            {
                break;    // discard all CE data
            }
        }

        u16Fpage=u16OneShotEnd;
    }

    waitCmdAllDone(cWaitTrigRCnt|cWaitCmdBz);
    // releaseBtSrcAddrInfo();

    waitAllChCeBzCore0();

    ctrlOnesCntStop(cBit0|cBit1);    // setSprOnesCntCondition(cEnSprOnesCntSetting);
}    /* buildBlockF2hTab */

#endif/* if (!_HwPlane2SprIssue) */

void trigNexReadCmd(WORD u16Fpage, BYTE uIntlvAddr, BYTE uDieAddr, BYTE uMlcMode, ADDRINFO *upTmpAddrInfo)
{
    BYTE uCh;    // uPlaneAddr;

    for(uCh=0; uCh<gTotalChNum; uCh++)
    {
        upTmpAddrInfo->u16FPage=(uMlcMode)?((u16Fpage/cProgCntPerWL)):(u16Fpage);
        // upTmpAddrInfo->uPageSelCmd=(uMlcMode)?((u16Fpage%cProgCntPerWL)+1):(0xA2);
        setPageSelCmd(upTmpAddrInfo, uMlcMode?((u16Fpage%cProgCntPerWL)+1):(cSlcCmd));
        upTmpAddrInfo->u16RwOpt=c16Bit0|c16Bit15;
        upTmpAddrInfo->uCh=uCh;
        upTmpAddrInfo->uIntlvAddr=uIntlvAddr;
        upTmpAddrInfo->uCe=(BYTE)mGetCEAddr(upTmpAddrInfo->uIntlvAddr);
        upTmpAddrInfo->uDieAddr=uDieAddr;
        upTmpAddrInfo->uPlaneAddr=0;
        upTmpAddrInfo->uSectorH=0;
        upTmpAddrInfo->uOpTyp=cReadCmdAle;
        setFLAddrActCh(uCh, upTmpAddrInfo);

        // mWaitCmdFifoBz;

        // for (uPlaneAddr=0; uPlaneAddr<gPlaneNum; uPlaneAddr++)
        // {
        // gPlaneAddr=0;    // uPlaneAddr;
        // gSectorH=0;

        // waitChCeBz(uCh, uIntlvAddr, 0);
        // flashReadPage();
        // gsRwCtrl.uWaitFlag[uCh][gActiveCe][uIntlvAddr]=cReadCmdAle;
        // setBzInfo(cReadCmdAle, uCh, uIntlvAddr);
        assignFreeBtSrcAddrInfo();

        upTmpAddrInfo++;
        // }
    }

    waitCmdAllDone(cWaitTrigRCnt);
    // releaseBtSrcAddrInfo();
    // }
}    /* trigNexReadCmd */

/* trigNexReadCmd */







