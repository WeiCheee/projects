







#if (!_ICE_LOAD_ALL)
#pragma default_function_attributes = @ ".CORE0_MAIN"
#endif

#if 1    // (_PRJ_BOOT||_PRJ_ISP||_PRJ_NVME||_PRJ_SMIVU)
// Main////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
void callCore1Task(BYTE uType)
{
    TASKENTRY usTskEntry;

    usTskEntry.uTskTyp=uType;
    insertTaskFifo(usTskEntry);

    while(gsTskFifoCtrl.u32HeadPtr!=gsTskFifoCtrl.u32TailPtr)
        ;
}

void enableLdpcPipe()
{
#if _ENABLE_LDPCPIPELINE
    TASKENTRY usTskEntry;

    gsRwCtrl.u32LdpcSyncWithCore1=1;
    usTskEntry.uTskTyp=cTskEnableLdpcPipe;
    insertTaskFifo(usTskEntry);

    while(gsRwCtrl.u32LdpcSyncWithCore1)
        ;
#endif
}

void disableLdpcPipe()
{
#if _ENABLE_LDPCPIPELINE
    TASKENTRY usTskEntry;

    gsRwCtrl.u32LdpcSyncWithCore1=1;
    usTskEntry.uTskTyp=cTskDisableLdpcPipe;
    insertTaskFifo(usTskEntry);

    while(gsRwCtrl.u32LdpcSyncWithCore1)
        ;
#endif
}

void activateIspCore0()
{
    TASKENTRY usTskEntry;

    usTskEntry.uTskTyp=cTskActivateIsp;
    insertTaskFifo(usTskEntry);

    while(gsTskFifoCtrl.u32HeadPtr!=gsTskFifoCtrl.u32TailPtr)
        ;
}

void getGlobEraseCntOfSpecFblock(WORD u16Fblock)
{
    TASKENTRY usTskEntry;

    usTskEntry.uTskTyp=cTskGetGlobEraseCntOfSpecFblock;
    usTskEntry.uTskOpt=0xFF;
    usTskEntry.u16TskSBufPtr=u16Fblock;
    insertTaskFifo(usTskEntry);

    while(gsTskFifoCtrl.u32HeadPtr!=gsTskFifoCtrl.u32TailPtr)
        ;
}

void waitAllChCeBzCore0()
{
    TASKENTRY usTskEntry;

    usTskEntry.uTskTyp=cTskWaitAllBz;
    insertTaskFifo(usTskEntry);
}

void progWproPageCore0(BYTE uWproIdx, WORD u16SbufPtr)
{
    TASKENTRY usTskEntry;

#if _ENABLE_HMB_FLUSH
    if(uWproIdx==cWproCacheInfo)
    {
        while(gsHmbInfo.u16HmbLastDirtyPtr!=c16Null)
            ;
    }
#endif

    usTskEntry.uTskTyp=cTskProgWpro;
    usTskEntry.uTskOpt=uWproIdx;
    usTskEntry.u16TskSBufPtr=u16SbufPtr;
    insertTaskFifo(usTskEntry);

    while(gsTskFifoCtrl.u32HeadPtr!=gsTskFifoCtrl.u32TailPtr)
        ;
}    /* progWproPageCore0 */

void readWproPageCore0(BYTE uWproIdx, WORD u16SbufPtr, BYTE uStartPageOffset)
{
    TASKENTRY usTskEntry;

    usTskEntry.uTskTyp=cTskReadWpro;
    usTskEntry.uTskOpt=uWproIdx;
    usTskEntry.u16TskSBufPtr=u16SbufPtr;
    usTskEntry.uTskPgOfst=uStartPageOffset;
    insertTaskFifo(usTskEntry);

    while(gsTskFifoCtrl.u32HeadPtr!=gsTskFifoCtrl.u32TailPtr)
        ;
}

void loadBadCntTabCore0(WORD u16SbufPtr, BYTE uStartPageOffset)
{
    TASKENTRY usTskEntry;

    usTskEntry.uTskTyp=cTskVendorOp;
    usTskEntry.uTskOpt=cVendorCore1ReadOrgBadCnt;
    usTskEntry.u16TskSBufPtr=u16SbufPtr;
    usTskEntry.uTskPgOfst=uStartPageOffset;
    insertTaskFifo(usTskEntry);

    while(gsTskFifoCtrl.u32HeadPtr!=gsTskFifoCtrl.u32TailPtr)
        ;
}

void loadOrgBadTabCore0(WORD u16SbufPtr, BYTE uStartPageOffset)
{
    TASKENTRY usTskEntry;

    usTskEntry.uTskTyp=cTskVendorOp;
    usTskEntry.uTskOpt=cVendorCore1ReadOrgBadTable;
    usTskEntry.u16TskSBufPtr=u16SbufPtr;
    usTskEntry.uTskPgOfst=uStartPageOffset;
    insertTaskFifo(usTskEntry);

    while(gsTskFifoCtrl.u32HeadPtr!=gsTskFifoCtrl.u32TailPtr)
        ;
}

void loadISPCodeCore0(BYTE uCodeBank, BYTE uDesCore)
{
#if (!_ICE_LOAD_ALL)
    TASKENTRY usTskEntry;
    usTskEntry.uTskTyp=cTskSwapCore0;
    usTskEntry.uTskPgOfst=uDesCore;    // 0: core0, 2: tsb0
    usTskEntry.uTskOpt=uCodeBank;
    insertTaskFifo(usTskEntry);

    while(gsTskFifoCtrl.u32HeadPtr!=gsTskFifoCtrl.u32TailPtr)
        ;

#if ((_CODECOVER)&&(_GREYBOX))
    if(uCodeBank==cBootIsp)
    {
        g32CodeCoverMapOffset=c32GreyBoxCore0CodeAddr+0x1000000;
    }

    if(uCodeBank==cBoot2Isp)
    {
        g32CodeCoverMapOffset=c32GreyBoxCore0CodeAddr+0x2000000;
    }
    else if(uCodeBank==cRwIsp)
    {
        g32CodeCoverMapOffset=c32GreyBoxCore0CodeAddr+0x3000000;
    }
    else if(uCodeBank==cNvmeIsp)
    {
        g32CodeCoverMapOffset=c32GreyBoxCore0CodeAddr+0x4000000;
    }
    else if(uCodeBank==cSmiVuIsp)
    {
        g32CodeCoverMapOffset=c32GreyBoxCore0CodeAddr+0x5000000;
    }
    else if(uCodeBank==cBootIsp1)
    {
        g32CodeCoverMapOffset=c32GreyBoxCore0CodeAddr+0x6000000;
    }
    else if(uCodeBank==cRwIsp1)
    {
        g32CodeCoverMapOffset=c32GreyBoxCore0CodeAddr+0x7000000;
    }
    else if(uCodeBank==cNvmeIsp1)
    {
        g32CodeCoverMapOffset=c32GreyBoxCore0CodeAddr+0x8000000;
    }
    else if(uCodeBank==cSmiVuIsp1)
    {
        g32CodeCoverMapOffset=c32GreyBoxCore0CodeAddr+0x9000000;
    }
    else if(uCodeBank==cErrHdlIsp1)
    {
        g32CodeCoverMapOffset=c32GreyBoxCore0CodeAddr+0xA000000;
    }
#endif/* if ((_CODECOVER)&&(_GREYBOX)) */
#endif/* if (!_ICE_LOAD_ALL) */
}    /* loadISPCodeCore0 */

void forceInvCpu1DCache()
{
    TASKENTRY usTskEntry;

    usTskEntry.uTskTyp=cTskInvalidateCore1DCache;
    insertTaskFifo(usTskEntry);

    while(gsTskFifoCtrl.u32HeadPtr!=gsTskFifoCtrl.u32TailPtr)
        ;
}

// void resetAllFlashCore0()
// {
//    TASKENTRY usTskEntry;
//
//    usTskEntry.uTskTyp=cTskRstAllFlash;
//    usTskEntry.uTskOpt=0;
//    insertTaskFifo(usTskEntry);
//
//    while(gsTskFifoCtrl.u32HeadPtr!=gsTskFifoCtrl.u32TailPtr)
//        ;
// }

// void resetCore1Var()
// {
//    TASKENTRY usTskEntry;
//
//    usTskEntry.uTskTyp=cTskRstCtlVar;
//    usTskEntry.uTskOpt=0;
//    insertTaskFifo(usTskEntry);
//
//    while(gsTskFifoCtrl.u32HeadPtr!=gsTskFifoCtrl.u32TailPtr)
//        ;
// }

void changeFlashClock()
{
    TASKENTRY usTskEntry;

    usTskEntry.uTskTyp=cTskChangeFlashClock;
    usTskEntry.uTskOpt=0;
    insertTaskFifo(usTskEntry);

    while(gsTskFifoCtrl.u32HeadPtr!=gsTskFifoCtrl.u32TailPtr)
        ;
}

void core1Sleep(BYTE uPowerState)
{
    TASKENTRY usTskEntry;

    usTskEntry.uTskTyp=cTskCore1Sleep;
    usTskEntry.uTskOpt=uPowerState;
    insertTaskFifo(usTskEntry);

    while(gsTskFifoCtrl.u32HeadPtr!=gsTskFifoCtrl.u32TailPtr)
        ;
}

void core1ResumePs3()
{
    TASKENTRY usTskEntry;

    usTskEntry.uTskTyp=cTskCore1ResumePs3;
    usTskEntry.uTskOpt=0;
    insertTaskFifo(usTskEntry);

    while(gsTskFifoCtrl.u32HeadPtr!=gsTskFifoCtrl.u32TailPtr)
        ;
}

void core1SwapNvmeBank()
{
    TASKENTRY usTskEntry;

    usTskEntry.uTskTyp=cTskCore1SwapNvmeBank;
    usTskEntry.uTskOpt=0;
    insertTaskFifo(usTskEntry);

    while(gsTskFifoCtrl.u32HeadPtr!=gsTskFifoCtrl.u32TailPtr)
        ;
}

void core1SwapIspBank()
{
    TASKENTRY usTskEntry;

    usTskEntry.uTskTyp=cTskCore1SwapIspBank;
    usTskEntry.uTskOpt=0;
    insertTaskFifo(usTskEntry);

    while(gsTskFifoCtrl.u32HeadPtr!=gsTskFifoCtrl.u32TailPtr)
        ;
}

#if _ENABLE_RAID
void core1TskRstRaidPara()
{
    TASKENTRY usTskEntry;

    usTskEntry.uTskTyp=cTskRstRaidPara;
    usTskEntry.u16TskSBufPtr=(WORD)((gsRwCtrl.u32ProgFifoTrig<<8)+gsRwCtrl.u32ProgFifoTail);
    usTskEntry.uTskOpt=cRaidParaRst4PcieErr;
    insertTaskFifo(usTskEntry);

    // while(gsTskFifoCtrl.u32HeadPtr!=gsTskFifoCtrl.u32TailPtr)
    // ;
}

#endif

#if 0    // _ENABLE_RAID
void initRaidEngineCore0()
{
    TASKENTRY usTskEntry;

    usTskEntry.uTskTyp=cTskInitRaidEngine;
    insertTaskFifo(usTskEntry);

    while(gsTskFifoCtrl.u32HeadPtr!=gsTskFifoCtrl.u32TailPtr)
        ;
}

#endif

void pushSpareBlockCore0(WORD u16Fblock, BYTE uPushOpt)
{
    TASKENTRY usTskEntry;

    usTskEntry.uTskTyp=cTskPushBlk;
    usTskEntry.uTskOpt=uPushOpt;

    while(gsTskFifoCtrl.u16PushFBlk!=c16FBlockInitValue)
        ;

    gsTskFifoCtrl.u16PushFBlk=u16Fblock;
    insertTaskFifo(usTskEntry);
}

void eraseUnitProcCore0(BYTE uOpt)
{
    TASKENTRY usTskEntry;

    usTskEntry.uTskTyp=cTskEraseUnitProc;
    usTskEntry.uTskOpt=uOpt;
    insertTaskFifo(usTskEntry);

    while(gsTskFifoCtrl.u32HeadPtr!=gsTskFifoCtrl.u32TailPtr)
        ;

    chkAerReliability();
}

void invPlaneBufFlagCore0(WORD u16BufPtr, BYTE uBufCnt, BYTE uOpt)
{
    TASKENTRY usTskEntry;

    usTskEntry.uTskTyp=cTskInvPlaneBufFlag;
    usTskEntry.u16TskSBufPtr=u16BufPtr;
    usTskEntry.uTskPgOfst=uBufCnt;
    usTskEntry.uTskOpt=uOpt;
    insertTaskFifo(usTskEntry);

    while(gsTskFifoCtrl.u32HeadPtr!=gsTskFifoCtrl.u32TailPtr)
        ;
}

void swapWproBlkCore0()
{
    TASKENTRY usTskEntry;

    usTskEntry.uTskTyp=cTskSwapWproBlk;
    insertTaskFifo(usTskEntry);

    while(gsTskFifoCtrl.u32HeadPtr!=gsTskFifoCtrl.u32TailPtr)
        ;
}

WORD popSpareBlockCore0(BYTE uPopOpt)
{
    TASKENTRY usTskEntry;

    usTskEntry.uTskTyp=cTskPopBlk;
    usTskEntry.uTskOpt=uPopOpt;
    gsTskFifoCtrl.u16PopFBlk=c16FBlockInitValue;

    // while(gsTskFifoCtrl.u16PopFBlk!=c16FBlockInitValue)
    //    ;

    insertTaskFifo(usTskEntry);

    while(gsTskFifoCtrl.u32HeadPtr!=gsTskFifoCtrl.u32TailPtr)
        ;

    return gsTskFifoCtrl.u16PopFBlk;
}    /* popSpareBlockCore0 */

void insSlcSortQCore0(WORD u16FBlk)
{
    TASKENTRY usTskEntry;

    usTskEntry.uTskTyp=cTskInsSlcSortQ;
    usTskEntry.uTskOpt=0xFF;
    usTskEntry.u16TskSBufPtr=c16BitFF;
    gsTskFifoCtrl.u16FBlk=u16FBlk;

    while(gsTskFifoCtrl.u16FBlk==0xFFFF)
        ;

    insertTaskFifo(usTskEntry);

    while(gsTskFifoCtrl.u32HeadPtr!=gsTskFifoCtrl.u32TailPtr)
        ;
}

void progH2fTableCore0(WORD u16SbufPtr, WORD u16Hblock, WORD u16RwOpt, WORD u16Caller, BYTE uSpecialOpt)
{
    TASKENTRY usTskEntry;

    flushDCache();
    usTskEntry.uTskTyp=cTskProgH2f;

    while(gsTskFifoCtrl.usProgH2fPara.u16Hblock!=0xFFFF)
        ;

#if _GREYBOX
    if((gsGbInfo.uGreyBoxItem==cUGSDProgH2fTableID)&&(gsGbInfo.uGreyBoxOpt==cVOpAllConfig)&&(gsGbInfo.uStag==cVsIdl))
    {
        trigGreyBox(cTrue);
    }
#endif
    gsTskFifoCtrl.usProgH2fPara.u16SbufPtr=u16SbufPtr;
    gsTskFifoCtrl.usProgH2fPara.u16Hblock=u16Hblock;
    gsTskFifoCtrl.usProgH2fPara.u16RwOpt=u16RwOpt;
    gsTskFifoCtrl.usProgH2fPara.u16Caller=u16Caller;
    gsTskFifoCtrl.usProgH2fPara.uSpecialOpt=uSpecialOpt;
    insertTaskFifo(usTskEntry);

    while((u16RwOpt&c16Bit15)&&(gsTskFifoCtrl.u32HeadPtr!=gsTskFifoCtrl.u32TailPtr))
        ;

    // gsTskFifoCtrl.usProgH2fPara.u16Hblock=0xffff;
}    /* progH2fTableCore0 */

void chkPushSpareQCore0(BYTE uInBoot)
{
    TASKENTRY usTskEntry;

    usTskEntry.uTskTyp=cTskChkPushSpareQ;
    gsTskFifoCtrl.usProgH2fPara.uSpecialOpt=uInBoot;
    insertTaskFifo(usTskEntry);

    while(gsTskFifoCtrl.u32HeadPtr!=gsTskFifoCtrl.u32TailPtr)
        ;

    rstH2F1KInfo();    // for core 1 progCacheInfo table
}    /* chkPushSpareQCore0 */

#if (_ENABLE_RAID&&_EN_VPC_SWAP)
void pushVPCtoRaidCore0(WORD u16BufIdx)
{
    TASKENTRY usTskEntry;

    usTskEntry.uTskTyp=cTskpushVPCtoRaid;
    usTskEntry.u16TskSBufPtr=u16BufIdx;
    insertTaskFifo(usTskEntry);

    while(gsTskFifoCtrl.u32HeadPtr!=gsTskFifoCtrl.u32TailPtr)
        ;
}

void popVPCfromRaidCore0(WORD u16BufIdx)
{
    TASKENTRY usTskEntry;

    usTskEntry.uTskTyp=cTskpopVPCfromRaid;
    usTskEntry.u16TskSBufPtr=u16BufIdx;
    insertTaskFifo(usTskEntry);

    while(gsTskFifoCtrl.u32HeadPtr!=gsTskFifoCtrl.u32TailPtr)
        ;
}

#endif/* if (_ENABLE_RAID&&_EN_VPC_SWAP) */

/*
   * void handleCntForSanitizeCore0()
   * {
   *  TASKENTRY usTskEntry;
   *
   *  usTskEntry.uTskTyp=cTskHandleCntForSanitize;
   *  insertTaskFifo(usTskEntry);
   *
   *  while(gsTskFifoCtrl.u32HeadPtr!=gsTskFifoCtrl.u32TailPtr)
   *      ;
   * }
   */
WORD GetAvgECCore0(BYTE u8Mode)
{
    TASKENTRY usTskEntry;
    WORD u16tempECValue=gsTskFifoCtrl.u16EraseCnt;
    WORD u16returnEC=0;

    usTskEntry.uTskOpt=u8Mode;
    usTskEntry.uTskTyp=cTskGetAvgECCore0;
    insertTaskFifo(usTskEntry);

    while(gsTskFifoCtrl.u32HeadPtr!=gsTskFifoCtrl.u32TailPtr)
        ;

    u16returnEC=gsTskFifoCtrl.u16EraseCnt;
    gsTskFifoCtrl.u16EraseCnt=u16tempECValue;
    return u16returnEC;
}

#endif/* if 1 */

#if (!_ICE_LOAD_ALL)
#pragma default_function_attributes =
#endif







