







// #if (!_ICE_LOAD_ALL)
// #pragma default_function_attributes = @ ".SAVE_IDX"
// #endif
#if (_CPUID==1)
void setSprByteOfIdxBlk(BYTE uPlaneAddr)
{
    BLKSPRINFO usBlkSprInfo;
    WORD *u16pBlkSprPtr;
    BYTE uLoop;

    usBlkSprInfo.u16Seed=g16arSeedTable[gpFlashAddrInfo->u16FPage];
    usBlkSprInfo.u16Spr8.us2BYTE.LowByte=cIndexBlockID;
    usBlkSprInfo.u16Spr8.us2BYTE.HighByte=gOpTyp;
    usBlkSprInfo.u32Spr9and10.u32all=g32IndexBlkSerial;

    usBlkSprInfo.u16Spr7.u16all=((WORD)gSysOption<<8)|gsWproInfo.uActIdx;

    if(gsWproInfo.u16arWproIdxPagePtr[cWproBadInfo]!=0xFFFF)
    {
        ADDRINFO usAddrInfo;

        usAddrInfo.u16FBlock=gsWproInfo.u16arWproBlk[mGetWproBlkIdx(cWproBadInfo)];
        usAddrInfo.u16FPage=mGetWproPagePtr(cWproBadInfo);

        tranAddrInfoTo2Ch(&usAddrInfo);
        mSetIdxBlkSpr4(usBlkSprInfo, usAddrInfo);
        mSetIdxBlkSpr5(usBlkSprInfo, usAddrInfo);
        mSetIdxBlkSpr6(usBlkSprInfo, usAddrInfo);
    }
    else
    {
        usBlkSprInfo.u16Spr4.u16all=0xFFFF;
        usBlkSprInfo.u16Spr5.u16all=0xFFFF;
        usBlkSprInfo.u16Spr6.u16all=0xFFFF;
    }

    u16pBlkSprPtr=&usBlkSprInfo.u16Spr0.u16all;

    for(uLoop=0; uLoop<cMaxWproBlkCnt; uLoop++)
    {
        *(u16pBlkSprPtr+uLoop)=gsWproInfo.u16arWproBlk[uLoop];
    }

    usBlkSprInfo.u16Spr11.u16all=g16arCurrSysBlkEsCnt[cSysBlockIdx];
    setSprByte(&usBlkSprInfo, uPlaneAddr);
}    /* setSprByteOfIdxBlk */

void setDataOfIdxBlk(WORD u16SbufPtr)
{
    ADDRINFO usAddrInfo;
    WORD *u16TsbPtr=(WORD *)(c32Tsb0SAddr+(u16SbufPtr<<9));

    if(gsWproInfo.u16arWproIdxPagePtr[cWproBadInfo]!=0xFFFF)
    {
        // Diff addr
        usAddrInfo.u16FBlock=gsWproInfo.u16arWproBlk[gsWproInfo.uarWproIdxPtr[cWproBadInfo]];
        gsRdlinkInfo.u16DiffFPageNoTran=u16TsbPtr[2]=usAddrInfo.u16FPage=mGetWproPagePtr(cWproBadInfo)+1;

        tranAddrInfoTo2Ch(&usAddrInfo);
        gsRdlinkInfo.u16DiffFBlock0=u16TsbPtr[0]=getDiffFBlock(usAddrInfo.u16FBlock,
                                                               usAddrInfo.uCh,
                                                               usAddrInfo.uIntlvAddr,
                                                               usAddrInfo.uPlaneAddr);

        usAddrInfo.u16FPage=mGetWproPagePtr(cWproBadInfo)+1+1;
        tranAddrInfoTo2Ch(&usAddrInfo);
        gsRdlinkInfo.u16DiffFBlock1=u16TsbPtr[1]=getDiffFBlock(usAddrInfo.u16FBlock,
                                                               usAddrInfo.uCh,
                                                               usAddrInfo.uIntlvAddr,
                                                               usAddrInfo.uPlaneAddr);
        u16TsbPtr[3]=0x55AA;
    }
    else
    {
        u16TsbPtr[0]=0xFFFF;
        u16TsbPtr[1]=0xFFFF;
        u16TsbPtr[2]=0xFFFF;
        u16TsbPtr[3]=0xFFFF;
    }

    u16TsbPtr[(4096-16+0)/2]=g16EccFailNormalQueIndex;
    u16TsbPtr[(4096-16+2)/2]=g16EccFailAuxQueIndex;
    u16TsbPtr[(4096-16+4)/2]=g16EccFailChAndCe;
    u16TsbPtr[(4096-16+6)/2]=g16EccFailDieAndPlane;
    u16TsbPtr[(4096-16+8)/2]=g16EccFailBlkAddr;
    u16TsbPtr[(4096-16+10)/2]=g16EccFailPageAddr;
    u16TsbPtr[(4096-16+12)/2]=g16EccFailRegInfo;    // 0x118 & 0x11D
    u16TsbPtr[(4096-16+14)/2]=g16EccFailChunkBitMap;    // g16DebugLastFailChunkBitMap
#if _EN_VPC_SWAP
    copyCcmVal((BYTE *)(&g16arFoundCacheIdx), (BYTE *)((&garCacheF2hTab[0])+(c32CacheF2hRamSize-8*1024)), 4*1024);    // 20190528_Louis_01
#else
    copyCcmVal((BYTE *)(&(u16TsbPtr[(4096)/2])), (BYTE *)((&garCacheF2hTab[0])+(c32CacheF2hRamSize-8*1024)), 4*1024);
#endif
}    /* setDataOfIdxBlk */

void saveIndexBlock()
{
    ADDRINFO usTmpAddrInfo;
    // BYTE uPlaneCnt;
    BYTE uLoop, uWrCnt;
    WORD u16SbufPtr;

    if(mChkDummyWrite)
    {
        return;
    }

#if (_EN_VPC_SWAP&&(!_ENABLE_RAID))
    if(mChkBitMask(g32VPCSwapFlag, cVPCntInBoot))
    {
        u16SbufPtr=c16RH2fTabSIdx+((c32CacheBlkVpCntVarSize+511)>>9);
    }
    else if(!mChkCacheInfoFlag(cDataProgramFail))
#else
    if(!mChkCacheInfoFlag(cDataProgramFail))
#endif
    {
        u16SbufPtr=c16RaidBufSIdx;
    }
    else
    {
        u16SbufPtr=c16RH2fTabSIdx+cDiffMixTableHalfKb;
    }

#if _GREYBOX
    outCS(cbTagsaveIndexBlock);
#endif

    if(gsRdlinkInfo.ubPwrWrIdxBlk==0)
    {
        uWrCnt=2;
        gsRdlinkInfo.ubPwrWrIdxBlk=1;
    }
    else
    {
        uWrCnt=1;
    }

    for(uLoop=0; uLoop<uWrCnt; uLoop++)
    {
        if(mChkCacheInfoFlag(cIndexBlockFull))
        {
            // if (mChkIndexbInFL)
            // {
            // pushSysSprBlk(garSysBlock[cSysBlockIdx]);
            // }

#if _GREYBOX
            if((gsGbInfo.uGreyBoxItem==cUGSDProgIndxBlkID)&&(gsGbInfo.uGreyBoxOpt==cVOpErasing)&&(gsGbInfo.uStag==cVsIdl))
            {
                trigGreyBox(cTrue);
            }
#endif
            initErasedSysSprBlk(cSysBlockIdx, 0);

            g16IdxBlkFreePagePtr=0;
            mClrCacheInfoFlag(cIndexBlockFull);
            g32IndexBlkSerial++;
        }

        tranRsvBlkAddr(garSysBlock[cSysBlockIdx], &usTmpAddrInfo);
        usTmpAddrInfo.u16FPage=g16IdxBlkFreePagePtr;
        // tranCeNum(&usTmpAddrInfo);
        setFLAddrActCh(usTmpAddrInfo.uCh, &usTmpAddrInfo);
        gSectorH=0;
        mSetTabSpr(gpFlashAddrInfo, cBit5);    // gpFlashAddrInfo->uTabSpar=1;

        mSetFRwParam(u16SbufPtr, gSectorPerPlaneH, c16Bit14|c16Bit2, cProgData);
        waitCmdFifoDpt(gActiveCh, &usTmpAddrInfo);
        // for (uPlaneCnt=0; uPlaneCnt<1; uPlaneCnt++)
        // {
        setSprByteOfIdxBlk(gPlaneAddr    /*+uPlaneCnt*/);
        // }
        setDataOfIdxBlk(u16SbufPtr);
        waitChCeBz(gActiveCh, gIntlvAddr, 0);

        usTmpAddrInfo.u16BufPtr=u16SbufPtr;

#if _GREYBOX
        if((gsGbInfo.uGreyBoxItem==cUGSDProgIndxBlkID)&&((gsGbInfo.uGreyBoxOpt==cVOpAllConfig)||(gsGbInfo.uGreyBoxOpt==cVOpProgIndxBlkDone))&&
           (gsGbInfo.uStag==cVsIdl))
        {
            trigGreyBox(cTrue);
        }
#endif

#if _ENABLE_E2E_TAB
        genInternalDataCrc(u16SbufPtr, gSectorPerPlaneH, usTmpAddrInfo.u16FPage*gSectorPerPlaneH, cE2eIndexBlk);
#endif

        flashProgPage(mGetWriteBuf, mGetProgSctrCnt, mGetWriteOpt);
        setBzInfo(gOpTyp, gActiveCh, gIntlvAddr);
        gsRwCtrl.usWaitInfo[gActiveCh][gIntlvAddr].uStatusErrStop=0;

        g16IdxBlkFreePagePtr++;

        if(g16IdxBlkFreePagePtr>=g16PagePerBlock1_SLC)
        {
            mSetCacheInfoFlag(cIndexBlockFull);
        }
    }

    gsRdlinkInfo.ubSaveIdxBlk=0;
    mSetIndexbInFL;
    gbUpdIdxF=cFalse;
}    /* saveIndexBlock */

#endif/* if (_CPUID==1) */

// #if (!_ICE_LOAD_ALL)
// #pragma default_function_attributes =
// #endif







