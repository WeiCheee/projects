







#include "inc/Reg.h"
#include "inc/TypeDef.h"
#include "inc/ProType.h"

void initVic1(LWORD u32IntsEnable)
{
    rmVic1VectAddr00=0x00000020;    // isrClkReqLatQ
    rmVic1VectAddr01=0x00000024;    // isrPwFail18
    rmVic1VectAddr02=0x00000028;    // isrPwFail23
    rmVic1VectAddr03=0x0000002C;    // isrWdtIntPwFail27
    rmVic1VectAddr04=0x00000030;    // isrPwFail40IntPwFail10
    rmVic1VectAddr05=0x00000034;    // isrPwFailEx
    rmVic1VectAddr06=0x00000038;    // isrPwFailPor1
    rmVic1VectAddr07=0x0000003C;    // isrThsorValue
    rmVic1VectAddr08=0x00000040;    // isrJtag
    rmVic1VectAddr09=0x00000044;    // isrGpioAll
    rmVic1VectAddr10=0x00000048;    // isrP11
    rmVic1VectAddr11=0x0000004C;    // isrAllTimer
    rmVic1VectAddr12=0x00000050;    // isrI2cSlave
    rmVic1VectAddr13=0x00000054;    // isrI2cMaster
    rmVic1VectAddr14=0x00000058;    // isrUart
    rmVic1VectAddr15=0x0000005C;    // isrRng
    rmVic1VectAddr16=0x00000060;    // isrPcieAppIrq0
    rmVic1VectAddr17=0x00000064;    // isrPcieAppIrq1
    rmVic1VectAddr18=0x00000068;    // isrPcieAppIrq2
    rmVic1VectAddr19=0x0000006C;    // isrPcieAppIrq3
    rmVic1VectAddr20=0x00000070;    // isrPcieIrq0
    rmVic1VectAddr21=0x00000074;    // isrPcieIrq1
    rmVic1VectAddr22=0x00000078;    // isrPcieIrq2
    rmVic1VectAddr23=0x0000007C;    // isrPcieIrq3
    rmVic1VectAddr24=0x00000080;    // isrSetBvb2CfgTmoFlag
    rmVic1VectAddr25=0x00000084;    // isrRsa
    rmVic1VectAddr26=0x00000088;    // isrFakeFailStop
    rmVic1VectAddr27=0x0000008C;    // isrCmdFifoFull
    rmVic1VectAddr28=0x00000090;    // isrFlash
    rmVic1VectAddr29=0x00000094;    // isrHdaDone
    rmVic1VectAddr30=0x00000098;    // isrBopDone
    rmVic1VectAddr31=0x0000009C;    // isrVIC31

    // Clear event select register
    rmVic1DisEvent(0xFFFFFFFF);
    rmVic1EnEvent((LWORD)(1<<31));

    // rmVicInt03Pri0;                    // Set UART INT highest priority
    // rmVicInt02Pri2;                    // Set TRNG INT 3rd priority
    rmVic1IntSel=0x00000000;    // 1 = FIQ, 0 = IRQ
    // for ClkReq# wake up, Clk_reg (bit0) must set Pulse mode
    rmVic1IntMode=0xE100B77F;    // 1 = Pulse Mode, 0 = Level Mode  //skyhsu FFFFFFFF-->E100B77E
    // for ClkReq# wake up, Clk_reg (bit0) must set Low Active
    rmVic1IntPolarity=0xFFFFFFFE;    // 1 = High Active, 0 = Low Active
    rmVic1SoftMaskN=0xFFFFFFFF;    // 1 = Non Masked, 0 = Marsked
    rmVic1IntEnable=u32IntsEnable;    // 1 = interrupt enable, 0= interrupt disable(reset)
    // rmClrFakeInt = 0xFFFFFFFF;         // Clear All Fake Interrupt
    rmVic1IrqClr;
    rmVic1Enable;    // Enable VIC CTL, HW switch

    __enable_ve();
    __enable_irq();
    __enable_fiq();
}    /* initVic1 */







