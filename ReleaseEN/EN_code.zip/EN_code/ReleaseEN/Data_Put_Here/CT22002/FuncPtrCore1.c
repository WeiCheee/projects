







#ifndef _FUNCPTR_C_
#define _FUNCPTR_C_

#include "inc/ProType.h"
#include "inc/GlobVarT.h"
#pragma default_variable_attributes = @ ".CORE1_FUNCPTR"

void dummyFuncCore1()
{
    gsFtlDbg.u16DummyFailType=cDummyFuncCore1;
    debugWhile();
}

void dummyFunc2Core1(BYTE a)
{
    gsFtlDbg.u16DummyFailType=cDummyFunc2Core1;
    debugWhile();
}

WORD dummyFunc3Core1(WORD a, WORD b)
{
    gsFtlDbg.u16DummyFailType=cDummyFunc3Core1;
    debugWhile();
    return 0;
}

BYTE dummyFunc4Core1()
{
    gsFtlDbg.u16DummyFailType=cDummyFunc4Core1;
    debugWhile();
    return 0;
}

void dummyFunc5Core1(WORD a, WORD b)
{
    gsFtlDbg.u16DummyFailType=cDummyFunc5Core1;
    debugWhile();
}

#if _PRJ_BOOTC1
void(*const codeFuncPtrCore1[]) (void)=
{
    core1Boot,
    modifyH2FtabBootCore1,
    chkPostReadFifo,
    dummyFuncCore1,    // markBadBlock,
    dummyFuncCore1,    // modifyH2FtabCore1,
    dummyFuncCore1,    // getGcSrcBlk,
    saveWproBadInfo,
    dummyFuncCore1,    // doRaidDecode,
};

void(*const codeFuncPtr2Core1[]) (BYTE)=
{
    dummyFunc2Core1,    // funcTskVendorOp,
    dummyFunc2Core1,    // funcTskEraseUnitProc,
    funcTskProgFwDlTempIspBlock,
    funcTskActivateIsp,
    funcTskJudgeSwapIsp,
    funcTskChkIspBlock,
    funcTskSwapFwSlotIsp,
    funcTskLoadIspPage,
    dummyFunc2Core1,    // chkPfFblock,
    dummyFunc2Core1,    // chkPWRCore1,
    dummyFunc2Core1,    // cfuncTskLoadTelemetryCtlrLog
    dummyFunc2Core1,    // funcTskEraseUnitStart,
    dummyFunc2Core1,    // funcTskEraseUnitContinue,
};

WORD(*const codeFuncPtr3Core1[]) (WORD, WORD)=
{
    dummyFunc3Core1,
};

BYTE(*const codeFuncPtr4Core1[]) (void)=
{
    recoverFlashReg,
    dummyFunc4Core1,
    dummyFunc4Core1,
};

void(*const codeFuncPtr5Core1[]) (WORD, WORD)=
{
    dummyFunc5Core1,
    dummyFunc5Core1,
};

#endif/* if _PRJ_BOOT */

#if _PRJ_ISPC1
void(*const codeFuncPtrCore1[]) (void)=
{
    dummyFuncCore1,    // core1Boot,
    dummyFuncCore1,    // modifyH2FtabBootCore1,
    dummyFuncCore1,    // chkPostReadFifo,
    dummyFuncCore1,    // markBadBlock,
    modifyH2FtabCore1,
    getGcSrcBlk,
    dummyFuncCore1,    // saveWproBadInfo,
    dummyFuncCore1,    // doRaidDecode,
};

void(*const codeFuncPtr2Core1[]) (BYTE)=
{
    dummyFunc2Core1,    // funcTskVendorOp,
    dummyFunc2Core1,    // funcTskEraseUnitProc,
    dummyFunc2Core1,    // funcTskProgFwDlTempIspBlock,
    dummyFunc2Core1,    // funcTskActivateIsp,
    dummyFunc2Core1,    // funcTskJudgeSwapIsp,
    dummyFunc2Core1,    // funcTskChkIspBlock,
    dummyFunc2Core1,    // funcTskSwapFwSlotIsp,
    dummyFunc2Core1,    // funcTskLoadIspPage,
    chkPfFblock,
    chkPWRCore1,
    dummyFunc2Core1,    // cfuncTskLoadTelemetryCtlrLog
    dummyFunc2Core1,    // funcTskEraseUnitStart,
    dummyFunc2Core1,    // funcTskEraseUnitContinue,
};

WORD(*const codeFuncPtr3Core1[]) (WORD, WORD)=
{
    dummyFunc3Core1,
};

BYTE(*const codeFuncPtr4Core1[]) (void)=
{
    dummyFunc4Core1,    // recoverFlashReg,
    dummyFunc4Core1,
    dummyFunc4Core1,
};

void(*const codeFuncPtr5Core1[]) (WORD, WORD)=
{
    dummyFunc5Core1,    // buildValidCachePage,
    dummyFunc5Core1,
};
#endif/* if _PRJ_ISP */

#if _PRJ_NVMEC1
void(*const codeFuncPtrCore1[]) (void)=
{
    dummyFuncCore1,    // core1Boot,
    dummyFuncCore1,    // modifyH2FtabBootCore1,
    dummyFuncCore1,    // chkPostReadFifo,
    dummyFuncCore1,    // markBadBlock,
    dummyFuncCore1,    // modifyH2FtabCore1,
    dummyFuncCore1,    // getGcSrcBlk,
    dummyFuncCore1,    // saveWproBadInfo,
    dummyFuncCore1,    // doRaidDecode,
};

void(*const codeFuncPtr2Core1[]) (BYTE)=
{
    dummyFunc2Core1,    // funcTskVendorOp,
    funcTskEraseUnitProc,
    funcTskProgFwDlTempIspBlock,
    funcTskActivateIsp,
    funcTskJudgeSwapIsp,
    funcTskChkIspBlock,
    funcTskSwapFwSlotIsp,
    funcTskLoadIspPage,
    chkPfFblock,
    dummyFunc2Core1,    // chkPWRCore1,
    funcTskLoadTelemetryCtlrLog,
    funcTskEraseUnitStart,
    funcTskEraseUnitContinue,
};

WORD(*const codeFuncPtr3Core1[]) (WORD, WORD)=
{
    dummyFunc3Core1,
};

BYTE(*const codeFuncPtr4Core1[]) (void)=
{
    recoverFlashReg,
    dummyFunc4Core1,
    dummyFunc4Core1,
};

void(*const codeFuncPtr5Core1[]) (WORD, WORD)=
{
    dummyFunc5Core1,    // buildValidCachePage,
    dummyFunc5Core1,
};

#endif/* if _PRJ_NVME */

#if _PRJ_SMIVUC1
void(*const codeFuncPtrCore1[]) (void)=
{
    dummyFuncCore1,    // core1Boot,
    dummyFuncCore1,    // modifyH2FtabBootCore1,
    dummyFuncCore1,    // chkPostReadFifo,
    dummyFuncCore1,    // markBadBlock,
    dummyFuncCore1,    // modifyH2FtabCore1,
    dummyFuncCore1,    // getGcSrcBlk,
    dummyFuncCore1,    // saveWproBadInfo,
    dummyFuncCore1,    // doRaidDecode,
};

void(*const codeFuncPtr2Core1[]) (BYTE)=
{
    funcTskVendorOp,
    dummyFunc2Core1,    // funcTskEraseUnitProc,
    dummyFunc2Core1,    // funcTskProgFwDlTempIspBlock,
    dummyFunc2Core1,    // funcTskActivateIsp,
    dummyFunc2Core1,    // funcTskJudgeSwapIsp,
    dummyFunc2Core1,    // funcTskChkIspBlock,
    dummyFunc2Core1,    // funcTskSwapFwSlotIsp,
    dummyFunc2Core1,    // funcTskLoadIspPage,
    dummyFunc2Core1,    // chkPfFblock,
    dummyFunc2Core1,    // chkPWRCore1,
    dummyFunc2Core1,    // cfuncTskLoadTelemetryCtlrLog
    dummyFunc2Core1,    // funcTskEraseUnitStart,
    dummyFunc2Core1,    // funcTskEraseUnitContinue,
};

WORD(*const codeFuncPtr3Core1[]) (WORD, WORD)=
{
    dummyFunc3Core1,
};

BYTE(*const codeFuncPtr4Core1[]) (void)=
{
    dummyFunc4Core1,    // recoverFlashReg,
    dummyFunc4Core1,
    dummyFunc4Core1,
};

void(*const codeFuncPtr5Core1[]) (WORD, WORD)=
{
    dummyFunc5Core1,    // buildValidCachePage,
    dummyFunc5Core1,
};

#endif/* if _PRJ_SMIVU */

#if _PRJ_ERRHDLC1
void(*const codeFuncPtrCore1[]) (void)=
{
    dummyFuncCore1,    // core1Boot,
    dummyFuncCore1,    // modifyH2FtabBootCore1,
    dummyFuncCore1,    // chkPostReadFifo,
    markBadBlock,
    dummyFuncCore1,    // modifyH2FtabCore1,
    dummyFuncCore1,    // getGcSrcBlk,
    dummyFuncCore1,    // saveWproBadInfo,
    dummyFuncCore1,    // doRaidDecode,
};

void(*const codeFuncPtr2Core1[]) (BYTE)=
{
    dummyFunc2Core1,    // funcTskVendorOp,
    dummyFunc2Core1,    // funcTskEraseUnitProc,
    dummyFunc2Core1,    // funcTskProgFwDlTempIspBlock,
    dummyFunc2Core1,    // funcTskActivateIsp,
    dummyFunc2Core1,    // funcTskJudgeSwapIsp,
    dummyFunc2Core1,    // funcTskChkIspBlock,
    dummyFunc2Core1,    // funcTskSwapFwSlotIsp,
    dummyFunc2Core1,    // funcTskLoadIspPage,
    chkPfFblock,
    dummyFunc2Core1,    // chkPWRCore1,
    dummyFunc2Core1,    // cfuncTskLoadTelemetryCtlrLog
    dummyFunc2Core1,    // funcTskEraseUnitStart,
    dummyFunc2Core1,    // funcTskEraseUnitContinue,
};

WORD(*const codeFuncPtr3Core1[]) (WORD, WORD)=
{
    dummyFunc3Core1,
};

BYTE(*const codeFuncPtr4Core1[]) (void)=
{
    dummyFunc4Core1,    // recoverFlashReg,
    dummyFunc4Core1,
    dummyFunc4Core1,
};

void(*const codeFuncPtr5Core1[]) (WORD, WORD)=
{
    buildValidCachePage,
    dummyFunc5Core1,
};

#endif/* if _PRJ_ERRHDLC1 */

#pragma default_function_attributes =

#endif    // #ifndef _FUNCPTR_C_







