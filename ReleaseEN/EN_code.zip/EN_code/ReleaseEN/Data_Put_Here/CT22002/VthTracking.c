/* 2016.8.1
put in Typedef.h

typedef struct _vtTracking
{
                BYTE u8arFlashID[6];              // [Input] Flash ID

                //Power on initial (FW Set)
                BYTE ubEnTracking:1;     //[Input] enable or disable
                BYTE ubEnN2RRT:1;                ////[Input] if not set this bit then vth center swill initialize to zero while N4 first loop

                ///Control flag (FW Set)
                BYTE ubFirstLoopInitalize:1;   // [Input], power on or after soft decode
                BYTE ubEnSeparateTrack:1;           // [Input] Enable or disable separate tracking       enable or disable, set when tracking
                BYTE ubEnSeparateUpper:1;          // [Input] Enable or disable separate upper           Up or Down

                //Status Flag
                BYTE ubLowerOverHill:1;                       //[Output]
                BYTE ubUpperOverHill:1;                       //[Output]
                BYTE ubReserved:1;                                //..

                ///Normal Soft Decode
                BYTE u8SoftMode;                  //[Input]                            // [Input] N4: 1,//             N6: 2,//             N8: 3
                BYTE PageKSize;                      //[Input] Decode size (K)
                BYTE u8RetryCnt;                    //[Input] Soft decode
                BYTE u8CurPageType;    //[Input] (1) LSB=0, (2) CSB=1, (3 )MSB=2, (4) SLC=4, (5) SLCPageOnTLC=8, (6) MLCPageOnTLC=12
                BYTE u8SoftNLoop;                 //[Output] update by tracking function, // initial from "ubFirstLoopInitalize=1"

                ///Tracking
                BYTE u8ActiveCh;
                LWORD g32arZero2OneCnt[(C_MaxSoftMode <<1) + 2 -1]; //[Output] Indirect read LDPC register 0xC4, 0xC5
                LWORD g32arOne2ZeroCnt[(C_MaxSoftMode <<1) + 2 -1]; //[Output] Indirect read LDPC register 0xC2, 0xC3
                LWORD g32arLowerDis[(C_MaxSoftMode <<1) + 2 -1];               //[Output]
                LWORD g32arUpperDis[(C_MaxSoftMode <<1) + 2 -1];               //[Output]

                ///Parameter
                BYTE u8arSoftStep[C_VthRegNum];                       // [Output] It should be updated by tracking function before lower/upper read.
                BYTE u8arTrackVthCenter[C_VthRegNum];  // [Output] Keep previous tracking result

                //Debug
                LWORD u8arEventLog[8];       // [Output] for debug

 }Tracking;


put in Var.c:
Tracking TrackingPara[C_MaxChNum];


put in Var.h:
extern Tracking TrackingPara[C_MaxChNum];;
//////////////////////////////////
#include "header225/TypeDef.h"
#include "header225/eiaextensions.h"
#include "header225/DRAMExtern.h"
#include "header225/CoreExtern.h"
//////////////////////////////////
*/

#if 0//(!_ENABLE_ECC_TEAM_TRACKING_MODULE)
#include "../ROM/TestCmd.h"
#include "../ROM/header225/Option.h"
#include "../ROM/header225/TypeDef.h"
#include "../ROM/header225/FlashCtrl.h"
#include "../ROM/header225/Const.h"
#include "../ROM/header225/Flash.h"
#include "../ROM/header225/System.h"
#include "../ROM/header225/Var.h"
#include "../ROM/header225/VarBit.h"
#include "../ROM/header225/Struct.h"
#include "../ROM/header225/eiaextensions.h"
#include "../ROM/header225/VthTracking.h"

#pragma CODE("VthTracking")

#define TrackingDebug
#define SLCTrackingLimit 40
#define HynixKV3SLCLimit 32
#define HynixKV4SLCLimit 90
#define HynixTLCTrackingLimit 25
#define TLCTrackingLimit 32
#define HynixKV3ARLimit 10
#define HynixKV4ARLimit 15  ///
#define HynixKV4GRLimit 40  ///
#define HynixF16ARLimit 6
#define BaseCnt 4096
#define TrackStepCnt 6
#define OverHillCount 500
#define TLCSoftStep 10 
#define HTLCSoftStep 7
#define HMLCSoftStep 8
#define  R_LDPC_DSP             ((( volatile unsigned int        *)         0x51200000 ))
#define S_2258 1
#define S_2260 0
#define S_2262 0
#define S_2263 0

#if S_2258
	#define C_LDPC_N4_Mode 0x01
	#define C_LDPC_N6_Mode 0x02
	#define C_LDPC_N8_Mode 0x03
	#define C_LDPC_RdCntBySoftMode(mode) (mode*2+2-1)
#elif S_2260 || S_2262 || S_2263
	#define C_LDPC_N4_Mode 0x02
	#define C_LDPC_N6_Mode 0x04
	#define C_LDPC_N8_Mode 0x06
	#define C_LDPC_RdCntBySoftMode(mode) (mode+1)
#endif


BYTE u8VthLowerShiftStep = 0;
BYTE u8VthUpperShiftStep = 0;
BYTE u8LowerShiftLeft = 0;
BYTE u8UpperShiftLeft = 0;
BYTE u8TLClimit,u8ARlimit,u8GRlimit,u8SLClimit;
BYTE SetSpeciailRR;

#else
#include "inc/TypeDef.h"
#include "inc/Const.h"
#include "inc/table.h"
#include "inc/GlobVarS.h"
#include "inc/GlobVarT.h"
#include "inc/GlobVar1.h"
#include "inc/ProType.h"
#include "inc/Reg.h"
#include "inc/ProType.h"
#include "inc/Mac.h"
#include "inc/BitDef.h"
#include "inc/GreyBox.h"

#if (!_ICE_LOAD_ALL)
#pragma default_function_attributes = @ ".CORE1_CODE"
#endif


#endif

//--------------------------------------------------------------------------------------------
//ECC Team TRACKING MODULE Start
void gChkOverHill(Tracking *TrackingPara)
{
	LWORD u8LowerCnt = 0;
	LWORD u8UpperCnt = 0;
	LWORD  overhill;

	if(( TrackingPara[0].u8arFlashID[0]==0xAD &&  TrackingPara[0].u8arFlashID[1]==0x5A) ||((TrackingPara[0].u8arFlashID[0]==0xEC)&&(TrackingPara[0].u8arFlashID[1]==0x3A))
	||((TrackingPara[0].u8arFlashID[0]==0x9B)&&(TrackingPara[0].u8arFlashID[1]==0x49)))
		overhill=(8*OverHillCount*TrackingPara[0].PageKSize+2*BaseCnt);
	else if((TrackingPara[0].u8arFlashID[0]==0xAD) &&  (TrackingPara[0].u8arFlashID[1]==0x5C) && ((TrackingPara[0].u8arFlashID[2]==0x28)
	||(TrackingPara[0].u8arFlashID[2]==0x29)))   //KV4
		overhill=(300*TrackingPara[0].PageKSize+2*BaseCnt);
	else if(((TrackingPara[0].u8arFlashID[0]==0x98)||(TrackingPara[0].u8arFlashID[0]==0x45)) 
		&& ((TrackingPara[0].u8arFlashID[1]==0x3C)  ||(TrackingPara[0].u8arFlashID[1]==0x3E) 
		||(TrackingPara[0].u8arFlashID[1]==0x3A)||(TrackingPara[0].u8arFlashID[1]==0x48)) ) {  //BiCS3 ,1y 1z
		overhill=(OverHillCount*TrackingPara[0].PageKSize+4*BaseCnt);
	}
	else overhill=(OverHillCount*TrackingPara[0].PageKSize+2*BaseCnt);

	
	TrackingPara[0].ubLowerOverHill=0;
	TrackingPara[0].ubUpperOverHill=0;
	
	u8LowerCnt = TrackingPara[0].g32arLowerDis[0]+TrackingPara[0].g32arLowerDis[1];
	u8UpperCnt =  TrackingPara[0].g32arUpperDis[0]+TrackingPara[0].g32arUpperDis[1];

	
	//SLC not included
	if((TrackingPara[0].u8CurPageType<4)||(TrackingPara[0].u8CurPageType>=12)){
		if(u8LowerCnt>overhill    ) //if lower overhill then upper overhill
		{
			TrackingPara[0].ubLowerOverHill= 1;
			TrackingPara[0].ubUpperOverHill= 1;
		}
		if(u8UpperCnt>overhill)
		{
			TrackingPara[0].ubUpperOverHill= 1;
		}
	}
}

void gFirstInitial(Tracking *TrackingPara)
{
	BYTE u8Cnt;//BYTE u8softMode,u8Cnt;

	SetSpeciailRR=0;
	if(TrackingPara[0].u8SoftMode<C_LDPC_N8_Mode ) {TrackingPara[0].u8SoftNLoop=1;}		
	else {
		 //bics3, KV4
		if((((TrackingPara[0].u8arFlashID[0]==0x98)||(TrackingPara[0].u8arFlashID[0]==0x45)) && ((TrackingPara[0].u8arFlashID[1]==0x3C)  ||(TrackingPara[0].u8arFlashID[1]==0x3E) 
		||(TrackingPara[0].u8arFlashID[1]==0x3A)||(TrackingPara[0].u8arFlashID[1]==0x48))) ||((TrackingPara[0].u8arFlashID[0]==0xAD)&&(TrackingPara[0].u8arFlashID[1]==0x5C)&&((TrackingPara[0].u8arFlashID[2]==0x28)||(TrackingPara[0].u8arFlashID[2]==0x29)))
		&&(TrackingPara[0].u8CurPageType<4))  //for TLC
			 TrackingPara[0].u8SoftNLoop=15;
		else  TrackingPara[0].u8SoftNLoop=10;
	}	

		
//////////////////soft step setting///////////////////////////////////////////////////////
	if(TrackingPara[0].u8arFlashID[0]==0xAD){//Hynix
		for(u8Cnt=0;u8Cnt<C_VthRegNum;u8Cnt++){	
			if(TrackingPara[0].u8arFlashID[1]==0x5A) TrackingPara[0].u8arSoftStep[u8Cnt]=HMLCSoftStep; //KV2
			else if((TrackingPara[0].u8arFlashID[1]==0x5C) && ((TrackingPara[0].u8arFlashID[2]==0x28)||(TrackingPara[0].u8arFlashID[2]==0x29))){  //Hynix V4
				if(u8Cnt==6 )TrackingPara[0].u8arSoftStep[u8Cnt]=TLCSoftStep;
				else TrackingPara[0].u8arSoftStep[u8Cnt]=HTLCSoftStep;
			}
			else TrackingPara[0].u8arSoftStep[u8Cnt]=HTLCSoftStep;
		}	
		if(TrackingPara[0].u8arFlashID[1]==0x5C){			
			TrackingPara[0].u8arSoftStep[7]=8; //KV3 SLC soft step=8
		}	
	}
	else if(((TrackingPara[0].u8arFlashID[0]==0xEC)&&(TrackingPara[0].u8arFlashID[1]==0x3A))
		||((TrackingPara[0].u8arFlashID[0]==0x9B)&&(TrackingPara[0].u8arFlashID[1]==0x49))){   //SS14nm , YMTC MLC
		for(u8Cnt=0;u8Cnt<C_VthRegNum;u8Cnt++){	
			TrackingPara[0].u8arSoftStep[u8Cnt]=HMLCSoftStep; 
		}
	}
	else{
		for(u8Cnt=0;u8Cnt<C_VthRegNum;u8Cnt++){
			TrackingPara[0].u8arSoftStep[u8Cnt]=TLCSoftStep; 
		}
	}	
/////////N4 reset tracking center/////////////////////////////////////////////////////////
	if(TrackingPara[0].u8SoftMode==C_LDPC_N4_Mode  && (!TrackingPara[0].ubEnN2RRT)  && (TrackingPara[0].ubEnTracking)){//N4 reset vthcenter
		if(TrackingPara[0].u8arFlashID[0]==0xAD && TrackingPara[0].u8arFlashID[1]!=0x5A   ){

			if(!TrackingPara[0].u8CurPageType){
				TrackingPara[0].u8arTrackVthCenter[2]=0;
				TrackingPara[0].u8arTrackVthCenter[6]=0;
			}
			else if(TrackingPara[0].u8CurPageType==1){
				TrackingPara[0].u8arTrackVthCenter[1]=0;
				TrackingPara[0].u8arTrackVthCenter[3]=0;
				TrackingPara[0].u8arTrackVthCenter[5]=0;
			}
			else if(TrackingPara[0].u8CurPageType==2){
				TrackingPara[0].u8arTrackVthCenter[0]=0;
				TrackingPara[0].u8arTrackVthCenter[4]=0;
			}	
			else if(TrackingPara[0].u8CurPageType==4 ){
				if( TrackingPara[0].u8arFlashID[1]==0x5C ) {TrackingPara[0].u8arTrackVthCenter[7]=0;} //KV3 SLC
				else if( TrackingPara[0].u8arFlashID[1]==0x3d) {TrackingPara[0].u8arTrackVthCenter[8]=0;} //F16 SLC
			
			}
			else if(TrackingPara[0].u8CurPageType==8){
				 if( TrackingPara[0].u8arFlashID[1]==0x3d) {TrackingPara[0].u8arTrackVthCenter[7]=0;} //F16 SLC on TLC WL
			}		
		}
		else if((TrackingPara[0].u8arFlashID[0]==0xAD && TrackingPara[0].u8arFlashID[1]==0x5A )
			||((TrackingPara[0].u8arFlashID[0]==0xEC)&&(TrackingPara[0].u8arFlashID[1]==0x3A))
			||((TrackingPara[0].u8arFlashID[0]==0x9B)&&(TrackingPara[0].u8arFlashID[1]==0x49))){
			
			if(!TrackingPara[0].u8CurPageType){
				TrackingPara[0].u8arTrackVthCenter[1]=0;
			}
			else if(TrackingPara[0].u8CurPageType==2){
				TrackingPara[0].u8arTrackVthCenter[0]=0;
				TrackingPara[0].u8arTrackVthCenter[2]=0;
			}	
			else if(TrackingPara[0].u8CurPageType==4 ){
				 TrackingPara[0].u8arTrackVthCenter[3]=0;
			}	
		}
		else{
			if(!TrackingPara[0].u8CurPageType){
				TrackingPara[0].u8arTrackVthCenter[0]=0;
				TrackingPara[0].u8arTrackVthCenter[4]=0;
			}
			else if(TrackingPara[0].u8CurPageType==1){
				TrackingPara[0].u8arTrackVthCenter[1]=0;
				TrackingPara[0].u8arTrackVthCenter[3]=0;
				TrackingPara[0].u8arTrackVthCenter[5]=0;
			}
			else if(TrackingPara[0].u8CurPageType==2){
				TrackingPara[0].u8arTrackVthCenter[2]=0;
				TrackingPara[0].u8arTrackVthCenter[6]=0;
			}
			else if(TrackingPara[0].u8CurPageType==4){
				TrackingPara[0].u8arTrackVthCenter[7]=0;
			}
		}
	}
	TrackingPara[0].ubFirstLoopInitalize=0;

}

void gCntHistogram(Tracking *TrackingPara)
{
	BYTE u8Cnt;
	BYTE u8readcnt;	

	u8readcnt= C_LDPC_RdCntBySoftMode(TrackingPara[0].u8SoftMode) ;
	
	if(!TrackingPara[0].u8RetryCnt){
		for(u8Cnt=0;u8Cnt<7;u8Cnt++){
			TrackingPara[0].g32arZero2OneCnt[u8Cnt]=0;
			TrackingPara[0].g32arOne2ZeroCnt[u8Cnt]=0;
			TrackingPara[0].g32arLowerDis[u8Cnt]=0;
			TrackingPara[0].g32arUpperDis[u8Cnt]=0;		
		}
	}
	else if(TrackingPara[0].u8RetryCnt<3){

		#if S_2258
			TrackingPara[0].g32arZero2OneCnt[TrackingPara[0].u8RetryCnt-1] = ((Ldpc_Rd(0,0xC2,1)<<16)|Ldpc_Rd(0,0xC3,1));
			TrackingPara[0].g32arOne2ZeroCnt[TrackingPara[0].u8RetryCnt-1] = ((Ldpc_Rd(0,0xC4,1)<<16)|Ldpc_Rd(0,0xC5,1));
		#elif S_2260 || S_2262 || S_2263
			//TrackingPara[0].g32arZero2OneCnt[TrackingPara[0].u8RetryCnt-1] =R_LDPC_DSP[0x8000*TrackingPara[0].u8ActiveCh+0x12]; 
			//TrackingPara[0].g32arOne2ZeroCnt[TrackingPara[0].u8RetryCnt-1] =R_LDPC_DSP[0x8000*TrackingPara[0].u8ActiveCh+0x13];

            TrackingPara[0].g32arZero2OneCnt[TrackingPara[0].u8RetryCnt-1] = (readDataInLdpc(0, rcLdpc0to1Counter, 1));
            TrackingPara[0].g32arOne2ZeroCnt[TrackingPara[0].u8RetryCnt-1] = (readDataInLdpc(0, rcLdpc1to0Counter, 1));
		#endif
		
		if(Mod(TrackingPara[0].u8RetryCnt,2)==1){
			TrackingPara[0].g32arUpperDis[TrackingPara[0].u8RetryCnt-1]= TrackingPara[0].g32arOne2ZeroCnt[TrackingPara[0].u8RetryCnt-1]+ BaseCnt;
			TrackingPara[0].g32arLowerDis[TrackingPara[0].u8RetryCnt-1]= TrackingPara[0].g32arZero2OneCnt[TrackingPara[0].u8RetryCnt-1]+ BaseCnt;
		}
		else{
			TrackingPara[0].g32arUpperDis[TrackingPara[0].u8RetryCnt-1]= TrackingPara[0].g32arZero2OneCnt[TrackingPara[0].u8RetryCnt-1]+ BaseCnt;
			TrackingPara[0].g32arLowerDis[TrackingPara[0].u8RetryCnt-1]= TrackingPara[0].g32arOne2ZeroCnt[TrackingPara[0].u8RetryCnt-1]+ BaseCnt;
		}
		
	}
	else{
		#if S_2258
			TrackingPara[0].g32arZero2OneCnt[TrackingPara[0].u8RetryCnt-1] = ((Ldpc_Rd(0,0xC2,1)<<16)|Ldpc_Rd(0,0xC3,1));
			TrackingPara[0].g32arOne2ZeroCnt[TrackingPara[0].u8RetryCnt-1] = ((Ldpc_Rd(0,0xC4,1)<<16)|Ldpc_Rd(0,0xC5,1));
		#elif S_2260 || S_2262 || S_2263
			//TrackingPara[0].g32arZero2OneCnt[TrackingPara[0].u8RetryCnt-1] =R_LDPC_DSP[0x8000*TrackingPara[0].u8ActiveCh+0x12]; 
			//TrackingPara[0].g32arOne2ZeroCnt[TrackingPara[0].u8RetryCnt-1] =R_LDPC_DSP[0x8000*TrackingPara[0].u8ActiveCh+0x13];

            TrackingPara[0].g32arZero2OneCnt[TrackingPara[0].u8RetryCnt-1] = (readDataInLdpc(0, rcLdpc0to1Counter, 1));
            TrackingPara[0].g32arOne2ZeroCnt[TrackingPara[0].u8RetryCnt-1] = (readDataInLdpc(0, rcLdpc1to0Counter, 1));
		#endif
		
		if(Mod(TrackingPara[0].u8RetryCnt,2)==1){
			TrackingPara[0].g32arUpperDis[TrackingPara[0].u8RetryCnt-1]= TrackingPara[0].g32arOne2ZeroCnt[TrackingPara[0].u8RetryCnt-1]-TrackingPara[0].g32arOne2ZeroCnt[TrackingPara[0].u8RetryCnt-3]+ BaseCnt;
			TrackingPara[0].g32arLowerDis[TrackingPara[0].u8RetryCnt-1]= TrackingPara[0].g32arZero2OneCnt[TrackingPara[0].u8RetryCnt-1]-TrackingPara[0].g32arZero2OneCnt[TrackingPara[0].u8RetryCnt-3]+ BaseCnt;
		}
		else{
			TrackingPara[0].g32arUpperDis[TrackingPara[0].u8RetryCnt-1]= TrackingPara[0].g32arZero2OneCnt[TrackingPara[0].u8RetryCnt-1]-TrackingPara[0].g32arZero2OneCnt[TrackingPara[0].u8RetryCnt-3]+ BaseCnt;
			TrackingPara[0].g32arLowerDis[TrackingPara[0].u8RetryCnt-1]= TrackingPara[0].g32arOne2ZeroCnt[TrackingPara[0].u8RetryCnt-1]-TrackingPara[0].g32arOne2ZeroCnt[TrackingPara[0].u8RetryCnt-3]+ BaseCnt;
		}
	}
	////////////////////////////////////////////////////////////////////////////////
	//CSB:     BR/2,FR/2
	if(TrackingPara[0].u8CurPageType==1 && (!TrackingPara[0].ubEnSeparateTrack) &&  TrackingPara[0].u8RetryCnt==u8readcnt-1){
		for(u8Cnt=0;u8Cnt<6;u8Cnt++){
			TrackingPara[0].g32arLowerDis[u8Cnt]>>=1;
		}
	}
}

void gCntShift(Tracking *TrackingPara)
{
	BYTE  u8softMode,u8Cnt,u8readcnt,u8gSoftStep;
	WORD u16offsettmp;
	WORD u8stepcnt;
	if(((TrackingPara[0].u8arFlashID[0]==0xAD &&  TrackingPara[0].u8arFlashID[1]==0x5A)  ) ){u8stepcnt=Div((TrackStepCnt*TrackingPara[0].PageKSize*3), 2);}
	else if((TrackingPara[0].u8arFlashID[0]==0xEC)&&(TrackingPara[0].u8arFlashID[1]==0x3A)){  //SS14nm
		if(TrackingPara[0].u8CurPageType==4) {u8stepcnt=Div((TrackStepCnt*TrackingPara[0].PageKSize), 10);}
		else {u8stepcnt=Div((TrackStepCnt*TrackingPara[0].PageKSize), 20);}
	}
	else if((TrackingPara[0].u8arFlashID[0]==0xAD) &&  (TrackingPara[0].u8arFlashID[1]==0x5C) && ((TrackingPara[0].u8arFlashID[2]==0x28)
	||(TrackingPara[0].u8arFlashID[2]==0x29))){  //KV4   
		if(TrackingPara[0].u8CurPageType==1)  u8stepcnt=Div((3*TrackStepCnt*TrackingPara[0].PageKSize), 2);	 //CSB
		else u8stepcnt=Div((3*TrackStepCnt*TrackingPara[0].PageKSize), 5);
	}
	else if((TrackingPara[0].u8arFlashID[0]==0x9B)&&(TrackingPara[0].u8arFlashID[1]==0x49))  {u8stepcnt=Div((TrackStepCnt*TrackingPara[0].PageKSize), 2);}
	else if((TrackingPara[0].u8arFlashID[0]==0xEC)&&(TrackingPara[0].u8arFlashID[1]==0x1E)) {u8stepcnt=Div((TrackStepCnt*TrackingPara[0].PageKSize), 2);}
	else if((((TrackingPara[0].u8arFlashID[0]==0x98)||(TrackingPara[0].u8arFlashID[0]==0x45)) && ((TrackingPara[0].u8arFlashID[1]==0x3C)  ||(TrackingPara[0].u8arFlashID[1]==0x3E) 
		||(TrackingPara[0].u8arFlashID[1]==0x3A)||(TrackingPara[0].u8arFlashID[1]==0x48)))&&(TrackingPara[0].u8CurPageType>=12))  {
		u8stepcnt=Div((TrackStepCnt*TrackingPara[0].PageKSize),2);//BiCS pMLC
	}	 
	else {u8stepcnt=TrackStepCnt*TrackingPara[0].PageKSize;}	


	#if S_2258
		u8softMode= TrackingPara[0].u8SoftMode;  //input N4:1, N6:2, N8:3
	#elif S_2260 || S_2262 || S_2263
		u8softMode= TrackingPara[0].u8SoftMode/2;   //input N4:2, N6:4, N8:6
	#endif
	
	u8readcnt= C_LDPC_RdCntBySoftMode(TrackingPara[0].u8SoftMode) ;
	
	
	u8VthLowerShiftStep = 0;
	u8VthUpperShiftStep = 0;
 	u8LowerShiftLeft = 0;
	u8UpperShiftLeft = 0;		
	if(!(TrackingPara[0].ubEnSeparateTrack)){
		if(TrackingPara[0].u8SoftMode<C_LDPC_N8_Mode  && TrackingPara[0].u8SoftNLoop>=1 ){
			TrackingPara[0].u8SoftNLoop-=1;
		}
		else if(TrackingPara[0].u8SoftMode==C_LDPC_N8_Mode  && (TrackingPara[0].u8SoftNLoop>=1)){
			TrackingPara[0].u8SoftNLoop-=1;
			for(u8Cnt=0;u8Cnt<C_VthRegNum;u8Cnt++){
				if(TrackingPara[0].u8SoftNLoop==6){				
					TrackingPara[0].u8arSoftStep[u8Cnt]-=1;		
				}
				else if(TrackingPara[0].u8SoftNLoop==2){
					TrackingPara[0].u8arSoftStep[u8Cnt]-=1;	
				}
			}
		}
	}
	gChkOverHill(&TrackingPara[0]);	
	if(TrackingPara[0].g32arZero2OneCnt[u8readcnt-2]<TrackingPara[0].g32arOne2ZeroCnt[u8readcnt-3])
			u8UpperShiftLeft = 0;	
	else
			u8UpperShiftLeft = 1;

	if(TrackingPara[0].g32arOne2ZeroCnt[u8readcnt-2]<TrackingPara[0].g32arZero2OneCnt[u8readcnt-3])
			u8LowerShiftLeft = 0;	
	else
			u8LowerShiftLeft = 1;	

	
	if(TrackingPara[0].ubLowerOverHill) {u8LowerShiftLeft = 1;}
	if(TrackingPara[0].ubUpperOverHill) {u8UpperShiftLeft= 1;}
	////////////////////////////////////////////////////////////////////////////////
	if(u8softMode>0){
		
		if(TrackingPara[0].u8CurPageType<4) {u8gSoftStep=TrackingPara[0].u8arSoftStep[0];}
		else if(TrackingPara[0].u8CurPageType==4){				
			if(TrackingPara[0].u8arFlashID[0]==0xAD && TrackingPara[0].u8arFlashID[1]==0x3d){
				u8gSoftStep=TrackingPara[0].u8arSoftStep[8];
			}
			else if(((TrackingPara[0].u8arFlashID[0]==0xEC)&&(TrackingPara[0].u8arFlashID[1]==0x3A))
				||((TrackingPara[0].u8arFlashID[0]==0x9B)&&(TrackingPara[0].u8arFlashID[1]==0x49))){   //SS14nm, YMTC
				u8gSoftStep=10;
			}
			else{
				u8gSoftStep=TrackingPara[0].u8arSoftStep[7];
			}
		}
		else if(TrackingPara[0].u8CurPageType==8){
			if(TrackingPara[0].u8arFlashID[0]==0xAD && TrackingPara[0].u8arFlashID[1]==0x3d){
				u8gSoftStep=TrackingPara[0].u8arSoftStep[7];
			}
		}	
		else if(TrackingPara[0].u8CurPageType>=12) u8gSoftStep=10;

				  
		if(u8LowerShiftLeft){
			u16offsettmp = Div((TrackingPara[0].g32arLowerDis[1] -TrackingPara[0].g32arLowerDis[0]), u8stepcnt);
	
			if(TrackingPara[0].u8CurPageType<4) u16offsettmp=Div(u16offsettmp,u8softMode);
 
			if(u16offsettmp>u8gSoftStep  ) u16offsettmp=u8gSoftStep;
			u8VthLowerShiftStep-=u16offsettmp;
		}
		else{
			u16offsettmp = Div((TrackingPara[0].g32arLowerDis[0] -TrackingPara[0].g32arLowerDis[1]), u8stepcnt);
 
			if(TrackingPara[0].u8CurPageType<4) u16offsettmp=Div(u16offsettmp, u8softMode);	
			
			if(u16offsettmp>u8gSoftStep  ) u16offsettmp=u8gSoftStep;
			u8VthLowerShiftStep+=u16offsettmp;
			
		}
		//if(TrackingPara[0].ubLowerOverHill) {u8VthLowerShiftStep-=u8gSoftStep;}
		///////////////////////////////////////
		if(u8UpperShiftLeft){
			u16offsettmp=Div((TrackingPara[0].g32arUpperDis[1] -TrackingPara[0].g32arUpperDis[0]), u8stepcnt);
 
			if(TrackingPara[0].u8CurPageType<4) u16offsettmp = Div(u16offsettmp, u8softMode);
			
			if(u16offsettmp>u8gSoftStep ) u16offsettmp=u8gSoftStep;
			u8VthUpperShiftStep-=u16offsettmp;
		}
		else{
			u16offsettmp=Div((TrackingPara[0].g32arUpperDis[0] -TrackingPara[0].g32arUpperDis[1]), u8stepcnt);
 
			if(TrackingPara[0].u8CurPageType<4) u16offsettmp = Div(u16offsettmp,u8softMode);
			
			if(u16offsettmp>u8gSoftStep  ) u16offsettmp=u8gSoftStep;
			u8VthUpperShiftStep+=u16offsettmp;
		}
		if(TrackingPara[0].ubUpperOverHill) {u8VthUpperShiftStep-=u8gSoftStep;}
     }

}

void gUpdateVthCenter(Tracking *TrackingPara)
{

	if(TrackingPara[0].u8CurPageType==0){  //LSB
			if(TrackingPara[0].u8arFlashID[0]==0xAD){
				if(TrackingPara[0].u8arFlashID[1]==0x5A){//KV2
					TrackingPara[0].u8arTrackVthCenter[1]+=u8VthLowerShiftStep;
				}
				else{
					TrackingPara[0].u8arTrackVthCenter[2]+=u8VthLowerShiftStep;
					TrackingPara[0].u8arTrackVthCenter[6]+=u8VthUpperShiftStep;
				}
			}
			else if(((TrackingPara[0].u8arFlashID[0]==0xEC)&&(TrackingPara[0].u8arFlashID[1]==0x3A))
				||((TrackingPara[0].u8arFlashID[0]==0x9B)&&(TrackingPara[0].u8arFlashID[1]==0x49))){   //SS14nm, YMTC
				TrackingPara[0].u8arTrackVthCenter[1]+=u8VthLowerShiftStep;	
			}
			else{
				TrackingPara[0].u8arTrackVthCenter[0]+=u8VthLowerShiftStep;
				TrackingPara[0].u8arTrackVthCenter[4]+=u8VthUpperShiftStep;
			}
		}
		else if(TrackingPara[0].u8CurPageType==1){//CSB

			if(TrackingPara[0].ubEnSeparateTrack){		
				if(TrackingPara[0].ubEnSeparateUpper){				
					TrackingPara[0].u8arTrackVthCenter[5] += u8VthLowerShiftStep;	
					TrackingPara[0].u8arTrackVthCenter[3] += u8VthUpperShiftStep;								
				}	
				else{		
					TrackingPara[0].u8arTrackVthCenter[1] += u8VthLowerShiftStep;	
					TrackingPara[0].u8arTrackVthCenter[3] += u8VthUpperShiftStep;													
				 }	
				TrackingPara[0].ubEnSeparateTrack=0;
			}
			else{
				if(u8LowerShiftLeft){					
					u8VthLowerShiftStep = 0 - (((BYTE)(0 - u8VthLowerShiftStep))>>1);							
				}
				else{		
					u8VthLowerShiftStep= u8VthLowerShiftStep>>1;
				}
				TrackingPara[0].u8arTrackVthCenter[1]+=u8VthLowerShiftStep;
				TrackingPara[0].u8arTrackVthCenter[3]+=u8VthUpperShiftStep;
				TrackingPara[0].u8arTrackVthCenter[5]+=u8VthLowerShiftStep;		
			}
				
		}
		else if(TrackingPara[0].u8CurPageType==2){//MSB
			if(TrackingPara[0].u8arFlashID[0]==0xAD){
				if(TrackingPara[0].u8arFlashID[1]==0x5A){
					TrackingPara[0].u8arTrackVthCenter[0]+=u8VthLowerShiftStep;
					TrackingPara[0].u8arTrackVthCenter[2]+=u8VthUpperShiftStep;
				}
				else{
					TrackingPara[0].u8arTrackVthCenter[0]+=u8VthLowerShiftStep;
					TrackingPara[0].u8arTrackVthCenter[4]+=u8VthUpperShiftStep;
				}
			}
			else if(((TrackingPara[0].u8arFlashID[0]==0xEC)&&(TrackingPara[0].u8arFlashID[1]==0x3A))
				||((TrackingPara[0].u8arFlashID[0]==0x9B)&&(TrackingPara[0].u8arFlashID[1]==0x49))){   //SS14nm, YMTC
				TrackingPara[0].u8arTrackVthCenter[0]+=u8VthLowerShiftStep;
				TrackingPara[0].u8arTrackVthCenter[2]+=u8VthUpperShiftStep;
			}			
			else{
				TrackingPara[0].u8arTrackVthCenter[2]+=u8VthLowerShiftStep;
				TrackingPara[0].u8arTrackVthCenter[6]+=u8VthUpperShiftStep;
			}
		}
		else if(TrackingPara[0].u8CurPageType==4){//SLC	
			 if(TrackingPara[0].u8arFlashID[0]==0xAD && TrackingPara[0].u8arFlashID[1]==0x3d){		
				TrackingPara[0].u8arTrackVthCenter[8]+=u8VthLowerShiftStep;
			}
			 else  if((TrackingPara[0].u8arFlashID[0]==0xAD && TrackingPara[0].u8arFlashID[1]==0x5A)
			 ||(TrackingPara[0].u8arFlashID[0]==0xEC && TrackingPara[0].u8arFlashID[1]==0x3A)
			 ||((TrackingPara[0].u8arFlashID[0]==0x9B)&&(TrackingPara[0].u8arFlashID[1]==0x49))){		//KV3, SS14nm, YMTC
				TrackingPara[0].u8arTrackVthCenter[3]+=u8VthLowerShiftStep;
			}
			 else{
				TrackingPara[0].u8arTrackVthCenter[7]+=u8VthLowerShiftStep;
			}
		}
		else if(TrackingPara[0].u8CurPageType==8){//SLC on TLC WL	

			 if((TrackingPara[0].u8arFlashID[0]==0xAD && TrackingPara[0].u8arFlashID[1]==0x3d)
			 ||(TrackingPara[0].u8arFlashID[0]==0xEC && TrackingPara[0].u8arFlashID[1]==0x1E)){   //SS V4 TLC		
				TrackingPara[0].u8arTrackVthCenter[7]+=u8VthLowerShiftStep;
			}
		}
		else if(TrackingPara[0].u8CurPageType==12){//MLC on TLC WL	
			//if(TrackingPara[0].u8arFlashID[0]==0xEC && TrackingPara[0].u8arFlashID[1]==0x1E){   //SS V4 TLC		
			
				TrackingPara[0].u8arTrackVthCenter[1]+=u8VthLowerShiftStep;
			//}
			}
		else if(TrackingPara[0].u8CurPageType==13){//MLC on TLC WL
			//if(TrackingPara[0].u8arFlashID[0]==0xEC && TrackingPara[0].u8arFlashID[1]==0x1E){   //SS V4 TLC		
				TrackingPara[0].u8arTrackVthCenter[0]+=u8VthLowerShiftStep;
				TrackingPara[0].u8arTrackVthCenter[2]+=u8VthUpperShiftStep;
			//}
		}
}

void gSetLimitation(Tracking *TrackingPara)
{
	BYTE u8Cnt;
	if(TrackingPara[0].u8arFlashID[0]==0xAD){ 
	 	u8TLClimit=HynixTLCTrackingLimit;
		
		if(TrackingPara[0].u8arFlashID[1]==0x5C){ //KV3
			u8ARlimit=HynixKV3ARLimit;

			if((TrackingPara[0].u8arFlashID[2]==0x28)||(TrackingPara[0].u8arFlashID[2]==0x29)){  //KV4
				u8GRlimit=HynixKV4GRLimit;
				u8ARlimit=HynixKV4ARLimit;
			}

		}
		else if(TrackingPara[0].u8arFlashID[1]==0x3A){//F16
			u8ARlimit=HynixF16ARLimit;
		}
		else if(TrackingPara[0].u8arFlashID[1]==0x5A){//KV2	
			u8ARlimit=40;
			u8TLClimit=36;
		}
		else{
			u8ARlimit=TLCTrackingLimit;
		}
	}
	else if(((TrackingPara[0].u8arFlashID[0]==0xEC)&&(TrackingPara[0].u8arFlashID[1]==0x3A))
		||((TrackingPara[0].u8arFlashID[0]==0x9B)&&(TrackingPara[0].u8arFlashID[1]==0x49))){   //SS14nm,YMTC
		u8ARlimit=40;
	
		if(TrackingPara[0].u8CurPageType==4) u8TLClimit=60;
		else u8TLClimit=38;
	}
	else if(((TrackingPara[0].u8arFlashID[0]==0x98)||(TrackingPara[0].u8arFlashID[0]==0x45)) && ((TrackingPara[0].u8arFlashID[1]==0x3C)  
		||(TrackingPara[0].u8arFlashID[1]==0x3E) ||(TrackingPara[0].u8arFlashID[1]==0x3A)||(TrackingPara[0].u8arFlashID[1]==0x48))  ){    //BiCS3
		if(TrackingPara[0].u8CurPageType<4){
	 	u8TLClimit=TLCTrackingLimit;
		u8ARlimit=30;
	}
		else{  //pMLC mode
			u8TLClimit=2*TLCTrackingLimit;		
			u8ARlimit=40;
		}
	}
	 else{
	 	u8TLClimit=TLCTrackingLimit;
		u8ARlimit=TLCTrackingLimit;
		u8SLClimit=SLCTrackingLimit;
	 }



	 if(0==SetSpeciailRR){

		//AR~GR limitation
		 for(u8Cnt=0;u8Cnt<7;u8Cnt++){ 
			
			//special GR limitation	
			if((TrackingPara[0].u8arFlashID[0]==0xAD)&&(TrackingPara[0].u8arFlashID[1]==0x5C)&&((TrackingPara[0].u8arFlashID[2]==0x28)
			||(TrackingPara[0].u8arFlashID[2]==0x29))&&(u8Cnt==6)){ //KV4 GR

				if(  ( TrackingPara[0].u8arTrackVthCenter[6]>=u8GRlimit)&& (TrackingPara[0].u8arTrackVthCenter[6]<=(256-u8GRlimit) ) ) {
							TrackingPara[0].u8arTrackVthCenter[6]=0;
				}
			}
			else if(!((TrackingPara[0].u8arFlashID[0]==0xAD && TrackingPara[0].u8arFlashID[1]==0x5A)||(TrackingPara[0].u8arFlashID[0]==0xEC && TrackingPara[0].u8arFlashID[1]==0x3A)
			 ||((TrackingPara[0].u8arFlashID[0]==0x9B)&&(TrackingPara[0].u8arFlashID[1]==0x49))))	{
				if( ( TrackingPara[0].u8arTrackVthCenter[u8Cnt]>=u8TLClimit)   &&     (TrackingPara[0].u8arTrackVthCenter[u8Cnt]<=(256-u8TLClimit) ) ){
					TrackingPara[0].u8arTrackVthCenter[u8Cnt]=0;
				}		
			} 
		  }

		 //special AR limitation	
		 if((( TrackingPara[0].u8arTrackVthCenter[0]>=u8TLClimit) &&  (TrackingPara[0].u8arTrackVthCenter[0]<=(256-u8ARlimit) ))){
			TrackingPara[0].u8arTrackVthCenter[0]=0;
		 }
	}
	 
}


void gSetSpecialRR(Tracking *TrackingPara)
{
	//SetSpeciailRR=0;
	
	if(TrackingPara[0].u8CurPageType<4){  //for TLC
		
		if(((TrackingPara[0].u8arFlashID[0]==0x98)||(TrackingPara[0].u8arFlashID[0]==0x45)) 
		&& ((TrackingPara[0].u8arFlashID[1]==0x3C)  ||(TrackingPara[0].u8arFlashID[1]==0x3E) ||(TrackingPara[0].u8arFlashID[1]==0x3A)||(TrackingPara[0].u8arFlashID[1]==0x48))   ){  //BiCS3
			if(TrackingPara[0].u8SoftNLoop==7){

				SetSpeciailRR=1;
				if(TrackingPara[0].u8CurPageType==0){  //LWHR xtemp
					TrackingPara[0].u8arTrackVthCenter[0]=238;
					TrackingPara[0].u8arTrackVthCenter[4]=228;
				}
				else if(TrackingPara[0].u8CurPageType==1){
					TrackingPara[0].u8arTrackVthCenter[1]=228;
					TrackingPara[0].u8arTrackVthCenter[3]=228;
					TrackingPara[0].u8arTrackVthCenter[5]=223;				
				}
				else if(TrackingPara[0].u8CurPageType==2){
					TrackingPara[0].u8arTrackVthCenter[2]=238;
					TrackingPara[0].u8arTrackVthCenter[6]=223;
				}	
				else  SetSpeciailRR=0;
			}
			else if(TrackingPara[0].u8SoftNLoop==3){ //HWLR xtemp

				SetSpeciailRR=1;
				if(TrackingPara[0].u8CurPageType==0){
					TrackingPara[0].u8arTrackVthCenter[0]=22;
					TrackingPara[0].u8arTrackVthCenter[4]=32;
				}
				else if(TrackingPara[0].u8CurPageType==1){
					TrackingPara[0].u8arTrackVthCenter[1]=32;
					TrackingPara[0].u8arTrackVthCenter[3]=32;
					TrackingPara[0].u8arTrackVthCenter[5]=32;				
				}
				else if(TrackingPara[0].u8CurPageType==2){
					TrackingPara[0].u8arTrackVthCenter[2]=30;
					TrackingPara[0].u8arTrackVthCenter[6]=40;
				}	
				else  SetSpeciailRR=0;
			}
		}
		else if((TrackingPara[0].u8arFlashID[0]==0xAD) &&  (TrackingPara[0].u8arFlashID[1]==0x5C) && ((TrackingPara[0].u8arFlashID[2]==0x28)
		||(TrackingPara[0].u8arFlashID[2]==0x29))){  //KV4

			if(TrackingPara[0].u8SoftNLoop==7){
				
				SetSpeciailRR=1;
				if(TrackingPara[0].u8CurPageType==2){ //Data Retention
					TrackingPara[0].u8arTrackVthCenter[0]=248;
					TrackingPara[0].u8arTrackVthCenter[4]=238;
				}
				else if(TrackingPara[0].u8CurPageType==1){
					TrackingPara[0].u8arTrackVthCenter[1]=248;
					TrackingPara[0].u8arTrackVthCenter[3]=238;
					TrackingPara[0].u8arTrackVthCenter[5]=233;				
				}
				else if(TrackingPara[0].u8CurPageType==0){
					TrackingPara[0].u8arTrackVthCenter[2]=238;
					TrackingPara[0].u8arTrackVthCenter[6]=233;
				}	
				else  SetSpeciailRR=0;
			}
			else if(TrackingPara[0].u8SoftNLoop==4){  //Read disturb

				SetSpeciailRR=1;
				if(TrackingPara[0].u8CurPageType==2){  
					TrackingPara[0].u8arTrackVthCenter[0]=12;
					TrackingPara[0].u8arTrackVthCenter[4]=246;
				}
				else if(TrackingPara[0].u8CurPageType==1){
					TrackingPara[0].u8arTrackVthCenter[1]=5;
					TrackingPara[0].u8arTrackVthCenter[3]=248;
					TrackingPara[0].u8arTrackVthCenter[5]=248;				
				}
				else if(TrackingPara[0].u8CurPageType==0){
					TrackingPara[0].u8arTrackVthCenter[2]=0;
					TrackingPara[0].u8arTrackVthCenter[6]=248;
				}	
				else  SetSpeciailRR=0;
			}
			else if(TrackingPara[0].u8SoftNLoop==2){  //Data Retention
				
				SetSpeciailRR=1;
				if(TrackingPara[0].u8CurPageType==2){
					TrackingPara[0].u8arTrackVthCenter[0]=242;
					TrackingPara[0].u8arTrackVthCenter[4]=230;
				}
				else if(TrackingPara[0].u8CurPageType==1){
					TrackingPara[0].u8arTrackVthCenter[1]=238;
					TrackingPara[0].u8arTrackVthCenter[3]=228;
					TrackingPara[0].u8arTrackVthCenter[5]=223;				
				}
				else if(TrackingPara[0].u8CurPageType==0){
					TrackingPara[0].u8arTrackVthCenter[2]=233;
					TrackingPara[0].u8arTrackVthCenter[6]=228;
				}	
				else  SetSpeciailRR=0;
			}		
		}
	}
}


void gLDPC_Vth_tracking(Tracking *TrackingPara)
{
	BYTE u8readcnt;
	
	u8readcnt= C_LDPC_RdCntBySoftMode(TrackingPara[0].u8SoftMode) ;
	
	if(TrackingPara[0].ubFirstLoopInitalize){
		gFirstInitial(&TrackingPara[0]);
	}	
	else{
		if(TrackingPara[0].ubEnTracking)  {gCntHistogram(&TrackingPara[0]);}		
		if(TrackingPara[0].u8RetryCnt==u8readcnt-1  ){ 
			 gCntShift(&TrackingPara[0]);
			 if(TrackingPara[0].ubEnTracking){
				 gUpdateVthCenter(&TrackingPara[0]);	
				 gSetLimitation(&TrackingPara[0]);	
				 gSetSpecialRR(&TrackingPara[0]);	

			
			 }
		}		
	}	
}
//--------------------------------------------------------------------------------------------
//ECC Team TRACKING MODULE End

#if(_ENABLE_ECC_TEAM_TRACKING_MODULE==0)
#pragma CODE()
#else
#if (!_ICE_LOAD_ALL)
#pragma default_function_attributes =
#endif
#endif






