







#include "inc/TypeDef.h"
#include "inc/Option.h"
#include "inc/ProType.h"
#include "inc/Reg.h"
#include "inc/NvmeCtrl.h"
#include "inc/GlobVar0.h"
#include "inc/GlobVarS.h"
#include "inc/GlobVarT.h"

void fillUnknownVendorCmdPattern()
{
    fillCcmVal((BYTE *)&garTsb0[0][0], cSingleSectorByte, cZero);

    garTsb0[0][0x00]='U';
    garTsb0[0][0x01]='N';
    garTsb0[0][0x02]='K';
    garTsb0[0][0x03]='N';
    garTsb0[0][0x04]='O';
    garTsb0[0][0x05]='W';
    garTsb0[0][0x06]='N';

    garTsb0[0][0x10]=rmNvmeSubOpcode;
    g32arTsb0[0][0x20/4]=rmNvmeSubCmdParam0;
    g32arTsb0[0][0x21/4]=rmNvmeSubCmdParam1;
    g32arTsb0[0][0x22/4]=rmNvmeSubCmdParam2;
    g32arTsb0[0][0x23/4]=rmNvmeSubCmdParam3;
}    /* fillUnknownVendorCmdPattern */

void insertVendorTask(BYTE uVndrOpt)
{
    // flashReadPage();
    TASKENTRY usTskEntry;

    usTskEntry.uTskTyp=cTskVendorOp;
    usTskEntry.uTskPgOfst=0;    // core0
    usTskEntry.uTskOpt=uVndrOpt;
    insertTaskFifo(usTskEntry);

    while(gsTskFifoCtrl.u32HeadPtr!=gsTskFifoCtrl.u32TailPtr)
        ;
}

void getNandParam(BYTE uParmAddr, BYTE *upValue)
{
    rmCle(0x37);

    // tRPARAM=100ns
    sysDelay(0x50);
    rmAle(uParmAddr);
    mWaitCmdFifoBz;

    // WE high to RE low for random data out(tWHR) :  120ns
    sysDelay(0x50);

    if(rmChkToggleMo||rmChkOnfi2Mo)
    {
        rmManRd(2);
    }
    else
    {
        rmManRd(1);
    }

    mWaitCmdFifoBz;

    // tRHW
    sysDelay(0x50);
    *upValue=rFLCtrl[rcRd0];
}    /* getNandParam */

void setNandParam(BYTE uParmAddr, BYTE uValue)
{
    rmCle(0X36);
    rmSetSctrAddr(uParmAddr);
    rmManAle(1);

    // Address to data loading time(tADL) : 300ns
    sysDelay(0x150);
    mWaitCmdFifoBz;

    if(rmChkToggleMo||rmChkOnfi2Mo)
    {
        rFLCtrl[rcRd0]=uValue;
        rFLCtrl[rcRd1]=uValue;
        rmManWr(2);
    }
    else
    {
        rmCmdMaskCleAleEnable;
        rmCle(uValue);
        rmCmdMaskCleAleDisable;
    }

    rmCle(0X16);

    // tSPARAM = 100ns
    sysDelay(0x50);
}    /* setNandParam */







