







#include "inc/TypeDef.h"
#include "inc/Option.h"
#include "inc/ProType.h"
#include "inc/Reg.h"

#if (!_ICE_LOAD_ALL)
#pragma default_function_attributes = @ ".HDMA"
#endif

void hdmaClrRam(LWORD u32RamSAddr, LWORD u32Len, LWORD u32Patn, WORD u16Opt)
{
#if _GREYBOX
    if(u32RamSAddr>c32DramAddr)
    {
        for(LWORD u32Loop=0; u32Loop<u32Len; u32Loop+=4)
        {
            *(LWORD *)(u32RamSAddr+u32Loop)=u32Patn;
        }
    }
    else
#endif
    {
        while(rmChkHdmaCmdFifoFull)
            ;

        if(u16Opt&cHdmaWait)
        {
            while(rmChkHdmaBz)
                ;
        }

        rmRstHdmaParam;
        rmSetHdmaFillMo;
        rmRstHdmaInt;
        rmSetHdmaPat(u32Patn);
        rmHdmaDisAutoAes;

        if(u16Opt&cHdmaEnCrc)
        {
            rmEnHdmaCrc;

            if(u16Opt&cHdmaGenCrc)
            {
                rmEnHdmaCrcGen;
                rmSetHdmaAesLba(gsE2eInfo.u32GenerateLba);
                rmSetHdmaAesExtLba(0);
            }
        }
        else
        {
            rmDisHdmaCrc;
        }

        if(u16Opt&cHdmaEnFwAes)
        {
            rmFwAesMode;
            rmHdmaAutoAesXts;
            rmSetHdmaAesLba(gsE2eInfo.u32GenerateLba);
            rmSetHdmaAesExtLba(0);
            rmHdmaAutoAesEnc;
        }

        switch(u16Opt&cLoNibble)
        {
            case cClrTsb:
                // flushDCache();
                rmSetHdmaDataDir(cHdmaBvci2Tsb);
                u32RamSAddr-=c32Tsb0SAddr;
                break;

            case cClrCore0Iccm:
                rmSetHdmaDataDir(cHdmaTsb2Bvci);
                rmSetHdmaCcm;
                rmEnSysBop2Ccm;
                break;

            case cClrCore0Dccm:
                // invalidDCache();
                rmSetHdmaDataDir(cHdmaTsb2Bvci);
                rmSetHdmaCcm;
                rmEnSysBop2Ccm;
                break;

            case cClrCore1Iccm:
                // flushDCache();
                rmSetHdmaDataDir(cHdmaTsb2Bvci);
                rmSetHdmaCcm;
                rmEnSysBop2Ccm;
                break;

            case cClrCore1Dccm:
                rmSetHdmaDataDir(cHdmaTsb2Bvci);
                rmSetHdmaCcm;
                rmEnSysBop2Ccm;
                break;

            case cClrStcm:
                // invalidDCache();
                rmSetHdmaDataDir(cHdmaTsb2Bvci);
                break;

            case cClrDram:
                // flushDCache();
                rmSetHdmaDram;
                rmSetHdmaDataDir(cHdmaTsb2Bvci);
                break;

            default:
                break;
        }    /* switch */

        rmSetHdmaDesAddr(u32RamSAddr);
        rmSetHdmaXfrLen(u32Len);

        if(u16Opt&cHdmaTsbFlag)
        {
            rmDisHdmaWrBypass;

            if(u16Opt&cHdmaRaidFlag)
            {
                rmEnHdmaRaidFlagDes;
            }
        }

        // if (rmChkSysDiv2)        //Is it working? SM2260 spec not description
        // {
        // rmEnHdmaDmaClkSync;  //Is it working? SM2260 spec not description
        // }
        // else
        // {
        // rmDisHdmaDmaClkSync; //Is it working? SM2260 spec not description
        // }

        rmTrigHdmaOp(0, cHdmaDmaOp);

        if(u16Opt&cHdmaWait)
        {
            while(rmChkHdmaBz)
                ;
        }
    }
}    /* hdmaClrRam */

#if (_CPUID==1)
void hdmaCopyRam(LWORD u32RamDAddr, LWORD u32RamSAddr, LWORD u32Len, WORD u16Opt)
{
    while(rmChkHdmaCmdFifoFull)
        ;

    if(u16Opt&cHdmaWait)
    {
        while(rmChkHdmaBz)
            ;
    }

    rmRstHdmaParam;
    rmRstHdmaInt;
    rmHdmaDisAutoAes;

    if(u16Opt&cHdmaEnCrc)
    {
        rmEnHdmaCrc;

        if(u16Opt&cHdmaGenCrc)
        {
            rmEnHdmaCrcGen;
            rmSetHdmaAesLba(gsE2eInfo.u32GenerateLba);
            rmSetHdmaAesExtLba(0);
        }
        else if(u16Opt&cHdmaCmpCrc)
        {
            rmEnHdmaCrcCompare;
            rmSetHdmaAesLba(gsE2eInfo.u32CompareLba);
            rmSetHdmaAesExtLba(0);
        }
    }

    if(u16Opt&cHdmaEnFwAes)
    {
        rmFwAesMode;
        rmHdmaAutoAesXts;
        rmSetHdmaAesLba(gsE2eInfo.u32GenerateLba);
        rmSetHdmaAesExtLba(0);
        rmHdmaAutoAesEnc;
    }

    switch(u16Opt&cLoNibble)
    {
        case cCopyTsb2Tsb:
            rmSetHdmaDataDir(cHdmaTsb2Tsb);
            break;

/*
   *      case cCopyTsb2Dccm:
   *          invalidDCache();
   *          rmSetHdmaDataDir(cHdmaTsb2Bvci);
   *          rmSetHdmaCcm;
   *          rmEnBopToDccm;
   *          break;
   *
   *      case cCopyDccm2Tsb:
   *          flushDCache();
   *          rmSetHdmaDataDir(cHdmaBvci2Tsb);
   *          rmSetHdmaCcm;
   *          rmEnBopToDccm;
   *          break;
   *
   *      case cCopyTsb2Iccm:
   *          rmSetHdmaDataDir(cHdmaTsb2Bvci);
   *          rmSetHdmaCcm;
   *          rmEnBopToIccm;
   *          break;
   *
   *      case cCopyIccm2Tsb:
   *          rmSetHdmaDataDir(cHdmaBvci2Tsb);
   *          rmSetHdmaCcm;
   *          rmEnBopToIccm;
   *          break;
   */
        default:
            break;
    }

    rmSetHdmaSrcAddr(u32RamSAddr);
    rmSetHdmaDesAddr(u32RamDAddr);
    rmSetHdmaXfrLen(u32Len);

    if(u16Opt&cHdmaTsbFlag)
    {
        rmDisHdmaRdBypass;
    }
    else
    {
        rmEnHdmaRdBypass;
    }

    if(u16Opt&cHdmaTsbWriteFlag)
    {
        rmDisHdmaWrBypass;
    }
    else
    {
        rmEnHdmaWrBypass;
    }

    /*
       * if (((uOpt&cLoNibble)>=cCopyTsb2Dccm)&&rmChkSysDiv2)
       * {
       *  rmEnHdmaDmaClkSync;
       * }
       * else
       */
    {
        rmDisHdmaDmaClkSync;
    }

    rmTrigHdmaOp(0, cHdmaDmaOp);

    if(u16Opt&cHdmaWait)
    {
        while(rmChkHdmaBz)
            ;
    }
}    /* hdmaCopyRam */

#if _ENABLE_RAID
////////////////////////////////////////////////
// Updated by Kane, 20170109, 20170222
//
// 1. u32RamSAddr: The start TSB address for Raid encode
//
// 2. u32Len: The byte length for Raid encode
//
// 3. uOpt:
//     [Bit6] cHdmaRaidFlag
//     [Bit5] cHdmaTsbFlag
//     [Bit4] cHdmaWait
//     [Bit3 to Bit0] XfrDir
//
//  4. uRaidOpt:
//     [Bit3 to Bit0] RaidType: Data, Gc, HTab
//
//  5. uPageType: ( Obtain in SetWriteDes() func, and Save in garDesAddrInfo[ ] Que )
//     [Bit7 to Bit4] WordLine Type: 1  (SLC), 2 (MLC), 3 (TLC)
//     [Bit3 to Bit0] Page Type: 1 (LP), 2 (UP), 3 (XP)
//
////////////////////////////////////////////////
void hdmaEncRam(WORD u16BufIdx, WORD u16TotalSctrCnt, WORD u16FPage, WORD u16Opt, BYTE uRaidOpt, BYTE uPageType)
{
    BYTE uSrcFlag=
        (u16Opt&
         cHdmaTsbFlag)?((u16Opt&cHdmaRaidFlag)?cHdmaSrcRaidBufFlag:cHdmaSrcBufFlag):((u16Opt&
                                                                                      cHdmaSrcRaidFlagOnly)?cHdmaSrcRaidFlagOnly:cHdmaSrcNonFlag);
    BYTE uRaidType=uRaidOpt&cLoNibble;
    BYTE uRaidEngIdx=cNull;
    BYTE uPtyIdx, uProgCntPerWL;

    while(u16TotalSctrCnt&(cRaidMinSctrCnt-1))
        ;

    while(u16TotalSctrCnt%mGetRaidSector(uRaidType))
        ;

    if(uRaidType<cRaidHTabBlk)
    {
        if(u16TotalSctrCnt)
        {
            if(uPageType==cSLC)
            {
                uProgCntPerWL=1;
                uPageType=0;
            }
            else
            {
                uProgCntPerWL=cProgCntPerWL;
            }

            u16FPage=u16FPage*uProgCntPerWL+uPageType;
            uPtyIdx=u16FPage&(cRaidParityNum-1);

            if((gsRaidInfo.u16arRaidFPage[uRaidType][uPtyIdx]==c16Null)&&(gsRaidInfo.u16RaidEngBitMap!=cRaidEngFull))
            {
                gsRaidInfo.uarRaidEngIdx[uRaidType][uPtyIdx]=getFreeRaidEngIdx(uRaidType);
                gsRaidInfo.uRaidPopEngCnt++;

                if(gsRaidInfo.uRaidPopEngCnt>gRaidMaxPopEngCnt)
                {
                    gRaidMaxPopEngCnt=gsRaidInfo.uRaidPopEngCnt;

                    while(gRaidMaxPopEngCnt>cRaidTotalEng)
                        ;
                }
            }

            gsRaidInfo.u16arRaidFPage[uRaidType][uPtyIdx]=u16FPage;
            uRaidEngIdx=gsRaidInfo.uarRaidEngIdx[uRaidType][uPtyIdx];

            trigRaidDataEnc(u16BufIdx,
                            u16TotalSctrCnt,
                            uSrcFlag,
                            uRaidEngIdx,
                            uRaidType,
                            gsRaidInfo.u16arRaidEngPgIdx[uRaidEngIdx],
                            gsRaidInfo.uarRaidEngSctrIdx[uRaidEngIdx],
                            cRaidActOptNon,
                            u16Opt&cHdmaWait);

            gsRaidInfo.u16arRaidEngPgIdx[uRaidEngIdx]+=(u16TotalSctrCnt/mGetRaidSector(uRaidType));

            if(gsRaidInfo.u16arRaidEngPgIdx[uRaidEngIdx]==mGetRaidKVal(uRaidType))
            {
                setRaidEngPtyBitMap(uRaidEngIdx);

                if(uRaidType==cRaidDataBlk)
                {
                    g32ParityOut|=cRaidDataPty;
                }
                else if(uRaidType==cRaidGcBlk)
                {
                    g32ParityOut|=cRaidGcPty;
                }
            }
        }
    }

#if _EN_RAID_H2F
    else if(uRaidType==cRaidHTabBlk)
    {
        if(gsRaidInfo.u16RaidEngBitMap!=cRaidEngFull)
        {
            uRaidEngIdx=getFreeRaidEngIdx(cRaidHTabBlk);
        }
        else
        {
            gsFtlDbg.u16DummyFailType=cHdmaEncRam1;
            debugWhile();
        }

        trigRaidDataEnc(u16BufIdx,
                        u16TotalSctrCnt,
                        uSrcFlag,
                        uRaidEngIdx,
                        uRaidType,
                        0,
                        0,
                        cRaidActOptNon,
                        u16Opt&cHdmaWait);
        trigRaidPtyOut(u16BufIdx+u16TotalSctrCnt,
                       cHdmaDesBufFlag,    // cHdmaDesNonFlag,
                       uRaidEngIdx,
                       uRaidType,
                       cRaidActOptPtyClr,
                       u16Opt&cHdmaWait);
        clrRaidEngBitMap(uRaidEngIdx);
    }
#endif/* if _EN_RAID_H2F */
    else
    {
        gsFtlDbg.u16DummyFailType=cHdmaEncRam2;
        debugWhile();
    }
}    /* hdmaEncRam */

////////////////////////////////////////////////
// Updated by Kane, 20170114, 20170119, 20170224
//
// 1. u32RamDAddr: The destination TSB address for Raid pty
//
// 2. uOpt:
//     [Bit6] cHdmaRaidFlag
//     [Bit5] cHdmaTsbFlag
//     [Bit4] cHdmaWait
//     [Bit3 to Bit0] XfrDir
//
// 3. uRaidOpt:
//     [Bit6] cRaid4KPty
//     [Bit5] cRaidPtyClr
//     [Bit3 to Bit0] RaidType: Data, Gc, HTab
//
// 4. uPageType: ( Obtain in SetWriteDes() func, and Save in garDesAddrInfo[ ] Que )
//     [Bit7 to Bit4] WordLine Type: 1  (SLC), 2 (MLC), 3 (TLC)
//     [Bit3 to Bit0] Page Type: 1 (LP), 2 (UP), 3 (XP)
//
////////////////////////////////////////////////
void hdmaGetRaidPty(WORD u16BufIdx, WORD u16Opt, BYTE uRaidOpt, WORD u16FPage, BYTE uPageType)
{
    BYTE uDesFlag=(u16Opt&cHdmaTsbFlag)?((u16Opt&cHdmaRaidFlag)?cHdmaDesRaidFlag:cHdmaDesBufFlag):cHdmaDesNonFlag;
    BYTE uRaidType=uRaidOpt&cLoNibble;
    BYTE uRaidActOpts=(uRaidOpt&cRaidPtyClr)?cRaidActOptPtyClr:cRaidActOptNon;
    BYTE uRaidEngIdx=cNull;
    BYTE uPtyIdx, uProgCntPerWL, uIdx;

    if(uRaidType<cRaidHTabBlk)
    {
        if(uPageType==cSLC)
        {
            uProgCntPerWL=1;
            uPageType=0;
        }
        else
        {
            uProgCntPerWL=cProgCntPerWL;
        }

        u16FPage=u16FPage*uProgCntPerWL+uPageType;
        uPtyIdx=u16FPage&(cRaidParityNum-1);

        if((gsRaidInfo.u16arRaidFPage[uRaidType][uPtyIdx]==u16FPage)&&(mChkRaidEngPtyBmap(gsRaidInfo.uarRaidEngIdx[uRaidType][uPtyIdx])))
        {
            uRaidEngIdx=gsRaidInfo.uarRaidEngIdx[uRaidType][uPtyIdx];
        }

        while(uRaidEngIdx>=cRaidTotalEng)
            ;

        trigRaidPtyOut(u16BufIdx,
                       uDesFlag,
                       uRaidEngIdx,
                       uRaidType,
                       uRaidActOpts,
                       u16Opt&cHdmaWait);

        if(uRaidOpt&cRaidPtyClr)
        {
            clrRaidEngPtyBitMap(uRaidEngIdx);
            clrRaidEngBitMap(uRaidEngIdx);
            gsRaidInfo.u16arRaidEngPgIdx[uRaidEngIdx]=0;
            gsRaidInfo.uarRaidEngSctrIdx[uRaidEngIdx]=0;

            if(uRaidType==cRaidDataBlk)
            {
                if(uPtyIdx==0)
                {
                    for(uIdx=0; uIdx<cRaidParityNum; uIdx++)
                    {
                        gsRaidInfo.uarBkDataRaidEngIdx[uIdx]=cNull;
                    }
                }

                gsRaidInfo.uarBkDataRaidEngIdx[uPtyIdx]=gsRaidInfo.uarRaidEngIdx[uRaidType][uPtyIdx];
            }

            gsRaidInfo.uarRaidEngIdx[uRaidType][uPtyIdx]=cNull;
            gsRaidInfo.u16arRaidFPage[uRaidType][uPtyIdx]=c16Null;
            gsRaidInfo.uRaidPopEngCnt--;

            if(uRaidType==cRaidDataBlk)
            {
                g32ParityOut&=~cRaidDataPty;
            }
            else if(uRaidType==cRaidGcBlk)
            {
                g32ParityOut&=~cRaidGcPty;
            }
        }
    }
    else
    {
        gsFtlDbg.u16DummyFailType=cHdmaGetRaidPty;
        debugWhile();
    }
}    /* hdmaGetRaidPty */

#endif/* if _ENABLE_RAID */
#endif/* if (_CPUID==1) */

#if (!_ICE_LOAD_ALL)
#pragma default_function_attributes =
#endif







