







#include "inc/ProType.h"
// #include "inc/FlashCtrl.h"
#include "inc/GlobVar0.h"
#include "inc/GlobVarS.h"
#include "inc/GlobVarT.h"
#include "inc/Reg.h"
#include "inc/FtlCtrl.h"

void setFakeRead(LWORD u32StartLBA, WORD u16BufIdx, LWORD u32XfrCnt)
{
    // FillEventLog(0x3300);
    // FillEventLog(u32StartLBA>>16);
    // FillEventLog(u32StartLBA);
    // FillEventLog(u16BufIdx);
    // FillEventLog(u32XfrCnt);
    while(rmChkFakeFail)
        ;

    while(rmFakeBusy)
        ;

    rmResetFake;
    rmEnFakeBufFlg;
    rmDisFakeOccFlg;
    // rmDisFakeBvciOccFlg;
    rmFakeRead;
    rmEnFakeCompare;

    // rmDisFakeCompare;
    while(!u32XfrCnt)
        ;

    rmSetFakeRdAddr(u16BufIdx);
    rmSetFakeLBA(u32StartLBA);
    rmSetFakeLen(u32XfrCnt);
    rmDisFakeBvci;
    rmEnFakeTsb;
    rmTrigFake;
}    /* setFakeRead */

void setFakeWrite(WORD u16SetOccFlg, LWORD u32StartLBA, WORD u16BufIdx, LWORD u32SecCnt)
{
    while(!u32SecCnt)
        ;

    while(rmChkFakeFail)
        ;

    while(rmFakeBusy)
        ;

    rmResetFake;
    rmEnFakeBufFlg;
    rmFakeWrite;
    rmDisFakeOccFlg;
    rmDisFakeCompare;

    if(u16SetOccFlg)    // Hank, there is a HW issue with Fake engine
    {
        // rmSetFakeBvciOccSec(((u16BufIdx>>C_SECTOR_PER_UNIT_2N)<<C_SECTOR_PER_UNIT_2N));
        // rmSetFakeTsbOccSec(((u16BufIdx>>C_SECTOR_PER_UNIT_2N)<<C_SECTOR_PER_UNIT_2N));
    }

    // rmSetFakeWrAddr(u16BufIdx);
    rmSetFakeRdAddr(u16BufIdx);

    rmSetFakeLBA(u32StartLBA);
    rmSetFakeLen(u32SecCnt);
    // rmDisFakeTsb;
    // rmEnFakeBvci;
    rmEnFakeTsb;
    rmDisFakeBvci;
    rmTrigFake;
    // rmFakeData2Tsb;
    // setFakeEngine(u32StartLBA, u16BufIdx, u32SecCnt, 1);
}    /* setFakeWrite */

void setFakeEngine(LWORD u32StartLBA, WORD u16BufIdx, LWORD u32XfrCnt, BYTE uWrite)
{
    while(!u32XfrCnt)
        ;

    rmSetFakeRdAddr(u16BufIdx);    // (KT) - Read from Tsb
    rmSetFakeLBA(u32StartLBA);
    rmSetFakeLen(u32XfrCnt);
    rmEnFakeTsb;
    rmDisFakeBvci;
    rmTrigFake;
}

void initFakeEngine()
{
    r32FakeCtrl[0]=0;
    rmPcieNvmeDis;
    // rmFakeScrbEn;
    rmEnFake;

#if 1    // for stupid initial
    rmFakeWrite;
    setFakeEngine(0, 0, 1, 1);

    while(rmFakeBusy)
        ;
#endif
    // rmResetFake;
    rmClrFakeFail;
    rmResetBufFlg;
    // M_RESET_OccupyFlg

    // rmEnBOPCtrlFlg;           //BOP to control Tsb pre-occupy flag
#if 0
    rmEnBOPRefBVFBuf;
    rmEnSataRefBVFBuf;
    rmEnSataRefBVFOcu;
#else    // (JL),20140821, new define in 2260
    rmEnHdmaRefBvfBuf;
    rmEnPcieWrRefBvfBuf;
    rmEnPcieWrRefBvfOcu;
    rmEnPcieRdRefBvfBuf;
    rmEnPcieRdRefBvfOcu;
#endif
    rmHdmaSoftReset;

    rmBopSoftReset;
}    /* initFakeEngine */







