







#include "inc/TypeDef.h"
#include "inc/Option.h"
#include "inc/ProType.h"
#include "inc/Reg.h"
#include "inc/NvmeCtrl.h"
#include "inc/table.h"
#include "inc/GlobVar0.h"
#include "inc/GlobVarS.h"
#include "inc/BitDef.h"

void getLogNvmeErrInfo(BYTE uRetainAsyncEvent)
{
    BYTE uLastIdx;
    WORD u16TmpCnt;
    LWORD u32EntryCnt;

    if(!uRetainAsyncEvent)
    {
        mClrAerErrorTypeMask;
        mClrErrorType;
    }

    updateInvalidDbErrLog();

    u32EntryCnt=(rmNvmeGetLogNumDw>>4);

    if(u32EntryCnt>(gsLightSwitch.usNvmeLs.uElpe+1))    // uELPE=0 means 1 log at least
    {
        u32EntryCnt=(gsLightSwitch.usNvmeLs.uElpe+1);    // only # of entry return
    }

    uLastIdx=gErrLogPtr;

#if _ENABLE_NVME_LS
    bopClrRam((LWORD)(BYTE *)(&g32arTsb0[0]), ((gsLightSwitch.usNvmeLs.uElpe+1)*sizeof(ERRORINFO)), 0x00, cBopWait|cClrTsb);    // 0's base, one
                                                                                                                                // entry is
#else
    bopClrRam((LWORD)(BYTE *)(&g32arTsb0[0]), (cMaxErrLogEntryCnt*sizeof(ERRORINFO)), 0x00, cBopWait|cClrTsb);
#endif

    for(u16TmpCnt=0; u16TmpCnt<u32EntryCnt; u16TmpCnt++)
    {
        uLastIdx=subPtrBy1(uLastIdx, (gsLightSwitch.usNvmeLs.uElpe+1));
        copyCcmVal((BYTE *)(&g32arTsb0[0][u16TmpCnt*16]), (BYTE *)(&garErrorLog[uLastIdx]), sizeof(ERRORINFO));
    }
}    /* getLogNvmeErrInfo */

void getLogNvmeSmart(BYTE uRetainAsyncEvent)
{
    SMARTINFO *usSmartPtr=(void *)(&gpGetLog->usSmartLog);
    WORD u16KelvinTemp;
    BYTE uCurTemp, uSpareAvaliable=0, uDriveUsedPercentage;

    if(!uRetainAsyncEvent)
    {
        mClrAerSmartTypeMask;
        mClrSmartType;
    }

#if _EN_NAND_TEMP
    if(!g32NandTempSensor)
    {
        // Update Nand temperature
        LWORD u32Cnt=0;

        g32NandTempSensor=1;

        while(g32NandTempSensor&&(u32Cnt<0x100))
        {
            sysDelay(10);
            u32Cnt++;
        }
    }

    uCurTemp=g32AvgNandTemp;
#else
    uCurTemp=getThermalSensorTemp();
#endif/* if _EN_CHRONUS_THERMAL_TEMP */
    u16KelvinTemp=mChgCelsiustoKelvin(uCurTemp);
    uSpareAvaliable=div((g16OrgSpareBlockCnt-gsBadInfo.u16TotalNewBadCnt)*100, g16OrgSpareBlockCnt);
    uDriveUsedPercentage=getDriveUsedPercentage();

    if((!uDriveUsedPercentage)&&(gsBadInfo.u16TotalNewBadCnt<=5))    // 20190225_SamHu_02 protect
    {
        uSpareAvaliable=100;
    }

    usSmartPtr->uCriticalWarning=0;
#if _ENABLE_SMART_LS
    if(gsLightSwitch.usSmartLs.uWarning&cSmartWarnAvaliableSpare)
    {
        usSmartPtr->uCriticalWarning|=((gsLightSwitch.usSmartLs.uAvaliableSpareThres>uSpareAvaliable)?cSmartWarnAvaliableSpare:0);
    }

    if(gsLightSwitch.usSmartLs.uWarning&cSmartWarnTemperature)
    {
        usSmartPtr->uCriticalWarning|=
            (((gsSmart.usStatus.u16OverTempThres<=u16KelvinTemp)||
              (gsSmart.usStatus.u16UnderTempThres>=u16KelvinTemp))?cSmartWarnTemperature:0);
    }

    if(gsLightSwitch.usSmartLs.uWarning&cSmartWarnReliability)
    {
#if 0
        if(gparLS_VUID->uOEMID==C_OEMID_OEM7)
        {
            usSmartPtr->uCriticalWarning.ReliabilityDegraded=
                (TotalProgEraseFailPercentage(C_ProgFail)>gparLS_SMART->OEM7_TH.uProgramFailCntTotal?1:0)
                ||(TotalProgEraseFailPercentage(C_EraseFail)>
                   gparLS_SMART->OEM7_TH.uEraseFailCountTotal?1:0)
                ||((GetDriveUsedPercentage()>gparLS_SMART->OEM7_TH.uWearLevelingCnt)?1:0);
        }
        else
#endif
        {
            usSmartPtr->uCriticalWarning|=((uDriveUsedPercentage>gsLightSwitch.usSmartLs.uWearLevelingCntThres)?cSmartWarnReliability:0);
        }
    }

    if((gsLightSwitch.usSmartLs.uWarning&cSmartWarnReadOnly)&&mChkDummyWrite)
    {
        usSmartPtr->uCriticalWarning|=cSmartWarnReadOnly;
    }

    if(usSmartPtr->uCriticalWarning)
    {
        NLOG(cLogHost,
             GETLOGPAGE_C,
             3,
             " SMART Critical Warning=0x%02X, uSpareAvaliable=0x%02X, u16KelvinTemp=0x%04X, uDriveUsedPercentage=0x%04X",
             (usSmartPtr->uCriticalWarning<<8|uSpareAvaliable),
             (WORD)u16KelvinTemp,
             (WORD)uDriveUsedPercentage);
    }
#endif/* if _ENABLE_SMART_LS */

    // [K] = [XC] + 273.15
    usSmartPtr->uCompositeTemperate[0]=u16KelvinTemp;
    usSmartPtr->uCompositeTemperate[1]=(u16KelvinTemp>>8);

    usSmartPtr->uAvailableSpare=uSpareAvaliable;

    usSmartPtr->uAvailableSpareThreshold=gsLightSwitch.usSmartLs.uAvaliableSpareThres;    // Update at first power on

    usSmartPtr->uPercentageUsed=uDriveUsedPercentage;
    usSmartPtr->u64arDataUnitsRead[0]=(g64TotalHostRdSecCnt/1000);
    usSmartPtr->u64arDataUnitsWritten[0]=(gsFtlDbg.u64TotalHostWrSecCnt/1000);
    usSmartPtr->u64arHostReadCommands[0]=g64HostRdCmdCnt;
    usSmartPtr->u64arHostWriteCommands[0]=g64HostWrCmdCnt;
    usSmartPtr->u64arControllerBusyTime[0]=(gsSmart.usCnt.u64ControllerBusyTimeMs/60000);
    usSmartPtr->u64arPowerCycles[0]=gsFtlDbg.u32PowerOnCnt;

    gsSmart.usCnt.u64PowerOnSec+=getRtcDiff1s();
    startRtcCounting1s();
    usSmartPtr->u64arPowerOnHours[0]=(gsSmart.usCnt.u64PowerOnSec/3600);
    usSmartPtr->u64arUnsafeShutdowns[0]=gsFtlDbg.u32UGSDPwrOnCnt;
#if (OEM==HP)
// 162:160 NVM Media Integrity Errors                     - 3 Bytes
// 165:163 End-to-End Internal Data Path Errors           - 3 Bytes
// 167:166 Data Integrity Errors -LBA Tag Mismatches      - 2 Bytes
// 171:168 Data Integrity Errors -CRC Checksum Failures   - 4 Bytes
// 175:172 Data Integrity Errors -UECC Errors             - 4 Bytes

// UECC Error:
// gsFtlDbg.u32SlcVthTrackingFailCnt
// gsFtlDbg.u32TlcVthTrackingFailCnt

// CRC chechsum failures:
// g32InternalDataPath

// End-to-End Internal Data Path Error:
// g32E2eDetectCnt
    LWORD u32UECC;
    LWORD u32E2E;
    u32UECC=(gsFtlDbg.u32SlcVthTrackingFailCnt+gsFtlDbg.u32TlcVthTrackingFailCnt);

    if((u32UECC<gsFtlDbg.u32SlcVthTrackingFailCnt)||(u32UECC<gsFtlDbg.u32TlcVthTrackingFailCnt))
    {
        u32UECC=0xFFFFFFFF;
    }

    if(g32E2eDetectCnt>0xFFFFFF)
    {
        u32E2E=0xFFFFFF;
    }
    else
    {
        u32E2E=g32E2eDetectCnt;
    }

    usSmartPtr->u64arMediaAndDataIntegrityErrors[0]=((QWORD)u32E2E<<24);
    usSmartPtr->u64arMediaAndDataIntegrityErrors[1]=(((QWORD)u32UECC<<32)|g32InternalDataPath);
#else/* if (OEM==HP) */
    usSmartPtr->u64arMediaAndDataIntegrityErrors[0]=gsSmart.usCnt.u64MediaDataIntegrityErr;
    usSmartPtr->u64arMediaAndDataIntegrityErrors[1]=0;
#endif/* if (OEM==HP) */
    usSmartPtr->u64arNumOfErrorLogEntries[0]=(((QWORD)g32ErrorCountH<<32)|g32ErrorCountL);
    // 20181115_SamHu
    usSmartPtr->u16arTemperatureSensor[0]=u16KelvinTemp;
#if _ENABLE_SMART_LS
    if(gsLightSwitch.usNvmeLs.u16WcTemp&&(gsSmart.usCnt.u64WcTempElapsedTimeSec/60))
    {
        usSmartPtr->u32WarningCompositeTemperatureTime+=(gsSmart.usCnt.u64WcTempElapsedTimeSec/60);
        gsSmart.usCnt.u64WcTempElapsedTimeSec%=60;
    }

    if(gsLightSwitch.usNvmeLs.u16CcTemp&&(gsSmart.usCnt.u64CcTempElapsedTimeSec/60))
    {
        usSmartPtr->u32CriticalCompositeTempTime+=(gsSmart.usCnt.u64CcTempElapsedTimeSec/60);
        gsSmart.usCnt.u64CcTempElapsedTimeSec%=60;
    }
#endif

    // Jira-75, don't return unexpected data here
    // Fw debug value, not in NVMe spec.
    /*
       * usSmartPtr->u16FwSpareBlkCnt=gsCacheInfo.u16SpareBlockCnt;
       * usSmartPtr->u16FwMinSpareBlkCnt=g16MinSpareBlockCnt;
       * usSmartPtr->u16FwTlcSprBlockCnt=gsCacheInfo.u16TLCSprBlockCnt;
       * usSmartPtr->u16FwMinTlcSprBlockCnt=0;
       * usSmartPtr->u16FwSlcMoSkipCnt=gsCacheInfo.u16SlcMoSkipCnt;
       * usSmartPtr->u16FwMlcMoSkipCnt=gsCacheInfo.u16MlcMoSkipCnt;
       * usSmartPtr->u16FwFullCacheBlockCnt=gsCacheInfo.u16FullCacheBlockCnt;    // closed SLC
       * usSmartPtr->u16FwTLCFullCacheBlockCnt=gsCacheInfo.u16TLCFullCacheBlockCnt;    // close TLC
       * usSmartPtr->uGcT2tOpFactor=gsGcInfo.uT2TOpFactor;
       *
       * uCurTemp=((gsHmbInfo.uHmbValid!=0)<<7)|((gsHmbInfo.uHmbEnable!=0)<<6)
       |((gsHmbInfo.uHmbEnWrCache!=0)<<4)|((gsHmbInfo.uHmbEnRdCache!=0)<<3)|((gsHmbInfo.uHmbEnGcCache!=0)<<2)
       |((gsHmbInfo.uHmbEnGcInfoCache!=0)<<1);
       * usSmartPtr->uHmbFlag=uCurTemp;
       */
    saveSmartInfo(cNotReadWpro);
}    /* getLogNvmeSmart */

// 20181213_KevinGG_01
void getLogDellSmart(BYTE uRetainAsyncEvent, WORD *u16DellInfo)
{
    DELLSMARTINFO *usDellSmartPtr=(void *)(&gpGetLog->usDellSmartLog);

    // temp value
    usDellSmartPtr->uReAssignedSectorCount=(BYTE)u16DellInfo[5];
    usDellSmartPtr->uProgramFailCountWorst=(BYTE)u16DellInfo[0];
    usDellSmartPtr->uProgramFailCountTotal=(BYTE)u16DellInfo[1];
    usDellSmartPtr->uEraseFailCountWorst=(BYTE)u16DellInfo[2];
    usDellSmartPtr->uEraseFailCountTotal=(BYTE)u16DellInfo[3];
    usDellSmartPtr->uWearLevelingCount=(BYTE)u16DellInfo[4];
    usDellSmartPtr->uUsedReservedBlockCountWorst=(BYTE)u16DellInfo[5];
    usDellSmartPtr->uUsedReservedBlockCountTotal=(BYTE)u16DellInfo[6];
    usDellSmartPtr->u32ReservedBlockCountTotal=(LWORD)u16DellInfo[7];

    saveSmartInfo(cNotReadWpro);
}

#if (OEM==LENOVO)
void getLogLenovoPageDFh(BYTE uRetainAsyncEvent)    // 20190115_Kevin_01
{
    LENOVOLOGDF *usLenovoDFhLogPtr=(void *)(&gpGetLog->usLenovoDFhLog);
    BYTE u8arModelNameTemp[40];
    BYTE uLoop, uShift;
    WORD u16AVGSLC=0, u16AVGTLC=0;
    WORD u16SLCBlock=0, u16TLCBlock=0;
    LWORD u32_Temp_L=0, u32_Temp_M=0;

    fillCcmVal((BYTE *)&usLenovoDFhLogPtr->uarRsvd1[0], 16, 0x20);    // Offset 004-019
    fillCcmVal((BYTE *)&usLenovoDFhLogPtr->uarRsvd2[0], 84, 0x20);    // Offset 140-223
    fillCcmVal((BYTE *)&usLenovoDFhLogPtr->uarRsvd3[0], 251, 0x20);    // Offset 261-511

    usLenovoDFhLogPtr->uarUpperCaseCharacters[0]='L';    // Offset 0
    usLenovoDFhLogPtr->uarUpperCaseCharacters[1]='E';    // Offset 1
    usLenovoDFhLogPtr->uarUpperCaseCharacters[2]='N';    // Offset 2
    usLenovoDFhLogPtr->uarUpperCaseCharacters[3]='2';    // Offset 3

    copyCcmVal(usLenovoDFhLogPtr->uarOriginal8SLabel, garLenovoLogDFhSN, 30);    // Offset 020-049
    GetModelName(u8arModelNameTemp);
    copyCcmVal(usLenovoDFhLogPtr->uarSupplierModelNumber, (BYTE *)u8arModelNameTemp, 40);    // Offset 050-089
    copyCcmVal(usLenovoDFhLogPtr->uarSupplierSerialNumber, gsMPInfo.uarSerialNum, 20);    // Offset 090-109

    if((garLenovoLogDFhNewSN[0]=='8')&&(garLenovoLogDFhNewSN[1]=='S'))    // [0] = 8, [1] = S
    {
        copyCcmVal(usLenovoDFhLogPtr->uarCurrent8SLabel, garLenovoLogDFhNewSN, 30);    // Offset 110~139
    }
    else
    {
        copyCcmVal(usLenovoDFhLogPtr->uarCurrent8SLabel, garLenovoLogDFhSN, 30);    // Offset 110~139
    }

    for(uLoop=0; uLoop<30; uLoop++)
    {
        if(usLenovoDFhLogPtr->uarOriginal8SLabel[uLoop]==0x0)
        {
            usLenovoDFhLogPtr->uarOriginal8SLabel[uLoop]=0x20;
        }

        if(usLenovoDFhLogPtr->uarCurrent8SLabel[uLoop]==0x0)
        {
            usLenovoDFhLogPtr->uarCurrent8SLabel[uLoop]=0x20;
        }
    }

    for(uLoop=0; uLoop<20; uLoop++)
    {
        if(usLenovoDFhLogPtr->uarSupplierSerialNumber[uLoop]==0x0)
        {
            usLenovoDFhLogPtr->uarSupplierSerialNumber[uLoop]=0x20;
        }
    }

    usLenovoDFhLogPtr->NANDWriteIn512KBLower=0;    // Offset 232-239
    usLenovoDFhLogPtr->NANDWriteIn512KBMiddle=0;    // Offset 232-239
    usLenovoDFhLogPtr->NANDWriteIn512KBUpper=0;    // Offset 224-231
    usLenovoDFhLogPtr->NANDWriteIn512KBUnused=0;    // Offset 224-231
    usLenovoDFhLogPtr->CRCErrorCNT=0;    // Offset 240-243
    usLenovoDFhLogPtr->SLCNANDWriteIn512KBLower=0;    // Offset 252-259
    usLenovoDFhLogPtr->SLCNANDWriteIn512KBMiddle=0;    // Offset 252-259
    usLenovoDFhLogPtr->SLCNANDWriteIn512KBUpper=0;    // Offset 244-251
    usLenovoDFhLogPtr->SLCNANDWriteIn512KBUnused=0;    // Offset 244-251

    u16AVGSLC=GetAvgECCore0(0);
    u16AVGTLC=GetAvgECCore0(1);
    u16SLCBlock=g16StaticBound-1;
    u16TLCBlock=g16TotalFBlock-g16OrgBadBlockCnt-g16LaterBadBlockCnt-g16FirstFBlock-gMinStaticSlcCnt+1;

    // SLC : (30000(SLC P/E Cycle)*Total SLC Block*SLC Block Size)/(512*1024)
    // --->30000*58*48*1024*1024/(512*1024)
    // --->30000*58*3*(2^4)*1024*1024/(512*1024)
    // --->30000*58*3*(2^5)

    // TLC : 3000(TLC P/E Cycle)*Total TLC Block*TLC Block size/(512*1024)
    // --->3000*870*144MB/(512*1024)
    // --->3000*870*9*(2^4)*1024*1024/(512*1024)
    // --->3000*870*9*2^5

    // For SLC NAND Write
    for(WORD u16idx=0; u16idx<u16SLCBlock*3; u16idx++)
    {
        u32_Temp_L=usLenovoDFhLogPtr->SLCNANDWriteIn512KBLower;
        usLenovoDFhLogPtr->SLCNANDWriteIn512KBLower+=u16AVGSLC;

        if(usLenovoDFhLogPtr->SLCNANDWriteIn512KBLower<u32_Temp_L)
        {
            usLenovoDFhLogPtr->SLCNANDWriteIn512KBMiddle++;
        }
    }

    // For TLC  NAND Write
    u32_Temp_L=0;

    for(WORD u16idx=0; u16idx<u16TLCBlock; u16idx++)
    {
        u32_Temp_L=usLenovoDFhLogPtr->NANDWriteIn512KBLower;
        usLenovoDFhLogPtr->NANDWriteIn512KBLower+=9*u16AVGTLC;

        if(usLenovoDFhLogPtr->NANDWriteIn512KBLower<u32_Temp_L)
        {
            usLenovoDFhLogPtr->NANDWriteIn512KBMiddle++;
        }
    }

    if((gTotalChNum==4)&&(gTotalCeNum==1))    // 128GB 2^5
    {
        uShift=5;
    }
    else if((gTotalChNum==4)&&(gTotalCeNum==2))    // 256GB 2^6
    {
        uShift=6;
    }
    else    // 512GB 2^7
    {
        uShift=7;
    }

    u32_Temp_L=0;
    u32_Temp_M=0;

    u32_Temp_L=usLenovoDFhLogPtr->SLCNANDWriteIn512KBLower<<uShift;
    u32_Temp_M=((usLenovoDFhLogPtr->SLCNANDWriteIn512KBMiddle<<uShift)|(usLenovoDFhLogPtr->SLCNANDWriteIn512KBLower>>(32-uShift)));
    usLenovoDFhLogPtr->SLCNANDWriteIn512KBLower=u32_Temp_L;
    usLenovoDFhLogPtr->SLCNANDWriteIn512KBMiddle=u32_Temp_M;

    u32_Temp_L=usLenovoDFhLogPtr->NANDWriteIn512KBLower<<uShift;
    u32_Temp_M=((usLenovoDFhLogPtr->NANDWriteIn512KBMiddle<<uShift)|(usLenovoDFhLogPtr->NANDWriteIn512KBLower>>(32-uShift)));
    usLenovoDFhLogPtr->NANDWriteIn512KBLower=u32_Temp_L;
    usLenovoDFhLogPtr->NANDWriteIn512KBMiddle=u32_Temp_M;

    u32_Temp_L=usLenovoDFhLogPtr->NANDWriteIn512KBLower;
    usLenovoDFhLogPtr->NANDWriteIn512KBLower+=usLenovoDFhLogPtr->SLCNANDWriteIn512KBLower;

    if(u32_Temp_L>usLenovoDFhLogPtr->NANDWriteIn512KBLower)
    {
        usLenovoDFhLogPtr->NANDWriteIn512KBMiddle++;
    }

    usLenovoDFhLogPtr->NANDWriteIn512KBMiddle+=usLenovoDFhLogPtr->SLCNANDWriteIn512KBMiddle;

    NLOG(cLogHost,
         GETLOGPAGE_C,
         4,
         "Block_SLC=0x%04X, Avg_SLC=0x%04X, Block_TLC=0x%04X, Avg_TLC=0x%04X",
         u16SLCBlock,
         u16AVGSLC,
         u16TLCBlock,
         u16AVGTLC);
    NLOG(cLogHost, GETLOGPAGE_C, 4, "SLC NAND Write: L=0x%08X, M=0x%08X ",
         usLenovoDFhLogPtr->SLCNANDWriteIn512KBLower>>16, usLenovoDFhLogPtr->SLCNANDWriteIn512KBLower,
         usLenovoDFhLogPtr->SLCNANDWriteIn512KBMiddle>>16, usLenovoDFhLogPtr->SLCNANDWriteIn512KBMiddle);
    NLOG(cLogHost, GETLOGPAGE_C, 4, "Total NAND Write: L=0x%08X, M=0x%08X ",
         usLenovoDFhLogPtr->NANDWriteIn512KBLower>>16, usLenovoDFhLogPtr->NANDWriteIn512KBLower,
         usLenovoDFhLogPtr->NANDWriteIn512KBMiddle>>16, usLenovoDFhLogPtr->NANDWriteIn512KBMiddle);
    usLenovoDFhLogPtr->PercentageUsed=u16AVGSLC/300;    // Offset 260  (u16AVGSLC*100)/30000;

    saveSmartInfo(cNotReadWpro);
}    /* getLogLenovoPageDFh */

void getLogPLPStatistics(BYTE uRetainAsyncEvent)
{
    PLPSTATISTICS *usPLPStatisticsLogPtr=(void *)(&gpGetLog->usPLPStatisticsLog);

    usPLPStatisticsLogPtr->u32CompletedPLPCount=gsFtlDbg.u32PlpScpCompleteCnt;    // Offset 0-3
    usPLPStatisticsLogPtr->u32IncompletedPLPCount=(gsFtlDbg.u32PlpScpGpioInitCnt-gsFtlDbg.u32PlpScpCompleteCnt);    // Offset 1
    saveSmartInfo(cNotReadWpro);
}    /* getLogLenovoPageDFh */

#endif/* if (OEM==LENOVO) */
void getLogVendorTelemetry()
{
    INTELRDTTELEMMETRY *upTelemetryData=(void *)&g32arTsb0[0];
    LWORD u32MaxEraseCnt, u32MinEraseCnt, u32AvgEraseCnt;

    bopClrRam((LWORD)(BYTE *)&g32arTsb0[0], 1024, 0x00000000, cBopWait|cClrTsb);
    upTelemetryData=(void *)&g32arTsb0[0];

    calEraseCnt(&u32MaxEraseCnt, &u32MinEraseCnt, &u32AvgEraseCnt, 0);

#if 0
    // offset 0x000
    upTelemetryData->u64Version=gTelemetry.g64Version;    // Shall reset all att if version mismatch?	x			0	VERSION
#endif
    upTelemetryData->u64RealloSctrCnt=gsBadInfo.u16TotalNewBadCnt;    // g16LaterBadCnt	V	V		8	Re-allocated // Sector
                                                                      // Count
#if 0
    upTelemetryData->u64ReallocatedSectorCountSLC=gTelemetry.g16LaterBadCnt_SLC;    // g16LaterBadCnt_SLC	V	V	V	16	Re-allocated
                                                                                    // Sector Count
    upTelemetryData->u64PoweronHoursCount=gTelemetry.g64DriveLifeSec/3600;    // g64DriveLifeSec/3600	V			24	Power-on
                                                                              // Hours Count
    upTelemetryData->u64UncorrectableErrorCount=gTelemetry.g32XORFailCnt;    // g32XORFailCnt	V			32	Uncorrectable
                                                                             // Error Count (XOR Fail)
    upTelemetryData->u64UncorrectableErrorCountSLC=gTelemetry.g32XORFailCnt_SLC;    // g32XORFailCnt_SLC	V		V	40	Uncorrectable
                                                                                    // Error Count (XOR Fail)
    upTelemetryData->u64ECCUnc_SoftLDPCfail=gTelemetry.g32LDPCFailCnt;    // g32LDPCFailCnt	V			48	ECCUnc (Soft
                                                                          // LDPC fail)
    upTelemetryData->u64SoftLDPCcorrectionEventCnt=gTelemetry.g32LDPCPassCnt;    // g32LDPCPassCnt	V			56	Soft
                                                                                 // LDPC correction event count
    upTelemetryData->u64ReadRetryFail=gTelemetry.g32RetryFailCnt;    // g32RetryFailCnt	V			64	TLC read retry fail
    upTelemetryData->u64ReadRetryFailSLC=gTelemetry.g32RetryFailCnt_SLC;    // g32RetryFailCnt_SLC	V		V	72	SLC read
                                                                            // retry fail
    // offset 0x050
    upTelemetryData->u64Temperature=GetCurrentTemp();    // run time var				80	Temperature
    /*  Read retry trigger*/
    upTelemetryData->u64ReadRetryTrigger=gTelemetry.g64ReadRetryTrigger;    // same as row 4				88	RE-allocated
                                                                            // Sector Events
#endif/* if 0 */
    upTelemetryData->u64TotalLbaWritten=gsFtlDbg.u64TotalHostWrSecCnt;
    upTelemetryData->u64TotalLbaRead=g64TotalHostRdSecCnt;
#if 0
    upTelemetryData->u64PS3Count=gTelemetry.g64PowerOnPS3Cnt;    // g64PowerOnPS3Cnt	V			112	PS3 Count
    upTelemetryData->u64PS4Count=gTelemetry.g64PowerOnPS4Cnt;    // g64PowerOnPS4Cnt	V			120	PS4 Count
    upTelemetryData->u64L12Count=gTelemetry.g64PowerOnL12Cnt;    // g64PowerOnL12Cnt	V			128	L1.2 Count //CSSD-2278
    upTelemetryData->u64AvailableSpareBlocks=g16PureSpareCnt_TLC;    // g16PureSpareCnt				136	TLC Available Spare
                                                                     // Blocks
    upTelemetryData->u64AvailableSpareBlocksSLC=g16PureSpareCnt_SLC;    // g16PureSpareCnt_SLC			V	144	SLC Available
                                                                        // Spare Blocks
    upTelemetryData->u64WearRangeDelta=(u32MaxErCnt-u32MinErCnt)*100/g16GRTPECycle;    // (max-min)/GRTPE_TLC				152	WearRangeDelta
    // =?
    // offset 0x0A0
    upTelemetryData->u64WearRangeDeltaSLC=(u32MaxErCnt_SLC-u32MinErCnt_SLC)*100/g16GRTPECycle_SLC;    // (max-min)/GRTPE_SLC			V	160	WearRangeDelta
    // =g32GRTPECycle_SLC
    upTelemetryData->u64HighTemp=gTelemetry.gMaxTemp;    // gMaxTemp	V			168	High Temp
    upTelemetryData->u64LowTemp=gTelemetry.gMinTemp;    // gMinTemp	V			176	Low Temp
    upTelemetryData->u64AvgTemp=(gTelemetry.gMaxTemp+gTelemetry.gMinTemp)/2;    // (gMaxTemp+gMinTemp)/2				184	Avg
                                                                                // Temp
    upTelemetryData->u64RecentHigh=gPowerOnMaxTemp;    // gPowerOnMaxTemp				192	Recent High
    upTelemetryData->u64RecentLow=gPowerOnMinTemp;    // gPowerOnMinTemp				200	Recent Low
    /*  auto-calibration fail*/
    upTelemetryData->u64AutoCalibrationFail=gTelemetry.g32AutoCalibrationFail;    // (gPowerOnMaxTemp+gPowerOnMinTemp)/2				208	Recent
                                                                                  // Average

    upTelemetryData->u64NandDataRead=gTelemetry.g64TotalReadPageCnt*gSectorPerPageH;    // g64TotalReadPageCnt	V			224	TLC
                                                                                        // Nand Data Read
    upTelemetryData->u64NandDataReadSLC=gTelemetry.g64TotalReadPageCnt_SLC*gSectorPerPageH;    // g64TotalReadPageCnt_SLC	V		V	216	SLC
                                                                                               // Nand Data Read
    upTelemetryData->u64Validblockcounts=u32VP;    // sum of g32ValidFPageCnt				232	Valid block counts
#endif/* if 0 */
    // offset 0x0F0
    upTelemetryData->u64NandDataWrite=g64NandTlcTotalWriteSecCnt;
    upTelemetryData->u64NandDataWriteSlc=g64NandSlcTotalWriteSecCnt;
#if 0    // NAND writes
    upTelemetryData->u64WearingLevelingCnt=gTelemetry.g32WearLevelingCnt;    // g32WearLevelingCnt	V			256	TLC
                                                                             // Wearing Leveling Count
    upTelemetryData->u64WearingLevelingCntSLC=gTelemetry.g32WearLevelingCnt_SLC;    // g32WearLevelingCnt_SLC	V		V	264	SLC
                                                                                    // Wearing Leveling Count
    upTelemetryData->u64NANDWrDueToWearingLeveling=gTelemetry.g32WearLevelingCnt*g32SectorsPerBlock;    // "row35*g32WearLevelingCnt"				272	TLC
                                                                                                        // NAND writes due to Wearing Leveling
    upTelemetryData->u64NANDWrDueToWearingLevelingSLC=gTelemetry.g32WearLevelingCnt_SLC*(g16PagePerBlock2_SLC<<gSectorPerPageH2n);    // "row36*g32WearLevelingCnt_SLC"				280	SLC
                                                                                                                                      // NAND
                                                                                                                                      // writes
                                                                                                                                      // due to
                                                                                                                                      // Wearing
                                                                                                                                      // Leveling
    // g32SectorsPerBlock_SLC?
    upTelemetryData->u64CurrentSpareSuperBlock=g16TotalSpareCnt_TLC;    // run time var				288	Current TLC spare super
                                                                        // block
    upTelemetryData->u64CurrentSpareSuperBlockSLC=g16TotalSpareCnt_SLC;    // run time var				296	Current SLC
                                                                           // spare super block
    // =g16TotalSpareCnt_SLC?
    upTelemetryData->u64SLCtoTLC_DefragCnt=gTelemetry.g32SLCtoTLCCnt;    // g32SLCtoTLCCnt	V		V	304	SLC to TLC
                                                                         // defrag count
    upTelemetryData->u64DefragCnt=gTelemetry.g32TLCtoTLCCnt;    // g32TLCtoTLCCnt	V			312	TLC Defrag count
    // offset 0x140
    upTelemetryData->u64DefragCntSLC=gTelemetry.g32SLCtoSLCCnt;    // g32SLCtoSLCCnt	V		V	320	SLC Defrag count
    upTelemetryData->u64ReadBackFailCnt=gTelemetry.g32ReadBackFailCnt;    // g32ReadBackFailCnt	V		V	328	Read back fail
                                                                          // count
    upTelemetryData->u64ProgramFailCnt=gTelemetry.g32ProgFailCnt;    // g32ProgFailCnt	V		V	336	TLC Program Fail
    upTelemetryData->u64ProgramFailCntSLC=gTelemetry.g32ProgFailCnt_SLC;    // g32ProgFailCnt_SLC	V		V	344	SLC
                                                                            // Program Fail
    upTelemetryData->u64EraseFailCnt=gTelemetry.g32EraseFailCnt;    // g32EraseFailCnt	V			352	TLC Erase Fail
    upTelemetryData->u64EraseFailCntSLC=gTelemetry.g32EraseFailCnt_SLC;    // g32EraseFailCnt_SLC	V		V	360	SLC
                                                                           // Erase Fail
#endif/* if 0 */
    upTelemetryData->u64EraseCycleAvg=u32AvgEraseCnt;    // run time calculation				368	Erase cycle average
    upTelemetryData->u64EraseCycleMax=u32MaxEraseCnt;    // run time calculation				376	Erase cycle Max
    upTelemetryData->u64EraseCycleMin=u32MinEraseCnt;    // run time calculation				384	Erase cycle Min
#if 0
    // offset 0x190
    upTelemetryData->u64EraseCycleAvgSlc=u32AvgEraseCntSlc;    // run time calculation			V	392	SLC Erase cycle average
    upTelemetryData->u64EraseCycleMaxSlc=u32MaxEraseCntSlc;    // run time calculation			V	400	SLC Erase cycle Max
    upTelemetryData->u64EraseCycleMinSlc=u32MinEraseCntSlc;    // run time calculation			V	408	SLC Erase cycle Min

    upTelemetryData->u64PS0toPS1=gTelemetry.g64PS0toPS1;
    upTelemetryData->u64PS1toPS0=gTelemetry.g64PS1toPS0;
    upTelemetryData->u64PS1toPS2=gTelemetry.g64PS1toPS2;
    upTelemetryData->u64PS2toPS1=gTelemetry.g64PS2toPS1;
    upTelemetryData->u64PS2toPSShutDown=gTelemetry.g64PS2toPSShutDown;
    /*  Link downshift*/
    upTelemetryData->u64LinkDownShift=gTelemetry.g32LinkDownShift;

    upTelemetryData->u64IdleSleepCnt=gTelemetry.g64IdleSleepCnt;

    upTelemetryData->u64L1EventCnt=gTelemetry.g64L1EventCnt;
    upTelemetryData->u64ECRCEventCount=gTelemetry.g64ECRCEventCount;
    upTelemetryData->u64LCRCEventCount=gTelemetry.g64LCRCEventCount;
    upTelemetryData->u64SLC2TLCProgCnt_Idle=gTelemetry.g64TotalSLC2TLCProgCnt_Idle;
    upTelemetryData->u64SLC2TLCProgCnt_Activity=gTelemetry.g64TotalSLC2TLCProgCnt_Activity;

    upTelemetryData->u64DRAMOneBitErrCnt=gTelemetry.g16DRAMOneBitErrCnt;    // =512
    upTelemetryData->u64SRAMOneBitErrCnt=gTelemetry.g16SRAMOneBitErrCnt;
    upTelemetryData->u64E2EDetectCnt=gTelemetry.g16E2EDetectCnt;

    upTelemetryData->u64PS3p5Count=gTelemetry.g64PowerOnPS3p5Cnt;

    /* New add for intel request for HH */    // CSSD-5321
    upTelemetryData->u64ThrottlingLightCnt=gTelemetry.g64PS0toPS1+gTelemetry.g64PS2toPS1;
    upTelemetryData->u64ThrottlingHeavyCnt=gTelemetry.g64PS1toPS2;
    upTelemetryData->u64ThrottlingLightDuration=g32TotalTimeForThermalMT1;
    upTelemetryData->u64ThrottlingHeavyDuration=g32TotalTimeForThermalMT2;
    upTelemetryData->u64RetryCnt=gTelemetry.g64ReadRetryTrigger;
    upTelemetryData->u64SoftDecodeCnt=gTelemetry.g32LDPCFailCnt+gTelemetry.g32LDPCPassCnt;
#endif/* if 0 */

    if(gsFtlDbg.u64TotalHostWrSecCnt)
    {
        upTelemetryData->u64WaiInteger=(div64(g64NandTlcTotalWriteSecCnt, gsFtlDbg.u64TotalHostWrSecCnt)
                                        +div64(g64NandSlcTotalWriteSecCnt, gsFtlDbg.u64TotalHostWrSecCnt));
        upTelemetryData->u64WaiDecimal=(div64((100*g64NandTlcTotalWriteSecCnt), gsFtlDbg.u64TotalHostWrSecCnt)
                                        +div64((100*g64NandSlcTotalWriteSecCnt), gsFtlDbg.u64TotalHostWrSecCnt)
                                        -(upTelemetryData->u64WaiInteger*100));
    }

    upTelemetryData->u64TotalPcieRdErrCnt=g32TotalPcieRdErrCnt;
    upTelemetryData->u64TotalPcieWrErrCnt=g32TotalPcieWrErrCnt;
}    /* getLogVendorTelemetry */

void getLogTelemetryHost()
{
    // Add function here for vendor specific data
    BYTE uCnt, uNvmeLsp=rmNvmeLsp;
    TELELOG *upTelemetryHostData=(void *)&g32arTsb0[0];

#if (_EN_CHRONUS_UART_DEBUG)
    if(mChkUartCMDRdy)
    {
        uNvmeLsp=(gpUartCMD->DW10>>8)&0xF;
    }
#endif

    bopClrRam(c32Tsb0SAddr, ((cTelemetryArea1DataSecCnt+1)*cSingleSectorByte), 0x00000000, cBopWait|cClrTsb);

    if(uNvmeLsp&cBit0)    // Create Telemetry Host-Initiated Data
    {
        saveEventLog(0);
    }
    else
    {
        readWproPageCore0(cWproEventLog, c16Tsb0SIdx, 0);
    }

    // shift 512 bytes for telemetry log header
    for(uCnt=gSectorPerPlaneH; uCnt>0; uCnt--)
    {
        copyCcmVal((BYTE *)(&garTsb0[uCnt][0]), (BYTE *)(&garTsb0[uCnt-1][0]), cSingleSectorByte);
    }

    readRdCntToTsb0Core0(gSectorPerPlaneH+1);
    readWproPageCore0(cWproBadInfo, cTelemetryBadInfoStrOfst, 0);
    loadBadCntTabCore0(cTelemetryOrgBadCntStrOfst, gBadCntTableStartPage);
    loadOrgBadTabCore0(cTelemetryOrgBadTabStrOfst, gBlockStatusStartPage);

    // fill header
    bopClrRam(c32Tsb0SAddr, cSingleSectorByte, 0x00000000, cBopWait|cClrTsb);
    upTelemetryHostData->uLid=0x7;
    copyCcmVal(upTelemetryHostData->uarIeee, gsMPInfo.uarIeee, 3);
    upTelemetryHostData->u16DataArea1LastBlock=cTelemetryArea1DataSecCnt;
    upTelemetryHostData->u16DataArea2LastBlock=cTelemetryArea1DataSecCnt;
    upTelemetryHostData->u16DataArea3LastBlock=cTelemetryArea1DataSecCnt;
    upTelemetryHostData->uCtrllerInitDataAvail=mChkTelemetryCtlrInfoAvail;
    upTelemetryHostData->uCtrllerInitDataGenNum=gTelemetryCtlrGenNum;
}    /* getLogTelemetryHost */

void getLogTelemetryController(BYTE uRetainAsyncEvent)
{
    // Add function here for vendor specific data
    BYTE uLogOffset, uDataAvail;
    TELELOG *upTelemetryCtlrData=(void *)&g32arTsb0[0];

    bopClrRam(c32Tsb0SAddr, ((cTelemetryArea3DataSecCnt+1)*cSingleSectorByte),
              0x00000000, cBopWait|cClrTsb);
    uDataAvail=mChkTelemetryCtlrInfoAvail;

    if(!mChkTelemetryCtlrInfoAvail)
    {
        // fill header with 0 available data
        upTelemetryCtlrData->uLid=0x8;
        copyCcmVal(upTelemetryCtlrData->uarIeee, gsMPInfo.uarIeee, 3);
        upTelemetryCtlrData->u16DataArea1LastBlock=0;
        upTelemetryCtlrData->u16DataArea2LastBlock=0;
        upTelemetryCtlrData->u16DataArea3LastBlock=0;
        upTelemetryCtlrData->uCtrllerInitDataAvail=uDataAvail;
        upTelemetryCtlrData->uCtrllerInitDataGenNum=gTelemetryCtlrGenNum;
        return;
    }

    if(!uRetainAsyncEvent)
    {
        mClrAerNoticeTypeMask;
        mClrAerTelemetryLog;
        // update Telemetry Controller-Initiated data available info
        uLogOffset=(c32FrontEndVarLogPageAddr)/512;
        FRONTENDDBGLOG *upFELog=(FRONTENDDBGLOG *)((void *)(&(garTsb0[uLogOffset][0])));

        readWproPageCore0(cWproEventLog, c16Tsb0SIdx, 0);
        mClrTelemetryCtlrInfoAvail;
        upFELog->uTelemetryControllerDataAvail=0;
        progWproPageCore0(cWproEventLog, c16Tsb0SIdx);
    }

    loadTelemetryCtlrLogCore0(c16Tsb0SIdx+1);    // reserved 1 sector for telemetry header

    // fill header
    bopClrRam(c32Tsb0SAddr, cSingleSectorByte, 0x00000000, cBopWait|cClrTsb);
    upTelemetryCtlrData->uLid=0x8;
    copyCcmVal(upTelemetryCtlrData->uarIeee, gsMPInfo.uarIeee, 3);
    upTelemetryCtlrData->u16DataArea1LastBlock=cTelemetryArea1DataSecCnt;
    upTelemetryCtlrData->u16DataArea2LastBlock=cTelemetryArea2DataSecCnt;
    upTelemetryCtlrData->u16DataArea3LastBlock=cTelemetryArea3DataSecCnt;
    upTelemetryCtlrData->uCtrllerInitDataAvail=uDataAvail;
    upTelemetryCtlrData->uCtrllerInitDataGenNum=gTelemetryCtlrGenNum;
}    /* getLogTelemetryController */

void getLogSanitize(BYTE uRetainAsyncEvent)
{
    LWORD u32ProgressValue=c16BitFF;

    if(!uRetainAsyncEvent)
    {
        mClrAerIoTypeMask;
        mClrIoType;
    }

    if(mChkSanitizeState)
    {
        gpGetLog->usSaniLog.uSstatL=mChkSanitizeState;
    }

    if(gpGetLog->usSaniLog.uSstatH)
    {
        if((gpGetLog->usSaniLog.u64LastHostWrCmdCnt!=g64HostWrCmdCnt)||gsSmart.usStatus.uWuncEver)
        {
            gpGetLog->usSaniLog.uSstatH=cSanitizeGlobalDataNotErased;
        }
    }

    if(mChkSanitizeInProgress)
    {
        if(gsSanitizeInfo.uMode==cSanitizeExitFailureMode)
        {
            // Just keep the last wpro data
            u32ProgressValue=gpGetLog->usSaniLog.u16Sprog;
        }
        else if((gsSanitizeInfo.uMode==cSanitizeBlockErase)||(gsSanitizeInfo.uMode==cSanitizeOverwrite))
        {
            if(gsSanitizeInfo.uMode==cSanitizeOverwrite)
            {
                gpGetLog->usSaniLog.uSstatL|=(gsEraseUnitInfo.usCurrentOperation.uPassCount<<3);
            }

            u32ProgressValue=
                div((((gsEraseUnitInfo.usCurrentOperation.u16NextFBlock-g16FirstFBlock)
                      +((g16TotalFBlock-g16FirstFBlock)*gsEraseUnitInfo.usCurrentOperation.u16CurrBlkOpCnt))*u32ProgressValue)
                    , gsEraseUnitInfo.u32TotalBlockOperations);
        }
        else if(gsSanitizeInfo.uMode==cSanitizeCryptoErase)
        {
            // u32ProgressValue=c16BitFF;
        }
        else
        {
            while(1)
                ;// No such case
        }
    }

    gpGetLog->usSaniLog.u16Sprog=(WORD)u32ProgressValue;
    saveSmartInfo(cNotReadWpro);
}    /* getLogSanitize */

void nvmeGetLogPage()
{
    LWORD u32NUMDOverflowChk, u32NUMD, u32OffsetUpper, u32NvmeDstPeriodMs;
    LWORD u32OffsetLower=rmLogPageOffsetLower, u32NsId=rmNvmeNsId;
    WORD u16BufIdx=0, u16StatusCode=cStatusSuccess;
    BYTE uRetainAsyncEvent=rmRetainAsyncEvent, uLid=rmNvmeLid;
    BYTE uPSDT, uLsp, uDstAbort, uCurrentOperation;
    BYTE u8capacityIndex;
    WORD u16DstExtendedTime;
    BYTE uarExtFwVersion1[8];
    BYTE uarExtFwVersion2[8];

#if (OEM==DELL)    // 20181213_KevinGG_01
    WORD u16DellInfo[8];
#endif

#if (_EN_CHRONUS_UART_DEBUG)
    if(mChkUartCMDRdy)
    {
        u32OffsetLower=gpUartCMD->DW12;
        u32NsId=gpUartCMD->NSID;
        uRetainAsyncEvent=(gpUartCMD->DW10&c16Bit15)?1:0;
        uLid=gpUartCMD->DW10&0xFF;
        u32NUMDOverflowChk=(gpUartCMD->DW10>>16)|(gpUartCMD->DW11<<16);
        uPSDT=gpUartCMD->DW0B1&0xC0;
        u32OffsetUpper=gpUartCMD->DW13;
        u32NUMD=((gpUartCMD->DW10>>16)|(gpUartCMD->DW11<<16))+1;
        uLsp=(gpUartCMD->DW10>>8)&0xF;
    }
    else
#endif
    {
        u32NUMDOverflowChk=rmNvmeGetLogNumDwOverflowChk;
        uPSDT=rmNvmeSgl;
        u32OffsetUpper=rmLogPageOffsetUpper;
        u32NUMD=rmNvmeGetLogNumDw;
        uLsp=rmNvmeLsp;
    }

    // 20181206_SamHu_01 add log
    NLOG(cLogHost, GETLOGPAGE_C, 1, "  Get Log: LID=0x%02X, gsNamespace.uActiveBitMap=0x%02X ",
         (WORD)((uLid<<8)|gsNamespace.uActiveBitMap));

    NLOG(cLogHost,
         GETLOGPAGE_C,
         4,
         "  Number of Dwords=0x%08X, Offset Lower=0x%08X ",
         u32NUMD>>16,
         u32NUMD,
         u32OffsetLower>>16,
         u32OffsetLower);

    if((uLid!=cLogErrInfo)
       &&(uLid!=cLogSmartInfo)
       &&(uLid!=cLogFwSlotInfo)
       &&(uLid!=cLogCmdEffect)
       &&(uLid!=cLogSelfTest)
#if _ENABLE_TELEINITLOG
       &&(uLid!=cLogTelemetryHost)
       &&(uLid!=cLogTelemetryController)
#endif
#if _ENABLE_SANITIZE
       &&(uLid!=cLogSanitize)
#endif
       &&(uLid!=cLogVendorTelemetry)

#if (OEM==DELL)
       &&(uLid!=cLogExtendSmart)
#endif
#if (OEM==LENOVO)
       &&(uLid!=cLogLenovoPageDFh)
       &&(uLid!=cLogPLPStatistics)
#endif
       )
    {
        u16StatusCode=cStatusInvalidLogPage;
    }
    else if((u32NUMDOverflowChk==c32BitFF)||uPSDT||(u32OffsetLower&0x03)||u32OffsetUpper||(uLsp&&(uLid!=cLogTelemetryHost))||
            (gsLightSwitch.usNvmeLs.uMdts&&(((u32NUMD>>10)>>gsLightSwitch.usNvmeLs.uMdts)>1)))
    {
        NLOG(cLogHost,
             GETLOGPAGE_C,
             4,
             "  u32NUMDOverflowChk=0x%08X, Offset Upper=0x%08X ",
             u32NUMDOverflowChk>>16,
             u32NUMDOverflowChk,
             u32OffsetUpper>>16,
             u32OffsetUpper);

        NLOG(cLogHost,
             GETLOGPAGE_C,
             1,
             "  uPSDT=0x%02X, LSP=0x%02X ",
             ((uPSDT<<8)|uLsp));

        u16StatusCode=cStatusInvalidField;
    }

#if (OEM==HP)    // 20190219_SamHu_02 linuxstor fail
    else if(((uLid!=cLogSmartInfo)&&(uLid!=cLogExtendSmart))&&(u32NsId!=cNamespaceNotSpecific)&&(u32NsId!=cNamespaceAll)&&
            ((u32NsId>gsLightSwitch.usNvme2Ls.u32NamespaceNum)||(!(gsNamespace.uActiveBitMap&cbBitTab[u32NsId-1]))))
#else
    else if(((uLid!=cLogSmartInfo)&&(uLid!=cLogExtendSmart)&&(uLid!=cLogLenovoPageDFh))&&(u32NsId!=cNamespaceNotSpecific)&&
            (u32NsId!=cNamespaceAll))
#endif
    {
        // follow Lenovo Spec 1.26 the drive should ignore the NSID field when the page field is DFh
        u16StatusCode=cStatusInvalidField;
    }
    else if(((uLid==cLogSmartInfo)||(uLid==cLogExtendSmart))&&(u32NsId!=cNamespaceNotSpecific)&&(u32NsId!=cNamespaceAll)&&
            ((u32NsId>gsLightSwitch.usNvme2Ls.u32NamespaceNum)||(!(gsNamespace.uActiveBitMap&cbBitTab[u32NsId-1]))))
    {
        // 20190219_SamHu_02  NDST18.g00 NS=0 should pass
        u16StatusCode=cStatusInvalidNsFormat;
    }

#if (_EN_CHRONUS_UART_DEBUG)
    else if(!mChkUartCMDRdy&&validatePrp(cValidPrpGetLog))    // check prp if non error
#else
    else if(validatePrp(cValidPrpGetLog))    // check prp if non error
#endif
    {
        NLOG(cLogHost, GETLOGPAGE_C, 0, " Invalid Prp Offset ");
        u16StatusCode=cStatusInvalidPrpOffset;
    }
    else if(mChkSanitizeCommandAbort&&(uLid!=cLogErrInfo)&&(uLid!=cLogSmartInfo)&&(uLid!=cLogChangedNsList)
            &&(uLid!=cRsrvNotification)&&(uLid!=cLogSanitize))
    {
        if(mChkSanitizeInProgress)
        {
            NLOG(cLogHost, GETLOGPAGE_C, 1, " Sanitize in progress, Current issued Get Log Page LID=0x%04X ", uLid);
            u16StatusCode=cStatusSanitizeInProgress;
        }
        else
        {
            NLOG(cLogHost, GETLOGPAGE_C, 1, " Sanitize failed, Current issued Get Log Page LID=0x%04X ", uLid);
            u16StatusCode=cStatusSanitizeFailed;
        }
    }
    else
    {
#if (OEM==DELL)    ////20181213_KevinGG_01
        if(uLid==cLogExtendSmart)
        {
            WORD u16AvgOfGlobEraseCnt;
            WORD u16DriveUsedPercentage;
            u16AvgOfGlobEraseCnt=GetAvgECCore0(1);
            u16DriveUsedPercentage=div((u16AvgOfGlobEraseCnt*100), g32GrtPeCycle);

            if(u16DriveUsedPercentage>254)
            {
                u16DriveUsedPercentage=255;
            }

            if((!u16DriveUsedPercentage)&&(gsBadInfo.u16TotalNewBadCnt<=5))    // 20190225_SamHu_02 protect
            {
                u16DellInfo[0]=0;
                u16DellInfo[1]=0;
                u16DellInfo[2]=0;
                u16DellInfo[3]=0;
                u16DellInfo[4]=u16DriveUsedPercentage;
                u16DellInfo[5]=0;
                u16DellInfo[6]=0;
                u16DellInfo[7]=g16TLCGCSpareCnt_Run*2;
            }
            else
            {
                u16DellInfo[0]=(gsBadInfo.u16ProgFailFblkCnt*100)/(g16TLCGCSpareCnt_Ori*2);
                u16DellInfo[1]=(gsBadInfo.u16ProgFailFblkCnt*100)/(g16TLCGCSpareCnt_Ori*2);
                u16DellInfo[2]=(gsBadInfo.u16EraseFailFblkCnt*100)/(g16TLCGCSpareCnt_Ori*2);
                u16DellInfo[3]=(gsBadInfo.u16EraseFailFblkCnt*100)/(g16TLCGCSpareCnt_Ori*2);
                u16DellInfo[4]=u16DriveUsedPercentage;
                u16DellInfo[5]=(gsBadInfo.u16TotalNewBadCnt*100)/(g16TLCGCSpareCnt_Ori*2);
                u16DellInfo[6]=(gsBadInfo.u16TotalNewBadCnt*100)/(g16TLCGCSpareCnt_Ori*2);
                u16DellInfo[7]=g16TLCGCSpareCnt_Run*2;
                // gsBadInfo.u16ProgFailFblkCnt;    // ProgFail_CNT
                // gsBadInfo.u16EraseFailFblkCnt;  // EraseFail_CNT
                // gsBadInfo.u16TotalNewBadCnt; // TotalBadBlock_CNT
                // g16TLCGCSpareCnt*2; //OP
            }
        }
#endif/* if (OEM==DELL) */

        if(uLid==cLogFwSlotInfo)
        {
            BYTE uSlot2PageOffset;
            // Load External FW Version first
            loadIspPageCore0(0x0B, cSysBlockIsp);
            copyCcmVal((BYTE *)uarExtFwVersion1, (BYTE *)&garTsb0[31][0x190], 8);
            uSlot2PageOffset=(cTotalIspCodeSize/gSectorPerPlaneH)+0x0B;
            loadIspPageCore0(uSlot2PageOffset, cSysBlockIsp);
            copyCcmVal((BYTE *)uarExtFwVersion2, (BYTE *)&garTsb0[31][0x190], 8);
        }

        readWproPageCore0(cWproGetLogPg, cNvmeGetLogSIdx, 0);

        switch(uLid)
        {
            case cLogErrInfo:
                getLogNvmeErrInfo(uRetainAsyncEvent);
                u16BufIdx=cNvmeGetLogSIdx;

                if(u32OffsetLower>=sizeof(ERRORINFO))
                {
                    u32OffsetLower=0;
                }

                break;

            case cLogSmartInfo:
                getLogNvmeSmart(uRetainAsyncEvent);
                u16BufIdx=cNvmeGetLogSmartIdx;

                if(u32OffsetLower>=512)
                {
                    u32OffsetLower=0;
                }

                break;

            case cLogFwSlotInfo:

                if(!uRetainAsyncEvent)
                {
                    mClrAerNoticeTypeMask;
                    mClrAerFwActive;
                }

                if(gsSmart.usStatus.uNextFwSlot!=cNoNextActiveFirmwareSlot)
                {
                    gpGetLog->usFwSlot.uarFrs[cFirmwareSlotAfi][0]|=(((gsSmart.usStatus.uNextFwSlot+1)&0x07)<<4);
                }
                else    // 20181205_SamHu_01
                {
                    gpGetLog->usFwSlot.uarFrs[cFirmwareSlotAfi][0]|=(((gsSmart.usStatus.uCurrFwSlot+1)&0x07)<<4);
                }

                copyCcmVal((UCBYTE *)(gpGetLog->usFwSlot.uarFrs[cFirmwareSlot1]), (BYTE *)uarExtFwVersion1, 8);
                copyCcmVal((UCBYTE *)(gpGetLog->usFwSlot.uarFrs[cFirmwareSlot2]), (BYTE *)uarExtFwVersion2, 8);

                u16BufIdx=cNvmeGetLogFwSlotIdx;

                if(u32OffsetLower>=sizeof(FWSLOTINFO))
                {
                    u32OffsetLower=0;
                }

                break;

            case cLogCmdEffect:
                u16BufIdx=cNvmeGetLogCmdEffectIdx;

                if(u32OffsetLower>=sizeof(CMDEFFECTLOG))
                {
                    u32OffsetLower=0;
                }

                break;

            case cLogSelfTest:
                uDstAbort=(gpGetLog->usDstLog.uCurrDstOperation&0x0F);
                uCurrentOperation=(gpGetLog->usDstLog.uCurrDstOperation>>4);
                u32NvmeDstPeriodMs=(getRtcCurrentMs()-gpGetLog->usDstLog.u32NvmeDstStartTimeMs);
// 20181206_SamHu_02
                u8capacityIndex=GetCapacityIndex();

                if(u8capacityIndex<=11)    // under 256GB 2min
                {
                    u16DstExtendedTime=cDstExtendedTime_256;
                }
                else if(u8capacityIndex<=13)    // under 512GB 4min
                {
                    u16DstExtendedTime=cDstExtendedTime_512;
                }
                else    // 8min
                {
                    u16DstExtendedTime=cDstExtendedTime_1024;
                }

                if(uDstAbort||((uCurrentOperation==cOperationShortDstInProgress)&&(u32NvmeDstPeriodMs>=cDstShortTime*1000))
                   ||((uCurrentOperation==cOperationExtendedDstInProgress)&&(u32NvmeDstPeriodMs>=u16DstExtendedTime*1000)))
                {
                    handleDst();
                }

                u16BufIdx=cNvmeGetLogDstIdx;

                if(u32OffsetLower>=564)
                {
                    u32OffsetLower=0;
                }

                break;

#if _ENABLE_TELEINITLOG
            case cLogTelemetryHost:

                if((u32OffsetLower&0x1FF)||(u32NUMD&0x1FF))    // 20181210_SamHu_01 not a multiple of 512 bytes
                {
                    u16StatusCode=cStatusInvalidField;
                }
                else
                {
                    getLogTelemetryHost();
                    u16BufIdx=cNvmeGetLogSIdx;

                    if(u32OffsetLower>=sizeof(TELELOG))
                    {
                        u32OffsetLower=0;
                    }
                }

                break;

            case cLogTelemetryController:

                if((u32OffsetLower&0x1FF)||(u32NUMD&0x1FF))    // 20181210_SamHu_01 not a multiple of 512 bytes
                {
                    u16StatusCode=cStatusInvalidField;
                }
                else
                {
                    getLogTelemetryController(uRetainAsyncEvent);
                    u16BufIdx=cNvmeGetLogSIdx;

                    if(u32OffsetLower>=sizeof(TELELOG))
                    {
                        u32OffsetLower=0;
                    }
                }
                break;
#endif/* if _ENABLE_TELEINITLOG */
#if _ENABLE_SANITIZE
            case cLogSanitize:
                getLogSanitize(uRetainAsyncEvent);
                u16BufIdx=cNvmeGetLogSanitizeIdx;

                if(u32OffsetLower>=512)
                {
                    u32OffsetLower=0;
                }
                break;
#endif
            case cLogVendorTelemetry:
                getLogVendorTelemetry();
                u16BufIdx=cNvmeGetLogSIdx;    // Use first 1k since don't use wpro data temporary
                break;

#if (OEM==DELL)
            case cLogExtendSmart:    // 20181203_SamHu_01
                getLogDellSmart(uRetainAsyncEvent, u16DellInfo);
                u16BufIdx=cNvmeGetLogDellSmartIdx;

                if(u32OffsetLower>=512)
                {
                    u32OffsetLower=0;
                }
                break;
#endif

#if (OEM==LENOVO)
            case cLogLenovoPageDFh:    // 20190107_SamHu_01
                getLogLenovoPageDFh(uRetainAsyncEvent);
                u16BufIdx=cNvmeGetLogLenovoPageDFhIdx;

                if(u32OffsetLower>=512)
                {
                    u32OffsetLower=0;
                }

                break;

            case cLogPLPStatistics:
                getLogPLPStatistics(uRetainAsyncEvent);
                u16BufIdx=cNvmeGetLogPLPStatisticsIdx;

                if(u32OffsetLower>=8)
                {
                    u32OffsetLower=0;
                }
                break;
#endif/* if (OEM==LENOVO) */

            default:
                u16StatusCode=cStatusInvalidLogPage;
                break;
        }    /* switch */

        if(u32OffsetLower)
        {
            // Don't save GetLog wpro after here
            if(u32OffsetLower<cSectorSize)
            {
                if(((u32OffsetLower+(u32NUMD<<2))>cSectorSize)&&(uLid==cLogSmartInfo))    // Jira-103
                {
                    bopClrRam((LWORD)(BYTE *)&g32arTsb0[u16BufIdx+1], ((u32NUMD<<2)+u32OffsetLower-cSectorSize), 0x00000000, cBopWait|cClrTsb);
                }

                copyCcmVal((BYTE *)(&garTsb0[u16BufIdx][0]),
                           (BYTE *)(&garTsb0[u16BufIdx+(u32OffsetLower/cSectorSize)][(u32OffsetLower%cSectorSize)]),
                           (u32NUMD<<2));
            }
            else
            {
                bopClrRam((LWORD)(BYTE *)&g32arTsb0[u16BufIdx][0], (u32NUMD<<2), 0x00000000, cBopWait|cClrTsb);
            }
        }
    }

#if (_EN_CHRONUS_UART_DEBUG)
    if(mChkUartCMDRdy)
    {
        g32arUartCQEntryDW[3]=u16StatusCode<<17;
        loadISPCodeCore0(cUartTsbBank, 2);
        sendUartCmdRsp(u16BufIdx);
    }
    else
#endif
    {
        if(u16StatusCode)
        {
            manualCompletion(u16StatusCode, 0x0, cNoRwCmd, 0x0);    // manual send completion, and pop next cmd
        }
        else
        {
            trigNonRWCmd(u16BufIdx, 0x0, cTsb0, cNvmeRead, cAutoCq);    // Set xferCnt=0 for get log page special case
        }
    }
}    /* nvmeGetLogPage */







