







#include "inc/Option.h"
#include "inc/TypeDef.h"
#include "inc/GlobVar0.h"
#include "inc/ProType.h"
#include "inc/Reg.h"

#if (!_ICE_LOAD_ALL)
#pragma default_function_attributes = @ ".SYS_CTRL"
#endif

#if (_CPUID!=1)

// System PLL Output Frequency is : [pll_ref_clk*(syspll_div_sel)] / divider

// Set PreScale
// pre_scale = 1'b0 -> pll_ref_clk = 25MHZ
// pre_scale = 1'b1 -> pll_ref_clk = 12.5MHZ

// Set VCO Sel
// vco_sel = 3'b000 => divider = 2,
// vco_sel = 3'b001 => divider = 4,
// vco_sel = 3'b010 => divider = 8,
// vco_sel = 3'b011 => divider = 16,
// vco_sel = 3'b100 => divider = 32,
// vco_sel = 3'b101 => divider = 64,
// vco_sel = 3'b110 => divider = 128,
// vco_sel = 3'b111 => divider = 256,

void setSysPllClock(WORD u16SysClk)
{
    WORD u16DivSel, u16Vc0Sel;

    if(u16SysClk<25)
    {
        u16Vc0Sel=cVcoSelDiv64;
        u16DivSel=(u16SysClk<<6)/25;
    }
    else if((u16SysClk>=25)&&(u16SysClk<50))
    {
        u16Vc0Sel=cVcoSelDiv32;
        u16DivSel=(u16SysClk<<5)/25;
    }
    else if((u16SysClk>=50)&&(u16SysClk<100))
    {
        u16Vc0Sel=cVcoSelDiv16;
        u16DivSel=(u16SysClk<<4)/25;
    }
    else if((u16SysClk>=100)&&(u16SysClk<200))
    {
        u16Vc0Sel=cVcoSelDiv8;
        u16DivSel=(u16SysClk<<3)/25;
    }
    else if((u16SysClk>=200)&&(u16SysClk<400))
    {
        u16Vc0Sel=cVcoSelDiv4;
        u16DivSel=(u16SysClk<<2)/25;
    }
    else
    {
        u16Vc0Sel=cVcoSelDiv2;
        u16DivSel=(u16SysClk<<1)/25;
    }

    if(gFormFactor==cBGA)
    {
        // _DIS_EXTERNAL_OSC
        if((rmChkFllTrimDone)&&(rmGetCurFllTrimVal==0x00))
        {
            rmCurFllTrimVal(0x40);    // about 25Mhz
        }

        rmSetSysPllClock(cLockSel160us, u16DivSel, cPreScale25Mhz, u16Vc0Sel, cOscSel);
    }
    else
    {
        // _EN_EXTERNAL_OSC
        rmSetSysPllClock(cLockSel160us, u16DivSel, cPreScale25Mhz, u16Vc0Sel, cXtalSel);
    }
}    /* setSysPllClock */

#endif/* if (_CPUID!=1) */

LWORD tran2DecClk()
{
    LWORD u32DecClk;
    WORD u16Divider;
    BYTE uPLLDivSel;
    WORD u16PLLVcoSel;
    BYTE uPreScale;

    u16PLLVcoSel=rmGetSysPllVcoSel;    // u16PLLVcoSel=(rmGetSysPllVcoSel&0x0F);
    uPreScale=rmGetSysPllPreScale;    // uPreScale=u16PLLVcoSel&0x08;
    // u16PLLVcoSel&=0x07;
    uPLLDivSel=rmGetSysClkPll;

    if(uPreScale==0)
    {
        u32DecClk=25000000;    // 25MHz
    }
    else if(uPreScale==1)
    {
        u32DecClk=12500000;    // 12.5MHz
    }
    // else if(uPreScale==2)  //mark here, 2263
    // {
    //    u32DecClk=6500000;    // 6.5MHz
    // }
    else
    {
        while(uPreScale)
            ;
    }

    if(u16PLLVcoSel==0)
    {
        u16Divider=2;
    }
    else if(u16PLLVcoSel==1)
    {
        u16Divider=4;
    }
    else if(u16PLLVcoSel==2)
    {
        u16Divider=8;
    }
    else if(u16PLLVcoSel==3)
    {
        u16Divider=16;
    }
    else if(u16PLLVcoSel==4)    // 2263
    {
        u16Divider=32;
    }
    else if(u16PLLVcoSel==5)    // 2263
    {
        u16Divider=64;
    }
    else if(u16PLLVcoSel==6)    // 2263
    {
        u16Divider=128;
    }
    else if(u16PLLVcoSel==7)    // 2263
    {
        u16Divider=256;
    }
    else
    {
        while(u16PLLVcoSel)
            ;
    }

    u32DecClk=(u32DecClk*uPLLDivSel)/u16Divider;

    return u32DecClk;
}    /* tran2DecClk */

void setFlashClock(WORD u16FlashClk)
{
    WORD u16DivSel, u16Vc0Sel;
    BYTE uTempDllDlyCnt=0;

    if(u16FlashClk<25)
    {
        u16Vc0Sel=cVcoSelDiv64;
        u16DivSel=(u16FlashClk<<6)/25;
    }
    else if((u16FlashClk>=25)&&(u16FlashClk<50))
    {
        u16Vc0Sel=cVcoSelDiv32;
        u16DivSel=(u16FlashClk<<5)/25;
    }
    else if((u16FlashClk>=50)&&(u16FlashClk<100))
    {
        u16Vc0Sel=cVcoSelDiv16;
        u16DivSel=(u16FlashClk<<4)/25;
    }
    else if((u16FlashClk>=100)&&(u16FlashClk<200))
    {
        u16Vc0Sel=cVcoSelDiv8;
        u16DivSel=(u16FlashClk<<3)/25;
    }
    else if((u16FlashClk>=200)&&(u16FlashClk<400))
    {
        u16Vc0Sel=cVcoSelDiv4;
        u16DivSel=(u16FlashClk<<2)/25;
    }
    else if((u16FlashClk>=400)&&(u16FlashClk<=800))
    {
        u16Vc0Sel=cVcoSelDiv2;
        u16DivSel=(u16FlashClk<<1)/25;
    }
    else
    {
        gsFtlDbg.u16DummyFailType=cSetFlashClock;
        debugWhile();
    }

    rmSetFshPllClock(cLockSel160us, u16DivSel, cPreScale25Mhz, u16Vc0Sel);

    rmSetLdpcPllClock(cLockSel160us, u16DivSel, cPreScale25Mhz, u16Vc0Sel);
    rmEnClk8Dsp;
    rmSetDspPllClock(cLockSel160us, u16DivSel, cPreScale25Mhz, u16Vc0Sel);

    while(!rmChkFshPllLock)
        ;

    rmSysSetDllRst;    // reset Flash Master DLL
    rmSysSetDllAutoLock;
    sysDelay(64);    // for 200MHz system clock
    rmSysClrDllRst;    // clr reset flash master dll
    sysDelay(64);    // for 200MHz system clock

    while(!rmChkSysDllLock)
        ;// chk flash master dll already locked

    uTempDllDlyCnt=rmGetFshDllDlyCnt;

    while((uTempDllDlyCnt!=rmGetFshDllDlyCnt)||(uTempDllDlyCnt==0x00))
    {
        uTempDllDlyCnt=rmGetFshDllDlyCnt;
    }

    rmSysClrDllAutoLock;
    rmSetFshDllDlyCnt(uTempDllDlyCnt);
}    /* setFlashClock */

#if (_CPUID!=1)

// GPIO clear interrupt
// FW need to write this register only when the corresponding interrupt bit is set to edge mode.
void gpioClrIsr(LWORD u32RegIdx, BYTE uPinIdx)
{
    LWORD u32ShiftCnt=0;
    BYTE uPxShift=0;

    if(u32RegIdx==rcGpioIntSetP0)
    {
        uPxShift=0;
    }
    else if(u32RegIdx==rcGpioIntSetP1)
    {
        uPxShift=8;
    }
    else if(u32RegIdx==rcGpioIntSetP2)
    {
        uPxShift=16;
    }

    u32ShiftCnt=(uPinIdx)+uPxShift;
    setRegMask((void *)&r32SysCtrl0[rcGpioIntrClr/4], 0x1<<u32ShiftCnt, 0xffffffff);
}    /* gpioClrIsr */

#endif/* if (_CPUID!=1) */

// =================== RTC ===================

LWORD getRtcCurrent1s()
{
    LWORD u32Sec;

    do
    {
        u32Sec=rmGetRtc1sTick;
    }
    while(u32Sec!=rmGetRtc1sTick);

    return u32Sec;
}    /* getRtcCurrent1s */

LWORD getRtcCurrent32k()
{
    LWORD u32Rtc32k;

    do
    {
        u32Rtc32k=rmGetRtc32kTick;
    }
    while(u32Rtc32k!=rmGetRtc32kTick);

    return u32Rtc32k;
}

// Avoid TSB code jump code for security.
LWORD getRtcCurrentMsForTsbCode()
{
    return getRtcCurrentMs();
}

LWORD getRtcCurrentMs()
{
    LWORD u32MsTick, u32Sec, u32Time;

    do
    {
        u32Sec=rmGetRtc1sTick;
        u32MsTick=rmGetRtc32kTick;
    }
    while((u32Sec!=rmGetRtc1sTick)||(u32MsTick!=rmGetRtc32kTick));

    // u32Time=((u32Sec*500)+(((u32MsTick&0x3FFF)*1000)>>15));  //2260 A1
    u32Time=((u32Sec*1000)+(((u32MsTick&0x7FFF)*1000)>>15));    // 2262/2263

    // Update in isr
    // u32SecDiff= div((u32Time-g32LastUpdatedRtcSec*1000), 1000);
    // gsDebugInfo.u32PowerOnSec+= u32SecDiff; // accumulate
    // g32LastUpdatedRtcSec+= u32SecDiff; // since this power cycle

    return u32Time;
}    /* getRtcCurrentMs */

#if (_CPUID!=1)

BYTE chkRtc32kTimeout(LWORD u32TimeoutVal)
{
    LWORD u32Rtc32kEndVal;

    u32Rtc32kEndVal=getRtcCurrent32k();

    if(u32Rtc32kEndVal>=g32Rtc32kStartVal)
    {
        if((u32Rtc32kEndVal-g32Rtc32kStartVal)>u32TimeoutVal)
        {
            return cSuccess;    // timeout
        }
        else
        {
            return cFalse;
        }
    }
    else
    {
        if(((0xFFFFFFFF-g32Rtc32kStartVal)+u32Rtc32kEndVal)>u32TimeoutVal)
        {
            return cSuccess;    // timeout
        }
        else
        {
            return cFalse;
        }
    }
}    /* chkRtc32kTimeout */

LWORD chkRtc32kProcTime(LWORD u32StartTime)
{
    LWORD u32Rtc32kEndVal;

    u32Rtc32kEndVal=getRtcCurrent32k();

    if(u32Rtc32kEndVal>=u32StartTime)
    {
        return u32Rtc32kEndVal-u32StartTime;
    }
    else
    {
        return (0xFFFFFFFF-u32StartTime)+u32Rtc32kEndVal;
    }
}

// #if (_CPUID!=1)

void startRtcCountingMs()
{
    g32RtcStartTimeMs=getRtcCurrentMs();
    g32BackgroundTimeMs=0;
}

void startRtcCounting1s()
{
    g32RtcStartTime1s=getRtcCurrent1s();
    // g32BackgroundTime= 0;
}

void startRtcCountingWcTemp()
{
    if(!gsSmart.usStatus.uOverTempBitMap&cOverWcTemp)
    {
        gsSmart.usStatus.u32RtcStartTimeWcTemp=getRtcCurrent1s();
        gsSmart.usStatus.uOverTempBitMap|=cOverWcTemp;
    }

    // g32BackgroundTime= 0;
}

void startRtcCountingCcTemp()
{
    if(!gsSmart.usStatus.uOverTempBitMap&cOverCcTemp)
    {
        gsSmart.usStatus.u32RtcStartTimeCcTemp=getRtcCurrent1s();
        gsSmart.usStatus.uOverTempBitMap|=cOverCcTemp;
    }

    // g32BackgroundTime= 0;
}

LWORD getRtcDiffMs()
{
    return getRtcCurrentMs()-g32RtcStartTimeMs;
}

LWORD getRtcDiff1s()
{
    return getRtcCurrent1s()-g32RtcStartTime1s;
}

LWORD getRtcDiffWcTemp()
{
    return getRtcCurrent1s()-gsSmart.usStatus.u32RtcStartTimeWcTemp;
}

LWORD getRtcDiffCcTemp()
{
    return getRtcCurrent1s()-gsSmart.usStatus.u32RtcStartTimeCcTemp;
}

#if 0
// =================== Arm Timer ===================
// example:
// count=enableArmTimer()
// .
// .
// .
// while(chkArmTimerTimeOut(count));
// disableArmTimer();

LWORD getFreq(WORD u16PLLSel)
{
    BYTE uVco, uPreScale;
    LWORD u32Freq;

    uVco=((u16PLLSel>>7)&0x0003)+1;
    uPreScale=(u16PLLSel>>9)&0x0003;
    u32Freq=((u16PLLSel&0x7f)*2500)>>(uVco+uPreScale);    // Unit: 10KHz

    return u32Freq;
}

BYTE enableCCNTCounter(LWORD u32Cnt)
{
    rmCp15DisCCNT;
    __ISB();
    rmCp15RstCNT;
    __ISB();
    rmCp15EnCCNT;
    __ISB();

    return 0;
}

LWORD enableArmTimer(LWORD u32IdleTimeMs)
{
    LWORD u32StopCnt, u32Freq;

    u32Freq=getFreq(rmGetSysClkPll);    // return unit 10KHz
    u32StopCnt=u32Freq*10*u32IdleTimeMs;

    enableCCNTCounter(u32StopCnt);

    return u32StopCnt;
}

void disableArmTimer()
{
    rmCp15DisCCNT;
}

BYTE chkArmTimerTimeOut(LWORD u32TimeOutCnt)
{
    return rmCp15ChkCCNT>=u32TimeOutCnt;
}

#endif/* if 0 */

// =================== System Timer ===================

void enSysTmr(WORD u16TmrVal)    // unit=65536*40ns ~ 2.62 ms
{
    // QWORD u64ClkSrc=25000000;
    // LWORD u32Tick;

    if(!g32SysTmrOn)
    {
#if (_CPUID!=1)
        g32SysTmrOn=1;
#else
        g32SysTmrOn=2;
#endif
        rmResetTimerCnt;

        rmSetSysTimerCnt(u16TmrVal);    // u32Tick);    // ~58ms = 22*65536*40ns, 40ns=1/25MHz,
        rmTimerEnable;
    }
}    /* enSysTmr */

void enSysTmrMs(WORD u16TmrValMs)
{
    // please do not turn on system timer together. 63XT only has one system timer.
    // If you can use RTC to replace your function, please use RTC.
    // System timer is dangerous.
    LWORD u32ClkSrcX1000=25000;    //  (25MHZ/1000)
    LWORD u32Tick;

    if(!g32SysTmrOn)
    {
#if (_CPUID!=1)
        g32SysTmrOn=1;
#else
        g32SysTmrOn=2;
#endif
        rmResetTimerCnt;

        if(rmGetSysXtalDiv==1)    // Xtal is 6.25MHz
        {
            u32ClkSrcX1000>>=2;
        }
        else if(rmGetSysXtalDiv==2)    // Xtal is 1.5625MHz
        {
            u32ClkSrcX1000>>=4;
        }
        else if(rmGetSysXtalDiv==3)    // Xtal is 195.3125 KHz
        {
            u32ClkSrcX1000>>=7;
        }

        // RTC Deviation
        u16TmrValMs-=((u16TmrValMs<<3)>>8);    // 3.125%

        u32Tick=(u16TmrValMs*u32ClkSrcX1000)>>16;

        rmResetTimerCnt;

        if(!u32Tick)
        {
            u32Tick=1;    // error protect
        }

        rmSetSysTimerCnt(u32Tick);    // ~58ms = 22*65536*40ns, 40ns=1/25MHz,
        rmTimerEnable;
    }
}    /* enSysTmr */

void disSysTmr()
{
    if(g32SysTmrOn)
    {
        rmTimerDisable;

        while(rmChkTimerEnable)
            ;

        g32SysTmrOn=0;
    }

#if (_CPUID!=1)
    // if(gCpu0TOFlag)
    // {
    gCpu0TOFlag=0;
    // }
#else
    g32Cpu1TOFlag=0;
#endif
}    /* disSysTmr */

// =================== Thermal sensor (Temperature)===================
#if (!_EN_NAND_TEMP)
void sleepRWTickTemp()
{
    LWORD u32Loop;
    LWORD u32SleepSec;

    u32SleepSec=(getRtcCurrent1s()-g32SleepStartTime1s)&0x00000007;

    for(u32Loop=0; u32Loop<u32SleepSec; u32Loop++)
    {
        g32arRWTickCnt[gRWTickCntPtr]=g32RWTickCnt;
        gRWTickCntPtr=(gRWTickCntPtr+1)&0x07;
    }
}

#endif

// SoC Junction Temperature
BYTE getIcJunctionTemp(WORD u16TempCode)
{
    BYTE uTemp=0;
    SLWORD s32Slope;

    // 226X : uTemp = (850+((u16TempCode-g16Code85)*550/(g16Code85-g16Code30))+5)/10
    s32Slope=(SLWORD)(g16Code85-u16TempCode)*880/(g16Code85-g16Code30);

    if(s32Slope>1360)    // overflow protection
    {
        uTemp=0;    // report host 0 degree C
    }
    else
    {
        uTemp=(1360-s32Slope)>>4;
    }

    return uTemp;
}    /* getIcJunctionTemp */

BYTE getThermalSensorTemp()
{
    BYTE uTjTemp=0;
    BYTE uSensorSel;
    WORD u16TempCode;

#if (!_EN_NAND_TEMP)
    BYTE uThetaJc=0, uTemp=0;
    BYTE uTmpPtr, uTmpPtrN;
    LWORD u32Loop, u32TmpRWTick, u32AvgRWTick=0;
    THERMALCALC *usThermalCalc;
#endif

    gThsor0Temperature=0;
    gThsor1Temperature=0;

    uSensorSel=gsLightSwitch.usThermalLs.uSensorSel;

    if(uSensorSel&cAsicSensor1)
    {
        do
        {
            u16TempCode=rmThsor1Value;
        }
        while(u16TempCode!=rmThsor1Value);

        gThsor1Temperature=getIcJunctionTemp(u16TempCode);
        uTjTemp=gThsor1Temperature;
    }

    if(uSensorSel&cAsicSensor0)
    {
        do
        {
            u16TempCode=rmThsor0Value;
        }
        while(u16TempCode!=rmThsor0Value);

        gThsor0Temperature=getIcJunctionTemp(u16TempCode);    // Get SoC junction temperature
        uTjTemp=gThsor0Temperature;
    }

    if((uSensorSel&cAsicSensor01)==cAsicSensor01)
    {
        uTjTemp=(gThsor0Temperature+gThsor1Temperature)>>1;
    }

    if(uSensorSel&cNandSensor)
    {
        g32NandTempSensor=1;
    }

    uTmpPtr=(gRWTickCntPtr-1)&0x07;

    // Theta Tjunction to Tcase calculation
    for(u32Loop=0; u32Loop<4; u32Loop++)
    {
        uTmpPtrN=uTmpPtr;
        uTmpPtr=(uTmpPtr-1)&0x07;

        if(g32arRWTickCnt[uTmpPtrN]>=g32arRWTickCnt[uTmpPtr])
        {
            u32TmpRWTick=g32arRWTickCnt[uTmpPtrN]-g32arRWTickCnt[uTmpPtr];
        }
        else
        {
            u32TmpRWTick=(0xFFFFFFF-g32arRWTickCnt[uTmpPtr])+g32arRWTickCnt[uTmpPtrN];
        }

        u32AvgRWTick+=u32TmpRWTick;
    }

    u32AvgRWTick=u32AvgRWTick>>2;

    // [Momo] Average RW Tick count offset themperature table in light switch
    usThermalCalc=&gsLightSwitch.usThermalLs.usNormalization.usThermalCalc[0];
    uThetaJc=gsLightSwitch.usThermalLs.usNormalization.usThermalCalc[5].uThetaJc;

    for(u32Loop=0; u32Loop<6; u32Loop++)
    {
        if(u32AvgRWTick>>(usThermalCalc->uShiftBit))
        {
            uThetaJc=usThermalCalc->uThetaJc;
            u32Loop=6;
        }
        else
        {
            usThermalCalc++;
        }
    }

// renew thermal offset F.J. Kuo 20190618
    if(uTjTemp>=uThetaJc+gThermalOffset)
    {
        uTemp=uTjTemp-uThetaJc-gThermalOffset;
    }
    else
    {
        uTemp=uTjTemp;
    }

    return uTemp;
}    /* getThermalSensorTemp */

#if 0
BYTE getCurrentNandTemp(BYTE uActiveCh, BYTE uIntlvOddA)
{
    BYTE uTemp=0;

    setFLActCh(uActiveCh);

    while(rmChkCmdFifoBz)
        ;

    rmSetSctrAddr(0xE7);
    rmCeOn(uIntlvOddA<<gIntIntlv2n);    // outside decide
    rmCle(0xEE);    // (Ab)

    rmManAle(1);    // (A) use ALE12

    while(rmChkCmdFifoBz)
        ;

    rmNop(5);    // need 100 ns

    rmCle(gReadStatusCmd);    // gStatusCmd);
    rmRdStatus(0x60);    // (Ab) Polling Status
    rmCle(0x00);

#if _INTEL_SYSTEM
    // else
    {
        rmManRd(4);
    }
#endif

    while(rmChkCmdFifoBz)
        ;

    rmAllCeOff;

    uTemp=rFLCtrl[rcRd0];
    return uTemp;
}    /* getCurrentNandTemp */

#endif/* if 0 */

// =================== Thermal sensor (Temperature) End ===================

void initUart()
{
    LWORD u32UARTfre;

    rmUartReset;
    rmUartEn;
    rmSetUartIntrMask(0x0E);    // rUartCtrl[rcUartImr]=0x0E;

    u32UARTfre=tran2DecClk();
    // rSysCtrl0[rcGpioP1Io]=cBit0|cBit3|cBit5;  //DAS, TX
    rmUartBaudRate=(u32UARTfre/921600)-1;
    // rmUartBaudRate=(u32UARTfre/115200)-1;
}

void initBusErrHandler()
{
    // set TSB Like bus timeout value, auto enable error check when IRQbit24 enable
    rmSetTsbErrTimerIntVal(cBusTimeout);
    rmSetBvaDmaErrTimerIntVal(cBusTimeout);
    rmSetBvaCpuErrTimerIntVal(cBusTimeout);

    // set AHB bus timeout value, auto enable error check when IRQbit24 enable
    // AHB timeout value will be set by HW
    // Disable bit mask to enable all domain except AHCI
    rmDisCpuCfgToMaskLow;
    rmDisCpuCfgToMaskHighWoAhci;
    rmDisCpuCfgDummyMaskLow;
    rmDisCpuCfgDummyMaskHighWoAhci;
}

#endif/* if (_CPUID!=1) */

#if (!_ICE_LOAD_ALL)
#pragma default_function_attributes =
#endif







