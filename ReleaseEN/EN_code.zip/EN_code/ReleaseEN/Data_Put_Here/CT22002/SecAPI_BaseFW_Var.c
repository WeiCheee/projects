







#include "inc/Security.h"
#include "inc/SecAPI_BaseFW_Define.h"
#include "inc/SecAPI_BaseFW_Type.h"
#include "inc/SecAPI_BaseFW_Var.h"
#include "inc/SecAPI_BaseFW_FuncPtr.h"

#if _PRJ_BOOT2
__root CBYTE cbSecBaseTag[16] @ ".SECBASE_TAG"=
{
    "Q0913A SECBASE 0"
};
#elif _PRJ_ISP
__root CBYTE cbSecBaseTag[16] @ ".SECBASE_TAG"=
{
    "Q0913A SECBASE 1"
};
#elif _PRJ_NVME
__root CBYTE cbSecBaseTag[16] @ ".SECBASE_TAG"=
{
    "Q0913A SECBASE 2"
};
#elif _PRJ_SMIVU
__root CBYTE cbSecBaseTag[16] @ ".SECBASE_TAG"=
{
    "Q0913A SECBASE 3"
};
#else/* if _PRJ_BOOT2 */
__root CBYTE cbSecBaseTag[16] @ ".SECBASE_TAG"=
{
    "Q0913A SECBASE  "
};
#endif/* if _PRJ_BOOT2 */

#pragma default_variable_attributes = @ ".SecurityAPI_Const_BaseFW"
CBYTE cbSmiSecureDefaultPassword[cRootKeySize]=
{
    "SMI_SM2263XT_Secure_SSD_20170123"
};

CBYTE cbRootKeyContext[16]=
{
    "SMISecurityTeamA"
};
CBYTE cbRootKeyLabel[7]=
{
    "RootKey"
};

#pragma default_variable_attributes =

#pragma default_variable_attributes = @ ".SecurityAPI_Var_CryptoLib"    // TSB0  (512B)
#pragma data_alignment=16
BYTE garCryptoTmpBuf[512];    // For Crypto temp data
#pragma default_variable_attributes =

#pragma default_variable_attributes = @ ".SecurityAPI_Var_BaseFW"    // TSB1 (2K)

#if _ENABLE_SECAPI
// TCG parameters in TSB0

// =====Don't need to be initialized for Power-cycle and DevSlp=======
LWORD g32SecLba;
LWORD g32SecGlobalHPage;
WORD g16ReceivedComId;
WORD g16ReadUnitCnt;
BYTE gReceivedProtocolId;
BYTE gReceivedRpmbTarget;    // Used for RPMB
BYTE gSecStartSectorH;

// IEEE1667 parameters in DRAM
// =====Need to be initialized for Power-cycle and DevSlp=======

// =====Don't need to be initialized for Power-cycle and DevSlp=======
#endif/* if _ENABLE_SECAPI */

#pragma default_variable_attributes =

#pragma default_variable_attributes = @ ".SecurityAPI_SecurityVar"    // TSB1
/* Used in GatherSecurityPageInfo() and UpdataSecurityKeyDRAMInfo() */
BYTE garEncryptedRootKey[cSp800_38fEncryptedSize];
BYTE garEncryptedOriginalKEK[cSp800_38fEncryptedSize];
BYTE garEncryptedMEK[cSp800_38fEncryptedMekSize];

#pragma default_variable_attributes =







