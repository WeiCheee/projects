







#include "inc/ProType.h"
// #include "inc/FlashCtrl.h"
#include "inc/GlobVar0.h"
#include "inc/GlobVarS.h"
#include "inc/GlobVarT.h"
#include "inc/Reg.h"
#include "inc/FtlCtrl.h"
#include "inc/Mac.h"
#if _EN_CDMTRIG
#include "inc/DebugLog.h"
#include "inc/EventLogIDX.h"
#include "inc/EventLogFunctionIDX.h"
#endif
// ---------------------Chaney Pre-fix wait Pretest----------------------------//

// #define cLPNsPerH2FTab  (64*1024/4) //g16PagePerH2fTab
#define cBufOverFlowThr (16)    // gsRwCtrl.u16BufOvfl4kThr
// -------------------------------end------------------------------------------//
#if _PRJ_ISP
BYTE chkExitSeqR(BYTE uHwPrd, WORD u16Next)
{
    // while((gsRwCtrl.u32TrigHmbTail!=gsRwCtrl.u32TrigHmbHead)&&gsHmbInfo.uHmbFreeHwPrdCnt)
    // {
    //    postHmbReadData();
    // }

    chkHmbPrdDone();

    trigHostSeqRead(0);

    if(mChkHandlePcieErrF)
    {
        return cSpExit;
    }
    else if((!mChkReadAhead)||(uHwPrd==cNull))
    {
        return cFalse;
    }
    else if((u16Next!=cTrue)&&!rmGetPrdRestSctrCnt(uHwPrd))    // (u16Next!=cNull))
    {
        return cTrue;
    }
    else
    {
        return cFalse;
    }
}    /* chkExitSeqR */

#endif/* if _PRJ_ISP */

BYTE getReadSctrCnt(LWORD u32RestSctrCnt)
{
    BYTE uReadSctrCnt;

    uReadSctrCnt=cSctrPer4k-gStartSector;

    if(uReadSctrCnt>u32RestSctrCnt)
    {
        uReadSctrCnt=u32RestSctrCnt;
    }

    return uReadSctrCnt;
}

// void assignReadBuf(PRDQUEUE *upPrdInfo)
// {
// g16ReadBufPtr= getReadBufPtr(g16ReadBufPtr)+upPrdInfo->uStartSctr;
// upPrdInfo->u16BufPtr= g16ReadBufPtr;
// g16ReadBufPtr= addReadBufPtr(g16ReadBufPtr, upPrdInfo->u32SctrCnt);
//
// }

// void allocateRdHaddrTag(PRDQUEUE *upPrdInfo)
// {
// upPrdInfo->uRdHAddrIdx= getFreeRdHaddrTag();
// }

#if _PRJ_ISP
BYTE trigHostSeqRead(BYTE uFinish)
{
    WORD u16HostTrigTail;    // , u16HostTrig4kCnt, u16SeqRd4kRstCnt;
    BYTE uLastHwPrdIdx=0xFF;

    u16HostTrigTail=gsPrdInfo.uarSeqPrdQue[gsPrdInfo.uSeqPrdTail];
    // u16HostTrig4kCnt=gsPrdInfo.uarPrdQue[u16HostTrigTail].u16PrdRd4kCnt;

    while(gsPrdInfo.uSeqRCmdCnt&&(!mChkHandlePcieErrF))
    {
        chkReleaseFreeHwPrd();

        // if(!gsPrdInfo.uSeqRTrigCnt&&gsPrdInfo.uFreeHwPrdCnt)
        if(gsPrdInfo.uFreeHwPrdCnt)
        {
            gsPrdInfo.uSeqRTrigCnt++;

            trigHostRw(u16HostTrigTail, c32AutoDmaTrigR, cLastPrd|cTsb|cAutoBufflag|cCrcCheckEn);

            uLastHwPrdIdx=gsPrdInfo.uarPrdQue[u16HostTrigTail].uHwPrdIdx;
            // if (u16SeqRd4kRstCnt>=u16HostTrig4kCnt)
            // {
            //    u16SeqRd4kRstCnt=u16SeqRd4kRstCnt-u16HostTrig4kCnt;
            // }
            // else
            // {
            //    u16SeqRd4kRstCnt=0;
            // }

            gsPrdInfo.uSeqPrdTail=((gsPrdInfo.uSeqPrdTail+1)&(cSeqPrdDepth-1));
            gsPrdInfo.uSeqRCmdCnt--;

            if(gsPrdInfo.uSeqRCmdCnt==0)
            {
                break;
            }

            u16HostTrigTail=gsPrdInfo.uarSeqPrdQue[gsPrdInfo.uSeqPrdTail];
            // u16HostTrig4kCnt=gsPrdInfo.uarPrdQue[u16HostTrigTail].u16PrdRd4kCnt;
        }

        // gsPrdInfo.u16SeqRd4kRstCnt=u16SeqRd4kRstCnt;

        if(!uFinish||mChkHandlePcieErrF)
        {
            break;
        }
    }

    return uLastHwPrdIdx;
}    /* trigHostSeqRead */

BYTE trigHostPrdTaskR()
{
    BYTE uStartSctr;
    PRDQUEUE *upPrdInfo;
    WORD u16Prd4KCnt, u16Hblock, u16Hpage, u16PrdTrig;    // , u16BufFree4kCnt;
    LWORD u32SctrCnt, u32LbaAddr;

#if _ENABLE_SECAPI
    LWORD u32PhysicalGHP;
#endif

    u16PrdTrig=gsPrdInfo.usReadPrdList.u16Trig;

    // if(u16PrdTrig!=gsPrdInfo.usReadPrdList.u16Tail)
    // {
    //    u16BufFree4kCnt=calFreeRdBuf(gsPrdInfo.uarPrdQue[gsPrdInfo.usReadPrdList.u16Tail].u16BufPtr);
    // }
    // else
    // {
    //    u16BufFree4kCnt=c16ReadBufSize4K;
    // }
    if(mChkHandlePcieErrF)
    {
        return cFalse;
    }

    do
    {
        upPrdInfo=&gsPrdInfo.uarPrdQue[u16PrdTrig];
        u32LbaAddr=upPrdInfo->u32LbaAddr;
        u32SctrCnt=upPrdInfo->u32SctrCnt;
        uStartSctr=upPrdInfo->uStartSctr=u32LbaAddr&(cSctrPer4k-1);
        u16Prd4KCnt=upPrdInfo->u16PrdRd4kCnt=(u32SctrCnt+uStartSctr+(cSctrPer4k-1))>>cSctrTo4kShift;
#if _EN_CDMTRIG
        if((gCDMStatus==cCDM_PrePare)&&(g32LastLbaR==u32LbaAddr)&&(uStartSctr==0))    // 20190618_ChrisSu
        {
            g32CDM_SRCnt++;

            g32CDM_RSctrCnt+=u32SctrCnt;

            if(g32CDM_RSctrCnt>cCDM5G)    // 5G
            {
                g32CDMTimer=rmGetRtc1sTick;
                gCDMStatus=cCDM_Triger;
                NLOG(cLogGC, READ_C, 0, "CDM_Triger");
            }
        }
        else if((gCDMStatus==cCDM_PrePare)&&g32CDM_SRCnt)
        {
            g32CDM_RBrkCnt++;

            if((g32CDM_SRCnt>>3)<g32CDM_RBrkCnt)
            {
                /*
                   *              NLOG(cLogGC,
                   *   READ_C,
                   *   4,
                   *   "g32CDM_RBrkCnt = 0x%08x,g32CDM_SRCnt=0x%08x",
                   *   g32CDM_RBrkCnt>>16,
                   *   g32CDM_RBrkCnt,
                   *   g32CDM_SRCnt>>16,
                   *   g32CDM_SRCnt);
                   */
                if(g32CDM_RBrkCnt>0x200)
                {
                    NLOG(cLogGC, READ_C, 0, "Cancel CDMPrepare!");
                    InitCDM();
                }
            }
        }
#endif/* if _EN_CDMTRIG */

#if _ENABLE_SECAPI
        if(gbEnTCG)
        {
            if((u32LbaAddr+uStartSctr)>=g32HostTotalDataSectorCnt)    // for using RW command to obtain MBR
            {
                // u32PhysicalGHP=SecAPI_GetReadGHP_Request(uMode, u32LbaAddr>>cSctrTo4kShift);
                u32PhysicalGHP=GetReadGHP(u32LbaAddr>>cSctrTo4kShift);
                u32LbaAddr=u32PhysicalGHP<<cSctrTo4kShift;
                u32LbaAddr+=uStartSctr;
#if _ENABLE_SECAPI_R_DEBUG
                NLOG(cLogSecApiDebug, READ_C, 1, "trigHostPrdTaskR()-uMode = 0x%04X.", (WORD)cTcgReadOrigin);
                NLOG(cLogSecApiDebug,
                     READ_C,
                     4,
                     "trigHostPrdTaskR()-u32PhysicalGHP = 0x%08X , u32GHP = 0x%08X.",
                     (WORD)(u32PhysicalGHP>>16),
                     (WORD)u32PhysicalGHP,
                     (WORD)((u32LbaAddr>>cSctrTo4kShift)>>16),
                     (WORD)u32LbaAddr>>cSctrTo4kShift);
#endif
            }
            else    // normal case
            {
#if _ENABLE_SECAPI_R_DEBUG
                NLOG(cLogSecApiDebug, READ_C, 1, "trigHostPrdTaskR()-uMode = 0x%04X.", (WORD)cNormalRead);
                NLOG(cLogSecApiDebug,
                     READ_C,
                     4,
                     "trigHostPrdTaskR()-u32PhysicalGHP = 0x%08X , u32GHP = 0x%08X.",
                     0xFFFF,
                     0xFFFF,
                     (WORD)((u32LbaAddr>>cSctrTo4kShift)>>16),
                     (WORD)u32LbaAddr>>cSctrTo4kShift);
#endif
            }
        }
#endif/* if _ENABLE_SECAPI */

#if _EN_External_CDM
        if((g32LastLbaR==u32LbaAddr)||(u16Prd4KCnt>=cBufOverFlowThr)||(((u32LbaAddr&(c16SctrPerRH2fTab-1))+u32SctrCnt)>c16SctrPerRH2fTab))
#else
        if((g32LastLbaR==u32LbaAddr)||(u16Prd4KCnt>cBufOverFlowThr)||(((u32LbaAddr&(c16SctrPerRH2fTab-1))+u32SctrCnt)>c16SctrPerRH2fTab))
#endif
        {
            if(gsPrdInfo.uQCmdCnt)
            {
                break;
            }

#if _ENABLE_SECAPI
            if(((gbEnTCG&&!gMBRShadow)||!gbEnTCG)&&(g32LastLbaR==u32LbaAddr)
#if _EN_WUNCTable    // WUNCTable Chief_21081121
               &&(!gsWUNCInfo.uWuncCnt)
#endif
               )
#else
            if(g32LastLbaR==u32LbaAddr)
#endif
            {
                if(gsPrdInfo.uarPrdLink[u16PrdTrig].uNext==cNull)
                {
                    if(!mChkReadAhead)
                    {
                        gsRwCtrl.uConsecReadCnt++;

                        if(gsRwCtrl.uConsecReadCnt>=cSeqReadAheadThr)
                        {
                            mSetReadAhead;
                        }
                    }
                }
                else
                {
                    if(mChkReadAhead)
                    {
                        if(gsPrdInfo.uarPrdQue[gsPrdInfo.uarPrdLink[u16PrdTrig].uNext].u32LbaAddr!=(u32LbaAddr+u32SctrCnt))
                        {
                            termContiR();
                        }
                    }
                }
            }
            else
            {
                if(mChkReadAhead)
                {
                    termContiR();
                }
                else
                {
                    gsRwCtrl.uConsecReadCnt=0;
                }
            }

            if(!mChkContHAddrR)
            {
                g16ReadBufPtr=getReadBufPtr(g16ReadBufPtr)+uStartSctr;
            }

            upPrdInfo->u16BufPtr=g16ReadBufPtr;
            g16ReadBufPtr=addReadBufPtr(upPrdInfo->u16BufPtr, u32SctrCnt);

            gsPrdInfo.uarSeqPrdQue[gsPrdInfo.uSeqPrdHead]=u16PrdTrig;
            gsPrdInfo.uSeqPrdHead=((gsPrdInfo.uSeqPrdHead+1)&(cSeqPrdDepth-1));
            gsPrdInfo.uSeqRCmdCnt++;

            do
            {
                chkReleaseFreeHwPrd();

                if(gsPrdInfo.uFreeHwPrdCnt)
                {
                    gsPrdInfo.uSeqRTrigCnt++;

                    trigHostRw(gsPrdInfo.uarSeqPrdQue[gsPrdInfo.uSeqPrdTail], c32AutoDmaTrigR, cLastPrd|cTsb|cAutoBufflag|cCrcCheckEn);

                    gsPrdInfo.uSeqPrdTail=((gsPrdInfo.uSeqPrdTail+1)&(cSeqPrdDepth-1));
                    gsPrdInfo.uSeqRCmdCnt--;
                    break;
                }
            }
            while((gsPrdInfo.uSeqRCmdCnt==cSeqPrdDepth)&&(!mChkHandlePcieErrF));

            gsRwCtrl.u32ReadHostLbaN=((u32LbaAddr+u32SctrCnt)&~(cSctrPer4k-1))+c16ReadBufSize;
            gsRwCtrl.u32SeqRdFlag=cBit0;
            postFAddrInfoSeqR(upPrdInfo, u16PrdTrig, gsPrdInfo.uarPrdLink[u16PrdTrig].uNext);
        }
        else
        {
            if(gsRwCtrl.u32SeqRdFlag)
            {
                if(mChkReadAhead)
                {
                    termContiR();
                }
                else
                {
                    if(gsPrdInfo.uSeqRCmdCnt)
                    {
                        trigHostSeqRead(1);
                    }

                    while(gsPrdInfo.uSeqRTrigCnt&&(!mChkHandlePcieErrF))
                    {
                        chkReleaseFreeHwPrd();
                    }

                    gsRwCtrl.uConsecReadCnt=0;
                    gsRwCtrl.u32SeqRdFlag=0;
                }

                bopClrRam((LWORD)&garSrchSrcTab, sizeof(garSrchSrcTab), 0xFFFFFFFF, cClrCore0Dccm|cBopWait);
                // u16BufFree4kCnt=c16ReadBufSize4K;
            }

            // if(u16Prd4KCnt>u16BufFree4kCnt)
            // {
            //    break;
            // }
            // else
            // {
            //    u16BufFree4kCnt-=u16Prd4KCnt;
            // }

            if((gsRwCtrl.uSrchQCnt+u16Prd4KCnt)>=(cSrchQDepth-1))
            {
                break;
            }

            u16Hblock=u32LbaAddr/g32SectorPerBlockH;

            if(mChkSrcInCache(u16Hblock))
            {
                BYTE uLoop1=0, uLoop2=0;

                for(uLoop1=0; uLoop1<(cBufOverFlowThr+1); uLoop1++)
                {
                    if((garSrchSrcTab[((g16SrchSrcTabFreePtr+uLoop1)&(cSrchSrcNum-1))]==c32BitFF)&&
                       ((gsRwCtrl.uarSrchQ2RdHaddr[(gsRwCtrl.uSrchQHead+uLoop1)&(cSrchQDepth-1)]&cBit7)==0))
                    {
                        uLoop2++;

                        if(uLoop2==u16Prd4KCnt)
                        {
                            garSrchSrcTab[g16SrchSrcTabFreePtr&(cSrchSrcNum-1)]=c32Bit31;

                            break;
                        }
                    }
                    else
                    {
                        break;
                    }
                }

                if(u16Prd4KCnt>uLoop2)
                {
                    break;
                }
            }

            // g16ReadBufPtr=getReadBufPtr(g16ReadBufPtr)+uStartSctr;
            // upPrdInfo->u16BufPtr=g16ReadBufPtr;
            // g16ReadBufPtr=addReadBufPtr(g16ReadBufPtr, u32SctrCnt);

            upPrdInfo->ubQRdCmd=1;
            gsPrdInfo.uQCmdCnt++;
            upPrdInfo->u16RestQRd4kCnt=u16Prd4KCnt;
            tranLba2HAddr(u32LbaAddr, &gsReadHAddrInfo[u16PrdTrig]);
            u16Hblock=g16HBlock;
            u16Hpage=g16HPage;
            // gpHostAddrInfo->u16FlashRBufPtr=upPrdInfo->u16BufPtr;
            g16HSgmt=u16Hpage>>9;
            gpHostAddrInfo->u16Srch4kCnt=u16Prd4KCnt;
            gpHostAddrInfo->uSrchHitCnt=0;
            // gpHostAddrInfo->uHmbHitCnt=0;
            gpHostAddrInfo->uSrcFromH2F=0;

            if(mChkSrcInCache(u16Hblock))
            {
                BYTE uSrchQHead=gsRwCtrl.uSrchQHead, uNbsQIdx;
                // gpHostAddrInfo->uLoadTabState=cPostReadTab;
                gpHostAddrInfo->u16SrchSrcTabStIdx=g16SrchSrcTabFreePtr;
                g16SrchSrcTabFreePtr=(g16SrchSrcTabFreePtr+u16Prd4KCnt)&(cSrchSrcNum-1);

                do
                {
                    gsRwCtrl.usSrchQ[uSrchQHead].u16HBlock=u16Hblock;
                    gsRwCtrl.usSrchQ[uSrchQHead].u16HPage=u16Hpage;
                    gsRwCtrl.uarSrchQ2RdHaddr[uSrchQHead]=(u16PrdTrig|cBit7);
                    uSrchQHead=(uSrchQHead+1)&(cSrchQDepth-1);
                    gsRwCtrl.uSrchQCnt++;

                    if(gsRwCtrl.uFreeNbsSlotCnt)
                    {
                        uNbsQIdx=gsRwCtrl.uarFreeNbsSlot[gsRwCtrl.uFreeNbsSlotHead];
                        gsRwCtrl.uFreeNbsSlotHead=(gsRwCtrl.uFreeNbsSlotHead+1)&(cSrchEnginDepth-1);
                        gsRwCtrl.uFreeNbsSlotCnt--;
                        rmSetNbsSrchTgt(uNbsQIdx,
                                        (LWORD)((gsRwCtrl.usSrchQ[gsRwCtrl.uSrchQTail].u16HBlock<<16)+
                                                gsRwCtrl.usSrchQ[gsRwCtrl.uSrchQTail].u16HPage));
                        rmSetNbsActBit(uNbsQIdx);
                        gsRwCtrl.uarNbs2SrchQ[uNbsQIdx]=gsRwCtrl.uSrchQTail;
                        gsRwCtrl.uSrchQTail=(gsRwCtrl.uSrchQTail+1)&(cSrchQDepth-1);
                    }

                    u16Hpage++;
                    u16Prd4KCnt--;
                }
                while(u16Prd4KCnt);

                gsRwCtrl.uSrchQHead=uSrchQHead;
            }
            else
            {
                gpHostAddrInfo->uSrcFromH2F=1;

                if(g16arH2fTabPtr[u16Hblock]==c16H2FTabInitValue)
                {
                    // gpHostAddrInfo->uLoadTabState=cReadTabOk;
                    gpHostAddrInfo->uTabSgmtIdx=cSrcAllDummy;    // Dummy read. [CC]
                    gsRwCtrl.uarSrcPrdPtr[gsRwCtrl.uSrcPrdHead]=u16PrdTrig;
                    gsRwCtrl.uSrcPrdHead=(gsRwCtrl.uSrcPrdHead+1)&(cPostSrcDept-1);
                    gsRwCtrl.uSrcPrdCnt++;
                }
                else
                {
                    // gpHostAddrInfo->uLoadTabState=cPostReadTab;
                    // gpHostAddrInfo->uSrcFromH2F=1;
                    gsRwCtrl.uarTabPrdPtr[gsRwCtrl.uTabPrdHead]=u16PrdTrig;
                    gsRwCtrl.uTabPrdHead=(gsRwCtrl.uTabPrdHead+1)&(cPostTabDept-1);
                    gsRwCtrl.uTabPrdCnt++;
                }
            }

            gbNewSrcF=1;
            g32RestSctrCnt=upPrdInfo->u32SctrCnt;
        }

        g32LastLbaR=u32LbaAddr+u32SctrCnt;
        u16PrdTrig=gsPrdInfo.uarPrdLink[u16PrdTrig].uNext;
#if _GREYBOX
        if(gsGbInfo.uGreyBoxItem==cHostRwReadAhead)
        {
            if(mChkReadAhead)
            {
                gsGbInfo.u32BkValue=g16ReadBufPtr;
                copyTsb2Sdram((BYTE *)c32GreyBoxBuf, (UCBYTE *)cTsb0Addr, cTsb0Size<<cSingleSectorShift);
            }
        }
#endif
    }
    while((u16PrdTrig!=cNull)&&(!mChkHandlePcieErrF));

    gsPrdInfo.usReadPrdList.u16Trig=u16PrdTrig;

    return cTrue;
}    /* trigHostPrdTaskR */

#if _EN_WUNCTable    // WUNCTable Chief_21081121
BYTE ChkWuncHit(BYTE uReadSctrCnt)
{
    BYTE uTrig=0;
    BYTE uIdx, uStartSct=gStartSector, uChkBitmap=0, uChkSctrCnt=0;

    NLOG(cLogHost, READ_C, 4,
         "Read Cmd u16HBlock=0x%04X, u16HPage=0x%04X, gStartSector=0x%04X, uReadSctrCnt=0x%04X",
         gpHostAddrInfo->u16HBlock, gpHostAddrInfo->u16HPage, gStartSector, uReadSctrCnt);

    for(uIdx=0; uIdx<C_MaxWUNCLAACnt; uIdx++)
    {
#if WUNC_debug
        NLOG(cLogHost, READ_C, 3,
             "Read Cmd u16HBlock=0x%04X, u16HPage=0x%04X, uBitMap=0x%04X",
             gsWUNCInfo.u16HBlock[uIdx], gsWUNCInfo.u16HPage[uIdx], gsWUNCInfo.uBitMap[uIdx]);
#endif

        if((gsWUNCInfo.u16HBlock[uIdx]==gpHostAddrInfo->u16HBlock)&&(gsWUNCInfo.u16HPage[uIdx]==gpHostAddrInfo->u16HPage))
        {
            for(; uChkSctrCnt<uReadSctrCnt; uChkSctrCnt++)
            {
                uChkBitmap|=cbBitTab[uStartSct];
                uStartSct++;
            }

            if(uChkBitmap&gsWUNCInfo.uBitMap[uIdx])
            {
                NLOG(cLogHost, READ_C, 3,
                     "Read Cmd Return UNC uChkBitmap=0x%04X,uReadSctrCnt=0x%04X,uBitMap=0x%04X",
                     uChkBitmap, uReadSctrCnt, gsWUNCInfo.uBitMap[uIdx]);
                uTrig=cUncBeforeTrig;
            }

            break;
        }
    }

    return uTrig;
}    /* ChkWuncHit */

#endif/* if _EN_WUNCTable */

void postFlashAddrInfoR()
{
    BYTE uSrc4kCnt, uReadSctrCnt, uTabSgmtIdx;    // , uPrdIdx;
    // PRDQUEUE *upPrdInfo;
    WORD u16FBlk, u16NowNodeIdx;
    LWORD u32FAddr, u32FPage, u32FreeHead, u32FreeTail, u32FreeCnt;
    PRDQUEUE *upPrdInfo;

#if _ENABLE_SECAPI
    BYTE uSecFlag;
#endif

    do
    {
        // uPrdIdx=gsRwCtrl.uarSrcPrdPtr[gsRwCtrl.uSrcPrdTail];
        upPrdInfo=&gsPrdInfo.uarPrdQue[gsRwCtrl.uarSrcPrdPtr[gsRwCtrl.uSrcPrdTail]];
        gpHostAddrInfo=&gsReadHAddrInfo[gsRwCtrl.uarSrcPrdPtr[gsRwCtrl.uSrcPrdTail]];
        uSrc4kCnt=upPrdInfo->u16PrdRd4kCnt;

        u32FreeHead=gsRwCtrl.u32FreeSrcFifoHead;
        u32FreeTail=gsRwCtrl.u32FreeSrcFifoTail;

        if(u32FreeHead==u32FreeTail)
        {
            if(gsRwCtrl.usSrcCmdList.u16Cnt!=0)
            {
                u32FreeCnt=0;
            }
            else
            {
                u32FreeCnt=cReadFifoDpt;
            }
        }
        else if(u32FreeHead>u32FreeTail)
        {
            u32FreeCnt=cReadFifoDpt-(u32FreeHead-u32FreeTail);
        }
        else
        {
            u32FreeCnt=u32FreeTail-u32FreeHead;    // cReadFifoDpt-(u32FreeHead+cReadFifoDpt-u32FreeTail);
        }

        if(u32FreeCnt<uSrc4kCnt)
        {
            break;
        }

        g16ReadBufPtr=getReadBufPtr(g16ReadBufPtr)+upPrdInfo->uStartSctr;
        gpHostAddrInfo->u16FlashRBufPtr=upPrdInfo->u16BufPtr=g16ReadBufPtr;
        g16ReadBufPtr=addReadBufPtr(g16ReadBufPtr, upPrdInfo->u32SctrCnt);
        uTabSgmtIdx=gpHostAddrInfo->uTabSgmtIdx;
#if _ENABLE_SECAPI
        uSecFlag=upPrdInfo->uSecFlag;
#endif
        gsE2eInfo.u32CurrentSctCnt=upPrdInfo->u32LbaAddr;

        do
        {
            if(uTabSgmtIdx==cSrcAllDummy)
            {
                u32FAddr=cUncTypeMask;
                u16FBlk=0;
                u32FPage=g16HPage;
            }
            else
            {
                if(gpHostAddrInfo->uSrcFromH2F)
                {
                    u32FAddr=garH2f1kTable[uTabSgmtIdx][g16HPage&(c16RH2fTabSize-1)];
                }
                else if((uTabSgmtIdx==0xFF)||
                        (mGetSrcFBlkAddr(garSrchSrcTab[gpHostAddrInfo->u16SrchSrcTabStIdx])!=c16FBlockInitValue))
                {
                    u32FAddr=garSrchSrcTab[gpHostAddrInfo->u16SrchSrcTabStIdx];
                }
                else
                {
                    u32FAddr=garH2f1kTable[uTabSgmtIdx][g16HPage&(c16RH2fTabSize-1)];
                }

                // if(!gpHostAddrInfo->uSrcFromH2F)
                // {
                //    garSrchSrcTab[gpHostAddrInfo->u16SrchSrcTabStIdx]=c32BitFF;
                // }

                // if(u32FAddr==c32BitFF)
                // {
                //    while(1);
                // }
                u16FBlk=mGetSrcFBlkAddr(u32FAddr);
                u32FPage=mGetSrcFPageAddr(u32FAddr);

                if(u16FBlk>=g16TotalFBlock)    // ==c16FBlockInitValue)
                {
                    u16FBlk=0;
                    u32FPage=g16HPage;
                }
            }

#if _ENABLE_WUNC
            if(u32FAddr&c32FBlockUncBit)
            {
                upPrdInfo->uUncFlag=cUncBeforeTrig;
            }
#endif

            if(!gpHostAddrInfo->uSrcFromH2F)
            {
                garSrchSrcTab[gpHostAddrInfo->u16SrchSrcTabStIdx]=c32BitFF;
            }

            if(!gbNewSrcF)
            {
                if((g16FBlock!=u16FBlk)||((g32FPageNoTran+gpFlashAddrInfo->uPlaneCnt)!=u32FPage)||
                   !((BYTE)u32FPage&(g4kNumPerPage-1)))
                {
                    gpHostAddrInfo->u16FlashRBufPtr=addReadBufPtr(gpHostAddrInfo->u16FlashRBufPtr, gpFlashAddrInfo->uRwHalfKb);

                    if((gpFlashAddrInfo->uRwHalfKb+gSectorH)>gSectorPerPlaneH)
                    {
                        g16RwOpt|=c16Bit0;
                    }

                    gsRwCtrl.u32FreeSrcFifoHead=(gsRwCtrl.u32FreeSrcFifoHead+1)&(cReadFifoDpt-1);
                    gbNewSrcF=1;
                }
            }

            if(uSrc4kCnt!=1)
            {
                uReadSctrCnt=getReadSctrCnt(g32RestSctrCnt);
            }
            else
            {
                uReadSctrCnt=g32RestSctrCnt;
            }

#if _EN_WUNCTable    // WUNCTable Chief_21081121
            if(gsWUNCInfo.uWuncCnt&(~cBit4)&&(!upPrdInfo->uUncFlag))
            {
                NLOG(cLogHost, READ_C, 4,
                     "postFAddrInfoSeqR Read Cmd u16HBlock=0x%04X,u16HPage=0x%04X,gStartSector=0x%04X, g32RestSctrCnt=0x%04X",
                     gpHostAddrInfo->u16HBlock, gpHostAddrInfo->u16HPage, gStartSector, uReadSctrCnt);

                upPrdInfo->uUncFlag=ChkWuncHit(uReadSctrCnt);
            }
#endif/* if _EN_WUNCTable */

            if(gbNewSrcF)
            {
                while((mGetSrcOccpyCnt()>=cReadSafetyFifoDpt)    /*&&(!mChkHandlePcieErrF)*/)
                {
                    chkReleaseFreeHwPrd();

                    while((gsRwCtrl.u32TrigHostTail!=gsRwCtrl.u32TrigHostHead)&&gsPrdInfo.uFreeHwPrdCnt)
                    {
                        trigHostRw(gsRwCtrl.uarTrigHostPrd[gsRwCtrl.u32TrigHostTail], c32AutoDmaTrigR,
                                   cLastPrd|cTsb|cAutoBufflag|cCrcCheckEn);

                        gsRwCtrl.u32TrigHostTail=(gsRwCtrl.u32TrigHostTail+1)&(cPrdDepth-1);
                    }    /* postFlashAddrInfoR */
                }

                u16NowNodeIdx=gsRwCtrl.uarFreeSrcQue[gsRwCtrl.u32FreeSrcFifoHead];
                gpFlashAddrInfo=&garSrcAddrInfo[u16NowNodeIdx];

                g32FPageNoTran=u32FPage;
                gpFlashAddrInfo->uPrdPtr=gsRwCtrl.uarSrcPrdPtr[gsRwCtrl.uSrcPrdTail];
                gpFlashAddrInfo->uTsb4kIdx=(gpHostAddrInfo->u16FlashRBufPtr>>cSctrTo4kShift);
                gpFlashAddrInfo->uSrcIdx=u16NowNodeIdx;
                mSetQRead(gpFlashAddrInfo);

#if _ENABLE_SECAPI
                if(uSecFlag&cMbrDummyReturn)
                {
                    g16FBlock=g16AbstrFBlock=0;
                    mSetFRwParam(gpHostAddrInfo->u16FlashRBufPtr, uReadSctrCnt, 0, cMbrReadDummy);
                    gpFlashAddrInfo->uDieAddr=(BYTE)gsE2eInfo.u32CurrentSctCnt;
                    gpFlashAddrInfo->uCe=(BYTE)(gsE2eInfo.u32CurrentSctCnt>>8);
                    gpFlashAddrInfo->uIntlvAddr=(BYTE)(gsE2eInfo.u32CurrentSctCnt>>16);
                    gpFlashAddrInfo->uCh=(BYTE)(gsE2eInfo.u32CurrentSctCnt>>24);
                }
                else
#endif

                if(!u16FBlk)
                {
                    g16FBlock=g16AbstrFBlock=0;

                    if(g32FPageNoTran>=g16H2fTabSize)
                    {
                        // mSetFRwParam(gpHostAddrInfo->u16FlashRBufPtr, uReadSctrCnt, 0, cHmbWrCacheData);
                        gsFtlDbg.u16DummyFailType=cPostFlashAddrInfoR;
#if (C_Log_SaveMask&C_Debug_P2)    // 20181031_Oscar
                        NLOG(cLogHost,
                             READ_C,
                             3,
                             " g32FPageNoTran=0x%08X, g16H2fTabSize=0x%04X ",
                             g32FPageNoTran>>16,
                             g32FPageNoTran,
                             g16H2fTabSize);
#endif
                        debugWhile();
                    }
                    else
                    {
                        mSetFRwParam(gpHostAddrInfo->u16FlashRBufPtr, uReadSctrCnt, 0, cHdmaDummy);
                        gpFlashAddrInfo->uDieAddr=(BYTE)gsE2eInfo.u32CurrentSctCnt;
                        gpFlashAddrInfo->uCe=(BYTE)(gsE2eInfo.u32CurrentSctCnt>>8);
                        gpFlashAddrInfo->uIntlvAddr=(BYTE)(gsE2eInfo.u32CurrentSctCnt>>16);
                        gpFlashAddrInfo->uCh=(BYTE)(gsE2eInfo.u32CurrentSctCnt>>24);
                    }
                }
                else
                {
                    g16FBlock=u16FBlk;
                    gSectorH=mTranSctr4kAddr(u32FPage)+gStartSector;
                    tranAddrInfo(gpFlashAddrInfo);
                    mSetFRwParam(gpHostAddrInfo->u16FlashRBufPtr, uReadSctrCnt, c16Bit1|c16Bit4|c16Bit6|c16Bit15, cHostReadData);
                }

                gpFlashAddrInfo->uPlaneCnt=1;
                gpHostAddrInfo->ubNewSrcF=0;
            }
            else    // if (!gbNewSrcF)
            {
                gpFlashAddrInfo->uRwHalfKb+=uReadSctrCnt;
                gpFlashAddrInfo->uPlaneCnt++;
            }

            if(uSrc4kCnt!=1)
            {
                gsE2eInfo.u32CurrentSctCnt+=uReadSctrCnt;
                gStartSector=(gStartSector+uReadSctrCnt)&(cSctrPer4k-1);    // mod(gStartSector+uReadSctrCnt, cSctrPer4k);
                g32RestSctrCnt-=uReadSctrCnt;
                gpHostAddrInfo->u16SrchSrcTabStIdx=(gpHostAddrInfo->u16SrchSrcTabStIdx+1)&(cSrchSrcNum-1);
                uSrc4kCnt--;
                g16HPage++;
            }
            else
            {
                break;
            }
        }
        while(uSrc4kCnt)
        ;

// gpHostAddrInfo->u16FlashRBufPtr=addReadBufPtr(gpHostAddrInfo->u16FlashRBufPtr, gpFlashAddrInfo->uRwHalfKb);

        if((gpFlashAddrInfo->uRwHalfKb+gSectorH)>gSectorPerPlaneH)
        {
            g16RwOpt|=c16Bit0;
        }

        gsRwCtrl.u32FreeSrcFifoHead=(gsRwCtrl.u32FreeSrcFifoHead+1)&(cReadFifoDpt-1);

        if(!(uTabSgmtIdx&(cBit6|cBit7)))
        {
            mSetH2f1kTabSgmtExpire(uTabSgmtIdx);

            if(mChkH2f1kTabSgmtExpire(uTabSgmtIdx))
            {
                gsRwCtrl.uFreeHSgmtCnt++;
            }
        }

        gsRwCtrl.uSrcPrdTail=(gsRwCtrl.uSrcPrdTail+1)&(cPostSrcDept-1);
        gsRwCtrl.uSrcPrdCnt--;
    }
    while(gsRwCtrl.uSrcPrdCnt)
    ;
}    /* postFlashAddrInfoR */

void postReadH2fSgmtTab(void)
{
    BYTE uPrdIdx, uSgmtIdx, uTrigRdTab;
    WORD u16Hblock, u16Hsgmt;
    LWORD u32H2f1kTabSgmt;

    do
    {
        if(!gsRwCtrl.uFreeHSgmtCnt||(mGetSrcOccpyCnt()>=cReadSafetyFifoDpt))
        {
            break;
        }

        uPrdIdx=gsRwCtrl.uarTabPrdPtr[gsRwCtrl.uTabPrdTail];
        gpHostAddrInfo=&gsReadHAddrInfo[uPrdIdx];
        u16Hblock=g16HBlock;
        u16Hsgmt=g16HSgmt;
        uTrigRdTab=0;

        if(g16arH2fTabPtr[u16Hblock]!=c16H2FTabInitValue)
        {
            u32H2f1kTabSgmt=(LWORD)(u16Hblock<<16)|u16Hsgmt;
            rmEnQuickSrch;
            rmSetSrchThVal(u32H2f1kTabSgmt);
            rmDisQuickSrch;

            if(rmChkSrchTgt32Vld)
            {
                uSgmtIdx=srchH2f1kTabSgmt2(u32H2f1kTabSgmt, cMaxRH2fTabNum);

                if(mChkH2f1kTabSgmtExpire(uSgmtIdx))
                {
                    if(gsPrdInfo.uarPrdQue[uPrdIdx].uE2eRetry)
                    {
                        do
                        {
                            g32arH2f1kTabSgmt[uSgmtIdx]=c32BitFF;
                            rmSetSrchTgt(uSgmtIdx, c32BitFF);
                            gsCacheInfo.uH2f1kSgmtFreePtr=(uSgmtIdx+1)&(cMaxRH2fTabNum-1);
                            gsCacheInfo.uH2f1kTabCnt--;
                            uSgmtIdx=srchH2f1kTabSgmt2(u32H2f1kTabSgmt, cMaxRH2fTabNum);
                        }
                        while(uSgmtIdx!=0xFF);

                        break;
                    }

                    gsRwCtrl.uFreeHSgmtCnt--;
                }
                else if(gsPrdInfo.uarPrdQue[uPrdIdx].uE2eRetry)
                {
                    break;
                }
            }
            else
            {
                if(mChkHmbLink(u16Hblock))
                {
#if _EN_PATCH_SM2263AA
#if _ENABLE_RAID
                    uSgmtIdx=setH2f1kTabSgmt(u32H2f1kTabSgmt, cMaxRH2fTabNum);
#else
                    uSgmtIdx=setH2f1kTabSgmt(u32H2f1kTabSgmt);
#endif
                    rmSetSrchTgt(uSgmtIdx, u32H2f1kTabSgmt);
                    mSetH2f1kTabSgmtPrep(uSgmtIdx);
                    gsRwCtrl.uFreeHSgmtCnt--;

                    readHmbH2fTab(c16RH2fTabSIdx+(uSgmtIdx<<2), u16Hblock, u16Hsgmt, uSgmtIdx, 0);
                    uTrigRdTab=cBit0;
#else
#if _EN_HMBDWORDMO
                    // if(gsHmbInfo.uHmbFreeHwPrdCnt<2)
                    // {
                    if(mChkHmbPrdTrigIdx)
                    {
                        releaseHmbHwPrd();
                    }
                    else if(gsHmbInfo.uHmbFreeHwPrdCnt<2)
                    {
                        break;
                    }

                    // }

                    WORD u16Hpage=g16HPage;

                    if((gsCacheInfo.uH2f1kTabCnt<cMaxRH2fTabNum)||(gsPrdInfo.uarPrdQue[uPrdIdx].u16PrdRd4kCnt!=1)||
                       ((u16Hpage&0x3FF)>0x3FC))
                    {
#if _ENABLE_RAID
                        uSgmtIdx=setH2f1kTabSgmt(u32H2f1kTabSgmt, cMaxRH2fTabNum);
#else
                        uSgmtIdx=setH2f1kTabSgmt(u32H2f1kTabSgmt);
#endif
                        rmSetSrchTgt(uSgmtIdx, u32H2f1kTabSgmt);
                        mSetH2f1kTabSgmtPrep(uSgmtIdx);
                        gsRwCtrl.uFreeHSgmtCnt--;

                        readHmbH2fTab(c16RH2fTabSIdx+(uSgmtIdx<<2), u16Hblock, u16Hsgmt, uSgmtIdx, 1);
                        uTrigRdTab=cBit0;
                    }
                    else
                    {
                        readHmbH2f4B(u16Hblock, u16Hpage, uPrdIdx);
                        uTrigRdTab=cBit1;
                        gpHostAddrInfo->uTabSgmtIdx=0xFF;
                    }
#else/* if _EN_HMBDWORDMO */
#if _ENABLE_RAID
                    uSgmtIdx=setH2f1kTabSgmt(u32H2f1kTabSgmt, cMaxRH2fTabNum);
#else
                    uSgmtIdx=setH2f1kTabSgmt(u32H2f1kTabSgmt);
#endif
                    rmSetSrchTgt(uSgmtIdx, u32H2f1kTabSgmt);
                    mSetH2f1kTabSgmtPrep(uSgmtIdx);
                    gsRwCtrl.uFreeHSgmtCnt--;

                    readHmbH2fTab(c16RH2fTabSIdx+(uSgmtIdx<<2), u16Hblock, u16Hsgmt, uSgmtIdx, 1);
                    uTrigRdTab=cBit0;
#endif/* if _EN_HMBDWORDMO */
#endif/* if _EN_PATCH_SM2263AA */
                    // gsPrdInfo.uarPrdQue[uPrdIdx].uE2eRetry=cBit7;
                }
                else
                {
#if _ENABLE_RAID
                    uSgmtIdx=setH2f1kTabSgmt(u32H2f1kTabSgmt, cMaxRH2fTabNum);
#else
                    uSgmtIdx=setH2f1kTabSgmt(u32H2f1kTabSgmt);
#endif
                    rmSetSrchTgt(uSgmtIdx, u32H2f1kTabSgmt);
                    mSetH2f1kTabSgmtPrep(uSgmtIdx);
                    gsRwCtrl.uFreeHSgmtCnt--;

                    readH2fSgmtTable(u16Hblock, u16Hsgmt, uSgmtIdx, 1);
                    uTrigRdTab=cBit0;
                }
            }

            if(!(uTrigRdTab&cBit1))
            {
                mClrH2f1kTabSgmtExpire(uSgmtIdx);
                gpHostAddrInfo->uTabSgmtIdx=uSgmtIdx;

                if(!mChkH2f1kTabSgmtPrep(uSgmtIdx))
                {
                    // Hit MapCache [CC]
                    // gpHostAddrInfo->uLoadTabState=cReadTabOk;
                    gsRwCtrl.uarSrcPrdPtr[gsRwCtrl.uSrcPrdHead]=uPrdIdx;
                    gsRwCtrl.uSrcPrdHead=(gsRwCtrl.uSrcPrdHead+1)&(cPostSrcDept-1);
                    gsRwCtrl.uSrcPrdCnt++;
                }
                else
                {
                    // Miss MapCache [CC]
                    if(!uTrigRdTab)
                    {
                        createPrdTabLink(uSgmtIdx, uPrdIdx);
                    }
                    else
                    {
                        gsRwCtrl.uarTab2PrdPtr[uSgmtIdx]=uPrdIdx;    // create tab link root. [CC]
                    }

                    // gpHostAddrInfo->uLoadTabState=cSrchSrcTabOk;
                }
            }
        }
        else
        {
            if(gpHostAddrInfo->uSrchHitCnt)
            {
                gpHostAddrInfo->uTabSgmtIdx=0xFF;
            }
            else
            {
                gpHostAddrInfo->uTabSgmtIdx=cSrcAllDummy;    // Dummy read. [CC]
            }

            // gpHostAddrInfo->uLoadTabState=cReadTabOk;
            gsRwCtrl.uarSrcPrdPtr[gsRwCtrl.uSrcPrdHead]=uPrdIdx;
            gsRwCtrl.uSrcPrdHead=(gsRwCtrl.uSrcPrdHead+1)&(cPostSrcDept-1);
            gsRwCtrl.uSrcPrdCnt++;
        }

        gsRwCtrl.uTabPrdTail=(gsRwCtrl.uTabPrdTail+1)&(cPostTabDept-1);
        gsRwCtrl.uTabPrdCnt--;
    }
    while(gsRwCtrl.uTabPrdCnt);
}    /* postReadH2fSgmtTab */

void termFlashOperR()
{
    // WORD u16PrdTrig;

    if(mChkReadAhead)
    {
        termContiR();
    }

    while(gsPrdInfo.usReadPrdList.u16Cnt&&!mChkHandlePcieErrF)
    {
        if(gsPrdInfo.usReadPrdList.u16Trig!=cNull)
        {
            trigHostPrdTaskR();
        }

        if(gsRwCtrl.uSrchQCnt&&!rmChkNbsQueMt)    // !rmChkBopBz)
        {
            postSrchF2hTab();
        }

        if(gsRwCtrl.uTabPrdCnt)    // &&gsRwCtrl.uFreeHSgmtCnt)
        {
            postReadH2fSgmtTab();
        }

#if _EN_RAID_DECODE
        if((gsRwCtrl.u32H2fSgmtRdyTail!=gsRwCtrl.u32H2fSgmtRdyHead)&&(!g32DecodeWait)&&(!gsRwCtrl.u32SeqRdFlag))
#else
        if(gsRwCtrl.u32H2fSgmtRdyTail!=gsRwCtrl.u32H2fSgmtRdyHead)
#endif
        {
            handleH2fSgmtRdy();
        }

        // if(gsHmbInfo.uHmbSgmtRdyCnt)
        // {
        //    handleHmbSgmtRdy();
        // }

        if(gsRwCtrl.uSrcPrdCnt)
        {
            postFlashAddrInfoR();
        }

        chkReleaseFreeHwPrd();

        if(gsPrdInfo.uSeqRCmdCnt)
        {
            trigHostSeqRead(1);
        }

        while((gsRwCtrl.u32TrigHostTail!=gsRwCtrl.u32TrigHostHead)&&gsPrdInfo.uFreeHwPrdCnt)
        {
            trigHostRw(gsRwCtrl.uarTrigHostPrd[gsRwCtrl.u32TrigHostTail], c32AutoDmaTrigR, cLastPrd|cTsb|cAutoBufflag|cCrcCheckEn);

            gsRwCtrl.u32TrigHostTail=(gsRwCtrl.u32TrigHostTail+1)&(cPrdDepth-1);
        }

        // while((gsRwCtrl.u32TrigHmbTail!=gsRwCtrl.u32TrigHmbHead)&&gsHmbInfo.uHmbFreeHwPrdCnt)
        // {
        //    postHmbReadData();
        // }

        chkHmbPrdDone();
    }

    if(mChkReadAhead)
    {
        termContiR();
    }

    gsRwCtrl.u32SeqRdFlag=0;

    while(gsRwCtrl.u32SeqRdCpu1Flag)
        ;

    // gReadFlag=0;
    g32LastLbaR=0xFFFFFFFF;
#if (C_Log_SaveMask&C_Debug_P2)    // 20181031_Oscar
    if(gsPrdInfo.uSeqRTrigCnt&&!mChkHandlePcieErrF)
    {
        NLOG(cLogHost, READ_C, 2, " gsPrdInfo.uSeqRTrigCnt=0x%04X ,mChkHandlePcieErrF=0x%04X", gsPrdInfo.uSeqRTrigCnt,
             mChkHandlePcieErrF);
    }
#endif

    while(gsPrdInfo.uSeqRTrigCnt&&!mChkHandlePcieErrF)
        ;

    bopClrRam((LWORD)&garSrchSrcTab, sizeof(garSrchSrcTab), 0xFFFFFFFF, cClrCore0Dccm|cBopWait);
    clrLastReadGrp();
}    /* termFlashOperR */

/*
   * void getReadH2fTabRdy(H2FTABLE *upReadSrcTab, WORD u16Hpage, BYTE uSgmtIdx)
   * {
   *  LWORD u32SrcFAddr;
   *
   *  mClrH2f1kTabSgmtPrep(uSgmtIdx);
   *  u32SrcFAddr=garH2f1kTable[uSgmtIdx][u16Hpage&(c16RH2fTabSize-1)];
   *  upReadSrcTab->u16FBlock=mGetSrcFBlkAddr(u32SrcFAddr);
   *  upReadSrcTab->u32FPage=mGetSrcFPageAddr(u32SrcFAddr);
   * }
   */

void addSeqReadHead(PRDQUEUE *upPrdInfo)
{
    gpHostAddrInfo->u16FlashRBufPtr=addReadBufPtr(gpHostAddrInfo->u16FlashRBufPtr, gpFlashAddrInfo->uRwHalfKb);

    // if((gpFlashAddrInfo->uRwHalfKb+gSectorH)>gSectorPerPlaneH)
    // {
    g16RwOpt|=c16Bit0;
    // }

    gsRwCtrl.u32ReadFifoLbaN+=gpFlashAddrInfo->uRwHalfKb;
    gsRwCtrl.u32FreeSrcFifoHead=(gsRwCtrl.u32FreeSrcFifoHead+1)&(cReadFifoDpt-1);
    gbNewSrcF=1;

    while(mGetSrcOccpyCnt()>=cReadSafetyFifoDpt&&(chkExitSeqR(upPrdInfo->uHwPrdIdx, cTrue)==cFalse))
        ;
}

void postFAddrInfoSeqR(PRDQUEUE *upPrdInfo, WORD u16PrdIdx, WORD u16NextPrd)
{
    BYTE uReadSctrCnt, uSgmtIdx, uLoadSgmtCnt, uSectorPerPageF;
    H2FTABLE usReadSrcTab;
    WORD u16Hsgmt, u16Hblock, u16Hpage, u16NowNodeIdx;
    LWORD u32FAddr=cUncTypeMask, u32ReadFifoLbaN, u32H2f1kTabSgmt;

    // LWORD u32FAddrUnc=cUncTypeMask;

#if _ENABLE_WUNC
    BYTE uWUNCTermFlag=0;
#endif

    if(!mChkContHAddrR)
    {
        tranLba2HAddr(upPrdInfo->u32LbaAddr, &gsReadHAddrInfo[u16PrdIdx]);
        gsRwCtrl.uSeqRdHaddrIdx=u16PrdIdx;
        gpHostAddrInfo->u16FlashRBufPtr=upPrdInfo->u16BufPtr;
        g16HSgmt=0xFFFF;
        gpHostAddrInfo->uTabSgmtIdx=0xFF;
        gbNewSrcF=1;
        g32RestSctrCnt=upPrdInfo->u32SctrCnt;
        gsRwCtrl.usSeqSrchTriged.u16HBlock=0xFFFF;    // TODO:continune seq read case

        if(mChkReadAhead)
        {
            mSetContHAddrR;    // gbContHAddrR=1;
        }

        gsRwCtrl.u32ReadFifoLbaN=upPrdInfo->u32LbaAddr;
        // gsRwCtrl.u32ReadTrigLbaN=upPrdInfo->u32LbaAddr-upPrdInfo->uStartSctr;
        gsE2eInfo.u32CurrentSctCnt=upPrdInfo->u32LbaAddr;

        if(upPrdInfo->uE2eRetry)
        {
            rstH2F1KInfo();
        }
    }

    if(mChkReadAhead)
    {
        u32ReadFifoLbaN=gsRwCtrl.u32ReadFifoLbaN;

        if(!gbNewSrcF)    // gbNewSrcF)
        {
            u32ReadFifoLbaN+=garSrcAddrInfo[gsRwCtrl.uarFreeSrcQue[gsRwCtrl.u32FreeSrcFifoHead]].uRwHalfKb;
        }

        // if(!mChkUnlimitedR&&(gsRwCtrl.u32ReadHostLbaN<g32TotalDatSector))
        if(gsRwCtrl.u32ReadHostLbaN<g32TotalDatSector)
        {
            if(gsRwCtrl.u32ReadHostLbaN>u32ReadFifoLbaN)
            {
                g32RestSctrCnt=gsRwCtrl.u32ReadHostLbaN-u32ReadFifoLbaN;
            }
            else
            {
                g32RestSctrCnt=0;
            }
        }
        else
        {
            g32RestSctrCnt=g32TotalDatSector-u32ReadFifoLbaN;
        }
    }
    else
    {
        g32RestSctrCnt=upPrdInfo->u32SctrCnt;
        gsRwCtrl.usSeqSrchTriged.u16HBlock=0xFFFF;    // TODO:continune seq read case
    }

    while((g32RestSctrCnt!=0)&&(chkExitSeqR(upPrdInfo->uHwPrdIdx, cFalse)==cFalse))
    {
        u16Hblock=g16HBlock;
        u16Hpage=g16HPage;

        if(mChkSrcInCache(u16Hblock)&&srchSrcInF2hTab2(u16Hblock, u16Hpage, &usReadSrcTab, gsRwCtrl.uSeqRdHaddrIdx))
        {}
        else
        {
            if(g16arH2fTabPtr[u16Hblock]!=c16H2FTabInitValue)
            {
                u16Hsgmt=u16Hpage>>9;

                if(u16Hsgmt==g16HSgmt)
                {
                    uSgmtIdx=gpHostAddrInfo->uTabSgmtIdx;
                }
                else
                {
                    // g16HSgmt=u16Hsgmt;
                    u32H2f1kTabSgmt=(LWORD)(u16Hblock<<16)|u16Hsgmt;
                    uSgmtIdx=srchH2f1kTabSgmt(u32H2f1kTabSgmt);
                }

                if(uSgmtIdx==0xFF)
                {
#if _EN_SEQRSGMTTAB
                    if(mChkReadAhead)
#else
                    if(0)
#endif
                    {
                        uSgmtIdx=gsCacheInfo.uH2f1kSgmtFreePtr;

                        uSectorPerPageF=(gSectorPerPageF>>1);

                        while(uSectorPerPageF<=u16Hsgmt)
                        {
                            uSectorPerPageF+=(gSectorPerPageF>>1);
                        }

                        if(uSectorPerPageF>gsCacheInfo.uMaxH2f2kTabSgmt)
                        {
                            uSectorPerPageF=gsCacheInfo.uMaxH2f2kTabSgmt;
                        }

                        uLoadSgmtCnt=uSectorPerPageF-u16Hsgmt;

                        if((uSgmtIdx+uLoadSgmtCnt)>cMaxRH2fTabNum)
                        {
                            uSgmtIdx=0;
                        }

                        BYTE uLoadSgmtCnt2=uLoadSgmtCnt;
                        BYTE uSgmtIdx2=uSgmtIdx;

                        while(uLoadSgmtCnt2)
                        {
                            g32arH2f1kTabSgmt[uSgmtIdx2]=u32H2f1kTabSgmt;
                            rmSetSrchTgt(uSgmtIdx2, u32H2f1kTabSgmt);

                            if(gsCacheInfo.uH2f1kTabCnt<cMaxRH2fTabNum)
                            {
                                gsCacheInfo.uH2f1kTabCnt++;
                            }

                            u32H2f1kTabSgmt++;
                            uLoadSgmtCnt2--;
                            uSgmtIdx2++;
                        }

                        gsCacheInfo.uH2f1kSgmtFreePtr=uSgmtIdx2&(cMaxRH2fTabNum-1);
                    }
                    else
                    {
#if _ENABLE_RAID
                        uSgmtIdx=setH2f1kTabSgmt(u32H2f1kTabSgmt, cMaxRH2fTabNum);
#else
                        uSgmtIdx=setH2f1kTabSgmt(u32H2f1kTabSgmt);
#endif
                        uLoadSgmtCnt=1;
                        rmSetSrchTgt(uSgmtIdx, u32H2f1kTabSgmt);
                    }

                    gsCacheInfo.u32H2f1kTabSgmtPrep=c32BitFF;    // mSetH2f1kTabSgmtPrep(uSgmtIdx);

                    if(mChkHmbLink(u16Hblock))
                    {
#if _EN_PATCH_SM2263AA
                        WORD u16BufPtr=c16RH2fTabSIdx+(uSgmtIdx<<2);
                        BYTE uBufMsk=(u16BufPtr&c16Bit2)?0xF0:0x0F;
                        readHmbH2fTab(u16BufPtr, u16Hblock, u16Hsgmt, uSgmtIdx, uLoadSgmtCnt);
#else
                        readHmbH2fTab(c16RH2fTabSIdx+(uSgmtIdx<<2), u16Hblock, u16Hsgmt, uSgmtIdx, uLoadSgmtCnt);
#endif

                        while(mChkH2f1kTabSgmtPrep(uSgmtIdx))    // !gsHmbInfo.uHmbSgmtRdyCnt)
                        {
                            chkHmbPrdDone();

#if _EN_PATCH_SM2263AA
                            if((rmBufStatus(u16BufPtr>>3)&uBufMsk)==uBufMsk)
                            {
                                rmSetBuf8Sts(u16BufPtr>>3, uBufMsk);
                                uLoadSgmtCnt--;
                                uBufMsk=~uBufMsk;
                                u16BufPtr+=4;
                            }
#endif
                        }

                        gsCacheInfo.u32H2f1kTabSgmtPrep=0;
                        // upPrdInfo->uE2eRetry=cBit7;

#if _EN_PATCH_SM2263AA
                        while(uLoadSgmtCnt)
                        {
                            if((rmBufStatus(u16BufPtr>>3)&uBufMsk)==uBufMsk)
                            {
                                rmSetBuf8Sts(u16BufPtr>>3, uBufMsk);
                                uLoadSgmtCnt--;
                                uBufMsk=~uBufMsk;
                                u16BufPtr+=4;
                            }
                        }
#endif
                    }
                    else
                    {
                        if(!gbNewSrcF)
                        {
                            u16NowNodeIdx=gsRwCtrl.uarFreeSrcQue[gsRwCtrl.u32FreeSrcFifoHead];
                            gpFlashAddrInfo=&garSrcAddrInfo[u16NowNodeIdx];
                            gpHostAddrInfo->u16FlashRBufPtr=
                                addReadBufPtr(gpHostAddrInfo->u16FlashRBufPtr, gpFlashAddrInfo->uRwHalfKb);
                            g16RwOpt|=c16Bit0;
                            gsRwCtrl.u32ReadFifoLbaN+=gpFlashAddrInfo->uRwHalfKb;
                            gsRwCtrl.u32FreeSrcFifoHead=(gsRwCtrl.u32FreeSrcFifoHead+1)&(cReadFifoDpt-1);
                            gbNewSrcF=1;
                        }

                        readH2fSgmtTable(u16Hblock, u16Hsgmt, uSgmtIdx, uLoadSgmtCnt);

                        while((gsRwCtrl.u32H2fSgmtRdyTail==gsRwCtrl.u32H2fSgmtRdyHead)&&
                              (chkExitSeqR(upPrdInfo->uHwPrdIdx, cTrue)==cFalse))
                            ;

                        if(gsRwCtrl.u32H2fSgmtRdyTail==gsRwCtrl.u32H2fSgmtRdyHead)
                        {
                            break;    // Exist sequence read.
                        }

#if _EN_RAID_DECODE
                        else
                        {
                            while(g32DecodeWait)
                                ;
                        }
#endif

                        gsRwCtrl.u32H2fSgmtRdyTail=(gsRwCtrl.u32H2fSgmtRdyTail+1)&(cH2fSgmtRdyDept-1);
                        gsCacheInfo.u32H2f1kTabSgmtPrep=0;    // mClrH2f1kTabSgmtPrep(uSgmtIdx);
                    }
                }
                else
                {
                    if(gsCacheInfo.u32H2f1kTabSgmtPrep)    // mChkH2f1kTabSgmtPrep(uSgmtIdx))
                    {
                        while((gsRwCtrl.u32H2fSgmtRdyTail==gsRwCtrl.u32H2fSgmtRdyHead)&&
                              (chkExitSeqR(upPrdInfo->uHwPrdIdx, cTrue)==cFalse))
                            ;

                        if(gsRwCtrl.u32H2fSgmtRdyTail==gsRwCtrl.u32H2fSgmtRdyHead)
                        {
                            break;
                        }

#if _EN_RAID_DECODE
                        else
                        {
                            while(g32DecodeWait)
                                ;
                        }
#endif

                        gsRwCtrl.u32H2fSgmtRdyTail=(gsRwCtrl.u32H2fSgmtRdyTail+1)&(cH2fSgmtRdyDept-1);
                        gsCacheInfo.u32H2f1kTabSgmtPrep=0;    // mClrH2f1kTabSgmtPrep(uSgmtIdx);
                    }
                }

                u32FAddr=garH2f1kTable[uSgmtIdx][u16Hpage&(c16RH2fTabSize-1)];
                usReadSrcTab.u16FBlock=mGetSrcFBlkAddr(u32FAddr);
                usReadSrcTab.u32FPage=mGetSrcFPageAddr(u32FAddr);
                gpHostAddrInfo->uTabSgmtIdx=uSgmtIdx;
                g16HSgmt=u16Hsgmt;

                if(usReadSrcTab.u16FBlock>=g16TotalFBlock)    // ==c16FBlockInitValue)
                {
                    usReadSrcTab.u16FBlock=0;
                    usReadSrcTab.u32FPage=u16Hpage;
                }
            }
            else
            {
                usReadSrcTab.u16FBlock=0;
                usReadSrcTab.u32FPage=u16Hpage;
            }
        }

#if _EN_WUNCTable    // WUNCTable Chief_21081121
        if(gsWUNCInfo.uWuncCnt&(~cBit4)&&(!upPrdInfo->uUncFlag))
        {
            NLOG(cLogHost, READ_C, 4,
                 "postFAddrInfoSeqR Read Cmd u16HBlock=0x%04X,u16HPage=0x%04X,gStartSector=0x%04X, g32RestSctrCnt=0x%04X",
                 gpHostAddrInfo->u16HBlock, gpHostAddrInfo->u16HPage, gStartSector, g32RestSctrCnt);

            if(ChkWuncHit(getReadSctrCnt(g32RestSctrCnt)))
            {
                upPrdInfo->uUncFlag=cUncAfterTrig;
            }
        }
#endif/* if _EN_WUNCTable */
#if _ENABLE_WUNC
        if(u32FAddr&c32FBlockUncBit
#if _EN_WUNCTable
           ||(upPrdInfo->uUncFlag==cUncAfterTrig)
#endif
           )
        {
            if(mChkReadAhead)
            {
                uWUNCTermFlag=1;
                u32ReadFifoLbaN=gsRwCtrl.u32ReadFifoLbaN;

                if(!gbNewSrcF)    // gbNewSrcF)
                {
                    u32ReadFifoLbaN+=garSrcAddrInfo[gsRwCtrl.uarFreeSrcQue[gsRwCtrl.u32FreeSrcFifoHead]].uRwHalfKb;
                }

                if(u32ReadFifoLbaN>(upPrdInfo->u32LbaAddr+upPrdInfo->u32SctrCnt))
                {
                    break;
                }
                else if(u32ReadFifoLbaN<upPrdInfo->u32LbaAddr)
                {
                    // FW can't return this WUNC, previous Prd fail
                }
                else
                {
                    if((upPrdInfo->u32LbaAddr+upPrdInfo->u32SctrCnt)<g32TotalDatSector)
                    {
                        g32RestSctrCnt=(upPrdInfo->u32LbaAddr+upPrdInfo->u32SctrCnt)-u32ReadFifoLbaN;
                    }
                    else
                    {
                        g32RestSctrCnt=g32TotalDatSector-u32ReadFifoLbaN;
                    }

                    rmNvmeSetUncFlag(gsPrdInfo.uarPrdQue[u16PrdIdx].uHwPrdIdx);
                    gsPrdInfo.uarPrdQue[u16PrdIdx].uUncFlag=cUncAfterTrig;

                    if(!g32RestSctrCnt)
                    {
                        break;
                    }
                }
            }
            else
            {
                rmNvmeSetUncFlag(gsPrdInfo.uarPrdQue[u16PrdIdx].uHwPrdIdx);
                gsPrdInfo.uarPrdQue[u16PrdIdx].uUncFlag=cUncAfterTrig;
            }
        }
#endif/* if _ENABLE_WUNC */

        if(!gbNewSrcF)
        {
            u16NowNodeIdx=gsRwCtrl.uarFreeSrcQue[gsRwCtrl.u32FreeSrcFifoHead];
            gpFlashAddrInfo=&garSrcAddrInfo[u16NowNodeIdx];

            if((g16FBlock!=usReadSrcTab.u16FBlock)||((g32FPageNoTran+gpFlashAddrInfo->uPlaneCnt)!=usReadSrcTab.u32FPage)||
               !((BYTE)usReadSrcTab.u32FPage&(((gOpTyp==cHdmaDummy)?(g4kNumPerPlane>>1):g4kNumPerPage)-1)))
            {
                if(mGetSrcOccpyCnt()>=cReadSafetyFifoDpt)
                {
                    while((mGetSrcOccpyCnt()>=cReadSafetyFifoDpt)&&(chkExitSeqR(upPrdInfo->uHwPrdIdx, cTrue)==cFalse))
                        ;

                    if((mGetSrcOccpyCnt()>=cReadSafetyFifoDpt)&&(chkExitSeqR(upPrdInfo->uHwPrdIdx, cTrue)==cTrue))
                    {
                        break;
                    }
                }

                // if((gOpTyp==cHmbWrCacheData)&&((gsRwCtrl.u32ReadFifoLbaN+gpFlashAddrInfo->uRwHalfKb)>gsRwCtrl.u32ReadHostLbaN))
                // {
                //    break;    // 2260 is XXXX
                // }

                // gpHostAddrInfo->u16FlashRBufPtr=addReadBufPtr(gpHostAddrInfo->u16FlashRBufPtr, gpFlashAddrInfo->uRwHalfKb);

                // always issue multi plane rd in seq read case
                // if((gpFlashAddrInfo->uRwHalfKb+gSectorH)>gSectorPerPlaneH)
                // {
                // g16RwOpt|=c16Bit0;
                // }

                // gsRwCtrl.u32ReadFifoLbaN+=gpFlashAddrInfo->uRwHalfKb;
                // gsRwCtrl.u32FreeSrcFifoHead=(gsRwCtrl.u32FreeSrcFifoHead+1)&(cReadFifoDpt-1);
                // gbNewSrcF=1;

                addSeqReadHead(upPrdInfo);
            }
        }

        uReadSctrCnt=getReadSctrCnt(g32RestSctrCnt);

        if(gbNewSrcF)
        {
            u16NowNodeIdx=gsRwCtrl.uarFreeSrcQue[gsRwCtrl.u32FreeSrcFifoHead];
            gpFlashAddrInfo=&garSrcAddrInfo[u16NowNodeIdx];
            g32FPageNoTran=usReadSrcTab.u32FPage;
            gpFlashAddrInfo->uPrdPtr=(BYTE)u16PrdIdx;
            gpFlashAddrInfo->uTsb4kIdx=(gpHostAddrInfo->u16FlashRBufPtr>>cSctrTo4kShift);
            gpFlashAddrInfo->uSrcIdx=u16NowNodeIdx;
#if _ENABLE_SECAPI
            if(upPrdInfo->uSecFlag&cMbrDummyReturn)
            {
                g16FBlock=g16AbstrFBlock=0;
                mSetFRwParam(gpHostAddrInfo->u16FlashRBufPtr, uReadSctrCnt, 0, cMbrReadDummy);
                gpFlashAddrInfo->uDieAddr=(BYTE)gsE2eInfo.u32CurrentSctCnt;
                gpFlashAddrInfo->uCe=(BYTE)(gsE2eInfo.u32CurrentSctCnt>>8);
                gpFlashAddrInfo->uIntlvAddr=(BYTE)(gsE2eInfo.u32CurrentSctCnt>>16);
                gpFlashAddrInfo->uCh=(BYTE)(gsE2eInfo.u32CurrentSctCnt>>24);
            }
            else
#endif

            if(!usReadSrcTab.u16FBlock)
            {
                g16FBlock=g16AbstrFBlock=0;

                if(g32FPageNoTran>=g16H2fTabSize)
                {
                    // mSetFRwParam(gpHostAddrInfo->u16FlashRBufPtr, uReadSctrCnt, 0, cHmbWrCacheData);
                    gsFtlDbg.u16DummyFailType=cPostFAddrInfoSeqR;
#if (C_Log_SaveMask&C_Debug_P2)    // 20181031_Oscar
                    NLOG(cLogHost, READ_C, 3, " g32FPageNoTran=0x%08X, g16H2fTabSize=0x%04X ", g32FPageNoTran>>16, g32FPageNoTran,
                         g16H2fTabSize);
#endif
                    debugWhile();
                }
                else
                {
                    mSetFRwParam(gpHostAddrInfo->u16FlashRBufPtr, uReadSctrCnt, 0, cHdmaDummy);
                    gpFlashAddrInfo->uDieAddr=(BYTE)gsE2eInfo.u32CurrentSctCnt;
                    gpFlashAddrInfo->uCe=(BYTE)(gsE2eInfo.u32CurrentSctCnt>>8);
                    gpFlashAddrInfo->uIntlvAddr=(BYTE)(gsE2eInfo.u32CurrentSctCnt>>16);
                    gpFlashAddrInfo->uCh=(BYTE)(gsE2eInfo.u32CurrentSctCnt>>24);
                }
            }
            else
            {
                g16FBlock=usReadSrcTab.u16FBlock;
                // g16FPage=mTran4kAddr(g32FPageNoTran);
                gSectorH=mTranSctr4kAddr(g32FPageNoTran)+gStartSector;
                tranAddrInfo(gpFlashAddrInfo);
                // tranCeNum(gpFlashAddrInfo);
                mSetFRwParam(gpHostAddrInfo->u16FlashRBufPtr, uReadSctrCnt, c16Bit1|c16Bit4|c16Bit6|c16Bit15, cHostReadData);
            }

            gpFlashAddrInfo->uPlaneCnt=1;
            gbNewSrcF=0;
        }
        else    // if (!gbNewSrcF)
        {
            gpFlashAddrInfo->uRwHalfKb+=uReadSctrCnt;
            gpFlashAddrInfo->uPlaneCnt++;
        }

        gsE2eInfo.u32CurrentSctCnt+=uReadSctrCnt;

        addLbaAddr(uReadSctrCnt);
        g32RestSctrCnt-=uReadSctrCnt;
    }

#if 0    // _ENABLE_WUNC
    if(u32FAddr&c32FBlockUncBit)
    {
        rmNvmeSetUncFlag(gsPrdInfo.uarPrdQue[u16PrdIdx].uHwPrdIdx);
        gsPrdInfo.uarPrdQue[u16PrdIdx].uUncFlag=cUncAfterTrig;
    }
#endif

    if(!gbNewSrcF&&(!mChkReadAhead||((gsRwCtrl.u32ReadFifoLbaN+gpFlashAddrInfo->uRwHalfKb)>=g32TotalDatSector)))
    {
        addSeqReadHead(upPrdInfo);
    }

#if _ENABLE_WUNC
    if(uWUNCTermFlag)
    {
        if(!gbNewSrcF)
        {
            addSeqReadHead(upPrdInfo);
        }

        termContiR();
    }
#endif
    /*
       * while(rmGetPrdRestSctrCnt(upPrdInfo->uHwPrdIdx))
       * {
       *  while((gsRwCtrl.u32TrigHmbTail!=gsRwCtrl.u32TrigHmbHead)&&gsHmbInfo.uHmbFreeHwPrdCnt)
       *  {
       *      postHmbReadData();
       *  }
       *
       *  if(rmHmbPrdQueTrigIdx!=gsHmbInfo.uHmbHwPrdTail)
       *  {
       *      releaseHmbHwPrd();
       *  }
       * }
       */
}    /* postFAddrInfoSeqR */

/*
   * BYTE srchSrcInHmb(WORD u16Hblock, WORD u16Hpage)
   * {
   *  if(gsHmbInfo.uHmbCache4kCnt)
   *  {
   *      BYTE uHmb4kPtr=gsHmbInfo.uHmbCache4kCnt;
   *
   *      do
   *      {
   *          uHmb4kPtr--;
   *
   *          if((gsHmbInfo.u32HmbCacheHp[uHmb4kPtr]==u16Hpage)&&(gsHmbInfo.u16HmbCacheHb[uHmb4kPtr]==u16Hblock))
   *          {
   *              return uHmb4kPtr;
   *          }
   *      }
   *      while(uHmb4kPtr);
   *  }
   *
   *  return 8;
   * }
   */

BYTE srchSrcInF2hTab2(WORD u16Hblock, WORD u16Hpage, H2FTABLE *upReadSrcTab, BYTE u16PrdIdx)
{
    LWORD u32Rst4kCnt, u32FAddr, u32Org4kCnt;
    WORD u16TempHpage=u16Hpage;

    // BYTE uHmb4kPtr;

    // uHmb4kPtr=srchSrcInHmb(u16Hblock, u16Hpage);

    // if(uHmb4kPtr!=8)    // 2260
    // {
    //    upReadSrcTab->u16FBlock=0;
    //    upReadSrcTab->u32FPage=uHmb4kPtr+c16H2fTabSize;
    // }
    // else
    // {
    if((gsRwCtrl.usSeqSrchTriged.u16HBlock!=u16Hblock)||(gsRwCtrl.usSeqSrchTriged.u16HPage<u16Hpage))
    {
        while(gsRwCtrl.uSrchQCnt)
            ;// for Debug

        u32Rst4kCnt=(g32RestSctrCnt+cSctrPer4k-1)>>cSctrTo4kShift;
        u32Rst4kCnt=mGetmin(u32Rst4kCnt, (c4KPerRH2fTab-(u16Hpage&(c4KPerRH2fTab-1))));
        u32Rst4kCnt=mGetmin(u32Rst4kCnt, cSrchEnginDepth);
        gsRwCtrl.u16SeqSrchStPage=u16Hpage;
        gsRwCtrl.usSeqSrchTriged.u16HBlock=u16Hblock;
        u32Org4kCnt=u32Rst4kCnt;

        do
        {
            gsRwCtrl.usSrchQ[gsRwCtrl.uSrchQHead].u16HBlock=u16Hblock;
            gsRwCtrl.usSrchQ[gsRwCtrl.uSrchQHead].u16HPage=u16TempHpage;
            gsRwCtrl.uarSrchQ2RdHaddr[gsRwCtrl.uSrchQHead]=u16PrdIdx;
            u16TempHpage++;
            u32Rst4kCnt--;
            gsRwCtrl.uSrchQHead=(gsRwCtrl.uSrchQHead+1)&(cSrchQDepth-1);
            gsRwCtrl.uSrchQCnt++;
        }
        while(u32Rst4kCnt);

        gsRwCtrl.usSeqSrchTriged.u16HPage=u16Hpage+u32Org4kCnt-1;
        gpHostAddrInfo->u16SrchSrcTabStIdx=0;
        postSrchF2hTab();    // Trig HW search engin.
        gpHostAddrInfo->u16Srch4kCnt=0xFFFF;    // Bypass push Prd to load table state in postSrchF2hTab(). [CC]

        while(gsRwCtrl.uSrchQCnt)
        {
            if(!rmChkNbsQueMt)
            {
                postSrchF2hTab();
            }
        }
    }

    // Get result
    u32FAddr=garSrchSrcTab[u16Hpage-gsRwCtrl.u16SeqSrchStPage];
    garSrchSrcTab[u16Hpage-gsRwCtrl.u16SeqSrchStPage]=c32BitFF;
    upReadSrcTab->u16FBlock=mGetSrcFBlkAddr(u32FAddr);
    upReadSrcTab->u32FPage=mGetSrcFPageAddr(u32FAddr);
    // }

    if(upReadSrcTab->u16FBlock==c16FBlockInitValue)
    {
        return cFalse;
    }
    else
    {
        return cTrue;
    }
}    /* srchSrcInF2hTab2 */

void termContiR()
{
    BYTE uCh, uIntlv;

    if(gsPrdInfo.uSeqRCmdCnt)
    {
        trigHostSeqRead(1);
    }

    // while(rmPrdPdtr0|rmPrdPdtr1)
    //    ;// wait all prd don
    while((gsPrdInfo.uSeqRTrigCnt)&&(!mChkHandlePcieErrF))
    {
        chkReleaseFreeHwPrd();
    }

    gsRwCtrl.u32SeqRdFlag|=cBit1;

    while((gsRwCtrl.u32SeqRdFlag&cBit1)||(gsRwCtrl.u32SeqRdFlag&cBit2)) // while(gsRwCtrl.u32SeqRdFlag&cBit1)
        ;

    // while(rmChkHdmaBz||(gsRwCtrl.u32FreeSrcFifoTail!=gsRwCtrl.u32FreeSrcFifoHead)||(gsHmbInfo.uHmbFreeHwPrdCnt!=cHmbHwPrdDepth))
    // {
    // if(rmHmbPrdQueTrigIdx!=gsHmbInfo.uHmbHwPrdTail)
    // {
    //    releaseHmbHwPrd();
    // }
    // rmResetBufFlg;
    // }
    for(uCh=0; uCh<gTotalChNum; uCh++)
    {
        for(uIntlv=0; uIntlv<gIntlvWay; uIntlv++)
        {
            gsRwCtrl.uContiAddrCnt[uCh][uIntlv]=0;
        }
    }

    // gsRwCtrl.u16ReadAheadSize=(c16ReadBufSize/2);
    gsRwCtrl.uConsecReadCnt=0;
    // gsRwCtrl.u32H2fSgmtRdyTail=gsRwCtrl.u32H2fSgmtRdyHead;

    if(gsCacheInfo.u32H2f1kTabSgmtPrep)
    {
        if(gsRwCtrl.u32H2fSgmtRdyTail!=gsRwCtrl.u32H2fSgmtRdyHead)
        {
            gsRwCtrl.u32H2fSgmtRdyTail=(gsRwCtrl.u32H2fSgmtRdyTail+1)&(cH2fSgmtRdyDept-1);
        }
        else
        {
            rstH2F1KInfo();
        }

        gsCacheInfo.u32H2f1kTabSgmtPrep=0;
    }

    while(gsRwCtrl.u32H2fSgmtRdyTail!=gsRwCtrl.u32H2fSgmtRdyHead)
        ;

    mClrReadAhead;
    mClrContHAddrR;
    // mClrUnlimitedR;
    // rmResetBufFlg;

    // if(gsRwCtrl.u32SeqRdFlag)
    {
        gsRwCtrl.u32SeqRdFlag=0;

        while(gsRwCtrl.u32SeqRdCpu1Flag)
            ;
    }
    bopClrRam((LWORD)&garSrchSrcTab, sizeof(garSrchSrcTab), 0xFFFFFFFF, cClrCore0Dccm|cBopWait);
}    /* termContiR */

#endif/* if (!_PRJ_SMIVU) */

void findReadSrc(WORD u16Hblock, WORD u16Hpage, BYTE uOpt)
{
#if (_PRJ_ISP||_PRJ_NVME||_PRJ_SMIVU)
    // H2FTABLE usReadSrcTab;
    LWORD u32FAddr, u32H2f1kTabSgmt;
    WORD u16Hsgmt, u16NowNodeIdx;
    BYTE uSgmtIdx;

    if(!mChkSrcInCache(u16Hblock)||(srchSrcInF2hTab(u16Hblock, u16Hpage)==c16BitFF))
    {
        if(g16arH2fTabPtr[u16Hblock]!=c16H2FTabInitValue)
        {
            u16Hsgmt=u16Hpage>>9;
            u32H2f1kTabSgmt=(LWORD)(u16Hblock<<16)|u16Hsgmt;
#if _ENABLE_RAID
            uSgmtIdx=srchH2f1kTabSgmt2(u32H2f1kTabSgmt, cHalfRH2fTabNum);
#else
            // uSgmtIdx=srchH2f1kTabSgmt2(u32H2f1kTabSgmt, (gInSecApi?cHalfRH2fTabNum:cMaxRH2fTabNum));
            uSgmtIdx=srchH2f1kTabSgmt2(u32H2f1kTabSgmt, cMaxRH2fTabNum);
#endif

            if(uSgmtIdx==0xFF)
            {
#if _ENABLE_RAID
                uSgmtIdx=setH2f1kTabSgmt(u32H2f1kTabSgmt, cHalfRH2fTabNum);
#else
                // uSgmtIdx=setH2f1kTabSgmt(u32H2f1kTabSgmt, (gInSecApi?cHalfRH2fTabNum:cMaxRH2fTabNum));
                uSgmtIdx=setH2f1kTabSgmt(u32H2f1kTabSgmt);
#endif
                mSetH2f1kTabSgmtPrep(uSgmtIdx);

                // AES will bypass HMB in here.
                if((uOpt&cBit0)&&mChkHmbLink(u16Hblock))
                {
                    u16NowNodeIdx=mGetHmbLink(u16Hblock);
                    g16arH2fTabPtr[u16Hblock]=g16arH2fTabPtr[g16TotalHBlock+u16NowNodeIdx];
                    // g16arH2fTabPtr[g16TotalHBlock+u16NowNodeIdx]=0xFFFF;

                    while(gsRwCtrl.u32ProgFifoTail!=gsRwCtrl.u32ProgFifoHead)
                        ;

                    readH2fSgmtTable(u16Hblock, u16Hsgmt, uSgmtIdx, 1);

                    // g16arH2fTabPtr[g16TotalHBlock+u16NowNodeIdx]=g16arH2fTabPtr[u16Hblock];
                    mSetH2fTabEntry(u16Hblock, gMaxH2fTabBlkNum, u16NowNodeIdx);

#if _EN_RAID_DECODE
                    while((gsRwCtrl.u32H2fSgmtRdyTail==gsRwCtrl.u32H2fSgmtRdyHead)||g32DecodeWait)
                        ;
#else
                    while(gsRwCtrl.u32H2fSgmtRdyTail==gsRwCtrl.u32H2fSgmtRdyHead)
                        ;
#endif

                    gsRwCtrl.u32H2fSgmtRdyTail=(gsRwCtrl.u32H2fSgmtRdyTail+1)&(cH2fSgmtRdyDept-1);
                    mClrH2f1kTabSgmtPrep(uSgmtIdx);
                }
                else if(mChkHmbLink(u16Hblock))
                {
#if _EN_PATCH_SM2263AA
                    WORD u16BufPtr=c16RH2fTabSIdx+(uSgmtIdx<<2);
                    BYTE uBufMsk=(u16BufPtr&c16Bit2)?0xF0:0x0F;
                    readHmbH2fTab(u16BufPtr, u16Hblock, u16Hsgmt, uSgmtIdx, 1);
#else
                    readHmbH2fTab(c16RH2fTabSIdx+(uSgmtIdx<<2), u16Hblock, u16Hsgmt, uSgmtIdx, 1);
#endif

                    while(mChkH2f1kTabSgmtPrep(uSgmtIdx))    // !gsHmbInfo.uHmbSgmtRdyCnt)
                    {
                        chkHmbPrdDone();
                    }

#if _EN_PATCH_SM2263AA
                    u16BufPtr>>=3;

                    while((rmBufStatus(u16BufPtr)&uBufMsk)!=uBufMsk)
                        ;
                    rmSetBuf8Sts(u16BufPtr, uBufMsk);
#endif
                }
                else
                {
                    readH2fSgmtTable(u16Hblock, u16Hsgmt, uSgmtIdx, 1);
#if _EN_RAID_DECODE
                    while((gsRwCtrl.u32H2fSgmtRdyTail==gsRwCtrl.u32H2fSgmtRdyHead)||g32DecodeWait)
                        ;
#else
                    while(gsRwCtrl.u32H2fSgmtRdyTail==gsRwCtrl.u32H2fSgmtRdyHead)
                        ;
#endif

                    gsRwCtrl.u32H2fSgmtRdyTail=(gsRwCtrl.u32H2fSgmtRdyTail+1)&(cH2fSgmtRdyDept-1);
                    mClrH2f1kTabSgmtPrep(uSgmtIdx);
                }

                // getReadH2fTabRdy(&usReadSrcTab, u16Hpage, uSgmtIdx);
            }
            else
            {
                while(mChkH2f1kTabSgmtPrep(uSgmtIdx))
                    ;// for Debug

                // u32FAddr=garH2f1kTable[uSgmtIdx][u16Hpage&(c16RH2fTabSize-1)];
                // usReadSrcTab.u16FBlock=mGetSrcFBlkAddr(u32FAddr);
                // usReadSrcTab.u32FPage=mGetSrcFPageAddr(u32FAddr);
            }

            u32FAddr=garH2f1kTable[uSgmtIdx][u16Hpage&(c16RH2fTabSize-1)];
            gsCacheInfo.u16SrchRslFBlock=mGetSrcFBlkAddr(u32FAddr);
            gsCacheInfo.u32SrchRslFPage=mGetSrcFPageAddr(u32FAddr);
        }
    }
#else/* if (_PRJ_ISP||_PRJ_NVME) */
    while(1)
        ;
#endif/* if _PRJ_ISP */
}    /* findReadSrc */







