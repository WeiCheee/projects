







#include "inc/TypeDef.h"
#include "inc/Const.h"
#include "inc/table.h"
#include "inc/GlobVarS.h"
#include "inc/GlobVarT.h"
#include "inc/GlobVar1.h"
#include "inc/ProType.h"
#include "inc/Reg.h"
#include "inc/ProType.h"
#include "inc/Mac.h"
#include "inc/BitDef.h"
#include "inc/GreyBox.h"
#if ((_CPUID)||(_ICE_LOAD_ALL))
#include "FlashCmdDir.c"
void setSprByteOfTabBlk(BYTE uTabID, WORD u16Spr0, WORD u16Spr1, WORD u16Spr2, LWORD u32Serial, BYTE uPlaneAddr, WORD u16Spr7)
{
    BLKSPRINFO usBlkSprInfo;

    usBlkSprInfo.u16Seed=g16arSeedTable[gpFlashAddrInfo->u16FPage];

    usBlkSprInfo.u16Spr8.us2BYTE.LowByte=uTabID;
    usBlkSprInfo.u16Spr8.us2BYTE.HighByte=gOpTyp;
    usBlkSprInfo.u32Spr9and10.u32all=u32Serial;
    // usBlkSprInfo.u16Spr11.u16all=mGetGlobEraseCnt(g16AbstrFBlock);
    usBlkSprInfo.u16Spr11.u16all=mGetGlobEraseCnt(g16AbstrFBlock);
    usBlkSprInfo.u16Spr0.u16all=u16Spr0;
    usBlkSprInfo.u16Spr1.u16all=u16Spr1;
    usBlkSprInfo.u16Spr2.u16all=u16Spr2;

    if(uTabID==cWPROBlockID)
    {
        usBlkSprInfo.u16Spr3.u16all=gsWproInfo.uActIdx;
    }
    else if(uTabID==cH2fTableID)
    {
        usBlkSprInfo.u16Spr3.u16all=g16arH2fTabPtr[u16Spr0];
    }
    else
    {
        usBlkSprInfo.u16Spr3.u16all=0xFFFF;
    }

    if((uTabID==cCacheBlockID)&&(gOpTyp==cPwrOnDummyProg))
    {
        usBlkSprInfo.u16Spr4.u16all=0xFFFF;
        usBlkSprInfo.u16Spr5.u16all=0xFFFF;
    }
    else
    {
        usBlkSprInfo.u16Spr4.u16all=gsFtlDbg.u32PowerOnCnt&0xFFFF;    // g16PowerOnCnt;
        usBlkSprInfo.u16Spr5.u16all=(gsFtlDbg.u32PowerOnCnt>>16);
    }

    if(uTabID==cH2fTableID)
    {
        usBlkSprInfo.u16Spr6.u16all=g16arH2fTabBlk[mGetH2fTabBlkIndex(u16Spr0)];
    }
    else if(uTabID==cWPROBlockID)
    {
        usBlkSprInfo.u16Spr6.u16all=gPowerDownMode;

        if(u16Spr0==cWproQBWithDumyW)
        {
            usBlkSprInfo.u16Spr6.u16all=gsFtlDbg.u16DummyFailType;
        }
    }
    else
    {
        usBlkSprInfo.u16Spr6.u16all=0xFFFF;
    }

    usBlkSprInfo.u16Spr7.u16all=u16Spr7;

    setSprByte(&usBlkSprInfo, uPlaneAddr);
}    /* setSprByteOfTabBlk */

void setSprByteforTest(BYTE uPlaneAddr, WORD u16Spr0, WORD u16Spr1, WORD u16Spr2, WORD u16Spr3, BYTE uTabID, LWORD u32Serial)
{
    BLKSPRINFO usBlkSprInfo;

    usBlkSprInfo.u16Seed=g16arSeedTable[gpFlashAddrInfo->u16FPage];
    usBlkSprInfo.u16Spr0.u16all=u16Spr0;
    usBlkSprInfo.u16Spr1.u16all=u16Spr1;
    usBlkSprInfo.u16Spr2.u16all=u16Spr2;
    usBlkSprInfo.u16Spr3.u16all=u16Spr3;
    usBlkSprInfo.u16Spr4.u16all=0x9527;    // g16PowerOnCnt;
    usBlkSprInfo.u16Spr5.u16all=0x9453;
    usBlkSprInfo.u16Spr6.u16all=0x55AA;
    usBlkSprInfo.u16Spr7.u16all=0x7788;
    usBlkSprInfo.u16Spr8.us2BYTE.HighByte=gpFlashAddrInfo->uOpTyp;
    usBlkSprInfo.u16Spr8.us2BYTE.LowByte=uTabID;
    usBlkSprInfo.u32Spr9and10.u32all=u32Serial;
    usBlkSprInfo.u16Spr11.u16all=0x5566;    // g32arGlobEraseCnt[g16AbstrFBlock].u16EraseCnt;
    setSprByte(&usBlkSprInfo, uPlaneAddr);
    setSprByte(&usBlkSprInfo, uPlaneAddr+1);
    setSprByte(&usBlkSprInfo, uPlaneAddr+2);
    setSprByte(&usBlkSprInfo, uPlaneAddr+3);
}    /* setSprByteforTest */

// test end
void writeFourData(BYTE uData1, BYTE uData2, BYTE uData3, BYTE uData4)
{
    if(rmChkToggleMo||rmChkOnfi2Mo)
    {
        rFLCtrl[rcRd0]=uData1;
        rFLCtrl[rcRd1]=uData1;
        rFLCtrl[rcRd2]=uData2;
        rFLCtrl[rcRd3]=uData2;
        rFLCtrl[rcRd4]=uData3;
        rFLCtrl[rcRd5]=uData3;
        rFLCtrl[rcRd6]=uData4;
        rFLCtrl[rcRd7]=uData4;
        rmManWr(8);
    }
    else
    {
        rFLCtrl[rcRd0]=uData1;
        rFLCtrl[rcRd1]=uData2;
        rFLCtrl[rcRd2]=uData3;
        rFLCtrl[rcRd3]=uData4;
        rmManWr(4);
    }
}    /* writeFourData */

void setFeatureByChCe(BYTE uCh, BYTE uCe, BYTE uAddr, BYTE uP0, BYTE uP1, BYTE uP2, BYTE uP3, BYTE uWaitReady)
{
    setFLActCh(uCh);
    rmCeOn(uCe);
    rmCle(0xEF);
    rmAle(uAddr);
    writeFourData(uP0, uP1, uP2, uP3);

    while(rmChkCmdFifoBz)
        ;

    if(uWaitReady)
    {
        rmCle(0x70);
        rmStsFailMask(0x00);
        rmRdStatus(0x60);

        while(rmChkCmdFifoBz)
            ;
    }

    rmCeOff(uCe);
}    /* setFeatureByChCe */

#if (_EN_WD_ResetCmd_Force_SDR)
void initForceSDRforResetCmd()
{
    // Wait LITEON/TSB !!
}    /* initForceSDRforResetCmd */

#endif/* if (_EN_WD_ResetCmd_Force_SDR) */

void resetFlashAtIntlv(BYTE uCh, BYTE uIntlvAddr)
{
    setFLActCh(uCh);
    rmCeOn(mGetCEAddr(uIntlvAddr));
    flashChangeDieCmd(mGetDieAddr(uIntlvAddr));
    rmNop2(0x80);
#if (_EN_WD_ResetCmd_Force_SDR)
    rmCle(0xFD);    // (gSyncResetCmd);
#else
#if _SANDISK_3D_GEN3
    rmCle(0xFB);
#else
    rmCle(0xFF);
#endif
#endif
    sysDelay(0xFFFF);
    rmNop(0x80);
    mWaitCmdFifoBz;
    rmCle(gReadStatusCmd);
    rmNop(0x80);
    rmStsFailMask(0x00);
    rmRdStatus(0x60);
    mWaitCmdFifoBz;
    rmCeOff(mGetCEAddr(uIntlvAddr));
}    /* resetFlashAtIntlv */

void resetFlash()
{
    // 4CH 8CE
    volatile BYTE uTemp[4][8]=
    {
        0
    };
    // BYTE uIndex;
    BYTE uTempActiveCe=0;
    BYTE uDieIndex;

#if 1
    setSelMulFL(1);
    rmChSoftReset;
    setSelMulFL(0);
#endif

    for(uDieIndex=0; uDieIndex<gTotalDiePerCe; uDieIndex++)
    {
        for(uTempActiveCe=0; uTempActiveCe<gTotalCeNum; uTempActiveCe++)
        {
            for(gActiveCh=0; gActiveCh<gTotalChNum; gActiveCh++)
            {
                setFLActCh(gActiveCh);
                rmCeOn(uTempActiveCe);

#if (_TSB_BiCS3||_SANDISK_3D_GEN2||_SANDISK_3D_GEN3|_TSB_BiCS4)
                // rmCle(gSyncResetCmd);
                if(rmGpioP06SelToggle)
                {
                    rmCle(gSyncResetCmd);
                }
                else
                {
                    rmCle(0xF1+uDieIndex);
                    rmNop2(0x80);
                    rmCle(0x89);
                    rmNop2(0x80);
                    rmNop2(0x80);
                    rmCle(0xFD);
                }
#endif
            }
        }
    }

    sysDelay(0x20FFFF);    // min 3ms reset time for CPU 350Mhz
    waitAllFlashReady();

    // rmNop(0x80);
    for(uDieIndex=0; uDieIndex<gTotalDiePerCe; uDieIndex++)
    {
        for(uTempActiveCe=0; uTempActiveCe<gTotalCeNum; uTempActiveCe++)
        {
            for(gActiveCh=0; gActiveCh<gTotalChNum; gActiveCh++)
            {
                setFLActCh(gActiveCh);
                rmCeOn(uTempActiveCe);

                while(rmChkCmdFifoBz)
                    ;

#if (_TSB_BiCS3||_SANDISK_3D_GEN2||_SANDISK_3D_GEN3|_TSB_BiCS4)
                // rmCle(gSyncResetCmd);
                rmCle(0xF1+uDieIndex);
                rmNop2(0x80);
#endif
                rmCle(gReadStatusCmd);    // Flash Reset CMD only support 70h in SPEC,but using 78h also work!!
                rmNop(0x80);
                rmStsFailMask(0x00);
                rmRdStatus(0x60);

                while(rmChkCmdFifoBz)
                    ;

                rmCeOff(uTempActiveCe);
            }
        }
    }

#if (_EN_WD_ResetCmd_Force_SDR)
    initForceSDRforResetCmd();
#endif
}    /* resetFlash */

#if 0
void setFeatureByChCeDie(BYTE uCh, BYTE uCe, BYTE uDieIndex, BYTE uAddr, BYTE uP0, BYTE uP1, BYTE uP2, BYTE uP3, BYTE uWaitReady)
{
    BYTE uPlaneRegBackUp, uSectorRegBackUp;
    WORD u16BlkRegBackUp, u16PageRegBackUp;

    setFLActCh(uCh);

    uPlaneRegBackUp=rFLCtrl[rcPlaneSel];
    uSectorRegBackUp=rFLCtrl[rcSec];
    u16PageRegBackUp=r16FLCtrl[rcPage/2];
    u16BlkRegBackUp=r16FLCtrl[rcBlock/2];
    rmCeOn(uCe);
    rmCle(0xD5);
    rmNop(0x10);
    rmAle(uDieIndex);
    rmNop(0x10);
    rmAle(uAddr);
    rmNop(0x10);

    while(rmChkCmdFifoBz)
        ;

    writeFourData(uP0, uP1, uP2, uP3);
    rmNop(cTwhr);

    while(rmChkCmdFifoBz)
        ;

    if(uWaitReady)
    {
        rmSetBlkAddr(0x0000);
        rmSetPageAddr(0x0000);
        rmSetSctrAddr(0x00);
        rmEnAutoPlane;
        rmSetPlaneBit(0);
        rmSetDieBit(uDieIndex);

#if (_SANDISK_3D_GEN3)
        rmCle(0xF1+uDieIndex);
        rmCle(gReadStatusCmd);
#else
        rmCle(0x78);
        rmAle3;
#endif
        rmStsFailMask(0x00);
        rmRdStatus(0x60);

        while(rmChkCmdFifoBz)
            ;
    }

    rmCeOff(uCe);
    rFLCtrl[rcPlaneSel]=uPlaneRegBackUp;
    rFLCtrl[rcSec]=uSectorRegBackUp;
    r16FLCtrl[rcPage/2]=u16PageRegBackUp;
    r16FLCtrl[rcBlock/2]=u16BlkRegBackUp;
}    /* setFeatureByChCeDie */

void setFlashFeature(BYTE uAddr, BYTE uP0, BYTE uP1, BYTE uP2, BYTE uP3, BYTE uWaitReady)
{
    BYTE uCh, uCe;

    // SetFeatrue
    for(uCh=0; uCh<gTotalChNum; uCh++)
    {
        for(uCe=0; uCe<gTotalCeNum; uCe++)
        {
            // getFeatureByChCeDie(uCh, uCe, 0x00, uAddr);
            setFeatureByChCe(uCh, uCe, uAddr, uP0, uP1, uP2, uP3, uWaitReady);

            // if(uWaitReady)
            // {
            //    getFeatureByChCeDie(uCh, uCe, 0x00, uAddr);
            // }
        }
    }
}    /* setFlashFeature */

#endif/* if 0 */
void pollStatus(BYTE uPollVal)
{
    if(mChkCardMode(cMultiDie))
    {
#if (_SANDISK_3D_GEN3)
        rmCle(0xF1+rmGetDieBit());
#else
        rmCle(gReadStatusEnhCmd);
        rmNop(5);
        rmAle3;
#endif
    }

    rmCle(gReadStatusCmd);
    rmRdStatus(uPollVal);
}    /* pollStatus */

void setAutoWrite(BYTE uCount, WORD u16Opt)
{
    if(u16Opt&c16Bit1)
    {
        rmWrDataAutoBuf;
    }
    else
    {
        rmWrDataDisBuf;
    }

    rmSetStartSector(gSectorH);
    rmWrData(uCount);
}

void setAutoRead(BYTE uCount, WORD u16Opt)
{
    if(u16Opt&c16Bit1)
    {
        rmRdDataAutoBuf;

#if _ENABLE_RAID
#if _EN_RAID_GC
        if((gOpTyp==cPreReadData)||(gOpTyp==cLastReadData)||(!gsGcInfo.uHmbEnGcCache&&((gOpTyp==cMoveReadData)||(u16Opt&cReadGcDesF2h))))
#else
        if((gOpTyp==cPreReadData)||(gOpTyp==cLastReadData))
#endif
        {
            rmEnFshRaidFlag;
        }
#endif
    }
    else
    {
        rmRdDataDisBuf;
    }

    rmSetStartSector(gSectorH);
#if _GREYBOX
    if(((gsGbInfo.uGreyBoxItem==cReadRetryDecodeTestID)||(gsGbInfo.uGreyBoxItem==cErrHdlReadUncInSlcDataID)\
        ||(gsGbInfo.uGreyBoxItem==cErrHdlReadUncInTlcDataID)||(gsGbInfo.uGreyBoxItem==cErrHdlProgWPROID))
       &&(gOpTyp==cHostReadData))
    {
        if(gErrInjectFlag&cBit0)
        {
            ctrlErrInject(0x10, cErrInjectReadMode, 0xFF, 0x30, 0xFFFF);    // erery Chunk Fail

            // gErrInjectFlag&=(~cBit0);
        }
        else
        {
            ctrlErrInject(0x00, cErrInjectReadMode, 0x01, 0x30, 0xFFFF);
        }
    }
    else if(gsGbInfo.uGreyBoxItem==cErrHdlGcFingerFailTestID)
    {
        if(gReadErrinjectEn&&(gErrInjectFlag&cBit0)&&(gOpTyp==cChkFingerFail))
        {
            ctrlErrInject(0x10, cErrInjectReadMode, 0xFF, 0x30, 0xFFFF);    // erery Chunk Fail
        }
        else
        {
            ctrlErrInject(0x00, cErrInjectReadMode, 0x01, 0x30, 0xFFFF);
        }
    }
    else if((gsGbInfo.uGreyBoxItem==cRAIDDecOnH2fTab))
    {
        if(gReadErrinjectEn&&(gErrInjectFlag&cBit0)&&((gOpTyp==cH2fReadTab)||(gOpTyp==cH2fRead1kTab)||(gOpTyp==cRaidDecRead)))
        {
            if((gPlaneAddr==(gPlaneNum-1))&&(gCh==(gTotalChNum-2))&&(gDieAddr==(gIntlvWay-1)))
            {
                ctrlErrInject(0x10, cErrInjectReadMode, 0x0C, 0x00, 0xFFFF);
            }
            else
            {
                ctrlErrInject(0x00, cErrInjectReadMode, 0x01, 0x30, 0xFFFF);
            }
        }
        else
        {
            ctrlErrInject(0x00, cErrInjectReadMode, 0x01, 0x30, 0xFFFF);
        }
    }
    else if((gsGbInfo.uGreyBoxItem==cRAIDDecOnH2f1kTab))
    {
        if(gReadErrinjectEn&&(gErrInjectFlag&cBit0)&&((gOpTyp==cH2fReadTab)||(gOpTyp==cH2fRead1kTab)||(gOpTyp==cRaidDecRead)))
        {
            if((gPlaneAddr==0)&&(gCh%4==0))
            {
                ctrlErrInject(0x10, cErrInjectReadMode, 0x30, 0x00, 0xFFFF);
            }
            else
            {
                ctrlErrInject(0x00, cErrInjectReadMode, 0x01, 0x30, 0xFFFF);
            }
        }
        else
        {
            ctrlErrInject(0x00, cErrInjectReadMode, 0x01, 0x30, 0xFFFF);
        }
    }
    else if((gsGbInfo.uGreyBoxItem==cRAIDDecOnNormData))
    {
        if(gReadErrinjectEn&&(gErrInjectFlag&cBit0)&&((gOpTyp==cHostReadData)||(gOpTyp==cRaidDecRead))&&
           (g16FPage>=((g16SlcPartialParityNum+cRaidParityNum)*(gTotalBankOfF2hTab)-cRaidParityNum)))
        {
            if((gPlaneAddr==0)&&(gCh==1)&&(gIntlvAddr==0))
            {
                ctrlErrInject(0x10, cErrInjectReadMode, 0x0C, 0x00, 0xFFFF);
            }
            else
            {
                ctrlErrInject(0x00, cErrInjectReadMode, 0x01, 0x30, 0xFFFF);
            }
        }
        else
        {
            ctrlErrInject(0x00, cErrInjectReadMode, 0x01, 0x30, 0xFFFF);
        }
    }
    else if((gsGbInfo.uGreyBoxItem==cRAIDDecOnOpenData))
    {
        if(gReadErrinjectEn&&(gErrInjectFlag&cBit0)&&((gOpTyp==cHostReadData)||(gOpTyp==cRaidDecRead)))
        {
            if((gPlaneAddr==0)&&(gCh==0)&&(gIntlvAddr==0))
            {
                ctrlErrInject(0x10, cErrInjectReadMode, 0x0C, 0x00, 0xFFFF);
            }
            else
            {
                ctrlErrInject(0x00, cErrInjectReadMode, 0x01, 0x30, 0xFFFF);
            }
        }
        else
        {
            ctrlErrInject(0x00, cErrInjectReadMode, 0x01, 0x30, 0xFFFF);
        }
    }
    else if((gsGbInfo.uGreyBoxItem==cRAIDDecOnPreReadData))
    {
        if(gReadErrinjectEn&&(gErrInjectFlag&cBit0)&&((gOpTyp==cPreReadData)||(gOpTyp==cRaidDecRead))&&(g16FPage<cRaidParityNum))
        {
            if((gPlaneAddr==0)&&(gCh==0)&&(gIntlvAddr==0))
            {
                ctrlErrInject(0x10, cErrInjectReadMode, 0x04, 0x00, 0xFFFF);
            }
            else
            {
                ctrlErrInject(0x00, cErrInjectReadMode, 0x01, 0x30, 0xFFFF);
            }
        }
        else
        {
            ctrlErrInject(0x00, cErrInjectReadMode, 0x01, 0x30, 0xFFFF);
        }
    }
    else if((gsGbInfo.uGreyBoxItem==cRAIDDecOnLastReadData))
    {
        if(gReadErrinjectEn&&(gErrInjectFlag&cBit0)&&((gOpTyp==cLastReadData)||(gOpTyp==cRaidDecRead))&&(g16FPage<cRaidParityNum))
        {
            if((gPlaneAddr==(gPlaneNum-1))&&(gCh==(gTotalChNum-1))&&(gIntlvAddr==(gIntlvWay-1)))
            {
                ctrlErrInject(0x10, cErrInjectReadMode, 0x80, 0x00, 0xFFFF);
            }
            else
            {
                ctrlErrInject(0x00, cErrInjectReadMode, 0x01, 0x30, 0xFFFF);
            }
        }
        else
        {
            ctrlErrInject(0x00, cErrInjectReadMode, 0x01, 0x30, 0xFFFF);
        }
    }
    else if((gsGbInfo.uGreyBoxItem==cRAIDDecOnMoveReadData))
    {
        if(gReadErrinjectEn&&(gErrInjectFlag&cBit0)&&((gOpTyp==cMoveReadData)||(gOpTyp==cRaidDecRead))&&(g16FPage<cRaidParityNum))
        {
            if((gPlaneAddr==0)&&(gCh==0)&&(gIntlvAddr==0))
            {
                ctrlErrInject(0x10, cErrInjectReadMode, 0x0C, 0x00, 0xFFFF);
            }
            else
            {
                ctrlErrInject(0x00, cErrInjectReadMode, 0x01, 0x30, 0xFFFF);
            }
        }
        else
        {
            ctrlErrInject(0x00, cErrInjectReadMode, 0x01, 0x30, 0xFFFF);
        }
    }
    else if((gsGbInfo.uGreyBoxItem==cSecurityRW)&&(gsGbInfo.uGreyBoxOpt&0x01)&&(gsGbInfo.uGreyBoxOpt&0x2))
    {
        if(gReadErrinjectEn&&(gErrInjectFlag&cBit0)&&((gOpTyp==cSecReadData)||(gOpTyp==cRaidDecRead))&&
           (g16FPage>=((g16SlcPartialParityNum+cRaidParityNum)*(gTotalBankOfF2hTab)-cRaidParityNum)))
        {
            if((gPlaneAddr==0)&&(gCh==1)&&(gIntlvAddr==0))
            {
                ctrlErrInject(0x10, cErrInjectReadMode, 0x0C, 0x00, 0xFFFF);
            }
            else
            {
                ctrlErrInject(0x00, cErrInjectReadMode, 0x01, 0x30, 0xFFFF);
            }
        }
        else
        {
            ctrlErrInject(0x00, cErrInjectReadMode, 0x01, 0x30, 0xFFFF);
        }
    }
    else
    {
        ctrlErrInject(0x00, cErrInjectReadMode, 0x01, 0x30, 0xFFFF);
    }
#endif/* if _GREYBOX */

#if _EN_RAID_DECODE
    if(rmChkDecModeRaid)
    {
        mWaitCmdFifoBz;    // wait for raid decode input
        rmSetLdpcPageIdx(gsRaidInfo.u16RaidLdpcPgIdx++);
    }

#if _EN_TEST_RAID_DECODE
    // mWaitCmdFifoBz;
    // for(BYTE uIdx=0; uIdx<c16MaxH2fTabBlkNum; uIdx++)
    {
        // if((g16arH2fTabBlk[uIdx]==g16FBlock)&&((g16FPage%8)==0)&&(gCh==0)&&(gPlaneAddr==1))
        // if((!gErrInjectFlag)&&(gsCacheInfo.u16ActiveCacheBlock==g16FBlock)&&((g16FPage%8)==0)&&(gCh==2)&&(gIntlvAddr==0)&&(gPlaneAddr==1))
        // if((!gErrInjectFlag)&&(gsCacheInfo.u16ActiveCacheBlock==g16FBlock)&&((g16FPage)==9)&&(gCh==2)&&(gIntlvAddr==0)&&(gPlaneAddr==1))
        // if((!gErrInjectFlag)&&((g16FPage)==0xbf)&&(gCh==0)&&(gIntlvAddr==0)&&(gPlaneAddr==1)&&(gPageSelCmd==1))
        if((!gErrInjectFlag)&&((g16FPage)==7)&&(gCh==2)&&(gIntlvAddr==0)&&(gPlaneAddr==1))
        {
            ctrlErrInject(0x10, cErrInjectReadMode, 0xFF, 0x30, 0xFFFF);    // erery Chunk Fail
            /*
               * r32FLCtrl[0xC4/4]=0x00000000;
               * r32FLCtrl[0xC8/4]=0x00000000;
               * r32FLCtrl[0xC4/4]=0x00000003;
               * // r32FLCtrl[0xCC/4]=0x55555555;
               * rFLCtrl[0xC0]=cBit4;
               * // break;
               */
        }
        else
        {
            ctrlErrInject(0x00, cErrInjectReadMode, 0x01, 0x30, 0xFFFF);
            /*   r32FLCtrl[0xC4/4]=0x00000000;
               * r32FLCtrl[0xC8/4]=0x00000000;
               * rFLCtrl[0xC0]=0;*/
        }
    }
#endif/* if _EN_TEST_RAID_DECODE */
#endif/* if _EN_RAID_DECODE */

    if(gEnableLdpcPipe)
    {
        gpFlashAddrInfo->uDmaCnt++;
        rmSetDmaId(gpFlashAddrInfo->uSrcIdx, gpFlashAddrInfo->uPlaneAddr);
    }

    rmRdData(uCount);

#if _ENABLE_RAID
    if(rmChkFshRaidFlag)
    {
        rmDisFshRaidFlag;
    }
#endif
}    /* setAutoRead */

void setAutoRead2(BYTE uCount, WORD u16Opt)
{
    if(u16Opt&c16Bit1)
    {
        rmRdDataAutoBuf;

#if _ENABLE_RAID
#if _EN_RAID_GC
        if((gOpTyp==cPreReadData)||(gOpTyp==cLastReadData)||(!gsGcInfo.uHmbEnGcCache&&((gOpTyp==cMoveReadData)||(u16Opt&cReadGcDesF2h))))
#else
        if((gOpTyp==cPreReadData)||(gOpTyp==cLastReadData))
#endif
        {
            rmEnFshRaidFlag;
        }
#endif
    }
    else
    {
        rmRdDataDisBuf;
    }

    rmSetStartSector(gSectorH);
#if _GREYBOX
    if(((gsGbInfo.uGreyBoxItem==cReadRetryDecodeTestID)||(gsGbInfo.uGreyBoxItem==cErrHdlReadUncInSlcDataID)\
        ||(gsGbInfo.uGreyBoxItem==cErrHdlReadUncInTlcDataID)||(gsGbInfo.uGreyBoxItem==cErrHdlProgWPROID))&&(gOpTyp==cHostReadData))
    {
        if(gErrInjectFlag&cBit0)
        {
            ctrlErrInject(0x10, cErrInjectReadMode, 0xFF, 0x30, 0xFFFF);    // erery Chunk Fail
            // gErrInjectFlag&=(~cBit0);
        }
        else
        {
            ctrlErrInject(0x00, cErrInjectReadMode, 0x01, 0x30, 0xFFFF);
        }
    }
    else if(gsGbInfo.uGreyBoxItem==cErrHdlGcFingerFailTestID)
    {
        if(gReadErrinjectEn&&(gErrInjectFlag&cBit0)&&(gOpTyp==cChkFingerFail))
        {
            ctrlErrInject(0x10, cErrInjectReadMode, 0xFF, 0x30, 0xFFFF);    // erery Chunk Fail
        }
        else
        {
            ctrlErrInject(0x00, cErrInjectReadMode, 0x01, 0x30, 0xFFFF);
        }
    }
    else if((gsGbInfo.uGreyBoxItem==cRAIDDecOnH2fTab))
    {
        if(gReadErrinjectEn&&(gErrInjectFlag&cBit0)&&((gOpTyp==cH2fReadTab)||(gOpTyp==cH2fRead1kTab)||(gOpTyp==cRaidDecRead)))
        {
            if((gPlaneAddr==(gPlaneNum-1))&&(gCh==(gTotalChNum-2))&&(gDieAddr==(gIntlvWay-1)))
            {
                ctrlErrInject(0x10, cErrInjectReadMode, 0x0C, 0x00, 0xFFFF);
            }
            else
            {
                ctrlErrInject(0x00, cErrInjectReadMode, 0x01, 0x30, 0xFFFF);
            }
        }
        else
        {
            ctrlErrInject(0x00, cErrInjectReadMode, 0x01, 0x30, 0xFFFF);
        }
    }
    else if((gsGbInfo.uGreyBoxItem==cRAIDDecOnH2f1kTab))
    {
        if(gReadErrinjectEn&&(gErrInjectFlag&cBit0)&&((gOpTyp==cH2fReadTab)||(gOpTyp==cH2fRead1kTab)||(gOpTyp==cRaidDecRead)))
        {
            if((gPlaneAddr==0)&&(gCh%4==0))
            {
                ctrlErrInject(0x10, cErrInjectReadMode, 0x30, 0x00, 0xFFFF);
            }
            else
            {
                ctrlErrInject(0x00, cErrInjectReadMode, 0x01, 0x30, 0xFFFF);
            }
        }
        else
        {
            ctrlErrInject(0x00, cErrInjectReadMode, 0x01, 0x30, 0xFFFF);
        }
    }
    else if((gsGbInfo.uGreyBoxItem==cRAIDDecOnNormData))
    {
        if(gReadErrinjectEn&&(gErrInjectFlag&cBit0)&&((gOpTyp==cHostReadData)||(gOpTyp==cRaidDecRead))&&
           (g16FPage>=((g16SlcPartialParityNum+cRaidParityNum)*(gTotalBankOfF2hTab)-cRaidParityNum)))
        {
            if((gPlaneAddr==0)&&(gCh==1)&&(gIntlvAddr==0))
            {
                ctrlErrInject(0x10, cErrInjectReadMode, 0x0C, 0x00, 0xFFFF);
            }
            else
            {
                ctrlErrInject(0x00, cErrInjectReadMode, 0x01, 0x30, 0xFFFF);
            }
        }
        else
        {
            ctrlErrInject(0x00, cErrInjectReadMode, 0x01, 0x30, 0xFFFF);
        }
    }
    else if((gsGbInfo.uGreyBoxItem==cRAIDDecOnOpenData))
    {
        if(gReadErrinjectEn&&(gErrInjectFlag&cBit0)&&((gOpTyp==cHostReadData)||(gOpTyp==cRaidDecRead)))
        {
            if((gPlaneAddr==0)&&(gCh==0)&&(gIntlvAddr==0))
            {
                ctrlErrInject(0x10, cErrInjectReadMode, 0x0C, 0x00, 0xFFFF);
            }
            else
            {
                ctrlErrInject(0x00, cErrInjectReadMode, 0x01, 0x30, 0xFFFF);
            }
        }
        else
        {
            ctrlErrInject(0x00, cErrInjectReadMode, 0x01, 0x30, 0xFFFF);
        }
    }
    else if((gsGbInfo.uGreyBoxItem==cRAIDDecOnPreReadData))
    {
        if(gReadErrinjectEn&&(gErrInjectFlag&cBit0)&&((gOpTyp==cPreReadData)||(gOpTyp==cRaidDecRead))&&(g16FPage<cRaidParityNum))
        {
            if((gPlaneAddr==0)&&(gCh==0)&&(gIntlvAddr==0))
            {
                ctrlErrInject(0x10, cErrInjectReadMode, 0x04, 0x00, 0xFFFF);
            }
            else
            {
                ctrlErrInject(0x00, cErrInjectReadMode, 0x01, 0x30, 0xFFFF);
            }
        }
        else
        {
            ctrlErrInject(0x00, cErrInjectReadMode, 0x01, 0x30, 0xFFFF);
        }
    }
    else if((gsGbInfo.uGreyBoxItem==cRAIDDecOnLastReadData))
    {
        if(gReadErrinjectEn&&(gErrInjectFlag&cBit0)&&((gOpTyp==cLastReadData)||(gOpTyp==cRaidDecRead))&&(g16FPage<cRaidParityNum))
        {
            if((gPlaneAddr==(gPlaneNum-1))&&(gCh==(gTotalChNum-1))&&(gIntlvAddr==(gIntlvWay-1)))
            {
                ctrlErrInject(0x10, cErrInjectReadMode, 0x80, 0x00, 0xFFFF);
            }
            else
            {
                ctrlErrInject(0x00, cErrInjectReadMode, 0x01, 0x30, 0xFFFF);
            }
        }
        else
        {
            ctrlErrInject(0x00, cErrInjectReadMode, 0x01, 0x30, 0xFFFF);
        }
    }
    else if((gsGbInfo.uGreyBoxItem==cRAIDDecOnMoveReadData))
    {
        if(gReadErrinjectEn&&(gErrInjectFlag&cBit0)&&((gOpTyp==cMoveReadData)||(gOpTyp==cRaidDecRead))&&(g16FPage<cRaidParityNum))
        {
            if((gPlaneAddr==0)&&(gCh==0)&&(gIntlvAddr==0))
            {
                ctrlErrInject(0x10, cErrInjectReadMode, 0x0C, 0x00, 0xFFFF);
            }
            else
            {
                ctrlErrInject(0x00, cErrInjectReadMode, 0x01, 0x30, 0xFFFF);
            }
        }
        else
        {
            ctrlErrInject(0x00, cErrInjectReadMode, 0x01, 0x30, 0xFFFF);
        }
    }
    else if((gsGbInfo.uGreyBoxItem==cSecurityRW)&&(gsGbInfo.uGreyBoxOpt&0x01)&&(gsGbInfo.uGreyBoxOpt&0x2))
    {
        if(gReadErrinjectEn&&(gErrInjectFlag&cBit0)&&((gOpTyp==cSecReadData)||(gOpTyp==cRaidDecRead))&&
           (g16FPage>=((g16SlcPartialParityNum+cRaidParityNum)*(gTotalBankOfF2hTab)-cRaidParityNum)))
        {
            if((gPlaneAddr==0)&&(gCh==1)&&(gIntlvAddr==0))
            {
                ctrlErrInject(0x10, cErrInjectReadMode, 0x0C, 0x00, 0xFFFF);
            }
            else
            {
                ctrlErrInject(0x00, cErrInjectReadMode, 0x01, 0x30, 0xFFFF);
            }
        }
        else
        {
            ctrlErrInject(0x00, cErrInjectReadMode, 0x01, 0x30, 0xFFFF);
        }
    }
    else
    {
        ctrlErrInject(0x00, cErrInjectReadMode, 0x01, 0x30, 0xFFFF);
    }
#endif/* if _GREYBOX */
    rmRdData(uCount);

#if _ENABLE_RAID
    if(rmChkFshRaidFlag)
    {
        rmDisFshRaidFlag;
    }
#endif
}    /* setAutoRead */

void setAutoAleReg(BYTE uPageSelCmd)
{
    if(gbLsbOnly)
    {
        if(mChkFLParam(cWithRlibMo))
        {
            rmSetPageAddr(g16FPage);
        }
        else if(mChkCardMode(cWithSlcMo))
        {
            rmSetPageAddr(g16FPage<<1);    // *2);
        }

        rmSetSeed(g16arSeedTable[g16FPage]);    // %c16PagePerSLC]);
    }
    else
    {
#if (_TSB_BiCS3|_SANDISK_3D_GEN2|_SANDISK_3D_GEN3|_TSB_BiCS4)
        rmSetPageAddr(g16FPage);
        rmSetSeed(g16arSeedTable[(cProgCntPerWL*g16FPage+uPageSelCmd-1)]);    // %c16PagePerTLC]);
#endif
    }

    rmSetSctrAddr(gSectorH);
}    /* setAutoAleReg */

void setAutoFBlock(BYTE uIntlvIdx, BYTE uPlaneIdx)
{
    if(g16FBlock==0xFFFF)
    {
        r16FLCtrl[rcBlock/2]=gsProgFailInfo.u16DiffPoolFBlk[uPlaneIdx];
    }
    else if(g16arDiffOffset[g16FBlock]!=0xffff)
    {
        if(mChkBitMask(g16arDiffOffset[g16FBlock], 0x0F))    // Tran Type2 to g16AbstrFBlock before setAutoFBlock
        {
            r16FLCtrl[rcBlock/2]=g16AbstrFBlock;
        }
        else
        {
            r16FLCtrl[rcBlock/2]=getDiffAddr(g16FBlock, gActiveCh, uIntlvIdx, uPlaneIdx);
        }
    }
    else
    {
        r16FLCtrl[rcBlock/2]=g16FBlock;
    }

    if(mChkCardMode(cMultiDie))
    {
        gDieAddr=mGetDieAddr(uIntlvIdx);    // for Erase Cmd
        rmSetDieBit(gDieAddr);
    }
}    /* setAutoFBlock */

// void chkTLCMoCmd(BYTE uWr)
// {
//    if(gbLsbOnly==0)
//    {
//        rmCle(mod(uWr, 3)+1);
//    }
// }

void setMultiPlaneRead()
{
    WORD u16FblockR=r16FLCtrl[rcBlock/2];
    BYTE uPlaneAddr;

    for(uPlaneAddr=0; uPlaneAddr<gPlaneNum; uPlaneAddr++)
    {
        setAutoFBlock(gIntlvAddr, uPlaneAddr);

        rmSetPlaneBit(uPlaneAddr);
#if (_TSB_BiCS3|_SANDISK_3D_GEN2|_SANDISK_3D_GEN3|_TSB_BiCS4)
        // chkTLCMoCmd((gPageSelCmd-1));
        if(gbLsbOnly==0)
        {
            // rmCle(((gPageSelCmd-1)%3)+1);
            if(!mChkFLParam(cWithPrimaryCmd))
            {
#if (_TSB_BiCS3|_SANDISK_3D_GEN2|_SANDISK_3D_GEN3|_TSB_BiCS4)
                rmCle(mGetPageSelCmd(gpFlashAddrInfo));
#endif
            }
            else
            {
                rmCle(mGetPageSelCmd(gpFlashAddrInfo));
            }
        }
#endif/* if (_TSB_BiCS3) */

        if(!mChkFLParam(cWithPrimaryCmd))
        {
            // chkTLCMoCmd(0);
            rmCle(gSecMPlaneReadCmd1);
            rmAle3;
        }
        else
        {
            rmCle(gPriMPlaneReadCmd1);
            rmAle5;

            if(uPlaneAddr<(gPlaneNum-1))
            {
                rmCle(gPriMPlaneReadCmd2);

                // pollStatus(cPollMaskNor);
                if(mChkCardMode(cMultiDie))
                {
                    rFLCtrl[rcStsFailMask]=0;
                    pollStatus(cBit6);
                }
                else
                {
                    rmCle(gReadStatusCmd);
                    rFLCtrl[rcStsFailMask]&=~cBit0;
                    rmRdStatus(cBit6);
                }
            }
        }
    }

#if _EN_CacheR
    if(g16RwOpt&c16Bit3)
    {
        // rmCle(gCacheReadCmd);
        rmCle(0x3C);
    }
    else
    {
        rmCle(gMulPlaneReadCmd2);
    }
#else
    rmCle(gMulPlaneReadCmd2);
#endif

    r16FLCtrl[rcBlock/2]=u16FblockR;
}    /* setMultiPlaneRead */

void setSinglePlaneRead(BYTE uHalf)
{
#if (_TSB_BiCS3|_SANDISK_3D_GEN2|_SANDISK_3D_GEN3|_TSB_BiCS4)
    // chkTLCMoCmd((gPageSelCmd-1));
    if(gbLsbOnly==0)
    {
        // rmCle(((gPageSelCmd-1)%3)+1);
        rmCle(mGetPageSelCmd(gpFlashAddrInfo));
    }
#endif
    rmCle(gPageReadCmd1);
    rmSetPlaneBit(gPlaneAddr);
    rmAle5;

    if(uHalf)
    {
        rmCle(cHalfReadCMD);
    }

#if _EN_CacheR
    else if(g16RwOpt&c16Bit3)
    {
        // rmCle(gCacheReadCmd);
        rmCle(0x3C);
    }
#endif
    else
    {
        rmCle(gPageReadCmd2);
    }
}    /* setSinglePlaneRead */

void setReadCmdAle(WORD u16Opt)
{
    chkRlibMoCmd();

    rmSelData;

    if(u16Opt&c16Bit0)
    {
        setMultiPlaneRead();
        // setAutoFBlock(gIntlvAddr, gPlaneAddr);
    }
    else
    {
        setSinglePlaneRead(0);
    }

    if(!(u16Opt&c16Bit9))
    {
        pollStatus(cPollMaskNor);
        rmCle(gReadMoCmd);
    }
}    /* setReadCmdAle */

#if (_TSB_BiCS3|_SANDISK_3D_GEN2|_SANDISK_3D_GEN3|_TSB_BiCS4)
#else
void setBitPerCell(BYTE uBit)
{
    BYTE uBkSctrReg=rFLCtrl[rcALE0];

    if(mChkCardMode(cMultiDie))
    {
        rmCle(0xD5);
        rmAle(gDieAddr);
    }
    else
    {
        rmCle(gSetFeatureCmd);
    }

    rmAle(cBpcFeatureAddr);
    rmNop(cTwhr);
    rFLCtrl[rcRd0]=uBit;
    rFLCtrl[rcRd1]=uBit;
    rFLCtrl[rcRd2]=1;
    rFLCtrl[rcRd3]=1;
    rFLCtrl[rcRd4]=0;
    rFLCtrl[rcRd5]=0;
    rFLCtrl[rcRd6]=0;
    rFLCtrl[rcRd7]=0;
    rmManWr(8);
    rmNop(cTwhr);
    pollStatus(cPollMaskNor);

    rFLCtrl[rcALE0]=uBkSctrReg;
}    /* setBitPerCell */

#endif/* if (_TSB_BiCS3|_SANDISK_3D_GEN2|_SANDISK_3D_GEN3|_TSB_BiCS4) */

void chkRlibMoCmd()
{
    if(mChkFLOption(cBpcOpCoCmd))
    {
        if(gbLsbOnly)    // temp solution to avoid SLC erasae and TLC program/read
        {
            if(mChkFLParam(cWithRlibMo|cWithSlcMo))    // cWithSlcMo ??
            {
                rmCle(gSlcMoAccessCmd);
                // rmNop(cTwhr);    // Wade suggestion
            }
        }
        else if(mChkFLParam(cWithRlibMo))
        {
            if(gSlcMoAbortCmd!=0xFF)
            {
                rmCle(gSlcMoAbortCmd);
                // rmNop(cTwhr);    // Wade suggestion
            }

            // else
            // {
            // while(gSlcMoAbortCmd); //gSlcMoAbortCmd = 0xFF ,should check!!
            // }
        }
    }
    else    // This is for SetFeature,Hynix and B0KB should not get here!!
    {
#if (_TSB_BiCS3|_SANDISK_3D_GEN2|_SANDISK_3D_GEN3|_TSB_BiCS4)
        // No SLC/TLC setFeature csae
        // It should not get here!!
#else
        if(gbLsbOnly)
        {
            setBitPerCell(cSetSlcMode);
        }
        else
        {
            setBitPerCell(mChkFLParam(cTlc)?cSetTlcMode:cSetMlcMode);
        }
#endif
    }
}    /* chkRlibMoCmd */

void trigProgSpare(WORD u16Opt)
{
    BYTE uSavePlane, uSprStr;

#if _EnSpareFunc
    if(!mChkTabSpr(gpFlashAddrInfo, cBit5|cBit6))
    {
        uSprStr=gSparePtrTail[gActiveCh];

        if((uSprStr&(cSpareRegisterCnt-1))<4)
        {
            rmSelSprGroup(0);
        }
        else
        {
            rmSelSprGroup(1);
        }

        uSavePlane=(uSprStr&cSprGrpMask);
        rmSetPlaneBit(uSavePlane);

#if cMultiplaneInSprSet
        if((gPlaneAddr==1)||(gPlaneAddr==3))
#endif
        {
            gSpareDesIdx[gActiveCh][(uSprStr&(cSpareRegisterCnt-1))]=gSrcIdx;    // for pcie write error
            gSparePtrTail[gActiveCh]=addPtrBy1(gSparePtrTail[gActiveCh], cSpareRegisterCnt);
        }
    }
    else if(mChkTabSpr(gpFlashAddrInfo, cBit6))
    {
        if((gSparePtrHead[gActiveCh]&(cSpareRegisterCnt-1))<4)
        {
            rmSelSprGroup(0);
        }
        else
        {
            rmSelSprGroup(1);
        }

        uSavePlane=(gSparePtrHead[gActiveCh]&cSprGrpMask);
        rmSetPlaneBit(uSavePlane);
    }
#endif/* if _EnSpareFunc */

    if(u16Opt&c16Bit4)
    {
#if (_TSB_BiCS3||_SANDISK_3D_GEN2||_SANDISK_3D_GEN3||_TSB_BiCS4)
        if(gbLsbOnly==0)
        {
            // James: according to Spec, Random Data In Command should issue page select previously. (Fixed by Rex)
            rmCle(mGetPageSelCmd(gpFlashAddrInfo));
        }
#endif
        rmCle(0x85);
        rmNop(cNopTcwaw);
        rmSprAle5;    // Change Write Column 2ALE
    }

    rmWrSpr;
    /*
       *  if(u16Opt&c16Bit4)
       *  {
       *      rmCle(0x85);
       *      rmNop(cNopTcwaw);
       * #if 1 //Sandisk MLC
       *      rmSprAle2; //Change Write Column 2ALE
       * #else
       *      rmSprAle5; //Change Write Column 5ALE
       * #endif
       *  }
       *  rmWrSpr;
       */
    // test end
}    /* trigProgSpare */

void setRandomoutCmd(BYTE uMultiPlane)
{
#if (_TSB_BiCS3|_SANDISK_3D_GEN2|_SANDISK_3D_GEN3|_TSB_BiCS4)
    rmCle(gRandomOutCmd1);
    rmSetPlaneBit(gPlaneAddr);
    rmAle5;
    rmCle(gRandomOutCmd2);
#endif
}    /* setRandomoutCmd */

void trigReadSpare(BYTE uMultiPlane)
{
    rmSelSpr;    // ctrlErrInject(0x02,cErrInjectReadMode,0x01,0x00,0x5AA5);
#if _GREYBOX
    if(((gsGbInfo.uGreyBoxItem==cReadRetryDecodeTestID)||(gsGbInfo.uGreyBoxItem==cErrHdlReadUncInSlcDataID)\
        ||(gsGbInfo.uGreyBoxItem==cErrHdlReadUncInTlcDataID)||(gsGbInfo.uGreyBoxItem==cErrHdlProgWPROID))&&(gOpTyp==cHostReadData))
    {
        if(gErrInjectFlag&cBit2)
        {
            ctrlErrInject(0x08, cErrInjectReadMode, 0xFF, 0x00, 0xFFFF);    // erery Chunk Fail
            gErrInjectFlag&=(~cBit2);
        }
        else
        {
            ctrlErrInject(0x00, cErrInjectReadMode, 0x01, 0x30, 0xFFFF);
        }
    }
    else if((gsGbInfo.uGreyBoxItem==cErrHdlGcFingerFailTestID)&&(gOpTyp==cChkFingerFail))
    {
        if(gErrInjectFlag&cBit2)
        {
            ctrlErrInject(0x08, cErrInjectReadMode, 0xFF, 0x00, 0xFFFF);    // erery Chunk Fail
            gErrInjectFlag&=(~cBit2);
        }
        else
        {
            ctrlErrInject(0x00, cErrInjectReadMode, 0x01, 0x30, 0xFFFF);
        }
    }
#endif/* if _GREYBOX */
    setRandomoutCmd(uMultiPlane);
    rmRdSpr;    // ctrlErrInject(0x00,cErrInjectReadMode,0x01,0x00,0x5AA5);
}    /* trigReadSpare */

void flashChangeDieCmd(BYTE uDie)
{
#if (_SANDISK_3D_GEN3)
    if(mChkCardMode(cMultiDie))
    {
        rmCle(0xF1+uDie);
    }
#endif
}    /* flashChangeDieCmd */

// -----------------------------------------------------------
// Bit0 - Multi-Plane Read
// Bit1 - Read Data Auto Buffer
// Bit2 - Random Out Only
// Bit3 - Cache Read
// Bit4 - Read Data
// Bit5 - Read Spare
// Bit6 - Buf Wrap
// Bit7 - Buf Wrap @ Write Buf
// Bit8 - Read Temp Register
// Bit9 - Pass Flash Busy
// Bit10 - pass Ecc fail MarkBad
// Bit11 - read cache F2h encode
// Bit12 - pass Data Out
// Bit13 - ignore dynamic read command
// Bit14 - set Vth = 0 after exiting Retry Flow and get its SLC Vth
// Bit15 - Pass Fifo Busy
// -----------------------------------------------------------
void flashReadPage()
{
    WORD u16Buf, u16Opt;
    BYTE uHalfKB, uOrgSectorH;

    u16Opt=mGetReadOpt;

    if(((u16Opt&(c16Bit2|c16Bit0))==c16Bit2)&&(!mChkCardMode(cMultiDie)))
    {
        if(gbLsbOnly)
        {
            rmSetSeed(g16arSeedTable[g16FPage]);
        }
        else
        {
            rmSetSeed(g16arSeedTable[(cProgCntPerWL*g16FPage+mGetPageSelCmd(gpFlashAddrInfo)-1)]);
        }

        rmSetSctrAddr(gSectorH);
    }
    else
    {
        setAutoFBlock(gIntlvAddr, gPlaneAddr);
        setAutoAleReg(mGetPageSelCmd(gpFlashAddrInfo));
    }

    rmCeOn(gCe);
    flashChangeDieCmd(gDieAddr);
#if _GREYBOX
    if(((gsGbInfo.uGreyBoxItem==cReadRetryDecodeTestID)||(gsGbInfo.uGreyBoxItem==cErrHdlReadUncInSlcDataID)\
        ||(gsGbInfo.uGreyBoxItem==cErrHdlReadUncInTlcDataID)||(gsGbInfo.uGreyBoxItem==cErrHdlProgWPROID))&&(gOpTyp==cHostReadData))
    {
        if(gReadErrinjectEn)
        {
            gErrInjectFlag=gsGbInfo.uGreyBoxOpt;

            if(gErrInjectFlag&0x80)
            {
                setTestRetryCmd();
            }
        }
    }
    else if((gsGbInfo.uGreyBoxItem==cErrHdlGcFingerFailTestID))
    {
        if(gReadErrinjectEn&&(gOpTyp==cChkFingerFail))
        {
            gErrInjectFlag=gsGbInfo.uGreyBoxOpt;
        }
    }
    else if((gsGbInfo.uGreyBoxItem==cRAIDDecOnH2fTab)||(gsGbInfo.uGreyBoxItem==cRAIDDecOnH2f1kTab))
    {
        if(gReadErrinjectEn&&((gOpTyp==cH2fReadTab)||(gOpTyp==cH2fRead1kTab)||(gOpTyp==cRaidDecRead)))
        {
            gErrInjectFlag=gsGbInfo.uGreyBoxOpt;
        }
    }
    else if((gsGbInfo.uGreyBoxItem==cRAIDDecOnNormData)||(gsGbInfo.uGreyBoxItem==cRAIDDecOnOpenData))
    {
        if(gReadErrinjectEn&&((gOpTyp==cHostReadData)||(gOpTyp==cRaidDecRead)))
        {
            gErrInjectFlag=gsGbInfo.uGreyBoxOpt;
        }
    }
    else if((gsGbInfo.uGreyBoxItem==cRAIDDecOnPreReadData))
    {
        if(gReadErrinjectEn&&((gOpTyp==cPreReadData)||(gOpTyp==cRaidDecRead)))
        {
            gErrInjectFlag=gsGbInfo.uGreyBoxOpt;
        }
    }
    else if((gsGbInfo.uGreyBoxItem==cRAIDDecOnLastReadData))
    {
        if(gReadErrinjectEn&&((gOpTyp==cLastReadData)||(gOpTyp==cRaidDecRead)))
        {
            gErrInjectFlag=gsGbInfo.uGreyBoxOpt;
        }
    }
    else if((gsGbInfo.uGreyBoxItem==cRAIDDecOnMoveReadData))
    {
        if(gReadErrinjectEn&&((gOpTyp==cMoveReadData)||(gOpTyp==cRaidDecRead)))
        {
            gErrInjectFlag=gsGbInfo.uGreyBoxOpt;
        }
    }
    else if((gsGbInfo.uGreyBoxItem==cSecurityRW)&&(gsGbInfo.uGreyBoxOpt&0x01)&&(gsGbInfo.uGreyBoxOpt&0x2))
    {
        if(gReadErrinjectEn&&((gOpTyp==cSecReadData)||(gOpTyp==cRaidDecRead)))
        {
            gErrInjectFlag=0x81;
        }
    }
    else
    {
        gErrInjectFlag=0x00;
    }
#endif/* if _GREYBOX */

#if _ENABLE_NAND_TestReadVth
    if(gErrInjectFlag==0x80)
    {
        setTestRetryCmd();
    }
#endif

    if(!(u16Opt&c16Bit2))
    {
        setReadCmdAle(u16Opt);
        gsRwCtrl.u16LastFBlockR[gCh][gIntlvAddr]=c16BitFF;
        gsRwCtrl.u16LastFPageR[gCh][gIntlvAddr]=c16BitFF;
    }

    gStartPlaneAddr=gPlaneAddr;

    if(u16Opt&c16Bit4)
    {
        u16Buf=mGetReadBuf;
        uHalfKB=mGetReadSctrCnt;
        uOrgSectorH=gSectorH;    // gOrgSectorH=gSectorH;
        mClrDmaCnt(gpFlashAddrInfo);

        while(uHalfKB>0)
        {
            setRandomoutCmd((BYTE)(u16Opt&c16Bit0));
            rmSetBufSAddr(u16Buf);

            if((gSectorH+uHalfKB)>gSectorPerPlaneH)
            {
                setAutoRead(gSectorPerPlaneH-gSectorH, u16Opt);

                if(u16Opt&c16Bit5)
                {
                    trigReadSpare((BYTE)(u16Opt&c16Bit0));    // for read retry flow
                }

                uHalfKB-=(gSectorPerPlaneH-gSectorH);
            }
            else
            {
                setAutoRead(uHalfKB, u16Opt);

                if(u16Opt&c16Bit5)
                {
                    if((gSectorH+uHalfKB)<gSectorPerPlaneH)
                    {
                        trigReadSpare((BYTE)(u16Opt&c16Bit0));
                    }
                    else
                    {
                        rmRdSpr;
                    }
                }

                break;
            }

            if(uHalfKB!=0)
            {
                if(u16Opt&c16Bit6)
                {
                    u16Buf=addReadBufPtr(u16Buf, gSectorPerPlaneH-gSectorH);
                }
                else
                {
                    u16Buf+=(gSectorPerPlaneH-gSectorH);
                }

                gSectorH=0;

                gPlaneAddr++;
                setAutoFBlock(gIntlvAddr, gPlaneAddr);
                setAutoAleReg(mGetPageSelCmd(gpFlashAddrInfo));

                if(!(u16Opt&c16Bit0))
                {
                    setReadCmdAle(0);
                }
            }
        }

        gSectorH=uOrgSectorH;
    }
    else if(u16Opt&c16Bit5)
    {
        trigReadSpare((BYTE)(u16Opt&c16Bit0));
    }

    rmAllCeOff;

    if(!(u16Opt&c16Bit15))
    {
        jdgReadRetry(gpFlashAddrInfo, 0);
    }
}    /* flashReadPage */

// -----------------------------------------------------------
// Bit0 - Multi-Plane Prog
// Bit1 - Write Data Auto Buffer
// Bit2 - Pass Flash Busy
// Bit3 - Cache Prog
// Bit4 - Prog Spare by Random In
// Bit5 - Pass Prog Spare
// Bit6 - Buf Wrap
// Bit7 - Buf Wrap @ Read Buf
// Bit8 - Pass Data In
// Bit9 - Prog F2H table step 1
// Bit10 - Prog F2H table step 2
// Bit11 - Prog Plane Raid
// Bit13 - Pseudo program
// Bit14 - One physical plane
// Bit15 - Pass Fifo Busy
// -----------------------------------------------------------
void flashProgPage(WORD u16Buf, BYTE uHalfKB, WORD u16Opt)
{
    // WORD u16F2hPadStartAddr_1;
    BYTE uSecNumPadF2h_1, uSecNumPadF2h_2;

    if(gbLsbOnly)
    {
        gsFtlDbg.u64TotalSlcProgCnt++;
        uSecNumPadF2h_1=gSlcSecNumPadF2h_1;
        uSecNumPadF2h_2=gSlcSecNumPadF2h_2;
        // u16F2hPadStartAddr_1=g16SlcF2hPadStartAddr_1;
    }
    else
    {
        gsFtlDbg.u64TotalTlcOneShotCnt++;
        uSecNumPadF2h_1=gTlcSecNumPadF2h_1;
        uSecNumPadF2h_2=gTlcSecNumPadF2h_2;
        // u16F2hPadStartAddr_1=g16TlcF2hPadStartAddr_1;
    }

    if(gBlkId==cGcDesBlockID)
    {
        u16Opt&=~(cProg16kF2H|cProg32kF2H);
    }
    else if(u16Opt&cProg16kF2H)
    {
        uHalfKB+=uSecNumPadF2h_1;
    }
    else if(u16Opt&cProg32kF2H)
    {
        uHalfKB+=uSecNumPadF2h_2;
    }

#if _ENABLE_RAID
    else if((gBlkId==cCacheBlockID)&&(u16Opt&cProgPlaneRaid))
    {
        uHalfKB+=cRaidDataSctrNum;
    }
#endif

#if _EnSpareFunc
    if(!mChkTabSpr(gpFlashAddrInfo, cBit5|cBit6))
    {
        if(gSpareCnt[gActiveCh]<mGetSprUseCnt(gpFlashAddrInfo))
        {
            gsFtlDbg.u16DummyFailType=cFlashProgPage;
            debugWhile();
        }
    }
#endif/* if _EnSpareFunc */

#if _EN_PROGFAILLOG
    if((gbLsbOnly==0)&&(gOpTyp!=cReProgData))
#else
    if(gbLsbOnly==0)
#endif
    {
        gPlaneAddr=0;
    }

    setAutoFBlock(gIntlvAddr, gPlaneAddr);
    setAutoAleReg((mGetPageSelCmd(gpFlashAddrInfo)));

    rmCeOn(gCe);
    flashChangeDieCmd(gDieAddr);
    chkRlibMoCmd();

#if (_TSB_BiCS3|_SANDISK_3D_GEN2|_SANDISK_3D_GEN3|_TSB_BiCS4)
    // chkTLCMoCmd(uIndex);
    if(!gbLsbOnly)
    {
        rmCle((mGetPageSelCmd(gpFlashAddrInfo)));
    }
#endif
    rmCle(gPageProgCmd1);    // 80h
    rmSetPlaneBit(gPlaneAddr);
    rmDataAle5;
    u16Buf=gpFlashAddrInfo->u16BufPtr;

    while((gPlaneAddr<gPlaneNum)&&(uHalfKB!=0))
    {
        rmSetBufSAddr(u16Buf);

        if((gSectorH+uHalfKB)>gSectorPerPlaneH)
        {
            if((u16Opt&c16Bit8)==0)
            {
                setAutoWrite(gSectorPerPlaneH-gSectorH, u16Opt);
            }

            uHalfKB-=(gSectorPerPlaneH-gSectorH);
        }
        else
        {
            if((u16Opt&c16Bit8)==0)
            {
                setAutoWrite(uHalfKB, u16Opt);
            }

            uHalfKB=0;
        }

        if(!(u16Opt&c16Bit5))
        {
            if(!(u16Opt&c16Bit8))
            {
                trigProgSpare(u16Opt);
            }
        }

        if(uHalfKB!=0)
        {
            gPlaneAddr++;
            gSectorH=0;

            if(u16Opt&c16Bit0)
            {
                setMultiPlaneProg(u16Opt, mGetPageSelCmd(gpFlashAddrInfo));
            }
            else
            {
                // single plane cmd
            }

            if(u16Opt&c16Bit6)
            {
                if(u16Opt&c16Bit7)
                {
                    u16Buf=addReadBufPtr(u16Buf, gSectorPerPlaneH);
                }
                else
                {
                    u16Buf=addWriteBufPtr(u16Buf, gSectorPerPlaneH);
                }
            }
            else
            {
                u16Buf+=gSectorPerPlaneH;
            }

            // only slc direct write case F2H from F2H Buffer
            if((u16Opt&cProg16kF2H)&&gbLsbOnly&&(uHalfKB==gSlcSecNumPadF2h_1))
            {
                u16Buf=g16SlcF2hPadStartAddr_1;
                u16Opt=u16Opt&(~(c16Bit1|c16Bit6));
            }

#if _ENABLE_RAID
            else if((u16Opt&cProgPlaneRaid)&&(gBlkId!=cGcDesBlockID)&&gbLsbOnly&&(uHalfKB==cRaidDataSctrNum))
            {
                u16Buf=c16ParitySIdx;
                u16Opt=u16Opt|c16Bit1&(~c16Bit6);
            }

#if _EN_RAID_H2F
            if((gBlkId==cH2fTableID)&&gbLsbOnly&&((gCh&((gTotalPlaneOfH2fTab/gPlaneNum)-1))==((gTotalPlaneOfH2fTab/gPlaneNum)-1))&&
               (gPlaneAddr==(gPlaneNum-1)))
            {
                if(!(u16Opt&c16Bit1))
                {
                    u16Opt=u16Opt|c16Bit1;
                }
            }
#endif
#endif/* if _ENABLE_RAID */
        }
    }

    if(gbLsbOnly)
    {
        if((u16Opt&c16Bit3)&&mChkFLOption(cEnCacheProg))
        {
            rmCle(gCacheProgCmd);
        }
        else
        {
            rmCle(gPageProgCmd2);
        }
    }
    else if(mGetPageSelCmd(gpFlashAddrInfo)==cMsbPreFixCmd)
    {
        if((u16Opt&c16Bit3)&&mChkFLOption(cEnCacheProg))
        {
            rmCle(gCacheProgCmd);
        }
        else
        {
            rmCle(cTLCProgCmd2);
        }
    }
    else
    {
        rmCle(cTLCProgCmd1);
        // rmCle(gReadStatusCmd);
        // rFLCtrl[rcStsFailMask]&=~cBit0;
        // rmRdStatus(cBit6);
    }

#if _GREYBOX
    chkGreyBoxStu();
#endif

    if(!(u16Opt&c16Bit2))
    {
        pollStatus(cPollMaskNor);
    }

    rmAllCeOff;

#if _EnSpareFunc
    if(mChkTabSpr(gpFlashAddrInfo, cBit5|cBit6))
    {
        gWaitSpareTyp[gActiveCh]=0xFF;
    }
    else if(gbLsbOnly)
    {
        gWaitSpareTyp[gActiveCh]=cSLCData;
    }
    else
    {
        gWaitSpareTyp[gActiveCh]=cTLCData;
    }
#endif

    if(gsRwCtrl.u16LastFBlockR[gCh][gIntlvAddr]!=cInvalid16Bit)
    {
        gsRwCtrl.u16LastFBlockR[gCh][gIntlvAddr]=cInvalid16Bit;
    }

    g16LastRdCntFBlock=cInvalid16Bit;
    g16LastRdCntFPage=cInvalid16Bit;

    if(!(u16Opt&c16Bit15))
    {
        waitCmdFifoDpt(gActiveCh, gpFlashAddrInfo);
        // gbProgramFail=?;
        rmResetEccSts;    // resetECC();
    }
}    /* flashProgPage */

void setMultiPlaneProg(WORD u16Opt, BYTE uPageSelCmd)
{
    rmCle(gMulPlaneProgCmd1);

    if(mChkCardMode(cMultiDie))
    {
        rFLCtrl[rcStsFailMask]=0;
        pollStatus(cBit6);
    }
    else
    {
        rmCle(gReadStatusCmd);
        rFLCtrl[rcStsFailMask]&=~cBit0;
        rmRdStatus(cBit6);
    }

    setAutoFBlock(gIntlvAddr, gPlaneAddr);
    rmSetPlaneBit(gPlaneAddr);

#if (_TSB_BiCS3|_SANDISK_3D_GEN2|_SANDISK_3D_GEN3|_TSB_BiCS4)
    // chkTLCMoCmd(uPageSelCmd);
    if(gbLsbOnly==0)
    {
        rmCle(uPageSelCmd);
    }
#endif

    if(u16Opt&c16Bit14)
    {
        rmCle(gPageProgCmd1);
    }
    else
    {
        rmCle(gMulPlaneProgCmd2);
    }

    // }
    // else
    // {
    // rmCle(cCopyBackProgCmd);
    // }

    rmAle5;
}    /* setMultiPlaneProg */

// flashErase
// Bit2 - Pass Flash Busy
// Bit3 - Reliable mode
// Bit10 - SanDisk Dummy Program
// Bit14 - one physical plane erase
// Bit15 - Pass Fifo Busy
void flashErase(WORD u16Opt)
{
    BYTE uIntlvAddr, uPlaneAddr;

#if (!_EN_EraseFail)
    rmDisStsFailStop;
#endif

    rmSetPageAddr(0x00);
    rmSetSctrAddr(0x00);
    rmResetEccSts;    // resetECC();

    if(!(u16Opt&c16Bit14))
    {
        gIntlvAddr=0;
        gPlaneAddr=0;
    }

    g16LastRdCntFBlock=cInvalid16Bit;
    g16LastRdCntFPage=cInvalid16Bit;

    for(uIntlvAddr=gIntlvAddr; uIntlvAddr<gIntlvWay; uIntlvAddr++)
    {
        rmCeOn(mGetCEAddr(uIntlvAddr));
        flashChangeDieCmd(mGetDieAddr(uIntlvAddr));

        // use TLC to erase
        if(mChkFLOption(cBpcOpCoCmd))
        {
            if(mChkFLParam(cWithRlibMo))
            {
                if(gSlcMoAbortCmd!=0xFF)
                {
                    rmCle(gSlcMoAbortCmd);
                    rmNop(cTwhr);    // Wade suggestion
                }
            }
        }
        else    // This is for SetFeature,Hynix and B0KB should not get here!!
        {
#if (_TSB_BiCS3|_SANDISK_3D_GEN2|_SANDISK_3D_GEN3|_TSB_BiCS4)
            // No SLC/TLC setFeature csae
            // It should not get here!!
#else
            setBitPerCell(mChkFLParam(cTlc)?cSetTlcMode:cSetMlcMode);
#endif
        }

        if(u16Opt&c16Bit3)
        {
            chkRlibMoCmd();
        }

        // if(mChkFLOption(cBpcOpCoCmd))
        // {
        // if(!(u16Opt&c16Bit13)&&((u16Opt&c16Bit14)||(mChkMlcSkipBit(g16FBlock)&&gbLsbOnly)))
        // {
        // if(mChkFLParam(cWithRlibMo|cWithSlcMo))
        // {
        // rmCle(gSlcMoAccessCmd);
        // rmNOP(cTwhr);
        // }
        // }
        // else
        // if(mChkFLParam(cWithRlibMo))
        // {
        // if(gSlcMoAbortCmd!=0xff)
        // {
        // rmCle(gSlcMoAbortCmd);
        // rmNop(cNopT_CWAW+cTwhr);
        // }
        // }
        // }
        /*else
           * {
           *  // if(!(u16Opt&c16Bit13)&&((u16Opt&c16Bit14)||(mChkMlcSkipBit(g16FBlock)&&gbLsbOnly)))
           *  // {
           *  //    setBitPerCell(cSetSlcMode);
           *  // }
           *  // else
           *  // {
           *  setBitPerCell(mChkFLParam(cTlc)?cSetTlcMode:cSetMlcMode);
           *  // }
           * }*/

#if 0    // _EN_DUMMYPROG
        if(u16Opt&c16Bit10)
        {
            rmCle(cDummyProgramCMD);
        }
#endif

        for(uPlaneAddr=gPlaneAddr; uPlaneAddr<gPlaneNum; uPlaneAddr+=1)
        {
            setAutoFBlock(uIntlvAddr, uPlaneAddr);

            rmCle(gBlockEraseCmd1);
            rmSetPlaneBit(uPlaneAddr);
            rmAle3;

            if((u16Opt&c16Bit14))
            {
                break;    // one physical plane erase
            }

#if 0    // 60->D1->60->D0
            if(uPlaneAddr<(gPlaneNum-1))
            {
                if(mChkFLParam(cWithPrimaryCmd)&&(gPriMPlaneEraseCmd2!=gBlockEraseCmd2))
                {
                    rmCle(gPriMPlaneEraseCmd2);
                    rmNop(30);    // temp use tWB=100ns
                    rmCle(gReadStatusCmd);
                    rFLCtrl[rcStsFailMask]&=~cBit0;
                    rmRdStatus(cBit6);
                }
            }
#endif
        }

        rmCle(gBlockEraseCmd2);
#if _GREYBOX
        chkGreyBoxStu();
#endif
        rmAllCeOff;
        setBzInfo(cEraseBlk, gActiveCh, uIntlvAddr);
        gsRwCtrl.u16LastFBlockR[gActiveCh][uIntlvAddr]=cInvalid16Bit;

        if((u16Opt&c16Bit14))
        {
            break;
        }
    }

    if(!(u16Opt&c16Bit2))
    {
        for(uIntlvAddr=0; uIntlvAddr<gIntlvWay; uIntlvAddr++)
        {
            if((u16Opt&c16Bit14))
            {
                uIntlvAddr=gIntlvAddr;
            }

            waitChCeBz(gActiveCh, uIntlvAddr, 0);

            if((u16Opt&c16Bit14))
            {
                break;
            }
        }
    }

    if(!(u16Opt&c16Bit15))
    {
        // waitCmdFifoDpt(gActiveCh, gpFlashAddrInfo);
        setFLActCh(gActiveCh);
        mWaitCmdFifoBz;
        gbEraseFail=rmChkStatusFail;
        rmResetEccSts;

#if (!_EN_EraseFail)
        rmEnStsFailStop;
        gbEraseFail=0;
#if _PWSample
        rmDisStsFailStop;
#endif
#endif
    }
}    /* flashErase */

// >>> merge 58xt IM3D
void flashDummyProgram(WORD u16Opt)
{
#if _EN_DUMMYPROG
    flashErase(u16Opt|c16Bit10);
#endif
}

// <<< merge 58xt IM3D

BYTE chkEraseStatus()
{
    BYTE uIntlvAddr, uEraseStatus;

    uEraseStatus=0;

    // if(gbLsbOnly)
    // {
    // rFLCtrl[rcStsFailMask]|=cBit0;
    // }

    for(uIntlvAddr=0; uIntlvAddr<gIntlvWay; uIntlvAddr++)
    {
        waitChCeBz(gActiveCh, uIntlvAddr, 0);
        mWaitCmdFifoBz;

        // for(uPlane=0; uPlane<gPlaneNum; uPlane+=1    /*gLogiPlaneNum*/)
        // {
#if _EN_GENERASEFAIL
        if((rmChkStatusFail)||((gErrInjectFlag&cBit3)&&(gActiveCh==3)&&(uIntlvAddr==1)))
        {
#if _EN_CHRONUS_UART_DEBUG
            NLOG(cLogCore1, FLASHCMD_C, 3, "Erase fail, Block=0x%04X, CH=0x%04X, CE=0x%04X",
                 getDiffFBlock(g16FBlock, gActiveCh, uIntlvAddr, gPlaneAddr),
                 gActiveCh, mGetCEAddr(uIntlvAddr));
#endif
            gErrInjectFlag=cBit0;
#else
        if(rmChkStatusFail)
        {
#if _EN_CHRONUS_UART_DEBUG
            NLOG(cLogCore1, FLASHCMD_C, 3, "Erase fail, Block=0x%04X, CH=0x%04X, CE=0x%04X",
                 getDiffFBlock(g16FBlock, gActiveCh, uIntlvAddr, gPlaneAddr),
                 gActiveCh, mGetCEAddr(uIntlvAddr));
#endif
            // REX
#if 1
            g16EccFailChAndCe=((gActiveCh<<8)|mGetCEAddr(uIntlvAddr));
            g16EccFailDieAndPlane=((mGetDieAddr(uIntlvAddr)<<8)|gPlaneAddr);

            if(g16arDiffOffset[g16FBlock]!=0xffff)
            {
                g16EccFailBlkAddr=getDiffAddr(g16FBlock, gActiveCh, uIntlvAddr, 0);
            }
            else
            {
                g16EccFailBlkAddr=g16FBlock;
            }

            g16EccFailBlkAddr=0;
            g16EccFailPageAddr=0;
            g16EccFailRegInfo=((rFLCtrl[rcEccResultSts]<<8)|rFLCtrl[rcOnceCntstatus]);    // 0x118 & 0x11D
            g16EccFailChunkBitMap=0;    // g16DebugLastFailChunkBitMap
            updateLogNandQueue();
#endif/* if 1 */
#endif/* if _EN_GENERASEFAIL */
            //
            gsFtlDbg.u16EraseFailCount++;
            rmResetEccSts;    // Status fail can happen in both plane
            rmCmdQueResume;
            sysDelay(16);    // wait cmd fifo resume
            uEraseStatus|=(cBit0<<uIntlvAddr);
            mWaitCmdFifoBz;
        }

        // }
    }

#if (!_EN_EraseFail)
    rmEnStsFailStop;
    uEraseStatus=0;
#if _PWSample
    rmDisStsFailStop;
#endif
#endif

    return uEraseStatus;
}    /* chkEraseStatus */

void setTsb1SectorPatternForDebug(WORD u16X, WORD u16Y)
{
    WORD u16SecIndex;

    for(u16SecIndex=0; u16SecIndex<c16WriteBufSize; u16SecIndex++)
    {
        g16arTsb0[u16SecIndex][0]=u16SecIndex;
        g16arTsb0[u16SecIndex][1]=0x5354;
        g16arTsb0[u16SecIndex][7]=u16X;
        g16arTsb0[u16SecIndex][8]=u16Y;
        g16arTsb0[u16SecIndex][254]=u16SecIndex;
        g16arTsb0[u16SecIndex][255]=0x4544;
    }
}

void getFeatureByChCeDie(BYTE uCh, BYTE uCe, BYTE uDieIndex, BYTE uAddr)
{
    BYTE uPlaneRegBackUp;
    WORD u16BlkRegBackUp;

    setFLActCh(uCh);
    uPlaneRegBackUp=rFLCtrl[rcPlaneSel];
    u16BlkRegBackUp=r16FLCtrl[rcBlock/2];
#if _ENABLE_NAND_UART_DEBUG
    r32FLCtrl[rcRd0/4]=0x55667788;
    NLOG(cLogCore1,
         FLASHCMD_C,
         4,
         "getFeatureByChCeDie()->uCh: 0x%04X ,uCe: 0x%04X uDieIndex: 0x%04X uAddr: 0x%04X ",
         (uCh),
         (uCe),
         (uDieIndex),
         (uAddr));
#endif
    rmCeOn(uCe);
    rmCle(0xD4);
    rmAle(uDieIndex);
    rmAle(uAddr);
    rmNop(0x10);

    while(rmChkCmdFifoBz)
        ;

    rmCle(0x70);
    rmStsFailMask(0x00);
    rmRdStatus(0x60);

    while(rmChkCmdFifoBz)
        ;

#if _ENABLE_NAND_UART_DEBUG
    NLOG(cLogCore1, FLASHCMD_C, 0, "## Read Status Ready!!##");
#endif

    if(rmChkToggleMo||rmChkOnfi2Mo)
    {
        rmCle(0x00);
        rmManRd(4);

        while(rmChkCmdFifoBz)
            ;

#if _ENABLE_NAND_UART_DEBUG
        NLOG(cLogCore1,
             FLASHCMD_C,
             4,
             "Toggle Read 4 byte ->P0: 0x%04X ,P1: 0x%04X P2: 0x%04X P3: 0x%04X ",
             (rFLCtrl[rcRd0]),
             (rFLCtrl[rcRd2]),
             (rFLCtrl[rcRd4]),
             (rFLCtrl[rcRd6]));
#endif
    }
    else
    {
        rmCle(0x00);
        rmManRd(1);

        while(rmChkCmdFifoBz)
            ;

#if _ENABLE_NAND_UART_DEBUG
        NLOG(cLogCore1, FLASHCMD_C, 1, "SDR Read 1 byte ->P0: 0x%04X ", (rFLCtrl[rcRd0]));
#endif
        rmManRd(1);

        while(rmChkCmdFifoBz)
            ;

#if _ENABLE_NAND_UART_DEBUG
        NLOG(cLogCore1, FLASHCMD_C, 1, "SDR Read 1 byte ->P1: 0x%04X ", (rFLCtrl[rcRd0]));
#endif
        rmManRd(1);

        while(rmChkCmdFifoBz)
            ;

#if _ENABLE_NAND_UART_DEBUG
        NLOG(cLogCore1, FLASHCMD_C, 1, "SDR Read 1 byte ->P2: 0x%04X ", (rFLCtrl[rcRd0]));
#endif
        rmManRd(1);

        while(rmChkCmdFifoBz)
            ;

#if _ENABLE_NAND_UART_DEBUG
        NLOG(cLogCore1, FLASHCMD_C, 1, "SDR Read 1 byte ->P3: 0x%04X ", (rFLCtrl[rcRd0]));
#endif
    }

    rmCeOff(uCe);
    rFLCtrl[rcPlaneSel]=uPlaneRegBackUp;
    r16FLCtrl[rcBlock/2]=u16BlkRegBackUp;
}    /* getFeatureByChCeDie */

#if (_EN_SLC_END_PARA)
BYTE getParaSlcEndurance(BYTE uCh, BYTE uCe, BYTE uDie)
{
    BYTE uDefaultVal;

#if 0
#else
    // Wait LITEON TSB SP cmd for getParaSlcEndurance
    uDefaultVal=0xFF;

    while(uDefaultVal)
        ;
#endif
    return uDefaultVal;
}    /* getParaSlcEndurance */

void setParaSlcEndurance(BYTE uCh, BYTE uCe, BYTE uDie, BYTE uParaEndurance)
{
#if 0
    // Wait LITEON TSB SP cmd for getParaSlcEndurance
#endif
}    /* setParaSlcEndurance */

void setSlcEndurPara()
{
    BYTE uCh, uCe, uIntlvAddr, uDie, uDefaultVal;

    for(uIntlvAddr=0; uIntlvAddr<gIntlvWay; uIntlvAddr++)
    {
        for(uCh=0; uCh<gTotalChNum; uCh++)
        {
            uCe=mGetCEAddr(uIntlvAddr);
            uDie=mGetDieAddr(uIntlvAddr);

            uDefaultVal=getParaSlcEndurance(uCh, uCe, uDie);

            if(g32SlcMaxEraseCnt<5000)
            {
                gsCacheInfo.u32SlcNextEraseCntThr=5000;
            }
            else if((g32SlcMaxEraseCnt>=5000)&&(g32SlcMaxEraseCnt<10000))
            {
                gsCacheInfo.u32SlcNextEraseCntThr=10000;
                uDefaultVal-=2;
            }
            else if((g32SlcMaxEraseCnt>=10000)&&(g32SlcMaxEraseCnt<20000))
            {
                gsCacheInfo.u32SlcNextEraseCntThr=20000;
                uDefaultVal-=4;
            }
            else if((g32SlcMaxEraseCnt>=20000)&&(g32SlcMaxEraseCnt<30000))
            {
                gsCacheInfo.u32SlcNextEraseCntThr=30000;
                uDefaultVal-=5;
            }
            else if((g32SlcMaxEraseCnt>=30000)&&(g32SlcMaxEraseCnt<40000))
            {
                gsCacheInfo.u32SlcNextEraseCntThr=40000;
                uDefaultVal-=6;
            }
            else if((g32SlcMaxEraseCnt>=40000))
            {
                gsCacheInfo.u32SlcNextEraseCntThr=0xFFFFFFFF;
                uDefaultVal-=8;
            }

            setParaSlcEndurance(uCh, uCe, uDie, uDefaultVal);
        }
    }
}    /* setSlcEndurPara */

#endif/* if (_EN_SLC_END_PARA) */

#if _EN_FLASH_WR_CMD

void flashWriteCmd(WORD u16Fblock)
{
#if 0
#else
    // Wait LITEON TSB SP cmd for Dummay program blk
#endif
}    /* flashWriteCmd */

#endif/* if _EN_FLASH_WR_CMD */

void setFlashFeatureForInterface(WORD u16FlashClk, BYTE uP0, BYTE uP1, BYTE uP2, BYTE uP3)
{
    BYTE uCh, uCe;

#if _ENABLE_NAND_UART_DEBUG
    NLOG(cLogCore1,
         FLASHCMD_C,
         3,
         "setFlashFeatureForInterface()->u16FlashClk: 0x%04X ,g16FlashClkForThermal: 0x%04X g16FlashClock: 0x%04X ",
         (u16FlashClk),
         (g16FlashClkForThermal),
         (g16FlashClock)
         );
#endif

    // SetFeatrue
    for(uCh=0; uCh<gTotalChNum; uCh++)
    {
        for(uCe=0; uCe<gTotalCeNum; uCe++)
        {
#if (_SANDISK_3D_GEN2||_SANDISK_3D_GEN3)
            setFeatureByChCe(uCh, uCe, 0x80, uP0, uP1, uP2, uP3, cNoWait);
#endif
#if (_TSB_BiCS3||_TSB_BiCS4)
            if(mChkFLParam(cManToTogMo))
            {
                // Only For Liteon BiCS3
                // getFeatureByChCeDie(uCh, uCe, 0x00, 0x80);
                if(g16FlashClkForThermal==38)
                {
                    // For PS4 return to Power ON
                    setFeatureByChCe(uCh, uCe, 0x80, 0x01, 0x00, 0x00, 0x00, cNoWait);
                }
                else
                {
                    setFeatureByChCe(uCh, uCe, 0x80, 0x00, 0x00, 0x00, 0x00, cNoWait);
                }
            }
            else
            {
                // setFeatureByChCe(uCh, uCe, 0x80, 0x00, 0x00, 0x00, 0x00, cNoWait);
            }
#endif/* if (_TSB_BiCS3) */
        }
    }

    waitAllFlashReady();

    setFlashClock(u16FlashClk);

//    if(u16FlashClk>=40)
//    {
    setBusDiff();          // LeverYu_20190723 Enable SOC Diff mode for all FlashClk setting
//    }
//    else
//    {
//        setBusToggleMode();
//    }

#if (_TSB_BiCS3||_TSB_BiCS4)
    if(g16FlashClkForThermal==38)
    {
        if(mChkFLParam(cManToTogMo))
        {
            setBusEdoMode();
        }
        else
        {
            setBusToggleMode();
            rmDfDdrSet(0x00);
            rmDdrDis;
        }
    }
#endif
//
#if 1
    while(rmChkCmdFifoBz)
        ;

    while(rmChkCmdFifoStsFull)
        ;

    while(rmChkLdpcDmaSt)
        ;

    while(rmChkSysCmdFifoBz)
        ;

    while(rmChkLdpcReady)
        ;
#endif
//
    setFlashDrv();
    setSelMulFL(1);
    setFlashRWDelayTime(u16FlashClk);
    rmSetDqsPreamble(rmGetTwhr2-rmGetTpre);
    rmEnAleCleDoubleCycle;
    rmEnACle2Cycle;
    setSelMulFL(0);
    setFlashDllAdj();
//
#if 1
    while(rmChkCmdFifoBz)
        ;

    while(rmChkCmdFifoStsFull)
        ;

    while(rmChkLdpcDmaSt)
        ;

    while(rmChkSysCmdFifoBz)
        ;

    while(rmChkLdpcReady)
        ;
#endif

//
    for(uCh=0; uCh<gTotalChNum; uCh++)
    {
        for(uCe=0; uCe<gTotalCeNum; uCe++)
        {
#if (_SANDISK_3D_GEN2||_SANDISK_3D_GEN3)
            getFeatureByChCeDie(uCh, uCe, 0x00, 0x80);
#endif
#if (_TSB_BiCS3|_TSB_BiCS4)
            if(mChkFLParam(cManToTogMo))
            {
                getFeatureByChCeDie(uCh, uCe, 0x00, 0x80);
            }

            getFeatureByChCeDie(uCh, uCe, 0x00, 0x10);
            getFeatureByChCeDie(uCh, uCe, 0x00, 0x02);
#endif
        }
    }

#if _ENABLE_NAND_UART_DEBUG
    NLOG(cLogCore1, FLASHCMD_C, 0, "## setFlashFeatureForInterface End ##");
#endif
}    /* setFlashFeatureForInterface */

/*
   * void addReadOpIdex(BYTE uCh)
   * {
   *  rmAddOPIndex;    // addChOpIndex(uCh);
   *  gsRwCtrl.uOpIdxSerial[uCh]++;
   *  gpFlashAddrInfo->uOpIdxSerial=gsRwCtrl.uOpIdxSerial[uCh];
   *  gsRwCtrl.uOpIdxAccCntR[uCh]++;
   *  gsRwCtrl.uAllOpIdxCntR++;
   * }
   */

void addProgOpIdex(BYTE uCh)
{
    rmAddOPIndex;    // addChOpIndex(uCh);
    gsRwCtrl.uOpIdxSerial[uCh]++;
    gpFlashAddrInfo->uOpIdxSerial=gsRwCtrl.uOpIdxSerial[uCh];
    gsRwCtrl.uOpIdxAccCntW[uCh]++;
}    /* addProgOpIdex */

void setBzInfo(BYTE uWaitFlag, BYTE uCh, BYTE uIntlvAddr)
{
    gsRwCtrl.usWaitInfo[uCh][uIntlvAddr].uWaitFlag=uWaitFlag;
#if _EN_PROGFAILLOG
    gsRwCtrl.usWaitInfo[uCh][uIntlvAddr].u16FBlock=g16FBlock;
    gsRwCtrl.usWaitInfo[uCh][uIntlvAddr].u16FPage=g16FPage;
#endif
}

void waitChCeBz(BYTE uCh, BYTE uIntlvAddr, BYTE uRdyTyp)
{
    BYTE uWaitFlag=gsRwCtrl.usWaitInfo[uCh][uIntlvAddr].uWaitFlag;
    BYTE uStsFailBit;

    if(uWaitFlag!=cNoOp)
    {
        if((uWaitFlag<=cProgData))    // ||(uWaitFlag==cReadCmdAle))
        {
            rmCeOn(mGetCEAddr(uIntlvAddr));

            if(mChkCardMode(cMultiDie))
            {
                rmSetDieBit(mGetDieAddr(uIntlvAddr));
                r16FLCtrl[rcBlock/2]=0;
                r16FLCtrl[rcPage/2]=0;
                rFLCtrl[rcPlaneSel]&=0xFC;
            }

#if _EN_PROGFAILLOG
            if((uWaitFlag!=cReadCmdAle)&&(uWaitFlag!=cCacheRCmd))
            {
                r16FLCtrl[rcBlock/2]=gsRwCtrl.usWaitInfo[uCh][uIntlvAddr].u16FBlock;
                r16FLCtrl[rcPage/2]=gsRwCtrl.usWaitInfo[uCh][uIntlvAddr].u16FPage;
                // rFLCtrl[rcPlaneSel]&=0xFC;
                // rFLCtrl[rcPlaneSel]|=uPlaneAddr;
                rFLCtrl[rcSec]|=(uIntlvAddr<<5);
                rmAle3;
            }
#endif

            if(mChkMlcMoBit(gsRwCtrl.usWaitInfo[uCh][uIntlvAddr].u16FBlock))
            {
                uStsFailBit=(cBit0|cBit1);    // TLC
            }
            else
            {
                uStsFailBit=(cBit2|cBit3);    // SLC
            }

            if(uWaitFlag==cEraseBlk)
            {
                rFLCtrl[rcStsFailMask]|=uStsFailBit;
            }
            else
            {
#if _EN_PROGFAILLOG
                if(!gsRwCtrl.usWaitInfo[uCh][uIntlvAddr].uStatusErrStop)
                {
                    rFLCtrl[rcStsFailMask]&=~(cBit0|cBit1|cBit2|cBit3);
                }
                else
                {
                    rFLCtrl[rcStsFailMask]|=uStsFailBit;
#if _GREYBOX
                    if((gsGbInfo.uGreyBoxItem&0x30)==0x30)
                    {
                        WORD u16FBlock=gsRwCtrl.usWaitInfo[uCh][uIntlvAddr].u16FBlock;
                        WORD u16FPage=gsRwCtrl.usWaitInfo[uCh][uIntlvAddr].u16FPage;
                        BYTE uGbSetProgFail=cFalse;

                        if((u16FPage==g16GbSetPgFailFpage)&&(uCh==gGbSetPgFailCh)&&(uIntlvAddr==gGbSetPgFailIntlvAddr))
                        {
                            if((gsGbInfo.uGreyBoxItem==cErrHdlProgCacheBlk)&&(u16FBlock==gsCacheInfo.u16ActiveCacheBlock))
                            {
                                uGbSetProgFail=cTrue;
                            }
                            else if((gsGbInfo.uGreyBoxItem==cErrHdlProgCacheBlk)&&(u16FBlock==gsCacheInfo.u16FluCacheBlock)&&
                                    (g16PagePerBlock1_SLC==(g16GbSetPgFailFpage+1)))
                            {
                                uGbSetProgFail=cTrue;
                            }
                            else if((((gsGbInfo.uGreyBoxItem==cErrHdlProgS2TGcDesID)&&(mGetGcFlow==cGcFlowS2T))||
                                     ((gsGbInfo.uGreyBoxItem==cErrHdlProgT2TGcDesID)&&(mGetGcFlow==cGcFlowT2T))||
                                     ((gsGbInfo.uGreyBoxItem==cErrHdlProgS2SGcDesID)&&(mGetGcFlow==cGcFlowS2S)))
                                    &&(u16FBlock==gsGcInfo.u16GcDesBlock)&&(!(gGbSetPgFailCase&cBit7)))
                            {
                                uGbSetProgFail=cTrue;
                                gGbSetPgFailCase|=cBit7;
                            }
                            else if((gsGbInfo.uGreyBoxItem==cErrHdlProgH2fTableID)&&
                                    (u16FBlock==g16arH2fTabBlk[gsCacheInfo.uActH2fTabBlkIdx]))
                            {
                                uGbSetProgFail=cTrue;
                            }
                            else if((gsGbInfo.uGreyBoxItem==cErrHdlProgWPROID)&&(u16FBlock==gsWproInfo.u16arWproBlk[gsWproInfo.uActIdx]))
                            {
                                uGbSetProgFail=cTrue;
                            }

                            if(uGbSetProgFail)
                            {
                                g16GbGetPgFailFblk=u16FBlock;
                                g16GbGetPgFailFblkNowDiffFblk=getDiffAddr(g16GbGetPgFailFblk,
                                                                          gGbSetPgFailCh,
                                                                          gGbSetPgFailIntlvAddr,
                                                                          gGbSetPgFailPlane);
                                rFLCtrl[rcStsFailMask]|=(cBit2|cBit5);
                            }
                        }
                    }
#endif/* if _GREYBOX */
                }
#else/* if _EN_PROGFAILLOG */
                rFLCtrl[rcStsFailMask]&=~(cBit0|cBit1|cBit2|cBit3);
#endif/* if _EN_PROGFAILLOG */
            }

            if(uWaitFlag==cCacheRCmd)
            {
                if(uRdyTyp==1)
                {
                    pollStatus(cBit6);
                }
                else
                {
                    pollStatus(cPollMaskNor);
                }

                rmCle(gReadMoCmd);
            }
            else if((uWaitFlag==cCacheRCmd1))
            {
#if (_SANDISK_3D_GEN3)
                rmCle(0xF1+rmGetDieBit());
#else
                rmCle(gReadStatusEnhCmd);
                rmNop(5);
                rmAle3;
#endif
                rmCle(gLastPageCacheReadCmd);
                pollStatus(cBit6);    // pollStatus(cPollMaskNor);
                rmCle(gReadMoCmd);
            }

#if _EN_MutiWayCacheRImprove
            else if(uWaitFlag==cCache3FCmd)
            {
                pollStatus(cBit6);
                rmCle(gReadMoCmd);
            }
#endif
            else
            {
                if(!mChkFLOption(cEnCacheProg))
                {
                    pollStatus(cPollMaskNor);
                }
                else
                {
                    if(uRdyTyp&&(uWaitFlag==cCacheProgData))
                    {
                        pollStatus(cBit6);
                    }
                    else
                    {
                        pollStatus(cPollMaskNor);
                    }
                }
            }

#if _GREYBOX
            if(rFLCtrl[rcStsFailMask]&cBit5)
            {
                rFLCtrl[rcStsFailMask]&=~(cBit2|cBit5);
            }
#endif
            rmAllCeOff;
        }

        gsRwCtrl.usWaitInfo[uCh][uIntlvAddr].uWaitFlag=cNoOp;
        gsRwCtrl.usWaitInfo[uCh][uIntlvAddr].uStatusErrStop=0;
    }
}    /* waitChCeBz */

void waitAllFlashReady()
{
    WORD u16WaitCnt=0;

    rmEnFrbMode;
    rmFrbPullUp;

    while(((!rmFrb)&&u16WaitCnt<10000))    // ??
    {
        // Chk RB Ready for All Ch in GPIO0.bit7
        sysDelay(600);    // 10 us sec tick for 200MHz system clock
        u16WaitCnt++;
    }
}

void waitAllChCeBz()
{
    BYTE uCh, uIntlvAddr;

    if(gEnableLdpcPipe)
    {
        while(g16LdpcDmaIdCnt)
        {
            chkLdpcResult(cLdpcNormalErr);
        }
    }

    for(uIntlvAddr=0; uIntlvAddr<gIntlvWay; uIntlvAddr++)
    {
        for(uCh=0; uCh<gTotalChNum; uCh++)
        {
            setFLActCh(uCh);
            waitChCeBz(uCh, uIntlvAddr, 0);
        }
    }

    if(gEnableLdpcPipe)
    {
        while(rmChkSysCmdFifoBz||rmChkSysStsErr)
        {
            for(uCh=0; uCh<gTotalChNum; uCh++)
            {
                setFLActCh(uCh);
#if _EN_PROGFAILLOG
                chkStatusFail(uCh);
#endif
            }
        }
    }
    else
    {
        while(rmChkSysCmdFifoBz||rmChkSysUNC||rmChkSysStsErr)
        {
            for(uCh=0; uCh<gTotalChNum; uCh++)
            {
                setFLActCh(uCh);
#if _EN_PROGFAILLOG
                chkStatusFail(uCh);
#endif

                while(rmChkUNC)
                {
                    chkEccFail(uCh);
                }
            }
        }
    }
}    /* waitAllChCeBz */

#if 0
void waitFifoOpIdx(BYTE uFifoThr, BYTE uBzBitMap)
{
    BYTE uCh;

    for(uCh=0; uCh<gTotalChNum; uCh++)
    {
        if(mChkBitMask(uBzBitMap, uCh))
        {
            setFLCtrlCh(uCh);
            waitCmdFifoDpt(uCh, gpFlashAddrInfo);
        }
    }
}

#endif

#if (!_ENABLE_SRC_LINK_LIST)
void rstFifoTailPtrR()
{
    while(gsRwCtrl.uReadFifoTail!=gsRwCtrl.uReadFifoTrig)
    {
        ADDRINFO *upAddrInfo=&garSrcAddrInfo[gsRwCtrl.uReadFifoTail];

        if(upAddrInfo->uAddrOpt&cDone)    // ubDone)
        {
            // if(!(gsPrdInfo.uarPrdQue[upAddrInfo->uPrdPtr].uPrdOpF&cQRdCmd))
            // {
            // if((upAddrInfo->uOpTyp==cHostReadData)||(upAddrInfo->uOpTyp==cHdmaDummy))
            // {
            // gsRwCtrl.u32ReadAheadLbaN+=upAddrInfo->uRwHalfKb;
            // }
            // }

            gsRwCtrl.uReadFifoTail=addRdFfPtrBy1(gsRwCtrl.uReadFifoTail);
            gsRwCtrl.uSrcCmdFifoCnt--;
        }
        else
        {
            break;
        }
    }
}    /* rstFifoTailPtrR */

#endif/* if !_ENABLE_SRC_LINK_LIST */

/*
   * void rstFifoTailPtrW()
   * {
   *  while(gsRwCtrl.uProgFifoTail!=gsRwCtrl.uProgFifoTrig)
   *  {
   *      ADDRINFO *upAddrInfo=&garDesAddrInfo[gsRwCtrl.uProgFifoTail];
   *
   *      if(upAddrInfo->uAddrOpt&cDone)
   *      {
   *          gsRwCtrl.uProgFifoTail=addWrFfPtrBy1(gsRwCtrl.uProgFifoTail);
   *          // gsRwCtrl.uProgFifoCnt--;
   *      }
   *      else
   *      {
   *          break;
   *      }
   *  }
   * }
   */

void chkReadState(ADDRINFO *upAddrInfo)
{
    BYTE uOpTyp, uPrdPtr, uTsbCnt, uTsbIdx;
    PRDQUEUE *upPrdInfo;

    uOpTyp=upAddrInfo->uOpTyp;
    uPrdPtr=upAddrInfo->uPrdPtr;
    uTsbCnt=upAddrInfo->uPlaneCnt;
    uTsbIdx=upAddrInfo->uTsb4kIdx;

    if((uOpTyp==cHostReadData)||(uOpTyp==cHdmaDummy))
    {
        upPrdInfo=&gsPrdInfo.uarPrdQue[uPrdPtr];

        if(upPrdInfo->ubQRdCmd&&mChkQRead(upAddrInfo))
        {
            upPrdInfo->u16RestQRd4kCnt-=upAddrInfo->uPlaneCnt;
            mClrQRead(upAddrInfo);

            if(!upPrdInfo->u16RestQRd4kCnt)
            {
                gsRwCtrl.uarTrigHostPrd[gsRwCtrl.u32TrigHostHead]=uPrdPtr;
                gsRwCtrl.u32TrigHostHead=(gsRwCtrl.u32TrigHostHead+1)&(cPrdDepth-1);
            }
        }
    }
    else if(uOpTyp==cH2fRead1kTab)
    {
#if _ENABLE_E2E_TAB
        chkReadTableCrcCnt(upAddrInfo);
#endif
        gsRwCtrl.uarH2fSgmtRdyQ[gsRwCtrl.u32H2fSgmtRdyHead]=uPrdPtr;
        gsRwCtrl.u32H2fSgmtRdyHead=(gsRwCtrl.u32H2fSgmtRdyHead+1)&(cH2fSgmtRdyDept-1);
    }

    if(uTsbIdx!=0xFF)
    {
        while(1)
        {
            garReadBufOrderTail[uTsbIdx]++;
            uTsbCnt--;

            if(!uTsbCnt)
            {
                break;
            }

            uTsbIdx=(uTsbIdx==(c16ReadBufSize4K-1))?0:(uTsbIdx+1);
        }
    }
}    /* chkReadState */

void chkLdpcResult(BYTE uMode)
{
    BYTE uSrcIdx, uCh;
    volatile LINKINFO *upDelLlInfo;
    WORD u16PrevNodeIdx, u16NextNodeIdx, u16DmaId;
    ADDRINFO *upAddrInfo;

/*
   *  LWORD u32FreeSrcFifoTail;
   */

    while(g16LdpcDmaIdCnt&&rmChkLdpcInfoFifoReady)    // &&uCnt)
    {
        u16DmaId=rmGetLdpcErrInfoId;

        if(u16DmaId)
        {
            if(rmGetLdpcErrInfoBitMap)
            {
                if(uMode==cLdpcNormalErr)
                {
                    handlePipeEccFail(rmGetLdpcDecSrcIdx(u16DmaId), rmGetLdpcErrPlaneIdx(u16DmaId));
                }

#if (_EN_GCPWR&&(!_EN_RAID_GC))
                else if(uMode==cLdpcPwr)
                {
                    BYTE uPageInWL;

                    gbEccFail=0;
                    handlePipeEccFail(rmGetLdpcDecSrcIdx(u16DmaId), rmGetLdpcErrPlaneIdx(u16DmaId));

                    if(gbEccFail)
                    {
                        uSrcIdx=rmGetLdpcDecSrcIdx(u16DmaId);
                        upAddrInfo=&garSrcAddrInfo[uSrcIdx];

                        if(mChkMlcMoBit(upAddrInfo->u16FBlock))
                        {
                            uPageInWL=1;
                        }
                        else
                        {
                            uPageInWL=mGetPageSelCmd(upAddrInfo);    // upAddrInfo->uPageSelCmd;
                        }

                        LWORD u32NoUpdateFPage=(LWORD)(upAddrInfo->u16FPage*gsGcInfo.uGCDesPagePerWL+(uPageInWL-1))*gTotalIntlvChPlaneNum+
                                                upAddrInfo->uIntlvAddr*gTotalChPlaneNum+upAddrInfo->uCh*gPlaneNum+
                                                rmGetLdpcErrPlaneIdx(u16DmaId);
                        mSetInvalidGcDesPage(u32NoUpdateFPage);
                        gbEccFail=0;
                    }
                }
#endif/* if (_EN_GCPWR&&(!_EN_RAID_GC)) */
            }

            uSrcIdx=rmGetLdpcDecSrcIdx(u16DmaId);
            upAddrInfo=&garSrcAddrInfo[uSrcIdx];

            if(mGetDmaCnt(upAddrInfo)==1)
            {
                chkReadState(upAddrInfo);

                if(upAddrInfo->uOpTyp==cPreReadData)
                {
                    invPlaneBufFlag(upAddrInfo->u16BufPtr, upAddrInfo->uRwHalfKb, cInvOccFlag);
                }
                else if(upAddrInfo->uOpTyp==cLastReadData)
                {
                    clrFwPreOccuFlag(upAddrInfo->u16BufPtr);    // Finn
                }

                uCh=upAddrInfo->uCh;
                gsRwCtrl.uChReadFifoTail[uCh]=(gsRwCtrl.uChReadFifoTail[uCh]+1)&(cMaxChFifoRDepth-1);
                // gsRwCtrl.uOpIdxAccCntR[uCh]--;
                // gsRwCtrl.uAllOpIdxCntR--;

                upDelLlInfo=&gsRwCtrl.usSrcCmdList;
                mDelNode(u16PrevNodeIdx, gsRwCtrl.uarSrcCmdLink, uSrcIdx, u16NextNodeIdx, upDelLlInfo);
                gsRwCtrl.uarFreeSrcQue[gsRwCtrl.u32FreeSrcFifoTail]=uSrcIdx;

/*
   *              u32FreeSrcFifoTail=(gsRwCtrl.u32FreeSrcFifoTail+1)&(cReadFifoDpt-1);
   *
   *              if((gsE2eInfo.uHmbEnable)&&(upAddrInfo->uOpTyp==cMoveReadData)&&(u32FreeSrcFifoTail==gsRwCtrl.u32FreeSrcFifoHead))
   *              {
   *                  hdmaCopyRam((LWORD)c32TsbTempCrcAddr,
   *                              (LWORD)c32TsbCrcAddr+(c16CopySIdx<<3),
   *                              c16WriteBufSize<<3,
   *                              cCopyTsb2Tsb|cHdmaWait|cHdmaTsbWriteFlag);
   *                  gsRwCtrl.u32FreeSrcFifoTail=u32FreeSrcFifoTail;
   *              }
   *              else
   */
                {
                    gsRwCtrl.u32FreeSrcFifoTail=(gsRwCtrl.u32FreeSrcFifoTail+1)&(cReadFifoDpt-1);
                }
            }
            else
            {
                upAddrInfo->uDmaCnt--;
            }

            g16LdpcDmaIdCnt--;
        }
        else
        {
            gsFtlDbg.u16DummyFailType=cChkLdpcResult;
            debugWhile();
        }

        rmPopLdpcInfo;
    }
}    /* chkLdpcResult */

void postFlashPreCmdAle(BYTE uTgtCh, BYTE uTgtIntlvAddr)
{
    ADDRINFO *upAddrInfo;
    BYTE uChTrig;
    BYTE uCnt=0;
    WORD u16LastFBlock=cInvalid16Bit, u16LastFPage=cInvalid16Bit;

#if  _EN_Precmd
    BYTE uLastPageSelCmd=cInvalid8Bit;
#endif

    setFLActCh(uTgtCh);
    uChTrig=gsRwCtrl.uChReadFifoTrig[uTgtCh];

    while(uChTrig!=gsRwCtrl.uChReadFifoHead[uTgtCh])
    {
        upAddrInfo=&garSrcAddrInfo[gsRwCtrl.uChReadFifoIdx[uTgtCh][uChTrig]];

        if(upAddrInfo->uIntlvAddr==uTgtIntlvAddr)
        {
#if  _EN_Precmd
            if((upAddrInfo->u16FBlock!=u16LastFBlock)||(upAddrInfo->u16FPage!=u16LastFPage)||
               (mGetPageSelCmd(upAddrInfo)!=uLastPageSelCmd)||(!(upAddrInfo->u16RwOpt&c16Bit9)))
#endif

            {
                u16LastFBlock=upAddrInfo->u16FBlock;
                u16LastFPage=upAddrInfo->u16FPage;
#if  _EN_Precmd
                uLastPageSelCmd=mGetPageSelCmd(upAddrInfo);    // upAddrInfo->uPageSelCmd;
#endif

                upAddrInfo->u16RwOpt|=c16Bit0;    // force use 2 plane read cmd and ale (for save last Page)

                if(upAddrInfo->u16RwOpt&c16Bit9)
                {
                    gsRwCtrl.uContiAddrCnt[upAddrInfo->uCh][upAddrInfo->uIntlvAddr]--;
                }

                if(!uCnt)
                {
                    upAddrInfo->u16RwOpt&=(~(c16Bit3|c16Bit9));    // clear CmdALE trigged flag.
                    gsRwCtrl.usWaitInfo[upAddrInfo->uCh][upAddrInfo->uIntlvAddr].uWaitFlag=cReadCmdAle;
                }
                else
                {
                    waitChCeBz(upAddrInfo->uCh, upAddrInfo->uIntlvAddr, 0);
                    upAddrInfo->u16RwOpt&=(~(c16Bit9));

                    while(!(upAddrInfo->u16RwOpt&c16Bit3))
                        ;

                    gsRwCtrl.usWaitInfo[upAddrInfo->uCh][upAddrInfo->uIntlvAddr].uWaitFlag=cCacheRCmd;
                }

                gsRwCtrl.usWaitInfo[upAddrInfo->uCh][upAddrInfo->uIntlvAddr].uStatusErrStop=0;

                uCnt++;

                gpFlashAddrInfo=upAddrInfo;
                // trigFlPreCmdAle();
                rmCeOn(gCe);
                flashChangeDieCmd(gDieAddr);
                chkRlibMoCmd();

#if _ENABLE_NAND_TestReadVth
                if(g16RCCnt==0)
                {
                    if((!gbLsbOnly)&&(gOpTyp!=cPwrOnGc))
                    {
                        setTestRetryCmd();
                        g16RCCnt=200;
                    }
                }
                else
                {
                    g16RCCnt--;
                }
#endif

                if(gbLsbOnly)
                {
                    if(mChkFLParam(cWithRlibMo))
                    {
                        rmSetPageAddr(g16FPage);
                    }
                    else if(mChkCardMode(cWithSlcMo))
                    {
                        rmSetPageAddr(g16FPage<<1);
                    }
                }
                else
                {
                    rmSetPageAddr(g16FPage);
                }

                rmSetSctrAddr(gSectorH);
                rmSelData;

                if(g16RwOpt&c16Bit0)
                {
                    setMultiPlaneRead();
                }
                else
                {
                    setAutoFBlock(gIntlvAddr, gPlaneAddr);
#if _EN_HalfR
                    if(!gsRwCtrl.uEnCacheR&&((gSectorH>>3)==((gSectorH+mGetReadSctrCnt-1)>>3)))
                    {
                        setSinglePlaneRead(1);
                    }
                    else
                    {
                        setSinglePlaneRead(0);
                    }
#else
                    setSinglePlaneRead(0);
#endif
                }

                rmAllCeOff;
            }
        }

        uChTrig=(uChTrig+1)&(cMaxChFifoRDepth-1);
    }

    gsRwCtrl.u16LastFBlockR[uTgtCh][uTgtIntlvAddr]=u16LastFBlock;
    gsRwCtrl.u16LastFPageR[uTgtCh][uTgtIntlvAddr]=u16LastFPage;
    g16LastRdCntFBlock=u16LastFBlock;
    g16LastRdCntFPage=u16LastFPage;
#if  _EN_Precmd
    gsRwCtrl.uPreFixCmd[uTgtCh][uTgtIntlvAddr]=uLastPageSelCmd;
#endif

    if(gsRwCtrl.uEnCacheR)
    {
        while(uCnt>2)
            ;
    }
    else
    {
        while(uCnt>1)
            ;
    }

    g32PreCmdAleDebugCnt[0]=uCnt;

    if(uCnt>g32PreCmdAleDebugCnt[1])
    {
        g32PreCmdAleDebugCnt[1]=uCnt;
    }

    /************/

    if(uCnt)
    {
        g32PreCmdAleDebugCnt[2]++;
    }
}    /* postFlashPreCmdAle */

void handlePipeEccFail(BYTE uSrcIdx, BYTE uPlaneIdx)
{
    ADDRINFO *upAddrInfo;
    BYTE uCh, uIntlvAddr;

    upAddrInfo=&garSrcAddrInfo[uSrcIdx];
    uCh=upAddrInfo->uCh;
    uIntlvAddr=upAddrInfo->uIntlvAddr;
    setFLActCh(uCh);

    while(rmGetOpIdxCntInFifo)
        ;

    mWaitCmdFifoBz;

    doReadRetry(upAddrInfo, uPlaneIdx, cLdpcPipeLineEnableMode);

#if _EN_RAID_DECODE
    if(gsRaidInfo.uRaidDecQueCnt)
    {
        return;
    }
#endif

    postFlashPreCmdAle(uCh, uIntlvAddr);
}    /* handlePipeEccFail */

void chkOpIdxAccCnt(BYTE uCh)
{
    BYTE uSortCnt, uOpIdxAccCnt, uNowOpIdx, uSrcIdx;    // , uProgFifoTail;
    ADDRINFO *upAddrInfo;
    volatile LINKINFO *upDelLlInfo;
    WORD u16PrevNodeIdx, u16NextNodeIdx;

/*
   *  LWORD u32FreeSrcFifoTail;
   */
    setFLActCh(uCh);
    uOpIdxAccCnt=gsRwCtrl.uOpIdxAccCntR[uCh]+gsRwCtrl.uOpIdxAccCntW[uCh];
    uSortCnt=uOpIdxAccCnt-rmGetOpIdxCntInFifo;

    if(uSortCnt)
    {
        uNowOpIdx=gsRwCtrl.uOpIdxSerial[uCh]-(uOpIdxAccCnt-1);

        while(uSortCnt!=0)
        {
            uSrcIdx=gsRwCtrl.uChReadFifoIdx[uCh][gsRwCtrl.uChReadFifoTail[uCh]];
            upAddrInfo=&garSrcAddrInfo[uSrcIdx];

            if(!gEnableLdpcPipe&&(!gsRwCtrl.uOpIdxAccCntW[uCh]||((upAddrInfo->uOpIdxSerial==uNowOpIdx)&&gsRwCtrl.uOpIdxAccCntR[uCh])))
            {
                chkReadState(upAddrInfo);

                if(upAddrInfo->uOpTyp==cPreReadData)
                {
                    invPlaneBufFlag(upAddrInfo->u16BufPtr, upAddrInfo->uRwHalfKb, cInvOccFlag);
                }
                else if(upAddrInfo->uOpTyp==cLastReadData)
                {
                    clrFwPreOccuFlag(upAddrInfo->u16BufPtr);
                }

                gsRwCtrl.uChReadFifoTail[uCh]=(gsRwCtrl.uChReadFifoTail[uCh]+1)&(cMaxChFifoRDepth-1);
                gsRwCtrl.uOpIdxAccCntR[uCh]--;
                gsRwCtrl.uAllOpIdxCntR--;
                upDelLlInfo=&gsRwCtrl.usSrcCmdList;
                mDelNode(u16PrevNodeIdx, gsRwCtrl.uarSrcCmdLink, uSrcIdx, u16NextNodeIdx, upDelLlInfo);
                gsRwCtrl.uarFreeSrcQue[gsRwCtrl.u32FreeSrcFifoTail]=uSrcIdx;

/*
   *              u32FreeSrcFifoTail=(gsRwCtrl.u32FreeSrcFifoTail+1)&(cReadFifoDpt-1);
   *
   *              if((gsE2eInfo.uHmbEnable)&&(upAddrInfo->uOpTyp==cMoveReadData)&&(u32FreeSrcFifoTail==gsRwCtrl.u32FreeSrcFifoHead))
   *              {
   *                  hdmaCopyRam((LWORD)c32TsbTempCrcAddr,
   *                              (LWORD)c32TsbCrcAddr+(c16CopySIdx<<3),
   *                              c16WriteBufSize<<3,
   *                              cCopyTsb2Tsb|cHdmaWait|cHdmaTsbWriteFlag);
   *                  gsRwCtrl.u32FreeSrcFifoTail=u32FreeSrcFifoTail;
   *              }
   *              else
   */
                {
                    gsRwCtrl.u32FreeSrcFifoTail=(gsRwCtrl.u32FreeSrcFifoTail+1)&(cReadFifoDpt-1);
                }
            }
            else
            {
                upAddrInfo=&garDesAddrInfo[gsRwCtrl.uChProgFifoIdx[uCh][gsRwCtrl.uChProgFifoTail[uCh]]];

                if(!gsRwCtrl.uOpIdxAccCntR[uCh]||((upAddrInfo->uOpIdxSerial==uNowOpIdx)&&gsRwCtrl.uOpIdxAccCntW[uCh]))
                {
#if _EnSpareFunc
                    if(gSpareCnt[uCh]>=mGetSprUseCnt(upAddrInfo))
                    {
                        gSpareCnt[uCh]=gSpareCnt[uCh]-mGetSprUseCnt(upAddrInfo);

                        if((gSpareCnt[uCh]==0)&&(gSparePtrHead[uCh]!=gSparePtrTail[uCh]))
                        {
                            gsFtlDbg.u16DummyFailType=cChkOpIdxAccCnt;
                            debugWhile();
                        }
                    }
                    else
                    {
                        while(!mChkTabSpr(upAddrInfo, cBit5|cBit6))
                            ;
                    }
#endif
                    upAddrInfo->uAddrOpt|=cDone;
                    gsRwCtrl.uChProgFifoTail[uCh]=addChPgFfPtrBy1(gsRwCtrl.uChProgFifoTail[uCh]);
                    gsRwCtrl.uOpIdxAccCntW[uCh]--;

                    while((gsRwCtrl.u32ProgFifoTail!=gsRwCtrl.u32ProgFifoTrig)&&(garDesAddrInfo[gsRwCtrl.u32ProgFifoTail].uAddrOpt&cDone))
                    {
                        gsRwCtrl.u32ProgFifoTail=addWrFfPtrBy1(gsRwCtrl.u32ProgFifoTail);    // (gsRwCtrl.u32ProgFifoTail+1)&(cWriteFifoDpt-1);
                    }
                }
            }

            uNowOpIdx++;
            uSortCnt--;
        }
    }
}    /* chkOpIdxAccCnt */

void chkOpIdxAccCntW(BYTE uCh)
{
    BYTE uSortCnt, uProgFifoTail;
    ADDRINFO *upAddrInfo;

    setFLActCh(uCh);
    uSortCnt=gsRwCtrl.uOpIdxAccCntW[uCh]-rmGetOpIdxCntInFifo;

    if(uSortCnt)
    {
        while(uSortCnt!=0)
        {
            upAddrInfo=&garDesAddrInfo[gsRwCtrl.uChProgFifoIdx[uCh][gsRwCtrl.uChProgFifoTail[uCh]]];

#if _EnSpareFunc
            if(gSpareCnt[uCh]>=mGetSprUseCnt(upAddrInfo))
            {
                gSpareCnt[uCh]=gSpareCnt[uCh]-mGetSprUseCnt(upAddrInfo);
            }
            else if(!mChkTabSpr(upAddrInfo, cBit5|cBit6))
            {
                gsFtlDbg.u16DummyFailType=cChkOpIdxAccCntW;
                debugWhile();
            }
#endif
            upAddrInfo->uAddrOpt|=cDone;
            gsRwCtrl.uChProgFifoTail[uCh]=(gsRwCtrl.uChProgFifoTail[uCh]+1)&(cMaxChFifoDepth-1);
            gsRwCtrl.uOpIdxAccCntW[uCh]--;

            uSortCnt--;
        }

        uProgFifoTail=gsRwCtrl.u32ProgFifoTail;

        while((uProgFifoTail!=gsRwCtrl.u32ProgFifoTrig)&&(garDesAddrInfo[uProgFifoTail].uAddrOpt&cDone))
        {
            uProgFifoTail=addWrFfPtrBy1(uProgFifoTail);
        }

        gsRwCtrl.u32ProgFifoTail=uProgFifoTail;
    }
}    /* chkOpIdxAccCntW */

void chkRwOpIdxTail(BYTE uCh)
{
    if(gsRwCtrl.uOpIdxAccCntW[uCh])
    {
        chkOpIdxAccCnt(uCh);
        chkEccFail(uCh);
#if _EN_PROGFAILLOG
        chkStatusFail(uCh);
#endif

        if(gEnableLdpcPipe)
        {
            chkLdpcResult(cLdpcNormalErr);
        }
    }
    else if(gsRwCtrl.uOpIdxAccCntR[uCh])
    {
        chkOpIdxAccCnt(uCh);
        chkEccFail(uCh);
#if _EN_PROGFAILLOG
        chkStatusFail(uCh);
#endif
    }
    else if(gEnableLdpcPipe)
    {
        chkLdpcResult(cLdpcNormalErr);
#if 0    // _EN_RAID_DECODE
        doRaidDecodeSwap();    // doRaidDecode();
#endif
    }
}    /* chkRwOpIdxTail */

BYTE getUNCOpIdx(BYTE uCh, BYTE uIdx)
{
    BYTE uTail=gsRwCtrl.uChReadFifoTail[uCh];
    ADDRINFO *upAddrInfo;

    do
    {
        upAddrInfo=&garSrcAddrInfo[gsRwCtrl.uChReadFifoIdx[uCh][uTail]];

        if(uIdx==upAddrInfo->uOpIdxSerial)
        {
            return gsRwCtrl.uChReadFifoIdx[uCh][uTail];
        }

        uTail=(uTail+1)&(cMaxChFifoRDepth-1);
    }
    while(uTail!=gsRwCtrl.uChReadFifoHead[uCh]);

    return cNoUECCSrc;
}    /* getUNCOpIdx */

void chkEccFail(BYTE uCh)
{
    if(!rmChkCmdFifoBz&&rmChkUNC)
    {
        if(rmGetOpIdxCntInFifo!=0)
        {
            gUncFifoPtr=getUNCOpIdx(uCh, rmGetOpIndex+1);

            if(gUncFifoPtr==cNoUECCSrc)
            {
                while(gUncFifoPtr)
                    ;
            }
            else
            {
                doReadRetry(&garSrcAddrInfo[gUncFifoPtr], cNoPlaneIndex, cLdpcPipeLineDisableMode);
#if 0    // _EN_RAID_DECODE
                doRaidDecodeSwap();    // doRaidDecode();
#endif
            }
        }
    }
}    /* chkEccFail */

void jdgReadRetry(ADDRINFO *upTempAddrInfo, BYTE uRstF)
{
    // LWORD u32StrT=0, u32EndT=0;

    waitCmdFifoDpt(upTempAddrInfo->uCh, upTempAddrInfo);
    gbEccFail=gbSprEccFail=gbDataEccFail=gbCorrStopF=gbOnesCntFail=0;

    if(uRstF!=0)
    {
        mClrBitMask(gPlaneUNCSts[upTempAddrInfo->uCh], upTempAddrInfo->uStartPlaneAddr);
        mClrBitMask(gPlaneCorrSts[upTempAddrInfo->uCh], upTempAddrInfo->uStartPlaneAddr);
    }
    else
    {
        gPlaneUNCSts[upTempAddrInfo->uCh]=0;
        gPlaneCorrSts[upTempAddrInfo->uCh]=0;
    }

    while(rmChkUNC)
    {
        doReadRetry(upTempAddrInfo, cNoPlaneIndex, cLdpcPipeLineDisableMode);
#if _EN_RAID_DECODE
        if((upTempAddrInfo->uOpTyp)!=cVenderRead)
        {
            if(gsRaidInfo.uRaidDecQueCnt)
            {
                doRaidDecodeSwap();    // doRaidDecode();
            }
        }
#endif

        while(rmChkCmdFifoBz)
            ;
    }
}    /* jdgReadRetry */

void getNandParam(BYTE uParmAddr, BYTE *upValue)
{}    /* getNandParam */

void setNandParam(BYTE uParmAddr, BYTE uValue)
{}    /* setNandParam */

void resetFlashForErrHandle()
{
#if 0
    // 4CH 8CE
    volatile BYTE uTemp[4][8]=
    {
        0
    };
#endif
    // BYTE uIndex;
    BYTE uTempActiveCe=0;

#if 1
    setSelMulFL(1);
    rmChSoftReset;
    setSelMulFL(0);
#endif
    waitAllChCeBz();

    for(uTempActiveCe=0; uTempActiveCe<gTotalCeNum; uTempActiveCe++)
    {
        for(gActiveCh=0; gActiveCh<gTotalChNum; gActiveCh++)
        {
            setFLActCh(gActiveCh);
            rmCeOn(uTempActiveCe);

#if 1
            rmCle(gReadStatusCmd);    // Flash Reset CMD only support 70h in SPEC,but using 78h also work!!
            rmNop(0x80);
            rmStsFailMask(0x00);
            rmRdStatus(0x60);

            while(rmChkCmdFifoBz)
                ;
#endif
#if (_EN_WD_ResetCmd_Force_SDR)
            rmCle(0xFD);    // (gSyncResetCmd);
#else
            rmCle(gSyncResetCmd);    // (gSyncResetCmd);
#endif
            sysDelay(0xFFFF);    // min 3ms reset time for CPU 350Mhz
            rmNop(0x80);

            while(rmChkCmdFifoBz)
                ;

            rmCle(gReadStatusCmd);    // Flash Reset CMD only support 70h in SPEC,but using 78h also work!!
            rmNop(0x80);
            rmStsFailMask(0x00);
            rmRdStatus(0x60);

            while(rmChkCmdFifoBz)
                ;

#if 0
            rmManRd(2);
            rmNop(0x01);

            while(rmChkCmdFifoBz)
                ;
            uTemp[gActiveCh][uTempActiveCe]=rFLCtrl[rcRd0];
#endif
            rmCeOff(uTempActiveCe);
        }
    }
}    /* resetFlash */

void resetRwCtrlForErrHandle()
{
    BYTE uCh, uIntlvAddr;

    gsRwCtrl.u32AllReadFifoCnt=0x00;
    gsRwCtrl.uAllOpIdxCntR=0x00;

    for(uCh=0; uCh<gTotalChNum; uCh++)
    {
        gsRwCtrl.uOpIdxSerial[uCh]=0x00;
        gsRwCtrl.uOpIdxAccCntR[uCh]=0x00;
        gsRwCtrl.uOpIdxAccCntW[uCh]=0x00;
        gsRwCtrl.uCmdFifoDpt[uCh]=0x00;

        gsRwCtrl.uChProgFifoHead[uCh]=0x00;
        gsRwCtrl.uChProgFifoTrig[uCh]=0x00;
        gsRwCtrl.uChProgFifoTail[uCh]=0x00;
        gsRwCtrl.uChProgFifoCnt[uCh]=0x00;
        gsRwCtrl.uChProgFifoPlaneCnt[uCh]=0x00;
        gsRwCtrl.uChPreFifoCnt[uCh]=0x00;
        gsRwCtrl.uChReadFifoHead[uCh]=0x00;
        gsRwCtrl.uChReadFifoTrig[uCh]=0x00;
        gsRwCtrl.uChReadFifoTail[uCh]=0x00;
        gsRwCtrl.uChReadFifoCnt[uCh]=0x00;
#if _EN_MutiWayCacheRImprove
        gsRwCtrl.uChLastReadCmdWay[uCh]=cInvalid8Bit;
        gsRwCtrl.uChForceDataOut[uCh]=0x00;
#endif

        for(uIntlvAddr=0; uIntlvAddr<gIntlvWay; uIntlvAddr++)
        {
            gsRwCtrl.uChPreFifoHead[uCh][uIntlvAddr]=0x00;
            gsRwCtrl.uChPreFifoTail[uCh][uIntlvAddr]=0x00;
            gsRwCtrl.usWaitInfo[uCh][uIntlvAddr].uWaitFlag=cNoOp;
            gsRwCtrl.u16LastFBlockR[uCh][uIntlvAddr]=cInvalid16Bit;
            gsRwCtrl.u16LastFPageR[uCh][uIntlvAddr]=cInvalid16Bit;
            gsRwCtrl.uContiAddrCnt[uCh][uIntlvAddr]=0;
#if _EN_Precmd
            gsRwCtrl.uPreFixCmd[uCh][uIntlvAddr]=cInvalid8Bit;
#endif
        }
    }

    gsRwCtrl.u32FreeSrcFifoTail=gsRwCtrl.u32FreeSrcFifoTrig=gsRwCtrl.u32FreeSrcFifoHead;
    gsRwCtrl.u32ProgFifoTail=gsRwCtrl.u32ProgFifoTrig=gsRwCtrl.u32ProgFifoHead;
    gsRwCtrl.usSrcCmdList.u16Cnt=0;
    g16LastRdCntFBlock=cInvalid16Bit;
    g16LastRdCntFPage=cInvalid16Bit;

#if _EnSpareFunc
    for(uCh=0; uCh<cMaxChNum; uCh++)
    {
        gSpareCnt[uCh]=0;
        gSparePtrHead[uCh]=0;
        gSparePtrTail[uCh]=0;
    }
#endif
}    /* resetRwCtrlForErrHandle */

void setFlashDriverStrength(BYTE uAddr, BYTE uWaitReady)
{
    BYTE uCh, uCe;
    BYTE *upIntrfaceSetPtr=&gCh0FshODTAndDrv;
    BYTE uP0, uP1, uP2, uP3;

#if _ENABLE_NAND_UART_DEBUG
    NLOG(cLogCore1, FLASHCMD_C, 0, "#### setFlashDriverStrength() ####");
#endif
    uP0=uP1=uP2=uP3=0x00;

    // SetFeatrue
    for(uCh=0; uCh<gTotalChNum; uCh++)
    {
        for(uCe=0; uCe<gTotalCeNum; uCe++)
        {
            uP0=(upIntrfaceSetPtr[uCh*4+0x00]&0x0F);
            getFeatureByChCeDie(uCh, uCe, 0x00, uAddr);
            setFeatureByChCe(uCh, uCe, uAddr, uP0, uP1, uP2, uP3, uWaitReady);

            if(uWaitReady)
            {
                getFeatureByChCeDie(uCh, uCe, 0x00, uAddr);
            }
        }
    }
}    /* setFlashDriverStrength */

void setFlashToggleSpecific(BYTE uAddr, BYTE uWaitReady)
{
    BYTE uCh, uCe;
    BYTE *upIntrfaceSetPtr=&gCh0FshODTAndDrv;
    BYTE uP0, uP1, uP2, uP3, uTempODT;

    uP0=uP1=uP2=uP3=uTempODT=0x00;
#if _ENABLE_NAND_UART_DEBUG
    NLOG(cLogCore1, FLASHCMD_C, 0, "#### setFlashToggleSpecific() ####");
#endif

    // SetFeatrue
    for(uCh=0; uCh<gTotalChNum; uCh++)
    {
        for(uCe=0; uCe<gTotalCeNum; uCe++)
        {
            uTempODT=(upIntrfaceSetPtr[uCh*4+0x00]&0xF0);
#if (_TSB_BiCS3|_TSB_BiCS4)
            if(g16FlashClock>=200)
            {
                if(gFormFactor==cBGA)
                {
                    uP0=uTempODT|0x06;
                }
                else
                {
                    uP0=uTempODT|0x07;
                }

                if(g16FlashClkForThermal==38)
                {
                    uP0=uTempODT|0x00;
                }
            }
            else
            {
                uP0=uTempODT|0x00;
            }
#endif/* if (_TSB_BiCS3|_TSB_BiCS4) */
#if (_SANDISK_3D_GEN2||_SANDISK_3D_GEN3)
            if(gFormFactor==cBGA)
            {
                uP0=uTempODT|0x06;
            }
            else
            {
                uP0=uTempODT|0x07;
            }
#endif
            getFeatureByChCeDie(uCh, uCe, 0x00, uAddr);
            setFeatureByChCe(uCh, uCe, uAddr, uP0, uP1, uP2, uP3, uWaitReady);

            if(uWaitReady)
            {
                getFeatureByChCeDie(uCh, uCe, 0x00, uAddr);
            }
        }
    }
}    /* setFlashToggleSpecific */

void changeFlashClockForThermal()
{
#if _ENABLE_NAND_UART_DEBUG
    NLOG(cLogCore1, FLASHCMD_C, 0, "## changeFlashClockForThermal() start ##");
#endif
#if (_TSB_BiCS3||_TSB_BiCS4)
    setFlashToggleSpecific(0x02, cNoWait);
    waitAllFlashReady();
    setFlashFeatureForInterface(g16FlashClkForThermal, 0x00, 0x00, 0x00, 0x00);    // Change to DDR Mode
#endif

#if (_SANDISK_3D_GEN2||_SANDISK_3D_GEN3)
    // SANDIXK_3D_GEN2 not support ODT!!
    setFlashToggleSpecific(0x02, cNoWait);
    waitAllFlashReady();
    setFlashFeatureForInterface(g16FlashClkForThermal, 0x00, 0x00, 0x00, 0x00);    // Change to DDR Mode
#endif
#if _ENABLE_NAND_UART_DEBUG
    NLOG(cLogCore1, FLASHCMD_C, 0, "## changeFlashClockForThermal() End ##");
#endif
}    /* changeFlashClockForThermal */

void getNandTempSensor()
{
#if _SANDISK_3D_GEN3
    // Wait LITEON TSB SP cmd for NandTempSensor
#endif/* if _SANDISK_3D_GEN3 */
}    /* getNandTempSensor */

#if (!_ICE_LOAD_ALL)
#pragma default_function_attributes =
#endif
#endif/* if ((_CPUID)||(_ICE_LOAD_ALL)) */







