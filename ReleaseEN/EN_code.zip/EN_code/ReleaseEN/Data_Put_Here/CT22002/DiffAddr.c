







#include "inc/Const.h"
// #include "inc/TypeDef.h"
// #include "inc/Option.h"
// #include "inc/ProType.h"
#include "inc/GlobVarS.h"
#include "inc/GlobVarT.h"
#include "inc/GlobVar1.h"
#include "inc/NvmeCtrl.h"
#include "inc/BitDef.h"
#include "inc/Reg.h"
#include "inc/Rdlink.h"
// #include "inc/Mac.h"
#include "inc/Option.h"

// opt Bit0: load only input index block
// Bit1: Other System Block

void loadBadInfoTab()
{
/*
   *  ADDRINFO usTmpAddrInfo;
   *
   * #if _INTEL_SYSTEM
   *  //flashSetFeature(0x92, 0x01, 0x00, 0x00, 0x00); //enable data randomization
   *  setFlashFeatrue(0x92, 0x01, 0x00, 0x00, 0x00, cForceWait); //enable data randomization
   * #endif
   *  tranRsvBlkAddr(garSysBlock[cBadInfo], &usTmpAddrInfo);
   *
   *  usTmpAddrInfo.u16FPage= gsBadInfo.u16BadInfoPageFreePtr-1; //load previous tab
   *  usTmpAddrInfo.uSectorH= 0;
   *
   *  setFLAddrActCh(usTmpAddrInfo.uCh, &usTmpAddrInfo);
   *
   *  setFRwParam(c16Tsb0SIdx, cBadInfoBufSctrCnt, c16Bit4|c16Bit10, cReadData);
   *  waitChCeBz(gActiveCh, gIntlvAddr, 0);
   *  flashReadPage();
   *
   *  if(gbEccFail)
   *  {
   *      bopClrRam(c32Tsb0SAddr, cBadInfoBufSctrCnt*512, 0, cClrTsb|cBopWait);
   *  }
   *
   * #if _INTEL_SYSTEM
   *  //flashSetFeature(0x92, 0x00, 0x00, 0x00, 0x00); //disable data randomization
   *  setFlashFeatrue(0x92, 0x00, 0x00, 0x00, 0x00, cForceWait); //enable data randomization
   * #endif
   */
}    /* loadBadInfoTab */

void initDiffTable()
{
    g16arDiffOffset=g16arTotalDiffAddr;
    g16arDiffAddr=&g16arTotalDiffAddr[g16DiffOffsetNum];
    g16arDiffType2Offset=&g16arTotalDiffAddr[cTotalDiffAddrTableSize/2-cMaxDiffType2Num];
    garRtDiffPoolPtr=(BYTE *)&g16arTotalDiffAddr[g16TotalFBlock];

    bopClrRam((LWORD)g16arTotalDiffAddr, cTotalDiffAddrTableSize, 0xFFFFFFFF, cClrCore1Dccm|cBopWait);
}

void loadDiffTabFromWpro(WORD u16SBufPtr, BYTE uSctrCnt, WORD u16FBlock, WORD u16FPage)
{
    ADDRINFO usTmpAddrInfo;

    usTmpAddrInfo.u16FBlock=u16FBlock;
    usTmpAddrInfo.u16FPage=u16FPage;
    tranAddrInfoTo2Ch(&usTmpAddrInfo);
    setFLAddrActCh(usTmpAddrInfo.uCh, &usTmpAddrInfo);
    gSectorH=0;
    mSetFRwParam(u16SBufPtr, uSctrCnt, c16Bit4|c16Bit10|c16Bit14, cReadData);
    mClrBitMask(gPlaneUNCSts[usTmpAddrInfo.uCh], usTmpAddrInfo.uPlaneAddr);
    waitChCeBz(usTmpAddrInfo.uCh, usTmpAddrInfo.uIntlvAddr, 0);
    flashReadPage();
    setBzInfo(gOpTyp, usTmpAddrInfo.uCh, usTmpAddrInfo.uIntlvAddr);
    gsRwCtrl.usWaitInfo[usTmpAddrInfo.uCh][usTmpAddrInfo.uIntlvAddr].uStatusErrStop=0;

    while(mChkBitMask(gPlaneUNCSts[usTmpAddrInfo.uCh], usTmpAddrInfo.uPlaneAddr))
        ;
}    /* loadDiffTabFormWPro */

void loadDiffTab()
{
    initDiffTable();
#if _EN_DIFFADDR
    BYTE uRestHalfKb=cDiffMixTableHalfKb, uDiffTabPage=gTotalDiffAddrTableStartPage;
    // WORD u16Block;
    WORD u16DiffStrBuf=c16Tsb0SIdx;

    gbEnDiffAddr=1;

#if (!_WO_INFOB)
    if(gsRdlinkInfo.u16DiffFPageNoTran!=c16BitFF)
    {
        fillCcmVal((BYTE *)&gPlaneUNCSts, cMaxChNum, 0);
        fillCcmVal((BYTE *)&gPlaneOnesCntSts, cMaxChNum, 0);
        fillCcmVal((BYTE *)&gReadLinkRetrySlcVth, sizeof(gReadLinkRetrySlcVth), 0);

        loadDiffTabFromWpro(u16DiffStrBuf, gSectorPerPlaneH, gsRdlinkInfo.u16DiffFBlock0, gsRdlinkInfo.u16DiffFPageNoTran);

        loadDiffTabFromWpro(u16DiffStrBuf+gSectorPerPlaneH,
                            (cDiffMixTableHalfKb-gSectorPerPlaneH),
                            gsRdlinkInfo.u16DiffFBlock1,
                            gsRdlinkInfo.u16DiffFPageNoTran+1);
#if (_EN_WHILE1)
        if((garTsb0[0][((g16TotalFBlock+(gTotalIntlvChPlaneNum*2))*2)+0]!=0x44)||
           (garTsb0[0][((g16TotalFBlock+(gTotalIntlvChPlaneNum*2))*2)+1]!=0x49)||
           (garTsb0[0][((g16TotalFBlock+(gTotalIntlvChPlaneNum*2))*2)+2]!=0x46)||
           (garTsb0[0][((g16TotalFBlock+(gTotalIntlvChPlaneNum*2))*2)+3]!=0x46))
        {
            while(1)
                ;
        }
#endif
    }
    else
    {
        while(uRestHalfKb>gSectorPerPlaneH)
        {
#if (!_PRJ_MPISP)
            while(loadInfoPage(uDiffTabPage, gSectorPerPlaneH, u16DiffStrBuf, 0, cSysBlock1stInfo, 0)!=0)
                ;
#else
            loadInfoPage(uDiffTabPage, gSectorPerPlaneH, u16DiffStrBuf, 0, cSysBlock1stInfo, 0);
#endif
            u16DiffStrBuf+=gSectorPerPlaneH;
            uRestHalfKb-=gSectorPerPlaneH;
            uDiffTabPage++;
        }

#if (!_PRJ_MPISP)
        while(loadInfoPage(uDiffTabPage, uRestHalfKb, u16DiffStrBuf, 0, cSysBlock1stInfo, 0)!=0)
            ;
#else
        loadInfoPage(uDiffTabPage, uRestHalfKb, u16DiffStrBuf, 0, cSysBlock1stInfo, 0);
#endif
    }
    bopCopyRam((LWORD)g16arTotalDiffAddr, (LWORD)&garTsb0[0][0], cTotalDiffAddrTableSize, cCopyTsb2Cpu1Dccm|cBopWait);
#endif/* if !_WO_INFOB */
#else/* if _EN_DIFFADDR */
    gbEnDiffAddr=0;
#endif/* if _EN_DIFFADDR */
}    /* loadDiffTab */

WORD getDiffAddr(WORD u16FBlock, BYTE uCh, BYTE uIntlvIdx, BYTE uPlaneIdx)
{
    BYTE uAddr=0;
    BYTE uAddrShift=0;
    BYTE uBitMap=0, uHiCnt=0, uByteOdr=0;
    WORD u16DiffOffset;
    UCBYTE *upDiffBlkBitMap;

    u16DiffOffset=g16arDiffOffset[u16FBlock]&(~c32Bit15);
    uAddr=(uCh*gIntlvWay+uIntlvIdx)*gPlaneNum+uPlaneIdx;

    if((g16arDiffOffset[u16FBlock]!=0xFFFF)&&(g16arDiffAddr[u16DiffOffset+(uAddr>>4)]&cb32BitTab[uAddr&0x0F]))
    {
        upDiffBlkBitMap=(UCBYTE *)(&(g16arDiffAddr[u16DiffOffset]));
        uAddrShift=uAddr>>3;    // n num 8bit,

        for(uByteOdr=0; uByteOdr<uAddrShift; uByteOdr++)
        {
            uHiCnt+=cbBitNumTab[*upDiffBlkBitMap];
            upDiffBlkBitMap++;
        }

        uAddrShift=(uAddr&7);

        if(uAddrShift>0)
        {
            uBitMap=(*upDiffBlkBitMap)&((1<<uAddrShift)-1);    // use as bit map
            uHiCnt+=cbBitNumTab[uBitMap];
        }

        return g16arDiffAddr[u16DiffOffset+gDiffBitMapOfst+uHiCnt];
    }
    else
    {
        return u16FBlock;
    }
}    /* getDiffAddr */

#if 0    // move to FlashPub.c
void tranType2Addr(ADDRINFO *upTmpAddrInfo, WORD u16Ty2Block)
{
    BYTE uAddr;

    // BYTE uPlaneBitCnt, uIntlvBitCnt, uPlaneBitShift, uIntlvBitShift, uChBitShift;

    upTmpAddrInfo->u16FBlock=u16Ty2Block&g16BlockBitMask;
    uAddr=u16Ty2Block>>gBlockBitCnt;
    upTmpAddrInfo->uCh=uAddr/gIntlvPlaneNum;
    uAddr%=gIntlvPlaneNum;
    upTmpAddrInfo->uIntlvAddr=uAddr/gPlaneNum;
    upTmpAddrInfo->uPlaneAddr=uAddr%gPlaneNum;
}

#endif

void getDiffAddr2(ADDRINFO *upTmpAddrInfo, WORD u16FBlock, BYTE uCh, BYTE uIntlvIdx, BYTE uPlaneIdx)
{
    BYTE uAddr=0;
    BYTE uAddrShift=0;
    BYTE uBitMap=0, uHiCnt=0, uByteOdr=0;
    WORD u16DiffOffset;
    UCBYTE *upDiffBlkBitMap;

    upTmpAddrInfo->uCh=uCh;
    upTmpAddrInfo->uIntlvAddr=uIntlvIdx;
    upTmpAddrInfo->uPlaneAddr=uPlaneIdx;
    upTmpAddrInfo->u16FBlock=u16FBlock;

    u16DiffOffset=g16arDiffOffset[u16FBlock]&(~c32Bit15);
    uAddr=(uCh*gIntlvWay+uIntlvIdx)*gPlaneNum+uPlaneIdx;

    if(g16arDiffAddr[u16DiffOffset+(uAddr>>4)]&cb32BitTab[uAddr&0x0F])
    {
        upDiffBlkBitMap=(UCBYTE *)(&(g16arDiffAddr[u16DiffOffset]));
        uAddrShift=uAddr>>3;    // n num 8bit,

        for(uByteOdr=0; uByteOdr<uAddrShift; uByteOdr++)
        {
            uHiCnt+=cbBitNumTab[*upDiffBlkBitMap];
            upDiffBlkBitMap++;
        }

        uAddrShift=(uAddr&7);

        if(uAddrShift>0)
        {
            uBitMap=(*upDiffBlkBitMap)&((1<<uAddrShift)-1);    // use as bit map
            uHiCnt+=cbBitNumTab[uBitMap];
        }

        tranType2Addr(upTmpAddrInfo, g16arDiffAddr[u16DiffOffset+gDiffBitMapOfst+uHiCnt]);
    }
}    /* getDiffAddr */

void setDiffType2AddrInfo(WORD u16FBlock)
{
    BYTE uCh, uIntlvIdx, uPlaneIdx, uAddr;
    BYTE uAddrShift=0;
    BYTE uBitMap=0, uHiCnt=0, uByteOdr=0;
    WORD u16DiffOffset;
    UCBYTE *upDiffBlkBitMap;

    gsDiffTyp2AddrInfo.u16FBlock=u16FBlock;

    u16DiffOffset=g16arDiffOffset[u16FBlock]&(~c32Bit15);
/*
   *  for(uAddr=0; uAddr<(gTotalIntlvChPlaneNum>>4); uAddr++)
   *  {
   *      gsDiffTyp2AddrInfo.u16arBitMap[uAddr]=g16arDiffAddr[u16DiffOffset+uAddr];
   *  }
   */
    uAddr=0;

    do
    {
        gsDiffTyp2AddrInfo.u16arBitMap[uAddr]=g16arDiffAddr[u16DiffOffset+uAddr];
        uAddr++;
    }
    while(uAddr<(gTotalIntlvChPlaneNum>>4));

    for(uCh=0; uCh<gTotalChNum; uCh++)
    {
        for(uIntlvIdx=0; uIntlvIdx<gIntlvWay; uIntlvIdx++)
        {
            for(uPlaneIdx=0; uPlaneIdx<gPlaneNum; uPlaneIdx++)
            {
                uAddr=(uCh*gIntlvWay+uIntlvIdx)*gPlaneNum+uPlaneIdx;

                if(g16arDiffAddr[u16DiffOffset+(uAddr>>4)]&cb32BitTab[uAddr&0x0F])
                {
                    upDiffBlkBitMap=(UCBYTE *)(&(g16arDiffAddr[u16DiffOffset]));
                    uAddrShift=uAddr>>3;    // n num 8bit,

                    for(uByteOdr=0; uByteOdr<uAddrShift; uByteOdr++)
                    {
                        uHiCnt+=cbBitNumTab[*upDiffBlkBitMap];
                        upDiffBlkBitMap++;
                    }

                    uAddrShift=(uAddr&7);

                    if(uAddrShift>0)
                    {
                        uBitMap=(*upDiffBlkBitMap)&((1<<uAddrShift)-1);    // use as bit map
                        uHiCnt+=cbBitNumTab[uBitMap];
                    }

                    gsDiffTyp2AddrInfo.u16arPhyAddr[uAddr]=g16arDiffAddr[u16DiffOffset+gDiffBitMapOfst+uHiCnt];
                }
                else
                {
                    gsDiffTyp2AddrInfo.u16arPhyAddr[uAddr]=c16BitFF;
                }
            }
        }
    }
}    /* getDiffAddr */

#if _ChkDiffMapping
void chkBlockMapping()
{
    volatile BYTE uStop=0;
    BYTE uCh, uIntlvIdx, uPlaneIdx, uIntlvIdx2, uPlaneIdx2, uType3Ptr;
    WORD u16Addr;
    WORD u16FBlock, u16Type3Block, u16PhyBlock;
    BYTE *upchkBitMap;
    ADDRINFO usTmpAddrInfo;

    bopClrRam((LWORD)&garTsb0[0], g16DiffOffsetNum*gTotalIntlvChPlaneNum/8, 0x00, cClrTsb|cBopWait);
    upchkBitMap=(BYTE *)&garTsb0[0][0];

    for(u16FBlock=0; u16FBlock<g16TotalFBlock; u16FBlock++)
    {
        if(g16arGlobEraseCnt[u16FBlock]!=c16BitFF)
        {
            for(uCh=0; uCh<gTotalChNum; uCh++)
            {
                for(uIntlvIdx=0; uIntlvIdx<gIntlvWay; uIntlvIdx++)
                {
                    for(uPlaneIdx=0; uPlaneIdx<gPlaneNum; uPlaneIdx++)
                    {
                        if(g16arDiffOffset[u16FBlock]!=0xFFFF)
                        {
                            if(mChkBitMask(g16arDiffOffset[u16FBlock], 0x0F))    // Type2 need to be tran before setAutoFBlock
                            {
                                getDiffAddr2(&usTmpAddrInfo, u16FBlock, uCh, uIntlvIdx, uPlaneIdx);
                                setFLActCh(usTmpAddrInfo.uCh);
                                g16AbstrFBlock=usTmpAddrInfo.u16FBlock;
                                g16FBlock=u16FBlock;
                                uIntlvIdx2=usTmpAddrInfo.uIntlvAddr;
                                uPlaneIdx2=usTmpAddrInfo.uPlaneAddr;
                            }
                            else
                            {
                                setFLActCh(uCh);
                                g16FBlock=u16FBlock;
                                uIntlvIdx2=uIntlvIdx;
                                uPlaneIdx2=uPlaneIdx;
                            }

                            setAutoFBlock(uIntlvIdx2, uPlaneIdx2);
                            u16PhyBlock=r16FLCtrl[rcBlock/2];
                        }
                        else
                        {
                            setFLActCh(uCh);
                            uIntlvIdx2=uIntlvIdx;
                            uPlaneIdx2=uPlaneIdx;
                            u16PhyBlock=u16FBlock;
                        }

                        if(u16PhyBlock>=g16TotalFBlock)
                        {
                            uStop=1;

                            while(uStop)
                                ;
                        }

                        u16Addr=(((u16PhyBlock*gTotalChNum+gActiveCh)*gIntlvWay+uIntlvIdx2)*gPlaneNum+uPlaneIdx2);

                        if(upchkBitMap[u16Addr/8]&cb32BitTab[u16Addr%8])
                        {
                            uStop=1;

                            while(uStop)
                                ;
                        }
                        else
                        {
                            upchkBitMap[u16Addr/8]|=cb32BitTab[u16Addr%8];
                        }
                    }
                }
            }
        }
    }

    for(uType3Ptr=0; uType3Ptr<gDiffType3Num; uType3Ptr++)
    {
        u16Type3Block=g16arDiffOffset[g16TotalFBlock+uType3Ptr];
        tranType2Addr(&usTmpAddrInfo, u16Type3Block);
        u16PhyBlock=usTmpAddrInfo.u16FBlock;
        setFLActCh(usTmpAddrInfo.uCh);
        uIntlvIdx2=usTmpAddrInfo.uIntlvAddr;
        uPlaneIdx2=usTmpAddrInfo.uPlaneAddr;

        if(u16PhyBlock>=g16TotalFBlock)
        {
            gsFtlDbg.u16DummyFailType=cChkBlockMapping;
            debugWhile();
        }

        u16Addr=(((u16PhyBlock*gTotalChNum+gActiveCh)*gIntlvWay+uIntlvIdx2)*gPlaneNum+uPlaneIdx2);

        if(upchkBitMap[u16Addr/8]&cb32BitTab[u16Addr%8])
        {
            gsFtlDbg.u16DummyFailType=cChkBlockMapping1;
            debugWhile();
        }
        else
        {
            upchkBitMap[u16Addr/8]|=cb32BitTab[u16Addr%8];
        }
    }
}    /* chkBlockMapping */

#endif/* if _ChkDiffMapping */







