







BYTE recoverFlashReg()
{
    BYTE uPass=0;
    BYTE uCh;

#if _EN_Precmd
    BYTE uIntlvAddr;
#endif

    initNandCtrlReg();

    if(rmGpioP06SelToggle)
    {
        if(rmChkDdrEn)
        {
            setBusDiff();
        }
        else
        {
            setBusToggleMode();
        }
    }
    else
    {
        if(rmChkDdrEn)
        {
            setBusDiff();
        }
        else
        {
            setBusEdoMode();
        }
    }

    rmSysDisF0DataPu;
    rmSysDisF1DataPu;
    rmSysDisF2DataPu;
    rmSysDisF3DataPu;
    rmSysEnF0DataPd;
    rmSysEnF1DataPd;
    rmSysEnF2DataPd;
    rmSysEnF3DataPd;

    rmSysDisF0DqsPd;
    rmSysDisF1DqsPd;
    rmSysDisF2DqsPd;
    rmSysDisF3DqsPd;
    rmSysEnF0DqsPu;
    rmSysEnF1DqsPu;
    rmSysEnF2DqsPu;
    rmSysEnF3DqsPu;

    setAleRegister();

    changeFlashClockForThermal();
    initBufWrap();

    uPass=1;
    ctrlScrbBothAndEcc(0x01, 0x01);
    gpFlashAddrInfo=(ADDRINFO *)&gsFlashAddrInfoTemp;
    // resetRwCtrlForErrHandle();

    for(uCh=0; uCh<gTotalChNum; uCh++)
    {
        gsRwCtrl.uOpIdxSerial[uCh]=0;
#if _EN_Precmd
        for(uIntlvAddr=0; uIntlvAddr<gIntlvWay; uIntlvAddr++)
        {
            gsRwCtrl.u16LastFBlockR[uCh][uIntlvAddr]=cInvalid16Bit;
            gsRwCtrl.u16LastFPageR[uCh][uIntlvAddr]=cInvalid16Bit;
            gsRwCtrl.uContiAddrCnt[uCh][uIntlvAddr]=0;
            gsRwCtrl.uPreFixCmd[uCh][uIntlvAddr]=cInvalid8Bit;
        }
#endif
    }

    gsFtlDbg.u32RRCnt=0;
    g16LastRdCntFBlock=cInvalid16Bit;
    g16LastRdCntFPage=cInvalid16Bit;

    return uPass;
}    /* recoverFlashReg */







