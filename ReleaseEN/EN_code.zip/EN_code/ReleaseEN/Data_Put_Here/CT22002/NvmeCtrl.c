







#include "inc/TypeDef.h"
#include "inc/ProType.h"
#include "inc/NvmeCtrl.h"
#include "inc/Asm.h"
#include "inc/GlobVarS.h"
#include "inc/Reg.h"
// #include "LightSwitch.c"

#if (!_ICE_LOAD_ALL)
#pragma default_function_attributes = @ ".NVME_CTRL"
#endif
#if (_CPUID!=1)

void initPcie()
{
    BYTE uEnOPROM=0;

#if _LOAD_OPROM
#if _ENABLE_PCIE_LS
    if(!(gsLightSwitch.usPcieLs.usRefClkAndOROM.uAll&0x01))
#endif
    {
        uEnOPROM=1;
        rmSetEpromSelSram;
        rmEnExpansionRomDps;
    }
#endif
    // PCIe Init
    LLOG_SAVE(cLogHost, NVMECTRL_C, 1, cSaveIdPcieInit, "PCIe Init, Link State=0x%04X ", rmDetectLinkState);

    rmEnPcieDbiroWrite;    // Nvme Only

#if _ENABLE_PCIE_LS
    rmSetPcieCfgVenderId(gsLightSwitch.usPcieLs.u16PcieVidLs);    // 0x8086->0x14A4
    rmSetPcieCfgDeviceId(gsLightSwitch.usPcieLs.u16PcieDidLs);    // 0xF1A5->0x9100
#else
    rmSetPcieCfgVenderId(0x14A4);
    rmSetPcieCfgDeviceId(0x9100);
#endif
    rmSetRevisionId(0x03);    // controller h/w stepping

    // Per NVMe SPEC 2-1 Device Status bit 4
    // Capabilities List (CL): Indicates the presence of a capabilities list.
    // The controller shall support the PCI Power Management capability as a minimum.
    // PCIe spec 3.0, clear bit 0 (immediately readiness). This register is defined in PCIe spec 3.1.
    if(gsLightSwitch.usNvmeLs.uComplianceTest&cPcie30)
    {
        rmSetStatusReg(0x0010);
    }

    rmSetClassCode(0x02, 0x08, 0x01);    // NME Express programming interface
                                         // Non-volatile memory controller sub class
                                         // mass storage controller class code
    rmSetCacheLineSize(0x00);
    rmSetMasterLatencyTimer(0x00);
    rmSetHeaderType(0x00);    // not a multi-function device
    rmSetBist(0x00);    // do not support BIST

    rmSetPcieBar0Type;
    rmSetPcieBar1;

    // Enable modification of CS2 register in Pcie MAC.
    rmPcieCs2En;

    rmSetPcieBar0Mask(0x0, 0x00003FFF);
    rmSetPcieBar0Mask(0x1, 0x00000000);
    rmSetPcieBar0Mask(0x2, 0x00000000);
    rmSetPcieBar0Mask(0x3, 0x00000000);
    rmSetPcieBar0Mask(0x4, 0x00000000);
    rmSetPcieBar0Mask(0x5, 0x00000000);

    if(uEnOPROM)
    {
        rmSetEprom(0x00000001);    // Clear OP ROM Mask
        sysDelay(50);
        rmSetEprom(0x0000FFFF);    // Clear OP ROM Mask
    }
    else
    {
        rmSetEprom(0x00000000);    // Clear OP ROM Mask
    }

    // Disable modification of CS2 register in Pcie MAC.
    rmPcieCs2Dis;

    rmSetCcpr(0x00);

#if _ENABLE_PCIE_LS
    rmSetSsvid(gsLightSwitch.usPcieLs.u16PcieSsvidLs);    // 0x8086->0x126F
    rmSetSsid(gsLightSwitch.usPcieLs.u16PcieSsidLs);    // 0xF1A5->0x2260
#else
    rmSetSsvid(0x126F);    // gparLS_Pcie->PcieSSVIDLs);
    rmSetSsid(0x2260);    // gparLS_Pcie->PcieSSIDLs);
#endif
    rmSetEprom(0x00000000);    // Disables OP ROM
    rmSetCapPointer(0x40);    // PCIe PM Cap Ptr

#if _LOAD_OPROM
    if(uEnOPROM)
    {
        rmSetEpromOffset(c16Tsb0SIdx);
        rmSetEpromDpp;
    }
#endif

    // Power Management Capabilities Register Offset 0x40
    // rmPowerManagementCapId(0x00);  //remove for 2263
    rmPowerManagementCapNextPtr(0x50);    // Enable MSI support //0x70); // Skip MSI capability
    rmSetPowerManagementCapRegVersion(0x03);
    rmSetPowerManagementCapRegPmeClock(0);

    if(gsLightSwitch.usNvmeLs.uComplianceTest&cPcie30)
    {
        rmSetPowerManagementCapRegPmeImmReadiRtnD0(0);
    }

    rmSetPowerManagementCapRegDeviceSpecInit(0);
    rmSetPowerManagementCapRegAuxCurrent(0);
    rmSetPowerManagementCapRegD1Support(cNotSupported);
    rmSetPowerManagementCapRegD2Support(cNotSupported);
    rmSetPowerManagementCapRegPmed0(cNotSupported);
    rmSetPowerManagementCapRegPmed1(cNotSupported);
    rmSetPowerManagementCapRegPmed2(cNotSupported);
    rmSetPowerManagementCapRegPmed3Hot(cNotSupported);
    rmSetPowerManagementCapRegPmed3Cold(cNotSupported);
#if _EN_D3Hot_PS4
    rmSetPmCtrlNoSoftReset(1);
#endif
    // MSI Message Control Register Offset 0x50
    rmSetMsiCapNextPtr(0x70);
#if _ENABLE_PCIE_LS
    rmSetMsiControlRegMultipleMessageCapable(gsLightSwitch.usPcieLs.usMultipleMesgCap.uAll&0x000E);    // 0x03->0x04 //Supports 8 vectors; h/w
                                                                                                       // limitation in A0; A1 should be
                                                                                                       // supporting 16 vectors
#else
    rmSetMsiControlRegMultipleMessageCapable(0x04);
#endif
    rmSetMsiControlRegCapableOf64Bits(1);    // 64 bit message address capable
    rmSetMsiControlRegPerVectorMaskCapable(1);    // 0);    // Does not support per vector masking
                                                  // Support MSI, PCIE is optional but NVME must be to support.

    // PCI Express Capabilities Register Offset 0x70
#if 0    // It should be for debug or MPISP
    rmPcieCapNextPtr(0x00);    // Disable MSIX in ROM Code
#else
    // OSIR �V MSI-X Per-Vector Masking (PVM) feature may miss interrupt event
    // it still fail with MSI, under debugging
    rmPcieCapNextPtr(0xB0);    // Enable MSIX in ISP Code
#endif
    rmPcieCapRegCapabilityVersion(0x02);
    rmPcieCapRegDeviceType(0);    // Indicating Pcie Endpoint
    rmPcieCapRegInterruptMessageNumber(0);
    rmPcieCapRegSlotImplemented(0);    // not slot

    // Device Capabilities Register offset 74h
#if _ENABLE_PCIE_LS
    rmSetPcieDeviceCapMaxPayloadSizeSupported(gsLightSwitch.usPcieLs.usDeviceCapLs.u16All&0x00000007);    // 0x02 //010b 512 bytes max payload
                                                                                                          // size
#else
    rmSetPcieDeviceCapMaxPayloadSizeSupported(0x02);
#endif
    rmSetPcieDeviceCapPhantomFunctionsSupported(0);    // No Function Number bits are used for Phantom Functions
    rmSetPcieDeviceCapExtendedTagSupported(0);    // 0b 5-bit Tag field supported
#if _ENABLE_PCIE_LS
    rmSetPcieDeviceCapL0sAcceptableLatency(gsLightSwitch.usPcieLs.usDeviceCapLs.u16All&0x000001C0);    // 0x07 //No Limit
    rmSetPcieDeviceCapL1AcceptableLatency(gsLightSwitch.usPcieLs.usDeviceCapLs.u16All&0x00000E00);    // 0x07 //No Limit
#else
    rmSetPcieDeviceCapL0sAcceptableLatency(0x07);    // gparLS_Pcie->DeviceCapLs.EndpointL0sAcceptableLatency;//No Limit
    rmSetPcieDeviceCapL1AcceptableLatency(0x07);    // gparLS_Pcie->DeviceCapLs.EndpointL1AcceptableLatency;//No Limit
#endif
    rmSetPcieDeviceCapRoleBasedErrorReporting(cSupported);
    rmSetPcieDeviceCapCapturedSlotPowerLimit(0x19);
    rmSetPcieDeviceCapCapturedSlotPowerLimitScale(0);    // 01b = 0.1x

#if _PCIE_FUN_LVL_RST
    rmSetPcieDeviceCapFunctionLevelResetCapability(cSupported);
#else
    rmSetPcieDeviceCapFunctionLevelResetCapability(cNotSupported);
#endif

    // Link Capabilities Register 0ffset 7Ch
#if _ENABLE_PCIE_LS
    rmSetPcieLinkCapMaximumLinkSpeed(gsLightSwitch.usPcieLs.usLinkCapLs.u32All&0x0000000F);    // 3 //1:Gen1, 2:Gen2, 3:Gen3
    rmSetPcieLinkCapMaximumLinkWidth(gsLightSwitch.usPcieLs.usLinkCapLs.u32All&0x000003F0);    // 4 //1/2/4:lane num
    rmSetPcieLinkCapActiveStatePmSupport(gsLightSwitch.usPcieLs.usLinkCapLs.u32All&0x00000C00);    // 3
    rmSetPcieLinkCapL0sExitLatency(gsLightSwitch.usPcieLs.usLinkCapLs.u32All&0x00007000);    // 4
    rmSetPcieLinkCapL1ExitLatency(gsLightSwitch.usPcieLs.usLinkCapLs.u32All&0x00038000);    // 3
    rmSetPcieLinkCapClockPowerManagement(gsLightSwitch.usPcieLs.usLinkCapLs.u32All&0x00040000);    // 1
#else
    rmSetPcieLinkCapMaximumLinkSpeed(3);    // 1:Gen1, 2:Gen2, 3:Gen3//R_PcieDev.DevPcieCap->LinkCapabilities.MaximumLinkSpeed=
                                            // gparLS_Pcie->LinkCapLs.MaximumLinkSpeed;
    rmSetPcieLinkCapMaximumLinkWidth(4);    // 1/2/4:lane num, R_PcieDev.DevPcieCap->LinkCapabilities.MaximumLinkWidth=
                                            // gparLS_Pcie->LinkCapLs.MaximumLinkWidth;
    rmSetPcieLinkCapActiveStatePmSupport(3);    // R_PcieDev.DevPcieCap->LinkCapabilities.ActiveStatePMSupport                =
                                                // gparLS_Pcie->LinkCapLs.ActiveStatePMSupport;
    rmSetPcieLinkCapL0sExitLatency(4);    // R_PcieDev.DevPcieCap->LinkCapabilities.L0sExitLatency                      =
                                          // gparLS_Pcie->LinkCapLs.L0sExitLatency;
    rmSetPcieLinkCapL1ExitLatency(3);    // R_PcieDev.DevPcieCap->LinkCapabilities.L1ExitLatency                       =
                                         // gparLS_Pcie->LinkCapLs.L1ExitLatency;
    rmSetPcieLinkCapClockPowerManagement(1);    // R_PcieDev.DevPcieCap->LinkCapabilities.ClockPowerManagement                =
                                                // gparLS_Pcie->LinkCapLs.ClockPowerManagement;
#endif/* if _ENABLE_PCIE_LS */
    rmSetPcieLinkCapSurpriseDownErrorReportingCapable(cNotSupported);
    rmSetPcieLinkCapDataLinkLayerActiveReportingCapable(cNotSupported);
    rmSetPcieLinkCapLinkBandwidthNotificationCapability(cNotSupported);
    rmSetPcieLinkCapAspmOptionalityCompliance(1);
    rmSetPcieLinkCapPortNumber(0);

    // Device Capabilites 2 Register offset 94h
#if _ENABLE_PCIE_LS
    rmSetPcieDeviceCap2CompletionTimeoutRangesSupported(gsLightSwitch.usPcieLs.usDeviceCap2Ls.u32All&0x0000000F);    // 0x0F //1111b Ranges A,
                                                                                                                     // B, C, and D
#else
    rmSetPcieDeviceCap2CompletionTimeoutRangesSupported(0x0F);
#endif
    rmSetPcieDeviceCap2CompletionTimeoutDisableSupported(cSupported);
    rmSetPcieDeviceCap2AriForwardingSupported(cNotSupported);
    rmSetPcieDeviceCap2AtomicOpRoutingSupported(cNotSupported);
    rmSetPcieDeviceCap2AtomicOpCompleterSupported32Bit(cNotSupported);
    rmSetPcieDeviceCap2AtomicOpCompleterSupported64Bit(cNotSupported);
    rmSetPcieDeviceCap2CasCompleterSupported128Bit(cNotSupported);
    rmSetPcieDeviceCap2NoRoEnabledPrprPassing(cNotSupported);
#if _ENABLE_PCIE_LS
    rmSetPcieDeviceCap2LtrMechanismSupported(gsLightSwitch.usPcieLs.usDeviceCap2Ls.u32All&0x00000800);    // 1
#else
    rmSetPcieDeviceCap2LtrMechanismSupported(1);
#endif
    rmSetPcieDeviceCap2TphCompleterSupported(cNotSupported);
#if _ENABLE_PCIE_LS
    rmSetPcieDeviceCap2ObffSupported(gsLightSwitch.usPcieLs.usDeviceCap2Ls.u32All&0x000C0000);    // 0->1
#else
    rmSetPcieDeviceCap2ObffSupported(1);
#endif
    rmSetPcieDeviceCap2ExtendedFmtFiledSupported(cNotSupported);
    rmSetPcieDeviceCap2End2EndTlpPrefixSupported(cNotSupported);
    rmSetPcieDeviceCap2MaxEnd2EndTlpPrefixes(0);
    rmClrPcieDeviceCap2RsrvBit;

    // Link Capabilities 2 Register offset 9Ch, supports 2.5, 5.0 and 8.0 GT/s

    // For passing PCIe spec 3.0, clear bit 31 (FRS Supported). This register is defined in PCIe spec 3.1.
    if(gsLightSwitch.usNvmeLs.uComplianceTest&cPcie30)
    {
        rmSetPcieLinkCap2PcieCapFrsSupported(0);
    }

#if _ENABLE_PCIE_LS
    rmSetPcieLinkCap2SupportedLinkSpeedsVector(gsLightSwitch.usPcieLs.usLinkCap2Ls.uAll&0x000000FE);    // 7
#else
    rmSetPcieLinkCap2SupportedLinkSpeedsVector(7);
#endif
    // Link Control 2 Register offset A0h
    // set it at another place, Just Set one times after power cycle

    // MIS-X Message Control Register Offset 0xB0

    // For passing PCIe CV test, we did not implement VPD now.
    rmSetMsixCapNextPtr(0);
    // Table Size?? need to judge ?? or A0 set to 8, A1 set to 16
#if _ENABLE_PCIE_LS
    if((gsLightSwitch.usPcieLs.usMessageCtrlLs.u16All&0x07FF)>=0x000F)
    {
        // gsLightSwitch.usPcieLs.usMessageCtrlLs.u16All=(gsLightSwitch.usPcieLs.usMessageCtrlLs.u16All&0x07FF)|0x000F;
        gsLightSwitch.usPcieLs.usMessageCtrlLs.u16All=(gsLightSwitch.usPcieLs.usMessageCtrlLs.u16All&0xF800)|0x000F;
    }

    rmSetMsixCtrlRegTableSize(gsLightSwitch.usPcieLs.usMessageCtrlLs.u16All&0x07FF);    // 0x0F //Supports 8 vecotrs in A0; 16 in A1
#else
    rmSetMsixCtrlRegTableSize(0x0F);
#endif

    rmSetMsixTableOffset(0x2000>>3);    // R_PCIeDev.DevPCIeMSIX->MessageTable.TableOffset  = (0x2000>>3);  //2263
    rmSetPbaMsixTableOffset(0x2100>>3);    // R_PCIeDev.DevPCIeMSIX->PBATable.TableOffset = (0x2800>>3);	     //2263

    // Offset - 0x100
    rmSetAdvancedErrorReport(0x15820001);    // Turn-off power budget function

    // offset 0x118 AER- Advanced Error Capabilities and Control
#if (_ENABLE_PCIE_LS    /*&&_ENABLE_PCIE_LS_FEAT_SUPPORT_OPT*/)
    rmSetAerCapCtrlEcrcGenerationCap(gsLightSwitch.usPcieLs.usAerCapLS.uAll&0x20);
    rmSetAerCapCtrlEcrcCheckCap(gsLightSwitch.usPcieLs.usAerCapLS.uAll&0x80);
#endif

    // Offset - 0x180
    rmSetL1PmSubstate(0x0001001E);    // Turn-off DPA function

    // offset 0x184 L1 Substates - Capability  //future to implement
#if (_ENABLE_PCIE_LS    /*&&_ENABLE_PCIE_LS_FEAT_SUPPORT_OPT*/)
    // R_PCIeDev.DevPCIeL1SubStateCap->ASPM_PM_L11_Support = gparLS_PCIe->L1SubExtCapLs.AspmL11Supported;  //2263
    // R_PCIeDev.DevPCIeL1SubStateCap->ASPM_PM_L12_Support = gparLS_PCIe->L1SubExtCapLs.AspmL12Supported;  //2263
    rmSetAspmL11Support(gsLightSwitch.usPcieLs.uL1SubExtCapLs.u32All);
    rmSetAspmL12Support(gsLightSwitch.usPcieLs.uL1SubExtCapLs.u32All);
#endif

    // Pcie MAC Port Link Control Offset 0x710
    rmSetPortLinkCtrlVendorSpecDllpReq(0);
    rmSetPortLinkCtrlScrambleDis(0);
    rmSetPortLinkCtrlLoopBackEn(0);
    rmSetPortLinkCtrlResetAssert(0);
    rmSetPortLinkCtrlDllLinkEn(1);
    rmSetPortLinkCtrlFastLinkMode(0);
#if _ENABLE_PCIE_LS
    rmSetPortLinkCtrlLinkModeEn((((gsLightSwitch.usPcieLs.usLinkCapLs.u32All&0x000003F0)>>4)*2)-1);    // must be 1,3,7
#else
    rmSetPortLinkCtrlLinkModeEn(7);    // cbPcieMacLinkModeSetting[4-1]);
#endif

    // ASIC Flush function is disable as default
    rmClrAutoFlushEn;    // 20190521_LeverYu_PS3 APST abort

    // Pcie MAC Link Width and Speed Change Control Register Offset 0x80C
    rmSetLinkWidthSpdChgCtrlNfts(0x80);
    rmSetLinkWidthSpdChgCtrlNumOfLanes(0x01);    // 2263 //0x04);
    rmSetLinkWidthSpdChgCtrlPredeterminedLanes(0);
    rmSetLinkWidthSpdChgCtrlAutoLaneFlipCtrLen(0x01);    // Enable Auto Lane Reveral
    rmSetLinkWidthSpdChgCtrlDirectedSpeedChange(0);
    rmSetLinkWidthSpdChgCtrlConfigPhyTxSwing(0);
    rmSetLinkWidthSpdChgCtrlConfigTxComplianceRcvBit(0);
    rmSetLinkWidthSpdChgCtrlDeEmphasisUpstreamPorts(0);

    // Pcie MAC AppCtl Register Offset 0xC00
    rmSetPcieAppCtrlAppsPmXmtPme(0);
    rmSetPcieAppCtrlAppReqEntrL1(0);
    rmSetPcieAppCtrlAppReqExitL1(0);
    rmSetPcieAppCtrlAppReadyEntrL23(1);    // 0);       //for Lenovo Y530
    rmSetPcieAppCtrlAppClkPmEn(cSupported);    // sam sugguest should not need support
    rmSetPcieAppCtrlAppLtssmEn(0);
    rmSetPcieAppCtrlWriteMacCS2(0);
    rmSetPcieAppCtrlCdmSelStickyRst(0);
    rmSetPcieAppCtrlNvmeEn(0x01);    // Reset default NVME_EN = 1
    rmSetPcieAppCtrlAppReqRetryEn(0);
    rmSetPcieAppCtrlCfgL1AuxClkSwitchCoreClkGateEn(0);
    rmSetPcieAppCtrlFlushEn(0x01);
    rmSetPcieAppCtrlCfgFroceTwoLane(0);    // set to '0' regardless of the link width
    rmSetPcieAppCtrlCfgFroceOneLane(0);    // 0);  //2263  // set to '0' regardless of the link width
    rmSetPcieAppCtrlPmCurrentState(0);
    rmSetPcieAppCtrlXmlhLtssmState(0);
    rmSetPcieAppCtrlCfgLinkRstDlyEn(0);    // '0' to disable gating
#if 0    // remove
    // rmSetPcieAppCtrlFwPerstN(1);  //0);
    // rmSetPcieAppCtrlCfgPerstNhostEn(0x00); //0x01);    // PERST will be handle by h/w in A1
#endif

    // Offset 0xC2C
#if _PHYCHG4_LTR    // (Sam) Disable HW auto LTR function
    rmSetLtrMsgReg0LtrMsgFwEn(0x00);
    rmSetLtrMsgReg0LtrMsgActiveEn(0x00);
#else
    rmSetLtrMsgReg0LtrMsgFwEn(0x01);
    rmSetLtrMsgReg0LtrMsgActiveEn(0x01);
#endif    // #if _PHYCHG4_LTR

    // According to Sam, the following two bits must be set to 0 in order to send the correct L0 LTR MSG
    rmSetLtrMsgReg0LtrMsgActiveL1En(0);    // 1: Active LTR message use L1 LTR
    rmSetLtrMsgReg0LtrMsgActiveL0sEn(0);    // 1: Active LTR message use L0s LTR

    // we dont need LTR for L0s
    // Offset 0xC30 LTR trigger timer 01
#if _ENABLE_PCIE_LS
    // rmSetLtrMsgReg1Timer0(gsLightSwitch.usPcieLs.usLtrTimer.u32All&0x0000FFFF);    // 0x0000 //for L1
    // rmSetLtrMsgReg1Timer1(gsLightSwitch.usPcieLs.usLtrTimer.u32All&0xFFFF0000);    // 0x0000 //for L1.2
#else
    // rmSetLtrMsgReg1Timer0(0x0000);    // for L1
    // rmSetLtrMsgReg1Timer1(0x0000);    // for L1.2
#endif

    // Offset 0xC30 LTR trigger timer 23
    // rmSetLtrMsgReg2Timer0(0xFFFFFFFF);    // not used
    // rmSetLtrMsgReg2Timer1(0xFFFFFFFF);    // not used

    // Offset 0xC38 LTR message
    initPcieLtrMsg();

    rmSetAckLatencyReplayTimer(cSetAckLatencyTimerLimit|cSetReplayTimerLimit);    // M_Set_ACK_Latency_Replay_Timer(SET_ACK_LATENCY_TIMER_LIMIT
                                                                                  // | SET_REPLAY_TIMER_LIMIT);

    rmSetPortFroceLink(0x00000000|cSetLowPowerEntranceCount);

    rmAckFreqL0L1AspmCtrl(
        cSetAckFreq|cSetAckNfts|cSetCommonClkNfts|
        (gsLightSwitch.usPcieLs.usLinkStateEntranceIdleTime.u32All&0x3F000000)|cSetEnterAspmL1WithoutRcvInL0s);

    rmSetGen3CtrlReg(0);    // This value needs to be set to '0' no matter at what link speed

    // rmSetOrderingReg(2);  //CSSD-3134(Sam)

    // Sam L1 timeout
    // rmSetL1TimerReg(gsLightSwitch.usPcieLs.usLinkStateEntranceIdleTime.u32All&0x0000FFFF); //remove, 2263
    rmSetL1TimerReg(0xFFFF);    // 2263
    rmResetLtssmTraceIntCtrl0;
    rmResetLtssmTraceIntCtrl1;

    rmSetAuxClkFreq(0x19);    // CSSD-5077 related, PS3.5/PS4 resume bug, can see link down or CPL TO

#if _2260PCIE_WORKAROUND
    // rmLtssmTraceTrig(0x474F4D54);
    rmLtssmTraceTrig(((cLtssmStateEn|cLtssmCfgLinkWdStart)<<24)|\
                     ((cLtssmStateEn|cLtssmRcvryRcvrCfg)<<16)|\
                     ((cLtssmStateEn|cLtssmRcvryLock)<<8)|\
                     (cLtssmStateEn|cLtssmL1Idle));
#endif

#if _ACER_ESD_ONELANE    // Sam Test Code for Acer platform
    rmLtssmTraceTrig(((cLtssmStateEn|cLtssmPreDetQuiet)<<24)|\
                     ((cLtssmStateEn|cLtssmCfgLaneNumAcept)<<16)|\
                     ((cLtssmStateEn|cLtssmCfgLaneNumWait)<<8)|\
                     (cLtssmStateEn|cLtssmCfgLinkWdAcept));

    rmSetDetectTimoutLtssm0(cLtssmCfgLaneNumAcept);    // To confirm that LTSSM change to predetect state is caused by timout at state
                                                       // "C_LTSSM_CFG_LANENUM_ACEPT"
    rmSetLtssmTimeoutValue(0x00030000);    // 3msec
#endif
    // rmLtssmTrig(0x20052311); //remove, 2263  // (Sam) 0x14=>0x05 from L1 to Pre-Detect

#if (_EN_PCIE_DEBUG)
    // Detect EQ phase done
    rmLtssmTraceTrig1(((cLtssmStateEn|cLtssmRcvryIdle)<<24)|\
                      ((cLtssmStateEn|cLtssmRcvryRcvrCfg)<<16)|\
                      ((cLtssmStateEn|cLtssmRcvryLock)<<8)|\
                      (cLtssmStateEn|cLtssmRcvryEq3));
#if _EN_CPLtimeouttest
    rmClrLtssmTraceIntr1;
    rmSetLtssmTraceIntr1En;
#else
    rmSetDetectTimoutLtssm1(cLtssmRcvryLock);
    rmSetDetectTimoutLtssm2(cLtssmRcvryRcvrCfg);

    rmClrLtssmTraceIntr1;
    rmSetLtssmTraceIntr1En;
    rmClrLtssmStateTimeoutIntr1;
    rmSetLtssmStateTimeoutIntr1En;
    rmClrLtssmStateTimeoutIntr2;
    rmSetLtssmStateTimeoutIntr2En;
#endif
#endif/* if (_EN_PCIE_DEBUG) */

#if (_DPHY_18)
    if(gsLightSwitch.usPhyLs.u16CustomizeF&cEarlyPCIeResetEn)
    {
        // rmLtssmTrig(0x1B190514); //remove, 2263   // Link Disable=0x19 for LTSSM int 02 (Lenovo y900a), and Pre-detect=0x05 for LTSSM int 01
        rmLtssmTrig((cLtssmLpbkActive<<24)|(cLtssmDisabled<<16)|(cLtssmPreDetQuiet<<8)|(cLtssmL1Idle));    // Link Disable=0x19 for LTSSM int 02
                                                                                                           // (Lenovo y900a), and
                                                                                                           // Pre-detect=0x05 for LTSSM int 01
    }
    else
    {
        // rmLtssmTrig(0x1B052314); //remove, 2263   // skyq 0x1B(loop back mode)/0x05(Pre-Detect) will gen int to pcie_irq_1_vect
        rmLtssmTrig((cLtssmLpbkActive<<24)|(cLtssmPreDetQuiet<<16)|(cLtssmRcvryEq3<<8)|(cLtssmL1Idle));    // skyq 0x1B(loop back
                                                                                                           // mode)/0x05(Pre-Detect) will gen
                                                                                                           // int to pcie_irq_1_vect
    }
#endif/* if (_DPHY_18) */

    rmLtssmCnt0Clr;    // clear L0 Cnt register
    rmEcrcCntClr;    // clear ECRC Cnt register
    rmLcrcCntClr;    // clear LCRC Cnt Register

    rmLtssmCnt0En;    // enable L0 event Cnt
    rmEcrcCntEn;    // enable ECRC event Cnt
    rmLcrcCntEn;    // enable LCRC event Cnt

    rmLtssmCnt0DisClr;    // stop clear L0 Cnt register
    rmEcrcCntDisClr;    // stop clear ECRC Cnt register
    rmLcrcCntDisClr;    // stop clear LCRC Cnt Register

//    if(gsLightSwitch.usPhyLs.u16CustomizeF&cPresetValueEQphase2En)    // remove for 2263  // ubPresetValueEQphase2En
//    {
//        rmSetGen3EqPsetReqVecReg(0, 0x80);
//        rmSetGen3EqPsetReqVecReg(1, 0x01);
//        rmSetGen3EqFmdcTminPhase23(0x4B);    // phase 2 5msec
//    }
//    else
//    {
//        rmSetGen3EqPsetReqVecReg(0, 0xFF);
//        rmSetGen3EqPsetReqVecReg(1, 0x07);
//        rmSetGen3EqFmdcTminPhase23(0x4D);    // phase 2 20msec
//    }

    rmSetGen3EqPsetReqVecReg(0, (gsLightSwitch.usPhyLs.u16CustomizeF&0x00FF));    // 2263
    rmSetGen3EqPsetReqVecReg(1, ((gsLightSwitch.usPhyLs.u16CustomizeF>>8)&0x0007));    // 2263

    BYTE uPresetValueCnt=chkEqPhase2PresetValueCnt();    // 2263

    if(uPresetValueCnt<9)    // 2263
    {
        rmSetGen3EqFmdcTminPhase23(0x53);    // phase2 19 msec,//2263
    }
    else
    {
        rmSetGen3EqFmdcTminPhase23(0x55);    // phase2 21 msec,//2263
    }

    // Enable Nvme offset C00h
    rmSetPcieAppCtrlNvmeEn(0x01);

    rmClrAutoSrisEn;

    rmSetPmCtrlNoSoftReset(1);    // tNvme 0_0.0.0

    rmDisPcieDbiroWrite;

    rmClrAutoSrisEn;

    gChgtoD0=0;
#if _EN_D3Hot_PS4
    rmClrD3Changed;
    rmClrPmL12Changed;
#endif
    rmClrEndIfReff;    // Dphy setting : allow refclk selection.

#if _FW_CTRL_LFCK
    rmClrLfckGating;
    rmClrtLfckAutoGate;
#else
    rmSetLfckAutoGate;    // auto gating LFCK, it work when ck3 trun off
#endif

#if (!_FW_HANDLE_L12)
    // set L1 gated setting
    // Offset 0xC4C
    rmSetAutoSendL1SubLtr;    // auto send LTR before enter L1.2

    // need to change flow for L1.2 send LTR
    // IF the host don't support, it don't need to send LTR automatically
    // Keep auto send now, Wait flow implement
#if _EN_D3Hot_PS4
    rmSetAutoEnterL1SubState;    // HW auto handle L1.2
#else
#if (_ENABLE_STANDBY_KEEP_L1)
    rmClrAutoEnterL1SubState;    // [Momo] LiteOn request, do not entry L1sub at standby mode
#else
    rmSetAutoEnterL1SubState;    // HW auto handle L1.2
#endif
#endif    // _EN_D3Hot_PS4

    rmSetL1AutoGatePclk;    // For power saving set Auto gating PCLK during L1

    rmSetWaitNvmeIdle;    // wait nvme idle before entering L1.2

    rmSetL1TimerReg((gsLightSwitch.usPcieLs.usLinkStateEntranceIdleTime.u32All&0x0000FFFF)<<3);    // L1 wait time into L1.2, 8=1ms

    // Offset 0xCF4
    rmPhyClkReqN(1);    // R_PCIeDev.DevMacAPPCTLREG0->phy_clk_req_n = 0x01;
    rmAppL1PwrOffEn(0);    // R_PCIeDev.DevMacAPPCTLREG0->app_l1_pwr_off_en = 0x00; //enable mac enter low power mode
    rmFwSaveStateAck(0);    // R_PCIeDev.DevMacAPPCTLREG0->fw_save_state_ack = 0x00; //enable mac enter low power mode

    // Offset 0xF28
    rmClrAppFlrPfDone;    // R_PCIeDev.DevMacAPPCTLREG1->APP_FLR_PF_Done = 0x0; // disable HW FLR operation. handled by FW

    // Offset 0xF2C
    rmSetL12RetryCount(0x01FF);    // retry count of entering L1.2

    rmPcieFastSimulationMode;    // shorten L1.2 entry timer
    // M_Set_L12_SleepTime(0xEF);  //Set time of keeping in L1.2

    rmSetL1RefNvmeIdle;    // If NVMe busy, link keep in L0
#endif/* if (!_FW_HANDLE_L12) */

    // rmLinkRstDlyDis;// No delay assert core reset after link down event occurred.
    rmLinkRstDlyEn;    // CSSD-4804 RDT stuck in while(M_Chk_PCLK)
    rmSet2262RstMechanism;    // When FW disable LTSSM bit, HW auto deassert core reset.
                              // If this bit is 0, when FW disable LTSSM bit, core reset always assert after link down.

#if _ENABLE_BUS_ERR_HANDLE
    rmClrAxiWrTimeoutErr;
    rmClrAxiWrWaitCnt;
    rmClrAxiRdTimeoutErr;
    rmClrAxiRdWaitCnt;
#endif

    rmLcrcCntClr;    // Add CPL timeout log use
    rmLcrcCntDisClr;
    rmLcrcCntEn;
}    /* initPcie */

void initPcieLtrMsg()
{
#if (_ENABLE_PCIE_LS&&(OEM!=DELL))    // Only Dell Disable LTR;20190403_Eason_02
#if (OEM==LENOVO)    // L0 and L1 70us for Lenovo;20190403_Eason_03
    rmSetMacLtrL0(0x88448844);    // L0
    // L0s , Not support
    rmSetMacLtrL1(0x88448844);    // L1
#else    // Other customer setting base on Lightswitch;20190403_Eason_03
    rmSetMacLtrL0(gsLightSwitch.usPcieLs.usLtrL0EntryLs.u32All);    // L0
    // L0s , Not support
    rmSetMacLtrL1(gsLightSwitch.usPcieLs.usLtrL1EntryLs.u32All);    // L1
#endif    // #if (OEM==LENOVO)
    rmSetMacLtrL12(gsLightSwitch.usPcieLs.usLtrL12EntryLs.u32All);    // L1.2
    rmSetMacLtrP1(gsLightSwitch.usPcieLs.usLtrL12EntryLs.u32All);    // P1
    rmSetMacLtrP2(gsLightSwitch.usPcieLs.usLtrL12EntryLs.u32All);    // P2
#else/* if _ENABLE_PCIE_LS */
    rmSetLtrMsgReg3MaxSnoopLatencyValue(0);    // R_PcieDev.DevMacLTRL0->MAX_SNOOP_LATENCY_VALUE =
                                               // gparLS_Pcie->LtrL0EntryLs.MAX_SNOOP_LATENCY_VALUE;
    rmSetLtrMsgReg3MaxSnoopLatencyScale(0);    // R_PcieDev.DevMacLTRL0->MAX_SNOOP_LATENCY_SCALE =
                                               // gparLS_Pcie->LtrL0EntryLs.MAX_SNOOP_LATENCY_SCALE;
    rmSetLtrMsgReg3SnoopLatencyRequirement(0);    // R_PcieDev.DevMacLTRL0->SNOOP_LATENCY_REQUIREMENT =
                                                  // gparLS_Pcie->LtrL0EntryLs.SNOOP_LATENCY_REQUIREMENT;
    rmSetLtrMsgReg3MaxNoSnoopLatencyValue(0);    // R_PcieDev.DevMacLTRL0->MAX_NO_SNOOP_LATENCY_VALUE =
                                                 // gparLS_Pcie->LtrL0EntryLs.MAX_NO_SNOOP_LATENCY_VALUE;
    rmSetLtrMsgReg3MaxNoSnoopLatencyScale(0);    // R_PcieDev.DevMacLTRL0->MAX_NO_SNOOP_LATENCY_SCALE =
                                                 // gparLS_Pcie->LtrL0EntryLs.MAX_NO_SNOOP_LATENCY_SCALE;
    rmSetLtrMsgReg3NoSnoopLatencyRequirement(0);    // R_PcieDev.DevMacLTRL0->NO_SNOOP_LATENCY_REQUIREMENT =
                                                    // gparLS_Pcie->LtrL0EntryLs.NO_SNOOP_LATENCY_REQUIREMENT;

    rmSetLtrMsgReg4MaxSnoopLatencyValue(0);    // R_PcieDev.DevMacLTRL1->MAX_SNOOP_LATENCY_VALUE =
                                               // gparLS_Pcie->LtrL1EntryLs.MAX_SNOOP_LATENCY_VALUE;
    rmSetLtrMsgReg4MaxSnoopLatencyScale(0);    // R_PcieDev.DevMacLTRL1->MAX_SNOOP_LATENCY_SCALE =
                                               // gparLS_Pcie->LtrL1EntryLs.MAX_SNOOP_LATENCY_SCALE;
    rmSetLtrMsgReg4SnoopLatencyRequirement(0);    // R_PcieDev.DevMacLTRL1->SNOOP_LATENCY_REQUIREMENT =
                                                  // gparLS_Pcie->LtrL1EntryLs.SNOOP_LATENCY_REQUIREMENT;
    rmSetLtrMsgReg4MaxNoSnoopLatencyValue(0);    // R_PcieDev.DevMacLTRL1->MAX_NO_SNOOP_LATENCY_VALUE =
                                                 // gparLS_Pcie->LtrL1EntryLs.MAX_NO_SNOOP_LATENCY_VALUE;
    rmSetLtrMsgReg4MaxNoSnoopLatencyScale(0);    // R_PcieDev.DevMacLTRL1->MAX_NO_SNOOP_LATENCY_SCALE =
                                                 // gparLS_Pcie->LtrL1EntryLs.MAX_NO_SNOOP_LATENCY_SCALE;
    rmSetLtrMsgReg4NoSnoopLatencyRequirement(0);    // R_PcieDev.DevMacLTRL1->NO_SNOOP_LATENCY_REQUIREMENT =
                                                    // gparLS_Pcie->LtrL1EntryLs.NO_SNOOP_LATENCY_REQUIREMENT;

    rmSetLtrMsgReg5MaxSnoopLatencyValue(0);    // R_PcieDev.DevMacLTRL12->MAX_SNOOP_LATENCY_VALUE =
                                               // gparLS_Pcie->LtrL12EntryLs.MAX_SNOOP_LATENCY_VALUE;
    rmSetLtrMsgReg5MaxSnoopLatencyScale(0);    // R_PcieDev.DevMacLTRL12->MAX_SNOOP_LATENCY_SCALE =
                                               // gparLS_Pcie->LtrL12EntryLs.MAX_SNOOP_LATENCY_SCALE;
    rmSetLtrMsgReg5SnoopLatencyRequirement(0);    // R_PcieDev.DevMacLTRL12->SNOOP_LATENCY_REQUIREMENT =
                                                  // gparLS_Pcie->LtrL12EntryLs.SNOOP_LATENCY_REQUIREMENT;
    rmSetLtrMsgReg5MaxNoSnoopLatencyValue(0);    // R_PcieDev.DevMacLTRL12->MAX_NO_SNOOP_LATENCY_VALUE =
                                                 // gparLS_Pcie->LtrL12EntryLs.MAX_NO_SNOOP_LATENCY_VALUE;
    rmSetLtrMsgReg5MaxNoSnoopLatencyScale(0);    // R_PcieDev.DevMacLTRL12->MAX_NO_SNOOP_LATENCY_SCALE =
                                                 // gparLS_Pcie->LtrL12EntryLs.MAX_NO_SNOOP_LATENCY_SCALE;
    rmSetLtrMsgReg5NoSnoopLatencyRequirement(0);    // R_PcieDev.DevMacLTRL12->NO_SNOOP_LATENCY_REQUIREMENT =
                                                    // gparLS_Pcie->LtrL12EntryLs.NO_SNOOP_LATENCY_REQUIREMENT;

    rmSetLtrMsgReg6MaxSnoopLatencyValue(0);    // R_PcieDev.DevMacLTR_4->MAX_SNOOP_LATENCY_VALUE =
                                               // gparLS_Pcie->LtrL12EntryLs.MAX_SNOOP_LATENCY_VALUE;
    rmSetLtrMsgReg6MaxSnoopLatencyScale(0);    // R_PcieDev.DevMacLTR_4->MAX_SNOOP_LATENCY_SCALE =
                                               // gparLS_Pcie->LtrL12EntryLs.MAX_SNOOP_LATENCY_SCALE;
    rmSetLtrMsgReg6SnoopLatencyRequirement(0);    // R_PcieDev.DevMacLTR_4->SNOOP_LATENCY_REQUIREMENT =
                                                  // gparLS_Pcie->LtrL12EntryLs.SNOOP_LATENCY_REQUIREMENT;
    rmSetLtrMsgReg6MaxNoSnoopLatencyValue(0);    // R_PcieDev.DevMacLTR_4->MAX_NO_SNOOP_LATENCY_VALUE =
                                                 // gparLS_Pcie->LtrL12EntryLs.MAX_NO_SNOOP_LATENCY_VALUE;
    rmSetLtrMsgReg6MaxNoSnoopLatencyScale(0);    // R_PcieDev.DevMacLTR_4->MAX_NO_SNOOP_LATENCY_SCALE =
                                                 // gparLS_Pcie->LtrL12EntryLs.MAX_NO_SNOOP_LATENCY_SCALE;
    rmSetLtrMsgReg6NoSnoopLatencyRequirement(0);    // R_PcieDev.DevMacLTR_4->NO_SNOOP_LATENCY_REQUIREMENT =
                                                    // gparLS_Pcie->LtrL12EntryLs.NO_SNOOP_LATENCY_REQUIREMENT;

    rmSetLtrMsgReg7MaxSnoopLatencyValue(0);    // R_PcieDev.DevMacLTR_5->MAX_SNOOP_LATENCY_VALUE =
                                               // gparLS_Pcie->LtrL12EntryLs.MAX_SNOOP_LATENCY_VALUE;
    rmSetLtrMsgReg7MaxSnoopLatencyScale(0);    // R_PcieDev.DevMacLTR_5->MAX_SNOOP_LATENCY_SCALE =
                                               // gparLS_Pcie->LtrL12EntryLs.MAX_SNOOP_LATENCY_SCALE;
    rmSetLtrMsgReg7SnoopLatencyRequirement(0);    // R_PcieDev.DevMacLTR_5->SNOOP_LATENCY_REQUIREMENT =
                                                  // gparLS_Pcie->LtrL12EntryLs.SNOOP_LATENCY_REQUIREMENT;
    rmSetLtrMsgReg7MaxNoSnoopLatencyValue(0);    // R_PcieDev.DevMacLTR_5->MAX_NO_SNOOP_LATENCY_VALUE =
                                                 // gparLS_Pcie->LtrL12EntryLs.MAX_NO_SNOOP_LATENCY_VALUE;
    rmSetLtrMsgReg7MaxNoSnoopLatencyScale(0);    // R_PcieDev.DevMacLTR_5->MAX_NO_SNOOP_LATENCY_SCALE =
                                                 // gparLS_Pcie->LtrL12EntryLs.MAX_NO_SNOOP_LATENCY_SCALE;
    rmSetLtrMsgReg7NoSnoopLatencyRequirement(0);    // R_PcieDev.DevMacLTR_5->NO_SNOOP_LATENCY_REQUIREMENT =
                                                    // gparLS_Pcie->LtrL12EntryLs.NO_SNOOP_LATENCY_REQUIREMENT;
#endif/* if _ENABLE_PCIE_LS */

#if _PCIE_D3HOT_D0_LTR_WORKAROUND    // (Sam) Manual LTR TLP header, keep during PS4
    rmSetPcieVenMsgCtrl0(0x34000000);
    rmSetPcieVenMsgCtrl1(0x00000010);
    rmSetPcieVenMsgCtrl2(0x90109010);
    rmSetPcieVenMsgCtrl3(0x00000000);
#endif
}    /* initPcieLtrMsg */

void resetNvmeIp()
{
    LWORD u32Cnt=0;
    LWORD u32PopCnt=0;
    BYTE uQID=17;

    if(rmChkNvmeInvDbWriteInt)
    {
        NLOG(cLogHost, NVMECTRL_C, 2, " resetNvmeIp(), Invalid write DB, bitmap=0x%08X ", rmChkNvmeInvDbWriteInt>>16, rmChkNvmeInvDbWriteInt);

        while(uQID)
        {
            uQID--;

            if(rmGetNvmeInvSqDb&cb32BitTab[uQID])
            {
                rmSetSqTailDoorBell(uQID, rmGet2263SqHeadDoorBell(uQID));
            }
        }
    }

    rmClrNvmeInvSqDbAll;
    rmClrNvmeInvCqDbAll;

    while((u32Cnt<10000)&&(!rmChkSqEmpty||!rmChkFwRqEmpty||rmChkCmdRdy))    // || !(R8_AUX[O8_CPU_Aux_Clt0_3] & SetB1)) // PS4 potential bugfix
    {
        while(rmChkCmdRdy)
        {
            rmPopNextCmd;
            u32Cnt=0;
            u32PopCnt++;
        }

        u32Cnt++;
    }

    if(u32PopCnt)
    {
        NLOG(cLogHost, NVMECTRL_C, 2, " resetNvmeIp(), Pop cmd cnt=0x%08X ", u32PopCnt>>16, u32PopCnt);
    }

    // move this portion of code from _HandleNvmeReset() to here to fix NVMETEST tool bug
    rmClrCcAms;    // For IOL, need clear is bit, this bit is set for the RR patch
    rmCcEnClr;    // Clear CC.EN              //CSSD-2097
    // rmClrCcRdy;
    rmClrNvmeCcEnOnInt;    // Clear CC.EN interrupt    //CSSD-2097
    rmClrShutdownNotify;    // (Luis)Clear CC.SHN             //IOL
    rmClrNvmeShnChangeInt;    // Clear CC.SHN interrupt   //IOL

    rmNvmeRstEn;    // reset NVMe IP & bridge
    // _nop();
    __DSB();
    __ISB();
    sysDelay(1000);

    if(rmChkFlushWriteEmpty||rmChkFlushReadEmpty||rmPrdPdtr0||rmPrdPdtr1||mPcieChkFlr)
    {
        NLOG(cLogHost, NVMECTRL_C, 2, " resetNvmeIp(), Write Empty=%d, Read Empty=%d ", rmChkFlushWriteEmpty, rmChkFlushReadEmpty);

        while(!rmAuxChkAllIdle)
            ;

        while(gsTskFifoCtrl.u32HeadPtr!=gsTskFifoCtrl.u32TailPtr)
            ;

        saveQBInfo(cOnPcieErr);
        core1SwapNvmeBank();    // Flash setting recover func at NvmeIsp1 bank.
        // BackUpAES();     //wait to implement
        // DisableCache();  //wait to implement
        rmSysSetPw1Rst;
        __DSB();
        __ISB();
        rmSysClrPw1Rst;

        // sysDelay(200);//finn wait pw1, 200 is a random number and it need to be comfirmed
        // init Bop
        // initBop();

        restorHwRegFromPs3();
        // init Bop
        initBop();    // momo

        initAes();

#if _ENABLE_SECAPI
        if(gbEnAes)
        {
            loadISPCodeCore0(cSecTsbBank, 3);
            SecAPI_NoticeSecCodeSwap(0);
            restoreAesKey();
            // SecAPI_NoticeSecCodeSwap(1);
        }
#endif

        readWproPageCore0(cWproQBootPg, c16Tsb0SIdx, 0);

        while(*(WORD *)(0x51100000+rcSparStartAddr)==0)
            ;// debug

        NLOG(cLogHost, NVMECTRL_C, 2, " resetNvmeIp(), Write Empty=%d, Read Empty=%d ", rmChkFlushWriteEmpty, rmChkFlushReadEmpty);
    }

    while(rmChkFlushWriteEmpty)
        ;// Albert

    while(rmChkFlushReadEmpty)
        ;

#if _EN_DisHMBInReset        // 20190805_Chief_DisHMB
    if(gsHmbInfo.uHmbEnable||(gChkFlag&cEnableFakeHMB))
#else
    if(gsHmbInfo.uHmbEnable)
#endif
    {
        disableHmbFunc(cEnabled);    // LeverYu_0813 SMI S0813A  SQ mismatch issue
    }

    // _nop();  //remove for 2263
    rmNvmeRstOff;

    // for CPL timeout to clear stop fetch command
    rmClrAllQueStopFetchCmd;

    rmClrMps;    // tnvme 1:1.0.0
    // rmSetPorSoftReset;  //tnvme 1:1.0.0
    // sysDelay(1000);
    // rmClrPorSoftReset;  //tnvme 1:1.0.0

    rmClrNvmeResetInt;

#if (!_SM226X_A0)
    rmClrAllPrpListErr;
#endif
}    /* resetNvmeIp */

void initNvmeBufWrap()
{
    // rmSetNvmeBias(u32DramCacheBias/64); // 32KB alignment

    rmSetTsbWrap0NvmeS(cTsb0StartBufIdx);
    rmSetTsbWrap0NvmeE(cTsb0StartBufIdx+cTsb0Size-1);

    rmSetTsbWrap1NvmeS(cTsb1StartBufIdx);
    rmSetTsbWrap1NvmeE(cTsb1StartBufIdx+cTsb1Size-1);

    rmSetTsbWrap2NvmeS(cTsb2StartBufIdx);
    rmSetTsbWrap2NvmeE(cTsb2StartBufIdx+cTsb2Size-1);

    // rmSetBvciWrap0NvmeS(0x00000000);
    // rmSetBvciWrap0NvmeE(u32Cache0Size-1);
    // rmSetBvciWrap1NvmeS(u32Cache0Size);
    // rmSetBvciWrap1NvmeE(u32Cache0Size+u32Cache1Size-1);
    // rmSetBvciWrap2NvmeS(u32Cache0Size);
    // rmSetBvciWrap2NvmeE(u32Cache0Size+u32Cache1Size-1);

    // Set reference flag
    // rmDisHdmaRefBvfBuf;
    // rmEnPcieWrRefBvfBuf;
    // rmEnPcieWrRefBVFOcu;
    // rmEnPcieRdRefBvfBuf;

    rmEnAnotherQueue;
    rmDisNvmeIpArb;
}    /* initNvmeBufWrap */

void initNvmeIp()
{
    rmSetNss;    // number of namespace supported = 1
    rmSetWaterMark;    // FwRq threshold, exceed threshold will produce interrupt

    rmLba512;    // set LBA size to 512 Byte
    // rmLocalHost128; //Host IF Burst Size to 128 Byte

    // rmForceBurstSize; //Force nvme west side burst size as unex register define
    // rmLocalHost256; //Host IF Burst Size to 256 Byte

    rmLocalMemory512;    // Local Memory IF Burst Size to 512 Byte

    // rmAllDmaEngineEn; //Global DMA Enable

#if _ENABLE_NVME_LS
#if _ENABLE_NVME_LS_FEAT_SUPPORT_OPT
    // if( gparLS_SEC->u32SecFeature.bATAPassThrough  //security feature, 2263 future to implement
    //        ||  gparLS_SEC->u32SecFeature.bOPAL
    //        ||  gparLS_SEC->u32SecFeature.bAutoFreezeLock
    //        ||  gparLS_SEC->u32SecFeature.beDrive
    //        ||  gparLS_SEC->u32SecFeature.bCRAM
    //        ||  gparLS_SEC->u32SecFeature.bPyrite
    //        ||  gparLS_SEC->u32SecFeature.bOPALite)
    // {
    //    u16OACS.resv_0 = 1; //[coby] use lightswitch to judge OACS bit0
    // }
    WORD u16Oacs=gsLightSwitch.usNvmeLs.u16Oacs;    // 0x07 Supports Security Receive/Send, Format NVM, Firmware Commit and Firmware Image
                                                    // Download commands
#if (_ENABLE_SECAPI)
    if(gbEnTCG||gbEnATAPassThrough||gbEnRpmb)
    {
        u16Oacs|=cSecuritySendReceiveCmd;    // judge OACS bit0
    }
#endif
    rmSetOacs((BYTE)u16Oacs);    // 0x07 Supports Security Receive/Send, Format NVM, Firmware Commit and Firmware Image
#endif/* if _ENABLE_NVME_LS_FEAT_SUPPORT_OPT */
    rmSetAcl(gsLightSwitch.usNvmeLs.uAcl);    // 0x03, limited after get lightswitch
    rmSetAerl(gsLightSwitch.usNvmeLs.uAerl);    // 0x03, limited after get lightswitch

#if _ENABLE_NVME_LS_FEAT_SUPPORT_OPT
    rmSetOncs(gsLightSwitch.usNvmeLs.uOncs);    // 0x1F HW Supports Compare, Write UNC, Dataset Management, Write Zeros, and Save/Select Field
    rmSetApst(gsLightSwitch.usNvmeLs.uApsta);    // Set APST enable/disable bit
#endif
    // rmSetMaxIntVec;    // 0x08 Supports maximum 8 interrupt vectors in A0; 16 in A1
    rmSetMaxIntVec((gsLightSwitch.usPcieLs.usMessageCtrlLs.u16All&0x07FF)+1);    // 0x08 Supports maximum 8 interrupt vectors
    rmSetMpsMaxMin(((gsLightSwitch.usNvmeLs.usControllerCapHi.u32All&0x00F00000)>>20),
                   ((gsLightSwitch.usNvmeLs.usControllerCapHi.u32All&0x000F0000)>>16));    //
                                                                                           // 0x01,0x00;
                                                                                           // 4KB
                                                                                           // Min
                                                                                           // and
                                                                                           // 4KB
                                                                                           // Max
                                                                                           // Memory
                                                                                           // Page
                                                                                           // Size
    rmSetTo((gsLightSwitch.usNvmeLs.usControllerCapLo.u32All&0xFF000000)>>24);    // 0x1C,  time out value
    rmSetMqes(gsLightSwitch.usNvmeLs.usControllerCapLo.u32All&0x0000FFFF);    // 0xff; Queue Depth 255
    rmSetNvmeMisc5((((gsLightSwitch.usNvmeLs.usControllerCapLo.u32All&0x00010000)>>16)<<3)    // CQR
                   |(((gsLightSwitch.usNvmeLs.usControllerCapLo.u32All&0x00060000)>>17)<<1)    // CFS and AMS
                   |(((gsLightSwitch.usNvmeLs.usControllerCapHi.u32All&0x00000010)>>4))    // NSSRS
                   );
    // CQR=1, CFS=0, AMS=0, NSSRS=1
    // NSSRS;//0x00 Do not support NVM Subsystem Reset
    // AMS;//0x00 Supports Weighted Round Robin with Urgent Priority Class ///???
    // CFS;//0x00 Controller Fatal Status
    // CQR;//0x01 Contiguous Queues Required

    rmSetNvmeVersion(gsLightSwitch.usNvmeLs.u32Ver);
#endif/* if _ENABLE_NVME_LS */
// #if (!_SM226X_A0)
//    rmClrAllPrpListErr;
// #endif
    // CC.RDY reset to 0 when CC.EN disable
    rmNvmeCcRdyFwCtrl;

    initNvmeBufWrap();
}    /* initNvmeIp */

void handleNvmeReset()
{
    updateInvalidDbErrLog();

#if _PCIE_FUN_LVL_RST
    rmNvmeEnFlrInt;
#endif
    rmNvmeCcEnOnEn;
    rmNvmeResetIntEn;
    rmNvmeShnChangeEn;    // Enable NVMe shutdown notice interrupt
    rmNvmeInvDbWriteEn;    // Enable Invalid DoorBell write interrupt //CSSD-1740

#if 0    // _ENABLE_E2E_PROTECTION
    rmNvmeCrcIntEn;
#endif

#if _ENABLE_UPDATE_NVMEFEATSETTING_INISR
    // Resets Get/Set Feature settings
    updateNvmeFeatureSetting();    // Resets feature settings
    //    Update_APST_Table();//resets APST setting
    // InitErrorLog();//new requirement in 1.3 spec. Error Logs shall be clear across power cycle and resets
    // Init_Timestamp(C_Initialized_By_Reset, 0);
#endif

    // Disable L1 Timeout,
#if _FW_HANDLE_L12
    gL1TimeOutEnabled=0;
#endif
    rmClrL1TimeoutEn;
    rmClrL1Timeout;    // clr int
// #if (!_SM226X_A0)
//    rmClrAllPrpListErr;
// #endif
    initNvmeIp();    // Re-initialize NVMe logic after reset
    mNvmeClrRst;    // clear f/w flag
    LLOG_SAVE(cLogHost, NVMECTRL_C, 1, cSaveIdNvmeResetDone, " NVMe Reset done, Link State=0x%04X ", rmDetectLinkState);
}    /* handleNvmeReset */

void handlePcieReset(BYTE uResetType)
{
    rmClrL1AutoGatePclk;    // disable Gating funtion for AMD cpu warmboot test F.J.Kuo_20190905(solution2)
    rmSetPcieDoNotEnterL1;    // kepp L0 while pcie reset for AMD CPU warmboot test F.J.Kuo_20190911(solution1)

    if(mNvmeChkNssr)
    {
        rmSetTargetSpeed(0x01);
        rmClrDirSpdChg;
        rmSetDirSpdChg;

        while((rmDetectLinkState!=0x11)&&
              (rmDetectLinkState!=0x05)&&
              (rmDetectLinkState!=0x00)&&
              rmChkPerstDeassert
              )
            ;

        NLOG(cLogHost, NVMECTRL_C, 1, " NSSR occurred, Link State=0x%04X", rmDetectLinkState);
    }

    if(uResetType==cPciePerstReset)    // PERST or NSSR
    {
        rmSetPcieAppCtrlAppLtssmEn(0);    // Disable LTSSM
    }
    else    // Link Down and HotReset
    {
        rmSetAutoFlushEn;    // 20190521_LeverYu_PS3 APST abort

        // FW2-1298,Normally we will disable ASIC Flush function to let FW can normally access PCIE resister.
        // To control ASIC Flush function timing, FW will start ASIC Flush function again until FW enter _HandlePcieRest
        // ASIC Flush will be disable in Init_PCIe()
    }

    // actions while CC.EN falling edge
    resetNvmeIp();    // reset NVMe before reset PCIE is a must

    if(uResetType==cPciePerstReset)    // PERST or NSSR
    {
#if 0    // Here is unuse for Sam debug
        if(uResetType==cPciePerstReset)    // PERST or NSSR
        {
            if(mPcieChkLinkDis)    // need to remove for 2263??
            {
                rmSetCoreRst;
                rmSetNonStickyRst;    // rmSetPmCtrlNoSoftReset(1); //2263 , //reset only non sticky reg for CV tes

                while(!rmChkPerstDeassert)
                    ;// Make sure PERST has been de-asserted

                sysDelay(10);
                rmClrNonStickyRst;    // rmSetPmCtrlNoSoftReset(0); //2263
                rmClrCoreRst;
            }
            else
#endif
        {
            rmSetPhyRst;
            rmSetFwPeRst;
            rmSwFwModePeRst;
            sysDelay(2);
            rmPclkPolarSelClr;

            while(rmChkPclkReady)
                ;

            sysDelay(2);
            rmClrPhyRst;
            sysDelay(255);
            rmPclkPolarSelSet;
            sysDelay(2);
            rmClrFwPeRst;
            // rmSwHwModePeRst; //????

            //// rmSetPhyRst;  //remove for 2263, sam
            //
            // while(!rmChkPerstDeassert)
            //    ;// Make sure PERST has been de-asserted
            //
            // sysDelay(10);
            //// rmClrPhyRst; //remove for 2263, sam
        }

        // if(mNvmeChkNSSR)
        // {
        //    // in A1, HW will do reset by itself when PERET, but NSSR still need FW to handle, Jack will check it when A1 back
        //    // rmSetPhyRst;
        //
        //    while(!rmChkPerstDeassert)
        //        ;// Make sure PERST has been de-asserted
        //
        //    sysDelay(10);
        //    // rmClrPhyRst;
        // }
        // else
        // {
        //    while(!rmChkPerstDeassert)
        //        ;// Make sure PERST has been de-asserted
        // }

        mPcieClrPerst;
        mNvmeClrNssr;
        rmClrLinkRstDetect;    // clear PCI-e link down reset source

        if(gsLightSwitch.usPhyLs.u16CustomizeF&cEarlyPCIeResetEn)    // EarlyPCIeResetEn, 2263
        {
            rmClrLtssmIntr2;
        }

        mPcieClrRst;    // cleaer PCI-e link down reset f/w flag
    }
    else    // if(uResetType == PCIE_LINK_DOWN_RESET)
    {
        // Handle PCIe Link Reset
#if 0
        rmSetPcieAppCtrlCfgLinkRstDlyEn(0x01);
        sysDelay(10);
        rmSetPcieAppCtrlCfgLinkRstDlyEn(0x00);
#else
        rmLinkRstDlyDis;    // CSSD-4804 RDT stuck in while(M_Chk_PCLK)
                            // No delay assert core reset after link down event occurred.
        sysDelay(40);
        rmSetPcieAppCtrlAppLtssmEn(0);    // Disable LTSSM
        rmLinkRstDlyEn;    // CSSD-4804 RDT stuck in while(M_Chk_PCLK)
#endif
        mPcieClrRst;    // cleaer PCI-e link down reset f/w flag
    }

    rmPcieForceLeaveL1;

    while(!rmChkPclkReady)
        ;

    rmPcieDisForceLeaveL1;
    rmClrPcieDoNotEnterL1;    // Sync 2262HH

    if((uResetType==cPciePerstReset)&&(!mPcieChkLinkDis))    // PERST
    {
#if _ENABLE_PCIE_LS
        rmSetPcieLinkCtrl2(gsLightSwitch.usPcieLs.usLinkCapLs.u32All);    // 3 //Just Init after PERST# was asserted
#else
        rmSetPcieLinkCtrl2(3);    // (gparLS_PCIe->LinkCapLs.MaximumLinkSpeed); //Just Init after PERST# was asserted
#endif
    }

    if(mPcieChkLinkDis)
    {
        mPcieClrLinkDis;
    }

    initPcie();
    handleNvmeReset();    // This function will reset g32NvmeCondition to '0'

    while(!rmChkPerstDeassert)
        ;// Make sure PERST has been de-asserted

    // Enable LTSSM
    rmSetPcieAppCtrlAppLtssmEn(0x01);    // R_PCIeDev.DevMacAppCtrl->APP_LTSSM_EN = 0x01;

    // Set PCIe interrupt
    // only need to clear once at power on M_PCIe_Intr0_Sts_Init;      //Initialize Int status reg
    rmSetLinkRstDetectEn;    // Enable PCIe Link Down interrupt
    rmSetLtrEnChangeEn;    // (Sam) interrupt, same VIC with link down, PCIe-
    rmSetBusMaterChangeEn;
    rmSetPcieDstateChangeIntrEn;    // (Sam)Enable D state change interrupt. It is for LTR PCIe compliance Test.

    if(gsLightSwitch.usPhyLs.u16CustomizeF&cEarlyPCIeResetEn)    // EarlyPCIeResetEn , 2263
    {
        rmSetLtssmIntr2En;    // 2263
    }

    g32LtrValue0=0;
    g32LtrValue2=0;
    gLtrEnabled=0;
    gChgtoD0=0;
#if _SM226X_A0
    gMsixTableFlag=0;
#endif

#if _ACER_ESD_ONELANE    // Sam Test Code for Acer platform
    rmSetLtssmTraceIntr0En;    // enable PCIe link interrupt
#endif

#if _2260PCIE_WORKAROUND
    rmSetLtssmTraceIntr0En;    // enable PCIe link interrupt
#endif
}    /* handlePcieReset */

void handleFlr()
{
    // clear BAR to avoid host keep issuing cmd
    // Reset BAR0 and 1;
    // 0x50001018>> reset 23~0;

    rmSetAllQueStopFetchCmd;    // Sync NH
    rmBgRstEn;    // Sync NH

    // Sync NH, not sure that is any side effect for CV FLR, but current test is pass for CV/Oakgate FLR.
    // rmSetAppFlrPfDone;    // new patch from Sam for Ulink FLR test fail.

    rmClrPcieBarAddr(0x0, 0x00000000);
    rmClrPcieBarAddr(0x1, 0x00000000);
    rmClrPcieBarAddr(0x2, 0x00000000);

    // resetNvmeIp();  //move to handleNvmeCondition, Chronos 49/50

    // handleNvmeReset(); //move to handleNvmeCondition, Chronos 49/50

    // 0x50001004 >> reset bit 10 8, 6, 2, 1 and 0;
    rmSetIose(0);
    rmSetMse(0);
    rmSetBme(0);
    rmSetPee(0);
    rmSetSee(0);
    rmSetId(0);

    // 0x5000100C>> reset bit 7~0;
    rmSetCacheLineSize(0x00);    // R_PCIeDev.PCIeHeader->CacheLineSize = 0x00;

    // Reset ROM BAR;
    rmSetEprom(0x00000000);    // Clear OP ROM Mask

    // 0x5000103C>> reset bit 7~0;
    rmClrPcieIntr;

    // 0x50001044>> reset bit 15 and 1~0
#if _EN_D3Hot_PS4
    rmSetPmCtrlNoSoftReset(1);
#endif    // _EN_D3Hot_PS4
    rmSetPmCtrlPowerState(0);
    rmSetPmCtrlPmeStatus(0);

    // 0x50001054>> reset bit 31~2 (MSI)
    rmSetMsiLower32BitsAddress(0);

    // 0x50001058>> reset bit 31~0
    rmSetMsiUpper32BitsAddress(0);

    // 0x5000105C>> reset bit 31~0
    rmSetMsiData(0);

    // 0x50001074>> reset bit 11~0, 15, and 28;
    // max payload size
    rmSetPcieDeviceCapMaxPayloadSizeSupported(gsLightSwitch.usPcieLs.usDeviceCapLs.u16All&0x00000007);    // 128/256/512 bytes max payload size

    rmSetPcieDeviceCapPhantomFunctionsSupported(0);    // No Function Number bits are used for Phantom Functions

    rmSetPcieDeviceCapExtendedTagSupported(0);    // 0b 5-bit Tag field supported

    rmSetPcieDeviceCapL0sAcceptableLatency(gsLightSwitch.usPcieLs.usDeviceCapLs.u16All&0x000001C0);    // No Limit

    rmSetPcieDeviceCapL1AcceptableLatency(gsLightSwitch.usPcieLs.usDeviceCapLs.u16All&0x00000E00);    // No Limit

    rmSetPcieDeviceCapRoleBasedErrorReporting(cSupported);    // Support
#if _PCIE_FUN_LVL_RST
    rmSetPcieDeviceCapFunctionLevelResetCapability(cSupported);    // Support
#else
    rmSetPcieDeviceCapFunctionLevelResetCapability(cNotSupported);    // not Support
#endif

    // 0x50001078>> reset bit 19~0;
    rmCorrectableErrorEnable(0);
    rmNonFatalErrorEnable(0);
    rmFatalErrorEnable(0);
    rmUnsupportedRequestErrorEnable(0);
    rmEnableRelaxedOrder(1);    // 0);

    rmExtendedTagEnable(0);
    rmPhantomFunctionsEnable(0);
    rmAuxPowerEnable(0);
    rmNoSnoopEnable(0);
    rmMaxReadRequestSize(2);    // 0);
    rmBridgeConfigRetryEnable(0);
    rmCorrectableErrorDetected(0);
    rmNonFatalErrorDetected(0);
    rmFatalErrorDetected(0);
    rmUnsupportedRequestDetected(0);

    // 0x50001098>> reset bit 14~13, 10 and 4~0
    rmCompletionTimeoutValue(0);
    rmCompletionTimeoutDisable(0);
    rmLtrMechanismEnable(0);
    rmObffEnable(0);

    // 0x500010B0>> reset bit 31, 30 and 26~16; (MSIX)
    rmSetMsixCtrlRegTableSize(gsLightSwitch.usPcieLs.usMessageCtrlLs.u16All&0x07FF);
    // Supports 8
    // vecotrs in A0; 16 in A1
    rmSetMsixCtrlRegFunctionMask(0);
    rmSetMsixCtrlRegMsixEnable(0);

    // new patch from Sam for CV&Ulink FLR test fail.
    // APSM shall be disabled after FLR
    rmClrHostEnAspm;
    rmClrHostEnAspmL11L12;

    rmEnPcieDbiroWrite;    // NVMe Only

    // MSIX table shall be reset by FW after FLR
    rmSetMsixTableOffset(0x2000>>3);    // R_PCIeDev.DevPCIeMSIX->MessageTable.TableOffset  = (0x2000>>3);  //2263
    rmSetPbaMsixTableOffset(0x2100>>3);    // R_PCIeDev.DevPCIeMSIX->PBATable.TableOffset = (0x2800>>3);	     //2263

    if(gsLightSwitch.usNvmeLs.uComplianceTest&cPcie30)
    {
        rmSetStatusReg(0x0010);
    }

    // restore capability list
    rmPowerManagementCapNextPtr(0x50);
    rmSetMsiCapNextPtr(0x70);
    rmPcieCapNextPtr(0xB0);
    rmSetMsixCapNextPtr(0x00);
    rmSetAdvancedErrorReport(0x15820001);    // Turn-off power budget function
    rmSetL1PmSubstate(0x0001001E);    // Turn-off DPA function

    rmDisPcieDbiroWrite;    // NVMe Only

    // 0x5000117C>> reset bit 28~16 and 12~0 (LTR)
    rmClrLtrMaxSnoopLatency;
    rmClrLtrMaxNoSnoopLatency;
}    /* handleFlr */

void handleShn()
{
    if(rmChkShutdownNotify)    // 00: No notification, 01: Normal shutdown notification , 10: Abrupt shutdown notification
    {
        if(!rmChkCmdRdy)
        {
            // handle NVMe shutdown until all command finished
            // rmSetAllQueStopFetchCmd;
            mNvmeClrShn;    // Clear f/w flag
            rmSetShstComplete;
            LLOG(cLogHost, NVMECTRL_C, 1, " Shutdown complete, Link State=0x%04X ", rmDetectLinkState);
        }
    }
    else
    {
        mNvmeClrShn;    // Clear f/w flag
        rmSetShstNormal;
    }

    if(mNvmeChkShnEntry)
    {
        mNvmeClrShnEntry;
    }

    gFWShnFlag=1;
}    /* handleShn */

void handleNvmeCondition()
{
    BYTE uBackUpRstType=0;

    if(mPcieChkRst    /*link down*/||mPcieChkPerst||mNvmeChkNssr||mPcieChkFlr)
    {
        if(mPcieChkRst||mPcieChkPerst||mPcieChkFlr)
        {
            uBackUpRstType=cBit0;
        }

        if(mPcieChkPerst||mNvmeChkNssr)
        {
            tracePcieEvent(0xA0);
#if _EN_Delay_Dis_LTSSM
            if(mPcieChkPerst&&(gGCRestFlg==1))
            {
                LLOG(cLogHost, NVMECTRL_C, 0, " PERST Dis LTSSM ");
                gGCRestFlg=0;
                rmPcieAppLtssmDis;    // CSSD-2652
            }
#endif
            // PERST
            handlePcieReset(cPciePerstReset);
        }
        else if(mPcieChkFlr)
        {
            tracePcieEvent(0xA1);
            resetNvmeIp();
            handleNvmeReset();
            mPcieClrFlr;
        }
        else
        {
            tracePcieEvent(0xA2);
            // Link Down Reset
            handlePcieReset(cPcieLinkDownReset);
        }

#if _EN_D3Hot_PS4
        mNvmeClrD3;
#endif    // _EN_D3Hot_PS4
        // rmClrAllQueStopFetchCmd;
        mClrHandlePcieErrF;

        if(rmChkNvmeNSSRO&&uBackUpRstType)    // after firmware commit activation, the NSSRO must clear 0 for Jira 8
        {
            rmClrNvmeNSSRO;
        }
    }

    // NVMe disable notice handelr
    if(mNvmeChkRst)
    {
        tracePcieEvent(0xA3);
        // actions while CC.EN falling edge
        resetNvmeIp();
        handleNvmeReset();

        // rmClrAllQueStopFetchCmd;
        mClrHandlePcieErrF;
        // rmClrNvmeNSSRO;
    }

    if(mChkFwActivate)
    {
        rmSetPp;
        NLOG(cLogBuild, NVMECTRL_C, 0, " rmSetPp ");
#if ((OEM==VERIFY)||(OEM==STD))    // 20190722_SamHu_01 Modify for Devx
        rmClrNvmeNSSRO;
#endif
        activateIspCore0();
        // rmClrPp;

        if(!mChkActivateFail)
        {
            resetFwDlFlow(0xAA);
            mClrFwActivate;

            if(((gsSmart.usStatus.uNextFwSlot+1)>=cNextActiveFirmwareSlot1)
               &&((gsSmart.usStatus.uNextFwSlot+1)<=cNextActiveFirmwareSlot7))
            {
                gsSmart.usStatus.uCurrFwSlot=gsSmart.usStatus.uNextFwSlot;
                gsSmart.usStatus.uNextFwSlot=cNoNextActiveFirmwareSlot;
                saveSmartInfo(cUpdateSlotInfo);
            }

            waitAllChCeBzCore0();
            rmVic0IrqClr;    // __disable_irq();
#if ((OEM!=VERIFY)&&(OEM!=STD))
            rmClrNvmeNSSRO;
#endif
            resetCpuFwCommit(cResetCpuSrst);    // resetCpu(cResetCpuSrst);
        }
        else
        {
            resetFwDlFlow(0xAB);
            mClrFwActivate;
            rmClrPp;
        }
    }

    // NVMe shutdown notice handler
    if(mNvmeChkShn)
    {
        tracePcieEvent(0xA4);
        handleShn();
    }

    // NVMe enable notice handler
    if((!mNvmeChkRst)&&(mNvmeChkCcEnOn))
    {
        tracePcieEvent(0xA5);

        // actions while CC.EN rising edge
        if(rmChkCcEn)    // correct judgment
        {
            tracePcieEvent(0xA6);
            initNvmeGlobVar(1);
            rmAllDmaEngineEn;    // CSSD-2605

            // gNvmePowerState.APSTState.APSTE = 0;  //future to implement
            rmSetCcRdy;    // HW will pull CC_RDY to low automatically
#if _RR_WORKAROUND
            rmSetCcAms;    // remove for 2263
#endif
            LLOG(cLogHost, NVMECTRL_C, 1, " NVMe EN (set cc_rdy),  Link State=0x%04X ", rmDetectLinkState);
            LLOG(cLogHost, NVMECTRL_C, 2, " PCIe Link Status : GEN=0x%04X , LANE=0x%04X", rmCheckCurrentSpeed, rmCheckCurrentLinkWidth);

            gsDebugInfo.u32CcRdyTime=getRtcCurrent32k();

            if(!gsDebugInfo.u32CcRdyFirstTime)    // for debug
            {
                gsDebugInfo.u32CcRdyFirstTime=gsDebugInfo.u32CcRdyTime;
            }
        }

#if (!_ENABLE_UPDATE_NVMEFEATSETTING_INISR)
        updateNvmeFeatureSetting();
#endif

        if(gsFwDlInfo.u32IspCodePerEndOffset)
        {
            resetFwDlFlow(0xFF);
        }

        if(((gsCurrDstResult.uDstStatus>>4)==cOperationShortDstInProgress)
           &&(!(gsCurrDstResult.uDstStatus&0x0F)))
        {
            gsCurrDstResult.uDstStatus|=cOperationAbortControllerLevelReset;
        }

        mNvmeClrCcEnOn;    // Clear f/w flag
        // rmClrNvmeNSSRO;
    }

#if _EN_D3Hot_PS4
    if(mNvmeChkD3)
    {
        if(rmChkShstComplete)
        {
            gsPowerState.uFeatVal.u32Current=cPs4;
            gsPowerState.uDevNextPs=cPs4;
            mPSChgSetPs34;
            gLowPowerStateRetryCnt=0;
        }

#if _EN_D3Hot_DisPS34    // for edevx script
        else if(gsPowerState.uPsChg||((gsPowerState.uFeatVal.u32Current&cPowerStateMask)>cPs2))
        {
            mPSChgClrPs34;
            gLowPowerStateRetryCnt=3;
        }
#endif    // #if _EN_D3Hot_DisPS34
        mNvmeClrD3;
    }

    if(mNvmeChkD0)
    {
        gsPowerState.uFeatVal.u32Current&=cPowerStateMaskClr;
        gsPowerState.uFeatVal.u32Current|=(LWORD)gsPowerState.uHostLastPs;
        gsPowerState.uDevNextPs=gsPowerState.uHostLastPs;

        if(gsPowerState.uDevNextPs<cPs3)
        {
            mPSChgClrPs34;
        }
        else
        {
            mPSChgSetPs34;
        }

        mNvmeClrD0;
    }
#else/* if _EN_D3Hot_PS4 */    // only verify STD
#if _EN_D3Hot_DisPS34    // for edevx script
    if(mNvmeChkD3)
    {
        if(gsPowerState.uPsChg||((gsPowerState.uFeatVal.u32Current&cPowerStateMask)>cPs2))
        {
            mPSChgClrPs34;
            gLowPowerStateRetryCnt=3;
        }

        mNvmeClrD3;
    }
#endif   // #if _EN_D3Hot_DisPS34
#endif    // _EN_D3Hot_PS4
}    /* handleNvmeCondition */

void chkNvmeIdle(BYTE uIdleBitmap)
{
    BYTE uQID;

    uIdleBitmap=(~uIdleBitmap);    // become busy bitmap

    if(uIdleBitmap&cBit7)
    {
        for(uQID=0; uQID<(cMaxIoSqCqCnt+1); uQID++)
        {
            if(rmGetCqHeadDoorBell(uQID)!=rmGet2263CqTailDoorBell(uQID))
            {
                NLOG(cLogPS, NVMECTRL_C, 3, " CQ busy: QID=0x%04X, HeadDB=0x%04X, TailDB=0x%04X ", uQID, rmGetCqHeadDoorBell(
                         uQID), rmGet2263CqTailDoorBell(uQID));
                return;
            }

            if(rmGetSqTailDoorBell(uQID)!=rmGet2263SqHeadDoorBell(uQID))
            {
                NLOG(cLogPS, NVMECTRL_C, 3, " SQ busy: QID=0x%04X, TailDB=0x%04X, HeadDB=0x%04X ", uQID, rmGetSqTailDoorBell(
                         uQID), rmGet2263SqHeadDoorBell(uQID));
                return;
            }
        }
    }
    else if(uIdleBitmap&cBit6)
    {
        NLOG(cLogPS, NVMECTRL_C, 0, " busy: sq_cmd_buf ");
    }
    else if(uIdleBitmap&cBit5)
    {
        NLOG(cLogPS, NVMECTRL_C, 0, " busy: hwcq ");
    }
    else if(uIdleBitmap&cBit4)
    {
        NLOG(cLogPS, NVMECTRL_C, 0, " busy: dmacq ");
    }
    else if(uIdleBitmap&cBit3)
    {
        NLOG(cLogPS, NVMECTRL_C, 0, " busy: fwcq ");
    }
    else if(uIdleBitmap&cBit2)
    {
        NLOG(cLogPS, NVMECTRL_C, 0, " busy: fwrq ");
    }
    else if(uIdleBitmap&cBit1)
    {
        NLOG(cLogPS, NVMECTRL_C, 0, " busy: prd ");
    }
    else if(uIdleBitmap&cBit0)
    {
        NLOG(cLogPS, NVMECTRL_C, 0, " busy: unex_engine ");
    }
}    /* chkNvmeIdle */

BYTE chkHostIdle(BYTE uOutputLog)
{
    BYTE uIdle=0;

    // dbPatch();

    // if(!rmChkAuxNvmeIdle)
    // rmChkAuxNvmeIdle doesn't include CQ check, so need a separate check for CQ
    if(!chkNvmeAllIdle())
    {
        if(uOutputLog)
        {
            NLOG(cLogPS, NVMECTRL_C, 1, " chkHostIdle busy: NVMe Idle Bitmap=0x%04X ", rmGetNvmeIdle);
            chkNvmeIdle(rmGetNvmeIdle);
            // NLOG(cLogPS, NVMECTRL_C, 2, " chkHostIdle busy: Admin CQ Head(0x%04X)!= Tail(0x%04X) ", rmGet2263IntSqHeadDoorBell(0),
        }
    }
    else if(rmChkCmdRdy)
    {
        if(uOutputLog)
        {
            NLOG(cLogPS, NVMECTRL_C, 0, " chkHostIdle busy: Get new cmd ");
        }
    }
    else if(rmChkNvmeResetInt)
    {
        // NVMe event
        if(uOutputLog)
        {
            NLOG(cLogPS, NVMECTRL_C, 0, " chkHostIdle busy: NVMe reset ");
        }
    }
    else if(rmChkNvmeShnChangeInt)
    {
        // NVMe event
        if(uOutputLog)
        {
            NLOG(cLogPS, NVMECTRL_C, 0, " chkHostIdle busy: NVMe shutdown ");
        }
    }
    else if(rmChkLinkRstDetect)
    {
        // PCIe event
        if(uOutputLog)
        {
            NLOG(cLogPS, NVMECTRL_C, 0, " chkHostIdle busy: PCIe link down ");
        }
    }
    else if(mGpioP1GetIsrState(0x01))
    {
        // PERST
        if(uOutputLog)
        {
            NLOG(cLogPS, NVMECTRL_C, 0, " chkHostIdle busy: PCIe reset-P11");
        }
    }
    else if(pendingAsyncEvent())
    {
        if(uOutputLog)
        {
            NLOG(cLogPS, NVMECTRL_C, 0, " ChkHostIdle busy: Pending AER ");    // busy:PendingAER
        }
    }
    else if((gsFwDlInfo.uFidStatus&cFidUnderProcess)&&((gsPowerState.uDevNextPs==cPs4)    /*||(gsPowerState.uDevNextPs==cPs3p5)*/))
    {
        if(uOutputLog)
        {
            NLOG(cLogPS, NVMECTRL_C, 0, " ChkHostIdle busy: FW download ");    // busy:FW download
        }
    }
    else
    {
        uIdle=1;
    }

    return uIdle;
}    /* chkHostIdle */

void manualCompletion(WORD u16StatusCode, LWORD u32CmdSpecific, BYTE uCmdType, BYTE uPrdIdx)
{
    LWORD u32TempBuf0=0, u32TempBuf1=0, u32TempBuf2=0, u32TempBuf3=0;
    BYTE uError=0;
    BYTE uPopNextCmd=cTrue;

    // Note; DW0~3 use same register offset, fw need to fill value in order and hw auto trigger after filling four times
    // wait completion queue is free
    while(rmChkFwCqFull)
        ;

    // DW 0
    u32TempBuf0=u32CmdSpecific;

    switch(uCmdType)
    {
        case cRwCmd:
            // DW 1
            u32TempBuf1=(gsPrdInfo.uarPrdQue[uPrdIdx].u16CqId|(uCmdType<<16));
            // DW 2
            u32TempBuf2=(gsPrdInfo.uarPrdQue[uPrdIdx].u16SqId<<16);
            // DW 3
            u32TempBuf3=((u16StatusCode<<17)|(gsPrdInfo.uarPrdQue[uPrdIdx].u16Cid));

            uPopNextCmd=cFalse;    // RW command already pop next cmd in pushIOCmd2PrdInfo()
            break;

        case cAbortCmd:
            // Abort (1)
            // DW 1
            u32TempBuf1=(rmNvmeCqId|(uCmdType<<16));
            // DW 2
            u32TempBuf2=(rmNvmeSqId<<16);
            // DW 3
            u32TempBuf3=(u16StatusCode<<17)|(rmNvmeCid);

            // NVMeGetAbortCmdResponse(&u32TempBuf1, &u32TempBuf2, &u32TempBuf3, cAbortCmd, uPrdIdx, u16StatusCode);
            // uPopNextCmd = TRUE; //RW command already pop next cmd in pushIOCmd2PrdInfo()
            break;

        case cAsyncCmd:
            // DW 1
            u32TempBuf1=(gsNvmeAer.uarAsyncQueue[uPrdIdx].u16CqId|(uCmdType<<16));
            // DW 2
            u32TempBuf2=(gsNvmeAer.uarAsyncQueue[uPrdIdx].u16SqId<<16);
            // DW 3
            u32TempBuf3=((u16StatusCode<<17)|(gsNvmeAer.uarAsyncQueue[uPrdIdx].u16Cid));

            uPopNextCmd=cFalse;    // Async command already pop next command at first((gparLS_Nvme->uAERL +1)), and wait for completion.
            break;

        case cDeleteQCmd:
            // DW 1
            u32TempBuf1=(uCmdType<<16);
            // DW 2
            u32TempBuf2=0x0<<16;
            u32TempBuf3=(u16StatusCode<<17)|(rmNvmeCid);
            uPopNextCmd=cFalse;
            break;

        // case cCreateQCmd:
        //
        //    rNvme0[rcCmdDw0]=rmNvmeOpCode;
        //    r32Nvme0[rcCmdDw10/4]=rmNvmeCmdDw10;
        //    r32Nvme0[rcCmdDw11/4]=rmNvmeCmdDw11;
        //    r32Nvme0[rcCmdPrp1Low/4]=rmNvmePrp1Low;
        //    r32Nvme0[rcCmdPrp1High/4]=rmNvmePrp1High;
        //    rmSetCreateSqCq;
        //    // DW 1
        //    u32TempBuf1=rmNvmeCqId;
        //    // DW 2
        //    u32TempBuf2=rmNvmeCqId<<16;
        //    // DW 3
        //    u32TempBuf3=(u16StatusCode<<17)|(rmNvmeCid);
        //
        //    uPopNextCmd=cTrue;
        //    break;

        case cNoRwCmd:
            // DW 1
            u32TempBuf1=rmNvmeCqId;    // (rmNvmeCqId|(uCmdType<<16));
            // DW 2
            u32TempBuf2=(rmNvmeSqId<<16);
            // DW 3
            u32TempBuf3=((u16StatusCode<<17)|rmNvmeCid);
            break;

        default:
            uError=1;
            break;
    }    /* switch */

    if(!((u16StatusCode==cStatusIntelPeekPoke)||(u16StatusCode==cStatusSuccess)))
    {
        // DebugLog(C_LOG_Host, 0x2D, 3, u32TempBuf3>>17, u32TempBuf3&0xFFFF, u32TempBuf2>>16, 0, 0); //Error Complete, SF=0x%04X, CID=0x%04X,
        // SQID=0x%04X
        // DebugLog(C_LOG_Host, 0x2E, 2, u32TempBuf1&0xFFFF, u32TempBuf1>>16, 0, 0, C_SaveID_ErrorComplete);//Error Complete, IP info,
        // CQID=0x%04X, Cmd Type=0x%04X
        NLOG(cLogComErr, NVMECTRL_C, 1, " Error Completion=0x%04X ", u16StatusCode);
//        rmUartTxWord(rmNvmeOpCode); rmUartTxLword(rmNvmeCmdDw10);  // rmUartTxLword(rmNvmeCreateqCmd11);//Add debug message
    }

    if(u16StatusCode)
    {
        if(((u16StatusCode&0x700)>>8)==cStatusMediaErr)
        {
            gsSmart.usCnt.u64MediaDataIntegrityErr++;
            addErrorLog(u16StatusCode, uPrdIdx, cIoCommandError);
        }
        else if(u16StatusCode==cStatusDataXfrErr)
        {
            if(uCmdType==cRwCmd)
            {
                addErrorLog(u16StatusCode, uPrdIdx, cIoCommandError);
            }
            else
            {
                if(rmNvmeSqId)    // IO command
                {
                    addErrorLog(u16StatusCode, uPrdIdx, cIoCommandError);
                }
                else
                {
                    addErrorLog(u16StatusCode, uPrdIdx, cAdminCommandError);
                }
            }
        }
    }

    if(uError)
    {
        gsFtlDbg.u16DummyFailType=cManualCompletion;
        debugWhile();    // undefined type
    }

    // if(uCmdType==cAsyncCmd)
    // {
    //    addCqPtrBy1(0);
    // }

    // if(uCmdType!=cDeleteQCmd)
    {
        trigCompletion(u32TempBuf0, u32TempBuf1, u32TempBuf2, u32TempBuf3, uPopNextCmd);
    }
#if 0    // 2263
    else    // CSSD-2575---Start
    {
        while(!gDelSqCnt)
            ;

        while(gDelSqCnt)    // CSSD-3147, CSSD-3149 and CSSD-3360, Fix issue that delete SQ cause false alarm invalid doorbell event
        {
            LWORD u32Cnt=0;
            LWORD u32PreTail=0, u32CurTail=0;
            WORD u16CqId, u16SqToBeDeleted;

            u32TempBuf3=(u16StatusCode<<17)|(garDelSqInfo[gDelSqTail].u16Cid);
            u16SqToBeDeleted=u32TempBuf0=garDelSqInfo[gDelSqTail].u16DelSqId;

            u16CqId=rmGetParingCq(u16SqToBeDeleted);

            // CSSD-2086
            // if(gsLightSwitch.usNvmeLs.uDoorBellPatch)
            // {
            //    // uCqId = M_Get_Paring_CQ(u16SqToBeDeleted);
            //    if(!checkCqShared(u16CqId))
            //    {
            //        g16arCommandCount[u16SqToBeDeleted]=0;
            //        g16CheckDbFlagBitmap|=cb16BitTab[u16SqToBeDeleted-1];
            //    }
            //
            //    g16ValidCqBitmap&=~(cb16BitTab[u16CqId-1]);
            // }

            trigCompletion(u32TempBuf0, u32TempBuf1, u32TempBuf2, u32TempBuf3, uPopNextCmd);

            while((rmGetNvmeSqEn&cbBitTab[u16SqToBeDeleted-1]))
                ;

            // DebugLog(C_LOG_Host, 0x6B, 4, u16SqToBeDeleted, u16CqId,g16arCommandCount[u16SqToBeDeleted], g16ValidCqBitmap, 0);
            // Trig SQ complete, SQ=0x%04X, CQ=0x%04X, CmdCnt=0x%04X, ValidCQBitmap=0x%04X

            u32CurTail=u32PreTail=rmGetSqTailDoorBell(u16SqToBeDeleted);

            while((u32Cnt<50000)&&(rmGetNvmeCqEn&cbBitTab[u16CqId-1]))
            {
                u32CurTail=rmGetSqTailDoorBell(u16SqToBeDeleted);

                if(u32CurTail!=u32PreTail)
                {
                    u32Cnt=0;
                    u32PreTail=u32CurTail;
                }
                else
                {
                    u32Cnt++;
                }
            }

            rmSetSqTailDoorBell(u16SqToBeDeleted, 0x0);    // update tail db to block controller from receiving more cmds.
            gDelSqTail=addPtrBy1(gDelSqTail, cMaxIoSqCqCnt);
            gDelSqCnt--;
        }

        // rmClrNvmeInvDb(0xFFFFFFFF);
        rmClrNvmeInvSqDbAll;    // rmClrNvmeInvSqDb(0xFFFFFFFF);
        rmClrNvmeInvCqDbAll;    // rmClrNvmeInvCqDb(0xFFFFFFFF);
        rmClrNvmeInvDbWriteInt;
        rmNvmeInvDbWriteEn;
        // gDelSqCnt =0;
        gDelWaitCnt=0;
    }    // CSSD-2575---End
#endif/* if 0 */
}    /* manualCompletion */

void trigCompletion(LWORD u32DWORD0, LWORD u32DWORD1, LWORD u32DWORD2, LWORD u32DWORD3, BYTE uPopNextCmd)
{
    // WORD u16CqId=rmNvmeCqId;

    if(uPopNextCmd)
    {
        // Write FUA/UNC command don't need to pop next cmd at here
        // Pop Next Cmd
        rmPopNextCmd;
        // addCqPtrBy1(u16CqId);
    }

    // Note; DW0~3 use same register offset, fw need to fill value in order and hw auto trigger after filling four times
    // DW 0
    rmSetFwCqRspDw(u32DWORD0);
    // DW 1
    rmSetFwCqRspDw(u32DWORD1);
    // DW 2
    rmSetFwCqRspDw(u32DWORD2);
    // DW 3
    rmSetFwCqRspDw(u32DWORD3);
}    /* trigCompletion */

BYTE trigNonRWCmd(volatile WORD u16BufSecIdx, volatile WORD u16SecCnt, volatile BYTE uTSBx, volatile BYTE uDir, volatile BYTE uManualCompletion)
{
    WORD u16PartialSecCnt=0;
    BYTE uPrdIdx=0, uNonSecAlignXfer=0;    // non ISP mode force to use prdIdx=0

    uPrdIdx=getFreeHwPrd();
    gsPrdInfo.u16arIdxToPrdInfo[uPrdIdx]=c16Null;    // use 0xFF to represent Admin cmd or debug

    if(u16SecCnt==0)    // non-sector based transfer for get error logs and get feature apst
    {
        if((rmNvmeFid==cNvmeFeatAutoPst)&&(rmNvmeOpCode==cNvmeCmdGetFeatures))    // if apst
        {
            u16SecCnt=1;
        }
        else if((rmNvmeOpCode==cNvmeCmdSecurityRecv))    // if Security Recv
        {
            u16SecCnt=g32ReceivedXfrCnt;
        }
        else    // must be get error log
        {
            u16SecCnt=(rmNvmeGetLogNumDw>>7);

            if(rmNvmeGetLogNumDw&0x7f)
            {
                u16SecCnt++;
            }
        }

        uNonSecAlignXfer=1;
    }
    else if(uManualCompletion&cMultiPrd)
    {
        u16PartialSecCnt=u16SecCnt;
        u16SecCnt=rmNvmeNlb;
    }
    else if(uManualCompletion&cMultiPrdForFd)
    {
        u16PartialSecCnt=u16SecCnt;
        u16SecCnt=((rmNvmeFwImageDlNumDw+127)>>7);
    }

    if(uDir==cNvmeRead)
    {
        setBufStatus(u16BufSecIdx, u16SecCnt, uTSBx);    // Set TSB buf flag
    }

    if(uManualCompletion&(cMultiPrd|cMultiPrdForFd))
    {
        setHwPrd(uPrdIdx, u16BufSecIdx, u16PartialSecCnt, 0, cNonLastPrd, 0);
    }
    else
    {
        setHwPrd(uPrdIdx, u16BufSecIdx, u16SecCnt, 0, 0, 0);
    }

    if(uNonSecAlignXfer)
    {
        u16SecCnt=0;    // represent non sector based transfer type
    }

    if(!(uManualCompletion&cHmbDescList))
    {
        setDesc(uPrdIdx, uDir, u16SecCnt, uManualCompletion);    // Trig and pop next cmd
    }
    else
    {
        // Use read Wpro data, please make sure already read cWproFeaturePg
        r32NvmeDesc[uPrdIdx][1]=0x00000000;
        r32NvmeDesc[uPrdIdx][2]=gpNvmeFeatVar->usHmbHwInfo.u32HmbDescListAddrLow;
        r32NvmeDesc[uPrdIdx][3]=gpNvmeFeatVar->usHmbHwInfo.u32HmbDescListAddrHigh;
        r32NvmeDesc[uPrdIdx][4]=0x00000000;
        r32NvmeDesc[uPrdIdx][5]=0x00000000;
        r32NvmeDesc[uPrdIdx][6]=u16SecCnt<<7;
        r32NvmeDesc[uPrdIdx][7]=0x00000000;
        r32NvmeDesc[uPrdIdx][0]=0x00000105;

        gsDebugInfo.u32LastHwPrdValidTime=getRtcCurrent32k();
    }

    waitHostDone();

    // transfer non-sector aligned payload, to ensure engine proper
    // function, f/w will need to reset Nvme bridge after data transfer
    if(uNonSecAlignXfer)
    {
        rmBgRstEn;
        _nop();
        _nop();
        rmBgRstOff;

        rmResetBufFlg;    // clear TSB buffer flag

        // future to implement
        // Init_Nvme_BufWrap(g32Cache0_Size,g32Cache1_Size,g32DramCacheBias);//re-initialize wraps, since we reset the bridge.
    }

    if(rmChkDpsDppFifoNotEmpty&&!(uManualCompletion&(cMultiPrd|cMultiPrdForFd)))
    {
        releaseFreeHwPrd2();
    }
    else if(mNvmeChkNssr||mPcieChkPerst||mPcieChkRst||mPcieChkFlr||mNvmeChkRst)
    {
        rmBgRstEn;
        _nop();
        _nop();
        rmBgRstOff;

        rmResetBufFlg;    // clear TSB buffer flag
        gsPrdInfo.uarFreeHwPrdQue[gsPrdInfo.uFreeHwPrdHead]=uPrdIdx;
        gsPrdInfo.uFreeHwPrdHead=(gsPrdInfo.uFreeHwPrdHead+1)&(cHwPrdDepth-1);
        gsPrdInfo.uFreeHwPrdCnt++;

        // debug
        // debugChkHwFreePrdQ();
    }
    else if(uManualCompletion&(cMultiPrd|cMultiPrdForFd))
    {
        // bypass, Multi-PRD case, manual release HW PRD
    }
    else
    {
        gsFtlDbg.u16DummyFailType=cTrigNonRWCmd;
        debugWhile();    // For debug
    }

    if(uDir==cNvmeWrite)
    {
        if(uManualCompletion&(cMultiPrd|cMultiPrdForFd))
        {
            setBufStatus(u16BufSecIdx, u16PartialSecCnt, uTSBx);    // Clr TSB buf flag
        }
        else
        {
            setBufStatus(u16BufSecIdx, u16SecCnt, uTSBx);    // Clr TSB buf flag
        }
    }

    return uPrdIdx;
}    /* trigNonRWCmd */

#if 0
void waitBufStatus(WORD u16BufSecIdx, WORD u16SecCnt, BYTE uWait)
{
    // uWait=0 => wait buffer empty / uWait1=1 => wait buffer data ready
    // u16ufSecIdx must align with check buf size
    LWORD u32Pat, u32False;
    BYTE uShift;
    WORD u16ByteIdx;
    BYTE uSecCnt1;

    u16ByteIdx=u16BufSecIdx>>5;    // /8 for Index from 32Byte
    uShift=u16BufSecIdx&0x1F;    // bit offset of 512 byte
    uSecCnt1=32-uShift;

    while(u16SecCnt)
    {
        if(uSecCnt1>u16SecCnt)
        {
            uSecCnt1=u16SecCnt;
        }

        u32Pat=cb32BitNumTab[uSecCnt1];    // bit number for 1k xfr, max page size is 16k
        u32Pat=u32Pat<<uShift;

        u32False=1;

        while(u32False)
        {
            if(!uWait)
            {
                u32False=(rm32BufStatus(u16ByteIdx)&u32Pat);    // uRlt=0 if all check bit become 0
            }
            else
            {
                u32False=((rm32BufStatus(u16ByteIdx)&u32Pat)!=u32Pat);    // uRlt=0 if all check bit become 1
            }
        }

        u16SecCnt-=uSecCnt1;
        u16ByteIdx++;

        if(u16ByteIdx==(cTsb0Size>>5))    // TBD
        {
            u16ByteIdx=0;
        }

        uShift=0;
        uSecCnt1=32;
    }
}    /* waitBufStatus */

#endif/* if 0 */
void setHwPrd(BYTE uHwPrdIdx, LWORD u32BufIdx, LWORD u32HostXfrCnt, LWORD u32LBA, BYTE uOpt, BYTE uOccF)
{
    // Set Buffer location
    LWORD u32Opt=(cTsb|cAutoBufflag);

    if(uOpt&cThroughAes)
    {
        rmAesMode;
        u32Opt|=cAes;
    }

    if(!(uOpt&cNonLastPrd))
    {
        u32Opt|=cLastPrd;
    }

    r32NvmePrd[uHwPrdIdx][0]=u32Opt;

    // Set Occupy flag
#if _ENABLE_OCC_FLAG
    if(uOccF)    // Enable Occupy flg   &  Set  occupy Address inside
    {
        r32NvmePrd[uHwPrdIdx][0]|=cSetTsbOccFlag;
        r32NvmePrd[uHwPrdIdx][3]=(u32BufIdx&~(cSctrPer4k-1));
    }
    else
    {
        r32NvmePrd[uHwPrdIdx][3]=0;
    }
#endif

    r32NvmePrd[uHwPrdIdx][1]=u32BufIdx;    // TSB Address
    r32NvmePrd[uHwPrdIdx][2]=0;

    // Set Transfer count
    r32NvmePrd[uHwPrdIdx][5]=u32HostXfrCnt;    // Transfer Count, sector based unit

    // LBA only for AES used

    r32NvmePrd[uHwPrdIdx][6]=u32LBA;    // LBA Low DW
    r32NvmePrd[uHwPrdIdx][7]=0;    // LBA High DW, set to 0 for now, assume capacity will not be so high
}    /* setHwPrd */

// Controller to Host
void setDesc(BYTE uPrdTag, BYTE uXfrDir, LWORD u32HostXfrCnt, BYTE uManualComplete)
{
    WORD u16SqIdTemp, u16CIdTemp;    // , u16CqId;
    LWORD u32NumDw;

    u16SqIdTemp=rmNvmeSqId;
    u16CIdTemp=rmNvmeCid;
    // u16CqId=rmNvmeCqId;

    // Set Desc
    r32NvmeDesc[uPrdTag][2]=rmNvmePrp1Low;
    r32NvmeDesc[uPrdTag][3]=rmNvmePrp1High;
    r32NvmeDesc[uPrdTag][4]=rmNvmePrp2Low;
    r32NvmeDesc[uPrdTag][5]=rmNvmePrp2High;

    if(u32HostXfrCnt)
    {
        r32NvmeDesc[uPrdTag][6]=u32HostXfrCnt<<7;    // (u32HostXfrCnt*128);    // DMA transfer size: DWord mode
    }
    else    // special cases for get feature apst and get error log
    {
        if((rmNvmeFid==cNvmeFeatAutoPst)&&(rmNvmeOpCode==cNvmeCmdGetFeatures))    // get feature apst
        {
            r32NvmeDesc[uPrdTag][6]=64;    // APST payload is 256 bytes, 64 dwords
        }
        else if((rmNvmeOpCode==cNvmeCmdSecurityRecv))    // if Security Recv
        {
            u32NumDw=(g32ReceivedXfrByte+(4-1))>>2;
#if 0
            if(u32NumDw&cBit0)    // Avoid hardware issue
            {
                u32NumDw++;
            }
#endif
            r32NvmeDesc[uPrdTag][6]=u32NumDw;
        }
        else    // get error log
        {
            u32NumDw=rmNvmeGetLogNumDw;

            // if(rmNvmeGetLogNumDw&cBit0)    // Avoid hardware issue
            // {
            //    u32NumDw++;
            // }

            r32NvmeDesc[uPrdTag][6]=u32NumDw;    // controlled by host
        }
    }

    r32NvmeDesc[uPrdTag][7]=((u16SqIdTemp<<16)|u16CIdTemp);

#if _ENABLE_SGLS
    if(rmNvmeSgl)
    {
        r32NvmeDesc[uPrdTag][1]=(c32Bit25|c32Bit24);    // SGL pointer, SGL
    }
    else
#endif
    {
        // Judge whther PRP2 is valid, set the valid bit
        if(rmNvmePrp2Low||rmNvmePrp2High)
        {
            r32NvmeDesc[uPrdTag][1]=c32Bit25;
        }
        else
        {
            r32NvmeDesc[uPrdTag][1]=0x00000000;
        }
    }

    // Trig
    if(uXfrDir==cNvmeRead)
    {
        if(uManualComplete)    // For UNC cmd
        {
            r32NvmeDesc[uPrdTag][0]=0x0000010D;    // RDMA, Trig, DMA transfer size: DWord mode
        }
        else
        {
            r32NvmeDesc[uPrdTag][0]=0x0000012D;    // Auto Completion, RDMA, Trig, DMA transfer size: DWord mode
        }
    }
    else if(uXfrDir==cNvmeWrite)
    {
        if(uManualComplete)    // For FUA cmd
        {
            r32NvmeDesc[uPrdTag][0]=0x00000105;    // WDMA, Trig, DMA transfer size: DWord mode
        }
        else
        {
            r32NvmeDesc[uPrdTag][0]=0x00000125;    // Auto Completion, WDMA, Trig, DMA transfer size: DWord mode
        }
    }

    gsDebugInfo.u32LastHwPrdValidTime=getRtcCurrent32k();

    if(!uManualComplete)    // Pop Next Cmd
    {
        rmPopNextCmd;
        // addCqPtrBy1(u16CqId);
    }
}    /* setDesc */

void waitHostDone()
{
    while(!(mNvmeChkRst||mPcieChkPerst||mPcieChkFlr||rmChkDpsDppFifoNotEmpty))
        ;
}

BYTE checkIfPrpOverlap(LWORD u32Prp1L, LWORD u32Prp2L, LWORD u32Prp1H, LWORD u32Prp2H, LWORD u32Mask)
{
    if(u32Prp1H==u32Prp2H)
    {
        if((u32Prp1L&u32Mask)==(u32Prp2L&u32Mask))
        {
            return 1;
        }
    }

    return 0;
}

BYTE checkIfNonDWordAligned(LWORD u32Prp1L, LWORD u32Prp2L)
{
    if((u32Prp1L&0x03)||(u32Prp2L&0x03))
    {
        return 1;
    }

    return 0;
}

BYTE validatePrp(BYTE uCmdType)
{
    LWORD u32Prp1L=0, u32Prp2L=0, u32Prp1H=0, u32Prp2H=0, u32HostBuffer=0, u32Mps=0, u32temp, u32Mask, u32Payload;
    BYTE uPrp1NotEmpty=0, uPrp2NotEmpty=0;
    BYTE uError=cPrpNoErr;

    // compute memory page size
    u32Mps=rmGetMps;
    u32temp=12+u32Mps;
    u32Mps=(1<<(u32temp));
    u32Mask=u32Mps-1;

    // get PRP values
    u32Prp1L=rmNvmePrp1Low;
    u32Prp2L=rmNvmePrp2Low;

    u32Prp1H=rmNvmePrp1High;
    u32Prp2H=rmNvmePrp2High;

    if(checkIfPrpOverlap(u32Prp1L, u32Prp2L, u32Prp1H, u32Prp2H, ~(u32Mask))&&(uCmdType!=cValidPrpCreateQueue))    // verify is prp overlaps
    {
        uError=cPrpOverlap;
    }
    else if(checkIfNonDWordAligned(u32Prp1L, u32Prp2L)&&(uCmdType!=cValidPrpCreateQueue))    // verify if prp is qwrod aligned
    {
        uError=cPrpNotAlign;
    }
    else    // PRPs do not overlap; is QWORD aligned; check if host allocate enough buffer
    {
        switch(uCmdType)
        {
            case cValidPrp4kData:
                u32Payload=0x1000;    // Identify cmd payload size is fixed to 4KB
                break;

            case cValidPrpGetLog:
                u32Payload=((rmNvmeGetLogNumDw)<<2);
                break;

            case cValidPrpFwImageDl:
                u32Payload=((rmNvmeFwImageDlNumDw)<<2);
                break;

            case cValidPrpCreateQueue:

                // if (CheckIfNon4KPageAligned(u32Prp1L, u32Prp2L))//verify if prp is 4K page aligned
                if((u32Prp1L&0xFFC)||(u32Prp2L&0xFFC))    // verify if prp is 4K page aligned
                {
                    return cPrpNot4KAlign;    // Oakgate Conformance test 2&3
                }
                else
                {
                    return cPrpNoErr;
                }

            case cValidPrpApst:
                u32Payload=0x100;
                break;

            default:
                break;
        }    /* switch */

        // check PRP 1
        if(u32Prp1L||u32Prp1H)
        {
            uPrp1NotEmpty=1;
            u32Prp1L&=u32Mask;
        }
        else
        {
            uError=cPrp1Empty;    // PRP1 can't be empty
        }

        // check PRP 2
        if(u32Prp2L||u32Prp2H)
        {
            uPrp2NotEmpty=1;
            u32Prp2L&=u32Mask;
        }
        else
        {
            u32Prp2L=u32Mps;
        }

        if(!uError)
        {
            if(u32Payload<=u32Mps)    // if payload is less or equal to MPS; assume PRP2 is not PRP list pointer
            {
                // Total host memory buffer allocated
                u32HostBuffer=(u32Mps-u32Prp1L)+(u32Mps-u32Prp2L);

                if(u32HostBuffer<u32Payload)    // we need at least 4KB memory buffer for Identify command
                {
                    uError=cPrpLessThanPayload;
                }
            }
            else    // if(u32Payload<=(2*u32Mps))
            {
                if(uPrp1NotEmpty&&uPrp2NotEmpty)
                {
                    if(u32Prp2L>(u32Mps-8))
                    {
                        uError=cPrp2LessThanList;
                    }
                }
                else    // not enough space, since payload is bigger than MPS, both PRP1 and PRP2 needs to be non-empty
                {
                    uError=cPrp2Empty;
                }
            }
        }
    }

    if(uError)
    {
        NLOG(cLogHost, NVMECTRL_C, 2, " PRP Error, uCmdType = 0x%04X, uError = 0x%04X ", uCmdType, uError);
        u32Prp1L=rmNvmePrp1Low;
        u32Prp2L=rmNvmePrp2Low;
        u32Prp1H=rmNvmePrp1High;
        u32Prp2H=rmNvmePrp2High;
        NLOG(cLogHost, NVMECTRL_C, 4, " PRP1 HiDWORD=0x%08X,  LoDWORD=0x%08X ", u32Prp1H>>16, u32Prp1H, u32Prp1L>>16, u32Prp1L);
        NLOG_SAVE(cLogHost,
                  NVMECTRL_C,
                  4,
                  cSaveIdPRPError,
                  " PRP2 HiDWORD=0x%08X,  LoDWORD=0x%08X ",
                  u32Prp2H>>16,
                  u32Prp2H,
                  u32Prp2L>>16,
                  u32Prp2L);
    }

    return uError;
}    /* validatePrp */

void chkPcieErrorEvent()
{
    // LWORD u32Cnt;

    if(rmLtssmEntrCnt0||rmEcrcCnt||rmLcrcCnt)
    {
        // below wait to implement
        // u32Cnt = M_LTSSM_Entr_Cnt0;
        // gSMART.g64L1EventCnt += u32Cnt;
        // gTelemetry.g64L1EventCnt += u32Cnt;
        //
        // u32Cnt = M_ECRC_Cnt;
        // gSMART.g64ECRCEventCount += u32Cnt;
        // gTelemetry.g64ECRCEventCount += u32Cnt;
        //
        // if(gparLS_VUID->uOEMID == C_OEMID_OEM3)
        //    g32OEM3PowerOn_LCRC_ECRC_Cnt += u32Cnt;
        //
        // u32Cnt = M_LCRC_Cnt;
        // gSMART.g64LCRCEventCount += u32Cnt;
        // gTelemetry.g64LCRCEventCount += u32Cnt;
        //
        // if(gparLS_VUID->uOEMID == C_OEMID_OEM3)
        //    g32OEM3PowerOn_LCRC_ECRC_Cnt += u32Cnt;

        rmLtssmCnt0Clr;    // clear L0 Cnt register
        rmEcrcCntClr;    // clear ECRC Cnt register
        rmLcrcCntClr;    // clear LCRC Cnt Register

        rmLtssmCnt0DisClr;    // stop clear L0 Cnt register
        rmEcrcCntDisClr;    // stop clear ECRC Cnt register
        rmLcrcCntDisClr;    // stop clear LCRC Cnt Register
    }
}    /* chkPcieErrorEvent */

void initNvmeGlobVar(BYTE uPowerOnInit)
{
    BYTE uIdx=0, uDwNum=0;

    for(uIdx=0; uIdx<cHwPrdDepth; uIdx++)
    {
        for(uDwNum=0; uDwNum<8; uDwNum++)
        {
            r32NvmeDesc[uIdx][uDwNum]=0x00;
            r32NvmePrd[uIdx][uDwNum]=0x00;
        }
    }

    gsPrdInfo.uFreeHwPrdHead=0x00;
    gsPrdInfo.uFreeHwPrdTail=0x00;
    gsPrdInfo.uFreeHwPrdCnt=cHwPrdDepth;

    for(uIdx=0; uIdx<cHwPrdDepth; uIdx++)
    {
        gsPrdInfo.uarFreeHwPrdQue[uIdx]=uIdx;
        gsPrdInfo.u16arIdxToPrdInfo[uIdx]=c16Null;
    }

    g32NvmeCondition=0;

    if(uPowerOnInit)
    {
        // ****** Asynchronous Event variables ****/
        bopClrRam((LWORD)&gsNvmeAer, sizeof(gsNvmeAer), 0x00000000, cBopWait|cClrCore0Dccm);
        gsNvmeAer.u32AerMask=0xFFFFFFFF;

        // ***** For Invalid DB error log ****/
        bopClrRam((LWORD)&gsInvalidDbInfo, sizeof(gsInvalidDbInfo), 0x00000000, cBopWait|cClrCore0Dccm);

        for(uIdx=0; uIdx<cMaxIoSqCqCnt; uIdx++)
        {
            g16Cq2SqidBitmap[uIdx]=0;
        }

        g16ValidSqBitmap=0;
        g16ValidCqBitmap=0;

        gTelemetryCtlrInfo=0;
        gTelemetryCtlrGenNum=0xff;
    }

    mClrHandlePcieErrF;
}    /* initNvmeGlobVar */

void resetCpuFwCommit(BYTE uType)
{
    void (*funPtr)()=0x00000000;
    // resetCpu(uType);
    mCallFuncPtr2(cfuncResetCpu, uType);
    funPtr();
}

void resetFwDlFlow(BYTE uRstTag)
{
    if(mChkFidUnderProcess)
    {
        // pushSysSprBlk(gsFwDlInfo.uSysRsvFwDlImageBlk);
    }

    NLOG(cLogHost, NVMECTRL_C, 1, " rstFwDlInfo(uRstTag) = 0x%04X ", uRstTag);

    if(!mChkFwCommitSuccess)
    {
        rstFwDlInfo(uRstTag);
    }
}

void rstFwDlInfo(BYTE uRstTag)
{
    fillCcmVal((BYTE *)&gsFwDlInfo, sizeof(gsFwDlInfo), 0x00);
    gsFwDlInfo.uSysRsvFwDlImageBlk=0xFF;
    mClrCacheInfoSpf(cFwCommit);

    gsFwDlInfo.uRstTag=uRstTag;

    if(    /*(uRstTag!=0xFE)&&*/ (uRstTag!=0xFF))
    {
        progCacheInfoTab();
    }

    gDLFWFail=0;    // Fix DriveMaster Protocl FwDnld Scirpt Issue for HP 20190719_Wade
#if _EN_FWCommit_Protect
    gJustReturnPass=0;
#endif
}    /* rstFwDlInfo */

void remHmbLink(WORD u16Hblock)
{
    volatile LINKINFO *upDelLlInfo;
    WORD u16PrevNodeIdx, u16NextNodeIdx, u16NowNodeIdx;

#if _GREYBOX
    outCS(cbTagremHmbLink);
#endif

    u16NowNodeIdx=mGetHmbLink(u16Hblock);

#if _ENABLE_HMB_FLUSH
    if(mChkHmbTabDirty(u16NowNodeIdx))
    {
        mClrHmbTabDirty(u16NowNodeIdx);

        if(gsHmbInfo.u16HmbLastDirtyPtr==u16NowNodeIdx)
        {
            gsHmbInfo.u16HmbLastDirtyPtr=gsHmbInfo.uarHmbLink[u16NowNodeIdx].u16Prev;
        }
    }
#endif
    g16arH2fTabPtr[u16Hblock]=g16arH2fTabPtr[g16TotalHBlock+u16NowNodeIdx];
    g16arH2fTabPtr[g16TotalHBlock+u16NowNodeIdx]=0xFFFF;
    g16arH2fBackup[u16NowNodeIdx]=0xFFFF;
    upDelLlInfo=&gsHmbInfo.usHmbList;

    while((gsHmbInfo.usHmbList.u16Head!=c16Null)&&(gsHmbInfo.uarHmbLink[gsHmbInfo.usHmbList.u16Head].u16Next!=c16Null))
        ;

    while((gsHmbInfo.usHmbList.u16Tail!=c16Null)&&(gsHmbInfo.uarHmbLink[gsHmbInfo.usHmbList.u16Tail].u16Prev!=c16Null))
        ;

    mDelNode16(u16PrevNodeIdx, gsHmbInfo.uarHmbLink, u16NowNodeIdx, u16NextNodeIdx, upDelLlInfo);

    while((gsHmbInfo.usHmbList.u16Head!=c16Null)&&(gsHmbInfo.uarHmbLink[gsHmbInfo.usHmbList.u16Head].u16Next!=c16Null))
        ;

    while((gsHmbInfo.usHmbList.u16Tail!=c16Null)&&(gsHmbInfo.uarHmbLink[gsHmbInfo.usHmbList.u16Tail].u16Prev!=c16Null))
        ;

    gsHmbInfo.u16arFreeHmbQ[gsHmbInfo.u16FreeHmbTail]=u16NowNodeIdx;
    gsHmbInfo.u16FreeHmbTail++;

    if(gsHmbInfo.u16FreeHmbTail>=g16HmbMaxTableNum)
    {
        gsHmbInfo.u16FreeHmbTail-=g16HmbMaxTableNum;
    }

#if _GREYBOX
    if(gsGbInfo.uGreyBoxItem==cTabHdlH2fOnHmb)
    {
        if(*(BYTE *)(c32GreyBoxBuf+u16Hblock))
        {
            fillCcmVal((BYTE *)c32GreyBoxBuf+u16Hblock, 1, cFalse);
        }
        else
        {
            gsGbInfo.uResult=cFail;
            outSta(cVFail);
        }
    }
#endif/* if _GREYBOX */
}    /* remHmbLink */

void disableHmbFunc(BYTE uAbrRst)    // LeverYu_0813 SMI S0813A  SQ mismatch issue
{
    WORD u16Loop;
    BYTE uLoop;

#if _ENABLE_HMB_FLUSH
    // TODO: need to verify. code swap? Rw isp?
    // flushCacheHmbTab();
#endif

// by yhlin
    prog1stInvQBootInWpro();
/*
   *  if(gsQBootInfo.ubQBootValid)
   *  {
   #if _EN_FW_DEBUG_UART
   *      NLOG(cLogTempDebug, NVMECTRL_C, 1, "disableHmbFunc, gsQBootInfo.ubQBootValid = 0x%04X", gsQBootInfo.ubQBootValid);
   #endif
   *      gsQBootInfo.ubQBootValid=0;
   *  }
   */
    gsHmbInfo.uHmbEnable=cFalse;
    // gsHmbInfo.uHmbEnWrCache=cFalse;
    // gsHmbInfo.uHmbEnRdCache=cFalse;
    gsHmbInfo.uHmbEnGcCache=cFalse;
    gsHmbInfo.uHmbEnPtCache=cFalse;
    gsGcInfo.uHmbEnGcCache=cFalse;
    gsGcInfo.uHmbEnPtCache=cFalse;
    // gsE2eInfo.uHmbEnable=cFalse;
    // gsHmbInfo.uHmbEnGcInfoCache=cFalse;

    rstH2F1KInfo();
    remAllHmbLink();

    gsHmbInfo.uHmbSwichChkTimer=cTrue;
    gsHmbInfo.uHmbStsChg=cTrue;
    gsGcInfo.uHMBchg=cTrue;

    for(u16Loop=0; u16Loop<g16HmbMaxTableNum; u16Loop++)
    {
        gsHmbInfo.uarHmbLink[u16Loop].u16Prev=u16Loop-1;
        gsHmbInfo.uarHmbLink[u16Loop].u16Next=u16Loop+1;
        gsHmbInfo.u16arFreeHmbQ[u16Loop]=u16Loop;
    }

    gsHmbInfo.uarHmbLink[g16HmbMaxTableNum-1].u16Next=c16Null;
    gsHmbInfo.usHmbList.u16Head=c16Null;
    gsHmbInfo.usHmbList.u16Tail=c16Null;
    gsHmbInfo.usHmbList.u16Trig=c16Null;
    gsHmbInfo.uHmbFreeHwPrdCnt=cHmbHwPrdDepth;

    gWriteHMBIndex=0;

    for(uLoop=0; uLoop<cHmbRacingFreeCnt; uLoop++)
    {
        g16WriteHMBH2FTable[uLoop]=c16Null;
    }

    if(uAbrRst)
    {
        rmSetARBSoftReset;    // reset hmb and nvme
    }

    rmSetHmbSoftReset;    // Reset Hmb
    sysDelay(2);

    if(uAbrRst)
    {
        rmClrARBSoftReset;
    }

    rmClrHmbSoftReset;

    gsHmbInfo.uHmbHwPrdTail=rmHmbPrdQueTrigIdx;
    gsHmbInfo.uHmbHwPrdHead=rmHmbPrdQueTrigIdx;
    rmRstCrc32PutAddr;
    gsHmbInfo.uRdCrcIdx=0;
    gsHmbInfo.uWrCrcIdx=0;
#if _EN_DisHMBInReset    // 20190424_Chief_DisHMB
    if((gDisHMBCnt_NormalBehavior!=cBitFF)&&mChkDisHMBCondition&&mPcieChkPerst)    // 20190808_Bruce_count Normal Behavior for DisHMB
    {
        gDisHMBCnt_NormalBehavior++;
        gDisHMBCnt_AbnormalBehavior=0;
    }

    if((gDisHMBCnt_AbnormalBehavior!=cBitFF)&&!mChkDisHMBCondition&&mPcieChkPerst)    // 20190808_Bruce_count Abnormal Behavior for DisHMB
    {
        gDisHMBCnt_AbnormalBehavior++;
    }

    gChkFlag=0;

    LWORD u32RTCs;
    u32RTCs=getRtcCurrent1s();

    if(g32DisHMBTimer)
    {
        if(u32RTCs-g32DisHMBTimer>=300)    // 20190819_Bruce 5mins for reset
        {
            gDisHMBCnt_NormalBehavior=0;
            NLOG(cLogHost, NVMECTRL_C, 2, " Time gap: 0x%08X. Over 300s reset NormalBehavior ", (u32RTCs-g32DisHMBTimer)>>16,
                 (u32RTCs-g32DisHMBTimer));
            NLOG(cLogHost,
                 NVMECTRL_C,
                 2,
                 " gDisHMBCnt_NormalBehavior: 0x%04X  gDisHMBCnt_AbnormalBehavior: 0x%04X ",
                 gDisHMBCnt_NormalBehavior,
                 gDisHMBCnt_AbnormalBehavior);
        }
    }
    g32DisHMBTimer=u32RTCs;
#endif/* if _EN_DisHMBInReset */
}    /* disableHmbFunc */

BYTE chkDstInProgress()
{
    if(((gsCurrDstResult.uDstStatus>>4)==cOperationShortDstInProgress)||
       ((gsCurrDstResult.uDstStatus>>4)==cOperationExtendedDstInProgress))
    {
        return cTrue;
    }

    return cFalse;
}

void remAllHmbLink()
{
    LWORD u32Cnt;

    while(gsHmbInfo.usHmbList.u16Cnt)
    {
#if _ENABLE_HMB_FLUSH
        while(mChkHmbTabDirty(gsHmbInfo.usHmbList.u16Tail))
            ;
#endif
        remHmbLink(g16arH2fBackup[gsHmbInfo.usHmbList.u16Tail]);
    }

    for(u32Cnt=cWproGcDesF2hTab00; u32Cnt<=cWproGcInfoPage; u32Cnt++)
    {
        if(mChkGcInfoHmbLink(u32Cnt))
        {
            mClrGcInfoHmbLink(u32Cnt);
        }
    }
}    /* remAllHmbLink */

#endif    // (_CPUID!=1)

#if (!_ICE_LOAD_ALL)
#pragma default_function_attributes =
#endif







