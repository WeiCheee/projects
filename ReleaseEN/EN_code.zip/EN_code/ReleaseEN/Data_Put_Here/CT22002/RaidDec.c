







#if _EN_RAID_DECODE
////////////////////////////////////////////////
// Updated by Kane, 20170103
//
// 1. u16DesTsbIdx: The TSB address that keeps the temp Raid parity
//
// 2. uDesFlag: 0x0 - Non,
//                    0x1 - Set Buf Flag,
//                    0x2 - Set Raid Flag
//
// 3. uRaidType: (cRaidTotalType=3) cRaidDataBlk, cRaidGcBlk, cRaidHTabBlk
//
////////////////////////////////////////////////
void trigRaidBopTerm(WORD u16DesTsbIdx, BYTE uDesFlag, BYTE uEngIdx, BYTE uRaidType, BYTE uRaidActOpts)
{
    BYTE uSctrNum=gsRaidInfo.uarRaidTotalType[uRaidType].uSctrNum;

    while(rmChkBopNbsBz)
        ;

    while(rmChkBopCmdFifoFull)
        ;

    while(rmChkBopBz)
        ;

    rmRstBopParam;    // (Kane_20170103) Reset HW Buf flag setting
    rmClrBopRaidCmd;    // Reset HW Raid cmd reg

#if _ENABLE_E2E_PROTECTION
    rmForceEnCrcfun;
#endif

    rmSetBopDesAddr((LWORD)u16DesTsbIdx<<9);
    rmSetBopSrcAddr(0);
    rmSetBopXfrLen((LWORD)(uSctrNum<<(9+cRaidUnitChgShiftBit)));
    rmSetBopDataDir(cBopTsb2Tsb);

    rmSetRaidCurEngineSel(uEngIdx);
    rmSetBopRaidCmd(cRaidCmdTerm);

    // (Kane_20170103) Set Des Flag (Buf Flag or Raid Flag)
    if(uDesFlag&cBopDesFlagMsk)
    {
        rmBopAutoFlagDes;

        if(uDesFlag&cBopDesRaidFlag)
        {
            rmEnBopRaidFlagDes;
        }
    }
    else
    {
        rmBopBypassDes;
    }

    rmTrigBopRaidCmd(0);

    rmChkBopDone;

    gsRaidInfo.uarRaidTermQue[uEngIdx].u16RaidTermInfo=(uRaidType<<12)|c16Bit0;    /*|(uRaidActOpts&cRaidActOptBGEnc)*/    // (Kane_20170103)
                                                                                                                           // Set c16Bit0
                                                                                                                           // (uRaidTermFlag)
    gsRaidInfo.uarRaidTermQue[uEngIdx].u16DesTsbIdx=u16DesTsbIdx;
    gsRaidInfo.uarRaidTermQue[uEngIdx].u16TermPgIdx=rmChkBopRaidTermPgIdx;
    gsRaidInfo.uarRaidTermQue[uEngIdx].uTermSctrIdx=rmChkBopRaidTermSctrIdx;
}    /* trigRaidBopTerm */

void trigRaidBopResm(BYTE uEngIdx, BYTE uSrcFlag)
{
    WORD u16KVal;
    BYTE uSctrNum, uRaidType;

    if(gsRaidInfo.uarRaidTermQue[uEngIdx].u16RaidTermInfo&c16Bit0)    // (Kane_20161229) Chk the uRaidTermFlag of the "uFGEngIdx". This bit
                                                                      // will be set if the uFGEngIdx is terminated.
    {
        uRaidType=((gsRaidInfo.uarRaidTermQue[uEngIdx].u16RaidTermInfo&cRaidTypeMsk)>>12);
        u16KVal=gsRaidInfo.uarRaidTotalType[uRaidType].u16KVal;
        uSctrNum=gsRaidInfo.uarRaidTotalType[uRaidType].uSctrNum;

        while(rmChkBopNbsBz)
            ;

        while(rmChkBopCmdFifoFull)
            ;

        while(rmChkBopBz)
            ;

        rmRstBopParam;    // (Kane_20170103) Reset HW Buf flag setting
        rmClrBopRaidCmd;    // Reset HW Raid cmd reg

#if _ENABLE_E2E_PROTECTION
        rmForceEnCrcfun;
#endif

        rmSetBopDesAddr(0);
        rmSetBopSrcAddr((LWORD)(gsRaidInfo.uarRaidTermQue[uEngIdx].u16DesTsbIdx)<<9);
        rmSetBopXfrLen((LWORD)(uSctrNum<<(9+cRaidUnitChgShiftBit)));
        rmSetBopDataDir(cBopTsb2Tsb);

        rmSetBopRaidResmPgIdx(gsRaidInfo.uarRaidTermQue[uEngIdx].u16TermPgIdx);
        rmSetBopRaidResmSctrIdx(gsRaidInfo.uarRaidTermQue[uEngIdx].uTermSctrIdx);

        rmSetRaidCurEngineSel(uEngIdx);
        rmSetRaidSctrNum(uSctrNum-1);
        rmSetRaidKValue(u16KVal);
        rmSetBopRaidCmd(cRaidCmdResm);

        // (Kane_20170103) Set Src Flag (Buf Flag or Raid Flag)
        if(uSrcFlag&cBopSrcFlagMsk)
        {
            rmBopAutoFlagSrc;

            if(uSrcFlag&cBopSrcRaidFlag)
            {
                rmEnBopRaidFlagSrc;
            }
        }
        else
        {
            rmBopBypassSrc;
        }

        rmTrigBopRaidCmd(0);

        rmChkBopDone;

        gsRaidInfo.uarRaidTermQue[uEngIdx].u16RaidTermInfo=0;
        gsRaidInfo.uarRaidTermQue[uEngIdx].u16DesTsbIdx=0;
        gsRaidInfo.uarRaidTermQue[uEngIdx].u16TermPgIdx=0;
        gsRaidInfo.uarRaidTermQue[uEngIdx].uTermSctrIdx=0;
    }
}    /* trigRaidBopResm */

void trigRaidBopDecIn(WORD u16SrcTsbIdx, WORD u16XfrSctrCnt, BYTE uSrcFlag, WORD u16PgIdx, BYTE uSctrIdx)
{
    while(rmChkBopNbsBz)
        ;

    while(rmChkBopCmdFifoFull)
        ;

    while(rmChkBopBz)
        ;

    rmRstBopParam;    // (Kane_20170103) Reset HW Buf flag setting
    rmRstBopRaidFlag;    // Reset HW Raid flag setting
    rmClrBopRaidCmd;    // Reset HW Raid cmd reg

#if _ENABLE_E2E_PROTECTION
    rmForceEnCrcfun;
#endif

    rmSetBopDesAddr(0);
    rmSetBopSrcAddr((LWORD)u16SrcTsbIdx<<9);
    rmSetBopXfrLen((LWORD)u16XfrSctrCnt<<9);
    rmSetBopDataDir(cBopTsb2Tsb);

    rmSetBopRaidResmPgIdx(u16PgIdx);
    rmSetBopRaidResmSctrIdx(uSctrIdx);

    rmSetBopRaidCmd(cRaidCmdDecIn);

    // (Kane_20170103) Set Src Flag (Buf Flag or Raid Flag)
    if(uSrcFlag&cBopSrcFlagMsk)
    {
        rmBopAutoFlagSrc;

        if(uSrcFlag&cBopSrcRaidFlag)
        {
            rmEnBopRaidFlagSrc;
        }
    }
    else
    {
        rmBopBypassSrc;
    }

    rmTrigBopRaidCmd(0);

    rmChkBopDone;
    rmClrBopRaidCmd;
}    /* trigRaidBopDecIn */

#if 0
void trigRaidBopDecOut(WORD u16DesTsbIdx, WORD u16XfrSctrCnt, BYTE uDesFlag, WORD u16PgIdx, BYTE uSctrIdx)
{
    while(rmChkBopNbsBz)
        ;

    while(rmChkBopCmdFifoFull)
        ;

    while(rmChkBopBz)
        ;

    rmRstBopParam;    // (Kane_20170103) Reset HW Buf flag setting
    rmRstBopRaidFlag;    // Reset HW Raid flag setting
    rmClrBopRaidCmd;    // Reset HW Raid cmd reg

#if _ENABLE_E2E_PROTECTION
    rmForceEnCrcfun;
#endif

    rmSetBopDesAddr((LWORD)u16DesTsbIdx<<9);
    rmSetBopSrcAddr(0);
    rmSetBopXfrLen((LWORD)u16XfrSctrCnt<<9);
    rmSetBopDataDir(cBopBvci2Tsb);

    rmSetBopRaidResmPgIdx(u16PgIdx);
    rmSetBopRaidResmSctrIdx(uSctrIdx);

    rmSetBopRaidCmd(cRaidCmdDecOut);

    // (Kane_20170103) Set Des Flag (Buf Flag or Raid Flag)
    if(uDesFlag&cBopDesFlagMsk)
    {
        rmBopAutoFlagDes;

        if(uDesFlag&cBopDesRaidFlag)
        {
            rmEnBopRaidFlagDes;
        }
    }
    else
    {
        rmBopBypassDes;
    }

    rmTrigBopRaidCmd(0);

    rmChkBopDone;
}    /* trigRaidBopDecOut */

#endif/* if 0 */

BYTE termRaidEngTask()
{
    BYTE uRaidEngIdx, uIdx;

    rmHdmaPause;

    if(gsRaidInfo.u16RaidEngBitMap!=cRaidEngFull)
    {
        for(uRaidEngIdx=0; uRaidEngIdx<cRaidTotalEng; uRaidEngIdx++)
        {
            if(!mChkRaidEngBmap(uRaidEngIdx))
            {
                break;
            }
        }
    }
    else
    {
        for(uIdx=0; uIdx<cRaidParityNum; uIdx++)
        {
            if(!mChkRaidEngPtyBmap(gsRaidInfo.uarRaidEngIdx[cRaidDataBlk][uIdx]))
            {
                uRaidEngIdx=gsRaidInfo.uarRaidEngIdx[cRaidDataBlk][uIdx];
                trigRaidBopTerm(c16RaidBufSIdx, cHdmaDesBufFlag, uRaidEngIdx, cRaidDataBlk, cRaidActOptNon);
                break;
            }
        }

        if(uIdx==cRaidParityNum)
        {
            gsFtlDbg.u16DummyFailType=cTermRaidEngTask;
            debugWhile();    // debug????

/*
   *          uRaidEngIdx=cRaidEng0;
   *          trigRaidPtyOut(c16RaidBufSIdx, cHdmaDesRaidFlag, uRaidEngIdx, cRaidDataBlk, cRaidActOptPtyClr, cHdmaWait);
   *          rmHdmaPause;
   */
        }
    }

    return uRaidEngIdx;
}    /* termRaidEngTask */

void resmRaidEngTask(BYTE uRaidEngIdx, BYTE uResmEng)
{
    if((gsRaidInfo.u16RaidEngBitMap==cRaidEngFull)||(uResmEng==cTrue))
    {
        if(gsRaidInfo.uarRaidTermQue[uRaidEngIdx].u16RaidTermInfo&c16Bit0)
        {
            trigRaidBopResm(uRaidEngIdx, cHdmaSrcBufFlag);
        }
        else
        {
            gsFtlDbg.u16DummyFailType=cResmRaidEngTask;
            debugWhile();    // debug????

/*
   *          rmHdmaPauseClr;
   *          trigRaidDataEnc(c16RaidBufSIdx,
   *                          mGetRaidSector(cRaidDataTerm),
   *                          cHdmaSrcRaidFlagOnly,
   *                          uRaidEngIdx,
   *                          cRaidDataTerm,
   *                          0,
   *                          0,
   *                          cRaidActOptNon,
   *                          cHdmaWait);
   */
        }

        // bopClrRam((LWORD)c32RaidBufSAddr, c32F2hRsvRamSize, 0x00000000, cBopWait|cClrTsb);
    }

    rmSysDisRaidClkAutoGate2;
    rmHdmaPauseClr;
    rmSysEnRaidClkAutoGate2;
}    /* resmRaidEngTask */

void setDecBufFlag(RAIDDECADDR *upDecAddrInfo, WORD u16ErrChunkMap, BYTE uRwHalfKb, BYTE uData)
{
    WORD u16StartBufIdx;
    BYTE uStartSctrH, uOpTyp;

    u16StartBufIdx=upDecAddrInfo->u16BufPtr;
    uStartSctrH=upDecAddrInfo->uSectorH;
    uOpTyp=upDecAddrInfo->uOpTyp;

    for(BYTE uLoop=0; uLoop<uRwHalfKb; uLoop++)
    {
        if(mChkBitMask(u16ErrChunkMap, uStartSctrH>>2))
        {
#if _EN_RAID_GC
            if((uOpTyp==cPreReadData)||(uOpTyp==cLastReadData)||(!gsGcInfo.uHmbEnGcCache&&(uOpTyp==cMoveReadData)))
#else
            if((uOpTyp==cPreReadData)||(uOpTyp==cLastReadData))
#endif
            {
                rmSetBufRaid8Sts(u16StartBufIdx>>3, (BYTE)cb32BitTab[u16StartBufIdx&7]);
            }
            else
            {
                rmSetBuf8Sts(u16StartBufIdx>>3, (BYTE)cb32BitTab[u16StartBufIdx&7]);
            }
        }

        if(uData)
        {
            u16StartBufIdx=addReadBufPtr(u16StartBufIdx, 1);
        }
        else
        {
            u16StartBufIdx+=1;
        }

        uStartSctrH++;
    }
}    /* setDecBufFlag */

void initRaidDecode(WORD u16TotalPage, WORD u16WantedPage, WORD u16ErrChunkMap, BYTE uRaidSctrNum, BYTE uRaidEngIdx)
{
    rmSetRaidCurEngineSel(uRaidEngIdx);
    rmRaidCodecClr;
    rmSetRaidDecWantedPage(u16WantedPage);
    rmSetErrChunkMap(u16ErrChunkMap);
    rmSetRaidSctrNum(uRaidSctrNum);
    rmSetRaidKValue(u16TotalPage);

    if(gSecurityOption&cEnE2e)
    {
        rmSetRaidE2eCtl;
    }

    rmHdmaDecInit;
    gsRaidInfo.u16RaidLdpcPgIdx=0;
}

BYTE getEncodedEng(WORD u16FPage)
{
    BYTE uIdx, uRaidEngIdx;

    uIdx=u16FPage&(cRaidParityNum-1);
    uRaidEngIdx=gsRaidInfo.uarRaidEngIdx[cRaidDataBlk][uIdx];

    if(!mChkRaidEngPtyBmap(uRaidEngIdx))
    {
        rmHdmaPause;
        trigRaidBopTerm(c16RaidBufSIdx, cHdmaDesBufFlag, uRaidEngIdx, cRaidDataBlk, cRaidActOptNon);
    }
    else
    {
        trigRaidPtyOut(c16RaidBufSIdx, cHdmaDesRaidFlag, uRaidEngIdx, cRaidDataBlk, cRaidActOptPtyClr, cHdmaWait);
        rmHdmaPause;
    }

    return uRaidEngIdx;
}    /* getEncodedEng */

void readDecodePage(WORD u16TotalPage, WORD u16BufPtr, BYTE uRwHalfKb, BYTE uSectorH, ADDRINFO *upAddrInfo)
{
    BYTE uIntlvAddr, uCh;

    for(uIntlvAddr=0; uIntlvAddr<gIntlvWay; uIntlvAddr++)
    {
        for(uCh=0; uCh<gTotalChNum; uCh++)
        {
            upAddrInfo->uCh=uCh;
            upAddrInfo->uIntlvAddr=uIntlvAddr;
            upAddrInfo->uCe=(BYTE)mGetCEAddr(upAddrInfo->uIntlvAddr);
            upAddrInfo->uDieAddr=mGetDieAddr(uIntlvAddr);
            setFLAddrActCh(uCh, upAddrInfo);
            gPlaneAddr=0;
            gSectorH=0;
            mSetFRwParam(0, 0, c16Bit0|c16Bit9|c16Bit15, cReadCmdAle);
            waitChCeBz(uCh, uIntlvAddr, 0);
            flashReadPage();
            setBzInfo(cReadCmdAle, uCh, uIntlvAddr);
            gsRwCtrl.usWaitInfo[uCh][uIntlvAddr].uStatusErrStop=0;
        }
    }

    for(uIntlvAddr=0; uIntlvAddr<gIntlvWay; uIntlvAddr++)
    {
        for(uCh=0; uCh<gTotalChNum; uCh++)
        {
            upAddrInfo->uCh=uCh;
            upAddrInfo->uIntlvAddr=uIntlvAddr;
            upAddrInfo->uCe=(BYTE)mGetCEAddr(upAddrInfo->uIntlvAddr);
            upAddrInfo->uDieAddr=mGetDieAddr(uIntlvAddr);
            setFLAddrActCh(uCh, upAddrInfo);
            rmSetDecModeRaid;
            // rmSetForceXfrTsbLdpc; //debug
            gSectorH=uSectorH;
            waitChCeBz(uCh, uIntlvAddr, 0);

            for(gPlaneAddr=0; gPlaneAddr<gPlaneNum; gPlaneAddr++)
            {
                rmSetRaidDecStartSect(gSectorH);
                mSetFRwParam(u16BufPtr, uRwHalfKb, c16Bit2|c16Bit4|c16Bit6|c16Bit10, cRaidDecRead);
                flashReadPage();
                setBzInfo(cRaidDecRead, uCh, uIntlvAddr);
                gsRwCtrl.usWaitInfo[uCh][uIntlvAddr].uStatusErrStop=0;

                if(gsRaidInfo.u16RaidLdpcPgIdx>=u16TotalPage)
                {
                    return;
                }
            }
        }
    }
}    /* readDecodePage */

BYTE chkRaidParityValid(ADDRINFO *upAddrInfo)
{
    BYTE uDecBank, uPtyIdx;
    WORD u16RaidStrAddr;

    if(upAddrInfo->u16FBlock==gsCacheInfo.u16ActiveCacheBlock)
    {
        uDecBank=(BYTE)(upAddrInfo->u32FPageNoTran/gsCacheInfo.u16TotalPgPerF2hTab);
        uPtyIdx=(BYTE)(upAddrInfo->u16FPage&(cRaidParityNum-1));

        if(uDecBank==gsCacheInfo.uF2hTabBank)
        {
            if(mChkMlcMoBit(upAddrInfo->u16FBlock))
            {
                u16RaidStrAddr=g16RaidStrAddr[uPtyIdx];
            }
            else
            {
                u16RaidStrAddr=g16SlcRaidStrAddr[uPtyIdx];
            }

            if(gsCacheInfo.u32CacheFreePagePtr+gsRwCtrl.u16ProgPageOfst<
               u16RaidStrAddr+(gsCacheInfo.uF2hTabBank*gsCacheInfo.u16TotalPgPerF2hTab))
            {
                return cFalse;
            }
        }
    }

    return cTrue;
}    /* chkRaidParityValid */

BYTE chkPartialParityValid(WORD u16FPage)
{
    BYTE uIdx;

    for(uIdx=0; uIdx<cRaidParityNum; uIdx++)
    {
        if(u16FPage==gsRaidInfo.u16arRaidFPage[cRaidDataBlk][uIdx])
        {
            return cFalse;    // partial parity in raid engine
        }
    }

    return cTrue;    // partial parity out
}

void trigRaidDecData(BYTE uIdx)
{
    ADDRINFO usTmpAddrInfo;

#if _EN_CHK_FINGER_FAIL
    ADDRINFO usBkAddrInfo;
#endif
    RAIDDECADDR *upAddrInfo;
    WORD u16ErrChunkMap, u16WantedPage, u16TotalPage, u16KVal, u16PtyIdx, u16BufPtr, u16Page, u16SctrIdx=0;
    BYTE uRaidEngIdx, uRaidCurEngIdx, uRaidSctrNum, uPlaneAddr, uRwHalfKb, uSectorH, uOrgRwHalfKb, uOrgSectorH, uBank, uResmEng=cFalse;
    LWORD u32TmpRRCnt;

    upAddrInfo=&gsRaidInfo.uarRaidDecQue[uIdx];
    u16ErrChunkMap=gsRaidInfo.u16arErrChunkMap[uIdx];
    u16WantedPage=upAddrInfo->uIntlvAddr*gTotalChPlaneNum+upAddrInfo->uCh*gPlaneNum+upAddrInfo->uPlaneAddr;

    usTmpAddrInfo.u32FPageNoTran=upAddrInfo->u32FPageNoTran;
    usTmpAddrInfo.u16AbstractFBlock=usTmpAddrInfo.u16FBlock=upAddrInfo->u16FBlock;
    usTmpAddrInfo.u16FPage=upAddrInfo->u16FPage;
    usTmpAddrInfo.uDieAddr=upAddrInfo->uDieAddr;
    usTmpAddrInfo.uCh=upAddrInfo->uCh;
    usTmpAddrInfo.uIntlvAddr=upAddrInfo->uIntlvAddr;
    usTmpAddrInfo.uPlaneAddr=upAddrInfo->uPlaneAddr;
    // usTmpAddrInfo.uPageSelCmd=upAddrInfo->uPageSelCmd;
    setPageSelCmd(&usTmpAddrInfo, upAddrInfo->uPageSelCmd);
#if _EN_CHK_FINGER_FAIL
    copyCcmVal((BYTE *)&usBkAddrInfo, (BYTE *)&usTmpAddrInfo, sizeof(ADDRINFO));
#endif
    u16BufPtr=upAddrInfo->u16BufPtr;
    uPlaneAddr=upAddrInfo->uPlaneAddr;
    uRwHalfKb=uOrgRwHalfKb=upAddrInfo->uRwHalfKb;
    uSectorH=uOrgSectorH=upAddrInfo->uSectorH;

    // adjust uSectorH to align 2k for raid decode
    if(uOrgSectorH&(cRaidMinSctrCnt-1))
    {
        uSectorH-=(uOrgSectorH&(cRaidMinSctrCnt-1));
        uRwHalfKb+=(uOrgSectorH&(cRaidMinSctrCnt-1));
    }

    // adjust uRwHalfKb to align 2k for raid decode
    if(uRwHalfKb&(cRaidMinSctrCnt-1))
    {
        uRwHalfKb+=(cRaidMinSctrCnt-(uRwHalfKb&(cRaidMinSctrCnt-1)));
    }

    uRaidSctrNum=(uRwHalfKb>>cRaidUnitChgShiftBit)-1;
    u16KVal=mGetRaidKVal(mChkMlcMoBit(usTmpAddrInfo.u16FBlock)?cRaidPtyTBlk:cRaidPtySBlk);
    uRaidCurEngIdx=rmChkRaidCurEngineSel;

#if _ENABLE_CPU_CYCLE_COUNTER
    initCyclecounter();
    g32Cpu1CycleCnt0=getCycleCounter();
#endif
    u32TmpRRCnt=gsFtlDbg.u32RRCnt;

    if(chkRaidParityValid(&usTmpAddrInfo))    // case1: raid parity
    {
        uRaidEngIdx=termRaidEngTask();
        u16TotalPage=gTotalIntlvChPlaneNum*u16KVal-1;
        u16PtyIdx=u16KVal<<cRaidStringShiftBit;
        uBank=usTmpAddrInfo.u16FPage/u16PtyIdx;
        u16Page=usTmpAddrInfo.u16FPage-(uBank*u16PtyIdx);
        u16WantedPage=(u16Page>>cRaidStringShiftBit)*gTotalIntlvChPlaneNum+u16WantedPage;
        initRaidDecode(u16TotalPage, u16WantedPage, u16ErrChunkMap, uRaidSctrNum, uRaidEngIdx);
        usTmpAddrInfo.u16FPage=(usTmpAddrInfo.u16FPage&(cRaidStringPerGrp-1))+(uBank*u16PtyIdx);

        while(gsRaidInfo.u16RaidLdpcPgIdx<u16TotalPage)
        {
            readDecodePage(u16TotalPage+1, u16BufPtr, uOrgRwHalfKb, uOrgSectorH, &usTmpAddrInfo);
            usTmpAddrInfo.u16FPage+=cRaidStringPerGrp;
        }
    }
    else    // case2: partial parity on raid engine
    {
        uResmEng=cTrue;
        uRaidEngIdx=getEncodedEng(usTmpAddrInfo.u16FPage);
        u16TotalPage=gsRaidInfo.u16arRaidEngPgIdx[uRaidEngIdx];
        u16PtyIdx=u16KVal<<cRaidStringShiftBit;
        uBank=usTmpAddrInfo.u16FPage/u16PtyIdx;
        u16Page=usTmpAddrInfo.u16FPage-(uBank*u16PtyIdx);
        u16WantedPage=(u16Page>>cRaidStringShiftBit)*gTotalIntlvChPlaneNum+u16WantedPage;
        initRaidDecode(u16TotalPage, u16WantedPage, u16ErrChunkMap, uRaidSctrNum, uRaidEngIdx);
        usTmpAddrInfo.u16FPage=(usTmpAddrInfo.u16FPage&(cRaidStringPerGrp-1))+(uBank*u16PtyIdx);

        while(gsRaidInfo.u16RaidLdpcPgIdx<u16TotalPage)
        {
            readDecodePage(u16TotalPage, u16BufPtr, uOrgRwHalfKb, uOrgSectorH, &usTmpAddrInfo);
            usTmpAddrInfo.u16FPage+=cRaidStringPerGrp;
        }

        if(g4kNumPerPlane!=cRaidEngineBuf4KSize)
        {
            u16SctrIdx=(uPlaneAddr&(cRaidEngineBuf4KSize/g4kNumPerPlane-1)*gSectorPerPlaneH);
        }

        rmClrDecErrMap;
        trigRaidBopDecIn(c16RaidBufSIdx+u16SctrIdx+uSectorH, uRwHalfKb, cBopSrcNonFlag, gsRaidInfo.u16RaidLdpcPgIdx, 0);
        gsRaidInfo.u16RaidLdpcPgIdx++;
    }

    if(gsFtlDbg.u32RRCnt>u32TmpRRCnt)
    {
        gsFtlDbg.u32RaidB2bRehCnt+=gsFtlDbg.u32RRCnt-u32TmpRRCnt;
#if (!_EN_LiteonRetryLog)
        NLOG(cLogCore1, RAIDDEC_C, 1, "RaidB2bRehCnt=0x%04X", gsFtlDbg.u32RaidB2bRehCnt);
#endif
    }

    while(gsRaidInfo.u16RaidLdpcPgIdx<=u16TotalPage)
        ;

    while(!rmChkRaidDecInDone)
        ;

    rmTrigRaidDecOut;

    setSelMulFL(1);
    rmClrDecModeRaid;
    setSelMulFL(0);

    rmWaitSysCmdFifoBz;
    setFLActCh(upAddrInfo->uCh);
    rmSetChunkEccStsMap(rmChkRaidDecOutErrChunkMap);

#if (_GREYBOX)
    if((rmChkRaidDecOutErrChunkMap&u16ErrChunkMap)||(gsGbInfo.uGreyBoxItem==cErrHdlReadUncInSlcDataID)||
       (gsGbInfo.uGreyBoxItem==cErrHdlReadUncInTlcDataID)||(gsGbInfo.uGreyBoxItem==cErrHdlProgWPROID))
#else
    if(rmChkRaidDecOutErrChunkMap&u16ErrChunkMap)
#endif
    {
        if(upAddrInfo->uOpTyp==cHostReadData)
        {
            if(gsPrdInfo.uarPrdQue[upAddrInfo->uPrdPtr].uHwPrdIdx!=cNull)
            {
                rmNvmeSetUncFlag(gsPrdInfo.uarPrdQue[upAddrInfo->uPrdPtr].uHwPrdIdx);
                gsPrdInfo.uarPrdQue[upAddrInfo->uPrdPtr].uUncFlag=cUncAfterTrig;
            }
            else
            {
                gsPrdInfo.uarPrdQue[upAddrInfo->uPrdPtr].uUncFlag=cUncBeforeTrig;
            }
        }

#if _EN_CHK_FINGER_FAIL
        if(mChkMlcMoBit(usTmpAddrInfo.u16FBlock))
        {
            if(gPSWstate==1)
            {
                setMarkBadBlock(&usBkAddrInfo, cS2TPWRFailID);
            }
            else
            {
                setMarkBadBlock(&usBkAddrInfo, cTLCRdEccFailID);
            }
        }
        else
        {
            setMarkBadBlock(&usBkAddrInfo, cRdEccFailID+gsReadRetryInfo.uRetryStartLevel);
        }
        gsFtlDbg.u16MarkBadCount++;
#endif/* if (_EN_RAID_DECODE) */

        gbEccFail|=1;
        gsFtlDbg.u16RaidDecDataFailCnt++;

        if(upAddrInfo->uRdEccFailIdx!=0xFF)
        {
            gsBadInfo.uarEccFailQue[upAddrInfo->uRdEccFailIdx].uRaidDecFail=cTrue;
        }

#if (!_EN_LiteonRetryLog)
        NLOG(cLogCore1, RAIDDEC_C, 0, "RaidDecDataFail");
#else
        if(!(mChkMlcMoBit(gpFlashAddrInfo->u16FBlock)))
        {
            NLOG(cLogCore1,
                 RAIDDEC_C,
                 4,
                 "RaidDecDataFail !! ->SLC mode CH: 0x%02X,CE: 0x%02X,Plan: 0x%04X,Block: 0x%04X,Page: 0x%04X",
                 (gsRaidInfo.uarRaidDecQue[gsRaidInfo.uRaidDecFifoHead].uCh<<8|gsRaidInfo.uarRaidDecQue[gsRaidInfo.uRaidDecFifoHead].uIntlvAddr),
                 gsRaidInfo.uarRaidDecQue[gsRaidInfo.uRaidDecFifoHead].uPlaneAddr,
                 // gsRaidInfo.uarRaidDecQue[gsRaidInfo.uRaidDecFifoHead].u16FBlock,
                 getDiffFBlock(gsRaidInfo.uarRaidDecQue[gsRaidInfo.uRaidDecFifoHead].u16FBlock,
                               gsRaidInfo.uarRaidDecQue[gsRaidInfo.uRaidDecFifoHead].uCh,
                               gsRaidInfo.uarRaidDecQue[gsRaidInfo.uRaidDecFifoHead].uIntlvAddr,
                               gsRaidInfo.uarRaidDecQue[gsRaidInfo.uRaidDecFifoHead].uPlaneAddr),
                 gsRaidInfo.uarRaidDecQue[gsRaidInfo.uRaidDecFifoHead].u16FPage);
        }
        else
        {
            NLOG(cLogCore1,
                 RAIDDEC_C,
                 4,
                 "RaidDecDataFail !! ->TLC mode CH: 0x%02X,CE: 0x%02X,Plan: 0x%04X,Block: 0x%04X,Page: 0x%04X",
                 (gsRaidInfo.uarRaidDecQue[gsRaidInfo.uRaidDecFifoHead].uCh<<8|gsRaidInfo.uarRaidDecQue[gsRaidInfo.uRaidDecFifoHead].uIntlvAddr),
                 gsRaidInfo.uarRaidDecQue[gsRaidInfo.uRaidDecFifoHead].uPlaneAddr,
                 // gsRaidInfo.uarRaidDecQue[gsRaidInfo.uRaidDecFifoHead].u16FBlock,
                 (getDiffFBlock(gsRaidInfo.uarRaidDecQue[gsRaidInfo.uRaidDecFifoHead].u16FBlock,
                                gsRaidInfo.uarRaidDecQue[gsRaidInfo.uRaidDecFifoHead].uCh,
                                gsRaidInfo.uarRaidDecQue[gsRaidInfo.uRaidDecFifoHead].uIntlvAddr,
                                gsRaidInfo.uarRaidDecQue[gsRaidInfo.uRaidDecFifoHead].uPlaneAddr)),
                 (gsRaidInfo.uarRaidDecQue[gsRaidInfo.uRaidDecFifoHead].u16FPage)*3);
            // ((cProgCntPerWL*(gsRaidInfo.uarRaidDecQue[gsRaidInfo.uRaidDecFifoHead].u16FPage))    /*+mGetPageSelCmd(gpFlashAddrInfo)-1)*/);
        }
#endif/* if (!_EN_LiteonRetryLog) */
    }
    else
    {
#if (!_EN_LiteonRetryLog)
        NLOG(cLogCore1, RAIDDEC_C, 0, "RaidDecDataPass");
#else
        if(!(mChkMlcMoBit(gpFlashAddrInfo->u16FBlock)))
        {
            NLOG(cLogCore1,
                 RAIDDEC_C,
                 4,
                 "RaidDecData Pass !! ->SLC mode CH: 0x%04X,Plan: 0x%04X,Block: 0x%04X,Page: 0x%04X",
                 gsRaidInfo.uarRaidDecQue[gsRaidInfo.uRaidDecFifoHead].uCh,
                 gsRaidInfo.uarRaidDecQue[gsRaidInfo.uRaidDecFifoHead].uPlaneAddr,
                 // gsRaidInfo.uarRaidDecQue[gsRaidInfo.uRaidDecFifoHead].u16FBlock,
                 getDiffFBlock(gsRaidInfo.uarRaidDecQue[gsRaidInfo.uRaidDecFifoHead].u16FBlock,
                               gsRaidInfo.uarRaidDecQue[gsRaidInfo.uRaidDecFifoHead].uCh,
                               gsRaidInfo.uarRaidDecQue[gsRaidInfo.uRaidDecFifoHead].uIntlvAddr,
                               gsRaidInfo.uarRaidDecQue[gsRaidInfo.uRaidDecFifoHead].uPlaneAddr),
                 gsRaidInfo.uarRaidDecQue[gsRaidInfo.uRaidDecFifoHead].u16FPage);
        }
        else
        {
            NLOG(cLogCore1,
                 RAIDDEC_C,
                 4,
                 "RaidDecData Pass !! ->TLC mode CH: 0x%02X,CE: 0x%02X,Plan: 0x%04X,Block: 0x%04X,Page: 0x%04X",
                 (gsRaidInfo.uarRaidDecQue[gsRaidInfo.uRaidDecFifoHead].uCh<<8|gsRaidInfo.uarRaidDecQue[gsRaidInfo.uRaidDecFifoHead].uIntlvAddr),
                 gsRaidInfo.uarRaidDecQue[gsRaidInfo.uRaidDecFifoHead].uPlaneAddr,
                 // gsRaidInfo.uarRaidDecQue[gsRaidInfo.uRaidDecFifoHead].u16FBlock,
                 (getDiffFBlock(gsRaidInfo.uarRaidDecQue[gsRaidInfo.uRaidDecFifoHead].u16FBlock,
                                gsRaidInfo.uarRaidDecQue[gsRaidInfo.uRaidDecFifoHead].uCh,
                                gsRaidInfo.uarRaidDecQue[gsRaidInfo.uRaidDecFifoHead].uIntlvAddr,
                                gsRaidInfo.uarRaidDecQue[gsRaidInfo.uRaidDecFifoHead].uPlaneAddr)),
                 (gsRaidInfo.uarRaidDecQue[gsRaidInfo.uRaidDecFifoHead].u16FPage)*3);
        }
#endif/* if (!_EN_LiteonRetryLog) */
        gsFtlDbg.u16RaidDecDataPassCnt++;
    }

    rmRaidCodecClr;
    resmRaidEngTask(uRaidEngIdx, uResmEng);
    rmSetRaidCurEngineSel(uRaidCurEngIdx);

#if _ENABLE_CPU_CYCLE_COUNTER
    g32Cpu1CycleCnt1=getCycleCounter();
    g32RaidTime=(g32Cpu1CycleCnt1-g32Cpu1CycleCnt0)*(1000/(tran2DecClk()/1000000));
#endif

    if(upAddrInfo->u16RwOpt&cRetryAutoBuf)
    {
        setDecBufFlag(upAddrInfo, u16ErrChunkMap, upAddrInfo->uRwHalfKb, cTrue);
    }

    mWaitCmdFifoBz;

#if (_GREYBOX)
    if(rmChkRaidDecOutErrChunkMap&u16ErrChunkMap)
    {
        gsGbInfo.uStag=cVsRaidDecH2fFailCnt;
        gsGbInfo.u32BkValue=(gsFtlDbg.u16RaidDecDataFailCnt<<4||gsRaidInfo.u16arErrChunkMap[uIdx]);
    }
    else
    {
        gsGbInfo.uStag=cVsInit;
    }

    if((gsGbInfo.uGreyBoxItem==cRAIDDecOnPreReadData)||(gsGbInfo.uGreyBoxItem==cRAIDDecOnLastReadData))
    {
        copyTsb2Sdram((BYTE *)c32GreyBoxBuf, (UCBYTE *)(cTsb0Addr+g16GbGcCachebActThr*512), 2*1024);
    }
#endif/* if _GRYBOX */
}    /* trigRaidDecData */

void trigRaidDecH2f(BYTE uIdx)
{
    ADDRINFO usTmpAddrInfo;
    RAIDDECADDR *upAddrInfo;
    WORD u16ErrChunkMap, u16BufPtr, u16WantedPage, uSectorH;
    BYTE uRaidEngIdx, uRaidCurEngIdx, uCh, uStCh, uPlaneCnt, uRaidSctrNum, uRwHalfKb;
    BYTE uLoop;

    upAddrInfo=&gsRaidInfo.uarRaidDecQue[uIdx];
    u16ErrChunkMap=gsRaidInfo.u16arErrChunkMap[uIdx];

    u16WantedPage=upAddrInfo->uPlaneAddr+gPlaneNum*(upAddrInfo->uCh&((gTotalPlaneOfH2fTab/gPlaneNum)-1));

    if(upAddrInfo->uOpTyp==cH2fReadTab)
    {
        uRaidSctrNum=gsRaidInfo.uarRaidTotalType[cRaidHTabBlk].uSctrNum-1;
        uRwHalfKb=gSectorPerPlaneH;
    }
    else if(upAddrInfo->uOpTyp==cH2fRead1kTab)
    {
        uRaidSctrNum=0;
        uRwHalfKb=cSctrPerRH2fTab;
    }

    if(u16WantedPage!=cRaidHTabKVal)
    {
#if _ENABLE_CPU_CYCLE_COUNTER
        initCyclecounter();
        g32Cpu1CycleCnt0=getCycleCounter();
#endif

        uRaidCurEngIdx=rmChkRaidCurEngineSel;
        uRaidEngIdx=termRaidEngTask();
        initRaidDecode(cRaidHTabKVal, u16WantedPage, u16ErrChunkMap, uRaidSctrNum, uRaidEngIdx);

        u16BufPtr=upAddrInfo->u16BufPtr;
        uSectorH=upAddrInfo->uSectorH;
        usTmpAddrInfo.u16FBlock=upAddrInfo->u16FBlock;
        usTmpAddrInfo.u16FPage=upAddrInfo->u16FPage;
        usTmpAddrInfo.uIntlvAddr=upAddrInfo->uIntlvAddr;
        usTmpAddrInfo.uCe=(BYTE)mGetCEAddr(upAddrInfo->uIntlvAddr);
        usTmpAddrInfo.uDieAddr=mGetDieAddr(upAddrInfo->uIntlvAddr);
        uStCh=upAddrInfo->uCh&(gTotalPlaneOfH2fTab/gPlaneNum);

        uCh=uStCh;
        uPlaneCnt=gTotalPlaneOfH2fTab;

        while(uPlaneCnt)
        {
            usTmpAddrInfo.uCh=uCh++;
            setFLAddrActCh(usTmpAddrInfo.uCh, &usTmpAddrInfo);
            gPlaneAddr=0;
            gSectorH=0;
            mSetFRwParam(0, 0, c16Bit0|c16Bit9|c16Bit15, cReadCmdAle);
            waitChCeBz(usTmpAddrInfo.uCh, usTmpAddrInfo.uIntlvAddr, 0);
            flashReadPage();
            setBzInfo(cReadCmdAle, usTmpAddrInfo.uCh, usTmpAddrInfo.uIntlvAddr);
            gsRwCtrl.usWaitInfo[usTmpAddrInfo.uCh][usTmpAddrInfo.uIntlvAddr].uStatusErrStop=0;
            uPlaneCnt-=gPlaneNum;
        }

        uCh=uStCh;
        uPlaneCnt=gTotalPlaneOfH2fTab;

        while(uPlaneCnt)
        {
            usTmpAddrInfo.uCh=uCh++;
            setFLAddrActCh(usTmpAddrInfo.uCh, &usTmpAddrInfo);
            rmSetDecModeRaid;
            // rmSetForceXfrTsbLdpc; //debug
            gSectorH=uSectorH;
            rmSetRaidDecStartSect(gSectorH);
            mSetFRwParam(u16BufPtr, uRwHalfKb, c16Bit2|c16Bit4|c16Bit10, cRaidDecRead);
            waitChCeBz(usTmpAddrInfo.uCh, usTmpAddrInfo.uIntlvAddr, 0);

            for(gPlaneAddr=0; gPlaneAddr<gPlaneNum; gPlaneAddr++)
            {
                flashReadPage();
            }

            setBzInfo(cRaidDecRead, usTmpAddrInfo.uCh, usTmpAddrInfo.uIntlvAddr);
            gsRwCtrl.usWaitInfo[usTmpAddrInfo.uCh][usTmpAddrInfo.uIntlvAddr].uStatusErrStop=0;
            uPlaneCnt-=gPlaneNum;
        }

        while(!rmChkRaidDecInDone)
            ;

        rmTrigRaidDecOut;

        setSelMulFL(1);
        rmClrDecModeRaid;
        setSelMulFL(0);

        rmWaitSysCmdFifoBz;
        setFLActCh(upAddrInfo->uCh);
        rmSetChunkEccStsMap(rmChkRaidDecOutErrChunkMap);
        rmRaidCodecClr;
        resmRaidEngTask(uRaidEngIdx, cFalse);
        rmSetRaidCurEngineSel(uRaidCurEngIdx);

        if(rmChkRaidDecOutErrChunkMap&u16ErrChunkMap)
        {
            for(uLoop=0; uLoop<upAddrInfo->uRwHalfKb; uLoop++)
            {
                if(mChkBitMask(rmChkRaidDecOutErrChunkMap, uSectorH>>2))
                {
                    // reset H2F
                    bopClrRam((LWORD)(upAddrInfo->u16BufPtr+uLoop)*512+c32Tsb0SAddr, 512, cUncTypeMask, cClrTsb|cBopWait);
                }

                uSectorH++;
            }

            gbEccFail|=1;
            gsFtlDbg.u16RaidDecH2fFailCnt++;

            if(upAddrInfo->uRdEccFailIdx!=0xFF)
            {
                gsBadInfo.uarEccFailQue[upAddrInfo->uRdEccFailIdx].uRaidDecFail=cTrue;
            }

            gsFtlDbg.u16DummyFailType=cH2fDecodeFail;
            // debugWhile();
        }
        else
        {
            gsFtlDbg.u16RaidDecH2fPassCnt++;
        }

#if _ENABLE_CPU_CYCLE_COUNTER
        g32Cpu1CycleCnt1=getCycleCounter();
        g32RaidTime=(g32Cpu1CycleCnt1-g32Cpu1CycleCnt0)*(1000/(tran2DecClk()/1000000));
#endif
    }
    else
    {
        g16RaidDecSkipCnt++;
    }

    if(upAddrInfo->u16RwOpt&cRetryAutoBuf)
    {
        setDecBufFlag(upAddrInfo, u16ErrChunkMap, uRwHalfKb, cFalse);
    }

    mWaitCmdFifoBz;

#if (_GREYBOX)
    if(rmChkRaidDecOutErrChunkMap&u16ErrChunkMap)
    {
        gsGbInfo.uStag=cVsRaidDecH2fFailCnt;
        gsGbInfo.u32BkValue=(gsFtlDbg.u16RaidDecH2fFailCnt<<4||gsRaidInfo.u16arErrChunkMap[uIdx]);
    }
    else
    {
        gsGbInfo.uStag=cVsInit;
    }
#endif/* if _GRYBOX */
}    /* trigRaidDecH2f */

#if 0
void trigTsbDecH2f(BYTE uIdx)    // need check
{
    RAIDDECADDR *upAddrInfo;
    WORD u16TotalPage, u16ErrChunkMap, u16BufPtr, u16WantedPage, u16PageIdx;
    BYTE uRaidEngIdx;

    upAddrInfo=&gsRaidInfo.uarRaidDecQue[uIdx];
    u16ErrChunkMap=gsRaidInfo.u16arErrChunkMap[uIdx];

    u16TotalPage=cRaidHTabKVal;
    u16WantedPage=upAddrInfo->uPlaneAddr+gPlaneNum*upAddrInfo->uCh;

    if(u16WantedPage==cRaidHTabKVal)
    {
        return;
    }

    uRaidEngIdx=termRaidEngTask();
    rmSetRaidCurEngineSel(uRaidEngIdx);
    rmRaidCodecClr;
    rmSetRaidDecWantedPage(u16WantedPage);
    rmSetRaidSctrNum(gsRaidInfo.uarRaidTotalType[cRaidHTabBlk].uSctrNum-1);
    rmSetRaidKValue(u16TotalPage);
    rmHdmaDecInit;

    u16BufPtr=upAddrInfo->u16BufPtr;
    u16BufPtr-=u16WantedPage*gSectorPerPlaneH;

    for(u16PageIdx=0; u16PageIdx<=u16TotalPage; u16PageIdx++)
    {
        if(u16PageIdx==u16WantedPage)
        {
            rmSetDecErrMap(u16ErrChunkMap);
        }
        else
        {
            rmClrDecErrMap;    // need to input the other fail page err map
        }

        trigRaidBopDecIn(u16BufPtr, gSectorPerPlaneH, cBopSrcNonFlag, u16PageIdx, 0);
        u16BufPtr+=gSectorPerPlaneH;
    }

    rmSetDecErrMap(u16ErrChunkMap);
    trigRaidBopDecOut(upAddrInfo->u16BufPtr, gSectorPerPlaneH, cBopDesNonFlag, u16TotalPage, 0);

    setFLActCh(upAddrInfo->uCh);
    rmSetChunkEccStsMap(rmBopRaidDecErrMap);

    if(upAddrInfo->u16RwOpt&cRetryAutoBuf)
    {
        setDecBufFlag(upAddrInfo, u16ErrChunkMap, gSectorPerPlaneH, cFalse);
    }

    mWaitCmdFifoBz;

    if(rmBopRaidDecErrMap)
    {
        gbEccFail|=1;
        gsRaidInfo.u16RaidDecFailCnt++;
    }
    else
    {
        rmResetResultFlag;
    }

    rmRaidCodecClr;
    resmRaidEngTask(uRaidEngIdx, cFalse);
}    /* trigTsbDecH2f */

#endif/* if 0 */

void doRaidDecode()
{
    BYTE uOpTyp, uIdx;

    while(gsRaidInfo.uRaidDecQueCnt)
    {
        g16RaidDecTotalCnt++;
        uIdx=gsRaidInfo.uRaidDecFifoTail;
        uOpTyp=gsRaidInfo.uarRaidDecQue[uIdx].uOpTyp;

        switch(uOpTyp)
        {
            case cPreReadData:
            case cLastReadData:
            case cHostReadData:
            case cMoveReadData:
            case cSecReadData:
                trigRaidDecData(uIdx);
                break;

            case cH2fReadTab:
            case cH2fRead1kTab:
                trigRaidDecH2f(uIdx);
                break;

            default:
                gsFtlDbg.u16DummyFailType=cDoRaidDecode;
                debugWhile();    // g16RaidDecSkipCnt++;
        }    /* switch */

        gsRaidInfo.uRaidDecFifoTail=addPtrBy1(gsRaidInfo.uRaidDecFifoTail, cRaidDecQueDepth);
        gsRaidInfo.uRaidDecQueCnt--;
    }

    while(gsRaidInfo.uRaidDecFifoTail!=gsRaidInfo.uRaidDecFifoHead)
        ;

    NLOG(cLogCore1, RAIDDEC_C, 0, "RaidDec End");
}    /* doRaidDecode */

#else/* if _EN_RAID_DECODE */
void doRaidDecode()
{}

#endif/* if _EN_RAID_DECODE */







