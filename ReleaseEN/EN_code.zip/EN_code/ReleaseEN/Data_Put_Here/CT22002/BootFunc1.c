







#include "inc/DebugLog.h"
#include "inc/EventLogIDX.h"
#include "inc/EventLogFunctionIDX.h"
#include "inc/Const.h"
#include "inc/TypeDef.h"
#include "inc/Option.h"
#include "inc/ProType.h"
#include "inc/Asm.h"
#include "inc/GlobVarS.h"
#include "inc/GlobVar0.h"
#include "inc/GlobVarT.h"
#include "inc/NvmeCtrl.h"
#include "inc/BitDef.h"
#include "inc/Reg.h"
#include "inc/Rdlink.h"
#include "inc/Mac.h"
#include "Common/Model.h"
#if (_GREYBOX)
#include "inc/GreyBox.h"
#endif

#if (!_ICE_LOAD_ALL)
#pragma default_function_attributes = @ ".CORE0_BOOT1"
#endif

#include "TaskFuncForPrj.c"
#include "SysCtrlBoot.c"
#if (!_ICE_LOAD_ALL)
#include "H2fTab.c"
#include "F2hTab.c"
// #include "FwCommitDl.c"
#endif
#include "Vic0Ctrl.c"
#include "FlashCmdDir.c"
#include "Ftl.c"
#include "SaveIdx.c"

#if _ENABLE_SECAPI
#include "Write.c"
#include "Read.c"
#include "TrimCmd.c"
#include "NvmeCommonFunc.c"
#endif
#include "I2cCtrl.c"
#if ((_ICE_LOAD_ALL)&&(_WO_INFOB))
#include "LightSwitch.c"
#endif

void bootFunc1()
{
#if _BuildIceLoadAllBin
    while(1)
        ;
#endif

    if(((!rmChkSoftwareReset)&&(!rmChkInDevSlp))||rmChkManufactureFlag)
    {
        rmPcieIntr01StsInit;
        rmPcieIntr23StsInit;    // 2263
    }

    initSram();
    initTsb0VarPointer();

    __enable_ve();    // enable Vectored Interrupt Controller
    initVic0(0);
    __enable_irq();

    mSetHandlePcieRstF;    // gHandlePcieRstInIsr=1;

    initCache();

    setBasicPoint();
#if ((!_ICE_DEBUG)||(_DONTGETPARA))
    initRootBlockVar();    // because TSB will be reset at initBufWrap()
#endif

#if (!_EN_CPUCLK575)
    setSysPllClock(400);
#else
    setSysPllClock(575);
#endif

    initUart();
    g32OutputUART=1;
    g32Core1State=cCore1SupendState;
    enableCore1();
    // g32Core1State=cCore1SupendState;

    while(!(g32Core1State==cCore1BootState_0))
        ;// wait core-1 boot up

    setClockGate(cWakeupFlow);
#if _ENABLE_NAND_UART_DEBUG
    g32OutputUART=1;
#else
    g32OutputUART=0;
#endif
#if ((_ICE_DEBUG)&&(!_DONTGETPARA))
    setOrgFlashCmd();
#endif

    // initNvmeGlobVar(1);
    redefParaVal();
    // gFuaWrSta=cFUACmdReset;
    // g32MaxDataXfrSec=0x10000;

    g32HostTotalDataSectorCnt=g32TotalDatSector;

    // gWritePrdCnt=0;
#if (!_TSB_BiCS4_WR)
    bopClrRam((LWORD)g16arEventLog, sizeof(g16arEventLog), 0x00000000, cBopWait|cClrTsb);
#endif
    bopClrRam((LWORD)g16arLinkLog, sizeof(g16arLinkLog), 0x00000000, cBopWait|cClrStcm);
    bopClrRam((LWORD)&garCmdHistory, sizeof(garCmdHistory), 0x00000000, cBopWait|cClrStcm);
#if _GREYBOX
    bopClrRam((LWORD)&garGbCmdHistory, sizeof(garGbCmdHistory), 0x00000000, cBopWait|cClrStcm);
#endif
    g16SaveEventLog=g16SaveEventLog2=0;
    gsFtlDbg.u16FtlEventReason=0;
    g32RxTrigStartmsTime=0;
    gFWShnFlag=0;

    gVuMode=0;    // for Vu Cmd
    gTlcMode=0;    // for Vu Cmd
    gProgFifoPtr=cBitFF;
    gDLFWFail=0;    // Fix DriveMaster Protocl FwDnld Scirpt Issue for HP 20190719_Wade
#if _EN_FWCommit_Protect
    gJustReturnPass=0;
#endif

    initBop();

    mClrStartThrottlingSt;

    if(!rmChkInDevSlp)
    {
        if(g16RTCTrim)
        {
            initTimer(g16RTCTrim);
        }
        else
        {
            initTimer(0xD8);
        }

        i2cInit();
        // i2cSetPmicAct88325();
        i2cSetPmicAct88325_Active();    // Core power 0.9V-->0.925V;20181221_Eason_02
    }
    else
    {
#if (_ENABLE_PM_BACKUP_SMART)
        rmRtc2HzIntDisable;

        if(rmGetRtc2HzTick>=cPsModeRtcWakeupPos10Min)
        {
            rmRtc2HzClearInt;

            while(rmChkRtc2HzInt)
                ;

            gSmartBackup=1;
        }

        rmSetRtc2HzMaskLo(0xFFFE);    // resume 1s interrupt
        rmRtc2HzReset;
#endif
        rmRtc2HzIntEnable;    // PS4 resume
    }

    gsDebugInfo.u32PowerOnTime=getRtcCurrent32k();

    initGPIO();

#if (!(_GREYBOX||_SM226X_A0||_INITDRAM))
    initDramLowPower();    // Set Dram to low power mode, Some SM2263AA has dram pll lock issue.
#endif

    if(!rmChkInDevSlp)
    {
        findSysRsvBlock();
    }

    g32Core1State=cCore1BootState_1;

    gsDebugInfo.u32FindSysBlkTime=getRtcCurrent32k();

    // wait core1 load different address
    while(!(g32Core1State==cCore1BootState_2))
        ;

    gsDebugInfo.u32FindSysBlkTime=getRtcCurrent32k();

    loadLightSwitch();
    initSecuritySwitches();

    // Set programmable timer for Novatek PMIC go to sleep time
    // PS4 doesn't set rmSysXtalDiv128
    // PS4 set rmSysXtalDiv1, down period is about 0.01ms * rmSetExPwdnTimer(x)
    rmSetExPwdnTimer(gsLightSwitch.usNvmeLs.uPdTimer);    // it is 0.01ms unit

    // doorBellPatch();    // 2263
    initGlobOpt(rmChkInDevSlp);
    initVdt();
}    /* bootFunc1 */

#if (_ICE_DEBUG|_PRJ_MPISP)
#if (!_WO_INFOB)
CBYTE cbTestParamTab[]    /*cSizeOfParaPageId*/=
{
    /*param 0x00A*/
    0x53, 0x4D, 0x32, 0x32, 0x36, 0x30, 0x50, 0x41, 0x52, 0x41, 0xEC,    /*0x00, 0xF5, 0x03, 0xFF, 0xFF,*/
};
#else
CBYTE cbTestParamTab[]=
{
    /*param 0x00A*/
    0x53, 0x4D, 0x32, 0x32, 0x36, 0x30, 0x50, 0x41, 0x52, 0x41, 0xAD, cCardMode, cFLParam, cFLOption, 0x00, 0x00,
    /*param 0x010*/
    cChMap, cCeMap, cIntlvWay, cPlaneNum, cTotalChNum, cTotalCeNum, cTotalIntlvChNum, cTotalDiePerCe, cDataECCLevel, cSprECCLevel, cPageNumReg,
    cBlockNumReg,
    cPlaneNumReg, 0x00, cTotalIntlvChPlaneNum, cTotalChPlaneNum,
    /*param 0x020*/
    0x00, 0x01, 0x02, 0x03, 0x04, 0x05, 0x06, 0x07, 0xFF, 0xFF, 0xFF, 0xFF, 0x00, 0x00, 0x00, 0x00,
    /*param 0x030*/
    c16FirstFBlock, c16FirstFBlock>>8, c16TotalFBlock,
    (c16TotalFBlock>>8), c16TotalHBlock, c16TotalHBlock>>8, c16FBlockPerCe, c16FBlockPerCe>>8, 0xB4, 0x03,
    0x00, 0x00, 0x00, 0x00, 0x00, 0x00,
    /*param 0x040*/
    cSectorPerPageF, cSectorPerPageH, cSectorPerPlaneF, cSectorPerPlaneH, 0x00, 0x00, c16PagePerBlock1, (c16PagePerBlock1>>8),
    c16PagePerBlock1_SLC,
    c16PagePerBlock1_SLC>>8, c16PagePerBlock3_SLC, (c16PagePerBlock3_SLC>>8), c32SectorPerBlockH, c32SectorPerBlockH>>8, c32SectorPerBlockH>>16,
    c32SectorPerBlockH>>24,
    /*param 0x050*/
    cCacheReadCmd, cLastPageCacheReadCmd, cCacheProgCmd, cRandomInCmd, cRandomOut1Cmd, cRandomOut2Cmd, cReadStatusCmd, cReadStatusEnhCmd,
    cSlcMoAccessCmd,
    cSlcMoAbortCmd, cMulPlaneRead1Cmd, cMulPlaneRead2Cmd, cMulPlaneProg1Cmd, cMulPlaneProg2Cmd, cSyncResetCmd, cPriBlockErase2Cmd,
    /*param 0x060*/
    0xB0, 0x4B, 0xF9, 0x0D, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, cIntlvPlaneNum, 0x01, 0x00, 0x00, 0x00, 0x00,
    /*param 0x070*/
    0x05, 0x15, 0x25, 0x35, 0x45, 0x46, 0x4E, 0x50, 0x00, 0x00, 0x00, 0x00, c16ValidTlcPgPerF2hTab, c16ValidTlcPgPerF2hTab>>8, 0x00, 0x00,
    /*param 0x080*/
    c16ValidPgPerF2hTab, c16ValidPgPerF2hTab>>8, c16PagePerH2fTab, c16PagePerH2fTab>>8, c16TotalPgPerF2hTab, c16TotalPgPerF2hTab>>8,
    c16MaxCachePageNum, c16MaxCachePageNum>>8, c16TotalTlcPgPerF2hTab, c16TotalTlcPgPerF2hTab>>8, cTotalPlaneOfH2fTab, cTotal4kNumOfF2hTab,
    cTotalPlaneOfCacheInfoTab, cTotalBankOfF2hTab, c4kNumPerPlane, c4kNumPerPage,
    /*param 0x090*/
    cPlaneSizeBitCnt, cPlaneBitCnt, cChBitCnt, cCeBitCnt, cDieBitCnt, cPlaneAddrBitShiftCnt, cChAddrBitShiftCnt, cCeAddrBitShiftCnt,
    cDieAddrBitShiftCnt2,
    cPhyPageAddrBitShiftCnt, cSlcMaxBank, 0x00, 0x00, 0x00, 0x00, 0x00,
    /*param 0x0A0*/
    0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00,
    /*param 0x0B0*/
    c32VpcPerTlcBlk, c32VpcPerTlcBlk>>8, c32VpcPerTlcBlk>>16, c32VpcPerTlcBlk>>24, c16MaxDualMoPeThr, c16MaxDualMoPeThr>>8,
    c16TlcFullCachebGcThr, c16TlcFullCachebGcThr>>8, c32VpcPerSlcBlk, c32VpcPerSlcBlk>>8, c32VpcPerSlcBlk>>16, c32VpcPerSlcBlk>>24,
    cTotalTlcBankOfF2hTab, cPhyDiePerPackage, 0x00, 0x00,
    /*param 0x0C0*/
    c32PagePerBlock2, c32PagePerBlock2>>8, c32PagePerBlock2>>16, c32PagePerBlock2>>24, c32PagePerBlock2By4k, c32PagePerBlock2By4k>>8,
    c32PagePerBlock2By4k>>16, c32PagePerBlock2By4k>>24, c32PagePerBlock2_SLCBy4k, c32PagePerBlock2_SLCBy4k>>8, c32PagePerBlock2_SLCBy4k>>16,
    c32PagePerBlock2_SLCBy4k>>24, 0x00, 0x00, 0x00, 0x00,
    /*param 0x0D0*/
    0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00,
    /*param 0x0E0*/
    0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00,
    /*param 0x0F0*/
    cFlashId_0, cFlashId_1, cFlashId_2, cFlashId_3, cFlashId_4, cFlashId_5, cFlashId_6, cFlashId_7,
    cCeDieMap_0, cCeDieMap_1, cCeDieMap_2, cCeDieMap_3, cCeDieMap_4, cCeDieMap_5, cCeDieMap_6, cCeDieMap_7,
};

#endif/* if !_WO_INFOB */
#endif/* if (_ICE_DEBUG|_PRJ_MPISP) */

void setChMapTab()
{
    BYTE uChIdx=0;
    BYTE uLoop;

    for(uLoop=0; uLoop<cMaxPhyChNum; uLoop++)
    {
        if(mChkBitMask(gChMap, uLoop))
        {
            garChMapTable[uChIdx]=uLoop;
            uChIdx++;
        }
    }
}

void setCeMapTab()
{
    BYTE uChIdx=0;
    BYTE uLoop;

    for(uLoop=0; uLoop<cMaxCePinNum; uLoop++)
    {
        if(mChkBitMask(gCeMap, uLoop))
        {
            garCeMapTable[uChIdx]=uLoop;
            uChIdx++;
        }
    }
}

void setBasicPoint()
{
    gChMap=gCeMap=0xFF;

    setCeMapTab();
    setChMapTab();

    // Flash CTRL
    regFSHA=(void *)rFSHA;    // Align Rom code
    reg16FSHA=(void *)rFSHA;    // Align Rom code
    reg32FSHA=(void *)rFSHA;    // Align Rom code
    rFLCtrl=(void *)rFSHA;
    r16FLCtrl=(void *)rFSHA;
    r32FLCtrl=(void *)rFSHA;

    regLdpcDsp=(void *)rLdpcDspCtrl;
    reg16LdpcDsp=(void *)rLdpcDspCtrl;
    reg32LdpcDsp=(void *)rLdpcDspCtrl;
    rLdpcDsp=(void *)rLdpcDspCtrl;    // 0x51200000
    r16LdpcDsp=(void *)rLdpcDspCtrl;
    r32LdpcDsp=(void *)rLdpcDspCtrl;
}    /* setBasicPoint */

void initTsb0VarPointer()
{
    garTsb0=(void *)cTsb0Addr;
    g16arTsb0=(void *)cTsb0Addr;
    g32arTsb0=(void *)cTsb0Addr;
    g64arTsb0=(void *)cTsb0Addr;

    garBadInfoBuf=(void *)cTsb0Addr;
    g16arBadInfoBuf=(void *)cTsb0Addr;
    g32arBadInfoBuf=(void *)cTsb0Addr;

    gpNvmeFeatVar=(void *)cTsb0Addr;
    gpGetLog=(void *)cTsb0Addr;

#if _ENABLE_SECAPI
    garIfSendBufPtr=(void *)cTrustedIfSendAddr;
    garIfRecvBufPtr=(void *)cTrustedIfRecvAddr;
#endif
}    /* initTsb0VarPointer */

void setFlashParam()
{
#if (!_WO_INFOB)
#else
    // copyCcmVal((BYTE *)c32StcmSAddr, (BYTE *)cbTestParamTab, 0x70);
    copyCcmVal((BYTE *)c32Tsb0SAddr, (BYTE *)cbTestParamTab, 0x100);

    // setBasicPoint();
#endif

    // setAutoAleCtrl();
    // setChunkMem();
}

#if _ICE_DEBUG&&(!_WO_INFOB)
void clrFLAleReg()
{
    BYTE uLoop;

    for(uLoop=0; uLoop<5; uLoop++)
    {
        rFLCtrl[rcALE0+uLoop]=0x00;
    }
}

void setParaPageAddr(BYTE uBlock)
{
    WORD u16Block;

    u16Block=(uBlock*cParaIncPageNum)+cRsv4BootLdr;

    rFLCtrl[rcALE2]=u16Block;
    rFLCtrl[rcALE3]=u16Block>>8;

    rmSetSeed(0x3C0B);
}

/*
   * void setParaPrefixSlcCmd(BYTE uRetryLoop)
   * {
   *  switch (uRetryLoop)
   *  {
   *      case cSlcRead:
   *          rmCle(0xA2);
   *          break;
   *
   *      case cRlibRead:
   *          rmCle(0xDA);
   *          break;
   *
   *      case cNorRead:
   *      default:
   *          break;
   *  }
   * }
   */

void uniCeFlashMap()
{
    BYTE u1stCeFlashMap=0, uTempFlag=0;

    uTempFlag=0;

    for(gActiveCe=0; ((gActiveCe<cMaxCePinNum)&&!uTempFlag); gActiveCe++)
    {
        if(garCeFlashMap[gActiveCe]!=0)
        {
            u1stCeFlashMap=garCeFlashMap[gActiveCe];
            uTempFlag=1;
        }
    }

    while(gActiveCe<cMaxCePinNum)
    {
        if(garCeFlashMap[gActiveCe]!=u1stCeFlashMap)
        {
            if((garCeFlashMap[gActiveCe]&u1stCeFlashMap)==u1stCeFlashMap)
            {
                garCeFlashMap[gActiveCe]=u1stCeFlashMap;
            }
            else
            {
                garCeFlashMap[gActiveCe]=cZero;
            }
        }

        gActiveCe++;
    }
}    /* uniCeFlashMap */

BYTE setCeFlashMap(BYTE uSelContDieSeq)
{
    WORD u16Delay;
    BYTE uTotalAccessCeCnt=0;

    fillCcmVal(garCeFlashMap, cMaxCePinNum, 0x00);

    for(gActiveCe=0; gActiveCe<cMaxCePinNum; gActiveCe++)
    {
        for(gActiveCh=0; gActiveCh<cMaxPhyChNum; gActiveCh++)
        {
            u16Delay=0;
            setFLActCh(gActiveCh);    // setFLAddrActCh(gActiveCh, &garFlashAddrInfo[gActiveCh]);
            clrFLAleReg();

            if(uSelContDieSeq)
            {
                // here can add other select mode
                rFLCtrl[rcALE4]=0x10*gActiveCe;
            }

            rmDirCeOn(gActiveCe);
            rmCle(gPageReadCmd1);
            rmManAle(5);
            rmCle(gLastPageCacheReadCmd);
            // sandiskDieSelect(gActiveCe);
            rmCle(gReadStatusCmd);
            // rmMiscTimerLen(600);
            // rmTimerTrig;
            rmRdStatus(cPollMaskNor);
            rmManRd(1);

            while(rmChkCmdFifoBz)
            {
                u16Delay++;

                if(u16Delay>2000)
                {
                    rmChSoftReset;    // rmRstCmdFifo;
                    resetEcc();    // rmRstFLSts;
                    break;
                }
            }

            if((rFLCtrl[rcRd0]!=0x70)&&(rFLCtrl[rcRd0]!=0xFF))
            {
                uTotalAccessCeCnt++;

                // if (gbTOFlag)
                // {
                // gbTOFlag=0;
                // }
                // else
                if(u16Delay<2000)
                {
                    rmChSoftReset;    // rmRstCmdFifo;
                    garCeFlashMap[gActiveCe]|=(1<<gActiveCh);
                }
            }
        }

        rmAllCeOff;

        while(rmChkCmdFifoBz)
            ;
    }

    // gbTOFlag=0;
    return uTotalAccessCeCnt;
}    /* setCeFlashMap */

void setChCeConfig()
{
    BYTE uDieMapMo, uCnt[3]=
    {
        0
    };

    // set initial variable
    gTotalCeNum=4;
    gTotalChNum=4;
    gCeMap=0x0F;
    gChMap=0xFF;
    // //////////////

    setBasicPoint();

    if(rmGpioP06SelToggle)
    {
        setBusToggleMode();
    }

    for(uDieMapMo=0; uDieMapMo<3; uDieMapMo++)
    {
        // Mode 2 is the same as mode 0 (for shorting code size)
        resetFlash();
        uCnt[uDieMapMo]=setCeFlashMap(uDieMapMo);

        if((uCnt[1]>uCnt[0])||(uDieMapMo==2))
        {
            break;
        }
        else if(uDieMapMo==1)
        {
            mClrCardMode(cMultiDie);
            continue;
        }

        mSetCardMode(cMultiDie);
    }

    uniCeFlashMap();

    setFLActCh(0);
}    /* setChCeConfig */

BYTE chkParaPageId()
{
    BYTE uLoop;
    BYTE *uarRwBuf2;

    uarRwBuf2=(void *)cTsb0Addr;

    for(uLoop=0; uLoop<cSizeOfParaPageId; uLoop++)
    {
        if(uarRwBuf2[uLoop]!=cbTestParamTab[uLoop])
        {
            return cFalse;
        }
    }

    return cTrue;
}

BYTE srchParaPage(BYTE uRetryLoop)
{
    BYTE uBlock;
    WORD u16Delay;

    for(gActiveCe=0; gActiveCe<cMaxCePinNum; gActiveCe++)
    {
        for(gActiveCh=0; gActiveCh<cMaxChNum; gActiveCh++)
        {
            setFLActCh(gActiveCh);    // setFLAddrActCh(gActiveCh, &garFlashAddrInfo[gActiveCh]);
            clrFLAleReg();

            if(mChkBitMask(garCeFlashMap[gActiveCe], gActiveCh))
            {
                for(uBlock=0; uBlock<cMaxParaBlkAddr; uBlock++)
                {
                    u16Delay=0;
                    setParaPageAddr(uBlock);
                    rmDirCeOn(gActiveCe);

                    // setParaPrefixSlcCmd(uRetryLoop);
                    if(!uRetryLoop&&(gSlcMoAccessCmd!=0xFF))
                    {
                        // use ICE to load code, you have to set command
                        rmCle(gSlcMoAccessCmd);

                        // rmCle(0xDA);
                    }

                    rmCle(gPageReadCmd1);
                    rmManAle(5);
                    rmCle(gPageReadCmd2);
                    rmCle(gReadStatusCmd);
                    rmRdStatus(cPollMaskNor);
                    rmCle(gPageReadCmd1);
                    rmCle(gRandomOutCmd1);
                    rmManAle(5);
                    rmCle(gRandomOutCmd2);
                    rmSetStartSector(0);
                    rmSetBufSAddr(c16Tsb0SIdx);
                    rmRdDataDisBuf;
                    rmRdData(cSizeOfBootLdr);
                    rmAllCeOff;

                    while(rmChkCmdFifoBz)
                    {
                        u16Delay++;

                        if(u16Delay>20000)
                        {
                            rmChSoftReset;    // rmRstCmdFifo;
                            resetEcc();    // rmRstFLSts;
                            break;
                        }
                    }

                    if(!rmChkUNC&&(u16Delay<=20000))
                    {
                        if(chkParaPageId())
                        {
                            return cTrue;
                        }
                    }
                    else
                    {
                        resetEcc();    // rmRstFLSts;
                    }
                }
            }
            else
            {}
        }

        setFLActCh(0);
    }

    return cFalse;
}    /* srchParaPage */

#endif/* if _ICE_DEBUG&&(!_WO_INFOB) */

void getParamTab()
{
    setFlashParam();

#if _ICE_DEBUG
#if (!_WO_INFOB)
    BYTE uRetryLoop=0;

    enEccInMax();

    // put para in TSB0
    while((uRetryLoop<cMaxSrchParaLoop)&&!srchParaPage(uRetryLoop))
    {
        uRetryLoop++;
    }
    enEccInNormal();
#endif
    // put seed in TSB0+0x400
    // copyCcmVal((BYTE*)c32Tsb0SAddr+0x400, (BYTE*)cb16TlcSeedTable, c16SeedTableSize*2);//seed
#endif/* if !_WO_INFOB */
}    /* getParamTab */

void tempSetFlashCmd()
{
    garFLCmdSetTab2[cPageRead1]=0x00;
    garFLCmdSetTab2[cPageRead2]=0x30;
    garFLCmdSetTab2[cPageProg1]=0x80;
    garFLCmdSetTab2[cPageProg2]=0x10;
    garFLCmdSetTab2[cBlockErase1]=0x60;
    garFLCmdSetTab2[cBlockErase2]=0xD0;
    garFLCmdSetTab2[cReset]=0xFF;
    garFLCmdSetTab2[cSetFeature]=0xEF;
    garFLCmdSetTab2[cSetDieFeature]=0xEF;
}

void initRootBlockVar()
{
#if ((_ICE_DEBUG)&&((!_DONTGETPARA)||(_WO_INFOB)))
    tempSetFlashCmd();
#if (!_WO_INFOB)
    setChCeConfig();
#endif
    getParamTab();
#endif

    bopCopyRam((LWORD)(BYTE *)garParaPageId, c32Tsb0SAddr, 0x100, cCopyTsb2Stcm|cBopWait);    // Parameter

    setCeMapTab();
    setChMapTab();
}    /* initRootBlockVar */

void findSysRsvBlock()
{
#if (!_WO_INFOB)    // should do in bootisp
    BYTE uRsvSysBlkNum;
    BYTE uIndexBlockAddr=0, uIndexBlockIdx=0;
    BYTE uISPBlockAddr=0, uISPBlockIdx=0;
    BYTE uDlImageBlockIdx=0, uTempInfoBlkIdx=0xFF;
    BYTE uFindISPBlock=0;
    BYTE uFindDlImageBlock=0;
    LWORD u32MaxSerialNum=0;
    WORD u16Idx=0;
    ADDRINFO usTmpAddrInfo;
    BLKSPRINFO usBlkSprInfo;

    ctrlOnesCntStop(0);

    mClrSysBlkInFL;

    uRsvSysBlkNum=cRsvSysBlkNum;
    u16Idx=0;

    enEccInNormal();

    while(u16Idx<uRsvSysBlkNum)
    {
        if(u16Idx<=cSysBlock2ndInfo)
        {
            usTmpAddrInfo.u16FPage=gEraseBlockStatusStartPage;    // gBadBlockBitMapStartPage;
        }
        else
        {
            usTmpAddrInfo.u16FPage=0;
        }

        if(garSysBlock[u16Idx]==cInvalid8Bit)
        {
            break;
        }

        tranRsvBlkAddr(garSysBlock[u16Idx], &usTmpAddrInfo);
        setFLAddrActCh(usTmpAddrInfo.uCh, &usTmpAddrInfo);
        rstUNCSts1PlaneCore0(gCh, gPlaneAddr);
        gSectorH=0;
        mSetFRwParam(0, 0, c16Bit5|c16Bit10|c16Bit14, cReadData);
        assignFreeBtSrcAddrInfo();

        waitCmdAllDone(cWaitTrigRCnt|cWaitCmdBz);
        // releaseBtSrcAddrInfo();

        if(!mChkBitMask(gPlaneUNCSts[gCh], gPlaneAddr))
        {
            getSprByte(&usBlkSprInfo, usTmpAddrInfo.uPlaneAddr);

            switch(u16Idx)
            {
                case cSysBlock1stInfo:

                    if(mGetMetaBlockId(usBlkSprInfo)==cInfoBlockID)
                    {
                        mSet1stInfoInFL;
                    }

                    break;

                case cSysBlock2ndInfo:

                    if(mGetMetaBlockId(usBlkSprInfo)==cInfoBlockID)
                    {
                        mSet2ndInfoInFL;
                    }

                    break;

                case cSysBlockMPInfo:

                    if(mGetMetaBlockId(usBlkSprInfo)==cMPInfoBlockID)
                    {
                        mSetMPInfoInFL;
                    }

                    break;

                case cSysBlockLog:

                    if(mGetMetaBlockId(usBlkSprInfo)==cLogBlockID)
                    {
                        mSetLogInfoInFL;
                    }

                    break;

                case cSysBlockIsp:
                case cSysBlockIdx:
                case cSysBlockSpare0:
                case cSysBlockSpare1:
                case cSysBlockSpare2:
                case cSysBlockSpare3:
                case cSysBlockSpare4:
                case cSysBlockSpare5:
                case cSysBlockSpare6:

                    if(mGetMetaBlockId(usBlkSprInfo)==cIndexBlockID)
                    {
                        mSetIndexbInFL;

                        if(mGetMetaBlkSn(usBlkSprInfo)>=u32MaxSerialNum)
                        {
                            u32MaxSerialNum=mGetMetaBlkSn(usBlkSprInfo);
                            uIndexBlockAddr=garSysBlock[u16Idx];
                            uIndexBlockIdx=u16Idx;
                        }
                    }

                default:
                    break;
            }    /* switch */
        }
        else
        {
            debugDeadLock(0x001E);    // _ICE_DEBUG
        }

        u16Idx++;
    }

    if(mChkIndexbInFL)
    {
        u16Idx=garSysBlock[cSysBlockIdx];
        garSysBlock[cSysBlockIdx]=uIndexBlockAddr;
        garSysBlock[uIndexBlockIdx]=u16Idx;
        g32IndexBlkSerial=u32MaxSerialNum;
    }

// CheckISP Block  20190117_SamHu_01
    u16Idx=0;
    u32MaxSerialNum=0;

    while(u16Idx<uRsvSysBlkNum)
    {
        if(garSysBlock[u16Idx]==cInvalid8Bit)
        {
            break;
        }

        tranRsvBlkAddr(garSysBlock[u16Idx], &usTmpAddrInfo);
        setFLAddrActCh(usTmpAddrInfo.uCh, &usTmpAddrInfo);
        rstUNCSts1PlaneCore0(gCh, gPlaneAddr);
        gSectorH=0;
        mSetFRwParam(0, 0, c16Bit5|c16Bit10|c16Bit14, cReadData);
        assignFreeBtSrcAddrInfo();

        waitCmdAllDone(cWaitTrigRCnt|cWaitCmdBz);
        // releaseBtSrcAddrInfo();

        if(!mChkBitMask(gPlaneUNCSts[gCh], gPlaneAddr))
        {
            getSprByte(&usBlkSprInfo, usTmpAddrInfo.uPlaneAddr);

            switch(u16Idx)
            {
                case cSysBlock1stInfo:
                case cSysBlock2ndInfo:
                case cSysBlockMPInfo:
                case cSysBlockIdx:
                case cSysBlockLog:
                    break;

                case cSysBlockIsp:
                case cSysBlockSpare0:
                case cSysBlockSpare1:
                case cSysBlockSpare2:
                case cSysBlockSpare3:
                case cSysBlockSpare4:
                case cSysBlockSpare5:
                case cSysBlockSpare6:

                    if(mGetMetaBlockId(usBlkSprInfo)==cIspBlockID)
                    {
                        uFindISPBlock=1;
                        uISPBlockAddr=garSysBlock[u16Idx];
                        uISPBlockIdx=u16Idx;
                    }

                default:
                    break;
            }    /* switch */
        }
        else
        {
            debugDeadLock(0x001E);    // _ICE_DEBUG
        }

        if(uFindISPBlock)
        {
            break;
        }

        u16Idx++;
    }

    if(uFindISPBlock)
    {
        u16Idx=garSysBlock[cSysBlockIsp];
        garSysBlock[cSysBlockIsp]=uISPBlockAddr;
        garSysBlock[uISPBlockIdx]=u16Idx;
        mSetIspBlkInFL;
    }

    // Double check Info 20190705_SamHu_01
    u16Idx=0;

    if(mChk1stInfoInFL||mChk2ndInfoInFL)
    {
        while(u16Idx<=cSysBlockIsp)
        {
            if(u16Idx==cSysBlockIsp)
            {
                usTmpAddrInfo.u16FPage=(cTotalPlaneOfIsp*2-1);
            }
            else
            {
                usTmpAddrInfo.u16FPage=(gISPCore1StartPage+cTotalPlaneOfIsp-1);
            }

            if(garSysBlock[u16Idx]==cInvalid8Bit)
            {
                break;
            }

            tranRsvBlkAddr(garSysBlock[u16Idx], &usTmpAddrInfo);
            setFLAddrActCh(usTmpAddrInfo.uCh, &usTmpAddrInfo);
            rstUNCSts1PlaneCore0(gCh, gPlaneAddr);
            gSectorH=0;
            mSetFRwParam(0, 0, c16Bit5|c16Bit10|c16Bit14, cReadData);
            assignFreeBtSrcAddrInfo();

            waitCmdAllDone(cWaitTrigRCnt|cWaitCmdBz);
            // releaseBtSrcAddrInfo();

            if(!mChkBitMask(gPlaneUNCSts[gCh], gPlaneAddr))
            {
                getSprByte(&usBlkSprInfo, usTmpAddrInfo.uPlaneAddr);

                switch(u16Idx)
                {
                    case cSysBlock1stInfo:

                        if(mGetMetaBlockId(usBlkSprInfo)!=cInfoBlockID)
                        {
                            mClr1stInfoInFL;
                        }

                        break;

                    case cSysBlock2ndInfo:

                        if(mGetMetaBlockId(usBlkSprInfo)!=cInfoBlockID)
                        {
                            mClr2ndInfoInFL;
                        }

                        break;

                    case cSysBlockIsp:

                        if(mGetMetaBlockId(usBlkSprInfo)!=cIspBlockID)
                        {
                            mClrIspBlkInFL;
                        }

                        break;

                    default:
                        break;
                }        /* switch */
            }
            else
            {
                debugDeadLock(0x001E);        // _ICE_DEBUG
            }

            u16Idx++;
        }
    }

    // FwDlImageBlk Block   20190117_SamHu_01
    u16Idx=0;
    u32MaxSerialNum=0;

    while(u16Idx<uRsvSysBlkNum)
    {
        if(garSysBlock[u16Idx]==cInvalid8Bit)
        {
            break;
        }

        tranRsvBlkAddr(garSysBlock[u16Idx], &usTmpAddrInfo);
        setFLAddrActCh(usTmpAddrInfo.uCh, &usTmpAddrInfo);
        rstUNCSts1PlaneCore0(gCh, gPlaneAddr);
        gSectorH=0;
        mSetFRwParam(0, 0, c16Bit5|c16Bit10|c16Bit14, cReadData);
        assignFreeBtSrcAddrInfo();

        waitCmdAllDone(cWaitTrigRCnt|cWaitCmdBz);
        // releaseBtSrcAddrInfo();

        if(!mChkBitMask(gPlaneUNCSts[gCh], gPlaneAddr))
        {
            getSprByte(&usBlkSprInfo, usTmpAddrInfo.uPlaneAddr);

            switch(u16Idx)
            {
                case cSysBlock1stInfo:
                case cSysBlock2ndInfo:
                case cSysBlockMPInfo:
                case cSysBlockIsp:
                case cSysBlockIdx:
                case cSysBlockLog:
                    break;

                case cSysBlockSpare0:
                case cSysBlockSpare1:
                case cSysBlockSpare2:
                case cSysBlockSpare3:
                case cSysBlockSpare4:
                case cSysBlockSpare5:
                case cSysBlockSpare6:

                    if(mGetMetaBlockId(usBlkSprInfo)==cFwDlDesBlockID)
                    {
                        uFindDlImageBlock=cTrue;
                        uDlImageBlockIdx=u16Idx;
                    }
                    else if(mGetMetaBlockId(usBlkSprInfo)==cInfoBlockID)
                    {
                        gsRdlinkInfo.ubExistTempInfoBlk=cTrue;
                        uTempInfoBlkIdx=u16Idx;
                        NLOG(cLogBuild, BOOTFUNC1_C, 0, "Find Temp Block");
                    }

                default:
                    break;
            }    /* switch */
        }
        else
        {
            debugDeadLock(0x001E);    // _ICE_DEBUG
        }

        u16Idx++;
    }

    if(gsRdlinkInfo.ubExistTempInfoBlk==cTrue)
    {
        u16Idx=garSysBlock[cSysBlockSpare0];
        garSysBlock[cSysBlockSpare0]=garSysBlock[uTempInfoBlkIdx];
        garSysBlock[uTempInfoBlkIdx]=u16Idx;
    }

    if(uFindDlImageBlock==cTrue)
    {
        u16Idx=garSysBlock[cSysBlockSpare0];
        garSysBlock[cSysBlockSpare0]=garSysBlock[uDlImageBlockIdx];
        garSysBlock[uDlImageBlockIdx]=u16Idx;
    }

    ctrlOnesCntStop(cBit0|cBit1);

    if(!mChk1stInfoInFL)
    {
        mSet1stInfoInjured;

        NLOG(cLogBuild, BOOTFUNC1_C, 0, "Info1 Fail");
    }

    if(!mChk2ndInfoInFL)
    {
        mSet2ndInfoInjured;

        NLOG(cLogBuild, BOOTFUNC1_C, 0, "Info2 Fail");
    }

    while((!gSysOption)&&(!gsRdlinkInfo.ubExistTempInfoBlk))
        ;// debug
#endif/* if !_WO_INFOB */
}    /* findSysRsvBlock */

void redefParaVal()
{
    BYTE uTemp;
    WORD u16Temp, u16TotalTlcFblkCap;

#if _SANDISK_3D_GEN2
    if(gIntlvWay==1)
    {
        // 24K F2h
        g16ValidPgPerF2hTab=0x17F8;
        g16TotalPgPerF2hTab=0x1800;
        gTotal4kNumOfF2hTab=0x8;
        gTotalBankOfF2hTab=1;    // temp set

        // 36K F2h
        g16TlcValidPgPerF2hTab=0x23F4;
        g16TotalTlcPgPerF2hTab=0x2400;
        gTlcTotal4kNumOfF2hTab=0xC;
        gTotalTlcBankOfF2hTab=2;    // temp set
    }
    else
    {
        // 48K F2h
        g16ValidPgPerF2hTab=0x2FF4;
        g16TotalPgPerF2hTab=0x3000;
        gTotal4kNumOfF2hTab=0xC;
        gTotalBankOfF2hTab=gIntlvWay/2;    // temp set
        // 48K F2h
        g16TlcValidPgPerF2hTab=0x2FF4;
        g16TotalTlcPgPerF2hTab=0x3000;
        gTlcTotal4kNumOfF2hTab=0xC;
        gTotalTlcBankOfF2hTab=gIntlvWay*3/2;    // temp set
    }

    while(gSyncResetCmd!=0xFF)
        ;
#elif _SANDISK_3D_GEN3
    if(gTotalChNum==2)
    {
        // 16K F2h
        g16ValidPgPerF2hTab=0x0FFC;
        g16TotalPgPerF2hTab=0x1000;
        gTotal4kNumOfF2hTab=0x4;
        gTotalBankOfF2hTab=gIntlvWay;    // temp set
        // 48K F2h
        g16TlcValidPgPerF2hTab=0x2FF4;
        g16TotalTlcPgPerF2hTab=0x3000;
        gTlcTotal4kNumOfF2hTab=0xC;
        gTotalTlcBankOfF2hTab=gIntlvWay;    // temp set
    }
    else
    {
        // 32K F2h
        g16ValidPgPerF2hTab=0x1FF8;
        g16TotalPgPerF2hTab=0x2000;
        gTotal4kNumOfF2hTab=0x8;
        gTotalBankOfF2hTab=gIntlvWay;    // temp set
        // 48K F2h
        g16TlcValidPgPerF2hTab=0x2FF4;
        g16TotalTlcPgPerF2hTab=0x3000;
        gTlcTotal4kNumOfF2hTab=0xC;
        gTotalTlcBankOfF2hTab=gIntlvWay*2;    // temp set
    }

    while(gSyncResetCmd!=0xFF)
        ;
#elif _TSB_BiCS3
    // 32K F2h
    g16ValidPgPerF2hTab=0x1FF8;
    g16TotalPgPerF2hTab=0x2000;
    gTotal4kNumOfF2hTab=0x8;
    gTotalBankOfF2hTab=gIntlvWay;    // temp set
    // 48K F2h
    g16TlcValidPgPerF2hTab=0x2FF4;
    g16TotalTlcPgPerF2hTab=0x3000;
    gTlcTotal4kNumOfF2hTab=0xC;
    gTotalTlcBankOfF2hTab=gIntlvWay*2;    // temp set

    while(gSyncResetCmd!=0xFF)
        ;
#elif _TSB_BiCS4_WR
    // 48K F2h
    g16ValidPgPerF2hTab=0x2FF4;
    g16TotalPgPerF2hTab=0x3000;
    gTotal4kNumOfF2hTab=0xC;
    gTotalBankOfF2hTab=gIntlvWay;

    // 48K F2h
    g16TlcValidPgPerF2hTab=0x2FF4;
    g16TotalTlcPgPerF2hTab=0x3000;
    gTlcTotal4kNumOfF2hTab=0xC;
    gTotalTlcBankOfF2hTab=gIntlvWay*3;

    while(gSyncResetCmd!=0xFF)
        ;
#else/* if _SANDISK_3D_GEN2 */
    // HynixV3  48K F2h
    g16TlcValidPgPerF2hTab=0x2FF4;
    gTlcTotal4kNumOfF2hTab=0xC;

    while(gSyncResetCmd!=0xFC)
        ;
#endif/* if _SANDISK_3D_GEN2 */

    // capicity > 460GB, just constant when 48K table and Max H block <9216
    if(g32TotalDatSector>0x35900D30)
    {
        // 128K H2f Table
        g32H2fTabFullSize=(128*1024);
        gGCH2fTabShiftSize=8;    // 256 sector= 2^8
        gHmbH2FTableShift=17;    // 2^17=128*1024
        g16HmbMaxTableNum=c16HmbMaxTableNum/2;
    }
    else
    {
        // 64K H2f Table
        g32H2fTabFullSize=(64*1024);
        gGCH2fTabShiftSize=7;    // 128 sector= 2^7
        gHmbH2FTableShift=16;    // 2^16=64*1024
        g16HmbMaxTableNum=c16HmbMaxTableNum;
    }

    // One plane Raid
    g32H2fTabValidSize=g32H2fTabFullSize-(gSectorPerPlaneH*512);
    g16PagePerH2fTab=(g32H2fTabValidSize/4);

    //
    g16H2fTabSize=(g32H2fTabFullSize/4);
    g16H2fTabSctrSize=(g32H2fTabFullSize/512);
    g16H2fTabValidSctrSize=(g32H2fTabValidSize/512);

    g16WproSwapSBuf=(c16GcBuSrcH2fIdx+g16H2fTabSctrSize);
    gPage4kPerH2fTab=g16H2fTabSctrSize/8;

    gTotalPlaneOfH2fTab=(g16H2fTabSctrSize+gSectorPerPlaneH-1)/gSectorPerPlaneH;
    g16TotalHBlock=(g32TotalDatSector+(g32H2fTabValidSize*2)-1)/(g32H2fTabValidSize*2);

    g32SectorPerBlockH=g32H2fTabValidSize*2;

#if (_SANDISK_3D_GEN2||_SANDISK_3D_GEN3||_TSB_BiCS3||_TSB_BiCS4)
    // g16PagePerH2fTab=0x4000-(g4kNumPerPlane<<10);
    // gTotalPlaneOfH2fTab=4;
    // g16TotalHBlock=g32TotalDatSector/(c32H2fTabValidSize*2)+1;
    // g32SectorPerBlockH=c32H2fTabValidSize*2;
#else
    // g16PagePerH2fTab=0x3800;
    // gTotalPlaneOfH2fTab=8;
#endif

#if 0    // _EN_RAID_GC
    // put partial parity to the end 16KB
    if(g16TotalPgPerF2hTab>0x2000)
    {
        gRsvCacheF2h=cTrue;
    }
    else
    {
        gRsvCacheF2h=cFalse;
    }
#endif

    uTemp=gSectorPerPlaneH;

    while(uTemp>1)
    {
        uTemp>>=1;
    }

    uTemp=gTotalPlaneOfH2fTab;

    while(uTemp>1)
    {
        uTemp>>=1;
        gsCacheInfo.uH2fTabProgSlotShift++;
    }

    gsCacheInfo.u16H2fTabPagePerBlk3=(g16PagePerBlock3_SLC*gSectorPerPlaneH)/g16H2fTabSctrSize;

    uTemp=0;
    u16Temp=1;

    while(u16Temp<gsCacheInfo.u16H2fTabPagePerBlk3)
    {
        u16Temp<<=1;
        uTemp++;
    }

    gMaxH2fTabBlkNum=(15-uTemp);

    if(gMaxH2fTabBlkNum>c16MaxH2fTabShiftNum)
    {
        // g16ChkHmbBit=cb16BitTab[15-(gMaxH2fTabBlkNum-c16MaxH2fTabShiftNum)];
        gMaxH2fTabBlkNum=c16MaxH2fTabBlkNum;
    }
    else
    {
        // g16ChkHmbBit=c16Bit15;
        gMaxH2fTabBlkNum=1<<(gMaxH2fTabBlkNum);
    }

    gsCacheInfo.uH2fTabPagePtrShift=uTemp;
    gsCacheInfo.u16H2fTabPagePtrMsk=u16Temp-1;
    u16Temp=1<<(15-gsCacheInfo.uH2fTabPagePtrShift);    // 16bit-1drop-pagebit

    // For Debug.
    while(gMaxH2fTabBlkNum!=u16Temp)
        ;

#if _ENABLE_RAID
    g32VpcPerSlcBlk=(g16ValidPgPerF2hTab-(cRaidParityNum*c4kNumPerRaidPty))*gTotalBankOfF2hTab;
    g32VpcPerTlcBlk=(g16TlcValidPgPerF2hTab-(cRaidParityNum*cProgCntPerWL*c4kNumPerRaidPty))*gTotalTlcBankOfF2hTab;
#else
    g32VpcPerSlcBlk=g16ValidPgPerF2hTab*gTotalBankOfF2hTab;
    g32VpcPerTlcBlk=g16TlcValidPgPerF2hTab*gTotalTlcBankOfF2hTab;
#endif

    gFLParam&=~cWithPrimaryCmd;
    // wait Mp tool fix
    // g16TlcFullCachebGcThr=(g32SectorPerBlockH*g16TotalHBlock)/((LWORD)g16TlcValidPgPerF2hTab*8*gTotalTlcBankOfF2hTab);
    // g16TlcFullCachebGcThr+=2;

    gsCacheInfo.uMaxH2f2kTabSgmt=(g32SectorPerBlockH>>(cSctrTo4kShift+9));

    gpSortF2hTab=(SORTF2HTAB *)(cFlushCacheVarStrAddr);

    gsCacheInfo.u16RaidPtyPagePerBlk3=(g16PagePerBlock3_SLC*gSectorPerPlaneH)/cRaidDataSctrNum;
    gsCacheInfo.u16RaidPtyFreePagePtr=c16BitFF;
    gsCacheInfo.u16RaidGcPtyFreePagePtr=c16BitFF;
    gsCacheInfo.uRaidPtyBlockCnt=0;
    gsCacheInfo.uRaidPtyBlkIdx=0;
    gsCacheInfo.uRaidGcPtyBlkIdx=0;

    gsFtlDbg.u16MinSpareBlockCnt=0xFFFF;
    gsFtlDbg.u16TlcMinSpareBlockCnt=0xFFFF;
    g16MaxDualMoPeThr=100;

    g32HmbTotalH2FTableSize=(g32H2fTabFullSize*g16HmbMaxTableNum);
    // g32HmbGcInfoStrAddr=g32HmbTotalH2FTableSize;
#if _FIX_SLC_Boundary    // temp set, can be removed and from parameter
#if !_EN_VPC_SWAP
    gMinStaticSlcCnt=59;
#endif
    u16TotalTlcFblkCap=(g32TotalDatSector>>3)/g32VpcPerTlcBlk;
    g16TlcFullCachebGcThr=(g16TotalFBlock-g16OrgBadBlockCnt-g16LaterBadBlockCnt-g16FirstFBlock-gMinStaticSlcCnt-u16TotalTlcFblkCap)/2;
    g16TlcFullCachebGcThr=u16TotalTlcFblkCap+g16TlcFullCachebGcThr;
#endif
#if _EN_Dynamic_Fix_Boundary
#if !_EN_VPC_SWAP
    gMinStaticSlcCnt=59;
#endif
    u16TotalTlcFblkCap=((g32TotalDatSector>>3)+g32VpcPerTlcBlk-1)/g32VpcPerTlcBlk;
    g16TLCGCSpareCnt_Ori=(g16TotalFBlock-g16OrgBadBlockCnt-g16LaterBadBlockCnt-g16FirstFBlock-gMinStaticSlcCnt-u16TotalTlcFblkCap)/2;
    // g16TLCGCSpareCnt_Run=
    // (g16TotalFBlock-g16OrgBadBlockCnt-g16LaterBadBlockCnt-gsBadInfo.u16TotalNewBadCnt-g16FirstFBlock-gMinStaticSlcCnt-u16TotalTlcFblkCap)/2;
    // g16TlcFullCachebGcThr=u16TotalTlcFblkCap+g16TLCGCSpareCnt_Run;
    g16MaxDualMoPeThr=0xFFFF;
#endif
#if _EN_VPC_SWAP
    if(g16TotalFBlock>1024)
    {
        gMinStaticSlcCnt=87;
    }
#endif
#if _EN_VPC_SWAP
    g16MaxSlcBlkQ=cMaxSlcBlkQ;
#endif

    // gGc4kNumPerMaxProgUnit=g4kNumPerPage*gTotalChNum;
    // g16GCOneShot4kCnt=gTotalIntlvChNum*g4kNumPerPage*cProgCntPerWL;
}    /* redefParaVal */

void setOrgFlashCmd()
{
    gSyncResetCmd=0xFF;
    gReadStatusCmd=0x70;
}

void initSecuritySwitches()
{
    *((BYTE *)((void *)(&gbsSecurity)))=0;

#if (!(_GREYBOX))
#if _ENABLE_SECAPI
#ifdef _FDE_DRIVE    // 20190108_SamHu_02 for Samsung FDE only
    gbEnAes=1;
    g32HostTotalDataSectorCnt-=cTcgReserveSecCnt;
    g32HostTotalDataSectorCnt-=gTcgReservedSecShiftCnt;
#else
    if(gsLightSwitch.usSecLs.uAes)
    {
        gbEnAes=1;
    }

    if(gsLightSwitch.usSecLs.u32SecFeature&c32Tcg)
    {
        gbEnTCG=1;
        gbEnSessionTimer=1;
    }

    if(gsLightSwitch.usSecLs.u32SecFeature&c32Ieee1667)
    {
        gbEnIEEE1667=1;
    }

    if(gsLightSwitch.usSecLs.u32SecFeature&c32Pyrite)
    {
        gbEnPyrite=1;
    }

    if(gsLightSwitch.usSecLs.u32SecFeature&c32OpalLite)
    {
        gbEnOpalite=1;
    }

    if(gbEnTCG)
    {
        g32HostTotalDataSectorCnt-=cTcgReserveSecCnt;
    }

    if(gTcgReservedSecShiftCnt)
    {
        g32HostTotalDataSectorCnt-=gTcgReservedSecShiftCnt;
    }
#endif/* ifdef _FDE_DRIVE */

#if _ENABLE_ATA_PASSTHROUGH
#ifdef _ENABLE_ATA_PASSTHROUGH_BY_OEM    // 20181114_SamHu
    if(gsLightSwitch.usSecLs.u32SecFeature&c32AtaPassThrough)
    {
        gbEnATAPassThrough=1;
    }
#endif
#endif
#endif/* if _ENABLE_SECAPI */
#endif/* if (!(_GREYBOX)) */
}    /* initSecuritySwitches */

#if (!_ICE_LOAD_ALL)
#pragma default_function_attributes =
#endif







