







// #if (_CPUID!=1)
#include "inc/Const.h"
#include "inc/TypeDef.h"
#include "inc/Option.h"
#include "inc/ProType.h"
#include "inc/GlobVarS.h"
#include "inc/GlobVar1.h"
#include "inc/GlobVarT.h"
#include "inc/NvmeCtrl.h"
#include "inc/BitDef.h"
#include "inc/NvmeCtrl.h"
#include "inc/Reg.h"
#include "inc/Mac.h"

#if (_GREYBOX)
#include "inc/GreyBox.h"
#endif

#include "inc/DebugLog.h"
#include "inc/EventLogIDX.h"
#include "inc/EventLogFunctionIDX.h"

#pragma default_function_attributes = @ ".CORE1_ISP"

#include "FlashCmdSwap.c"

void setVendorRwInfo(void)
{
    BYTE uEnEcc=1, uEnScrambler=rmVndrEnScrambler;
    BYTE u2kChunk;

    if(gOpTyp==cVenderRead)
    {
        if(rmVndrDisEcc)
        {
            uEnEcc=0;
        }

        if(rmVndrForce1Plane)
        {
            mGetReadOpt&=~c16Bit0;
        }

        if(!rmVndrNoSpare)
        {
            mGetReadOpt|=c16Bit5;
        }

        mGetReadOpt|=c16Bit10;
    }

    if(gOpTyp==cVenderWrite)
    {
        // if(rmVndrForce1Plane)
        // {
        mGetWriteOpt&=~c16Bit0;
        mGetProgSctrCnt=gSectorPerPlaneH;
        // }
        // else
        // {

        // mGetWriteOpt |= c16Bit0;
        // mGetProgSctrCnt= (gSectorPerPlaneH*gPlaneNum);
        // for(uPlaneIdx=1; uPlaneIdx < gPlaneNum; uPlaneIdx++)
        // {
        // copyTsb2Tsb((UCBYTE *)&garTsb0[gSectorPerPlaneH*uPlaneIdx][0], (UCBYTE *)&garTsb0[0][0], (WORD)gSectorPerPlaneH*cSingleSectorByte);
        // }
        // }

        if(!rmVndrNoSpare)
        {
            mGetWriteOpt|=c16Bit4;
        }
    }
    else if(gOpTyp==cVenderErase)
    {
        if(rmVndrForce1Plane)
        {
            g16RwOpt=c16Bit14;
        }
    }

    u2kChunk=rmVndr2kChunk;
    g16FBlock=rmVndrFBlock;
    g16FPage=rmVndrFPage;
    gIntlvAddr=rmVndrCe;
    gCe=(BYTE)mGetCEAddr(gIntlvAddr);
    gDieAddr=rmVndrDie;
    gCh=rmVndrCh;
    gPlaneAddr=rmVndrPlane;
    gSectorH=(u2kChunk<<1);

    if(rmVndrEnSlcMode)
    {
        // Slc mode.
        mClrMlcMoBit(rmVndrFBlock);
    }
    else
    {
        // Tlc mode.
        mSetMlcMoBit(rmVndrFBlock);
#if (_TSB_BiCS3||_SANDISK_3D_GEN2||_SANDISK_3D_GEN3||_TSB_BiCS4)
        setPageSelCmd(gpFlashAddrInfo, (g16FPage%cProgCntPerWL)+1);
        g16FPage=(g16FPage/cProgCntPerWL);
#endif
    }

    /* Enable/Disable scrambler and ECC */
    if(rmVndrEnMaxEcc)
    {
        ctrlScrbBothAndEcc(uEnScrambler<<cBit0, (uEnEcc<<1));
    }
    else
    {
        ctrlScrbBothAndEcc(uEnScrambler<<cBit0, (uEnEcc<<0));
    }

    setFLActCh(gCh);
}    /* setVendorRwInfo */

void setSprByteforVendor(BYTE uPlaneAddr, WORD u16Spr0, WORD u16Spr1, WORD u16Spr2, WORD u16Spr3, BYTE uBlkID)
{
    BLKSPRINFO usBlkSprInfo;
    BYTE uPlaneLoop;

    if(mChkMlcMoBit(g16FBlock))
    {
        gSpareCnt[gCh]=cSpareUseOfTLC;
    }
    else
    {
        gSpareCnt[gCh]=cSpareUseOfSLC;
    }

    usBlkSprInfo.u16Spr0.u16all=u16Spr0;
    usBlkSprInfo.u16Spr1.u16all=u16Spr1;
    usBlkSprInfo.u16Spr2.u16all=u16Spr2;
    usBlkSprInfo.u16Spr3.u16all=u16Spr3;
    usBlkSprInfo.u16Spr4.u16all=0x0000;
    usBlkSprInfo.u16Spr5.u16all=0x0000;
    usBlkSprInfo.u16Spr6.u16all=0x0000;
    usBlkSprInfo.u16Spr7.u16all=0x0000;
    usBlkSprInfo.u16Spr8.us2BYTE.HighByte=gpFlashAddrInfo->uOpTyp;
    usBlkSprInfo.u16Spr8.us2BYTE.LowByte=uBlkID;
    usBlkSprInfo.u32Spr9and10.u32all=0x00000000;
    usBlkSprInfo.u16Spr11.u16all=0x0000;    // g32arGlobEraseCnt[g16AbstrFBlock].u16EraseCnt;

    for(uPlaneLoop=0; uPlaneLoop<gPlaneNum; uPlaneLoop++)
    {
        setSprByte(&usBlkSprInfo, uPlaneLoop);
    }
}    /* setSprByteforTest */

BYTE vendorCmdReadPhysicalPage()
{
    LWORD u32TlcMode;
    BLKSPRINFO upBlkSprInfo;
    WORD u16BlkTemp;

    u16BlkTemp=rmVndrFBlock;
    // save as cell mode
    u32TlcMode=mChkMlcMoBit(rmVndrFBlock);
    gpFlashAddrInfo=&gpVendorAddrInfo;
    gOpTyp=cVenderRead;

    mGetReadOpt=c16Bit4;

    setVendorRwInfo();
    mGetReadBuf=c16Tsb0SIdx;

    if(mGetReadOpt&c16Bit5)
    {
        mGetReadSctrCnt=g32HostXfrCnt-1;
    }
    else
    {
        mGetReadSctrCnt=g32HostXfrCnt;
    }

    // mGetReadSctrCnt=gSectorPerPlaneH;
    // fillCcmVal((BYTE *)&garTsb0[g32HostXfrCnt-1][0], 0x100, cZero);
    fillCcmVal((BYTE *)&garTsb0[0][0], ((gSectorPerPlaneH*gPlaneNum)+1)*512, cZero);

    if(gIntlvAddr>=gIntlvWay)
    {
        // This is for FTL using!!
        gIntlvAddr=gIntlvAddr%gIntlvWay;
        gCe=(BYTE)mGetCEAddr(gIntlvAddr);
        gDieAddr=mGetDieAddr(gIntlvAddr);
    }

    if(gCh>=gTotalChNum)
    {
        gCh=gCh%gTotalChNum;
    }

    resetEcc();    // rmResetEccSts;

    if((gVuCmdSpFlag&cVuCmdVthEnable)==cVuCmdVthEnable)
    {
        while(gEnableLdpcPipe)
            ;

        mGetReadOpt=(mGetReadOpt|c16Bit15);

        if(rmVndrNoReadData)
        {
            mGetReadOpt&=~c16Bit4;
        }

        if(rmVndrNoSpare)
        {
            mGetReadOpt&=~c16Bit5;
        }

        if((mGetReadOpt&(c16Bit4|c16Bit5))==0x00)
        {
            mGetReadSctrCnt=0;
        }

        if((mGetReadSctrCnt%gSectorPerPlaneH)!=0)
        {
            mGetReadSctrCnt=mGetReadSctrCnt-(mGetReadSctrCnt%gSectorPerPlaneH);
        }

        rmDisUnCorrErrStop;
        rmDisOnesCntStop;
        rmSetEccFailForceXfr;

        gDieAddr=mGetDieAddr(gIntlvAddr);
        rmSetDieBit(gDieAddr);
        copyCcmVal((BYTE *)&gsFlashAddrInfoTemp, (BYTE *)&gpVendorAddrInfo, sizeof(ADDRINFO));
        rmCeOn(gCe);
        flashChangeDieCmd(gDieAddr);
        setTestRetryCmd();
        rmCle(0x5D);
        rmNop(0x10);
        rmCeOff(gCe);
    }

    flashReadPage();

    if((gVuCmdSpFlag&cVuCmdVthEnable)==cVuCmdVthEnable)
    {
        while(rmChkLdpcDmaSt)
            ;

        while(rmChkCmdFifoBz)
            ;

        garTsb0[g32HostXfrCnt-1][0x23]=gVuCmdSpFlag;
        garTsb0[g32HostXfrCnt-1][0x24]=rFLCtrl[rcLdpcEccErrCntHB];
        garTsb0[g32HostXfrCnt-1][0x25]=rFLCtrl[rcLdpcEccErrCntLB];
        garTsb0[g32HostXfrCnt-1][0x26]=rmGetSprEcc;
        garTsb0[g32HostXfrCnt-1][0x27]=rmGetEccResultSts;
        garTsb0[g32HostXfrCnt-1][0x28]=rmGetEccCorrectableSts;
        garTsb0[g32HostXfrCnt-1][0x29]=rFLCtrl[rcOnceCntstatus];
        garTsb0[g32HostXfrCnt-1][0x2A]=rFLCtrl[(rcChunkEccStsMap+1)];
        garTsb0[g32HostXfrCnt-1][0x2B]=rFLCtrl[rcChunkEccStsMap];
        resetEcc();    // rmResetEccSts;

        while(rmChkCmdFifoBz)
            ;

        rmEnOnesCntStop;
        rmEnUnCorrErrStop;
        rmClrEccFailForceXfr;

        rmCeOn(gCe);
        flashChangeDieCmd(gDieAddr);
        fillCcmVal((BYTE *)&garVuCmdVthCenter[0], (sizeof(garVuCmdVthCenter)), cZero);
        setTestRetryCmd();
        rmCeOff(gCe);
        gVuCmdSpFlag=(gVuCmdSpFlag&(~cVuCmdVthEnable));

        while(rmChkCmdFifoBz)
            ;

        while(rmChkUNC)
            ;

        while(rmChkSysUNC)
            ;
    }
    else
    {
        /* check status*/
        // Note: Here still need to add a valid "gPlaneUNCSts" and "gPlaneCorrSts".
        // garTsb0[g32HostXfrCnt-1][0x19]=gbOnesCntFail;
        garTsb0[g32HostXfrCnt-1][0x20]=gPlaneUNCSts[gActiveCh];
        garTsb0[g32HostXfrCnt-1][0x21]=gPlaneCorrSts[gActiveCh];
        garTsb0[g32HostXfrCnt-1][0x22]=gbOnesCntFail;
        garTsb0[g32HostXfrCnt-1][0x23]=gVuCmdSpFlag;
        garTsb0[g32HostXfrCnt-1][0x24]=rFLCtrl[rcLdpcEccErrCntHB];
        garTsb0[g32HostXfrCnt-1][0x25]=rFLCtrl[rcLdpcEccErrCntLB];
        garTsb0[g32HostXfrCnt-1][0x26]=rmGetSprEcc;
    }

#if _GREYBOX
    if((gsGbInfo.uGreyBoxItem==cRAIDDecOnNormData)||
       ((gsGbInfo.uGreyBoxItem==cSecurityRW)&&((gsGbInfo.uGreyBoxOpt&0x01)&&(gsGbInfo.uGreyBoxOpt&0x2))))
    {
#if _EN_RAID_DECODE
        while(g32DecodeWait)
            ;
#endif
    }
#endif

    /* Save as spare byte*/
    if(mGetReadOpt&c16Bit5)
    {
        getSprByte(&upBlkSprInfo, gPlaneAddr);
        copyReg2Tsb((BYTE *)&garTsb0[g32HostXfrCnt-1][0], (volatile BYTE *)&upBlkSprInfo, sizeof(BLKSPRINFO));
    }

#if 0    // No need
    if(gSecurityOption&cEnE2e)
    {
        for(BYTE uCnt=0; uCnt<gSectorPerPlaneH; uCnt++)
        {
            garTsb0[g32HostXfrCnt-1][0x30+(uCnt*2)]=(*(BYTE *)(c32TsbCrcAddr+(mGetReadBuf*8)+(uCnt*8)));
            garTsb0[g32HostXfrCnt-1][0x31+(uCnt*2)]=(*(BYTE *)(c32TsbCrcAddr+(mGetReadBuf*8)+(uCnt*8)+1));
        }
    }
#endif

    if(u32TlcMode)
    {
        mSetMlcMoBit(u16BlkTemp);
    }
    else
    {
        mClrMlcMoBit(u16BlkTemp);
    }

    // ctrlScrbBothAndEcc(1, 1);
    return cSuccess;
}    /* vendorCmdReadPhysicalPage */

void vendorCmdWritePhysicalPage()
{
    LWORD u32TlcMode;

    // BLKSPRINFO *upBlkSprInfo;

    u32TlcMode=mChkMlcMoBit(rmVndrFBlock);
    gpFlashAddrInfo=&gpVendorAddrInfo;
    gOpTyp=cVenderWrite;
    setVendorRwInfo();
    setSprByteforVendor(gPlaneAddr, g16FBlock, g16FPage, gCh, gIntlvAddr, 0xFF);
    mSetFRwParam(c16Tsb0SIdx, gSectorPerPlaneH, 0, cVenderWrite);
    setFLActCh(gCh);

    flashProgPage(mGetWriteBuf, mGetProgSctrCnt, mGetWriteOpt);

    gSpareCnt[gCh]=cZero;

    if(u32TlcMode)
    {
        mSetMlcMoBit(g16FBlock);
    }
    else
    {
        mClrMlcMoBit(g16FBlock);
    }

    // ctrlScrbBothAndEcc(1, 1);
}    /* vendorCmdWritePhysicalPage */

void vendorCmdErasePhysicalBlock()
{
    gpFlashAddrInfo=&gpVendorAddrInfo;

    /* Check Vendor command option */
    gOpTyp=cVenderErase;
    g16RwOpt=0;
    setVendorRwInfo();

    flashErase(g16RwOpt);
    // ctrlScrbBothAndEcc(1, 1);
}    /* vendorCmdErasePhysicalBlock */

BYTE setWdVendorInfo(void)
{
    BYTE uEnEcc=1, uEnScrambler=rmVndrEnScrambler;
    BYTE u2kChunk;
    BYTE uEemptyFlag=0x00;

    if(gOpTyp==cVenderRead)
    {
        fillCcmVal((BYTE *)&garTsb0[0][0], ((gSectorPerPlaneH*gPlaneNum)+1)*512, cZero);

        if(rmVndrDisEcc)
        {
            uEnEcc=0;
        }

        if(rmVndrForce1Plane)
        {
            mGetReadOpt&=~c16Bit0;
        }

        if(!rmVndrNoReadData)
        {
            mGetReadOpt|=c16Bit4;
        }

        if(!rmVndrNoSpare)
        {
            mGetReadOpt|=c16Bit5;
        }

        mGetReadOpt|=c16Bit10;
    }

    if(gOpTyp==cVenderWrite)
    {
        mGetWriteOpt&=~c16Bit0;
        mGetWriteBuf=c16Tsb0SIdx;
        mGetProgSctrCnt=gSectorPerPlaneH;
        mGetWriteOpt|=c16Bit4;
    }
    else if(gOpTyp==cVenderErase)
    {
        fillCcmVal((BYTE *)&garTsb0[0][0], ((gSectorPerPlaneH*gPlaneNum)+1)*512, cZero);
        // Always use 1P
        g16RwOpt|=c16Bit14;
    }

    g16FBlock=rmVndrFBlock;
    g16FPage=rmVndrFPage;
    gCh=rmVndrCh;
    gCe=rmVndrCe;
    gDieAddr=rmVndrDie;
    gIntlvAddr=gCe*gDieBitCnt+gDieAddr;

    if(gIntlvAddr>=gIntlvWay)
    {
        gIntlvAddr=gIntlvAddr%gIntlvWay;
    }

    gPlaneAddr=rmVndrPlane;
    u2kChunk=rmVndr2kChunk;
    gSectorH=(u2kChunk<<1);

    if(((cBit0<<gCh)&gChMap)==0)
    {
        uEemptyFlag=cVuWdEmptyFail;
    }

    if(((cBit0<<gCe)&gCeMap)==0)
    {
        uEemptyFlag=cVuWdEmptyFail;
    }

    if(gDieAddr>=gTotalDiePerCe)
    {
        uEemptyFlag=cVuWdEmptyFail;
    }

    if(rmVndrEnSlcMode)
    {
        // Slc mode.
        mClrMlcMoBit(rmVndrFBlock);
    }
    else
    {
        // Tlc mode.
        mSetMlcMoBit(rmVndrFBlock);
#if (_TSB_BiCS3||_SANDISK_3D_GEN2||_SANDISK_3D_GEN3||_TSB_BiCS4)
        setPageSelCmd(gpFlashAddrInfo, (g16FPage%cProgCntPerWL)+1);
        g16FPage=(g16FPage/cProgCntPerWL);
#endif
    }

    /* Enable/Disable scrambler and ECC */
    if(rmVndrEnMaxEcc)
    {
        ctrlScrbBothAndEcc(uEnScrambler<<cBit0, (uEnEcc<<1));
    }
    else
    {
        ctrlScrbBothAndEcc(uEnScrambler<<cBit0, (uEnEcc<<0));
    }

    return uEemptyFlag;
}    /* setVendorRwInfo */

void setWdPhyCh(BYTE uChNum)
{
#if (_CPUID==1)
    gActiveCh=uChNum;
#endif
    uChNum=uChNum;
    rFLCtrl=(void *)regFSHA[uChNum];
    r16FLCtrl=(void *)reg16FSHA[uChNum];
    r32FLCtrl=(void *)reg32FSHA[uChNum];
    rmSetLdpcChannel(uChNum);
}

void vendorCmdWdPhyErase()
{
    LWORD u32TlcMode;
    WORD u16BlkTemp;
    BYTE uEemptyFlag=0x00;
    BYTE uFailMask=0x00, uReadyMask=0x60;

    u16BlkTemp=rmVndrFBlock;
    // save as cell mode
    u32TlcMode=mChkMlcMoBit(rmVndrFBlock);
    gpFlashAddrInfo=&gpVendorAddrInfo;
    g16WdVuEraseProgramSts=0x0000;

    if(rmVndrEnSlcMode)
    {
        // Slc mode.
        mClrMlcMoBit(rmVndrFBlock);
    }
    else
    {
        // Tlc mode.
        mSetMlcMoBit(rmVndrFBlock);
    }

    gOpTyp=cVenderErase;
    g16RwOpt=(0|cBit2|c16Bit3|c16Bit14);
    uEemptyFlag=setWdVendorInfo();

    if(uEemptyFlag!=cVuWdEmptyFail)
    {
        setWdPhyCh(gCh);
        rmSetBlkAddr(g16FBlock);
        rmSetPageAddr(0x00);
        rmSetSctrAddr(0x00);
        rmSetStartSector(0x00);
        rmSetDiePlane(gDieAddr, gPlaneAddr);

        resetEcc();
        rmDisStsFailStop;

        // flashErase(g16RwOpt);
        rmDirCeOn(gCe);
        flashChangeDieCmd(gDieAddr);

        if(rmVndrEnSlcMode)
        {
            rmCle(0xA2);
            rmNop(0x10);
            uFailMask=cBit2;
        }
        else
        {
            uFailMask=cBit0;
        }

        rmCle(0x60);
        rmAle3;
        rmCle(0xD0);

        rmNop(0x10);
        rmCle(0x78);
        rmAle3;
        rmStsFailMask(uFailMask);    // rmStsFailMask(0x00);
        rmRdStatus(uReadyMask);

        while(rmChkCmdFifoBz)
            ;

        rmManRd(4);

        while(rmChkCmdFifoBz)
            ;

        rmAllCeOff;

        garTsb0[g32HostXfrCnt-1][0x23]=gVuCmdSpFlag;
        // garTsb0[g32HostXfrCnt-1][0x24]=rFLCtrl[rcLdpcEccErrCntHB];
        // garTsb0[g32HostXfrCnt-1][0x25]=rFLCtrl[rcLdpcEccErrCntLB];
        // garTsb0[g32HostXfrCnt-1][0x26]=rmGetSprEcc;
        garTsb0[g32HostXfrCnt-1][0x27]=rmGetOPResultFlag;
        garTsb0[g32HostXfrCnt-1][0x28]=rFLCtrl[rcRd0];
        garTsb0[g32HostXfrCnt-1][0x29]=rFLCtrl[rcRd1];
        garTsb0[g32HostXfrCnt-1][0x2A]=rFLCtrl[rcRd2];
        garTsb0[g32HostXfrCnt-1][0x2B]=rFLCtrl[rcRd3];

        g16WdVuEraseProgramSts=(rmGetOPResultFlag<<8)|(rFLCtrl[rcRd0]);

        resetEcc();
        rmEnStsFailStop;
    }
    else
    {
        fillCcmVal((BYTE *)&garTsb0[0][0], ((gSectorPerPlaneH*gPlaneNum)+1)*512, cVuWdEmptyFail);
        g16WdVuEraseProgramSts=(cVuWdEmptyFail<<8)|cVuWdEmptyFail;
    }

    if(u32TlcMode)
    {
        mSetMlcMoBit(u16BlkTemp);
    }
    else
    {
        mClrMlcMoBit(u16BlkTemp);
    }
}    /* vendorCmdWdPhyErase */

void vendorCmdWdPhyProgram()
{
    LWORD u32TlcMode;
    BLKSPRINFO *upBlkSprInfo;
    WORD u16BlkTemp;
    BYTE uEemptyFlag=0x00;
    BYTE uFailMask=0x00, uReadyMask=0x60;
    WORD u16PageCnt=0, u16PageIndex=0;

    u16BlkTemp=rmVndrFBlock;
    // save as cell mode
    u32TlcMode=mChkMlcMoBit(rmVndrFBlock);
    gpFlashAddrInfo=&gpVendorAddrInfo;
    g16WdVuEraseProgramSts=0x0000;

    if(rmVndrEnSlcMode)
    {
        // Slc mode.
        mClrMlcMoBit(rmVndrFBlock);
    }
    else
    {
        // Tlc mode.
        mSetMlcMoBit(rmVndrFBlock);
    }

    gOpTyp=cVenderWrite;
    g16RwOpt=(0|cBit2|c16Bit14|c16Bit15);
    uEemptyFlag=setWdVendorInfo();
    mGetProgSctrCnt=gSectorPerPlaneH;

    if(uEemptyFlag!=cVuWdEmptyFail)
    {
        setWdPhyCh(gCh);
        rmSetBlkAddr(g16FBlock);
        rmSetSctrAddr(0x00);
        rmSetStartSector(0x00);
        rmSetDiePlane(gDieAddr, gPlaneAddr);

        if(rmVndrEnSlcMode)
        {
            u16PageCnt=1;
            // u16PageCnt=g16PagePerBlock1_SLC;
        }
        else
        {
            u16PageCnt=1;
            // u16PageCnt=g16PagePerBlock1;
        }

        // for(u16PageIndex=0;(rmVndrFPage+u16PageIndex)<u16PageCnt;u16PageIndex++)
        for(u16PageIndex=0; (rmVndrFPage+u16PageIndex)<(u16PageCnt+rmVndrFPage); u16PageIndex++)
        {
            resetEcc();
            rmDisStsFailStop;

            rmDirCeOn(gCe);
            flashChangeDieCmd(gDieAddr);

            g16FPage=rmVndrFPage+u16PageIndex;

            if(rmVndrEnSlcMode)
            {
                // rmSetPageAddr(g16FPage);
                // rmSetSeed(g16arSeedTable[g16FPage]);
                rmCle(0xA2);
                rmNop(0x10);
                uFailMask=cBit2;
            }
            else
            {
                setPageSelCmd(gpFlashAddrInfo, (g16FPage%cProgCntPerWL)+1);
                g16FPage=(g16FPage/cProgCntPerWL);

                // rmSetPageAddr(g16FPage);
                rmCle((mGetPageSelCmd(gpFlashAddrInfo)));
                uFailMask=cBit0;
                // rmSetSeed(g16arSeedTable[rmVndrFPage+u16PageIndex]);
            }

            rmSetPageAddr(g16FPage);
            rmSetSeed(g16arSeedTable[rmVndrFPage+u16PageIndex]);

            rmCle(0x80);
            rmWrDataDisBuf;
            rmSetBufSAddr(mGetWriteBuf);
            rmDataAle5;
            mWaitCmdFifoBz;
            rmWrData(mGetProgSctrCnt);
            mWaitCmdFifoBz;
            // Spr
            fillCcmVal((BYTE *)&rFLCtrl[(rcP0SprSeed+(gPlaneAddr*cSprGrpOffset))], 26, 0x00);
            upBlkSprInfo=(BLKSPRINFO *)(&rFLCtrl[(rcP0SprSeed+(gPlaneAddr*cSprGrpOffset))]);
            upBlkSprInfo->u16Seed=r16FLCtrl[rcDataSeed/2];
            upBlkSprInfo->u16Spr0.u16all=g16FBlock;
            upBlkSprInfo->u16Spr1.u16all=rmVndrFPage+u16PageIndex;
            upBlkSprInfo->u16Spr2.u16all=gCh;
            upBlkSprInfo->u16Spr3.u16all=gCe;
            upBlkSprInfo->u16Spr4.u16all=gDieAddr;
            upBlkSprInfo->u16Spr5.u16all=gPlaneAddr;
            upBlkSprInfo->u16Spr8.us2BYTE.HighByte=gpFlashAddrInfo->uOpTyp;
            upBlkSprInfo->u16Spr8.us2BYTE.LowByte=0xFF;    // BlkID

#if 1
            if(!rmVndrEnSlcMode)
            {
                rmCle((mGetPageSelCmd(gpFlashAddrInfo)));
            }

            rmCle(0x85);
            rmNop(cNopTcwaw);
            rmSprAle5;
#endif
            rmWrSpr;

            if(rmVndrEnSlcMode)
            {
                rmCle(0x10);
            }
            else
            {
                if(mGetPageSelCmd(gpFlashAddrInfo)==0x03)
                {
                    rmCle(0x10);
                }
                else
                {
                    rmCle(0x1A);
                }
            }

            rmNop(0x10);
            rmCle(0x78);
            rmAle3;
            rmStsFailMask(uFailMask);    // rmStsFailMask(0x00);
            rmRdStatus(uReadyMask);

            while(rmChkCmdFifoBz)
                ;

            rmManRd(4);

            while(rmChkCmdFifoBz)
                ;

            rmAllCeOff;

            // garTsb0[g32HostXfrCnt-1][0x23]=gVuCmdSpFlag;
            // garTsb0[g32HostXfrCnt-1][0x24]=rFLCtrl[rcLdpcEccErrCntHB];
            // garTsb0[g32HostXfrCnt-1][0x25]=rFLCtrl[rcLdpcEccErrCntLB];
            // garTsb0[g32HostXfrCnt-1][0x26]=rmGetSprEcc;
            // garTsb0[g32HostXfrCnt-1][0x27]=rmGetOPResultFlag;
            // garTsb0[g32HostXfrCnt-1][0x28]=rFLCtrl[rcRd0];
            // garTsb0[g32HostXfrCnt-1][0x29]=rFLCtrl[rcRd1];
            // garTsb0[g32HostXfrCnt-1][0x2A]=rFLCtrl[rcRd2];
            // garTsb0[g32HostXfrCnt-1][0x2B]=rFLCtrl[rcRd3];

            g16WdVuEraseProgramSts|=(rmGetOPResultFlag<<8)|(rFLCtrl[rcRd0]);

            resetEcc();
            rmEnStsFailStop;
        }
    }
    else
    {
        fillCcmVal((BYTE *)&garTsb0[0][0], ((gSectorPerPlaneH*gPlaneNum)+1)*512, cVuWdEmptyFail);
        g16WdVuEraseProgramSts=(cVuWdEmptyFail<<8)|cVuWdEmptyFail;
    }

    if(u32TlcMode)
    {
        mSetMlcMoBit(u16BlkTemp);
    }
    else
    {
        mClrMlcMoBit(u16BlkTemp);
    }
}    /* vendorCmdWdPhyProgram */

void vendorCmdWdPhyRead()
{
    LWORD u32TlcMode;
    BLKSPRINFO *upBlkSprInfo;
    WORD u16BlkTemp;
    BYTE uEemptyFlag=0x00;
    BYTE uFailMask=0x00, uReadyMask=0x60;

    u16BlkTemp=rmVndrFBlock;
    // save as cell mode
    u32TlcMode=mChkMlcMoBit(rmVndrFBlock);
    gpFlashAddrInfo=&gpVendorAddrInfo;
    g16WdVuEraseProgramSts=0x0000;

    if(rmVndrEnSlcMode)
    {
        // Slc mode.
        mClrMlcMoBit(rmVndrFBlock);
    }
    else
    {
        // Tlc mode.
        mSetMlcMoBit(rmVndrFBlock);
    }

    gOpTyp=cVenderRead;
    g16RwOpt=(0|c16Bit9|c16Bit10|c16Bit15);
    uEemptyFlag=setWdVendorInfo();
    mGetProgSctrCnt=gSectorPerPlaneH;

    if(uEemptyFlag!=cVuWdEmptyFail)
    {
        setWdPhyCh(gCh);

        resetEcc();
        rmDisUnCorrErrStop;
        rmDisOnesCntStop;
        rmSetEccFailForceXfr;

        // flashErase(g16RwOpt);
        rmDirCeOn(gCe);
        flashChangeDieCmd(gDieAddr);

        if((gVuCmdSpFlag&cVuCmdVthEnable)==cVuCmdVthEnable)
        {
            copyCcmVal((BYTE *)&gsFlashAddrInfoTemp, (BYTE *)&gpVendorAddrInfo, sizeof(ADDRINFO));
            setTestRetryCmd();
            rmCle(0x5D);
        }

        rmSetBlkAddr(g16FBlock);
        rmSetSctrAddr(0x00);
        rmSetStartSector(0x00);
        rmSetDiePlane(gDieAddr, gPlaneAddr);

        if(rmVndrEnSlcMode)
        {
            rmSetPageAddr(g16FPage);
            rmSetSeed(g16arSeedTable[g16FPage]);
            rmCle(0xA2);
            rmNop(0x10);
        }
        else
        {
            rmSetPageAddr(g16FPage);
            rmCle((mGetPageSelCmd(gpFlashAddrInfo)));

            rmSetSeed(g16arSeedTable[rmVndrFPage]);
        }

        rmCle(0x00);
        rmRdDataDisBuf;
        rmAle5;
        mWaitCmdFifoBz;
        rmCle(0x30);

        rmNop(0x10);
        rmCle(0x78);
        rmAle3;
        rmStsFailMask(uFailMask);
        rmRdStatus(uReadyMask);

        while(rmChkCmdFifoBz)
            ;

        if(mGetReadOpt&c16Bit4)
        {
            // Read Data
            rmCle(0x05);
            rmAle5;
            rmCle(0xE0);

            rmRdDataDisBuf;
            rmSetBufSAddr(mGetReadBuf);
            rmRdData(mGetReadSctrCnt);
            mWaitCmdFifoBz;

            if((gVuCmdSpFlag&cVuCmdRetryEnable)==cVuCmdRetryEnable)
            {
                if(rmChkUNC)
                {
                    doReadRetry(gpFlashAddrInfo, cNoPlaneIndex, cLdpcPipeLineDisableMode);
                }
            }
        }

        if(mGetReadOpt&c16Bit5)
        {
            // Read Spr
            fillCcmVal((BYTE *)&rFLCtrl[(rcP0SprSeed+(gPlaneAddr*cSprGrpOffset))], 26, 0x00);
            upBlkSprInfo=(BLKSPRINFO *)(&rFLCtrl[(rcP0SprSeed+(gPlaneAddr*cSprGrpOffset))]);
            rmSelSpr;
            rmCle(0x05);
            rmAle5;
            rmCle(0xE0);
            rmRdSpr;
            mWaitCmdFifoBz;

            if((gVuCmdSpFlag&cVuCmdRetryEnable)==cVuCmdRetryEnable)
            {
                if(rmSprUNC)
                {
                    doReadRetry(gpFlashAddrInfo, cNoPlaneIndex, cLdpcPipeLineDisableMode);
                }
            }

            copyReg2Tsb((BYTE *)&garTsb0[g32HostXfrCnt-1][0], (volatile BYTE *)(upBlkSprInfo), sizeof(BLKSPRINFO));
        }

        garTsb0[g32HostXfrCnt-1][0x23]=gVuCmdSpFlag;
        garTsb0[g32HostXfrCnt-1][0x24]=rFLCtrl[rcLdpcEccErrCntHB];
        garTsb0[g32HostXfrCnt-1][0x25]=rFLCtrl[rcLdpcEccErrCntLB];
        garTsb0[g32HostXfrCnt-1][0x26]=rmGetSprEcc;
        garTsb0[g32HostXfrCnt-1][0x27]=rmGetEccResultSts;
        garTsb0[g32HostXfrCnt-1][0x28]=rmGetEccCorrectableSts;
        garTsb0[g32HostXfrCnt-1][0x29]=rFLCtrl[rcOnceCntstatus];
        garTsb0[g32HostXfrCnt-1][0x2A]=rFLCtrl[(rcChunkEccStsMap+1)];
        garTsb0[g32HostXfrCnt-1][0x2B]=rFLCtrl[rcChunkEccStsMap];

        if((gVuCmdSpFlag&cVuCmdRetryEnable)==cVuCmdRetryEnable)
        {
            garTsb0[g32HostXfrCnt-1][0x27]=((g16EccFailRegInfo>>8)&0xFF);
            garTsb0[g32HostXfrCnt-1][0x29]=((g16EccFailRegInfo)&0xFF);

            if(((g16EccFailRegInfo)&0xFF)!=0x00)
            {
                garTsb0[g32HostXfrCnt-1][0x2A]=((g16DebugLastFailChunkBitMap>>8)&0xFF);
                garTsb0[g32HostXfrCnt-1][0x2B]=(g16DebugLastFailChunkBitMap&0xFF);
            }

            gVuCmdSpFlag=gVuCmdSpFlag&(~cVuCmdRetryEnable);
        }

        g16arTsb0[g32HostXfrCnt-1][0x30/2]=rmGetLdpcChkErrCnt(0);
        g16arTsb0[g32HostXfrCnt-1][0x32/2]=rmGetLdpcChkErrCnt(1);
        g16arTsb0[g32HostXfrCnt-1][0x34/2]=rmGetLdpcChkErrCnt(2);
        g16arTsb0[g32HostXfrCnt-1][0x36/2]=rmGetLdpcChkErrCnt(3);
        g16arTsb0[g32HostXfrCnt-1][0x38/2]=rmGetLdpcChkErrCnt(4);
        g16arTsb0[g32HostXfrCnt-1][0x3A/2]=rmGetLdpcChkErrCnt(5);
        g16arTsb0[g32HostXfrCnt-1][0x3C/2]=rmGetLdpcChkErrCnt(6);
        g16arTsb0[g32HostXfrCnt-1][0x3E/2]=rmGetLdpcChkErrCnt(7);

        if((gVuCmdSpFlag&cVuCmdVthEnable)==cVuCmdVthEnable)
        {
            fillCcmVal((BYTE *)&garVuCmdVthCenter[0], (sizeof(garVuCmdVthCenter)), cZero);
            setTestRetryCmd();
            gVuCmdSpFlag=(gVuCmdSpFlag&(~cVuCmdVthEnable));
        }

        rmAllCeOff;

        while(rmChkLdpcDmaSt)
            ;

        while(rmChkCmdFifoBz)
            ;

        resetEcc();
        rmEnOnesCntStop;
        rmEnUnCorrErrStop;
        rmClrEccFailForceXfr;

        while(rmChkCmdFifoBz)
            ;

        while(rmChkUNC)
            ;

        while(rmChkSysUNC)
            ;

        waitCmdFifoDpt(gCh, gpFlashAddrInfo);
    }
    else
    {
        fillCcmVal((BYTE *)&garTsb0[0][0], ((gSectorPerPlaneH*gPlaneNum)+1)*512, cVuWdEmptyFail);
        g16WdVuEraseProgramSts=(cVuWdEmptyFail<<8)|cVuWdEmptyFail;
    }

    if(u32TlcMode)
    {
        mSetMlcMoBit(u16BlkTemp);
    }
    else
    {
        mClrMlcMoBit(u16BlkTemp);
    }
}    /* vendorCmdWdPhyRead */

void vendorCmdWdCheckSts()
{
    if(g16WdVuEraseProgramSts==((cVuWdEmptyFail<<8)|cVuWdEmptyFail))
    {
        fillCcmVal((BYTE *)&garTsb0[0][0], ((gSectorPerPlaneH*gPlaneNum)+1)*512, cVuWdEmptyFail);
    }
    else
    {
        fillCcmVal((BYTE *)&garTsb0[0][0], ((gSectorPerPlaneH*gPlaneNum)+1)*512, cZero);
        g16arTsb0[0][0]=g16WdVuEraseProgramSts;
        g16arTsb0[0][1]=g16WdVuEraseProgramSts;
    }
}

void doVtDistribution()
{
#if 0
#else
    // Wait LITEON/TSB VtDistribution flow!!
#endif
    // lock gate=====================
}    /* doVtDistribution */

void avgEraseCnt()
{
    WORD u16Fblk, u16TlcIdx=0, u16SlcIdx=0;
    WORD u16MaxTlcEraseCnt=0, u16MaxSlcEraseCnt=0;
    WORD u16MinTlcEraseCnt=0xFFFF, u16MinSlcEraseCnt=0xFFFF;
    LWORD u32SumTlcEraseCnt=0, u32SumSlcEraseCnt=0;

    // Steve modify 20180927 same with DFD debug log
    for(u16Fblk=g16FirstFBlock; u16Fblk<g16TotalFBlock; u16Fblk++)
    {
        if(g16arGlobEraseCnt[u16Fblk]!=0xFFFF)
        {
            if(u16Fblk>=g16StaticBound)
            {
                // TLC
                g16arTsb0[8][u16TlcIdx]=g16arGlobEraseCnt[u16Fblk];
                u16TlcIdx++;
                u32SumTlcEraseCnt+=g16arGlobEraseCnt[u16Fblk];

                if(g16arGlobEraseCnt[u16Fblk]>u16MaxTlcEraseCnt)
                {
                    u16MaxTlcEraseCnt=g16arGlobEraseCnt[u16Fblk];
                }

                if(g16arGlobEraseCnt[u16Fblk]<u16MinTlcEraseCnt)
                {
                    u16MinTlcEraseCnt=g16arGlobEraseCnt[u16Fblk];
                }
            }
            else
            {
                // SLC
                g16arTsb0[16][u16SlcIdx]=g16arGlobEraseCnt[u16Fblk];
                u16SlcIdx++;
                u32SumSlcEraseCnt+=g16arGlobEraseCnt[u16Fblk];

                if(g16arGlobEraseCnt[u16Fblk]>u16MaxSlcEraseCnt)
                {
                    u16MaxSlcEraseCnt=g16arGlobEraseCnt[u16Fblk];
                }

                if(g16arGlobEraseCnt[u16Fblk]<u16MinSlcEraseCnt)
                {
                    u16MinSlcEraseCnt=g16arGlobEraseCnt[u16Fblk];
                }
            }
        }
    }

    if(u16MinTlcEraseCnt==0xFFFF)
    {
        u16MinTlcEraseCnt=0;
    }

    if(u16MinSlcEraseCnt==0xFFFF)
    {
        u16MinSlcEraseCnt=0;
    }

    if(u16TlcIdx==0)
    {
        g16arTsb0[24][0]=0;
    }
    else
    {
        g16arTsb0[24][0]=u32SumTlcEraseCnt/u16TlcIdx;
    }

    if(u16SlcIdx==0)
    {
        g16arTsb0[24][1]=0;
    }
    else
    {
        g16arTsb0[24][1]=u32SumSlcEraseCnt/u16SlcIdx;
    }

    // TLC
    g32arTsb0[0][0x4]=u16MaxTlcEraseCnt;
    // g32arTsb0[0][0x5]=(u32SumSlcEraseCnt+u32SumTlcEraseCnt)/(u16SlcIdx+u16TlcIdx);
    g32arTsb0[0][0x5]=u32SumTlcEraseCnt/u16TlcIdx;
    g32arTsb0[0][0x6]=u16MinTlcEraseCnt;
    // SLC
    g32arTsb0[0][0x8]=u16MaxSlcEraseCnt;
    g32arTsb0[0][0x9]=u32SumSlcEraseCnt/u16SlcIdx;
    g32arTsb0[0][0xA]=u16MinSlcEraseCnt;
}    /* avgEraseCnt */

void funcTskVendorOp(BYTE uTskTail)
{
    waitAllChCeBz();
    gpFlashAddrInfo=&gpVendorAddrInfo;
    setFLActCh(gCh);

    if((gsTskFifoCtrl.uarTskFifo[uTskTail].uTskOpt)==cVendorCore1ReadFlash)
    {
        vendorCmdReadPhysicalPage();
    }
    else if((gsTskFifoCtrl.uarTskFifo[uTskTail].uTskOpt)==cVendorCore1ProgFlash)
    {
        vendorCmdWritePhysicalPage();
    }
    else if((gsTskFifoCtrl.uarTskFifo[uTskTail].uTskOpt)==cVendorCore1EraseFlash)
    {
        vendorCmdErasePhysicalBlock();
    }
    else if((gsTskFifoCtrl.uarTskFifo[uTskTail].uTskOpt)==cVendorCore1ReadGlobEraseCnt)
    {
        // readGlobEraseCnt(g16RwOpt);
        UCBYTE *ucPtr=(UCBYTE *)garTsb0;
        bopClrRam((LWORD)c32Tsb0SAddr, 26*512, 0x00000000, cBopWait|cClrTsb);
        copyCcmVal((UCBYTE *)&garTsb0[0][0], (UCBYTE *)g16arGlobEraseCnt, (g16TotalFBlock*2));
        ucPtr+=(g16TotalFBlock*2);
        *(ucPtr)=g16TotalFBlock>>8;
        *(ucPtr+1)=g16TotalFBlock;
        *(ucPtr+2)=g16FirstFBlock>>8;
        *(ucPtr+3)=g16FirstFBlock;
        *(ucPtr+4)=gMinStaticSlcCnt;
        // avgEraseCnt();
    }
    else if((gsTskFifoCtrl.uarTskFifo[uTskTail].uTskOpt)==cVendorCore1ReadGlobReadCnt)
    {
#if _EN_VPC_SWAP
        // readGlobEraseCnt(g16RwOpt);
        copyCcmVal((UCBYTE *)&garTsb0[0][0], (UCBYTE *)g16arGlobReadCnt, (c16MaxBlockNum*2));
        copyCcmVal((UCBYTE *)&garTsb0[(c16MaxBlockNum>>8)][0], (UCBYTE *)garGlobReadCntHighByte, (c16MaxBlockNum));
#else
        // readGlobEraseCnt(g16RwOpt);
        copyCcmVal((UCBYTE *)&garTsb0[0][0], (UCBYTE *)g32arGlobReadCnt, (c16MaxBlockNum*4));
#endif
    }
    else if((gsTskFifoCtrl.uarTskFifo[uTskTail].uTskOpt)==cVendorCore1ReadFlashId)
    {
        readFlashId((BYTE *)(&garTsb0[0][0x30]));
        // copyCcmVal((BYTE *)(&garTsb0[0][0x30]), (BYTE *)gFlashId, 8);
    }
    else if((gsTskFifoCtrl.uarTskFifo[uTskTail].uTskOpt)==cVendorCore1doVtDistribution)
    {
        doVtDistribution();
    }
    else if((gsTskFifoCtrl.uarTskFifo[uTskTail].uTskOpt)==cVendorCore1WdPhyErase)
    {
        // WD FAE Debug using
        vendorCmdWdPhyErase();
    }
    else if((gsTskFifoCtrl.uarTskFifo[uTskTail].uTskOpt)==cVendorCore1WdPhyProgram)
    {
        // WD FAE Debug using
        vendorCmdWdPhyProgram();
    }
    else if((gsTskFifoCtrl.uarTskFifo[uTskTail].uTskOpt)==cVendorCore1WdPhyRead)
    {
        // WD FAE Debug using
        vendorCmdWdPhyRead();
    }
    else if((gsTskFifoCtrl.uarTskFifo[uTskTail].uTskOpt)==cVendorCore1WdCheckSts)
    {
        // WD FAE Debug using
        vendorCmdWdCheckSts();
    }
    else if((gsTskFifoCtrl.uarTskFifo[uTskTail].uTskOpt)==cVendorCore1WriteMPInfo)
    {
        vendorCmdWriteMPInfo();
    }
    else if((gsTskFifoCtrl.uarTskFifo[uTskTail].uTskOpt)==cVendorCore1ModifyEraseCnt)
    {
#if _GREYBOX
        WORD u16TmpIdx=0;

        for(WORD u16Idx=g16FirstFBlock; u16Idx<g16TotalFBlock; u16Idx++)
        {
            g16GbGlobEraseCnt[u16Idx]=g16arGlobEraseCnt[u16Idx];

            if(mChkPoppedBit(u16Idx))    //
            {
                if(mChkMlcMoBit(u16Idx)&&(g16arGlobEraseCnt[u16Idx]!=c16BitFF))    // TLC && Not bad block
                {
                    u16TmpIdx=u16Idx;
                    g16GbWLGcSrcTLCBlock=u16Idx;
                }
            }
        }

        for(WORD u16Idx=g16FirstFBlock; u16Idx<g16TotalFBlock; u16Idx++)
        {
            if(mChkPoppedBit(u16Idx)&&mChkMlcMoBit(u16Idx)&&(g16arGlobEraseCnt[u16Idx]!=c16BitFF))    // TLC
            {
                if(u16Idx!=u16TmpIdx)    // TLC
                {
                    g16arGlobEraseCnt[u16Idx]+=500;
                    gsCacheInfo.u32DynamicTotalEraseCnt+=500;    // test by yhlin
                }
            }
            else if((!mChkPoppedBit(u16Idx))&&mChkMlcMoBit(u16Idx))    // empty block && TLC Block
            {
                if((g16GbWLGcDesTLCBlock==0)&&(g16arGlobEraseCnt[u16Idx]!=c16BitFF))
                {
                    g16GbWLGcDesTLCBlock=u16Idx;
                    g16arGlobEraseCnt[u16Idx]+=100;
                }
                else if((g16arGlobEraseCnt[u16Idx]!=c16BitFF)&&(g16arGlobEraseCnt[u16Idx]<(gsCacheInfo.u16DynamicAvgEraseCnt+cWearLevelThr))&&
                        (g16arGlobEraseCnt[g16GbWLGcDesTLCBlock]<g16arGlobEraseCnt[u16Idx]))
                {
                    g16GbWLGcDesTLCBlock=u16Idx;
                }
            }
        }
#endif/* if _GREYBOX */
    }
    else if((gsTskFifoCtrl.uarTskFifo[uTskTail].uTskOpt)==cVendorCore1MarkBadBlock)
    {
#if _GREYBOX
        ADDRINFO upTmpAddrInfo;
        BYTE uEraseFlag;
        LWORD u32TempFPageNoTran, u32EraseFail=0;
        uEraseFlag=((rmNvmeSubCmdParam1>>16)&0xF000)>>12;
        upTmpAddrInfo.u16AbstractFBlock=rmNvmeSubCmdParam1&0x0000FFFF;
        upTmpAddrInfo.u32FPageNoTran=rmNvmeSubCmdParam2;
        upTmpAddrInfo.uCh=(rmNvmeSubCmdParam1>>16)&0x000F;
        upTmpAddrInfo.uPlaneAddr=((rmNvmeSubCmdParam1>>16)&0x00F0)>>4;
        upTmpAddrInfo.uIntlvAddr=((rmNvmeSubCmdParam1>>16)&0x0F00)>>8;
        upTmpAddrInfo.u16FPage=(WORD)((upTmpAddrInfo.u32FPageNoTran>>gPhyPageAddrBitShiftCnt)&g32PhyPageAddrMask);

        if(uEraseFlag==0)
        {
            if(mChkPoppedBit(upTmpAddrInfo.u16AbstractFBlock))
            {}
            else
            {
                if((!mChkPoppedBit(upTmpAddrInfo.u16AbstractFBlock))&&mChkMlcMoBit(upTmpAddrInfo.u16AbstractFBlock))    // empty block && TLC
                                                                                                                        // Block
                {
                    u32TempFPageNoTran=upTmpAddrInfo.u16FPage;
                    upTmpAddrInfo.u16FPage=u32TempFPageNoTran/cProgCntPerWL;
                    setPageSelCmd(&upTmpAddrInfo, (u32TempFPageNoTran-(upTmpAddrInfo.u16FPage*cProgCntPerWL))+1);
                    setMarkBadBlock(&upTmpAddrInfo, cTLCRdEccFailID);
                }
                else    // SLC
                {
                    setPageSelCmd(&upTmpAddrInfo, cSlcCmd);
                    setMarkBadBlock(&upTmpAddrInfo, cRdEccFailID);
                }
            }
        }
        else
        {
            u32EraseFail=1;
            setEraseBadBlock(upTmpAddrInfo.u16AbstractFBlock, u32EraseFail);
#if 1    // just for No Org Bad
            if(u32EraseFail)
            {
                mSetPoppedBit(upTmpAddrInfo.u16AbstractFBlock);
                mSetGlobEraseCnt(upTmpAddrInfo.u16AbstractFBlock, c16BitFF);
            }
#endif

#if !_EN_Always_DynamicMode
            if(gsFtlDbg.uStaticMode==cEndStaticMode)
            {
                if(mChkMlcMoBit(upTmpAddrInfo.u16AbstractFBlock))
                {
                    gsCacheInfo.u32DynamicTotalEraseCnt++;
                    gsCacheInfo.u16DynamicAvgEraseCnt=(gsCacheInfo.u32DynamicTotalEraseCnt/g16MinStaticTlcCnt);
                }

#if _EN_Dynamic_Fix_Boundary
                else
#else
                else if(!mChkMlcMoBit(upTmpAddrInfo.u16AbstractFBlock))
#endif
                {
                    gsCacheInfo.u32SLCTotalEraseCnt++;
                    gsCacheInfo.u16SLCAvgEraseCnt=(gsCacheInfo.u32SLCTotalEraseCnt/gMinStaticSlcCnt);
                }
            }
#endif/* if !_EN_Always_DynamicMode */
        }
#endif/* if _GREYBOX */
    }
    else if((gsTskFifoCtrl.uarTskFifo[uTskTail].uTskOpt)==cVendorCore1ReadOrgBadCnt)
    {
        loadInfoPage(gsTskFifoCtrl.uarTskFifo[uTskTail].uTskPgOfst,
                     gSectorPerPlaneH,
                     gsTskFifoCtrl.uarTskFifo[uTskTail].u16TskSBufPtr,
                     0,
                     cSysBlock1stInfo,
                     0);
    }
    else if((gsTskFifoCtrl.uarTskFifo[uTskTail].uTskOpt)==cVendorCore1ReadOrgBadTable)
    {
        WORD u16FPage=0, u16StrBuf=0;
        u16FPage=gsTskFifoCtrl.uarTskFifo[uTskTail].uTskPgOfst;
        u16StrBuf=gsTskFifoCtrl.uarTskFifo[uTskTail].u16TskSBufPtr;

        while(u16FPage<gEraseBlockStatusStartPage)
        {
            loadInfoPage(u16FPage, gSectorPerPlaneH, u16StrBuf, 0, cSysBlock1stInfo, 0);
            u16StrBuf+=gSectorPerPlaneH;
            u16FPage++;
        }
    }
    else if((gsTskFifoCtrl.uarTskFifo[uTskTail].uTskOpt)==cVendorCore1LiteOnVU_ReadFlashId)
    {
        readFlashId_LiteOnVU((BYTE *)(&garTsb0[0][0x0]));
        // readFlashId((BYTE *)(&garTsb0[0][0x30]));
    }
    else if((gsTskFifoCtrl.uarTskFifo[uTskTail].uTskOpt)==cVendorCore1LiteOnVU_ReadGlobEraseCnt)
    {
        readGlobEraseCnt_LiteOnVU((BYTE *)(&garTsb0[0][0x0]));
        // readFlashId((BYTE *)(&garTsb0[0][0x30]));
    }

    ctrlScrbBothAndEcc(1, 1);
}    /* funcTskVendorOp */

BYTE chkFlashVendorID()
{
    switch(rFLCtrl[rcRd0])
    {
        case cSamsungID:
        case cToshibaID:
        case cInfineonID:
        case cSandiskID:
        case cHynixID:
        case cMicronID:
        case cSTID:
        case cIntelID:
            return 1;

        default:
            return 0;
    }
}    /* chkFlashVendorID */

void readFlashId(BYTE *upPtr)
{
    BYTE uActiveCe;

#if (_SANDISK_3D_GEN2||_SANDISK_3D_GEN3||_TSB_BiCS3||_TSB_BiCS4)
    BYTE uIdNum, uIsFlashVendorID, uRecover=0;

    if(rmChkDfDdrEn)
    {
        uRecover=1;
        setFlashClock(cSlowClock);
    }

    // Read FlashID
    for(uActiveCe=0; uActiveCe<gTotalCeNum; uActiveCe++)
    {
        for(gActiveCh=0; gActiveCh<gTotalChNum; gActiveCh++)
        {
            setFLActCh(gActiveCh);
            rmCeOn(uActiveCe);
            rFLCtrl[rcRd0]=0x00;
            rFLCtrl[rcRd1]=0x00;
            rFLCtrl[rcRd2]=0x00;
            rFLCtrl[rcRd3]=0x00;
            rFLCtrl[rcRd4]=0x00;
            rFLCtrl[rcRd5]=0x00;
            rFLCtrl[rcRd6]=0x00;
            rFLCtrl[rcRd6]=0x00;

            while(rmChkCmdFifoBz)
                ;

            rmCle(0x70);
            rmRdStatus(cPollMaskNor);

            while(rmChkCmdFifoBz)
                ;

            rmCle(0x90);
            rmAle(0x00);
            rmNop(cTwhr);

            while(rmChkCmdFifoBz)
                ;

            for(uIdNum=0; uIdNum<cMaxIDNum; uIdNum++)
            {
                rmManRd(1);

                while(rmChkCmdFifoBz)
                    ;

                rmNop(cTwhr);

                if(!uIdNum)
                {
                    if(chkFlashVendorID())
                    {
                        uIsFlashVendorID=1;
                    }
                    else
                    {
                        uIsFlashVendorID=0;
                    }
                }

                if(uIsFlashVendorID)
                {
                    upPtr[(garCeMapTable[uActiveCe]*cMaxChNum+garChMapTable[gActiveCh])*cMaxIDNum+uIdNum]=rFLCtrl[rcRd0];
                }
                else
                {
                    upPtr[(garCeMapTable[uActiveCe]*cMaxChNum+garChMapTable[gActiveCh])*cMaxIDNum+uIdNum]=0xFF;
                }
            }

            rmCeOff(uActiveCe);
        }

        setFLActCh(0);
    }

    if(uRecover)
    {
        setFlashClock(g16FlashClock);
    }
#else/* if (_SANDISK_3D_GEN2||_SANDISK_3D_GEN3||_TSB_BiCS3||_TSB_BiCS4) */
    // doesn't support
    bopClrRam((LWORD)&upPtr[(uActiveCe*cMaxChNum+gActiveCh)*cMaxIDNum], cMaxIDNum, 0xFF, cBopWait|cClrTsb);
#endif/* if (_SANDISK_3D_GEN2||_SANDISK_3D_GEN3||_TSB_BiCS3||_TSB_BiCS4) */
}    /* readFlashId */

void vendorCmdWriteMPInfo()
{
    WORD u16ProgIndex;
    BYTE *upMPInfoBuf;
    BYTE uarSprInfo[cSprSpace]={0};
    ADDRINFO usTmpAddrInfo;

    g16WdVuEraseProgramSts=0x00;
    bopCopyRam((LWORD)&garTsb0[gSectorPerPlaneH*2][0x0], (LWORD)&garTsb0[0][0x0], 8192, cCopyTsb2Tsb|cBopWait);
    loadInfoPage(0, gSectorPerPlaneH, c16WriteSIdx, 0, cSysBlockMPInfo, cBit1);
    bopCopyRam((LWORD)&garTsb0[16][0x0], (LWORD)&garTsb0[gSectorPerPlaneH*2][0x0], 8192, cCopyTsb2Tsb|cBopWait);

    tranRsvBlkAddr(garSysBlock[cSysBlockMPInfo], &usTmpAddrInfo);
    enEccInNormal();

    setFLAddrActCh(usTmpAddrInfo.uCh, &usTmpAddrInfo);

    resetEcc();
    rmDisStsFailStop;

    g16RwOpt=0;

    /* force 1 plane */
    g16RwOpt=c16Bit2|c16Bit14|c16Bit15;

    /* Check Vendor command option */
    gOpTyp=cVenderErase;

    rmEnEcc;
    rmEnScrbBoth;
    rmClrEccFailForceXfr;

    flashErase(g16RwOpt);

    setFLAddrActCh(usTmpAddrInfo.uCh, &usTmpAddrInfo);
    rmCeOn(usTmpAddrInfo.uCe);
    rmNop(0x10);
    rmCle(0x70);
    rmStsFailMask(cBit2);    // rmStsFailMask(0x00);
    rmRdStatus(cPollMaskNor);

    while(rmChkCmdFifoBz)
        ;

    rmManRd(4);

    while(rmChkCmdFifoBz)
        ;

    if(rmChkStatusFail)    // if(gbEraseFail)
    {
        g16WdVuEraseProgramSts=(rmGetOPResultFlag<<8)|(rFLCtrl[rcRd0]);
        rmAllCeOff;
        resetEcc();
        rmEnStsFailStop;
    }
    else
    {
        upMPInfoBuf=(BYTE *)cTsb0Addr;
        *(WORD *)(&upMPInfoBuf[0x3A4])=g16FlashClock;

        for(u16ProgIndex=cZero; u16ProgIndex<g16PagePerBlock1_SLC; u16ProgIndex++)
        {
            /* disable Max Ecc */
            enEccInNormal();

            setFLAddrActCh(usTmpAddrInfo.uCh, &usTmpAddrInfo);
            resetEcc();
            rmDisStsFailStop;

            g16RwOpt=0;

            g16FPage=u16ProgIndex;
            gSectorH=0;
            mClrMlcMoBit(g16FBlock);
            rmEnEcc;
            rmEnScrbBoth;
            rmClrEccFailForceXfr;

            /* fill Spare */
            fillCcmVal((BYTE *)uarSprInfo, cSprSpace, 0x00);
            uarSprInfo[0x00]=uarSprInfo[0x10]=cMPInfoBlockID;
            copyCcmVal((BYTE *)&rFLCtrl[rcSpr0+(gPlaneAddr*cSprPlaneOffset)], uarSprInfo, cSprByteNum);

            mSetFRwParam(c16Tsb0SIdx, gSectorPerPlaneH, c16Bit4|c16Bit14|c16Bit15, cVenderWrite);

            mSetTabSpr(gpFlashAddrInfo, cBit5);
            flashProgPage(mGetWriteBuf, mGetProgSctrCnt, mGetWriteOpt);

            setFLAddrActCh(usTmpAddrInfo.uCh, &usTmpAddrInfo);
            rmCeOn(usTmpAddrInfo.uCe);
            rmNop(0x10);
            rmCle(0x70);
            rmStsFailMask(cBit2);    // rmStsFailMask(0x00);
            rmRdStatus(0x60);

            while(rmChkCmdFifoBz)
                ;

            rmManRd(4);

            while(rmChkCmdFifoBz)
                ;

            if(rmChkStatusFail)    // if(gbEraseFail)
            {
                g16WdVuEraseProgramSts=(rmGetOPResultFlag<<8)|(rFLCtrl[rcRd0]);
                rmAllCeOff;
                resetEcc();
                rmEnStsFailStop;
                break;
            }
        }
    }
}    /* vendorCmdWriteMPInfo */

void readFlashId_LiteOnVU(BYTE *upPtr)
{
    BYTE uActiveCe;
    WORD u16Count=0;

#if (_SANDISK_3D_GEN2||_SANDISK_3D_GEN3||_TSB_BiCS3||_TSB_BiCS4)
    BYTE uIdNum, uIsFlashVendorID, uRecover=0;

    if(rmChkDfDdrEn)
    {
        uRecover=1;
        setFlashClock(cSlowClock);
    }

    // Read FlashID
    for(gActiveCh=0; gActiveCh<gTotalChNum; gActiveCh++)
    {
        setFLActCh(gActiveCh);

        for(uActiveCe=0; uActiveCe<gTotalCeNum; uActiveCe++)
        {
            rmCeOn(uActiveCe);
            rFLCtrl[rcRd0]=0x00;
            rFLCtrl[rcRd1]=0x00;
            rFLCtrl[rcRd2]=0x00;
            rFLCtrl[rcRd3]=0x00;
            rFLCtrl[rcRd4]=0x00;
            rFLCtrl[rcRd5]=0x00;
            rFLCtrl[rcRd6]=0x00;
            rFLCtrl[rcRd6]=0x00;

            while(rmChkCmdFifoBz)
                ;

            // rmCle(0xFF);
            rmCle(0x70);
            rmRdStatus(cPollMaskNor);

            while(rmChkCmdFifoBz)
                ;

            rmCle(0x90);
            rmAle(0x00);
            rmNop(cTwhr);

            while(rmChkCmdFifoBz)
                ;

            upPtr[u16Count]=gActiveCh;
            upPtr[u16Count+1]=uActiveCe;

            for(uIdNum=0; uIdNum<cMaxIDNum; uIdNum++)
            {
                rmManRd(1);

                while(rmChkCmdFifoBz)
                    ;

                rmNop(cTwhr);

                if(!uIdNum)
                {
                    if(chkFlashVendorID())
                    {
                        uIsFlashVendorID=1;
                    }
                    else
                    {
                        uIsFlashVendorID=0;
                    }
                }

                if(uIsFlashVendorID)
                {
                    upPtr[u16Count+0x04+uIdNum]=rFLCtrl[rcRd0];
                }
                else
                {
                    upPtr[u16Count+0x04+uIdNum]=0xFF;
                }
            }

            u16Count+=0x10;
            rmCeOff(uActiveCe);
        }
    }

    setFLActCh(0);

    if(uRecover)
    {
        setFlashClock(g16FlashClock);
    }
#else/* if (_SANDISK_3D_GEN2||_SANDISK_3D_GEN3||_TSB_BiCS3) */
    // doesn't support
    bopClrRam((LWORD)&upPtr[(uActiveCe*cMaxChNum+gActiveCh)*cMaxIDNum], cMaxIDNum, 0xFF, cBopWait|cClrTsb);
#endif/* if (_SANDISK_3D_GEN2||_SANDISK_3D_GEN3||_TSB_BiCS3) */
}    /* readFlashId */

void readGlobEraseCnt_LiteOnVU(BYTE *upPtr)
{
    // BYTE uActiveCe;
    // WORD u16Count=0;
    bopClrRam((LWORD)c32Tsb0SAddr, 26*512, 0x00000000, cBopWait|cClrTsb);
    // copyCcmVal((UCBYTE *)&garTsb0[0][0], (UCBYTE *)g16arGlobEraseCnt, (c16MaxBlockNum*2));
    // Table tag
    garTsb0[0][0x0]='E';
    garTsb0[0][0x1]='C';
    garTsb0[0][0x2]='T';
    garTsb0[0][0x3]='B';
    // Type
    garTsb0[0][0x4]=0xFF;
    garTsb0[0][0x5]=0xFF;
    // Version
    garTsb0[0][0x6]=0xFF;
    garTsb0[0][0x7]=0xFF;
    // Length
    g32arTsb0[0][0x2]=g16TotalFBlock*2;
    // EC Information
    avgEraseCnt();
}    /* readGlobEraseCnt_LiteOnVU */

#pragma default_function_attributes =







