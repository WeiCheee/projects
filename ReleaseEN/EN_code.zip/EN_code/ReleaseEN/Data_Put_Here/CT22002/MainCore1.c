







#include "inc/Asm.h"
// #include "inc/BitDef.h"
#include "inc/Const.h"
// #include "inc/FtlCtrl.h"
#include "inc/GlobVar1.h"
#include "inc/GlobVarS.h"
#include "inc/GlobVarT.h"
#include "inc/Mac.h"
// #include "inc/NvmeCtrl.h"
#include "inc/Option.h"
#include "inc/ProType.h"
#include "inc/Reg.h"
// #include "inc/Table.h"
#include "inc/TypeDef.h"
// #include "inc/Rdlink.h"
#include "inc/GreyBox.h"

#include "RdlinkVar.c"

#pragma default_function_attributes = @ ".CORE1_CODE"
#include "Isr1.c"
#include "Bop.c"
#include "StbLib.c"
// #include "PrdMgr.c"
#include "SysCtrl.c"
// #include "NvmeCtrl.c"
// #include "RwCmd.c"
#include "Hdma.c"
#include "WproBlk.c"
#include "SaveIdx.c"
#include "Table.c"
#include "SprBlk.c"
#include "DiffAddr.c"
#include "FlashCmd.c"
#include "FlashCtrl.c"
#include "FlashReadRetry.c"
#include "VthTracking.c"
#include "TrigAddrInfo.c"
#include "FlashPub.c"
#include "H2fTab.c"
// #include "Vic1Ctrl.c"
// #include "SramEcc.c"
#if _ENABLE_RAID
#include "Raid.c"
#include "RaidDec.c"
#endif

// #include "Core1TempInvFunc.c"
#include "FtlPub.c"
// #include "InitDRAM.c"
#include "FtlIndiv.c"

void saveWdtDebugInfo(WORD u16BufIdx)
{
    ADDRINFO usTmpAddrInfo;
    BLKSPRINFO usBlkSprInfo;
    WORD u16PageCnt=0;

    bopClrRam(c32Tsb0SAddr+(u16BufIdx*cSingleSectorByte), (cTelemetryArea3DataSecCnt*cSingleSectorByte),
              0x00000000, cBopWait|cClrTsb);
#if _EN_VPC_SWAP
    bopCopyRam(c32Tsb0SAddr+(u16BufIdx*cSingleSectorByte), (LWORD)(&g16arGlobReadCnt[0]),
               c16MaxBlockNum*sizeof(WORD), cCopyTsb2Tsb|cBopWait);
    bopCopyRam(c32Tsb0SAddr+(u16BufIdx*cSingleSectorByte)+(c16MaxBlockNum*sizeof(WORD)), (LWORD)(&garGlobReadCntHighByte[0]),
               c16MaxBlockNum*sizeof(BYTE), cCopyTsb2Tsb|cBopWait);
    bopCopyRam(c32Tsb0SAddr+(u16BufIdx*cSingleSectorByte)+(c16MaxBlockNum*(sizeof(WORD)+sizeof(BYTE))), (LWORD)(&g32arPushReclaimQ[0]),
               (c16MaxBlockNum/32)*sizeof(LWORD), cCopyCpu1Dccm2Tsb|cBopWait);
#else
#if _TSB_BiCS4
    bopCopyRam(c32Tsb0SAddr+(u16BufIdx*cSingleSectorByte), (LWORD)(&g32arGlobReadCnt[0]),
               c16MaxBlockNum*sizeof(LWORD), cCopyStcm2Tsb|cBopWait);
#else
    bopCopyRam(c32Tsb0SAddr+(u16BufIdx*cSingleSectorByte), (LWORD)(&g32arGlobReadCnt[0]),
               c16MaxBlockNum*sizeof(LWORD), cCopyTsb2Tsb|cBopWait);
#endif

    bopCopyRam(c32Tsb0SAddr+(u16BufIdx*cSingleSectorByte)+(c16MaxBlockNum*sizeof(LWORD)), (LWORD)(&g32arPushReclaimQ[0]),
               (c16MaxBlockNum/32)*sizeof(LWORD), cCopyCpu1Dccm2Tsb|cBopWait);
#endif/* if _EN_VPC_SWAP */
    u16BufIdx=u16BufIdx+gSectorPerPlaneH-1;
    g16arTsb0[u16BufIdx][0x1FE/2]=c16MaxBlockNum*sizeof(LWORD);
    g16arTsb0[u16BufIdx][0x1FC/2]=(c16MaxBlockNum/32)*sizeof(LWORD);
    // to-do: whole system dump:
    // dump HW regs here for now, start by 64th sectors
    // PCIE, 0xF36= 3894 bytes ~ 4k
    u16BufIdx++;
    copyReg2Tsb32((volatile LWORD *)(&g32arTsb0[u16BufIdx]), &r32Pcie[0], (rcPiceShareReg3/4)+1);

    // Nvme0, 0x237C= 9084 bytes ~ 9k
    u16BufIdx+=8;
    copyReg2Tsb32((volatile LWORD *)(&g32arTsb0[u16BufIdx]), &r32Nvme0[0], (rcCq8BaseAddr1High/4)+1);
    // Nvme1, 0x1120 ~ 0x2494 = 4980 bytes ~ 5K
    u16BufIdx+=18;
    copyReg2Tsb32((volatile LWORD *)(&g32arTsb0[u16BufIdx]), &r32Nvme1[rcNvmeUnexDmaCtrl0/4], ((rcFailCrc/4)-(rcNvmeUnexDmaCtrl0/4))+1);

    // Hmb, 0x0040 ~ 0x1008 = 4040 bytes ~ 4K
    u16BufIdx+=10;
    copyReg2Tsb32((volatile LWORD *)(&g32arTsb0[u16BufIdx]), &r32NvmeHmb[rcConfigHmbDma/4], ((rcHmbDescEntrySize/4)-(rcConfigHmbDma/4))+1);

    // SysCtrl0, 0x19D = 413 bytes ~ 0.5K
    u16BufIdx+=8;
    copyReg2Tsb32((volatile LWORD *)(&g32arTsb0[u16BufIdx]), &r32SysCtrl0[0], (rcSys1Cltr3/4)+1);
    // SysCtrl1, 0x90 = 144 bytes ~ 0.5K
    u16BufIdx+=1;
    copyReg2Tsb32((volatile LWORD *)(&g32arTsb0[u16BufIdx]), &r32SysCtrl1[0], (rcRsaCtrl/4)+1);

    // prog flash
    if(!mChkLogInfoInFL)
    {
        initErasedSysSprBlk(cSysBlockLog, cBit0);
    }

    for(u16PageCnt=0; u16PageCnt<cTelemetryCtlrDataPageCnt; u16PageCnt++)
    {
        tranRsvBlkAddr(garSysBlock[cSysBlockLog], &usTmpAddrInfo);
        usTmpAddrInfo.u16FPage=g16LogBlkFreePagePtr;
        setFLAddrActCh(usTmpAddrInfo.uCh, &usTmpAddrInfo);
        gSectorH=0;
        mSetTabSpr(gpFlashAddrInfo, cBit5);    // gpFlashAddrInfo->uTabSpar=1;

        mSetFRwParam(c16Tsb0SIdx+(u16PageCnt*gSectorPerPlaneH), gSectorPerPlaneH, c16Bit14, cProgData);
        waitCmdFifoDpt(gActiveCh, &usTmpAddrInfo);
        usBlkSprInfo.u16Seed=g16arSeedTable[gpFlashAddrInfo->u16FPage];
        usBlkSprInfo.u16Spr8.us2BYTE.LowByte=cLogBlockID;
        usBlkSprInfo.u16Spr8.us2BYTE.HighByte=gOpTyp;
        usBlkSprInfo.u16Spr7.us2BYTE.LowByte=gTelemetryCtlrGenNum;
        usBlkSprInfo.u16Spr6.u16all=u16PageCnt;
        setSprByte(&usBlkSprInfo, gPlaneAddr);
        waitChCeBz(gActiveCh, gIntlvAddr, 0);

        flashProgPage(mGetWriteBuf, mGetProgSctrCnt, mGetWriteOpt);
        setBzInfo(gOpTyp, gActiveCh, gIntlvAddr);
        gsRwCtrl.usWaitInfo[gActiveCh][gIntlvAddr].uStatusErrStop=0;

        g16LogBlkFreePagePtr++;

        if(g16LogBlkFreePagePtr>=g16PagePerBlock1_SLC)
        {
            mSetCacheInfoFlag(cLogInfoBlockFull);
            break;
        }
    }

    waitAllChCeBz();
    mSetLogInfoInFL;
}    /* saveWdtDebugInfo */

void setBasicPointCore1()
{
    // Flash CTRL
    regFSHA=(void *)rFSHA;    // Align Rom code
    reg16FSHA=(void *)rFSHA;    // Align Rom code
    reg32FSHA=(void *)rFSHA;    // Align Rom code
    rFLCtrl=(void *)rFSHA;
    r16FLCtrl=(void *)rFSHA;
    r32FLCtrl=(void *)rFSHA;

    regLdpcDsp=(void *)rLdpcDspCtrl;
    reg16LdpcDsp=(void *)rLdpcDspCtrl;
    reg32LdpcDsp=(void *)rLdpcDspCtrl;
    rLdpcDsp=(void *)rLdpcDspCtrl;    // 0x51200000
    r16LdpcDsp=(void *)rLdpcDspCtrl;
    r32LdpcDsp=(void *)rLdpcDspCtrl;
}    /* setBasicPoint */

void initBufWrap()
{
    // rmPcieNvmeDis;    //MIKEY DISABLE for FAKE

    // g16WriteTrigUnitCnt=(1024>>cSectorPerUnit2N);    // 512KB/512=1K sector; 1K/8=128 4K

    rmResetBufFlg;    // (J)reset TSB0
    rmResetOccupyFlg;
    rmEnTsb0HandShake;    // to control sata and flash bufferhandshake
    rmEnTsb1HandShake;
    rmEnTsb2HandShake;    // to control sata and flash bufferhandshake
    rmEnTsb3HandShake;
    rmTsbInterLeave512B;
    rmSeqMskNseqEn;

    // M_DisTSB0HandShake;     //Disable buffer flag and occupy flag of TSB0
    // M_DisTSB1HandShake;     //Disable buffer flag and occupy flag of TSB1
    // M_DisTSB2HandShake;     //Disable buffer flag and occupy flag of TSB0
    // M_DisTSB3HandShake;     //Disable buffer flag and occupy flag of TSB1
    rmDisMultiCr;    // Allen fix bop hang bug//HW will pre send packet // ask Yuming
    rmEnTsbGroupMod;    // Enable TSB group mode
    // Group1 = (PCIEW,PCIER,HDMA),
    // Group2 = (8 Flash CH),
    // Group3 = (CPU0W, CPU1W, CS0,CPU0R,CPU1R, IIC,BOP)

    // ========TSB=====
    // (1) Flash Controller && BOP Controller  && HDMA Controller && ECC
    rmSysDisFakeClkGate;

    setSelMulFL(1);

    rmSetAhciTsbWrapSaddr0(cTsb0StartBufIdx);    // TSB(1), Unit: Sector
    rmSetAhciTsbWrapDaddr0(cTsb0StartBufIdx+cTsb0Size-1);
    rmSetDmaTsbHead0(cTsb0StartBufIdx);
    rmSetDmaTsbTail0(cTsb0StartBufIdx+cTsb0Size-1);
    rmSetHdmaTsbHead0(cTsb0StartBufIdx);
    rmSetHdmaTsbTail0((cTsb0StartBufIdx+cTsb0Size-1));
    rmSetFlashTsbHead0(cTsb0StartBufIdx);
    rmSetFlashTsbTail0((cTsb0StartBufIdx+cTsb0Size-1));
    rmSetEccTsbHead0(cTsb0StartBufIdx);
    rmSetEccTsbTail0(cTsb0StartBufIdx+cTsb0Size-1);

    rmSetAhciTsbWrapSaddr1(cTsb1StartBufIdx);    // TSB(2), Unit: Sector
    rmSetAhciTsbWrapDaddr1(cTsb1StartBufIdx+cTsb1Size-1);
    rmSetDmaTsbHead1(cTsb1StartBufIdx);
    rmSetDmaTsbTail1(cTsb1StartBufIdx+cTsb1Size-1);
    rmSetHdmaTsbHead1(cTsb1StartBufIdx);
    rmSetHdmaTsbTail1(cTsb1StartBufIdx+cTsb1Size-1);
    rmSetFlashTsbHead1(cTsb1StartBufIdx);
    rmSetFlashTsbTail1((cTsb1StartBufIdx+cTsb1Size-1));
    rmSetEccTsbHead1(cTsb1StartBufIdx);
    rmSetEccTsbTail1(cTsb1StartBufIdx+cTsb1Size-1);

    // rmSetAhciTsbWrapSaddr2(cTsb2StartBufIdx);    // TSB(3), Unit: Sector
    // rmSetAhciTsbWrapDaddr2(cTsb2StartBufIdx+cTsb2Size-1);
    // rmSetDmaTsbHead2(cTsb2StartBufIdx);
    // rmSetDmaTsbTail2(cTsb2StartBufIdx+cTsb2Size-1);
    // rmSetHdmaTsbHead2(cTsb2StartBufIdx);
    // rmSetHdmaTsbTail2(cTsb2StartBufIdx+cTsb2Size-1);
    // rmSetFlashTsbHead2(cTsb2StartBufIdx);
    // rmSetFlashTsbTail2((cTsb2StartBufIdx+cTsb2Size-1));
    // rmSetEccTsbHead2(cTsb2StartBufIdx);
    // rmSetEccTsbTail2(cTsb2StartBufIdx+cTsb2Size-1);

    rmSetAhciTsbWrapSaddr2(0x0800);    // TSB(3), Unit: Sector
    rmSetAhciTsbWrapDaddr2(0x080F);
    rmSetDmaTsbHead2(0x0800);
    rmSetDmaTsbTail2(0x080F);
    rmSetHdmaTsbHead2(0x0800);
    rmSetHdmaTsbTail2(0x080F);
    rmSetFlashTsbHead2(0x0800);
    rmSetFlashTsbTail2(0x080F);
    rmSetEccTsbHead2(0x0800);
    rmSetEccTsbTail2(0x080F);

    setSelMulFL(0);

    rmSysEnFakeClkGate;
}    /* initBufWrap */

void TestModeCommand(BYTE uLun, BYTE uAddr, BYTE uP0)
{
    rmCle(0xF1);
    rmCle(0x56);
    rmAle(uAddr);
    rmCmdMaskCleAleEnable;
    rmCle(uP0);
    rmCmdMaskCleAleDisable;
}

void getNandVersion(BYTE uCh, BYTE uCe)
{
    gNandVersion=0;
#if _ENABLE_RETRY_TSB_BiCS4_256Gb
    setFLActCh(uCh);

    while(rmChkCmdFifoBz)
        ;

    rmCeOn(uCe);
    rmCle(0x5C);
    rmCle(0xC5);

    TestModeCommand(0, 0, 1);

    while(rmChkCmdFifoBz)
        ;

    TestModeCommand(0, 1, 6);

    rmCle(0x00);
    rmAle(0xDD);

    rmCle(0x5F);
    rmNop(cTwhr);

    while(rmChkCmdFifoBz)
        ;

    sysDelay(0xFFFF);
    rmManRd(2);

    while(rmChkCmdFifoBz)
        ;

    gNandVersion=rFLCtrl[rcRd0]&1;
    NLOG(cLogCore1, MAINCORE1_C, 1, "getNandVersion: %04d ", gNandVersion);

    TestModeCommand(0, 1, 0);
    TestModeCommand(0, 0, 0);
    rmCle(0xFF);

    while(rmChkCmdFifoBz)
        ;

    sysDelay(0xFFFF);    // min 3ms reset time for CPU 350Mhz
    rmNop(0x80);

    rmCle(0x70);
    rmStsFailMask(0x00);
    rmRdStatus(0x60);

    while(rmChkCmdFifoBz)
        ;
    rmCeOff(uCe);
#endif/* if _ENABLE_RETRY_TSB_BiCS4_256Gb */
}    /* getNandVersion */

void initNandFlash()
{
    if(!rmChkInDevSlp)
    {
#if (OEM==SAMSUNG)
#if 0
        BYTE uCh;
        BYTE *upIntrfaceSetPtr=&gCh0FshODTAndDrv;

        if((gChMap==0x0F)&&(gCeMap==0x1))    // 128GB
        {
            for(uCh=0; uCh<gTotalChNum; uCh++)
            {
                upIntrfaceSetPtr[uCh*4+0x00]=4;
                upIntrfaceSetPtr[uCh*4+0x01]=0x44;
                upIntrfaceSetPtr[uCh*4+0x02]=0x44;
                upIntrfaceSetPtr[uCh*4+0x03]=0;
            }

            NLOG(cLogCore1, MAINCORE1_C, 0, "Capacity 128GB");
        }
        else    // 256GB
        {
            if(g16TotalFBlock==0x3DE)
            {
                for(uCh=0; uCh<gTotalChNum; uCh++)
                {
                    upIntrfaceSetPtr[uCh*4+0x00]=4;
                    upIntrfaceSetPtr[uCh*4+0x01]=0x66;
                    upIntrfaceSetPtr[uCh*4+0x02]=0x66;
                    upIntrfaceSetPtr[uCh*4+0x03]=0;
                }

                NLOG(cLogCore1, MAINCORE1_C, 0, "Capacity 256GB");
            }
            else    // 512
            {
                for(uCh=0; uCh<gTotalChNum; uCh++)
                {
                    upIntrfaceSetPtr[uCh*4+0x00]=4;
                    upIntrfaceSetPtr[uCh*4+0x01]=0xCC;
                    upIntrfaceSetPtr[uCh*4+0x02]=0xCC;
                    upIntrfaceSetPtr[uCh*4+0x03]=0;
                }

                NLOG(cLogCore1, MAINCORE1_C, 0, "Capacity 512GB");
            }
        }
#endif /* if 0 */
        // g16FlashClock=0x125;
#endif /* if (OEM==SAMSUNG) */
        // readFlashId((BYTE *)(&garTsb0[0][0x30]));
#if (_TSB_BiCS3||_TSB_BiCS4)
        // setFlashFeature(0x10, 0x06, 0x00, 0x00, 0x00, cForceWait);    // Driver strength setting
        setFlashDriverStrength(0x10, cForceWait);
        setFlashToggleSpecific(0x02, cNoWait);
        waitAllFlashReady();
        setFlashFeatureForInterface(g16FlashClock, 0x00, 0x00, 0x00, 0x00);    // Change to DDR Mode
#endif
#if (_SANDISK_3D_GEN2|_SANDISK_3D_GEN3)
        // setFlashFeature(0x10, 0x06, 0x00, 0x00, 0x00, cForceWait);    // Driver strength setting
        setFlashDriverStrength(0x10, cForceWait);
        // SANDIXK_3D_GEN2 not support ODT!!
        // setFlashFeature(0x02, 0x07, 0x00, 0x00, 0x00, cNoWait);    // Toggle 2.0 specific setting
        setFlashToggleSpecific(0x02, cNoWait);
        waitAllFlashReady();
        setFlashFeatureForInterface(g16FlashClock, 0x00, 0x00, 0x00, 0x00);    // Change to DDR Mode
#endif
        ctrlScrbBothAndEcc(0x01, 0x01);
    }

#if 0    // Flash Thermal test
    {
        volatile BYTE uStop=1;

        g16FlashClkForThermal=200;
        NLOG(cLogCore1, MAINCORE1_C, 1, "------Test_ChangeFlashClk: 0x%04X  ", g16FlashClkForThermal);
        changeFlashClockForThermal();

        uStop=1;

        while(uStop)
            ;

        g16FlashClkForThermal=160;
        NLOG(cLogCore1, MAINCORE1_C, 1, "------Test_ChangeFlashClk: 0x%04X  ", g16FlashClkForThermal);
        changeFlashClockForThermal();

        g16FlashClkForThermal=66;
        NLOG(cLogCore1, MAINCORE1_C, 1, "------Test_ChangeFlashClk: 0x%04X  ", g16FlashClkForThermal);
        changeFlashClockForThermal();

        g16FlashClkForThermal=266;
        NLOG(cLogCore1, MAINCORE1_C, 1, "------Test_ChangeFlashClk: 0x%04X  ", g16FlashClkForThermal);
        changeFlashClockForThermal();

        g16FlashClkForThermal=38;
        NLOG(cLogCore1, MAINCORE1_C, 1, "------Test_ChangeFlashClk: 0x%04X  ", g16FlashClkForThermal);
        changeFlashClockForThermal();
        // setSysPllClock(250);
        // NLOG(cLogCore1, MAINCORE1_C, 0, "------setSysPllClock(250)");
        g16FlashClkForThermal=266;
        NLOG(cLogCore1, MAINCORE1_C, 1, "------Test_ChangeFlashClk: 0x%04X  ", g16FlashClkForThermal);

        if(rmChkDdrEn)
        {
            while(1)
                ;
        }

        changeFlashClockForThermal();
    }
#endif/* if 0 */
//
    gpFlashAddrInfo=(ADDRINFO *)&gsFlashAddrInfoTemp;
    gErrInjectFlag=0x00;
    gVuCmdSpFlag=0x00;
    initTrackingPara();
    initRetryTablePassIndex();
    getNandVersion(0, 0);
}    /* initNandFlash */

void initNandBusAndAleReg()
{
    if(!rmChkInDevSlp)
    {
        if(rmGpioP06SelToggle)
        {
            setBusToggleMode();
        }
        else
        {
            setBusEdoMode();
        }
    }

    setAleRegister();

    rmSysDisF0DataPd;
    rmSysDisF1DataPd;
    rmSysDisF2DataPd;
    rmSysDisF3DataPd;
    rmSysEnF0DataPu;
    rmSysEnF1DataPu;
    rmSysEnF2DataPu;
    rmSysEnF3DataPu;

    if(!rmChkInDevSlp)
    {
        resetFlash();
    }

    rmSysDisF0DqsPd;
    rmSysDisF1DqsPd;
    rmSysDisF2DqsPd;
    rmSysDisF3DqsPd;
    rmSysEnF0DqsPu;
    rmSysEnF1DqsPu;
    rmSysEnF2DqsPu;
    rmSysEnF3DqsPu;
}    /* initNandBusAndAleReg */

void initNandCtrlReg()
{
    LWORD u32FlashIOSetting=0x10331033;    // For 4ch4way TH58TEG8DDJTA20 , 3 was  not acceptable
    BYTE uCh;

    setBasicPointCore1();
    g32DieAddrBitMask=cb32BitNumTab[gDieBitCnt];
    g32CeAddrBitMask=cb32BitNumTab[gCeBitCnt];
    g32ChAddrBitMask=cb32BitNumTab[gChBitCnt];
    g32PlaneAddrBitMask=cb32BitNumTab[gPlaneBitCnt];
    g32PhyPageAddrMask=cb32BitNumTab[32-gPhyPageAddrBitShiftCnt];

    if(!rmChkInDevSlp)
    {
        // if (rmGpioP02CEDeMuxEn)
        {
            u32FlashIOSetting=0x10781078;    // Temp use du/dd=7/7
        }

        for(uCh=0; uCh<cMaxChNum*2; uCh++)
        {
            r32SysCtrl0[(rcCtrlIoCh0/4)+uCh]=u32FlashIOSetting;    // setting IOs driving strength
        }

        // init system controller
        rmSysDisFwp;
        rmSysEnFceOe;    // flash chip enable pin output enable control.

        if(gFormFactor==cEV_Board)
        {
            rmSetVrefDiv2(0xAA);    // EVB
        }
        else
        {
            rmSetVrefDiv2(0x00);
        }

        for(uCh=0; uCh<cMaxChNum; uCh++)
        {
            rSysCtrl0[rcF0DqsCtrl0+uCh*4]|=cBit0;
        }

        // Change to CH8
        setSelMulFL(1);

        rmChSoftReset;    // soft reset flash controller

        while(rmChkSysCmdFifoBz)
            ;

        rmDisStsFailStop;
        rmEnPollStsToggle;
        rmSetTwhr2(0x0E);    // rmSetTwhr2(0x0A);
        rmSetTpre(0x0D);

        // 2260 always use 2K
        rmSetDmaLen2K;

        rmAleDriveDQSEn;
        rmAleDriveDqsHigh;
        rmEnBusEDOMo;
        rmSpareLen26BS;
        rmEnACle2Cycle;
        rmEnAleCleDoubleCycle;
        rmEnEccEngine;
        rmEnAutoPlane;
        rmResetEccSts;
        // controller interrupt enable
        rmEnContrllerInt;
        rmEnTimeOutInt;
        rmEnCmdInt;
        rmEnAleOverInt;
        rmEnCmdFifoFullInt;

        rmCmdRwSelNormalSource;
        rmSelSprGroup(0);    // cpu access which spare group
        rmSetMiscReg(0x0000);
        rmSetErrInjectPattern(0x0000);

        while(rmChkSysCmdFifoBz)
            ;

        rmEnPlaneRetry;
        rmDisSeedInc;
        rmEnScrbData;
        rmEnSprSeed;
        rmEnScrbSpare;
        rmMultiCeQueDis;
        rmDisReadRetry;
        setCeQueAddr();
        rmEnCmdFifoFullInt;
        rmDisLdpcFastDone;
        // add set tranAdj here
        rmSetDllAdjVal(0xAA);    // rmSetDllAdjVal(0xBC);//rmSetDllAdjVal(0x0C);

        // Change to CH0
        setSelMulFL(0);

        sysDelay(16);
        rmSysSetDllRst;    // Alert reset signal
        sysDelay(16);
        rmSysClrDllRst;    // Clear reset signal

        while(!rmChkSysDllLock)
            ;
    }
    else    // PS4 resume
    {
        if(gFormFactor==cEV_Board)
        {
            rmSetVrefDiv2(0xAA);    // EVB
        }
        else
        {
            rmSetVrefDiv2(0x00);
        }

        for(uCh=0; uCh<cMaxChNum; uCh++)
        {
            rSysCtrl0[rcF0DqsCtrl0+uCh*4]|=cBit0;
        }

        // Change to CH8
        setSelMulFL(1);

        rmChSoftReset;    // soft reset flash controller

        while(rmChkSysCmdFifoBz)
            ;

        rmDisStsFailStop;
        rmEnPollStsToggle;

        rmAleDriveDQSEn;
        rmAleDriveDqsHigh;
        rmEnACle2Cycle;
        rmEnAleCleDoubleCycle;
        rmEnEccEngine;
        rmEnAutoPlane;
        rmResetEccSts;
        // controller interrupt enable
        rmEnContrllerInt;
        rmEnTimeOutInt;
        rmEnCmdInt;
        rmEnAleOverInt;
        rmEnCmdFifoFullInt;

        rmCmdRwSelNormalSource;
        rmSelSprGroup(0);    // cpu access which spare group
        rmSetMiscReg(0x0000);
        rmSetErrInjectPattern(0x0000);

        while(rmChkSysCmdFifoBz)
            ;

        rmEnPlaneRetry;
        rmDisSeedInc;
        rmEnScrbData;
        rmEnSprSeed;
        rmEnScrbSpare;
        rmMultiCeQueDis;
        rmDisReadRetry;
        setCeQueAddr();
        rmEnCmdFifoFullInt;
        rmDisLdpcFastDone;
        // add set tranAdj here

        // Change to CH0
        setSelMulFL(0);
    }

    for(uCh=0; uCh<gTotalChNum; uCh++)
    {
        rmSetLdpcChannel(garChMapTable[uCh]);
        rmSetSoftType(0);    // Hynix V3 use SMI mode
        rmSetForceUpdatellr;    // Force update llr for each channel, still has this hw bug in SM2260
    }

    rmLdpcEnLowPower;
    rmLdpcSetBFupperbound(360);    // 90 bit, enter high power mode

#if _EN_PROGFAILLOG
    setSelMulFL(1);
    rmEnStsFailStop;
    setSelMulFL(0);
#endif
}    /* initNandCtrlReg */

void tempSetFlashCmd()
{
    garFLCmdSetTab2[cPageRead1]=0x00;
    garFLCmdSetTab2[cPageRead2]=0x30;
    garFLCmdSetTab2[cPageProg1]=0x80;
    garFLCmdSetTab2[cPageProg2]=0x10;
    garFLCmdSetTab2[cBlockErase1]=0x60;
    garFLCmdSetTab2[cBlockErase2]=0xD0;
    garFLCmdSetTab2[cReset]=0xFF;
    garFLCmdSetTab2[cSetFeature]=0xEF;
    garFLCmdSetTab2[cSetDieFeature]=0xEF;
}

#if S_SpeedUPSLCProg

void AIPRSet(BYTE uALE, BYTE uData)
{
    rmCle(0x55);
    rmAle(uALE);

    if(rmChkToggleMo||rmChkOnfi2Mo)
    {
        rFLCtrl[rcRd0]=uData;
        rFLCtrl[rcRd1]=uData;
        rmManWr(2);
    }
    else
    {
        rFLCtrl[rcRd0]=uData;
        rmManWr(1);
    }
}

void Overload_AIPR_Disable()
{
    BYTE u8Ch, u8CE;

    for(u8CE=0; u8CE<gTotalCeNum; u8CE++)
    {
        for(u8Ch=0; u8Ch<gTotalChNum; u8Ch++)
        {
            setFLActCh(u8Ch);    // ch
            rmCeOn(u8CE);

            rmCle(0xD5);
            rmAle(0);    // LUN
            rmAle(0x91);

            writeFourData(0, 0, 0, 0);
        }
    }

    sysDelay(150);    // tADL

    // (2)===============Parameter Overload Set===============================
    for(u8CE=0; u8CE<gTotalCeNum; u8CE++)
    {
        for(u8Ch=0; u8Ch<gTotalChNum; u8Ch++)
        {
            setFLActCh(u8Ch);    // ch
            rmCeOn(u8CE);
            rmCle(0xF1);
            rmCle(0x98);
            // F_WE_Byte(0x79, !gbToggleMode);
            // while(M_ChkEmptyBusy)

            rmAle(0x79);    // setA CS0: 79h, CS1: ABh
        }
    }

    sysDelay(0xE3A6);    // tADL
    sysDelay(0xE3A6);
    sysDelay(0xE3A6);
    sysDelay(0xE3A6);
    sysDelay(0xE3A6);

    for(u8CE=0; u8CE<gTotalCeNum; u8CE++)
    {
        for(u8Ch=0; u8Ch<gTotalChNum; u8Ch++)
        {
            setFLActCh(u8Ch);    // ch
            rmCeOn(u8CE);
            rmCle(0x72);
            rmStsFailMask(0x08);
            rmRdStatus(0x60);

            mWaitCmdFifoBz;
            // rmCle(0x00);
            rmManRd(2);

            mWaitCmdFifoBz;
            // rmUartTxLword(0xaa000d0a|rFLCtrl[rcRd0]<<16);
            // NLOG(cLogCore1, AGINGFLASHCMD_C, 4, "u8Ch%04d, u8CE%04d, AIPRstatus: 0x%04x 0x%04x", u8Ch, u8CE, rFLCtrl[rcRd0], rFLCtrl[rcRd1]);
            sysDelay(0xE3A6);    // 200us

            rmCle(0x76);
            rmManRd(2);
            mWaitCmdFifoBz;
            // u8PARA=rFLCtrl[rcRd0];
            // NLOG(cLogCore1, AGINGFLASHCMD_C, 3, "u8Ch%04d, u8CE%04d, u8PARA: 0x%04x", u8Ch, u8CE, u8PARA);
        }
    }

    // (3)===============5C-C5 Fn-56-00-01===============================

    for(u8CE=0; u8CE<gTotalCeNum; u8CE++)
    {
        for(u8Ch=0; u8Ch<gTotalChNum; u8Ch++)
        {
            setFLActCh(u8Ch);    // ch
            rmCeOn(u8CE);
            rmCle(0x5C);
            rmCle(0xC5);
            AIPRSet(0x00, 0x01);

            AIPRSet(0xA6, 0x05);
            AIPRSet(0xD6, 0x46);
            AIPRSet(0xFF, 0x01);
            AIPRSet(0x10, 0x2A);
            AIPRSet(0xFF, 0x00);

            AIPRSet(0x01, 0x00);
            AIPRSet(0x00, 0x00);

            rmCle(0xFF);
            mWaitCmdFifoBz;
        }
    }

    for(u8CE=0; u8CE<gTotalCeNum; u8CE++)
    {
        for(u8Ch=0; u8Ch<gTotalChNum; u8Ch++)
        {
            setFLActCh(u8Ch);    // ch
            rmCeOn(u8CE);
            rmCle(0x70);
            rmStsFailMask(0x00);
            rmRdStatus(0x60);
            mWaitCmdFifoBz;
        }
    }
}    /* Overload_AIPR_Disable */

void ReturnNormal()
{
    BYTE u8Ch, u8CE;

    for(u8CE=0; u8CE<gTotalCeNum; u8CE++)
    {
        for(u8Ch=0; u8Ch<gTotalChNum; u8Ch++)
        {
            setFLActCh(u8Ch);    // ch
            rmCeOn(u8CE);
            rmCle(0xF1);
            // rmNop2(0x80);
            // rmCle(0x89);
            // rmNop2(0x80);
            rmCle(0xFD);
            mWaitCmdFifoBz;
        }
    }

    // setFlashClock(66);
    setBusToggleMode();
    rmDfDdrSet(0x00);
    rmDdrDis;

    sysDelay(0x1E3A6);    // tADL
    sysDelay(0x1E3A6);
    sysDelay(0xE3A6);
    sysDelay(0xE3A6);
    sysDelay(0xE3A6);
    // sysDelay(0x20FFFF);    // min 3ms reset time for CPU 350Mhz

    waitAllFlashReady();

    // initNandBusAndAleReg();
    initNandFlash();
}    /* ReturnNormal */

#endif/* if S_SpeedUPSLCProg */
void funcTskPopBlk(BYTE uTskTail)
{
    gsTskFifoCtrl.u16PopFBlk=popSpareBlock(gsTskFifoCtrl.uarTskFifo[uTskTail].uTskOpt);
}

void funcTskPushBlk(BYTE uTskTail)
{
    pushSpareBlock(gsTskFifoCtrl.u16PushFBlk, gsTskFifoCtrl.uarTskFifo[uTskTail].uTskOpt);
    gsTskFifoCtrl.u16PushFBlk=c16FBlockInitValue;
}

void funcTskWaitAllBz(BYTE uTskTail)
{
    waitAllChCeBz();
}

void funcTskChkEsSts(BYTE uTskTail)
{
    _nop();    // while (1);
}

void funcTskProgWpro(BYTE uTskTail)
{
    progWproPage(gsTskFifoCtrl.uarTskFifo[uTskTail].uTskOpt, gsTskFifoCtrl.uarTskFifo[uTskTail].u16TskSBufPtr);
}

void funcTskReadWpro(BYTE uTskTail)
{
    BYTE uCh, uLdpcPipeFlag;

    uLdpcPipeFlag=0;

    if(gEnableLdpcPipe)
    {
        while(g16LdpcDmaIdCnt)
        {
            chkLdpcResult(cLdpcNormalErr);
        }

        for(uCh=0; uCh<gTotalChNum; uCh++)
        {
            setFLActCh(uCh);
            rmEnWaitDMADone;
            rmDisDmaPipe;
        }

        gEnableLdpcPipe=0;
        uLdpcPipeFlag=1;
    }

    readWproPage(gsTskFifoCtrl.uarTskFifo[uTskTail].uTskOpt,
                 gsTskFifoCtrl.uarTskFifo[uTskTail].u16TskSBufPtr,
                 gsTskFifoCtrl.uarTskFifo[uTskTail].uTskPgOfst);

    if(uLdpcPipeFlag)
    {
        for(uCh=0; uCh<gTotalChNum; uCh++)
        {
            setFLActCh(uCh);
            rmDisWaitDMADone;
            rmEnDmaPipe;
        }

        gEnableLdpcPipe=1;

        while(g16LdpcDmaIdCnt)
            ;// for Debug
    }
}    /* funcTskReadWpro */

void funcTskProgH2f(BYTE uTskTail)
{
    progH2fTable(gsTskFifoCtrl.usProgH2fPara.u16SbufPtr,
                 gsTskFifoCtrl.usProgH2fPara.u16Hblock,
                 gsTskFifoCtrl.usProgH2fPara.u16RwOpt,
                 gsTskFifoCtrl.usProgH2fPara.u16Caller,
                 gsTskFifoCtrl.usProgH2fPara.uSpecialOpt);
    gsTskFifoCtrl.usProgH2fPara.u16Hblock=0xFFFF;
}

void funcTskWaitProgH2fTxData(BYTE uTskTail)
{
    if(mChkDummyWrite){return;}

#if _EN_PROGFAILLOG
    while((rmChkSysCmdFifoBz&gsTskFifoCtrl.usProgH2fPara.uWaitChBitMap)||rmChkSysStsErr)
    {
        chkAllChStatusFail(cNull);
    }

    gsProgFailInfo.uProgH2fCnt=0;
#else
    while(rmChkSysCmdFifoBz&gsTskFifoCtrl.usProgH2fPara.uWaitChBitMap)
        ;
#endif

    gsTskFifoCtrl.usProgH2fPara.uWaitChBitMap=0;
}    /* funcTskWaitProgH2fTxData */

void funcTskMarkBad(BYTE uTskTail)
{
    loadIspCode(cErrHdlIsp1, 1);
    mCallFuncPtrCore1(cmarkBadBlock);    // markBadBlock();    // need to chk!!!!
    loadIspCode(cRwIsp1, 1);
}

void funcTskSwapCore0(BYTE uTskTail)
{
    loadIspCode(gsTskFifoCtrl.uarTskFifo[uTskTail].uTskOpt, gsTskFifoCtrl.uarTskFifo[uTskTail].uTskPgOfst);
}

void funcTskInvalidateCore1DCache(BYTE uTskTail)
{
    invalidateDCache();
}

void funcTskCore1SetGlobEraseCnt(BYTE uTskTail)
{
#if _EN_VPC_SWAP
    bopCopyRam((LWORD)&g16arGlobEraseCnt, (LWORD)&g16arTempGlobEraseCnt, c16MaxBlockNum*2, cCopyTsb2Stcm|cBopWait);
#else
    bopCopyRam((LWORD)&g16arGlobEraseCnt, (LWORD)&g16arTempGlobEraseCnt, c16MaxBlockNum*2, cCopyTsb2Cpu1Dccm|cBopWait);
#endif
    bopCopyRam((LWORD)&g32arPopBit, (LWORD)&g32arPopDeniedFlag, (c16MaxBlockNum/8), cCopyTsb2Tsb|cBopWait);
}

void funcTskSetSlcEndurPara(BYTE uTskTail)
{
    setSlcEndurPara();
}    /* funcTskSetSlcEndurPara */

void funcTskFlashWriteCmd(BYTE uTskTail)
{
    flashWriteCmd(gsTskFifoCtrl.u16FBlk);
    gsTskFifoCtrl.u16FBlk=c16BitFF;
}    /* funcTskSetSlcEndurPara */

void funcTskCore0GetGlobEraseCnt(BYTE uTskTail)
{
#if _EN_VPC_SWAP
    bopCopyRam((LWORD)&g16arTempGlobEraseCnt, (LWORD)&g16arGlobEraseCnt, c16MaxBlockNum*2, cCopyStcm2Tsb|cBopWait);
#else
    bopCopyRam((LWORD)&g16arTempGlobEraseCnt, (LWORD)&g16arGlobEraseCnt, c16MaxBlockNum*2, cCopyCpu1Dccm2Tsb|cBopWait);
#endif
    bopCopyRam((LWORD)&g32arPopDeniedFlag, (LWORD)&g32arPopBit, (c16MaxBlockNum/8), cCopyTsb2Tsb|cBopWait);
}

void funcTskCore0GetDiffType2Offset(BYTE uTskTail)
{
    bopCopyRam((LWORD)&g16arTempDiffType2Offset, (LWORD)g16arDiffType2Offset, cMaxDiffType2Num*2, cCopyCpu1Dccm2Tsb|cBopWait);
}

void funcTskSaveIndexBlockCore0(BYTE uTskTail)
{
    saveIndexBlock();
}

void funcTskInitEraseCnt(BYTE uTskTail)    // 20190506_Louis
{
    for(WORD u16Fblock=g16FirstFBlock; u16Fblock<g16TotalFBlock; u16Fblock++)
    {
        if((mGetGlobEraseCnt(u16Fblock)!=c16BitFF)&&(chkDiffType2Ptr(u16Fblock)==0xFF))
        {
            if(chkWproBlk(u16Fblock))
            {
                mSetGlobEraseCnt(u16Fblock, 0);
            }
            else
            {
                mSetGlobEraseCnt(u16Fblock, 1);
            }

            /*
               * NLOG(cLogCore1,
               * MAINCORE1_C,
               * 3,
               * "funcTskInitEraseCnt: Blk=0x%04x, GlobEraseCnt[0x%04x]=0x%04x",
               * u16Fblock,
               * u16Fblock,
               * g16arGlobEraseCnt[u16Fblock]);
               */
        }
    }
} /* funcTskInitEraseCnt */

// void funcTskPrePopBlkErase(BYTE uTskTail)
// {
//    gsTskFifoCtrl.u16PrePopFBlk=prepopBlockErase(gsTskFifoCtrl.uarTskFifo[uTskTail].uTskOpt);
// }

void funcTskPrePopBlkChkStatus(BYTE uTskTail)
{
    gsTskFifoCtrl.u32EraseFail=eraseBlockProc(gsTskFifoCtrl.u16PopFBlk, gsTskFifoCtrl.uarTskFifo[uTskTail].uTskOpt);
}

void funcTskChkPushSpareQ(BYTE uTskTail)
{
    chkPushSpareQ(gsTskFifoCtrl.usProgH2fPara.uSpecialOpt&cInBoot);
}

void funcTskSetDiffType2AddrInfo(BYTE uTskTail)
{
    setDiffType2AddrInfo(gsTskFifoCtrl.uarTskFifo[uTskTail].u16TskSBufPtr);
}

void funcTskRstAllFlash(BYTE uTskTail)
{
    resetFlashForErrHandle();
}

void funcTskRstAllFshInHdPCIeErr(BYTE uTskTail)
{
    resetFlashForErrHandle();
    resetRwCtrlForErrHandle();

    // if(gsTskFifoCtrl.uarTskFifo[uTskTail].uTskOpt==cNvmeCmdRead)
    // {
    //    rmResetBufFlg;    // Random Read pcie error, temp solution
    // }

    // disSysTmr();
}

void funcTskRstCtlVar(BYTE uTskTail)
{
    resetRwCtrlForErrHandle();
}

void funcTskChangeFlashClock(BYTE uTskTail)
{
    changeFlashClockForThermal();
}

void funcTskCore0GetRndSeed(BYTE uTskTail)
{
    WORD u16Seed;

    u16Seed=gsTskFifoCtrl.uarTskFifo[uTskTail].u16TskSBufPtr;
    gsTskFifoCtrl.u16Seed=g16arSeedTable[u16Seed];
}

void funcTskBuildF2h(BYTE uTskTail)
{
    // buildValidCachePage(mGet16GcSrcBlock(cGcHeadSrcBlk), c16GcSrcBlk0F2hSIdx);    // temp for GC src only
    loadIspCode(cErrHdlIsp1, 1);
    mCallFuncPtr5Core1(cbuildValidCachePage, mGet16GcSrcBlock(cGcHeadSrcBlk), c16GcSrcBlk0F2hSIdx);
    loadIspCode(cRwIsp1, 1);
}

void funcTskRemWproPage(BYTE uTskTail)
{
    BYTE uIdx=gsTskFifoCtrl.uarTskFifo[uTskTail].uTskOpt;

    remWproPage(uIdx);
}    /* funcTskRemWproPage */

void funcTskSetGcInfoHmbLink(BYTE uTskTail)
{
    mSetGcInfoHmbLink(gsTskFifoCtrl.uarTskFifo[uTskTail].uTskOpt);
}

void funcTskEnLdpcPipe(BYTE uTskTail)
{
    BYTE uCh;

    g16LdpcDmaIdCnt=0;

    // Wait all Flash Dma IO done. [CC]
    while(gsRwCtrl.uAllOpIdxCntR)
    {
        for(uCh=0; uCh<gTotalChNum; uCh++)
        {
            chkRwOpIdxTail(uCh);
        }
    }

    for(uCh=0; uCh<gTotalChNum; uCh++)
    {
        setFLActCh(uCh);
        rmDisWaitDMADone;
        rmEnDmaPipe;
    }

    gEnableLdpcPipe=1;
    gsRwCtrl.u32LdpcSyncWithCore1=0;
#if _EN_CacheR
#if (!_EN_MutiWayCacheRImprove)
    if(mChkFLOption(cEnCacheRead)&&(gIntlvWay==1))
#endif
    {
        gsRwCtrl.uEnCacheR=1;
    }
#endif
}    /* funcTskEnLdpcPipe */

void funcTskDisLdpcPipe(BYTE uTskTail)
{
    BYTE uCh;

#if _EN_Precmd
    BYTE uIntlvAddr;
#endif

    while(g16LdpcDmaIdCnt)
    {
        chkLdpcResult(cLdpcNormalErr);
    }

    for(uCh=0; uCh<gTotalChNum; uCh++)
    {
        setFLActCh(uCh);
        rmEnWaitDMADone;
        rmDisDmaPipe;
#if _EN_Precmd
        for(uIntlvAddr=0; uIntlvAddr<gIntlvWay; uIntlvAddr++)
        {
            gsRwCtrl.u16LastFBlockR[uCh][uIntlvAddr]=cInvalid16Bit;
            gsRwCtrl.u16LastFPageR[uCh][uIntlvAddr]=cInvalid16Bit;
            gsRwCtrl.uPreFixCmd[uCh][uIntlvAddr]=cInvalid8Bit;

            if(!mChkRaidDecF(cRaidDecodeMode))
            {
                gsRwCtrl.uContiAddrCnt[uCh][uIntlvAddr]=0;
            }
        }
#endif
    }

    gEnableLdpcPipe=0;
    gsRwCtrl.u32LdpcSyncWithCore1=0;
    g16LastRdCntFBlock=cInvalid16Bit;
    g16LastRdCntFPage=cInvalid16Bit;
#if _EN_CacheR
#if (!_EN_MutiWayCacheRImprove)
    if(mChkFLOption(cEnCacheRead)&&(gIntlvWay==1))
#endif
    {
        gsRwCtrl.uEnCacheR=0;
    }
#endif
}    /* funcTskDisLdpcPipe */

void funcTskChkPostWriteRead(BYTE uTskTail)
{
    mCallFuncPtr2Core1(cchkPWRCore1, gsTskFifoCtrl.uarTskFifo[uTskTail].uTskPgOfst);
    // chkPWRCore1(gsTskFifoCtrl.uarTskFifo[uTskTail].uTskPgOfst);
}

void funcTskCore1SetGlobEraseCnt1Blk(BYTE uTskTail)
{
    // bopCopyRam((LWORD)&g16arGlobEraseCnt, (LWORD)&g16arTempGlobEraseCnt, c16MaxBlockNum*2, cCopyTsb2Cpu1Dccm|cBopWait);
    g16arGlobEraseCnt[gsTskFifoCtrl.u16FBlk]=gsTskFifoCtrl.u16EraseCnt;

    if(gsTskFifoCtrl.uarTskFifo[uTskTail].uTskOpt)
    {
        mSetPoppedBit(gsTskFifoCtrl.u16FBlk);
    }
    else
    {
        mClrPoppedBit(gsTskFifoCtrl.u16FBlk);
    }

    gsTskFifoCtrl.u16FBlk=c16BitFF;
    gsTskFifoCtrl.u16EraseCnt=c16BitFF;
    gsTskFifoCtrl.uarTskFifo[uTskTail].uTskOpt=0xFF;
}    /* funcTskCore1SetGlobEraseCnt1Blk */

void funcTskCore1Sleep(BYTE uTskTail)
{
#if _CORE1_SLEEP
#if _ENABLE_NVME_PM
    WORD u16FlashClkBK;

    if((gsTskFifoCtrl.uarTskFifo[uTskTail].uTskOpt==cPs3)&&(!g32Ps3EnPwrDomain1))
    {
#if (_ENABLE_NAND_UART_DEBUG)
        NLOG(cLogCore1, MAINCORE1_C, 0, "********************Core1 _ PS3");
#endif
        loadIspCode(cNvmeIsp1, 1);    // Flash setting recover func at NvmeIsp1 bank.
    }
    else if(gsTskFifoCtrl.uarTskFifo[uTskTail].uTskOpt==cPs4)
    {
        // Backup Seed Table
        // bopCopyRam((LWORD)&g16arBkSeedTable, (LWORD)&g16arSeedTable, c16SeedTableSize*2, cCopyCpu1Iccm2Tsb|cBopWait);
        bopCopyRam((LWORD)c32Tsb2SeedAddr, (LWORD)&g16arSeedTable, c16SeedTableSize*2, cCopyCpu1Iccm2Tsb|cBopWait);
#if (_ENABLE_NAND_UART_DEBUG)
        NLOG(cLogCore1, MAINCORE1_C, 0, "####################Core1 _ PS4");
#endif
        u16FlashClkBK=g16FlashClkForThermal;
        g16FlashClkForThermal=38;
        changeFlashClockForThermal();
    }
#endif/* if _ENABLE_NVME_PM */
    // loadIspCode(cNvmeIsp1, 1);
    __disable_irq();
    g32Core1State=cCore1SleepState;    // 2
    gsTskFifoCtrl.u32TailPtr=(gsTskFifoCtrl.u32TailPtr+1)&cTaskDepMsk;
    _nop();
    _nop();
    // __disable_irq();
    // __DSB();
    // __WFE();		//Go sleep
    // __WFE();		//Clear Flag
    __WFI();
    __enable_irq();
    rmVic0IntClr=cIrqSev;    // clear event
#if _ENABLE_NVME_PM
    if(gsTskFifoCtrl.uarTskFifo[uTskTail].uTskOpt==cPs4)    // PS4 Abort
    {
        g16FlashClkForThermal=u16FlashClkBK;
#if (_ENABLE_NAND_UART_DEBUG)
        NLOG(cLogCore1, MAINCORE1_C, 0, "####################Core1 _ PS4 Abort");
#endif
        changeFlashClockForThermal();
#if _ENABLE_RAID
        initRaidEngineResumePS3();    // init Raid for PS4 Abort
#endif
    }
#endif
    g32Core1State=cCore1BootState_Finished;    // cCore1ReadyState;    // 1
#endif/* if _CORE1_SLEEP */
}    /* funcTskCore1Sleep */

void funcTskCore1ClrLastRGrp(BYTE uTskTail)
{
    BYTE uCh, uIntlvAddr;

    for(uCh=0; uCh<gTotalChNum; uCh++)
    {
        for(uIntlvAddr=0; uIntlvAddr<gIntlvWay; uIntlvAddr++)
        {
            gsRwCtrl.u16LastFBlockR[uCh][uIntlvAddr]=cInvalid16Bit;
            gsRwCtrl.u16LastFPageR[uCh][uIntlvAddr]=cInvalid16Bit;
            gsRwCtrl.uContiAddrCnt[uCh][uIntlvAddr]=0;
#if _EN_Precmd
            gsRwCtrl.uPreFixCmd[uCh][uIntlvAddr]=cInvalid8Bit;
#endif
        }
    }

    g16LastRdCntFBlock=cInvalid16Bit;
    g16LastRdCntFPage=cInvalid16Bit;
}    /* funcTskCore1ClrLastRGrp */

#if _ENABLE_RAID
/*
   * void funcTskSetRaidEncode(BYTE uTskTail)
   * {
   *  setRaidEncode(gsTskFifoCtrl.usRaidEncPara.u16SbufPtr,
   *                gsTskFifoCtrl.usRaidEncPara.u16TotalSctrCnt,
   *                gsTskFifoCtrl.usRaidEncPara.u16FPage,
   *                gsTskFifoCtrl.usRaidEncPara.u16TskOpt,
   *                gsTskFifoCtrl.usRaidEncPara.uRaidOpt,
   *                gsTskFifoCtrl.usRaidEncPara.uPageType);
   * }
   *
   * void funcTskGetRaidParity(BYTE uTskTail)
   * {
   *  getRaidParity(gsTskFifoCtrl.usRaidEncPara.u16SbufPtr,
   *                gsTskFifoCtrl.usRaidEncPara.u16TskOpt,
   *                gsTskFifoCtrl.usRaidEncPara.uRaidOpt,
   *                gsTskFifoCtrl.usRaidEncPara.u16FPage,
   *                gsTskFifoCtrl.usRaidEncPara.uPageType);
   * }
   */
void funcTskProgPartialRaidParity(BYTE uTskTail)
{
    progPartialRaidParity(gsTskFifoCtrl.usRaidEncPara.u16SbufPtr,
                          gsTskFifoCtrl.usRaidEncPara.u16FPage,
                          gsTskFifoCtrl.usRaidEncPara.uRaidOpt,
                          gsTskFifoCtrl.usRaidEncPara.uPageType);
}

void funcTskPushRaidPtyBlk(BYTE uTskTail)
{
    pushRaidPtyBlk(gsTskFifoCtrl.usRaidEncPara.uRaidOpt);
}

void funcTskInitRaidEngine(BYTE uTskTail)
{
    initRaidEngine();
}

void funcTskRstRaidEngVar(BYTE uTskTail)
{
    rstRaidEngVar(gsTskFifoCtrl.usRaidEncPara.uRaidOpt);
}

void funcTskRstRaidPara(BYTE uTskTail)
{
    ADDRINFO *upAddrInfo;
    WORD u16RaidEngPgIdxNextPg, u16RaidEngPgIdxAlnPg, u16RaidEngPgIdx, u16PagePerBank, u16PageInBank, u16FPage, u16TrigPageInBank;
    BYTE uPtyIdx, uIdx, uHdmaCmdFifoCnt, uTempRaidEngIdx, uRaidEngRst;

    if(gsTskFifoCtrl.uarTskFifo[uTskTail].uTskOpt==cRaidParaRst4PcieErr)
    {
        uHdmaCmdFifoCnt=rmGetHdmaCmdFifoCnt;

        if(uHdmaCmdFifoCnt)
        {
            upAddrInfo=&garDesAddrInfo[(gsTskFifoCtrl.uarTskFifo[uTskTail].u16TskSBufPtr&cBitFF)];
            uHdmaCmdFifoCnt=rmGetHdmaCmdFifoCnt;
            u16FPage=upAddrInfo->u16FPage;
            uPtyIdx=(BYTE)(u16FPage&(cRaidParityNum-1));
            u16PagePerBank=g16PagePerBlock1_SLC/gTotalBankOfF2hTab;
            u16PageInBank=u16FPage%u16PagePerBank;
            u16RaidEngPgIdxNextPg=(((u16FPage+cRaidParityNum)%u16PagePerBank)/cRaidParityNum)*cRaidDataKVal;
            u16RaidEngPgIdxAlnPg=(u16PageInBank/cRaidParityNum)*cRaidDataKVal;
            u16RaidEngPgIdx=u16RaidEngPgIdxAlnPg+upAddrInfo->uIntlvAddr*gTotalChPlaneNum+upAddrInfo->uCh*gPlaneNum;

            if(u16RaidEngPgIdx||u16PageInBank)
            {
                upAddrInfo=&garDesAddrInfo[subWrFfPtrBy1(gsTskFifoCtrl.uarTskFifo[uTskTail].u16TskSBufPtr>>8)];
                u16TrigPageInBank=(upAddrInfo->u16FPage)%u16PagePerBank;
                uRaidEngRst=0;

                if((u16TrigPageInBank/cRaidParityNum)==((u16PagePerBank/cRaidParityNum)-1))    // Raid engine may be done in HDMA
                {
                    uRaidEngRst=1;
                }

                for(uIdx=0; uIdx<cRaidParityNum; uIdx++)
                {
                    if(u16TrigPageInBank==u16PageInBank)
                    {
                        uIdx=uPtyIdx;
                    }

                    if(uRaidEngRst&&(gsRaidInfo.uarBkDataRaidEngIdx[uIdx]!=cNull))
                    {
                        gsRaidInfo.uarRaidEngIdx[cRaidDataBlk][uIdx]=gsRaidInfo.uarBkDataRaidEngIdx[uIdx];
                    }

                    uTempRaidEngIdx=gsRaidInfo.uarRaidEngIdx[cRaidDataBlk][uIdx];

                    if(uTempRaidEngIdx!=cNull)
                    {
                        if(uIdx==uPtyIdx)
                        {
                            gsRaidInfo.u16arRaidEngPgIdx[uTempRaidEngIdx]=u16RaidEngPgIdx;
                            gsRaidInfo.u16arRaidFPage[cRaidDataBlk][uTempRaidEngIdx]=u16PageInBank;
                        }
                        else if(uIdx<uPtyIdx)
                        {
                            gsRaidInfo.u16arRaidEngPgIdx[uTempRaidEngIdx]=u16RaidEngPgIdxNextPg;    // 0
                            gsRaidInfo.u16arRaidFPage[cRaidDataBlk][uTempRaidEngIdx]=u16PageInBank+uIdx-uPtyIdx;
                        }
                        else if(uIdx>uPtyIdx)
                        {
                            gsRaidInfo.u16arRaidEngPgIdx[uTempRaidEngIdx]=u16RaidEngPgIdxAlnPg;

                            if(u16PageInBank>=cRaidParityNum)
                            {
                                gsRaidInfo.u16arRaidFPage[cRaidDataBlk][uTempRaidEngIdx]=u16PageInBank+uIdx-uPtyIdx-cRaidParityNum;
                            }
                        }

                        if(gsRaidInfo.u16arRaidEngPgIdx[uTempRaidEngIdx])
                        {
                            if(!mChkRaidEngBmap(uTempRaidEngIdx))
                            {
                                mSetRaidEngBmap(uTempRaidEngIdx);
                                gsRaidInfo.uRaidPopEngCnt++;
                            }
                        }
                        else
                        {
                            if(mChkRaidEngBmap(uTempRaidEngIdx))
                            {
                                mClrRaidEngBmap(uTempRaidEngIdx);
                                gsRaidInfo.uRaidPopEngCnt--;
                            }

                            gsRaidInfo.uarRaidEngIdx[cRaidDataBlk][uIdx]=cNull;
                            gsRaidInfo.u16arRaidFPage[cRaidDataBlk][uIdx]=c16Null;
                        }

                        mClrRaidEngPtyBmap(uTempRaidEngIdx);
                    }

                    if(u16TrigPageInBank==u16PageInBank)
                    {
                        break;
                    }
                }
            }
            else
            {
                rstRaidEngVar(cRaidDataBlk);
            }
        }

        rmHdmaSoftReset;
    }

    gsRwCtrl.u32ProgFifoTrig=gsRwCtrl.u32ProgFifoHead;
}    /* funcTskRstRaidPara */

#endif/* if _ENABLE_RAID */

void funcTskRstUNCSts1Plane(BYTE uTskTail)
{
    mClrBitMask(gPlaneUNCSts[gsTskFifoCtrl.uarTskFifo[uTskTail].uTskOpt], gsTskFifoCtrl.uarTskFifo[uTskTail].uTskPgOfst);
    mClrBitMask(gPlaneOnesCntSts[gsTskFifoCtrl.uarTskFifo[uTskTail].uTskOpt], gsTskFifoCtrl.uarTskFifo[uTskTail].uTskPgOfst);    // TODO
    gReadLinkRetrySlcVth[gsTskFifoCtrl.uarTskFifo[uTskTail].uTskOpt][gsTskFifoCtrl.uarTskFifo[uTskTail].uTskPgOfst]=0;
}

void invPlaneBufFlag(WORD u16BufPtr, BYTE uBufCnt, BYTE uOpt)
{
    LWORD u32BufInvBit=0;

    WORD u16SBufIdx=u16BufPtr&0x1F;
    WORD u16EBufIdx=u16SBufIdx+uBufCnt;

    for(; u16SBufIdx<u16EBufIdx; u16SBufIdx++)
    {
        mSetBitMask(u32BufInvBit, u16SBufIdx&0x1F);
    }

    if(uOpt&cInvBufFlag)
    {
#if _ENABLE_RAID
        rmSetBufRaid32Sts(u16BufPtr>>5, u32BufInvBit);
#else
        rmSetBuf32Sts(u16BufPtr>>5, u32BufInvBit);
#endif
    }

    if(uOpt&cInvOccFlag)
    {
        while(((rm32BufOccStatus(u16BufPtr>>5)&u32BufInvBit)!=u32BufInvBit)&&!mChkHandlePcieErrF) // Jira51
            ;// debug

        rmSetBufOcc32Sts(u16BufPtr>>5, u32BufInvBit);
        clrFwPreOccuFlag(u16BufPtr);
    }
}    /* invPlaneBufFlag */

void funcTskInvPlaneBufFlag(BYTE uTskTail)
{
    invPlaneBufFlag(gsTskFifoCtrl.uarTskFifo[uTskTail].u16TskSBufPtr,
                    gsTskFifoCtrl.uarTskFifo[uTskTail].uTskPgOfst,
                    gsTskFifoCtrl.uarTskFifo[uTskTail].uTskOpt);
}

void funcTskRstUNCSts(BYTE uTskTail)
{
    fillCcmVal((BYTE *)&gPlaneUNCSts, cMaxChNum, 0);
    fillCcmVal((BYTE *)&gPlaneOnesCntSts, cMaxChNum, 0);    // TODO
    fillCcmVal((BYTE *)&gReadLinkRetrySlcVth, sizeof(gReadLinkRetrySlcVth), 0);
}

void funcTskGetGlobEraseCntOfSpecFblock(BYTE uTskTail)
{
    g16OneFblockGlobEraseCnt=(g16arGlobEraseCnt[gsTskFifoCtrl.uarTskFifo[uTskTail].u16TskSBufPtr]);
}

void funcTskSwapWproBlk(BYTE uTskTail)
{
    swapWproBlk();
    waitAllChCeBz();
    saveIndexBlock();
}

void funcTskCore1ResumePs3(BYTE uTskTail)
{
    // For Rex, Resume PS3 to setting Sys&Flash ctrl reg.
    BYTE uPass=0;

    while(gEnableLdpcPipe==1)
        ;

    uPass=mCallFuncPtr4Core1(crecoverFlashReg);
    loadIspCode(cRwIsp1, 1);    // Swap Core1 to RW ISP

    if(uPass==0)
    {
        while(!uPass)
            ;
    }

#if _ENABLE_RAID
    // Init RAID Engine
    initRaidEngineResumePS3();
#endif
}    /* funcTskCore1ResumePs3 */

void funcTskGetDifferAddr(BYTE uTskTail)
{
    gsTskFifoCtrl.u16FBlk=getDiffAddr(gsTskFifoCtrl.u16PopFBlk, gsTskFifoCtrl.u16PushFBlk, gsTskFifoCtrl.u16Seed, gsTskFifoCtrl.u16EraseCnt);
}

void funcTskInsSlcSortQ(BYTE uTskTail)
{
    insSlcSortQ(gsTskFifoCtrl.u16FBlk);
    gsTskFifoCtrl.u16FBlk=c16BitFF;
}

void funcTskGetGcSrcBlk(BYTE uTskTail)
{
    mCallFuncPtrCore1(cgetGcSrcBlk);    // getGcSrcBlk();
}

void funcTskInitSlcQ(BYTE uTskTail)
{
#if _EN_VPC_SWAP
    WORD u16Idx;

    for(u16Idx=0; u16Idx<(c16MaxBlockNum/8); u16Idx++)
    {
        g32DataBlockBitmap[u16Idx]=0x00000000;
    }

    g16GcSLCStartBlk=g16FirstFBlock;
    g16GcTLCStartBlk=g16StaticBound;
    g16DataBlkCnt=0;
    g16SlcSortQCnt=g16DataBlkCnt;

#if _EN_512Gb_Debug
    NLOG(cLogCore1,
         MAINCORE1_C,
         6,
         "funcTskInitSlcQ! SLCSrcBlk=0x%04x, TLCSrcBlk=0x%04x, FirstFBlk=0x%04x, StaticBound=0x%04x, SlcQCnt=0x%04X, FullCacheBlockCnt=0x%04X",
         g16GcSLCStartBlk,
         g16GcTLCStartBlk,
         g16FirstFBlock,
         g16StaticBound,
         g16SlcSortQCnt,
         gsCacheInfo.u16FullCacheBlockCnt);
#endif
#else/* if _EN_VPC_SWAP */
    WORD u16Fblock;

    bopClrRam((LWORD)&g16SlcSortQFBlk, cMaxSlcBlkQ*2, 0xFFFFFFFF, cClrCore1Dccm|cBopWait);
    bopClrRam((LWORD)&gSlcSortQIdx, c16MaxBlockNum, 0xFFFFFFFF, cClrCore1Dccm|cBopWait);

    for(u16Fblock=0; u16Fblock<cMaxSlcBlkQ; u16Fblock++)
    {
        garSlcSortQLink[u16Fblock].uPrev=u16Fblock-1;
        garSlcSortQLink[u16Fblock].uNext=u16Fblock+1;
        garFreeSlcSortQ[u16Fblock]=u16Fblock;
    }

    garSlcSortQLink[cMaxSlcBlkQ-1].uNext=cNull;

    gsSlcSortQList.u16Cnt=0;
    gsSlcSortQList.u16Head=cNull;
    gsSlcSortQList.u16Tail=cNull;
    gsSlcSortQList.u16Trig=cNull;
    g32FreeSlcSortQHead=0;
    g32FreeSlcSortQTail=0;
#endif/* if _EN_VPC_SWAP */
}    /* funcTskInitSlcQ */

void funcTskRetoreSlcQ(BYTE uTskTail)
{
    if(gsTskFifoCtrl.uarTskFifo[uTskTail].uTskOpt==cFromQBoot)
    {
        // from restore QBoot
        bopCopyRam((LWORD)c32SlcQRamAddr, ((LWORD)garTsb0[0])+c32SlcQStAddr, c32SlcQRamSize, cCopyTsb2Cpu1Dccm|cBopWait);
    }
    else
    {
        // from restore CacheInfo
        bopCopyRam((LWORD)c32SlcQRamAddr, (LWORD)(cTsb0Addr+c32ProgCacheInfo_SlcQStAddr), c32SlcQRamSize, cCopyTsb2Cpu1Dccm|cBopWait);
    }

#if _EN_VPC_SWAP
#if _EN_Liteon_ErrHandle    // 20190618_Louis_02
    WORD u16RescanSLCQCnt=0;

    for(WORD u16Blk=0; u16Blk<g16TotalFBlock; u16Blk++)
    {
        if(mChkDataBlockBit(u16Blk))
        {
            u16RescanSLCQCnt++;
        }
    }

    if(g16DataBlkCnt!=u16RescanSLCQCnt)
    {
        NLOG(cLogBuild, MAINCORE1_C, 2, " SlcSortQCnt mismatch! g16DataBlkCnt=0x%04x, u16RescanSLCQCnt=0x%04x ", g16DataBlkCnt,
             u16RescanSLCQCnt);
        g16DataBlkCnt=u16RescanSLCQCnt;
    }
#endif/* if _EN_Liteon_ErrHandle */

    g16SlcSortQCnt=g16DataBlkCnt;

    NLOG(cLogCore1,
         MAINCORE1_C,
         5,
         "funcTskRestoreSlcQ! SLCSrcBlk=0x%04x, TLCSrcBlk=0x%04x, SlcSortQCnt=0x%04x, g16DataBlkCnt=0x%04x, FullCacheBlockCnt=0x%04x",
         g16GcSLCStartBlk,
         g16GcTLCStartBlk,
         g16SlcSortQCnt,
         g16DataBlkCnt,
         gsCacheInfo.u16FullCacheBlockCnt);
#else  /* if _EN_VPC_SWAP */
    g16SlcSortQCnt=gsSlcSortQList.u16Cnt;    // 20181223_Bruce
#endif /* if _EN_VPC_SWAP */
}    /* funcTskRetoreSlcQ */

/*void funcTskResetGCFlag(BYTE uTskTail)
   * {
   *  if(mChkGcQue(cGcTypTLCWearLvl))
   *  {
   *      gsCacheInfo.u16TLCGcWLCnt++;
   *      mClrGcFlag(cGcSrchWearF);
   *  }
   *
   *  if(!gsGcInfo.uGcPrioTlcBlkNumPtr)
   *  {
   *      if(mChkGcQue(cGcTypTLCWearLvl))
   *      {
   *          mPopGcQue(cGcTypTLCWearLvl);
   *      }
   *  }
   *
   *  if(!gsGcInfo.uGcPrioTlcBlkNumPtr&&!gsGcInfo.uGCSLCReclaimPtr)
   *  {
   *      mClrGcFlag(cUnderReclaim);
   *  }
   * }*/    /* funcTskResetGCFlag */

#if _EN_SLCOpenBlkReadScrub
void funcTskPushWLReadReclaimQ(BYTE uTskTail)
{
    mClrPushReClaimQBit(gsTskFifoCtrl.u16FBlk);
    pushWLReadReclaimQ(gsTskFifoCtrl.u16FBlk, cTouchRdCntThr);
}

#endif

void funcTskinitGcProc(BYTE uTskTail)
{
    BYTE uSrcIdx;

    mSetGcState(cGcBuildSrc);
    gsGcInfo.uGcSrcF2hTabBank=0;
    gsGcInfo.uGcDesF2hTabBank=0;
    gsGcInfo.uGcDesF2hTabUpdBank=0;
    gsGcInfo.uGcDesF2hTabBuildBank=0;
    gsGcInfo.u16PwrStrPage=0;
    gsGcInfo.uGcDesF2hTabPWRBank=0;

    while(gsGcInfo.uGcSrcBlkCnt)
        ;

    gsGcInfo.u16GcIncompleteSrchFblk=cInvldFBlk;
    gsGcInfo.u16GcIncompleteSrchHblk=0xFFFF;
    gsGcInfo.u16GcIncompleteSrchHpg=0xFFFF;
    gsGcInfo.uGcIncompleteSrchSrcBlkPtr=0xFF;

    // bopClrRam((LWORD)&g32GcS2tH2fSkpSrcHblkSrch, c16MaxH2fTabNum/8, 0x00000000, cClrTsb|cBopWait);

    gsGcInfo.u16GcPwReadPagePtr=0;
    gsGcInfo.u32GcSrcF4kPtr=0;
    gsGcInfo.u32GcDesF4kPtr=0;
    gsGcInfo.u32GcDesF4kPtr2=0;
    // gsGcInfo.u16GcDesF2hTabFreePtr=g16TotalTlcPgPerF2hTab-1;
    // gsGcInfo.u16SrcHandlePage=gsGcInfo.u16DesHandlePage=0;
    gsGcInfo.u16GcOneShotPtr=0;
    gsGcInfo.uOneShotChPtr=0;
    gsGcInfo.uGcIntlvPtr=0;
    gsGcInfo.uSrcHandlePageType=0;
    gsGcInfo.uLoadGCTabIdx=0;

    gsGcInfo.u16HmbXfrUnit=0;

    for(uSrcIdx=0; uSrcIdx<cMaxGcSrcBlkNum; uSrcIdx++)    // 20190618_Louis_01
    {
        gsGcInfo.u16GcSrcBlock[uSrcIdx]=cInvldFBlk;
    }
}    /* funcTskinitGcProc */

void funcTskgcDesBlkFullSetting(BYTE uTskTail)
{
    BYTE uIdx;
    WORD u16Fblock;
    LWORD u32Sum;

    u32Sum=gsGcInfo.u32GcLastX2TBuildSrcTabTime+gsGcInfo.u32GcLastX2TMoveDataTime+gsGcInfo.u32GcLastX2TPostWRTime+
            gsGcInfo.u32GcLastX2TFlushF2hTabTime;
#if _EN_FW_DEBUG_UART
    NLOG(cLogGC,
         MAINCORE1_C,
         9,
         "Gc flow: 0x%04X, ProcTime: 0x%08X, BuildSrcTabTime: 0x%08X, MoveDataTime: 0x%08X, FlushF2hTabTime: 0x%08X",
         mGetGcFlow,
         u32Sum>>16,
         (WORD)u32Sum,
         gsGcInfo.u32GcLastX2TBuildSrcTabTime>>16,
         (WORD)gsGcInfo.u32GcLastX2TBuildSrcTabTime,
         gsGcInfo.u32GcLastX2TMoveDataTime>>16,
         (WORD)gsGcInfo.u32GcLastX2TMoveDataTime,
         gsGcInfo.u32GcLastX2TFlushF2hTabTime>>16,
         (WORD)gsGcInfo.u32GcLastX2TFlushF2hTabTime);
#endif

    if(mGetGcFlow!=cGcFlowT2T)
    {
        gsGcInfo.u32GcLastS2TProcTime=u32Sum;

        if(u32Sum>gsGcInfo.u32GcMaxS2TProcTime)
        {
            gsGcInfo.u32GcMaxS2TProcTime=u32Sum;
            gsGcInfo.u32GcMaxS2TBuildSrcTabTime=gsGcInfo.u32GcLastX2TBuildSrcTabTime;
            gsGcInfo.u32GcMaxS2TMoveDataTime=gsGcInfo.u32GcLastX2TMoveDataTime;
            gsGcInfo.u32GcMaxS2TPostWRTime=gsGcInfo.u32GcLastX2TPostWRTime;
            gsGcInfo.u32GcMaxS2TFlushF2hTabTime=gsGcInfo.u32GcLastX2TFlushF2hTabTime;
        }
    }
    else
    {
        gsGcInfo.u32GcLastT2TProcTime=u32Sum;

        if(u32Sum>gsGcInfo.u32GcMaxT2TProcTime)
        {
            gsGcInfo.u32GcMaxT2TProcTime=u32Sum;
            gsGcInfo.u32GcMaxT2TBuildSrcTabTime=gsGcInfo.u32GcLastX2TBuildSrcTabTime;
            gsGcInfo.u32GcMaxT2TMoveDataTime=gsGcInfo.u32GcLastX2TMoveDataTime;
            gsGcInfo.u32GcMaxT2TPostWRTime=gsGcInfo.u32GcLastX2TPostWRTime;
            gsGcInfo.u32GcMaxT2TFlushF2hTabTime=gsGcInfo.u32GcLastX2TFlushF2hTabTime;
        }
    }

    gsGcInfo.u32GcLastX2TBuildSrcTabTime=0;
    gsGcInfo.u32GcLastX2TMoveDataTime=0;
    gsGcInfo.u32GcLastX2TPostWRTime=0;
    gsGcInfo.u32GcLastX2TFlushF2hTabTime=0;

    mSetGcFlag(cGcDesFull);

    if(gsGcInfo.u16GcDesBlock!=c16FBlockInitValue)
    {
#if _EN_VPC_SWAP
        if(mChkVPCntValid(gsGcInfo.u16GcDesBlock))
#else
        if(mGetCacheBlkVpCnt(gsGcInfo.u16GcDesBlock))
#endif
        {
            mClrSkipGcSrch(gsGcInfo.u16GcDesBlock);
        }
        else
        {
            pushSpareBlock(gsGcInfo.u16GcDesBlock, cPushNotErase|cPushDataBlock);
        }
    }

#if _EN_PROGFAILLOG
    gsGcInfo.u16GcDesPfBlock=gsGcInfo.u16GcDesBlock;
#endif
    gsGcInfo.u16GcDesSLCBlock=c16FBlockInitValue;
    gsGcInfo.u16GcDesTLCBlock=c16FBlockInitValue;
    gsGcInfo.u16GcDesBlock=c16FBlockInitValue;

    while(!gsGcInfo.uGcDesBlkCnt)
        ;

    gsGcInfo.uGcDesBlkCnt--;

    if(!gsGcInfo.uGcDesBlkCnt)
    {
        while(gsGcInfo.uGcSrcBlkCnt)
        {
            u16Fblock=mGet16GcSrcBlock(cGcHeadSrcBlk);

#if _EN_VPC_SWAP
            if(mChkVPCntValid(u16Fblock))
#else
            if(mGetCacheBlkVpCnt(u16Fblock))
#endif
            {
                if(mChkSkipGcSrch(u16Fblock))
                {
                    mClrSkipGcSrch(u16Fblock);
                }

                if(mChkGcSrcBlkBmap(u16Fblock))
                {
                    mClrGcSrcBlkBmap(u16Fblock);
                }
            }

            deleteGcSrcBlk(cGcHeadSrcBlk);
        }

        while(gsGcInfo.uGcSkipPopSrcBlockCnt)
        {
            gsGcInfo.uGcSkipPopSrcBlockCnt--;
            u16Fblock=gsGcInfo.u16arGcSkipPopSrcBlock[gsGcInfo.uGcSkipPopSrcBlockCnt];
#if _EN_VPC_SWAP
            if(mChkVPCntValid(u16Fblock))
#else
            if(mGetCacheBlkVpCnt(u16Fblock))
#endif
            {
                if(mChkSkipGcSrch(u16Fblock))
                {
                    mClrSkipGcSrch(u16Fblock);
                }

                if(mChkGcSrcBlkBmap(u16Fblock))
                {
                    mClrGcSrcBlkBmap(u16Fblock);
                }
            }

#if _EN_SLCOpenBlkReadScrub
            if(u16Fblock==gsGcInfo.u16FlushBlk)
            {
                mSetGcFlushState(cFlushIdle);
                mClrGcFlag(cFlushforReclaim);
                gsGcInfo.u16FlushBlk=c16FBlockInitValue;
            }
#endif

            gsGcInfo.u16arGcSkipPopSrcBlock[gsGcInfo.uGcSkipPopSrcBlockCnt]=cInvldFBlk;
        }

        uIdx=cWproGcDesF2hTab00;

        do
        {
            remWproPage(uIdx);
            uIdx++;
        }
        while(uIdx<=cWproGcInfoPage);

        // while(gsWproInfo.u16arWproIdxPagePtr[cWproGcInfoPage]<gsWproInfo.u16PagePerBlock3);

        if(mChkGcFlag(cGcSpareNotEnough))
        {
            if(gsCacheInfo.u16SpareBlockCnt>=5)
            {
                mSetGcFlow(cGcFlowIdl);
                mClrGcFlag(cGcSpareNotEnough);
            }
        }
        else
        {
            mSetGcFlow(cGcFlowIdl);
        }

        mSetGcState(cGcStateIdle);

        if(mChkGcQue(cGcTypTLCWearLvl))
        {
            gsFtlDbg.u16TLCGcWLCnt++;
            mClrGcFlag(cGcSrchWearF);
        }

        if(!gsGcInfo.uGcPrioTlcBlkNumPtr)
        {
            if(mChkGcQue(cGcTypTLCWearLvl))
            {
                mPopGcQue(cGcTypTLCWearLvl);
            }
        }

        if(!gsGcInfo.uGcPrioTlcBlkNumPtr&&!gsGcInfo.uGCSLCReclaimPtr)
        {
            mClrGcFlag(cUnderReclaim);
        }
    }

#if _EN_FW_DEBUG_UART
    NLOG(cLogGC,
         MAINCORE1_C,
         5,
         "TotalSpareCnt: 0x%04X, SLCSpareCnt: 0x%04X, DynamicSpareCnt: 0x%04X, SLCFullCacheBlockCnt: 0x%04X, TLCFullCacheBlockCnt: 0x%04X, Gc Done",
         gsCacheInfo.u16SpareBlockCnt,
         gsCacheInfo.u16SLCSpareCnt,
         gsCacheInfo.u16DynamicSpareCnt,
         gsCacheInfo.u16FullCacheBlockCnt,
         gsCacheInfo.u16TLCFullCacheBlockCnt);
#endif
}    /* funcTskgcDesBlkFullSetting */

void funcTskdeleteGcSrcBlk(BYTE uTskTail)
{
    BYTE uSrcBlk=gsTskFifoCtrl.uarTskFifo[uTskTail].uTskOpt;

    deleteGcSrcBlk(uSrcBlk);
}

void funcTskLoadDiff(BYTE uTskTail)
{
    loadDiffTab();
}

void funcTskSaveWproBadInfo(BYTE uTskTail)
{
    while(g32Core1State>=cCore1BootState_Finished)
        ;

    mCallFuncPtrCore1(csaveWproBadInfo);    // saveWproBadInfo();
}

void funcTskVendorOpSwap(BYTE uTskTail)
{
    loadIspCode(cSmiVuIsp1, 1);
    mCallFuncPtr2Core1(cfuncTskVendorOp, uTskTail);
    loadIspCode(cRwIsp1, 1);
}

void funcTskEraseUnitProcSwap(BYTE uTskTail)
{
    loadIspCode(cNvmeIsp1, 1);
    mCallFuncPtr2Core1(cfuncTskEraseUnitProc, uTskTail);
    loadIspCode(cRwIsp1, 1);
}

void funcTskProgFwDlTempIspBlockSwap(BYTE uTskTail)
{
    if(g32Core1State==cCore1BootState_Finished)
    {
        loadIspCode(cNvmeIsp1, 1);
    }

    mCallFuncPtr2Core1(cfuncTskProgFwDlTempIspBlock, uTskTail);

    if(g32Core1State==cCore1BootState_Finished)
    {
        loadIspCode(cRwIsp1, 1);
    }
}

void funcTskActivateIspSwap(BYTE uTskTail)
{
    if(g32Core1State==cCore1BootState_Finished)
    {
        loadIspCode(cNvmeIsp1, 1);
    }

    mCallFuncPtr2Core1(cfuncTskActivateIsp, uTskTail);

    if((g32Core1State==cCore1BootState_Finished)&&mChkActivateFail)
    {
        // If activate success, the InfoBlock already change to new version, don't swap code.
        loadIspCode(cRwIsp1, 1);
    }
}

void funcTskJudgeSwapIspSwap(BYTE uTskTail)
{
    while(g32Core1State>=cCore1BootState_Finished)
        ;

    mCallFuncPtr2Core1(cfuncTskJudgeSwapIsp, uTskTail);
}

void funcTskChkIspBlockSwap(BYTE uTskTail)
{
    if(g32Core1State==cCore1BootState_Finished)
    {
        loadIspCode(cNvmeIsp1, 1);
    }

    mCallFuncPtr2Core1(cfuncTskChkIspBlock, uTskTail);

    if(g32Core1State==cCore1BootState_Finished)
    {
        loadIspCode(cRwIsp1, 1);
    }
}

void funcTskSwapFwSlotIspSwap(BYTE uTskTail)
{
    if(g32Core1State==cCore1BootState_Finished)
    {
        loadIspCode(cNvmeIsp1, 1);
    }

    mCallFuncPtr2Core1(cfuncTskSwapFwSlotIsp, uTskTail);

    if(g32Core1State==cCore1BootState_Finished)
    {
        loadIspCode(cRwIsp1, 1);
    }
}

void funcTskLoadIspPageSwap(BYTE uTskTail)
{
    if(g32Core1State==cCore1BootState_Finished)
    {
        loadIspCode(cNvmeIsp1, 1);
    }

    mCallFuncPtr2Core1(cfuncTskLoadIspPage, uTskTail);

    if(g32Core1State==cCore1BootState_Finished)
    {
        loadIspCode(cRwIsp1, 1);
    }
}

void funcTskEraseUnitStartSwap(BYTE uTskTail)
{
    loadIspCode(cNvmeIsp1, 1);
    mCallFuncPtr2Core1(cfuncTskEraseUnitStart, uTskTail);
    loadIspCode(cRwIsp1, 1);
}

void funcTskEraseUnitContinueSwap(BYTE uTskTail)
{
    loadIspCode(cNvmeIsp1, 1);
    mCallFuncPtr2Core1(cfuncTskEraseUnitContinue, uTskTail);
    loadIspCode(cRwIsp1, 1);
}

void funcTskCore1SwapNvmeBank(BYTE uTskTail)
{
    loadIspCode(cNvmeIsp1, 1);
}

void funcTskCore1SwapIspBank(BYTE uTskTail)
{
    loadIspCode(cRwIsp1, 1);
}

void funcTskReadRdCnt2Tsb0(BYTE uTskTail)
{
    BYTE uTskPgOfst;

    uTskPgOfst=gsTskFifoCtrl.uarTskFifo[uTskTail].uTskPgOfst;
#if _EN_VPC_SWAP
    bopCopyRam(c32Tsb0SAddr+(uTskPgOfst*cSingleSectorByte), (LWORD)(&g16arGlobReadCnt[0]),
               c16MaxBlockNum*sizeof(WORD), cCopyTsb2Tsb|cBopWait);
    bopCopyRam(c32Tsb0SAddr+(uTskPgOfst*cSingleSectorByte)+(c16MaxBlockNum*sizeof(WORD)), (LWORD)(&garGlobReadCntHighByte[0]),
               c16MaxBlockNum*sizeof(BYTE), cCopyTsb2Tsb|cBopWait);
    bopCopyRam(c32Tsb0SAddr+(uTskPgOfst*cSingleSectorByte)+(c16MaxBlockNum*(sizeof(WORD)+sizeof(BYTE))), (LWORD)(&g32arPushReclaimQ[0]),
               (c16MaxBlockNum/32)*sizeof(LWORD), cCopyCpu1Dccm2Tsb|cBopWait);
#else
#if (_TSB_BiCS4)
    bopCopyRam(c32Tsb0SAddr+(uTskPgOfst*cSingleSectorByte), (LWORD)(&g32arGlobReadCnt[0]),
               c16MaxBlockNum*sizeof(LWORD), cCopyStcm2Tsb|cBopWait);
#else
    bopCopyRam(c32Tsb0SAddr+(uTskPgOfst*cSingleSectorByte), (LWORD)(&g32arGlobReadCnt[0]),
               c16MaxBlockNum*sizeof(LWORD), cCopyTsb2Tsb|cBopWait);
#endif
    bopCopyRam(c32Tsb0SAddr+(uTskPgOfst*cSingleSectorByte)+(c16MaxBlockNum*sizeof(LWORD)), (LWORD)(&g32arPushReclaimQ[0]),
               (c16MaxBlockNum/32)*sizeof(LWORD), cCopyCpu1Dccm2Tsb|cBopWait);
#endif
    uTskPgOfst=uTskPgOfst+gSectorPerPlaneH-1;
    g16arTsb0[uTskPgOfst][0x1FE/2]=c16MaxBlockNum*sizeof(LWORD);
    g16arTsb0[uTskPgOfst][0x1FC/2]=(c16MaxBlockNum/32)*sizeof(LWORD);
}    /* funcTskReadRdCnt2Tsb0 */

void funcTskLoadTelemetryCtlrLogSwap(BYTE uTskTail)
{
    if(g32Core1State==cCore1BootState_Finished)
    {
        loadIspCode(cNvmeIsp1, 1);
    }

    mCallFuncPtr2Core1(cfuncTskLoadTelemetryCtlrLog, uTskTail);

    if(g32Core1State==cCore1BootState_Finished)
    {
        loadIspCode(cRwIsp1, 1);
    }
}

void funcTskGetAvgEC(BYTE uTskTail)
{
    BYTE u8TskOpt=gsTskFifoCtrl.uarTskFifo[uTskTail].uTskOpt;

    gsTskFifoCtrl.u16EraseCnt=AvgECForCore1(u8TskOpt);
}    /* funcTskGetAvgEC */

#if _EN_CHK_FINGER_FAIL
void funcTskChkFingerFail(BYTE uTskTail)
{
    volatile BYTE uStop=1;
    BYTE uFingerIdx, uLayer, uUeccCnt;
    WORD u16NowNodeIdx, u16Index, u16Page;
    ADDRINFO usTempAddrInfo;

    funcTskDisLdpcPipe(0);
    gpFlashAddrInfo=&usTempAddrInfo;

    for(u16Index=0; u16Index<gTotalIntlvChPlaneNum; u16Index++)
    {
        /* check at least 3 layer's CSBs for all 4 fingers of the FBlcok */
        for(uFingerIdx=0; uFingerIdx<cFingersPerBlock; uFingerIdx++)
        {
            uUeccCnt=0;

            for(uLayer=0; uLayer<cChkLayersOfFinger; uLayer++)
            {
                /* check the CSBs */
                u16Page=(uLayer*cPagesPerLayer)+((uFingerIdx*cProgCntPerWL)+cCSB);

                g16FBlock=gsGcInfo.u16GcDesBlock;
                g32FPageNoTran=((u16Page&g32PhyPageAddrMask)<<gPhyPageAddrBitShiftCnt)|(u16Index*g4kNumPerPlane);
                gpFlashAddrInfo->uTsb4kIdx=0xFF;
                gpFlashAddrInfo->uSrcIdx=u16NowNodeIdx;
                tranAddrInfo(gpFlashAddrInfo);
                gSectorH=0;
                setFLActCh(gpFlashAddrInfo->uCh);
                mSetFRwParam(c16Tsb0SIdx, 0x04, c16Bit4|c16Bit10, cChkFingerFail);
                gpFlashAddrInfo->uPlaneCnt=1;
                waitChCeBz(gpFlashAddrInfo->uCh, gpFlashAddrInfo->uIntlvAddr, 0);

                gbEccFail=0;

                flashReadPage();

                if(gbEccFail)
                {
                    uUeccCnt++;
#if _GREYBOX
                    if((gsGbInfo.uGreyBoxItem==cErrHdlGcFingerFailTestID)&&(g32GbFingerFailBlk==c32BitFF))
                    {
                        gsGbInfo.uStag=cVsTriggered;

                        if(((BYTE)gsGbInfo.u32BkValue)>uUeccCnt)
                        {
                            gReadErrinjectEn=cTrue;
                            g16GbRetryTabLoop=c16BitFF;
                        }
                        else
                        {
                            gReadErrinjectEn=cFalse;
                            g16GbRetryTabLoop=0;
                        }
                    }
#endif
                    gbEccFail=0;
                    // return cFail;
                }

                if(uUeccCnt==cChkLayersOfFinger)
                {
#if _GREYBOX
                    if(gsGbInfo.uGreyBoxItem==cErrHdlGcFingerFailTestID)
                    {
                        gsGbInfo.uStag=cVsDone;
                        g32GbFingerFailBlk=gsGcInfo.u16GcDesBlock;
                    }
#endif
#if _EN_FW_DEBUG_UART
                    NLOG(cLogCore1, MAINCORE1_C, 4,
                         "chkFingerFail: Ch: 0x%04X,Intlv: 0x%04X,CE: 0x%04X,Die: 0x%04X",
                         gCh,
                         gIntlvAddr,
                         gCe,
                         gDieAddr);
                    NLOG(cLogCore1, MAINCORE1_C, 4,
                         "chkFingerFail: Plane:0x%04X,Block: 0x%04X,Page: 0x%04X,Sector: 0x%04X",
                         gPlaneAddr,
                         g16FBlock,
                         g16FPage,
                         gSectorH);
                    NLOG(cLogCore1, MAINCORE1_C, 1,
                         "chkFingerFail: rFLCtrl[0x11A]=0x%04X",
                         rFLCtrl[0x11A]);
#endif
                    funcTskgcDesBlkFullSetting(0);
                    setMarkBadBlock(gpFlashAddrInfo, cGcFingerFailID);
                    gsTskFifoCtrl.u32EraseFail=cFail;
                    funcTskEnLdpcPipe(0);
                    return;
                }
            }
        }
    }

    gsTskFifoCtrl.u32EraseFail=cSuccess;
    funcTskEnLdpcPipe(0);
}    /* funcTskChkFingerFail */

#endif/* if _EN_CHK_FINGER_FAIL */
void funcTskMarkEraseBad(BYTE uTskTail)
{
    setEraseBadBlock(gsTskFifoCtrl.u16FBlk, gsTskFifoCtrl.u32EraseFail);
}

#if (_ENABLE_RAID&&_EN_VPC_SWAP)
void funcTskpushVPCtoRaid(BYTE uTskTail)
{
    hdmaEncRam(gsTskFifoCtrl.uarTskFifo[uTskTail].u16TskSBufPtr, cRaidDataSctrNum, 0, cHdmaWait, cRaidEngTemp, cSLC);
}

void funcTskpopVPCfromRaid(BYTE uTskTail)
{
    hdmaGetRaidPty(gsTskFifoCtrl.uarTskFifo[uTskTail].u16TskSBufPtr, cHdmaWait, cRaidPtyClr|cRaidEngTemp, 0, cSLC);
}

#endif

void(*const core1TaskFuncPtr[]) (BYTE)=
{
    funcTskPopBlk,
    funcTskPushBlk,
    funcTskWaitAllBz,
    funcTskChkEsSts,
    funcTskProgWpro,
    funcTskReadWpro,
    funcTskProgH2f,
    funcTskMarkBad,
    funcTskSwapCore0,
    funcTskInvalidateCore1DCache,
    funcTskCore1SetGlobEraseCnt,
    funcTskCore0GetGlobEraseCnt,
    funcTskCore0GetDiffType2Offset,
    funcTskSaveIndexBlockCore0,
    // funcTskPrePopBlkErase,
    funcTskPrePopBlkChkStatus,
    funcTskVendorOpSwap,
    funcTskChkPushSpareQ,
    funcTskSetDiffType2AddrInfo,
    funcTskRstAllFlash,
    funcTskRstAllFshInHdPCIeErr,
    funcTskRstCtlVar,
    funcTskCore0GetRndSeed,
    funcTskBuildF2h,
    funcTskEraseUnitProcSwap,
    funcTskEnLdpcPipe,
    funcTskDisLdpcPipe,
    funcTskChkPostWriteRead,
    funcTskCore1SetGlobEraseCnt1Blk,
    funcTskProgFwDlTempIspBlockSwap,
    funcTskActivateIspSwap,
    funcTskJudgeSwapIspSwap,
    funcTskChkIspBlockSwap,
    funcTskSwapFwSlotIspSwap,
    funcTskLoadIspPageSwap,
    funcTskCore1Sleep,
    funcTskCore1ClrLastRGrp,
#if _ENABLE_RAID
    // funcTskSetRaidEncode,
    // funcTskGetRaidParity,
    funcTskProgPartialRaidParity,
    funcTskPushRaidPtyBlk,
    funcTskInitRaidEngine,
    funcTskRstRaidEngVar,
#endif
    funcTskChangeFlashClock,
    funcTskWaitProgH2fTxData,
    funcTskRstUNCSts,
    funcTskRstUNCSts1Plane,
    funcTskInvPlaneBufFlag,
    funcTskGetGlobEraseCntOfSpecFblock,
    funcTskCore1ResumePs3,
    funcTskRemWproPage,
    funcTskGetDifferAddr,
    funcTskSwapWproBlk,
    funcTskInsSlcSortQ,
    funcTskGetGcSrcBlk,
    funcTskInitSlcQ,
    funcTskRetoreSlcQ,
    funcTskSetSlcEndurPara,
    funcTskSetGcInfoHmbLink,
    funcTskFlashWriteCmd,
    funcTskLoadDiff,
    funcTskSaveWproBadInfo,
    funcTskCore1SwapNvmeBank,
    // funcTskResetGCFlag,
    funcTskReadRdCnt2Tsb0,
#if _EN_SLCOpenBlkReadScrub
    funcTskPushWLReadReclaimQ,
#endif
    funcTskinitGcProc,
    funcTskgcDesBlkFullSetting,
    funcTskdeleteGcSrcBlk,
#if _ENABLE_RAID
    funcTskRstRaidPara,
#endif
    funcTskLoadTelemetryCtlrLogSwap,
    funcTskEraseUnitStartSwap,
    funcTskEraseUnitContinueSwap,
    funcTskCore1SwapIspBank,
#if _EN_CHK_FINGER_FAIL
    funcTskChkFingerFail,
#endif
    funcTskGetAvgEC,
    funcTskMarkEraseBad,
#if (_ENABLE_RAID&&_EN_VPC_SWAP)
    funcTskpushVPCtoRaid,
    funcTskpopVPCfromRaid,
#endif
    funcTskInitEraseCnt,
};

#if _GREYBOX
__arm void main() @ ".CORE1_MAIN_ENTRYCODE"
#else
void main()
#endif
{
#if !_INITDRAM
    BYTE uTskTail, uTskType;

#if (!_GREYBOX)
    mCallFuncPtrCore1(ccore1Boot);    // core1Boot();
#else
    g32GreyBoxSwapOffset1=((LWORD)cGreyBoxSwapCodeSize1<<cSingleSectorShift)*(cBootIsp1);
    mCallFuncPtrCore1(ccore1Boot);    // core1Boot();
#endif/* if (!_GREYBOX) */
#if (C_Log_SaveMask&C_Debug_P1)    // _ENABLE_NAND_UART_DEBUG  //20181025_Bill
    NLOG(cLogCore1, MAINCORE1_C, 0, "mCallFuncPtrCore1(ccore1Boot) end");
#endif

    while(g32Core1State!=cCore1BootState_SwapCPU1Rw)
    {
        if(gsRwCtrl.u32FreeSrcFifoTrig!=gsRwCtrl.u32FreeSrcFifoHead)
        {
            insSrcCmdList();
        }

        if(gsRwCtrl.usSrcCmdList.u16Cnt)
        {
            mCallFuncPtrCore1(cchkPostReadFifo);    // chkPostReadFifo();
            trigFlCmdFfStep2();
        }
        else if(gsRwCtrl.u32ProgFifoTail!=gsRwCtrl.u32ProgFifoHead)
        {
            trigFlashCmdFifoW();
        }
        else if(gsTskFifoCtrl.u32HeadPtr!=gsTskFifoCtrl.u32TailPtr)
        {
            uTskTail=gsTskFifoCtrl.u32TailPtr;
            uTskType=gsTskFifoCtrl.uarTskFifo[uTskTail].uTskTyp;
            core1TaskFuncPtr[uTskType](uTskTail);
            gsTskFifoCtrl.u32TailPtr=(gsTskFifoCtrl.u32TailPtr+1)&cTaskDepMsk;
        }
        else if(gsCacheInfo.ubEnDualCoreFlush&&(gsCacheInfo.u32ModifyH2fPtrTail<=gsCacheInfo.u32ModifyH2fPtrHead))
        {
            mCallFuncPtrCore1(cmodifyH2FtabBootCore1);    // modifyH2FtabBootCore1();
        }
        else if((gsRwCtrl.usBootErsCmdInfo.uSysBlkIdx!=cInvalid8Bit)&&(g32Core1State>=cCore1BootState_2))
        {
            initErasedSysSprBlk(gsRwCtrl.usBootErsCmdInfo.uSysBlkIdx, gsRwCtrl.usBootErsCmdInfo.uOpt);
            gsRwCtrl.usBootErsCmdInfo.uSysBlkIdx=cInvalid8Bit;
        }
        else if(g32Core1State==cCore1BootState_1)
        {
            // loadDiffTab();
            g32Core1State=cCore1BootState_2;
        }
        else if(g32Core1State==cCore1BootState_3)
        {
#if _ENABLE_RAID
            initRaidEngine();
#endif
            g32Core1State=cCore1BootState_4;
        }
    }

#if _GREYBOX
    __flushCache();
    __enableDataCache();
    __enableInstCache();
#endif
    loadIspCode(cRwIsp1, 1);
    g32Core1State=cCore1BootState_Finished;
    // syncCore1Var();
    // BYTE uCnt;
#if (C_Log_SaveMask&C_Debug_P1)    // _ENABLE_NAND_UART_DEBUG  //20181025_Bill
    NLOG(cLogCore1, MAINCORE1_C, 0, "g32Core1State=cCore1BootState_Finished end");
#endif
#if _DEBUG_LOG
    debugAllChReadFifo(0);
    debugTSBflag(0);
    getPfRtcTime(0);
#endif

    while(1)
    {
        // blinkLed(); //too long

        while(gsRwCtrl.u32SeqRdFlag)
        {
            gsRwCtrl.u32SeqRdCpu1Flag=cTrue;

            if(gsRwCtrl.u32FreeSrcFifoTrig!=gsRwCtrl.u32FreeSrcFifoHead)
            {
                insSrcCmdList();
            }

            if(gsRwCtrl.usSrcCmdList.u16Cnt)
            {
                g32RWTickCnt++;
                chkPostReadFifo2();
                trigFlCmdFfStep2();
            }

            if(gsRwCtrl.u32SeqRdFlag&cBit1)
            {
                termContiRCore1();
                gsRwCtrl.u32SeqRdFlag|=cBit2;
                gsRwCtrl.u32SeqRdFlag&=~cBit1;
            }

            if(gsRwCtrl.u32SeqRdFlag&cBit2)
            {
                for(BYTE uCnt=0; uCnt<c16ReadBufSize4K; uCnt+=4)
                {
                    garReadBufOrderHead[uCnt]=garReadBufOrderTail[uCnt]=0;
                    garReadBufOrderHead[uCnt+1]=garReadBufOrderTail[uCnt+1]=0;
                    garReadBufOrderHead[uCnt+2]=garReadBufOrderTail[uCnt+2]=0;
                    garReadBufOrderHead[uCnt+3]=garReadBufOrderTail[uCnt+3]=0;
                }

                g16ReadBufPtr=c16ReadSIdx;
                gsRwCtrl.u32SeqRdFlag&=~cBit2;
            }

#if _EN_NAND_TEMP
            if(g32NandTempSensor&&(gsRwCtrl.u32ProgFifoTail==gsRwCtrl.u32ProgFifoTrig))
            {
                getNandTempSensor();
                g32NandTempSensor=0;
            }
#endif
        }

        gsRwCtrl.u32SeqRdCpu1Flag=cFalse;

        if(gsRwCtrl.u32FreeSrcFifoTrig!=gsRwCtrl.u32FreeSrcFifoHead)
        {
            insSrcCmdList();
        }

#if _EN_WRHWPRDCORE1
        if(gsPrdInfo.u32TrigWrCmdTail!=gsPrdInfo.u32TrigWrCmdTrig)
        {
            setHwPrdCore1();
        }
#endif

        if(gsRwCtrl.usSrcCmdList.u16Cnt)
        {
            g32RWTickCnt++;
            chkPostReadFifo2();
            trigFlCmdFfStep2();
        }
        else if(gProgFifoPtr!=cBitFF)
        {
            setSprByteOfDataBlk(gProgFifoPtr);
            gProgFifoPtr=cBitFF;
        }
        else if(gsRwCtrl.u32ProgFifoTail!=gsRwCtrl.u32ProgFifoHead)
        {
            g32RWTickCnt++;

            if(!mChkGcFlag(cUnderGcH2fTab))
            {
                trigFlashCmdFifoW();
            }
            else
            {
                trigFLCmdFifoWtab();
            }
        }
        else if(gsTskFifoCtrl.u32HeadPtr!=gsTskFifoCtrl.u32TailPtr)
        {
            uTskTail=gsTskFifoCtrl.u32TailPtr;
            uTskType=gsTskFifoCtrl.uarTskFifo[uTskTail].uTskTyp;
            core1TaskFuncPtr[uTskType](uTskTail);
#if _CORE1_SLEEP
            if(uTskType!=cTskCore1Sleep)
#endif
            {
                gsTskFifoCtrl.u32TailPtr=(gsTskFifoCtrl.u32TailPtr+1)&cTaskDepMsk;
            }

#if (_ENABLE_NAND_UART_DEBUG)
            if(uTskType==cTskCore1Sleep)
            {
                NLOG(cLogCore1, MAINCORE1_C, 0, "_____________cTskCore1Sleep_________");
            }
#endif
        }
        else if(gsCacheInfo.ubEnDualCoreFlush&&(gsCacheInfo.u32ModifyH2fPtrTail<=gsCacheInfo.u32ModifyH2fPtrHead))
        {
            mCallFuncPtrCore1(cmodifyH2FtabCore1);    // modifyH2FtabCore1();
        }

        /*
           * else if((gsGcInfo.uGcPrioBlkNumPtr<cMaxGcPrioBlkNum)&&(!gsRdCntCtrl.u16ChkRdCnt))
           * {
           *  // background check read count
           *  chkReadCntInBg();
           * }
           */

#if _INITDRAM
        else if(gGreyBoxBootSta==cGreyBoxBootCore0Ready)
        {
            goCore1DramCode();
        }
#endif/* if _InitDram */

#if _EN_NAND_TEMP
        if(g32NandTempSensor&&(gsRwCtrl.u32ProgFifoTail==gsRwCtrl.u32ProgFifoTrig))
        {
            getNandTempSensor();
            g32NandTempSensor=0;
        }
#endif
    }
#else/* if !_INITDRAM */
    void (*ISPPretestFunPtr)(unsigned char)=0;
    unsigned int u32JumpAddr=c32GreyBoxCode1CodeAddr;
    ISPPretestFunPtr=(void (*)(unsigned char))(u32JumpAddr);
    ISPPretestFunPtr(0);
#endif/* if !_INITDRAM */
}    /* main */

void setWriteDes(WORD u16ProgPageOfst, ADDRINFO *upTmpAddrInfo, BYTE uDesTyp)
{
    // LWORD u324KNumOfDesFblk, u32FreePagePtr;

    if(uDesTyp==cWriteH2fTab)
    {
        upTmpAddrInfo->u16FBlock=g16arH2fTabBlk[gsCacheInfo.uActH2fTabBlkIdx];
        upTmpAddrInfo->u32FPageNoTran=mTranH2fTabAddr(gsCacheInfo.u16H2fTabFreePagePtr)+u16ProgPageOfst;
        // upTmpAddrInfo->ubLsbOnly=1;
        upTmpAddrInfo->uAddrOpt=cH2fTableID;    // (upTmpAddrInfo->uAddrOpt&0xF0)|cH2fTableID;
        // upTmpAddrInfo->ubRsvBlkSeed=0;
        tranAddrInfo(upTmpAddrInfo);
    }
    else if(uDesTyp==cWriteWpro)
    {
        // upTmpAddrInfo->u16FBlock=gsWproInfo.u16WproBlk;
        upTmpAddrInfo->u16FBlock=gsWproInfo.u16arWproBlk[gsWproInfo.uActIdx];
        upTmpAddrInfo->u16FPage=gsWproInfo.u16WproFreePagePtr+u16ProgPageOfst;
        // upTmpAddrInfo->ubLsbOnly=1;
        upTmpAddrInfo->uAddrOpt=cWPROBlockID;    // (upTmpAddrInfo->uAddrOpt&0xF0)|cWPROBlockID;
    }
    else if(uDesTyp==cWriteRaid)
    {
        upTmpAddrInfo->u16FBlock=g16arRaidParityBlk[gsCacheInfo.uRaidPtyBlkIdx];
        upTmpAddrInfo->u32FPageNoTran=mTranRaidPtyAddr(gsCacheInfo.u16RaidPtyFreePagePtr)+u16ProgPageOfst;
        upTmpAddrInfo->uAddrOpt=cRaidParityID;
        tranAddrInfo(upTmpAddrInfo);
    }
    else if(uDesTyp==cWriteRaidGc)
    {
        upTmpAddrInfo->u16FBlock=g16arRaidParityBlk[gsCacheInfo.uRaidGcPtyBlkIdx];
        upTmpAddrInfo->u32FPageNoTran=mTranRaidPtyAddr(gsCacheInfo.u16RaidGcPtyFreePagePtr)+u16ProgPageOfst;
        upTmpAddrInfo->uAddrOpt=cRaidParityID;
        tranAddrInfo(upTmpAddrInfo);
    }
    else
    {
        gsFtlDbg.u16DummyFailType=cSetWriteDes2;
        debugWhile();
    }

    mClrSprUseCnt(upTmpAddrInfo);    // upTmpAddrInfo->uSparUseCnt=0;
}    /* setWriteDes */

void blinkLed()
{
#if (!_GREYBOX)
    LWORD uDly;

    rmGpioP12Led(0);
    rmGpioP16Led(0);

    for(uDly=0; uDly<1000; uDly++)
    {
        sysDelay(0xFFFF);
    }

    rmGpioP12Led(1);
    rmGpioP16Led(1);

    for(uDly=0; uDly<1000; uDly++)
    {
        sysDelay(0xFFFF);
    }
#endif/* if (!_GREYBOX) */
}    /* blinkLed */

void loadIspCode(BYTE uCodeBank, BYTE uDesCore)
{
#if (!_GREYBOX)
    WORD u16IspPage, u16CodeLenSec, u16BufIdx;
    BYTE uSecCodeLoaded=0;

    if(uDesCore==0)
    {
        u16BufIdx=0;

        if(uCodeBank==cPs4ExitBootIsp)
        {
            u16CodeLenSec=c32Ps4BootIspCodeSize>>cSingleSectorShift;
        }
        else
        {
            u16CodeLenSec=cSwapCodeSize;
        }

        u16IspPage=gISPBlockStartPage+(((uCodeBank+1)*cSwapCodeSize)/gSectorPerPlaneH);
    }
    else if(uDesCore==1)
    {
        u16CodeLenSec=cSwapCodeSize1;
        u16IspPage=gISPBlockStartPage+((((cCore1Start+1)*cSwapCodeSize)+uCodeBank*cSwapCodeSize1)/gSectorPerPlaneH);
        u16BufIdx=c16TsbCore1SIdx;
        // u16IspPage=    /*gIsp1BlockStartPage*/ +(((uCodeBank+1)*cSwapCodeSize)/gSectorPerPlaneH);
    }
    else if(uDesCore==2)
    {
        u16BufIdx=cUartTsbStartBufIdx;
        u16CodeLenSec=cUartTsbSwapCodeSize;
        u16IspPage=gISPBlockStartPage+(((uCodeBank+1)*cSwapCodeSize)/gSectorPerPlaneH);
    }

#if _ENABLE_SECAPI
    else if(uDesCore==3)    // for Security
    {
#if (!_INITDRAM)
        u16BufIdx=cTrustedCryptoLibStartBufIdx;
        u16CodeLenSec=csecBaseSwapCodeSize;
        u16IspPage=gISPBlockStartPage+((((uCodeBank+1)*cSwapCodeSize)+csecBaseSwapCodeSize*(mChkISPMode-cBoot2Isp))/gSectorPerPlaneH);
#endif
    }
#endif

    while(u16CodeLenSec!=0)
    {
        if(loadInfoPage(u16IspPage, gSectorPerPlaneH, u16BufIdx, 0, cSysBlock1stInfo, 0)!=0)
        {
            debugDeadLock(0x0078|c16Bit15);
        }
        else
        {
            if(u16CodeLenSec>gSectorPerPlaneH)
            {
                u16CodeLenSec-=gSectorPerPlaneH;
            }
            else
            {
                u16CodeLenSec=0;
            }

            u16IspPage++;    // u16CodeLocSec+=uHalfKB;
            u16BufIdx+=gSectorPerPlaneH;

            if((uDesCore==3)&&(u16CodeLenSec==0)&&(uSecCodeLoaded==0)&&(uCodeBank!=cNvmeIsp)&&(uCodeBank!=cSmiVuIsp))
            {
                uSecCodeLoaded=1;
                u16CodeLenSec=cSecApiSwapCodeSize;
                u16IspPage=gISPBlockStartPage+((((uCodeBank+1)*cSwapCodeSize)+csecBaseSwapCodeSize*4)/gSectorPerPlaneH);
            }
        }
    }

    if(uDesCore==0)
    {
        if(uCodeBank==cPs4ExitBootIsp)    // Load PS4 boot isp code to 0x40180000
        {
            bopCopyRam(c32Tsb2SAddr, c32Tsb0SAddr, c32Ps4BootIspCodeSize, cCopyTsb2Tsb|cBopWait);
        }
        else
        {
            bopCopyRam((cItcmAddr+cItcmSize/2), c32Tsb0SAddr, cItcmSize/2, cCopyTsb2Iccm|cBopWait);
            mSetISPMode(uCodeBank);
        }
    }
    else if(uDesCore==1)
    {
        bopCopyRam((cItcmAddr+cItcmSize-cSwapCodeSize1*0x200), c32TsbCore1SwapAddr, cSwapCodeSize1*0x200, cCopyTsb2Cpu1Iccm|cBopWait);
        mSetISPC1Mode(uCodeBank);
    }
    else if((uDesCore==2)||(uDesCore==3))
    {
        // load code bank to TSB0
    }
    else
    {
        gsFtlDbg.u16DummyFailType=cLoadIspCode;
        debugWhile();    // Finn: I think you already got some trouble
    }
#else/* if (!_GREYBOX) */
    if((uDesCore==0)||(uDesCore==3))
    {
        mSetISPMode(uCodeBank);
        g32GreyBoxSwapOffset=((LWORD)cSwapCodeSize<<cSingleSectorShift)*(uCodeBank-1);
    }
    else if(uDesCore==1)
    {
        mSetISPC1Mode(uCodeBank);
        g32GreyBoxSwapOffset1=((LWORD)cGreyBoxSwapCodeSize1<<cSingleSectorShift)*(uCodeBank);
    }

#if ((_CODECOVER)&&(_GREYBOX))
    if(uDesCore==0)
    {
        if(uCodeBank==cBootIsp)
        {
            g32CodeCoverMapOffset=c32GreyBoxCore0CodeAddr+0x1000000;
        }
        else if(uCodeBank==cBoot2Isp)
        {
            g32CodeCoverMapOffset=c32GreyBoxCore0CodeAddr+0x2000000;
        }
        else if(uCodeBank==cRwIsp)
        {
            g32CodeCoverMapOffset=c32GreyBoxCore0CodeAddr+0x3000000;
        }
        else if(uCodeBank==cNvmeIsp)
        {
            g32CodeCoverMapOffset=c32GreyBoxCore0CodeAddr+0x4000000;
        }
        else if(uCodeBank==cSmiVuIsp)
        {
            g32CodeCoverMapOffset=c32GreyBoxCore0CodeAddr+0x5000000;
        }
    }
    else if(uDesCore==1)
    {
        if(uCodeBank==cBootIsp1)
        {
            g32CodeCoverMapOffset=c32GreyBoxCore0CodeAddr+0x6000000;
        }
        else if(uCodeBank==cRwIsp1)
        {
            g32CodeCoverMapOffset=c32GreyBoxCore0CodeAddr+0x7000000;
        }
        else if(uCodeBank==cNvmeIsp1)
        {
            g32CodeCoverMapOffset=c32GreyBoxCore0CodeAddr+0x8000000;
        }
        else if(uCodeBank==cSmiVuIsp1)
        {
            g32CodeCoverMapOffset=c32GreyBoxCore0CodeAddr+0x9000000;
        }
        else if(uCodeBank==cErrHdlIsp1)
        {
            g32CodeCoverMapOffset=c32GreyBoxCore0CodeAddr+0xA000000;
        }
    }
#endif/* if ((_CODECOVER)&&(_GREYBOX)) */
#endif/* if (!_GREYBOX) */
}    /* loadISPCode */

BYTE chkWproBlk(WORD u16Fblock)
{
    BYTE uWproBlkIdx;

    for(uWproBlkIdx=0; uWproBlkIdx<cMaxWproBlkCnt; uWproBlkIdx++)
    {
        if((gsWproInfo.u16arWproBlk[uWproBlkIdx])==u16Fblock)
        {
            return cFalse;
        }
    }

    return cTrue;
}

void setSprByteOfSysBlk(WORD u16Ptr, BYTE uPlaneAddr, BYTE uBlockId)
{
    BLKSPRINFO usBlkSprInfo;

    usBlkSprInfo.u16Seed=g16arSeedTable[gpFlashAddrInfo->u16FPage];

    usBlkSprInfo.u16Spr8.us2BYTE.LowByte=uBlockId;
    usBlkSprInfo.u16Spr8.us2BYTE.HighByte=cTrue;
    usBlkSprInfo.u32Spr9and10.u32all=0;    // getIspBlockSerial()+1;
    usBlkSprInfo.u16Spr11.u16all=mGetGlobEraseCnt(g16AbstrFBlock);

    usBlkSprInfo.u16Spr0.u16all=uBlockId;
    usBlkSprInfo.u16Spr1.u16all=div(cTotalIspCodeSize, gSectorPerPlaneH);    // getTotalPlaneOfIsp();
    usBlkSprInfo.u16Spr2.u16all=0xFFFF;
    usBlkSprInfo.u16Spr3.u16all=(u16Ptr<<8);    // BootIsp:garLinkId[0x7]

    usBlkSprInfo.u16Spr4.u16all=gsFtlDbg.u32PowerOnCnt&0xFFFF;    // g16PowerOnCnt;
    usBlkSprInfo.u16Spr5.u16all=(gsFtlDbg.u32PowerOnCnt>>16);
    usBlkSprInfo.u16Spr6.u16all=0xFFFF;
    usBlkSprInfo.u16Spr7.u16all=0xFFFF;

    setSprByte(&usBlkSprInfo, uPlaneAddr);
}    /* setSprByteOfDMBlk */

BYTE readIspBlock(WORD u16Pageptr, BYTE uIndex, BLKSPRINFO *upBlkSprInfo)
{
    ADDRINFO usTmpAddrInfo;
    BYTE uType=0;

    if((uIndex<=cSysBlock2ndInfo)||(uIndex==gsFwDlInfo.uSysRsvFwDlImageBlk))
    {
        uType|=cBit0;
    }

    bopClrRam((LWORD)(BYTE *)&usTmpAddrInfo, sizeof(ADDRINFO), 0x00000000, cClrCore1Dccm|cBopWait);

    if((u16Pageptr<gNorEccStrPage)&&(uType&cBit0))
    {
        enEccInMax();
    }

    tranRsvBlkAddr(garSysBlock[uIndex], &usTmpAddrInfo);
    // tranCeNum(&usTmpAddrInfo);

    usTmpAddrInfo.uSectorH=0;
    usTmpAddrInfo.u16FPage=u16Pageptr;

    setFLAddrActCh(usTmpAddrInfo.uCh, &usTmpAddrInfo);
    mClrBitMask(gPlaneUNCSts[gCh], gPlaneAddr);

    // mSetSeedOfst(usTmpAddrInfo.u16FBlock, 0);
    if((u16Pageptr<gNorEccStrPage)&&(uType&cBit0))
    {
        // enEccInMax();
        mSetFRwParam(c16Tsb0SIdx, (gSectorPerPlaneH-4), c16Bit4|c16Bit5|c16Bit10|c16Bit13, cReadData);
    }
    else
    {
#if _ENABLE_E2E_TAB
        gsE2eInfo.uTableType=cE2eInfoBlk;
#endif
        mSetFRwParam(c16Tsb0SIdx, gSectorPerPlaneH, c16Bit4|c16Bit5|c16Bit10|c16Bit13, cReadData);
    }

    waitCmdFifoDpt(usTmpAddrInfo.uCh, &usTmpAddrInfo);
    waitChCeBz(usTmpAddrInfo.uCh, usTmpAddrInfo.uIntlvAddr, cNoOp);
    flashReadPage();

#if _ENABLE_E2E_TAB
    if((u16Pageptr<gNorEccStrPage)&&(uType&cBit0))
    {}
    else
    {
        if(!mChkBitMask(gPlaneUNCSts[gCh], gPlaneAddr)&&chkReadTableCrcCnt(gpFlashAddrInfo))
        {
            gsE2eInfo.uTableType=cE2eUserDataBlk;
            return cReadIspUnc;
        }
    }
    gsE2eInfo.uTableType=cE2eUserDataBlk;
#endif

    if(mChkBitMask(gPlaneUNCSts[gCh], gPlaneAddr))
    {
        enEccInNormal();
        return cReadIspUnc;
    }

    getSprByte(upBlkSprInfo, usTmpAddrInfo.uPlaneAddr);

    if((u16Pageptr<gNorEccStrPage)&&(uType&cBit0))
    {
        enEccInNormal();
    }

    if(uIndex==gsFwDlInfo.uSysRsvFwDlImageBlk)
    {
        if(upBlkSprInfo->u16Spr8.us2BYTE.LowByte!=cFwDlDesBlockID)
        {
            return cReadIspBlkIdMismatch;
        }
    }
    else if(uIndex==cSysBlockIsp)
    {
        if(upBlkSprInfo->u16Spr8.us2BYTE.LowByte!=cIspBlockID)
        {
            return cReadIspBlkIdMismatch;
        }
    }
    else if(uIndex==cSysBlockSpare1)    // Only for swap Ispblk case
    {
        if(upBlkSprInfo->u16Spr8.us2BYTE.LowByte!=cTmpBlockID)
        {
            return cReadIspBlkIdMismatch;
        }
    }
    else    // Info blk case
    {
        if((upBlkSprInfo->u16Spr8.us2BYTE.LowByte!=cInfoBlockID)
           &&(u16Pageptr<(gISPCore1StartPage+cTotalPlaneOfIsp)))
        {
            return cReadIspBlkIdMismatch;
        }
    }

    return cReadIspSuccess;
}    /* readIspBlock */

void setSprByteOfIspBlk(BLKSPRINFO *upBlkSprInfo, WORD u16EraseCnt, BYTE uPlaneAddr)
{
    BLKSPRINFO usBlkSprInfo;
    WORD *u16pSprPtr;
    WORD *u16pSprPtr1;
    BYTE uLoop;

    u16pSprPtr=&(upBlkSprInfo->u16Spr0.u16all);
    u16pSprPtr1=&(usBlkSprInfo.u16Spr0.u16all);

    for(uLoop=0; uLoop<(cSprByteNum/2); uLoop++)
    {
        *u16pSprPtr1++=*u16pSprPtr++;
    }

    usBlkSprInfo.u16Seed=g16arSeedTable[gpFlashAddrInfo->u16FPage];
    usBlkSprInfo.u16Spr0.u16all=cInfoBlockID;
    usBlkSprInfo.u16Spr8.us2BYTE.LowByte=cInfoBlockID;
    usBlkSprInfo.u16Spr11.u16all=u16EraseCnt;

    setSprByte(&usBlkSprInfo, uPlaneAddr);
}    /* setSprByteOfIspBlk */

void remSlcSortQ(WORD u16FBlock)
{
#if _EN_VPC_SWAP
    if(g16DataBlkCnt==0)
    {
        NLOG(cLogCore1, MAINCORE1_C, 1, "DataBlkCnt=0! u16FBlock=0x%04X", u16FBlock);
#if _EN_KEEP_RW_ON_ERROR    // 20190528_Louis_04
        g16DataBlkCnt++;
#else
        while(1)
            ;
#endif
    }

    g16DataBlkCnt--;
    g16SlcSortQCnt=g16DataBlkCnt;
#if 0    // _EN_512Gb_Debug
    NLOG(cLogTempDebug, MAINCORE1_C, 1, "mClrDataBlockBit: Block=0x%04x", u16FBlock);
#endif
    mClrDataBlockBit(u16FBlock);

    if(gFor512GbDebug)    // 20190528_Louis_04
    {
        NLOG(cLogHost, MAINCORE1_C, 1, "mClrDataBlockBit issue: Have been cleared! u16Fblock=0x%04x", u16FBlock);
        gFor512GbDebug=0;
    }

#if _EN_512Gb_Debug
    NLOG(cLogCore1,
         MAINCORE1_C,
         4,
         "After remSlcSortQ! u16FBlock=0x%04X, g16SlcSortQCnt=0x%04X, g16DataBlkCnt=0x%04X, FullCacheBlockCnt=0x%04X",
         u16FBlock,
         g16SlcSortQCnt,
         g16DataBlkCnt,
         gsCacheInfo.u16FullCacheBlockCnt);
#endif
#else/* if _EN_VPC_SWAP */
    BYTE uSrcIdx;
    volatile LINKINFO *upDelLlInfo;
    WORD u16PrevNodeIdx, u16NextNodeIdx;

    while(u16FBlock>=g16TotalFBlock)
        ;

    uSrcIdx=gSlcSortQIdx[u16FBlock];

    if(uSrcIdx==0xFF)
    {
        gsFtlDbg.u16DummyFailType=cRemSlcSortQ;
        debugWhile();
    }
    else
    {
        while(gsSlcSortQList.u16Cnt==0)
            ;

        g16SlcSortQFBlk[uSrcIdx]=0xFFFF;
        gSlcSortQIdx[u16FBlock]=0xFF;

        upDelLlInfo=&gsSlcSortQList;
        mDelNode(u16PrevNodeIdx, garSlcSortQLink, uSrcIdx, u16NextNodeIdx, upDelLlInfo);
        garFreeSlcSortQ[g32FreeSlcSortQTail]=uSrcIdx;
        g32FreeSlcSortQTail=addPtrBy1(g32FreeSlcSortQTail, cMaxSlcBlkQ);
        g16SlcSortQCnt=gsSlcSortQList.u16Cnt;    // 20181223_Bruce
    }

    // debug Slc sort queue not correct
    while((gsSlcSortQList.u16Head>cNull)||(gsSlcSortQList.u16Tail>cNull)||(gsSlcSortQList.u16Trig>cNull))
        ;
#endif/* if _EN_VPC_SWAP */
}    /* remSlcSortQ */

void insSlcSortQ(WORD u16FBlock)
{
#if _EN_VPC_SWAP
    if(g16DataBlkCnt>=g16TotalFBlock)
    {
        NLOG(cLogCore1, MAINCORE1_C, 1, "DataBlkCnt>=TotalFBlock! u16FBlock=0x%04X", u16FBlock);
#if _EN_KEEP_RW_ON_ERROR    // 20190528_Louis_04
        WORD u16RescanSLCQCnt=0;    // g16DataBlkCnt=g16TotalFBlock;  //20190618_Louis_02

        for(WORD u16Blk=0; u16Blk<g16TotalFBlock; u16Blk++)
        {
            if(mChkDataBlockBit(u16Blk))
            {
                u16RescanSLCQCnt++;
            }
        }

        g16DataBlkCnt=u16RescanSLCQCnt;
#else
        while(1)
            ;
#endif
    }

#if 0    // _EN_512Gb_Debug
    NLOG(cLogTempDebug, MAINCORE1_C, 1, "mSetDataBlockBit: Block=0x%04x", (WORD)u16FBlock);
#endif
    mSetDataBlockBit(u16FBlock);

    if(gFor512GbDebug)
    {
        NLOG(cLogHost, MAINCORE1_C, 1, "mSetDataBlockBit issue: Have been set! u16Fblock=0x%04x", u16FBlock);
        gFor512GbDebug=0;
    }

    g16DataBlkCnt++;    // 20181223_Bruce
    g16SlcSortQCnt=g16DataBlkCnt;

#if _EN_512Gb_Debug
    NLOG(cLogCore1,
         MAINCORE1_C,
         4,
         "After insSlcSortQ! u16FBlock=0x%04X, g16SlcSortQCnt=0x%04X, g16DataBlkCnt=0x%04X, FullCacheBlockCnt=0x%04X",
         u16FBlock,
         g16SlcSortQCnt,
         g16DataBlkCnt,
         gsCacheInfo.u16FullCacheBlockCnt);
#endif
#else/* if _EN_VPC_SWAP */
    WORD u16PrevNodeIdx, u16NextNodeIdx, u16NowNodeIdx;
    volatile LINKINFO *upInsLlInfo;

#if _EN_Liteon_ErrHandle
    if(gJdgBootGCFlag&(cBootSLCQGC))
    {
        while(gsSlcSortQList.u16Cnt==cMaxSlcBlkQ)
            ;
    }
    else
    {
        while(gsSlcSortQList.u16Cnt==(cMaxSlcBlkQ-2))
            ;
    }
#else
    while(gsSlcSortQList.u16Cnt==cMaxSlcBlkQ)
        ;
#endif

    while(u16FBlock>=g16TotalFBlock)
        ;

    u16NowNodeIdx=garFreeSlcSortQ[g32FreeSlcSortQHead];

    g16SlcSortQFBlk[u16NowNodeIdx]=u16FBlock;

    gSlcSortQIdx[u16FBlock]=u16NowNodeIdx;

    g32FreeSlcSortQHead=addPtrBy1(g32FreeSlcSortQHead, cMaxSlcBlkQ);
    upInsLlInfo=&gsSlcSortQList;
    mInsNode(u16PrevNodeIdx, upInsLlInfo, u16NextNodeIdx, garSlcSortQLink, u16NowNodeIdx);
    g16SlcSortQCnt=gsSlcSortQList.u16Cnt;    // 20181223_Bruce

    // debug Slc sort queue not correct
    while((gsSlcSortQList.u16Head>cNull)||(gsSlcSortQList.u16Tail>cNull)||(gsSlcSortQList.u16Trig>cNull))
        ;
#endif/* if _EN_VPC_SWAP */
}    /* insSlcSortQ */

void pushWLReadReclaimQ(WORD u16FBlock, BYTE uReason)
{
    BYTE uLoop;

    if(!mChkPushReClaimQBit(u16FBlock))
    {
        // if(uReason!=cDoWearLeveling)
        // {
#if (C_Log_SaveMask&C_Debug_P2)
        NLOG(cLogCore1, MAINCORE1_C, 2, "pushWLReadReclaimQ uReason: 0x%04X , u16FBlock: 0x%04X", uReason, u16FBlock);
#endif
        // }

        if(!mChkSkipGcSrch(u16FBlock))
        {
            if(mChkMlcMoBit(u16FBlock))
            {
                if((gsGcInfo.uGcPrioTlcBlkNumPtr<cMaxGcPrioBlkNum))
                {
                    gsGcInfo.u16Gc1stPrioTlcBlock[gsGcInfo.uGcPrioTlcBlkNumPtr]=u16FBlock;
                    gsGcInfo.uGc1stPrioTlcBlockTyp[gsGcInfo.uGcPrioTlcBlkNumPtr]=uReason;
                    gsGcInfo.uGcPrioTlcBlkNumPtr++;
                }

                if(uReason!=cDoWearLeveling)
                {
                    gsFtlDbg.u16ReclaimCnt++;
                }
            }
            else
            {
                if(gsGcInfo.uGCSLCReclaimPtr<cMaxGcPrioBlkNum)
                {
                    gsGcInfo.u16GcRCSlcBlock[gsGcInfo.uGCSLCReclaimPtr]=u16FBlock;
                    gsGcInfo.uGCSLCReclaimPtr++;
                    gsFtlDbg.u16SLCReclaimCnt++;
                }
            }
        }

        if(((uReason==cDoSoftRetry)||(uReason==cTouchRdCntThr)))
        {
#if _EN_SLCOpenBlkReadScrub
            if(((u16FBlock==gsCacheInfo.u16ActiveCacheBlock)||(u16FBlock==gsCacheInfo.u16FluCacheBlock))&&(mGetGcFlushState==cFlushIdle))
            {
                gsGcInfo.u16FlushBlk=u16FBlock;
                mSetGcFlag(cFlushforReclaim);
                mSetGcFlushState(cWriteDummy);
                gsFtlDbg.u16SLCFlushCnt++;
            }
            else if(!mChkSkipGcSrch(u16FBlock)||mChkGcSrcBlkBmap(u16FBlock))
            {
                mSetGcFlag(cUnderReclaim);
            }
            else if(!mChkGcFlag(cReadScrubH2F))
            {
                for(uLoop=0; uLoop<gMaxH2fTabBlkNum; uLoop++)
                {
                    if(g16arH2fTabBlk[uLoop]==u16FBlock)
                    {
                        gsGcInfo.u16H2FReclaimBlk=u16FBlock;
                        mSetGcFlag(cReadScrubH2F);
                        gsFtlDbg.u16H2FScrubCnt++;
                        uLoop=gMaxH2fTabBlkNum;
                    }
                }
            }
#else/* if _EN_SLCOpenBlkReadScrub */
            if(!mChkSkipGcSrch(u16FBlock))
            {
                mSetGcFlag(cUnderReclaim);
            }
#endif/* if _EN_SLCOpenBlkReadScrub */
        }

        mSetPushReClaimQBit(u16FBlock);
#if (_GREYBOX)
        if((gsGbInfo.uGreyBoxItem==cUGSDReclaimID)&&(mChkMlcMoBit(u16FBlock)))
        {
            if((*(WORD *)(c32GreyBoxBuf+cGbInfoReclimFBlk1))==0)
            {
                *(WORD *)(c32GreyBoxBuf+cGbInfoReclimFBlk1)=u16FBlock;
                // outString("cGbInfoReclimFBlk1 =@", (*(WORD *)(c32GreyBoxBuf+cGbInfoReclimFBlk1)));
            }
            else if((*(WORD *)(c32GreyBoxBuf+cGbInfoReclimFBlk2))==0)
            {
                *(WORD *)(c32GreyBoxBuf+cGbInfoReclimFBlk2)=u16FBlock;
                // outString("cGbInfoReclimFBlk2 =@", (*(WORD *)(c32GreyBoxBuf+cGbInfoReclimFBlk2)));
            }
            else if((*(WORD *)(c32GreyBoxBuf+cGbInfoReclimFBlk3))==0)
            {
                *(WORD *)(c32GreyBoxBuf+cGbInfoReclimFBlk3)=u16FBlock;
                // outString("cGbInfoReclimFBlk3 =@", (*(WORD *)(c32GreyBoxBuf+cGbInfoReclimFBlk3)));
            }
        }
        else if(gsGbInfo.uGreyBoxItem==cFtlRuleReadReclaimID)
        {
            g16GbGetReclaimBlk=g16FBlock;
        }
#endif/* if (_GREYBOX) */
    }

    while(u16FBlock>g16TotalFBlock)
        ;
}    /* pushReadReclaimQ */

void chkPopWLReadReclaimQ(WORD u16FBlock)
{
    BYTE uLoop1=0, uLoop2=0;

    mSetGlobReadCnt(u16FBlock, 0);

#if _EN_VPC_SWAP
    if(mChkDataBlockBit(u16FBlock)&&!mChkMlcMoBit(u16FBlock))
    {
        remSlcSortQ(u16FBlock);
    }
#else
    if(gSlcSortQIdx[u16FBlock]!=0xFF)
    {
        remSlcSortQ(u16FBlock);
    }
#endif

    if(mChkPushReClaimQBit(u16FBlock))
    {
        if(mChkMlcMoBit(u16FBlock))
        {
            if(gsGcInfo.uGcPrioTlcBlkNumPtr)
            {
                for(uLoop1=0; uLoop1<gsGcInfo.uGcPrioTlcBlkNumPtr; uLoop1++)
                {
                    if(gsGcInfo.u16Gc1stPrioTlcBlock[uLoop1]==u16FBlock)
                    {
                        gsGcInfo.uGcPrioTlcBlkNumPtr--;

                        for(uLoop2=uLoop1; uLoop2<gsGcInfo.uGcPrioTlcBlkNumPtr; uLoop2++)
                        {
                            gsGcInfo.u16Gc1stPrioTlcBlock[uLoop2]=gsGcInfo.u16Gc1stPrioTlcBlock[uLoop2+1];
                            gsGcInfo.uGc1stPrioTlcBlockTyp[uLoop2]=gsGcInfo.uGc1stPrioTlcBlockTyp[uLoop2+1];
                        }

                        gsGcInfo.u16Gc1stPrioTlcBlock[gsGcInfo.uGcPrioTlcBlkNumPtr]=0xFFFF;
                        gsGcInfo.uGc1stPrioTlcBlockTyp[gsGcInfo.uGcPrioTlcBlkNumPtr]=0xFF;
                    }
                }
            }
        }
        else
        {
            if(gsGcInfo.uGCSLCReclaimPtr)
            {
                for(uLoop1=0; uLoop1<gsGcInfo.uGCSLCReclaimPtr; uLoop1++)
                {
                    if(gsGcInfo.u16GcRCSlcBlock[uLoop1]==u16FBlock)
                    {
                        gsGcInfo.uGCSLCReclaimPtr--;

                        for(uLoop2=uLoop1; uLoop2<gsGcInfo.uGCSLCReclaimPtr; uLoop2++)
                        {
                            gsGcInfo.u16GcRCSlcBlock[uLoop2]=gsGcInfo.u16GcRCSlcBlock[uLoop2+1];
                        }

                        gsGcInfo.u16GcRCSlcBlock[gsGcInfo.uGCSLCReclaimPtr]=0xFFFF;
                    }
                }
            }
        }

        mClrPushReClaimQBit(u16FBlock);
    }
}    /* chkPopReadReclaimQ */

BYTE hostRequsetCore1(void)
{
    return (rmChkCmdRdy)&&(rmChkCcRdy);
}

/*
   * void chkReadCntInBg()
   * {
   *  BYTE uLoop=cChkRdCntLoop;    // check change -5, check nothing -1
   *
   *  do
   *  {
   *      if(g32arGlobReadCnt[gsRdCntCtrl.u16ChkFBlkPtr]&c64ChgReadCntBit)
   *      {
   *          g32arGlobReadCnt[gsRdCntCtrl.u16ChkFBlkPtr]&=~c64ChgReadCntBit;
   *
   *          if(g32arGlobReadCnt[gsRdCntCtrl.u16ChkFBlkPtr]>c64SlcClosedBlkVpcThr)
   *          {
   *              if(pushReadReclaimQ(gsRdCntCtrl.u16ChkFBlkPtr, cTouchRdCntThr))
   *              {
   *                  uLoop=1;    // let it exit
   *              }
   *          }
   *
   *          if(uLoop<cChkRdCntRatio)
   *          {
   *              uLoop=1;
   *          }
   *          else
   *          {
   *              uLoop-=(cChkRdCntRatio-1);
   *          }
   *      }
   *
   *      uLoop--;
   *
   *      gsRdCntCtrl.u16ChkFBlkPtr++;
   *
   *      if(gsRdCntCtrl.u16ChkFBlkPtr==g16TotalFBlock)
   *      {
   *          gsRdCntCtrl.u16ChkFBlkPtr=g16FirstFBlock;
   *          gsRdCntCtrl.u16ChkRdCnt=c16ChkRdCntFreq;
   *      }
   *  }
   *  while(uLoop);
   * } */   /* chkReadCntInBg */

void setHwPrdCore1()
{
    PRDQUEUE *upPrdInfo;
    LWORD u32SctrCnt, u32TrigWrCmdTrig=gsPrdInfo.u32TrigWrCmdTrig;
    LWORD u32PrdOpt=0;
    BYTE uHwPrdIdx;

    do
    {
        upPrdInfo=&gsPrdInfo.uarPrdQue[gsPrdInfo.uarSeqPrdQue[u32TrigWrCmdTrig]];
        uHwPrdIdx=upPrdInfo->uHwPrdIdx;
        u32SctrCnt=upPrdInfo->u32SctrCnt;

        if(gbEnAes)
        {
            rmAesMode;
            u32PrdOpt|=cAes;
        }

        if(upPrdInfo->ubSetOccF)
        {
#if _ENABLE_RAID
            r32NvmePrd[uHwPrdIdx][0]=cLastPrd|cTsb|cAutoRaidFlag|cSetTsbOccFlag|u32PrdOpt;
#else
            r32NvmePrd[uHwPrdIdx][0]=cLastPrd|cTsb|cAutoBufflag|cSetTsbOccFlag|u32PrdOpt;
#endif

            if(mChkDummyWrite&&(upPrdInfo->uOpCode==cNvmeCmdWrite))
            {
                r32NvmePrd[uHwPrdIdx][0]&=~(cAutoBufflag|cAutoRaidFlag|cSetTsbOccFlag);
            }

            r32NvmePrd[uHwPrdIdx][3]=(upPrdInfo->u16BufPtr&~(cSctrPer4k-1));

            // setFwPreOccuFlag(upPrdInfo->u16BufPtr); //Finn Fw Occupy use at cpu0
        }
        else
        {
#if _ENABLE_RAID
            r32NvmePrd[uHwPrdIdx][0]=cLastPrd|cTsb|cAutoRaidFlag|u32PrdOpt;
#else
            r32NvmePrd[uHwPrdIdx][0]=cLastPrd|cTsb|cAutoBufflag|u32PrdOpt;
#endif

            if(mChkDummyWrite&&(upPrdInfo->uOpCode==cNvmeCmdWrite))
            {
                r32NvmePrd[uHwPrdIdx][0]&=~(cAutoBufflag|cAutoRaidFlag|cSetTsbOccFlag);
            }

            r32NvmePrd[uHwPrdIdx][3]=0;
        }

        r32NvmePrd[uHwPrdIdx][1]=upPrdInfo->u16BufPtr;
        r32NvmePrd[uHwPrdIdx][5]=u32SctrCnt;
        r32NvmePrd[uHwPrdIdx][6]=upPrdInfo->u32LbaAddr;
        r32NvmeDesc[uHwPrdIdx][2]=upPrdInfo->u32Prp1L;
        r32NvmeDesc[uHwPrdIdx][3]=upPrdInfo->u32Prp1H;
        r32NvmeDesc[uHwPrdIdx][6]=(u32SctrCnt<<7);
        r32NvmeDesc[uHwPrdIdx][7]=((upPrdInfo->u16SqId<<16)|upPrdInfo->u16Cid);

        if(upPrdInfo->uSgl)
        {
            r32NvmeDesc[uHwPrdIdx][1]=(c32Bit25|c32Bit24);
        }
        else
        {
            if(upPrdInfo->u32Prp2L||upPrdInfo->u32Prp2H)
            {
                r32NvmeDesc[uHwPrdIdx][4]=upPrdInfo->u32Prp2L;
                r32NvmeDesc[uHwPrdIdx][5]=upPrdInfo->u32Prp2H;
                r32NvmeDesc[uHwPrdIdx][1]=c32Bit25;
            }
            else
            {
                r32NvmeDesc[uHwPrdIdx][1]=0x00000000;
            }
        }

        if(upPrdInfo->uFua&cHdlNvmeFlush)    // 20190417_ChrisSu
        {
            r32NvmeDesc[uHwPrdIdx][0]=c32ManualDmaTrigW;
        }
        else
        {
            r32NvmeDesc[uHwPrdIdx][0]=c32AutoDmaTrigW;
        }

        u32TrigWrCmdTrig=((u32TrigWrCmdTrig+1)&(cSeqPrdDepth-1));
    }
    while(u32TrigWrCmdTrig!=gsPrdInfo.u32TrigWrCmdTail);

    gsPrdInfo.u32TrigWrCmdTrig=u32TrigWrCmdTrig;
}    /* setHwPrdCore1 */

WORD getDiffFBlock(WORD u16FBlock, BYTE uCh, BYTE uIntlvIdx, BYTE uPlaneIdx)
{
    if(g16arDiffOffset[u16FBlock]!=0xffff)
    {
        u16FBlock=getDiffAddr(u16FBlock, uCh, uIntlvIdx, uPlaneIdx);
    }

    return u16FBlock;
}

void setMarkBadBlock(ADDRINFO *upTmpAddrInfo, BYTE uFailId)
{
#if _EN_TEST_RAID_DECODE
    return;
#endif

    if(gsBadInfo.uRdEccFailQueCnt<cEccFailQuedpth)
    {
        NLOG(cLogCore1, MAINCORE1_C, 0, "setMarkBadBlock :");
#if _DEBUG_LOG
        printNandPhyAddr(upTmpAddrInfo);
#endif
        gsBadInfo.uarEccFailQue[gsBadInfo.uRdEccFailQueCnt].u16Fblock=upTmpAddrInfo->u16AbstractFBlock;

        // gsBadInfo.uarEccFailQue[gsBadInfo.uRdEccFailQueCnt].u16Fpage=upTmpAddrInfo->u16FPage;
        if(!(mChkMlcMoBit(upTmpAddrInfo->u16AbstractFBlock)))
        {
            if(mChkFLParam(cWithRlibMo))
            {
                gsBadInfo.uarEccFailQue[gsBadInfo.uRdEccFailQueCnt].u16Fpage=upTmpAddrInfo->u16FPage;
            }
            else if(mChkCardMode(cWithSlcMo))
            {
                gsBadInfo.uarEccFailQue[gsBadInfo.uRdEccFailQueCnt].u16Fpage=(upTmpAddrInfo->u16FPage<<1);
            }
        }
        else
        {
#if (_TSB_BiCS3|_SANDISK_3D_GEN2|_SANDISK_3D_GEN3|_TSB_BiCS4)
            gsBadInfo.uarEccFailQue[gsBadInfo.uRdEccFailQueCnt].u16Fpage=
                ((cProgCntPerWL*(upTmpAddrInfo->u16FPage))+mGetPageSelCmd(upTmpAddrInfo)-1);
#endif
        }

        gsBadInfo.uarEccFailQue[gsBadInfo.uRdEccFailQueCnt].u16EraseCnt=mGetGlobEraseCnt(upTmpAddrInfo->u16AbstractFBlock);
        gsBadInfo.uarEccFailQue[gsBadInfo.uRdEccFailQueCnt].uCh=upTmpAddrInfo->uCh;
        gsBadInfo.uarEccFailQue[gsBadInfo.uRdEccFailQueCnt].uPlaneAddr=upTmpAddrInfo->uPlaneAddr;
        gsBadInfo.uarEccFailQue[gsBadInfo.uRdEccFailQueCnt].uIntlvAddr=upTmpAddrInfo->uIntlvAddr;
#if _ENABLE_THERMAL
        gsBadInfo.uarEccFailQue[gsBadInfo.uRdEccFailQueCnt].uTemperture=gThsor0TemperatureBk;
#else
        gsBadInfo.uarEccFailQue[gsBadInfo.uRdEccFailQueCnt].uTemperture=63;    // the mark of 22"63"
#endif
        gsBadInfo.uarEccFailQue[gsBadInfo.uRdEccFailQueCnt].uFailID=uFailId;
        gsBadInfo.uarEccFailQue[gsBadInfo.uRdEccFailQueCnt].uRaidDecFail=cFalse;

        gsBadInfo.uRdEccFailQueCnt++;
        mSetBadInfoFlag(cBadInfoChg);    // gsBadInfo.ubBadInfoChg=1;

// Hacker
#if (!_EN_PWR_EccOverThrChk)
        if(uFailId!=cTLCRdEccFailID)
#else
        if(uFailId!=cS2TPWRFailID)
#endif
        {
            BYTE uNeedPop=0;

            // prevent program fail block reuse.
            if((uFailId==cProgFailReProgID)||(uFailId==cProgFailGcDesID)||(uFailId==cProgFailWproID)||(uFailId==cProgFailParityID))
            {
                uNeedPop=1;
            }

            if(((uFailId&cMarkBadID_Filter)!=cProgFailHighID)||uNeedPop)
            {
                // mSetPoppedBit(upTmpAddrInfo->u16AbstractFBlock);
                mSetPoppedBit(upTmpAddrInfo->u16AbstractFBlock);
                mSetGlobEraseCnt(upTmpAddrInfo->u16AbstractFBlock, c16BitFF);
            }
        }
    }

    // while (1);
}    /* setMarkBadBlock */

void chkPfFblockProc(BYTE uCh)
{
    if(!mChkCacheInfoFlag(cDataProgramFail)&&(g32Core1State==cCore1BootState_Finished))
    {
        mCallFuncPtr2Core1(cchkPfFblock, uCh);    // chkPfFblock(uCh);
    }
    else
    {
        mSetCacheInfoFlag(cMoveProgramFail);

        setFLActCh(uCh);

        while(rmChkCmdFifoBz)
            ;

        if(rmChkStatusFail)
        {
#if _DEBUG_LOG
            NLOG(cLogCore1, MAINCORE1_C, 0, "Program Fail in Core1BootState!!");
#endif
            rmResetEccSts;
            rmCmdQueResume;

            while(rmChkCmdFifoBz)
                ;
        }
    }
}    /* chkPfFblockProc */

void deleteGcSrcBlk(BYTE uInvalidBlkPtr)
{
    BYTE uEmptyGcSrcBlkIdx=gsGcInfo.uGcSrcBlkIdx[uInvalidBlkPtr];
    BYTE uNowBlkPtr=uInvalidBlkPtr;

    mGet16GcSrcBlock(uInvalidBlkPtr)|=c16Bit15;    // Easy to see which Blk was deleted

    while(uNowBlkPtr<(gsGcInfo.uGcSrcBlkCnt-1))
    {
        gsGcInfo.uGcSrcBlkIdx[uNowBlkPtr]=gsGcInfo.uGcSrcBlkIdx[uNowBlkPtr+1];
        uNowBlkPtr++;
    }

    gsGcInfo.uGcSrcBlkIdx[uNowBlkPtr]=uEmptyGcSrcBlkIdx;
    gsGcInfo.uGcSrcBlkCnt--;
}

WORD AvgECForCore1(BYTE u8Mode)
{
    WORD u16Fblk, u16TlcIdx=0, u16SlcIdx=0;
    WORD u16MaxTlcEraseCnt=0, u16MaxSlcEraseCnt=0;
    WORD u16MinTlcEraseCnt=0xFFFF, u16MinSlcEraseCnt=0xFFFF;
    LWORD u32SumTlcEraseCnt=0, u32SumSlcEraseCnt=0;
    WORD u16AvgEC=0;

    for(u16Fblk=g16FirstFBlock; u16Fblk<g16TotalFBlock; u16Fblk++)
    {
        if(g16arGlobEraseCnt[u16Fblk]!=0xFFFF)
        {
            if(u16Fblk>=g16StaticBound)
            {
                u16TlcIdx++;
                u32SumTlcEraseCnt+=g16arGlobEraseCnt[u16Fblk];

                if(g16arGlobEraseCnt[u16Fblk]>u16MaxTlcEraseCnt)
                {
                    u16MaxTlcEraseCnt=g16arGlobEraseCnt[u16Fblk];
                }
                else if(g16arGlobEraseCnt[u16Fblk]<u16MinTlcEraseCnt)
                {
                    u16MinTlcEraseCnt=g16arGlobEraseCnt[u16Fblk];
                }
            }
            else
            {
                u16SlcIdx++;
                u32SumSlcEraseCnt+=g16arGlobEraseCnt[u16Fblk];

                if(g16arGlobEraseCnt[u16Fblk]>u16MaxSlcEraseCnt)
                {
                    u16MaxSlcEraseCnt=g16arGlobEraseCnt[u16Fblk];
                }
                else if(g16arGlobEraseCnt[u16Fblk]<u16MinSlcEraseCnt)
                {
                    u16MinSlcEraseCnt=g16arGlobEraseCnt[u16Fblk];
                }
            }
        }
    }

    if(u8Mode==1)
    {
        if(u16TlcIdx==0)
        {
            u16AvgEC=0;
        }
        else
        {
            u16AvgEC=u32SumTlcEraseCnt/u16TlcIdx;
        }
    }
    else if(u8Mode==0)
    {
        if(u16SlcIdx==0)
        {
            u16AvgEC=0;
        }
        else
        {
            u16AvgEC=u32SumSlcEraseCnt/u16SlcIdx;
        }
    }
    else
    {}

    return u16AvgEC;
}    /* AvgECForCore1 */

#if _EN_RAID_DECODE
void doRaidDecodeSwap()
{
    if(mChkRaidDecF(cRaidDecOptMsk)==cRaidEnableDecode)
    {
        BYTE uIntlvAddr, uCh, uEnLdpcPipe=gEnableLdpcPipe;

#if _GREYBOX
        if((gsGbInfo.uGreyBoxItem==cRAIDDecOnH2fTab)||(gsGbInfo.uGreyBoxItem==cRAIDDecOnH2f1kTab)\
           ||(gsGbInfo.uGreyBoxItem==cRAIDDecOnNormData)||(gsGbInfo.uGreyBoxItem==cRAIDDecOnOpenData)\
           ||(gsGbInfo.uGreyBoxItem==cRAIDDecOnPreReadData)||(gsGbInfo.uGreyBoxItem==cRAIDDecOnLastReadData)\
           ||(gsGbInfo.uGreyBoxItem==cRAIDDecOnMoveReadData)||
           ((gsGbInfo.uGreyBoxItem==cSecurityRW)&&(gsGbInfo.uGreyBoxOpt&0x01)&&(gsGbInfo.uGreyBoxOpt&0x2)))
        {
            gReadErrinjectEn=cTrue;
            g16GbRetryTabLoop=c16BitFF;
            gsGbInfo.uStag=cVsInit;
        }
#endif

#if _EN_CacheR
        for(uIntlvAddr=0; uIntlvAddr<gIntlvWay; uIntlvAddr++)
        {
            for(uCh=0; uCh<gTotalChNum; uCh++)
            {
#if  _EN_MutiWayCacheRImprove
                if(gsRwCtrl.uEnCacheR&&
                   ((gsRwCtrl.usWaitInfo[uCh][uIntlvAddr].uWaitFlag==cCacheRCmd)||
                    (gsRwCtrl.usWaitInfo[uCh][uIntlvAddr].uWaitFlag==cCacheRCmd1)||
                    (gsRwCtrl.usWaitInfo[uCh][uIntlvAddr].uWaitFlag==cCache3FCmd)))
#else
                if(gsRwCtrl.uEnCacheR&&
                   ((gsRwCtrl.usWaitInfo[uCh][uIntlvAddr].uWaitFlag==cCacheRCmd)||
                    (gsRwCtrl.usWaitInfo[uCh][uIntlvAddr].uWaitFlag==cCacheRCmd1)))
#endif

                {
                    setFLActCh(uCh);
                    rmCeOn(mGetCEAddr(uIntlvAddr));
                    rmSetDieBit(mGetDieAddr(uIntlvAddr));
                    pollStatus(cPollMaskNor);
#if  _EN_MutiWayCacheRImprove
                    if(gsRwCtrl.usWaitInfo[uCh][uIntlvAddr].uWaitFlag!=cCache3FCmd)
#endif
                    {
                        rmCle(gLastPageCacheReadCmd);
                        pollStatus(cPollMaskNor);
                    }

                    rmAllCeOff;
                    mWaitCmdFifoBz;
                }
            }
        }
#endif/* if _EN_CacheR */

        mSetRaidDecF(cRaidDecodeMode);

#if _ENABLE_LDPCPIPELINE
        waitAllChCeBz();

        if(uEnLdpcPipe)
        {
            funcTskDisLdpcPipe(0);
        }
#endif
        mSetRaidDecF(cRaidUnderDecode);

        // uIspMode=mChkISPC1Mode;

        // if(uIspMode!=cRwIsp1)
        // {
        //     loadIspCode(cRwIsp1, 1);
        // }
        doRaidDecode();    // mCallFuncPtrCore1(cdoRaidDecode);
        // if(uIspMode!=cRwIsp1)
        // {
        //     loadIspCode(uIspMode, 1);
        // }

#if _ENABLE_LDPCPIPELINE
        waitAllChCeBz();

        if(uEnLdpcPipe)
        {
            funcTskEnLdpcPipe(0);
        }
#endif

        mClrRaidDecF(cRaidEnableDecode);
        mClrRaidDecF(cRaidUnderDecode);
        mClrRaidDecF(cRaidDecodeMode);
        g32DecodeWait=cFalse;

        for(uIntlvAddr=0; uIntlvAddr<gIntlvWay; uIntlvAddr++)
        {
            for(uCh=0; uCh<gTotalChNum; uCh++)
            {
                postFlashPreCmdAle(uCh, uIntlvAddr);
            }
        }
    }
}    /* doRaidDecodeSwap */

#endif/* if _EN_RAID_DECODE */
#if 0
void saveQBInfowithDummy(BYTE uFailType)
{
    if(mChkDummyWrite)
    {
        return;
    }

    if(uFailType!=0xFF)
    {
        gsFtlDbg.u16DummyFailType=uFailType;
    }

    gsCacheInfo.ubEnDualCoreFlush=cFalse;
    // bopClrRam((LWORD)0x40000000, 384*1024, 0x00000000, cBopWait|cClrTsb);
    // *(WORD *)garTsb0[0x290]=g16DummyFailType;
    gPowerDownMode=cGSD;
    progWproPage(cWproQBWithDumyW, c16Tsb0SIdx);
    waitAllChCeBz();
    mClrSaveDummyInfo;
    rmResetRaidFlg;
    rmResetBufFlg;
    rmResetOccupyFlg;
    gsCacheInfo.u32ModifyH2fPtrHead=gsCacheInfo.u32ModifyH2fPtrTail;
    mSetGcFlag(cBrkBgdGcF);
    gsRwCtrl.u16OccFSkipSize=0;
    gsRwCtrl.u16OccFSkipStBufPtr=0;

    while(1)
        ;
}    /* saveQBInfowithDummy */

#endif/* if 0 */
#pragma default_function_attributes =







