







#include <stdio.h>
#include "inc/Option.h"
#include "inc/TypeDef.h"
#include "inc/Reg.h"
#include "inc/GlobVar0.h"
#include "inc/BitDef.h"
#include "inc/ProType.h"
#include "inc/ROM_code.txt"

void spiStsSetting()
{
    rmSpiEn;
    rmSpiWrite(0x06);    // write-status cmd
    rmSpiDis;

    rmSpiEn;
    rmSpiWrite(0x01);    // write-status cmd
    rmSpiWrite(0x00);    // write status (disable all protect)
    rmSpiDis;
}

void spiReadSts()
{
    BYTE uStatusBusy;

    rmSpiEn;
    rmSpiWrite(0x05);    // read-status cmd
    uStatusBusy=1;

    while(uStatusBusy)
    {
        rmSpiRead(0xFF);    // Write this byte to start rx data from SPI flash

        uStatusBusy=rBvacCtrl[rcSpiInData];
        uStatusBusy=uStatusBusy&0x01;
    }

    rmSpiDis;
}    /* spiReadSts */

void spiChipErase()
{
    rmSpiEn;
    rmSpiWrite(0x06);    // write-enable cmd
    rmSpiDis;

    rmSpiEn;
    rmSpiWrite(0xC7);    // chip erase cmd
    rmSpiDis;
    spiReadSts();    // read status
}

void spiPageErase()
{
    rmSpiEn;
    rmSpiWrite(0x06);    // write-enable cmd
    rmSpiDis;

    rmSpiEn;
    rmSpiWrite(0x42);    // page erase cmd
    rmSpiWrite(0x00);    // erase addr
    rmSpiWrite(0x00);    // erase addr
    rmSpiDis;
    spiReadSts();    // read status

    rmSpiEn;
    rmSpiWrite(0x06);    // write-enable cmd
    rmSpiDis;

    rmSpiEn;
    rmSpiWrite(0x42);    // page erase cmd
    rmSpiWrite(0x00);    // erase addr
    rmSpiWrite(0x40);    // erase addr
    rmSpiDis;
    spiReadSts();    // read status
}    /* spiPageErase */

BYTE spiReadCompare(LWORD u32ReadSize, BYTE *upCmpPtr)
{
    LWORD u32Idx;

    rmSpiEn;

    rmSpiWrite(0x03);    // read cmd
    rmSpiWrite(0x00);    // read addr
    rmSpiWrite(0x00);    // read addr

    for(u32Idx=0; u32Idx<u32ReadSize; u32Idx+=4)
    {
        rmSpiRead(0xFF);
        garTsb0[u32Idx/512][(u32Idx%512)]=rBvacCtrl[rcSpiInData];

        if(rBvacCtrl[rcSpiInData]!=upCmpPtr[u32Idx+0])
        {
            rmSpiDis;
            return 1;
        }

        rmSpiRead(0xFF);
        garTsb0[u32Idx/512][(u32Idx+1)%512]=rBvacCtrl[rcSpiInData];

        if(rBvacCtrl[rcSpiInData]!=upCmpPtr[u32Idx+1])
        {
            rmSpiDis;
            return 1;
        }

        rmSpiRead(0xFF);
        garTsb0[u32Idx/512][(u32Idx+2)%512]=rBvacCtrl[rcSpiInData];

        if(rBvacCtrl[rcSpiInData]!=upCmpPtr[u32Idx+2])
        {
            rmSpiDis;
            return 1;
        }

        rmSpiRead(0xFF);
        garTsb0[u32Idx/512][(u32Idx+3)%512]=rBvacCtrl[rcSpiInData];

        if(rBvacCtrl[rcSpiInData]!=upCmpPtr[u32Idx+3])
        {
            rmSpiDis;
            return 1;
        }
    }

    rmSpiDis;
    return 0;
}    /* spiReadCompare */

BYTE spiReadPatCompare(LWORD u32ReadSize)
{
    LWORD u32Idx;

    rmSpiEn;

    rmSpiWrite(0x03);    // read cmd
    rmSpiWrite(0x00);    // read addr
    rmSpiWrite(0x00);    // read addr

    for(u32Idx=0; u32Idx<u32ReadSize; u32Idx+=4)
    {
        rmSpiRead(0xFF);

        if(rBvacCtrl[rcSpiInData]!=0x5A)
        {
            rmSpiDis;
            return 1;
        }

        rmSpiRead(0xFF);

        if(rBvacCtrl[rcSpiInData]!=0xA5)
        {
            rmSpiDis;
            return 1;
        }

        rmSpiRead(0xFF);

        if(rBvacCtrl[rcSpiInData]!=0x36)
        {
            rmSpiDis;
            return 1;
        }

        rmSpiRead(0xFF);

        if(rBvacCtrl[rcSpiInData]!=0xBD)
        {
            rmSpiDis;
            return 1;
        }
    }

    rmSpiDis;
    return 0;
}    /* spiReadPatCompare */

void spiProgRom(LWORD u32WriteSize, BYTE *upDataPtr)
{
    LWORD u32Idx, u32Idx1;
    BYTE uIdx;

    for(u32Idx=0; u32Idx<u32WriteSize; u32Idx+=64)
    {
        rmSpiEn;
        rmSpiWrite(0x06);    // write-enable cmd
        rmSpiDis;

        rmSpiEn;
        rmSpiWrite(0x02);    // write-page cmd  (64 Byte max)
        rmSpiWrite(u32Idx>>8);    // write addr
        rmSpiWrite(u32Idx);    // write addr

        for(uIdx=0; uIdx<64; uIdx+=4)
        {
            u32Idx1=u32Idx+uIdx;
            rmSpiWrite(upDataPtr[u32Idx1+0]);
            rmSpiWrite(upDataPtr[u32Idx1+1]);
            rmSpiWrite(upDataPtr[u32Idx1+2]);
            rmSpiWrite(upDataPtr[u32Idx1+3]);
        }

        rmSpiDis;
        spiReadSts();    // read status
    }

    // disable AAl cmd
    rmSpiEn;
    rmSpiWrite(0x04);    // write-disable cmd
    rmSpiDis;
    spiReadSts();    // read status
}    /* spiProgRom */

void spiProgPat(LWORD u32WriteSize)
{
    LWORD u32Idx, u32Idx1;
    BYTE uIdx;

    for(u32Idx=0; u32Idx<u32WriteSize; u32Idx+=64)
    {
        rmSpiEn;
        rmSpiWrite(0x06);    // write-enable cmd
        rmSpiDis;

        rmSpiEn;
        rmSpiWrite(0x02);    // write-page cmd  (64 Byte max)
        rmSpiWrite(u32Idx>>8);    // write addr
        rmSpiWrite(u32Idx);    // write addr

        for(uIdx=0; uIdx<64; uIdx+=4)
        {
            u32Idx1=u32Idx+uIdx;
            rmSpiWrite(0x5A);
            rmSpiWrite(0xA5);
            rmSpiWrite(0x36);
            rmSpiWrite(0xBD);
        }

        rmSpiDis;
        spiReadSts();    // read status
    }

    // disable AAl cmd
    rmSpiEn;
    rmSpiWrite(0x04);    // write-disable cmd
    rmSpiDis;
    spiReadSts();    // read status
}    /* spiProgPat */

void spiProgTest()
{
    // BYTE *uarIspTab=&cbIspTable[0];

    BYTE uSts;

    spiStsSetting();
#if _CPU_SPI_PROG_TEST
    spiChipErase();
    spiProgRom(40960, (BYTE *)garISPTable);
#endif
    uSts=spiReadCompare(40960, (BYTE *)garISPTable);

    // spiProgPat(2560);
    // uSts=spiReadPatCompare(2560);

    while(uSts)
        ;
}    /* spiProgTest */







