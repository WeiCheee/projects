







#include "inc/TypeDef.h"
#include "inc/Option.h"
#include "inc/ProType.h"
#include "inc/Reg.h"
#include "inc/NvmeCtrl.h"
#include "inc/table.h"
#include "inc/GlobVar0.h"
#include "inc/GlobVarS.h"
#include "inc/GlobVarT.h"
#include "inc/Mac.h"

#if _GREYBOX
#include "inc/GreyBox.h"

#if ((!_ICE_LOAD_ALL)||(_CPUID))
#pragma default_variable_attributes = @ ".GREYBOX_VAR"
#endif

LWORD g32CodeCoverMapOffset;

// Variable for GreyBox
GBINFO gsGbInfo;
LWORD g32GreyBoxSwapOffset;
LWORD g32GreyBoxSwapOffset1;
BYTE gGreyBoxUartEn;

// Variable for test item GC
BYTE gGbGcSrcBlkCnt;
BYTE gpGbGcSrcIndex[cMaxGcSrcBlkNum];
WORD g16GbGcCachebActThr;
WORD g16GbTlcFullCachebGcThr;
WORD g16GbSpareBlockCnt;
WORD g16GbGcSrcBlock[cMaxGcSrcBlkNum];
WORD g16GbGcDesTLCBlock;
WORD g16GbCounter;
LWORD g32GbGcCachebTime;
LWORD g32GbTotalSrcBlkVpc;
LWORD g32GbGcSlcVpcThr;

// Variable for test item Retry or Read Err Handle
BYTE gReadErrinjectEn;

// Variable for test item RAID
BYTE gGbDieAddr;
BYTE gGbCe;
BYTE gGbIntlvAddr;
BYTE gGbCh;
BYTE gGbPlaneAddr;
WORD g16GbFBlock;
WORD g16GbFPage;
WORD g16GbRetryTabLoop;
WORD g16GbRaidDecTotalCnt;

// Variable for test item Read Cnt & Reclaim
WORD g16GbSetReclaimBlk;
WORD g16GbGetReclaimBlk;

// Variable for test item Finger Fail
LWORD g32GbFingerFailBlk;

// Variable for test item WL
LWORD g16GbGlobEraseCnt[c16MaxBlockNum];
WORD g16GbWLGcSrcTLCBlock;
WORD g16GbWLGcDesTLCBlock;
WORD g16GbSlcMoSkipCnt;

// Variable for test item Program Fail
WORD g16GbGetPgFailFblk;
WORD g16GbGetPgFailFblkNowDiffFblk;
WORD g16GbGetPgFailFblkAfterDiffFblock;
WORD g16GbSetPgFailFpage;
BYTE gGbSetPgFailIntlvAddr;
BYTE gGbSetPgFailCh;
BYTE gGbSetPgFailPlane;
BYTE gGbSetPgFailCase;
BYTE gGbEnCacheProg;
ADDRINFO gsIspAddrInfo;
ADDRINFO gsGbAddrInfo;

// Variable for UnitTest
UTINFO gsUtInfo;

// Variable for record Command
LWORD g32GbCmdHistoryPtr;
LWORD g32GbEndCmdHistoryPtr;
CMDSTRUCT garGbCmdHistory[cCmdHistorySize*cCmdHistorySize];
NVMEPRDSTRUCT garGbCmdValidHistory[cCmdHistorySize*cCmdHistorySize];

#if ((!_ICE_LOAD_ALL)||(_CPUID))
#pragma default_variable_attributes =
#endif

#if ((!_ICE_LOAD_ALL)||(_CPUID))
#pragma default_function_attributes = @ ".GREYBOX_DATA"
#endif
// dataInVendorCmdGreyBoxPre.c tag
CBYTE cbTagdataInVendorCmdGreyBoxPre[] @ ".GREYBOX_DATA"={"CS. dataInVendorCmdGreyBoxPre()"};
CBYTE cbTagdataInVendorCmdGreyBoxTrig[] @ ".GREYBOX_DATA"={"CS. dataInVendorCmdGreyBoxTrig()"};
CBYTE cbTagdataInVendorCmdGreyBoxDone[] @ ".GREYBOX_DATA"={"CS. dataInVendorCmdGreyBoxDone()"};
CBYTE cbTagdataInVendorCmdGreyBoxInit[] @ ".GREYBOX_DATA"={"CS. dataInVendorCmdGreyBoxInit()"};
CBYTE cbTagdataInVendorCmdGreyBoxSaveQBInfo[] @ ".GREYBOX_DATA"={"CS. dataInVendorCmdGreyBoxSaveQBInfo()"};

// dataOutVendorCmd.c tag
CBYTE cbTagdataOutVendorCmdGreyBoxTrig[] @ ".GREYBOX_DATA"={"CS. dataOutVendorCmdGreyBoxTrig()"};

// F2hTab.c
CBYTE cbTagflushCacheF2hTab[] @ ".GREYBOX_DATA"={"CS. flushCacheF2hTab()"};
CBYTE cbTagmodifyH2Ftab[] @ ".GREYBOX_DATA"={"CS. modifyH2Ftab()"};
CBYTE cbTagsetH2fSrcBlock[] @ ".GREYBOX_DATA"={"CS. setH2fSrcBlock()"};
// Hmb.c
CBYTE cbTagwriteHmbH2fTab[] @ ".GREYBOX_DATA"={"CS. writeHmbH2fTab()"};
CBYTE cbTagremHmbLink[] @ ".GREYBOX_DATA"={"CS. remHmbLink()"};

// GcH2fTab.c
CBYTE cbTagbgdClnH2fTabblkProc[] @ ".GREYBOX_DATA"={"CS. bgdClnH2fTabblkProc()"};

// GcCacheB.c
CBYTE cbTagflushGcDesF2hTab[] @ ".GREYBOX_DATA"={"CS. flushGcDesF2hTab()"};
CBYTE cbTagbgdClnCacheblkProc[] @ ".GREYBOX_DATA"={"CS. bgdClnCacheblkProc()"};

// NvmeIoCmd.C
CBYTE cbTagnvmeWriteUncorrectable[] @ ".GREYBOX_DATA"={"CS. nvmeWriteUncorrectable()"};

// FlashReadRetry.c
CBYTE cbTagdoReadRetry[] @ ".GREYBOX_DATA"={"CS. doReadRetry()"};
CBYTE cbTagdoReadRetryForPipeLine[] @ ".GREYBOX_DATA"={"CS. calRetryParaForPipeLine()"};
CBYTE cbTagsetTestRetryCmd[] @ ".GREYBOX_DATA"={"CS. cbTagsetTestRetryCmd()"};

// SaveIndx.c
CBYTE cbTagsaveIndexBlock[] @ ".GREYBOX_DATA"={"CS. saveIndexBlock()"};

// Write.c
CBYTE cbTaginitNewFblkProc[] @ ".GREYBOX_DATA"={"CS. initNewFblkProc()"};

CBYTE cVTrig[] @ ".GREYBOX_DATA"={"Sta. ------------------------ Triggered -----------------------"};
CBYTE cVOccur[] @ ".GREYBOX_DATA"={"Sta. ------------------------ Occurred ------------------------"};
CBYTE cVComplet[] @ ".GREYBOX_DATA"={"Sta. ------------------------ Completed -----------------------"};
CBYTE cVFail[] @ ".GREYBOX_DATA"={"Sta. ------------------------ Fail ----------------------------"};

#if ((!_ICE_LOAD_ALL)||(_CPUID))
#pragma default_function_attributes =
#endif

#if ((!_ICE_LOAD_ALL)||(_CPUID))
#pragma default_function_attributes = @ ".GREYBOX_FUNC"
#endif
// Function for GreyBox

void addCoverageUart()
{
#if (!_DEBUG_LOG)
    volatile LWORD u32CodeCoverCheckSize=(LWORD)0x128E0;    // c512KBytes>>2;
    volatile LWORD u32Loop;
    LWORD u32Val;
    BYTE uLoop, uarVal[8];
    BYTE uTempVal;

    rmWaitUartBusy;
    rmNewLine;
    rmWaitUartBusy;
    rmUartTxByte('1');
    rmWaitUartBusy;
    rmUartTxByte(' ');

    for(u32Loop=0; u32Loop<16; u32Loop++)
    {
        rmWaitUartBusy;
        rmUartTxByte('0');
        rmWaitUartBusy;
        rmUartTxByte('x');
        rmWaitUartBusy;
        rmUartTxByte('0');
        rmWaitUartBusy;
        rmUartTxByte(' ');
    }

    rmWaitUartBusy;
    rmUartTxByte('E');
    rmWaitUartBusy;
    rmNewLine;
    rmWaitUartBusy;
    rmUartTxByte('C');
    rmWaitUartBusy;
    rmUartTxByte(' ');

    for(u32Loop=0; u32Loop<u32CodeCoverCheckSize; u32Loop+=4)
    {
        u32Val=*(LWORD *)(c32GreyBoxCore0CodeAddr+0x1000000+u32Loop);
        rmWaitUartBusy;
        rmUartTxByte('0');
        rmWaitUartBusy;
        rmUartTxByte('x');

        for(uLoop=0; uLoop<8; uLoop++)
        {
            uTempVal=u32Val&0xF;

            if(uTempVal<0xA)
            {
                uarVal[uLoop]=uTempVal+cAsciiTo0;
            }
            else
            {
                uarVal[uLoop]=(uTempVal-0xA)+cAsciiToA;
            }

            u32Val=u32Val>>4;    // 0xF

            if(!u32Val)
            {
                break;
            }
        }

        uLoop++;

        while(uLoop!=0)
        {
            rmWaitUartBusy;
            rmUartTxByte(uarVal[--uLoop]);
        }

        rmWaitUartBusy;
        rmUartTxByte(' ');

        if((u32Loop!=0)&&(u32Loop%64==0))
        {
            rmWaitUartBusy;
            rmUartTxByte('E');
            rmWaitUartBusy;
            rmNewLine;
            rmWaitUartBusy;
            rmUartTxByte('C');
            rmWaitUartBusy;
            rmUartTxByte(' ');
        }
    }

    rmWaitUartBusy;
    rmNewLine;
    rmWaitUartBusy;
    rmUartTxByte('2');
    rmWaitUartBusy;
    rmUartTxByte(' ');

    for(u32Loop=0; u32Loop<16; u32Loop++)
    {
        rmWaitUartBusy;
        rmUartTxByte('0');
        rmWaitUartBusy;
        rmUartTxByte('x');
        rmWaitUartBusy;
        rmUartTxByte('0');
        rmWaitUartBusy;
        rmUartTxByte(' ');
    }

    rmWaitUartBusy;
    rmUartTxByte('E');
    rmWaitUartBusy;
    rmNewLine;
    rmWaitUartBusy;
    rmUartTxByte('C');
    rmWaitUartBusy;
    rmUartTxByte(' ');

    for(u32Loop=0; u32Loop<u32CodeCoverCheckSize; u32Loop+=4)
    {
        u32Val=*(LWORD *)(c32GreyBoxCore0CodeAddr+0x2000000+u32Loop);
        rmWaitUartBusy;
        rmUartTxByte('0');
        rmWaitUartBusy;
        rmUartTxByte('x');

        for(uLoop=0; uLoop<8; uLoop++)
        {
            uTempVal=u32Val&0xF;

            if(uTempVal<0xA)
            {
                uarVal[uLoop]=uTempVal+cAsciiTo0;
            }
            else
            {
                uarVal[uLoop]=(uTempVal-0xA)+cAsciiToA;
            }

            u32Val=u32Val>>4;    // 0xF

            if(!u32Val)
            {
                break;
            }
        }

        uLoop++;

        while(uLoop!=0)
        {
            rmWaitUartBusy;
            rmUartTxByte(uarVal[--uLoop]);
        }

        rmWaitUartBusy;
        rmUartTxByte(' ');

        if((u32Loop!=0)&&(u32Loop%64==0))
        {
            rmWaitUartBusy;
            rmUartTxByte('E');
            rmWaitUartBusy;
            rmNewLine;
            rmWaitUartBusy;
            rmUartTxByte('C');
            rmWaitUartBusy;
            rmUartTxByte(' ');
        }
    }

    rmWaitUartBusy;
    rmNewLine;
    rmWaitUartBusy;
    rmUartTxByte('3');
    rmWaitUartBusy;
    rmUartTxByte(' ');

    for(u32Loop=0; u32Loop<16; u32Loop++)
    {
        rmWaitUartBusy;
        rmUartTxByte('0');
        rmWaitUartBusy;
        rmUartTxByte('x');
        rmWaitUartBusy;
        rmUartTxByte('0');
        rmWaitUartBusy;
        rmUartTxByte(' ');
    }

    rmWaitUartBusy;
    rmUartTxByte('E');
    rmWaitUartBusy;
    rmNewLine;
    rmWaitUartBusy;
    rmUartTxByte('C');
    rmWaitUartBusy;
    rmUartTxByte(' ');

    for(u32Loop=0; u32Loop<u32CodeCoverCheckSize; u32Loop+=4)
    {
        u32Val=*(LWORD *)(c32GreyBoxCore0CodeAddr+0x3000000+u32Loop);
        rmWaitUartBusy;
        rmUartTxByte('0');
        rmWaitUartBusy;
        rmUartTxByte('x');

        for(uLoop=0; uLoop<8; uLoop++)
        {
            uTempVal=u32Val&0xF;

            if(uTempVal<0xA)
            {
                uarVal[uLoop]=uTempVal+cAsciiTo0;
            }
            else
            {
                uarVal[uLoop]=(uTempVal-0xA)+cAsciiToA;
            }

            u32Val=u32Val>>4;    // 0xF

            if(!u32Val)
            {
                break;
            }
        }

        uLoop++;

        while(uLoop!=0)
        {
            rmWaitUartBusy;
            rmUartTxByte(uarVal[--uLoop]);
        }

        rmWaitUartBusy;
        rmUartTxByte(' ');

        if((u32Loop!=0)&&(u32Loop%64==0))
        {
            rmWaitUartBusy;
            rmUartTxByte('E');
            rmWaitUartBusy;
            rmNewLine;
            rmWaitUartBusy;
            rmUartTxByte('C');
            rmWaitUartBusy;
            rmUartTxByte(' ');
        }
    }

    rmWaitUartBusy;
    rmNewLine;
    rmWaitUartBusy;
    rmUartTxByte('4');
    rmWaitUartBusy;
    rmUartTxByte(' ');

    for(u32Loop=0; u32Loop<16; u32Loop++)
    {
        rmWaitUartBusy;
        rmUartTxByte('0');
        rmWaitUartBusy;
        rmUartTxByte('x');
        rmWaitUartBusy;
        rmUartTxByte('0');
        rmWaitUartBusy;
        rmUartTxByte(' ');
    }

    rmWaitUartBusy;
    rmUartTxByte('E');
    rmWaitUartBusy;
    rmNewLine;
    rmWaitUartBusy;
    rmUartTxByte('C');
    rmWaitUartBusy;
    rmUartTxByte(' ');

    for(u32Loop=0; u32Loop<u32CodeCoverCheckSize; u32Loop+=4)
    {
        u32Val=*(LWORD *)(c32GreyBoxCore0CodeAddr+0x4000000+u32Loop);
        rmWaitUartBusy;
        rmUartTxByte('0');
        rmWaitUartBusy;
        rmUartTxByte('x');

        for(uLoop=0; uLoop<8; uLoop++)
        {
            uTempVal=u32Val&0xF;

            if(uTempVal<0xA)
            {
                uarVal[uLoop]=uTempVal+cAsciiTo0;
            }
            else
            {
                uarVal[uLoop]=(uTempVal-0xA)+cAsciiToA;
            }

            u32Val=u32Val>>4;    // 0xF

            if(!u32Val)
            {
                break;
            }
        }

        uLoop++;

        while(uLoop!=0)
        {
            rmWaitUartBusy;
            rmUartTxByte(uarVal[--uLoop]);
        }

        rmWaitUartBusy;
        rmUartTxByte(' ');

        if((u32Loop!=0)&&(u32Loop%64==0))
        {
            rmWaitUartBusy;
            rmUartTxByte('E');
            rmWaitUartBusy;
            rmNewLine;
            rmWaitUartBusy;
            rmUartTxByte('C');
            rmWaitUartBusy;
            rmUartTxByte(' ');
        }
    }

    rmWaitUartBusy;
    rmNewLine;
    rmWaitUartBusy;
    rmUartTxByte('5');
    rmWaitUartBusy;
    rmUartTxByte(' ');

    for(u32Loop=0; u32Loop<16; u32Loop++)
    {
        rmWaitUartBusy;
        rmUartTxByte('0');
        rmWaitUartBusy;
        rmUartTxByte('x');
        rmWaitUartBusy;
        rmUartTxByte('0');
        rmWaitUartBusy;
        rmUartTxByte(' ');
    }

    rmWaitUartBusy;
    rmUartTxByte('E');
    rmWaitUartBusy;
    rmNewLine;
    rmWaitUartBusy;
    rmUartTxByte('C');
    rmWaitUartBusy;
    rmUartTxByte(' ');

    for(u32Loop=0; u32Loop<u32CodeCoverCheckSize; u32Loop+=4)
    {
        u32Val=*(LWORD *)(c32GreyBoxCore0CodeAddr+0x5000000+u32Loop);
        rmWaitUartBusy;
        rmUartTxByte('0');
        rmWaitUartBusy;
        rmUartTxByte('x');

        for(uLoop=0; uLoop<8; uLoop++)
        {
            uTempVal=u32Val&0xF;

            if(uTempVal<0xA)
            {
                uarVal[uLoop]=uTempVal+cAsciiTo0;
            }
            else
            {
                uarVal[uLoop]=(uTempVal-0xA)+cAsciiToA;
            }

            u32Val=u32Val>>4;    // 0xF

            if(!u32Val)
            {
                break;
            }
        }

        uLoop++;

        while(uLoop!=0)
        {
            rmWaitUartBusy;
            rmUartTxByte(uarVal[--uLoop]);
        }

        rmWaitUartBusy;
        rmUartTxByte(' ');

        if((u32Loop!=0)&&(u32Loop%64==0))
        {
            rmWaitUartBusy;
            rmUartTxByte('E');
            rmWaitUartBusy;
            rmNewLine;
            rmWaitUartBusy;
            rmUartTxByte('C');
            rmWaitUartBusy;
            rmUartTxByte(' ');
        }
    }

    rmWaitUartBusy;
    rmNewLine;
    rmWaitUartBusy;
    rmUartTxByte('6');
    rmWaitUartBusy;
    rmUartTxByte(' ');

    for(u32Loop=0; u32Loop<16; u32Loop++)
    {
        rmWaitUartBusy;
        rmUartTxByte('0');
        rmWaitUartBusy;
        rmUartTxByte('x');
        rmWaitUartBusy;
        rmUartTxByte('0');
        rmWaitUartBusy;
        rmUartTxByte(' ');
    }

    rmWaitUartBusy;
    rmUartTxByte('E');
    rmWaitUartBusy;
    rmNewLine;
    rmWaitUartBusy;
    rmUartTxByte('C');
    rmWaitUartBusy;
    rmUartTxByte(' ');

    for(u32Loop=0; u32Loop<u32CodeCoverCheckSize; u32Loop+=4)
    {
        u32Val=*(LWORD *)(c32GreyBoxCore0CodeAddr+0x6000000+u32Loop);
        rmWaitUartBusy;
        rmUartTxByte('0');
        rmWaitUartBusy;
        rmUartTxByte('x');

        for(uLoop=0; uLoop<8; uLoop++)
        {
            uTempVal=u32Val&0xF;

            if(uTempVal<0xA)
            {
                uarVal[uLoop]=uTempVal+cAsciiTo0;
            }
            else
            {
                uarVal[uLoop]=(uTempVal-0xA)+cAsciiToA;
            }

            u32Val=u32Val>>4;    // 0xF

            if(!u32Val)
            {
                break;
            }
        }

        uLoop++;

        while(uLoop!=0)
        {
            rmWaitUartBusy;
            rmUartTxByte(uarVal[--uLoop]);
        }

        rmWaitUartBusy;
        rmUartTxByte(' ');

        if((u32Loop!=0)&&(u32Loop%64==0))
        {
            rmWaitUartBusy;
            rmUartTxByte('E');
            rmWaitUartBusy;
            rmNewLine;
            rmWaitUartBusy;
            rmUartTxByte('C');
            rmWaitUartBusy;
            rmUartTxByte(' ');
        }
    }

    rmWaitUartBusy;
    rmNewLine;
    rmWaitUartBusy;
    rmUartTxByte('7');
    rmWaitUartBusy;
    rmUartTxByte(' ');

    for(u32Loop=0; u32Loop<16; u32Loop++)
    {
        rmWaitUartBusy;
        rmUartTxByte('0');
        rmWaitUartBusy;
        rmUartTxByte('x');
        rmWaitUartBusy;
        rmUartTxByte('0');
        rmWaitUartBusy;
        rmUartTxByte(' ');
    }

    rmWaitUartBusy;
    rmUartTxByte('E');
    rmWaitUartBusy;
    rmNewLine;
    rmWaitUartBusy;
    rmUartTxByte('C');
    rmWaitUartBusy;
    rmUartTxByte(' ');

    for(u32Loop=0; u32Loop<u32CodeCoverCheckSize; u32Loop+=4)
    {
        u32Val=*(LWORD *)(c32GreyBoxCore0CodeAddr+0x7000000+u32Loop);
        rmWaitUartBusy;
        rmUartTxByte('0');
        rmWaitUartBusy;
        rmUartTxByte('x');

        for(uLoop=0; uLoop<8; uLoop++)
        {
            uTempVal=u32Val&0xF;

            if(uTempVal<0xA)
            {
                uarVal[uLoop]=uTempVal+cAsciiTo0;
            }
            else
            {
                uarVal[uLoop]=(uTempVal-0xA)+cAsciiToA;
            }

            u32Val=u32Val>>4;    // 0xF

            if(!u32Val)
            {
                break;
            }
        }

        uLoop++;

        while(uLoop!=0)
        {
            rmWaitUartBusy;
            rmUartTxByte(uarVal[--uLoop]);
        }

        rmWaitUartBusy;
        rmUartTxByte(' ');

        if((u32Loop!=0)&&(u32Loop%64==0))
        {
            rmWaitUartBusy;
            rmUartTxByte('E');
            rmWaitUartBusy;
            rmNewLine;
            rmWaitUartBusy;
            rmUartTxByte('C');
            rmWaitUartBusy;
            rmUartTxByte(' ');
        }
    }

    rmWaitUartBusy;
    rmNewLine;
    rmWaitUartBusy;
    rmUartTxByte('8');
    rmWaitUartBusy;
    rmUartTxByte(' ');

    for(u32Loop=0; u32Loop<16; u32Loop++)
    {
        rmWaitUartBusy;
        rmUartTxByte('0');
        rmWaitUartBusy;
        rmUartTxByte('x');
        rmWaitUartBusy;
        rmUartTxByte('0');
        rmWaitUartBusy;
        rmUartTxByte(' ');
    }

    rmWaitUartBusy;
    rmUartTxByte('E');
    rmWaitUartBusy;
    rmNewLine;
    rmWaitUartBusy;
    rmUartTxByte('C');
    rmWaitUartBusy;
    rmUartTxByte(' ');

    for(u32Loop=0; u32Loop<u32CodeCoverCheckSize; u32Loop+=4)
    {
        u32Val=*(LWORD *)(c32GreyBoxCore0CodeAddr+0x8000000+u32Loop);
        rmWaitUartBusy;
        rmUartTxByte('0');
        rmWaitUartBusy;
        rmUartTxByte('x');

        for(uLoop=0; uLoop<8; uLoop++)
        {
            uTempVal=u32Val&0xF;

            if(uTempVal<0xA)
            {
                uarVal[uLoop]=uTempVal+cAsciiTo0;
            }
            else
            {
                uarVal[uLoop]=(uTempVal-0xA)+cAsciiToA;
            }

            u32Val=u32Val>>4;    // 0xF

            if(!u32Val)
            {
                break;
            }
        }

        uLoop++;

        while(uLoop!=0)
        {
            rmWaitUartBusy;
            rmUartTxByte(uarVal[--uLoop]);
        }

        rmWaitUartBusy;
        rmUartTxByte(' ');

        if((u32Loop!=0)&&(u32Loop%64==0))
        {
            rmWaitUartBusy;
            rmUartTxByte('E');
            rmWaitUartBusy;
            rmNewLine;
            rmWaitUartBusy;
            rmUartTxByte('C');
            rmWaitUartBusy;
            rmUartTxByte(' ');
        }
    }

    rmWaitUartBusy;
    rmNewLine;
    rmWaitUartBusy;
    rmUartTxByte('9');
    rmWaitUartBusy;
    rmUartTxByte(' ');

    for(u32Loop=0; u32Loop<16; u32Loop++)
    {
        rmWaitUartBusy;
        rmUartTxByte('0');
        rmWaitUartBusy;
        rmUartTxByte('x');
        rmWaitUartBusy;
        rmUartTxByte('0');
        rmWaitUartBusy;
        rmUartTxByte(' ');
    }

    rmWaitUartBusy;
    rmUartTxByte('E');
    rmWaitUartBusy;
    rmNewLine;
    rmWaitUartBusy;
    rmUartTxByte('C');
    rmWaitUartBusy;
    rmUartTxByte(' ');

    for(u32Loop=0; u32Loop<u32CodeCoverCheckSize; u32Loop+=4)
    {
        u32Val=*(LWORD *)(c32GreyBoxCore0CodeAddr+0x9000000+u32Loop);
        rmWaitUartBusy;
        rmUartTxByte('0');
        rmWaitUartBusy;
        rmUartTxByte('x');

        for(uLoop=0; uLoop<8; uLoop++)
        {
            uTempVal=u32Val&0xF;

            if(uTempVal<0xA)
            {
                uarVal[uLoop]=uTempVal+cAsciiTo0;
            }
            else
            {
                uarVal[uLoop]=(uTempVal-0xA)+cAsciiToA;
            }

            u32Val=u32Val>>4;    // 0xF

            if(!u32Val)
            {
                break;
            }
        }

        uLoop++;

        while(uLoop!=0)
        {
            rmWaitUartBusy;
            rmUartTxByte(uarVal[--uLoop]);
        }

        rmWaitUartBusy;
        rmUartTxByte(' ');

        if((u32Loop!=0)&&(u32Loop%64==0))
        {
            rmWaitUartBusy;
            rmUartTxByte('E');
            rmWaitUartBusy;
            rmNewLine;
            rmWaitUartBusy;
            rmUartTxByte('C');
            rmWaitUartBusy;
            rmUartTxByte(' ');
        }
    }

    rmWaitUartBusy;
    rmNewLine;
    rmWaitUartBusy;
    rmUartTxByte('A');
    rmWaitUartBusy;
    rmUartTxByte(' ');

    for(u32Loop=0; u32Loop<16; u32Loop++)
    {
        rmWaitUartBusy;
        rmUartTxByte('0');
        rmWaitUartBusy;
        rmUartTxByte('x');
        rmWaitUartBusy;
        rmUartTxByte('0');
        rmWaitUartBusy;
        rmUartTxByte(' ');
    }

    rmWaitUartBusy;
    rmUartTxByte('E');
    rmWaitUartBusy;
    rmNewLine;
    rmWaitUartBusy;
    rmUartTxByte('C');
    rmWaitUartBusy;
    rmUartTxByte(' ');

    for(u32Loop=0; u32Loop<u32CodeCoverCheckSize; u32Loop+=4)
    {
        u32Val=*(LWORD *)(c32GreyBoxCore0CodeAddr+0xA000000+u32Loop);
        rmWaitUartBusy;
        rmUartTxByte('0');
        rmWaitUartBusy;
        rmUartTxByte('x');

        for(uLoop=0; uLoop<8; uLoop++)
        {
            uTempVal=u32Val&0xF;

            if(uTempVal<0xA)
            {
                uarVal[uLoop]=uTempVal+cAsciiTo0;
            }
            else
            {
                uarVal[uLoop]=(uTempVal-0xA)+cAsciiToA;
            }

            u32Val=u32Val>>4;    // 0xF

            if(!u32Val)
            {
                break;
            }
        }

        uLoop++;

        while(uLoop!=0)
        {
            rmWaitUartBusy;
            rmUartTxByte(uarVal[--uLoop]);
        }

        rmWaitUartBusy;
        rmUartTxByte(' ');

        if((u32Loop!=0)&&(u32Loop%64==0))
        {
            rmWaitUartBusy;
            rmUartTxByte('E');
            rmWaitUartBusy;
            rmNewLine;
            rmWaitUartBusy;
            rmUartTxByte('C');
            rmWaitUartBusy;
            rmUartTxByte(' ');
        }
    }
#endif/* if 0 */
}    /* addCoverageUart */

void triggerUGSD(BYTE uWaitCmdDone)
{
    // waitAllChCeBzCore0();
    /* Cut-off flash core power */
    outInfo(cGbPbaInfo);
    outSta(cVOccur);

    if(uWaitCmdDone)
    {
        mWaitCmdFifoBz;
    }

#if _CPUID
    // Save as gpFlashAddrInfo
    copyCcmVal((BYTE *)&gsFlashAddrInfoTemp, (BYTE *)gpFlashAddrInfo, sizeof(ADDRINFO));

    if((gsGbInfo.uGreyBoxOpt==cVOpProgFristF2H)||(gsGbInfo.uGreyBoxOpt==cVOpProgQboot)||(gsGbInfo.uGreyBoxOpt==cVOpProgLastF2H)||
       (gsGbInfo.uGreyBoxOpt==cVOpProgCacheInfoInitCache)||(gsGbInfo.uGreyBoxOpt==cVOpProgCacheInfoH2fFull)||
       (gsGbInfo.uGreyBoxOpt==cVOpAllConfig)||(gsGbInfo.uGreyBoxOpt==cVOpProgH2fxHmb)||(gsGbInfo.uGreyBoxOpt==cVOpSetFeature)||
       (gsGbInfo.uGreyBoxOpt==cVOpProgH2fonHmb)||(gsGbInfo.uGreyBoxOpt==cVOpProgCacheLast6Page)||(gsGbInfo.uGreyBoxOpt==cVOpProgCacheLast3Page))
    {
        BYTE uChBk=gActiveCh;
        waitAllChCeBz();
        setFLActCh(uChBk);

        mSetFRwParam(c16Tsb1SIdx, gSectorPerPlaneH, c16Bit4|c16Bit14, cVenderWrite);
        flashProgPage(c16Tsb1SIdx, gSectorPerPlaneH, c16Bit4|c16Bit14);
    }

    rmFlashCorePower(0);
    outSta(cVOccur);

    gsGbInfo.uStag=cVsDone;
    outInfo(cGbPbaInfo);

    saveRamInfo();
#endif/* if _CPUID */

#if (_CODECOVER)
    addCoverageUart();
#endif

    while(1)
        ;
}    /* triggerUGSD */

void addCoverage(LWORD u32File, LWORD u32Line, LWORD u32ID)
{
    rmWaitUartBusy;
    rmUartTxLword(0xFFFFFFFF);
    rmCovFuncCode(u32File, u32Line, u32ID);
}

void makeAWGN(BYTE uAWGNlv, BYTE uCh)
{
    // outCS("CS. makeAWGN()");

    if(((gsGbInfo.uGreyBoxItem)&cInjectRF)&&(rFLCtrl[0XC0]==0x00)&&(gsGbInfo.uStag==cVsIdl))
    {
        outInfo(cGbPbaInfo);
        BYTE uChLoop;

        for(uChLoop=0; uChLoop<gTotalChNum; uChLoop++)
        {
            setFLActCh(uChLoop);
            mWaitCmdFifoBz;
        }

        setFLActCh(uCh);

        /* Enable AWGN */
        rFLCtrl[0XC0]=cBit4;

        /* UNC */
        if(uAWGNlv==cAWGNUNC)
        {
            // outSta("make AWGN.");
            /* One chunk with the most noise(it will UNC)
               * ,other chunk with 0.3% noise.*/
            r32FLCtrl[0x31]=0X33333333;
            r32FLCtrl[0x32]=0X33333333;
            r32FLCtrl[0x33]=0X55555555;
            r32FLCtrl[0x34]=0X55555555;
            r32FLCtrl[0x35]=0X55555555;
            // rFLCtrl[0XC4+(gInjectChunk>>1)] = uAWGNlv<<(((gInjectChunk+1)%2)<<2);
            // rFLCtrl[0XC4+(2>>1)] = uAWGNlv<<(((2+1)%2)<<2);
        }

        /* with noise 0.3%/0.6%/1.4% */
#if 0
        else
        {
            /* One chunk with noise(0.3%/0.6%/1.4%)
               * ,other chunk with lowest noise(be able correct with BCH)*/
            r32FLCtrl[0x31]=0X33333333;
            r32FLCtrl[0x32]=0X33333333;
            r32FLCtrl[0x33]=0xFFFFFFFF;
            r32FLCtrl[0x34]=0xFFFFFFFF;
            r32FLCtrl[0x35]=0xFFFFFFFF;
            // rFLCtrl[0XC4+(gInjectChunk>>1)] = uAWGNlv<<(((gInjectChunk+1)%2)<<2);
        }
#endif
    }
    else if((rFLCtrl[0XC0])&&(uAWGNlv==cAWGNNon))
    {
        outInfo(cGbPbaInfo);
        // outSta("Recover AWGN.");
        // mWaitSysCmdFifoBz;
        mWaitCmdFifoBz;

        /* Disable AWGN */
        setSelMulFL(1);
        // mWaitSysCmdFifoBz;
        mWaitCmdFifoBz;
        rFLCtrl[0XC0]=0x00;
        setSelMulFL(0);

        /* Recover Flag */
        gsGbInfo.uGreyBoxItem=cVsIdl;
        // outSta(cVComplet);
    }
}    /* makeAWGN */

/* Output FW information by UART*/
void outInfo(BYTE uInfoType)
{
#if (!_CODECOVER)
    if(gGreyBoxUartEn)
    {
        rmNewLine;
        WORD u16Loop;

        switch(uInfoType)
        {
            /* here is related with Address */
            case cGbHqInfo:
                outString(cVHqInfo, 0);
                outString("rmNvmeLbaLow=@", rmNvmeLbaLow);
                outString("rmNvmeNlb=@", rmNvmeNlb);
                // outString("rmNvmeOpCode=@", rmNvmeOpCode);
                // outString("rmNvmeCqId=@", rmNvmeCqId);
                // outString("rmNvmeSqId=@", rmNvmeSqId);
                // outString("rmNvmeSgl=@", rmNvmeSgl);
                break;

            case cGbPbaInfo:
                outString(cVPbaInfo, 0);
                outString("g16FBlock=@", g16FBlock);
                outString("g32FPageNoTran=@", g32FPageNoTran);
                outString("gCh=@", gCh);
                outString("gIntlvAddr=@", gIntlvAddr);
                outString("gPlaneAddr=@", gPlaneAddr);
                outString("g16FPage=@", g16FPage);
                outString("gbLsbOnly=@", gbLsbOnly);
                outString("g16RwOpt=@", g16RwOpt);
                outString("gOpTyp=@", gOpTyp);
                break;

            /* here is related with GC */
            case cGbGcInfo:
                outString(cVPbGcInfo, 0);
                break;

            /* here is related with verify */
            case cGbVerifyInfo:
                outString(cVVerifyInfo, 0);
                break;

            /* here is related with BadInfo */
            case cGvMarkBadInfo:
                outString(cVMarkBadInfo, 0);
                break;

            case cGbRwCtrl:
                outString(cVRwCtrl, 0);
                break;

            case cGbHmbInfo:
                outString(cVHmbInfo, 0);
#if 0    // (!_CPUID)
                outString("g32HmbDescEntryAddrLow=@", g32HmbDescEntryAddrLow);
                outString("g32HmbDescEntryAddrHigh=@", g32HmbDescEntryAddrHigh);
                outString("g32HmbDescEntrySize=@", g32HmbDescEntrySize);
                outString("gsHmbInfo.u16FreeHmbHead=@", gsHmbInfo.u16FreeHmbHead);
#else
                outString("g32HmbDescEntryAddrLow=@", 0);
                outString("g32HmbDescEntryAddrHigh=@", 0);
                outString("g32HmbDescEntrySize=@", 0);
                outString("gsHmbInfo.u16FreeHmbHead=@", 0);
                break;
#endif
            case cGbTrigInfo:
                outString(cVTrigInfo, 0);
                outString("FBlock=@", gsGbAddrInfo.u16FBlock);
                outString("FPage=@", gsGbAddrInfo.u16FPage);
                outString("Ch=@", gsGbAddrInfo.uCh);
                outString("Ce=@", gsGbAddrInfo.uCe);
                outString("IntlvAddr=@", gsGbAddrInfo.uIntlvAddr);
                outString("PlaneAddr=@", gsGbAddrInfo.uPlaneAddr);
                break;

            case cGbH2fInfo:
                outString(cVH2fInfo, 0);
                outString("gsCacheInfo.uH2fTabBlockCnt=@", gsCacheInfo.uH2fTabBlockCnt);
                outString("gsCacheInfo.uActH2fTabBlkIdx=@", gsCacheInfo.uActH2fTabBlkIdx);
                outString("gsCacheInfo.u16H2fTabFreePagePtr=@", gsCacheInfo.u16H2fTabFreePagePtr);
                outString("gsGcInfo.uGcH2fTabbHiThr=@", gsGcInfo.uGcH2fTabbHiThr);
                outString("gsGcInfo.uGcH2fTabbLoThr=@", gsGcInfo.uGcH2fTabbLoThr);
                outString("gsGcInfo.uGcH2fTabBlkIdx=@", gsGcInfo.uGcH2fTabBlkIdx);
                outString("H2f Table Block.", 0);

                for(u16Loop=0; u16Loop<c16MaxH2fTabBlkNum; u16Loop++)
                {
                    outString("g16arH2fTabBlk=@", g16arH2fTabBlk[u16Loop]);
                }

                outString("H2f Table Vp Cnt.", 0);

                for(u16Loop=0; u16Loop<c16MaxH2fTabBlkNum; u16Loop++)
                {
                    outString("g16arH2fTabBlkVpCnt=@", g16arH2fTabBlkVpCnt[u16Loop]);
                }

                break;

            default:
                break;
        }    /* switch */

        rmNewLine;
        rmNewLine;
    }
#endif/* if (!_CODECOVER) */
}    /* outInfo */

/* Output Call Stack by UART*/
void outCS(CBYTE *upCallStack)
{
#if (!_CODECOVER)
    if(gGreyBoxUartEn)
    {
        outString((CBYTE *)upCallStack, 0);
    }
    // delay(0xff);
#endif
}

/* Output Verify Status */
void outSta(CBYTE *upSta)
{
#if (!_CODECOVER)
    if(gGreyBoxUartEn)
    {
        rmNewLine;
        outString((CBYTE *)upSta, 0);
    }
#endif
}

/* Output String by UART*/
void outString(CBYTE *ups, LWORD u32Val)
{
#if (_CODECOVER)
    rmWaitUartBusy;
    rmUartTxLword(u32Val);
#else
    if(gGreyBoxUartEn)
    {
        BYTE uLoop, uarVal[8];
        BYTE uTempVal;

        rmWaitUartBusy;

        while(*ups!=0x00)
        {
            if(*ups!=cCharAt)
            {
                rmUartTxByte(*ups);
            }
            else
            {
                rmUartTxByte('0');
                rmUartTxByte('x');

                for(uLoop=0; uLoop<8; uLoop++)
                {
                    uTempVal=u32Val&0xF;

                    if(uTempVal<0xA)
                    {
                        uarVal[uLoop]=uTempVal+cAsciiTo0;
                    }
                    else
                    {
                        uarVal[uLoop]=(uTempVal-0xA)+cAsciiToA;
                    }

                    u32Val=u32Val>>4;    // 0xF

                    if(!u32Val)
                    {
                        break;
                    }
                }

                uLoop++;

                while(uLoop!=0)
                {
                    rmWaitUartBusy;
                    rmUartTxByte(uarVal[--uLoop]);
                }
            }

            ups++;
        }

#if (!_CODECOVER)
        rmNewLine;
#endif
    }
#endif/* if (_CODECOVER) */
}    /* outString */

void trigGreyBox(BYTE uSaveRam)
{
    // outSta(cVTrig);
    gsGbInfo.uStag=cVsTriggered;

    if(uSaveRam)
    {
#if (_CPUID==0)
        copySdram2Tsb((UCBYTE *)c32GreyBoxBuf, (UCBYTE *)cDtcmAddr, cDtcmSize);
#endif
    }
}

void chkGreyBoxStu(void)
{
    BYTE    /*uDataP01BlkId, */ uDataP23BlkId, uSpr0, uTabBlkId;

    if(!mChkTabSpr(gpFlashAddrInfo, cBit5|cBit6))
    {
        if(((gSparePtrTail[gActiveCh]-mGetSprUseCnt(gpFlashAddrInfo))&0x03))
        {
            // uDataP01BlkId=rFLCtrl[(rcSpr0+(cSprGrpOffset*2))+0x10];
            uDataP23BlkId=rFLCtrl[(rcSpr0+(cSprGrpOffset*3))+0x10];
        }
        else
        {
            // uDataP01BlkId=rFLCtrl[(rcSpr0+(cSprGrpOffset*0))+0x10];
            uDataP23BlkId=rFLCtrl[(rcSpr0+(cSprGrpOffset*1))+0x10];
        }

        // outString("uDataP01BlkId = @", uDataP01BlkId);
        // outString("uDataP23BlkId = @", uDataP23BlkId);
    }
    else
    {
        uTabBlkId=rFLCtrl[(rcSpr0+(cSprGrpOffset*gPlaneAddr))+0x10];
        // outString("uTabBlkId = @", uTabBlkId);
    }

    uSpr0=rFLCtrl[(rcSpr0+(cSprGrpOffset*gPlaneAddr))+0];

    if(gsGbInfo.uStag==cVsTriggered)
    {
        // Erasing
        if(((gsGbInfo.uGreyBoxItem&0xF0)==0x10)&&(gsGbInfo.uGreyBoxOpt==cVOpErasing))
        {
            rmCle(gResetCmd);
            triggerUGSD(cFalse);
        }

        if(gsGbInfo.uGreyBoxItem==cUGSDProgCacheSlcID)
        {
            if(gsGbInfo.uGreyBoxOpt==cVOpAllConfig)
            {
                if((uDataP23BlkId==cCacheBlockID)&&(g16FPage==0)&&(gActiveCh==(gTotalChNum-1)))
                {
                    // waitAllChCeBz();
                    gPlaneAddr=0;
                    setFLActCh(0);
                    triggerUGSD(cTrue);
                }
            }
            else if(gsGbInfo.uGreyBoxOpt==cVOpProgCacheLast6Page)
            {
                if((uDataP23BlkId==cCacheBlockID)&&(g16FPage==(g16PagePerBlock1_SLC-6)))
                {
                    triggerUGSD(cFalse);
                }
            }
            else if(gsGbInfo.uGreyBoxOpt==cVOpProgCacheLast3Page)
            {
                if((uDataP23BlkId==cCacheBlockID)&&(g16FPage==(g16PagePerBlock1_SLC-3)))
                {
                    triggerUGSD(cFalse);
                }
            }
            else if(gsGbInfo.uGreyBoxOpt==cVOpProgFristF2H)
            {
                if((uDataP23BlkId==cF2hTableID)&&((g16FPage/(g16PagePerBlock1_SLC/gTotalBankOfF2hTab))==0))
                {
                    triggerUGSD(cFalse);
                }
            }
            else if(gsGbInfo.uGreyBoxOpt==cVOpProgLastF2H)
            {
                if((uDataP23BlkId==cF2hTableID)&&((g16FPage/(g16PagePerBlock1_SLC/gTotalBankOfF2hTab))==(gTotalBankOfF2hTab-1)))
                {
                    triggerUGSD(cFalse);
                }
            }
            else if(gsGbInfo.uGreyBoxOpt==cVOpProgLastF2HDone)
            {
                if((uDataP23BlkId==cF2hTableID)&&((g16FPage/(g16PagePerBlock1_SLC/gTotalBankOfF2hTab))==(gTotalBankOfF2hTab-1)))
                {
                    triggerUGSD(cTrue);
                }
            }
        }
        else if(gsGbInfo.uGreyBoxItem==cUGSDProgH2fTableID)
        {
            if(gsGbInfo.uGreyBoxOpt==cVOpAllConfig)
            {
                if(uTabBlkId==cH2fTableID)
                {
                    triggerUGSD(cFalse);
                }
            }
        }
        else if(gsGbInfo.uGreyBoxItem==cUGSDProgWPROID)
        {
            if(uTabBlkId==cWPROBlockID)
            {
                if((gsGbInfo.uGreyBoxOpt==cVOpProgQboot)&&(uSpr0==cWproQBootPg))
                {
                    triggerUGSD(cFalse);
                }
                else if((gsGbInfo.uGreyBoxOpt==cVOpSetFeature)&&(uSpr0==cWproFeaturePg))
                {
                    triggerUGSD(cFalse);
                }
                else if(uSpr0==cWproCacheInfo)
                {
                    if((gsGbInfo.uGreyBoxOpt==cVOpProgCacheInfoInitCache)||(gsGbInfo.uGreyBoxOpt==cVOpProgCacheInfoH2fFull))
                    {
                        triggerUGSD(cFalse);
                    }

                    // else if((gsGbInfo.uGreyBoxOpt==cVOpProgCacheInfoInitCacheDone)||(gsGbInfo.uGreyBoxOpt==cVOpProgCacheInfoH2fFullDone))
                    // {
                    //    triggerUGSD(cTrue);
                    // }
                }
            }
        }
        else if(gsGbInfo.uGreyBoxItem==cUGSDSecureEraseID)
        {
            if(gsGbInfo.uGreyBoxOpt==cVOpProgCacheInfoAfEraseAll)
            {
                if(uSpr0==cWproCacheInfo)
                {
                    triggerUGSD(cFalse);
                }
            }
        }
        else if(gsGbInfo.uGreyBoxItem==cUGSDSwapWproID)
        {
            if(uTabBlkId==cWPROBlockID)
            {
                triggerUGSD(cFalse);
            }
        }
        else if(gsGbInfo.uGreyBoxItem==cUGSDReclaimID)
        {
            if(gsGbInfo.uGreyBoxOpt==cVOpProgLastF2H)
            {
                if((uDataP23BlkId==cF2hTableID)&&((g16RwOpt&cProg32kF2H)&&((g32FPageNoTran/g16TotalTlcPgPerF2hTab)==(gTotalTlcBankOfF2hTab-1))))
                {
                    triggerUGSD(cFalse);
                }
            }
            else if(gsGbInfo.uGreyBoxOpt==cVOpProgH2fxHmb)
            {
                if(uTabBlkId==cH2fTableID)
                {
                    triggerUGSD(cFalse);
                }
            }
            else if(gsGbInfo.uGreyBoxOpt==cVOpProgWproGcInfo)
            {
                if(uTabBlkId==cWPROBlockID)
                {
                    if(uSpr0==cWproGcInfoPage)
                    {
                        triggerUGSD(cFalse);
                    }
                }
            }
        }
        else if(gsGbInfo.uGreyBoxItem==cUGSDProgIndxBlkID)
        {
            if((gsGbInfo.uGreyBoxOpt==cVOpAllConfig)&&(uTabBlkId==cIndexBlockID))
            {
                triggerUGSD(cFalse);
            }
            else if((gsGbInfo.uGreyBoxOpt==cVOpProgIndxBlkDone)&&(uTabBlkId==cIndexBlockID))
            {
                triggerUGSD(cTrue);
            }
        }
        else if(gsGbInfo.uGreyBoxItem==cUGSDS2TID)
        {
            if(gsGbInfo.uGreyBoxOpt==cVOpProgLastF2H)
            {
                if((uDataP23BlkId==cF2hTableID)&&
                   ((g16RwOpt&cProg32kF2H)&&((g32FPageNoTran/g16TotalTlcPgPerF2hTab)==(gTotalTlcBankOfF2hTab-1))))
                {
                    triggerUGSD(cFalse);
                }
            }
            else if(gsGbInfo.uGreyBoxOpt==cVOpProgH2fxHmb)
            {
                if(uTabBlkId==cH2fTableID)
                {
                    triggerUGSD(cFalse);
                }
            }
            else if(gsGbInfo.uGreyBoxOpt==cVOpProgWproGcInfo)
            {
                if(uTabBlkId==cWPROBlockID)
                {
                    if(uSpr0==cWproGcInfoPage)
                    {
                        triggerUGSD(cFalse);
                    }
                }
            }
        }
        else if(gsGbInfo.uGreyBoxItem==cUGSDGcH2fTableID)
        {
            if(gsGbInfo.uGreyBoxOpt==cVOpProgCacheInfoH2fFull)
            {
                if((uTabBlkId==cWPROBlockID)&&(uSpr0==cWproCacheInfo))
                {
                    triggerUGSD(cFalse);
                }
            }
        }
        else if(gsGbInfo.uGreyBoxItem==cRAIDEncOnGc)
        {
            if((uDataP23BlkId==cF2hTableID)&&((g16RwOpt&cProg32kF2H)&&((g32FPageNoTran/g16TotalTlcPgPerF2hTab)==(gTotalTlcBankOfF2hTab-1))))
            {
                g16GbFBlock=gpFlashAddrInfo->u16FBlock;
                g16GbFPage=gpFlashAddrInfo->u16FPage;
                gGbCh=gpFlashAddrInfo->uCh;
                gGbCe=gpFlashAddrInfo->uCe;
                gGbDieAddr=gpFlashAddrInfo->uDieAddr;
                gGbIntlvAddr=gpFlashAddrInfo->uIntlvAddr;
                gGbPlaneAddr=gpFlashAddrInfo->uPlaneAddr;
                gsGbInfo.uResult=cSuccess;
            }
        }

#if 0
        else if(gsGbInfo.uGreyBoxItem==cRAIDDecOnMoveReadData)
        {
            if((uDataP23BlkId==cF2hTableID)&&
               ((g16RwOpt&cProg32kF2H)&&((g32FPageNoTran/g16TotalTlcPgPerF2hTab)==(gTotalTlcBankOfF2hTab-1))))
            {
                gsGbInfo.uResult=cSuccess;
            }
        }
#endif
        else if((gsGbInfo.uGreyBoxItem==cUGSDT2TID)&&(mGetGcFlow==cGcFlowT2T))
        {
            if(gsGbInfo.uGreyBoxOpt==cVOpProgLastF2H)
            {
                if((uDataP23BlkId==cF2hTableID)&&
                   ((g16RwOpt&cProg32kF2H)&&((g32FPageNoTran/g16TotalTlcPgPerF2hTab)==(gTotalTlcBankOfF2hTab-1))))
                {
                    triggerUGSD(cFalse);
                }
            }
            else if(gsGbInfo.uGreyBoxOpt==cVOpProgH2fxHmb)
            {
                if(uTabBlkId==cH2fTableID)
                {
                    triggerUGSD(cFalse);
                }
            }
            else if(gsGbInfo.uGreyBoxOpt==cVOpProgWproGcInfo)
            {
                if(uTabBlkId==cWPROBlockID)
                {
                    if(uSpr0==cWproGcInfoPage)
                    {
                        triggerUGSD(cFalse);
                    }
                }
            }
        }
        else if((gsGbInfo.uGreyBoxItem==cUGSDS2SID)&&(mGetGcFlow==cGcFlowS2S))
        {
            if(gsGbInfo.uGreyBoxOpt==cVOpProgLastF2H)
            {
                if((uDataP23BlkId==cF2hTableID)&&((g32FPageNoTran/g16TotalPgPerF2hTab)==(gTotalBankOfF2hTab-1)))
                {
                    triggerUGSD(cFalse);
                }
            }
            else if(gsGbInfo.uGreyBoxOpt==cVOpProgH2fxHmb)
            {
                if(uTabBlkId==cH2fTableID)
                {
                    triggerUGSD(cFalse);
                }
            }
            else if(gsGbInfo.uGreyBoxOpt==cVOpProgWproGcInfo)
            {
                if(uTabBlkId==cWPROBlockID)
                {
                    if(uSpr0==cWproGcInfoPage)
                    {
                        triggerUGSD(cFalse);
                    }
                }
            }
        }
        else if((gsGbInfo.uGreyBoxItem==cUGSDonWearleveling)&&(mGetGcFlow==cGcFlowT2T))
        {
            if(gsGbInfo.uGreyBoxOpt==cVOpProgLastF2H)
            {
                if(uDataP23BlkId==cF2hTableID)
                {
                    triggerUGSD(cFalse);
                }
            }
            else if(gsGbInfo.uGreyBoxOpt==cVOpProgWproGcInfo)
            {
                if(uTabBlkId==cWPROBlockID)
                {
                    if(uSpr0==cWproGcInfoPage)
                    {
                        triggerUGSD(cFalse);
                    }
                }
            }
        }
        else if((gsGbInfo.uGreyBoxItem==cUGSDonEraseFail)&&
                ((gsGbInfo.uGreyBoxOpt==cVOpPopCacheSlcBfErase)||(gsGbInfo.uGreyBoxOpt==cVOpPopCacheSlcAfErase)||
                 (gsGbInfo.uGreyBoxOpt==cVOpPopH2fTableBfErase)||(gsGbInfo.uGreyBoxOpt==cVOpPopH2fTableAfErase)||
                 (gsGbInfo.uGreyBoxOpt==cVOpPopWPROIDBfErase)||(gsGbInfo.uGreyBoxOpt==cVOpPopWPROIDAfErase)))
        {
#if (_CODECOVER)
            addCoverageUart();
#endif

            while(1)
                ;
        }
    }

#if 0
    else if(gsGbInfo.uStag&cBit0)
    {
        if((gsGbInfo.uGreyBoxItem==cGCS2TThree2OneFull)&&(mGetGcFlow==cGcFlowS2T))
        {
            if((uDataP23BlkId==cF2hTableID)&&
               ((g16RwOpt&cProg32kF2H)&&((g32FPageNoTran/g16TotalTlcPgPerF2hTab)==(gTotalTlcBankOfF2hTab-1))))
            {
                gsGbInfo.uResult=cSuccess;
            }
        }

        if(((gsGbInfo.uGreyBoxItem==cGCT2TX2OneNotFull)||(gsGbInfo.uGreyBoxItem==cGCT2TSixteen2OneMoreFull))&&(mGetGcFlow==cGcFlowT2T))
        {
            if((uDataP23BlkId==cF2hTableID)&&
               ((g16RwOpt&cProg32kF2H)&&((g32FPageNoTran/g16TotalTlcPgPerF2hTab)==(gTotalTlcBankOfF2hTab-1))))
            {
                gsGbInfo.uResult=cSuccess;
            }
        }

        if((gsGbInfo.uGreyBoxItem==cGCS2SThirtytwo2OneNotFull)&&(mGetGcFlow==cGcFlowS2S))
        {
            if((uDataP23BlkId==cF2hTableID)&&((g32FPageNoTran/g16TotalPgPerF2hTab)==(gTotalBankOfF2hTab-1)))
            {
                gsGbInfo.uResult=cSuccess;
            }
        }
    }
#endif/* if 0 */
}    /* chkGreyBoxStu */

void chkGreyBoxGc(BYTE uStag)
{
    if(uStag==0)    // selectSrcBlk
    {
        if((gsGbInfo.uGreyBoxItem==cGCS2TThree2OneFull)||(gsGbInfo.uGreyBoxItem==cGCS2TSixteen2OneFull)||
           (gsGbInfo.uGreyBoxItem==cGCS2TSixteen2OneNotFull)||(gsGbInfo.uGreyBoxItem==cGCT2TX2OneNotFull)||
           (gsGbInfo.uGreyBoxItem==cGCT2TSixteen2OneMoreFull)||(gsGbInfo.uGreyBoxItem==cGCT2TX2OneFull)||
           (gsGbInfo.uGreyBoxItem==cGCPartialS2Tfour2OneFull)||(gsGbInfo.uGreyBoxItem==cGCS2SThirtytwo2OneNotFull)||
           (gsGbInfo.uGreyBoxItem==cSecurityRW))
        {
            BYTE uLoop;
            BYTE uStop=0;
            BYTE uIndex=0;
            BYTE uCompareStop=0;
            LWORD u32Loop;
            LWORD u32VpCnt;
            gGbGcSrcBlkCnt=gsGcInfo.uGcSrcBlkCnt;
            g32GbTotalSrcBlkVpc=gsGcInfo.u32TotalSrcBlkVpc;
            g16GbSpareBlockCnt=(gsCacheInfo.u16SLCSpareCnt+gsCacheInfo.u16DynamicSpareCnt);

            if((gsGbInfo.uGreyBoxItem==cGCS2TThree2OneFull)||(gsGbInfo.uGreyBoxItem==cGCS2TSixteen2OneFull)||
               (gsGbInfo.uGreyBoxItem==cGCS2TSixteen2OneNotFull)||
               (gsGbInfo.uGreyBoxItem==cGCPartialS2Tfour2OneFull))
            {
                if((mGetGcFlow==cGcFlowS2T)&&(g16GbGcDesTLCBlock==0))
                {
                    g16GbGcDesTLCBlock=c16BitFF;
                }
            }
            else if((gsGbInfo.uGreyBoxItem==cGCT2TX2OneNotFull)||(gsGbInfo.uGreyBoxItem==cGCT2TSixteen2OneMoreFull)||
                    (gsGbInfo.uGreyBoxItem==cGCT2TX2OneFull))
            {
                if((mGetGcFlow==cGcFlowT2T)&&(g16GbGcDesTLCBlock==0))
                {
                    g16GbGcDesTLCBlock=c16BitFF;
                }
            }
            else if((gsGbInfo.uGreyBoxItem==cGCS2SThirtytwo2OneNotFull))
            {
                if((mGetGcFlow==cGcFlowS2S)&&(g16GbGcDesTLCBlock==0))
                {
                    g16GbGcDesTLCBlock=c16BitFF;
                }
            }

            for(uLoop=0; uLoop<gsGcInfo.uGcSrcBlkCnt; uLoop++)
            {
                BYTE uNowGcSrcBlkIdx=gsGcInfo.uGcSrcBlkIdx[uLoop];
                g16GbGcSrcBlock[uLoop]=gsGcInfo.u16GcSrcBlock[uNowGcSrcBlkIdx];

                if((gsGbInfo.uGreyBoxItem==cGCS2TThree2OneFull)||(gsGbInfo.uGreyBoxItem==cGCS2TSixteen2OneFull)||
                   (gsGbInfo.uGreyBoxItem==cGCS2TSixteen2OneNotFull)||(gsGbInfo.uGreyBoxItem==cGCPartialS2Tfour2OneFull)||
                   (gsGbInfo.uGreyBoxItem==cGCS2SThirtytwo2OneNotFull)||(gsGbInfo.uGreyBoxItem==cSecurityRW))
                {
                    if(mChkMlcMoBit(g16GbGcSrcBlock[uLoop]))    // TLC
                    {
                        uStop=1;
                        break;
                    }
                }
                else if((gsGbInfo.uGreyBoxItem==cGCT2TX2OneNotFull)||
                        (gsGbInfo.uGreyBoxItem==cGCT2TSixteen2OneMoreFull)||
                        (gsGbInfo.uGreyBoxItem==cGCT2TX2OneFull))
                {
                    if(!(mChkMlcMoBit(g16GbGcSrcBlock[uLoop])))    // SLC
                    {
                        uStop=1;
                        break;
                    }
                }
            }

            if(uStop==0)
            {
                gsGbInfo.uStag|=cBit0;
            }

            uStop=0;

            for(u32Loop=g16FirstFBlock; u32Loop<g16TotalFBlock&&uStop!=1; u32Loop++)
            {
                uCompareStop=0;

                if((gsGbInfo.uGreyBoxItem==cGCS2TThree2OneFull)||(gsGbInfo.uGreyBoxItem==cGCS2TSixteen2OneFull)||
                   (gsGbInfo.uGreyBoxItem==cGCS2TSixteen2OneNotFull)||(gsGbInfo.uGreyBoxItem==cGCPartialS2Tfour2OneFull)||
                   (gsGbInfo.uGreyBoxItem==cGCS2SThirtytwo2OneNotFull))
                {
                    if(!mChkMlcMoBit(u32Loop))    // SLC
                    {
                        u32VpCnt=mGetCacheBlkVpCnt(u32Loop);
                    }
                    else
                    {
                        u32VpCnt=0;
                    }
                }
                else if((gsGbInfo.uGreyBoxItem==cGCT2TX2OneNotFull)||(gsGbInfo.uGreyBoxItem==cGCT2TSixteen2OneMoreFull)||
                        (gsGbInfo.uGreyBoxItem==cGCT2TX2OneFull))
                {
                    if(mChkMlcMoBit(u32Loop))    // TLC
                    {
                        u32VpCnt=mGetCacheBlkVpCnt(u32Loop);
                    }
                    else
                    {
                        u32VpCnt=0;
                    }
                }

                if(u32VpCnt!=0)
                {
                    for(uLoop=0; uLoop<gsGcInfo.uGcSrcBlkCnt; uLoop++)
                    {
                        if((u32Loop==gsGcInfo.u16GcSrcBlock[uLoop])||
                           (u32Loop==gsCacheInfo.u16ActiveCacheBlock)||
                           (u32Loop==gsCacheInfo.u16FluCacheBlock))
                        {
                            if((u32Loop==gsGcInfo.u16GcSrcBlock[uLoop]))
                            {
                                gpGbGcSrcIndex[uLoop]=uIndex;
                            }

                            uCompareStop=1;
                            break;
                        }
                    }

                    uIndex++;

                    if(uCompareStop==0)
                    {
                        for(uLoop=0; uLoop<gsGcInfo.uGcSrcBlkCnt; uLoop++)
                        {
                            if(u32VpCnt<mGetCacheBlkVpCnt(gsGcInfo.u16GcSrcBlock[uLoop]))
                            {
                                uStop=1;
                                break;
                            }
                        }
                    }
                }
            }

            if(uStop==0)
            {
                gsGbInfo.uStag|=cBit2;
            }
        }
        else if((gsGbInfo.uGreyBoxItem==cWearleveingRule)&&(mGetGcFlow==cGcFlowT2T))
        {
            for(BYTE uLoop=0; uLoop<gsGcInfo.uGcSrcBlkCnt; uLoop++)
            {
                BYTE uNowGcSrcBlkIdx=gsGcInfo.uGcSrcBlkIdx[uLoop];
                g16GbGcSrcBlock[uLoop]=gsGcInfo.u16GcSrcBlock[uNowGcSrcBlkIdx];

                if(gsGcInfo.u16GcSrcBlock[uNowGcSrcBlkIdx]==g16GbWLGcSrcTLCBlock)
                {
                    gsGbInfo.uStag|=cBit0;
                    break;
                }
            }
        }
        else if((gsGbInfo.uGreyBoxItem==cUGSDonWearleveling)&&(gsGbInfo.uGreyBoxOpt==cVOpNormal)&&(mGetGcFlow==cGcFlowT2T))
        {
            for(BYTE uLoop=0; uLoop<gsGcInfo.uGcSrcBlkCnt; uLoop++)
            {
                BYTE uNowGcSrcBlkIdx=gsGcInfo.uGcSrcBlkIdx[uLoop];
                g16GbGcSrcBlock[uLoop]=gsGcInfo.u16GcSrcBlock[uNowGcSrcBlkIdx];

                if(gsGcInfo.u16GcSrcBlock[uNowGcSrcBlkIdx]==g16GbWLGcSrcTLCBlock)
                {
                    gsGbInfo.uStag|=cBit0;
                    break;
                }
            }
        }
    }
    else if(uStag==1)    // initGcDesFblkProc
    {
        if((gsGbInfo.uGreyBoxItem==cGCS2TThree2OneFull)||(gsGbInfo.uGreyBoxItem==cGCS2TSixteen2OneFull)||
           (gsGbInfo.uGreyBoxItem==cGCS2TSixteen2OneNotFull)||(gsGbInfo.uGreyBoxItem==cGCPartialS2Tfour2OneFull)||
           (gsGbInfo.uGreyBoxItem==cSecurityRW))
        {
            if((g16GbGcDesTLCBlock==c16BitFF)&&(mGetGcFlow==cGcFlowS2T))
            {
                g16GbGcDesTLCBlock=gsGcInfo.u16GcDesTLCBlock;
            }

            if(mChkMlcMoBit(gsGcInfo.u16GcDesTLCBlock))    // TLC
            {
                gsGbInfo.uStag|=cBit1;
            }
        }
        else if((gsGbInfo.uGreyBoxItem==cGCT2TX2OneNotFull)||
                (gsGbInfo.uGreyBoxItem==cGCT2TSixteen2OneMoreFull)||
                (gsGbInfo.uGreyBoxItem==cGCT2TX2OneFull))
        {
            if((g16GbGcDesTLCBlock==c16BitFF)&&(mGetGcFlow==cGcFlowT2T))
            {
                g16GbGcDesTLCBlock=gsGcInfo.u16GcDesTLCBlock;
            }

            if(mChkMlcMoBit(gsGcInfo.u16GcDesTLCBlock))    // TLC
            {
                gsGbInfo.uStag|=cBit1;
            }
        }
        else if((gsGbInfo.uGreyBoxItem==cGCS2SThirtytwo2OneNotFull))
        {
            if((g16GbGcDesTLCBlock==c16BitFF)&&(mGetGcFlow==cGcFlowS2S))
            {
                g16GbGcDesTLCBlock=gsGcInfo.u16GcDesSLCBlock;
            }

            if(!(mChkMlcMoBit(gsGcInfo.u16GcDesBlock)))    // SLC
            {
                gsGbInfo.uStag|=cBit1;
            }
        }
        else if((gsGbInfo.uGreyBoxItem==cWearleveingRule))
        {
            if(gsGcInfo.u16GcDesTLCBlock==g16GbWLGcDesTLCBlock)
            {
                gsGbInfo.uStag|=cBit1;
            }
        }
        else if((gsGbInfo.uGreyBoxItem==cUGSDonWearleveling)&&(gsGbInfo.uGreyBoxOpt==cVOpNormal))
        {
            if(gsGcInfo.u16GcDesTLCBlock==g16GbWLGcDesTLCBlock)
            {
                gsGbInfo.uStag|=cBit1;
            }
        }
    }
    else if(uStag==2)    // end of GC
    {
        if((gsGbInfo.uGreyBoxItem==cGCS2TThree2OneFull)||(gsGbInfo.uGreyBoxItem==cGCS2TSixteen2OneFull)||
           (gsGbInfo.uGreyBoxItem==cGCS2TSixteen2OneNotFull)||(gsGbInfo.uGreyBoxItem==cGCT2TX2OneNotFull)||
           (gsGbInfo.uGreyBoxItem==cGCT2TSixteen2OneMoreFull)||(gsGbInfo.uGreyBoxItem==cGCT2TX2OneFull)||
           (gsGbInfo.uGreyBoxItem==cGCPartialS2Tfour2OneFull)||(gsGbInfo.uGreyBoxItem==cGCS2SThirtytwo2OneNotFull))
        {
            BYTE uLoop;
            LWORD u32VpCnt;
            BYTE uStop=0;

            if(gsGbInfo.uGreyBoxItem==cGCS2TThree2OneFull)
            {
                for(uLoop=0; uLoop<3; uLoop++)
                {
                    u32VpCnt=mGetCacheBlkVpCnt(g16GbGcSrcBlock[uLoop]);

                    if(u32VpCnt!=0)
                    {
                        // uStop=1;
                        break;
                    }
                }
            }
            else if(gsGbInfo.uGreyBoxItem==cGCPartialS2Tfour2OneFull)
            {
                for(uLoop=0; uLoop<gGbGcSrcBlkCnt; uLoop++)
                {
                    u32VpCnt=mGetCacheBlkVpCnt(g16GbGcSrcBlock[uLoop]);

                    if(u32VpCnt!=0)
                    {
                        uStop=1;
                        break;
                    }
                }
            }
            else if((gsGbInfo.uGreyBoxItem==cGCT2TSixteen2OneMoreFull)||
                    (gsGbInfo.uGreyBoxItem==cGCT2TX2OneFull)||(gsGbInfo.uGreyBoxItem==cGCT2TX2OneNotFull))
            {
                u32VpCnt=mGetCacheBlkVpCnt(g16GbGcSrcBlock[0]);

                if(u32VpCnt!=0)
                {
                    g16GbGcDesTLCBlock=0;
                    uStop=1;
                }
            }
            else
            {
                for(uLoop=0; uLoop<gGbGcSrcBlkCnt; uLoop++)
                {
                    u32VpCnt=mGetCacheBlkVpCnt(g16GbGcSrcBlock[uLoop]);

                    if(u32VpCnt!=0)
                    {
                        uStop=1;
                        break;
                    }
                }
            }

            if(uStop==0)
            {
                if((gsGbInfo.uGreyBoxItem==cGCS2SThirtytwo2OneNotFull))
                {
                    if(g32GbTotalSrcBlkVpc==(mGetCacheBlkVpCnt(g16GbGcDesTLCBlock)))
                    {
                        gsGbInfo.uStag|=cBit3;
                    }
                }
                else
                {
                    if(g32GbTotalSrcBlkVpc>=g32VpcPerTlcBlk)
                    {
                        if(mGetCacheBlkVpCnt(g16GbGcDesTLCBlock)==g32VpcPerTlcBlk)
                        {
                            gsGbInfo.uStag|=cBit3;
                        }
                    }
                    else
                    {
                        if(mGetCacheBlkVpCnt(g16GbGcDesTLCBlock)==g32GbTotalSrcBlkVpc)
                        {
                            gsGbInfo.uStag|=cBit3;
                        }
                    }
                }
            }

            if((gsGbInfo.uGreyBoxItem==cGCS2TThree2OneFull)&&
               ((gsCacheInfo.u16SLCSpareCnt+gsCacheInfo.u16DynamicSpareCnt)==(g16GbSpareBlockCnt+2)))
            {
                gsGbInfo.uStag|=cBit4;
                g16GbSpareBlockCnt=gsCacheInfo.u16SLCSpareCnt;
            }
            else if((gsGbInfo.uGreyBoxItem==cGCPartialS2Tfour2OneFull))
            {
                gsGbInfo.uStag|=cBit4;
                g16GbSpareBlockCnt=gsCacheInfo.u16SLCSpareCnt;
            }
            else if(((gsGbInfo.uGreyBoxItem==cGCS2TSixteen2OneFull)||
                     (gsGbInfo.uGreyBoxItem==cGCS2TSixteen2OneNotFull))&&
                    ((gsCacheInfo.u16SLCSpareCnt+gsCacheInfo.u16DynamicSpareCnt)==(g16GbSpareBlockCnt+(cMaxGcSrcBlkNum-1))))
            {
                gsGbInfo.uStag|=cBit4;
                g16GbSpareBlockCnt=gsCacheInfo.u16SLCSpareCnt;
            }
            else if((gsGbInfo.uGreyBoxItem==cGCT2TX2OneNotFull)&&
                    ((gsCacheInfo.u16SLCSpareCnt+gsCacheInfo.u16DynamicSpareCnt)==(g16GbSpareBlockCnt+gGbGcSrcBlkCnt-1)))
            {
                gsGbInfo.uStag|=cBit4;
                g16GbSpareBlockCnt=gsCacheInfo.u16SLCSpareCnt;
            }
            else if(((gsGbInfo.uGreyBoxItem==cGCT2TSixteen2OneMoreFull)||
                     (gsGbInfo.uGreyBoxItem==cGCT2TX2OneFull))&&
                    ((gsCacheInfo.u16SLCSpareCnt+gsCacheInfo.u16DynamicSpareCnt)==g16GbSpareBlockCnt))

            {
                gsGbInfo.uStag|=cBit0;
                gsGbInfo.uStag|=cBit4;
                g16GbSpareBlockCnt=gsCacheInfo.u16SLCSpareCnt;
            }
            else if((gsGbInfo.uGreyBoxItem==cGCS2SThirtytwo2OneNotFull)&&
                    ((gsCacheInfo.u16SLCSpareCnt+gsCacheInfo.u16DynamicSpareCnt)==(g16GbSpareBlockCnt+gGbGcSrcBlkCnt-1)))
            {
                gsGbInfo.uStag|=cBit4;
                g16GbSpareBlockCnt=gsCacheInfo.u16SLCSpareCnt;
            }

            if((gsGbInfo.uStag&cBit0)&&(gsGbInfo.uStag&cBit1)&&(gsGbInfo.uStag&cBit2)&&(gsGbInfo.uStag&cBit3)&&
               (gsGbInfo.uStag&cBit4))
            {
                gsGbInfo.uResult=cSuccess;
            }
        }
        else if((gsGbInfo.uGreyBoxItem==cWearleveingRule))
        {
            if(!(mGetCacheBlkVpCnt(g16GbWLGcSrcTLCBlock)))
            {
                gsGbInfo.uStag|=cBit2;
            }

            if(mGetCacheBlkVpCnt(g16GbWLGcDesTLCBlock)==g32VpcPerTlcBlk)
            {
                gsGbInfo.uStag|=cBit3;
            }

            if((gsGbInfo.uStag&cBit0)&&(gsGbInfo.uStag&cBit1)&&(gsGbInfo.uStag&cBit2)&&(gsGbInfo.uStag&cBit3))
            {
                gsGbInfo.uResult=cSuccess;
            }
        }
        else if((gsGbInfo.uGreyBoxItem==cUGSDonWearleveling)&&(gsGbInfo.uGreyBoxOpt==cVOpNormal))
        {
            if(!(mGetCacheBlkVpCnt(g16GbWLGcSrcTLCBlock)))
            {
                gsGbInfo.uStag|=cBit2;
            }

            if(mGetCacheBlkVpCnt(g16GbWLGcDesTLCBlock)==g32VpcPerTlcBlk)
            {
                gsGbInfo.uStag|=cBit3;
            }

            if((gsGbInfo.uStag&cBit0)&&(gsGbInfo.uStag&cBit1)&&(gsGbInfo.uStag&cBit2)&&(gsGbInfo.uStag&cBit3))
            {
                gsGbInfo.uResult=cSuccess;
            }
        }
        else if(gsGbInfo.uGreyBoxItem==cSecurityRW)
        {
            if((gsGbInfo.uStag&cBit0)&&(gsGbInfo.uStag&cBit1))
            {
                gsGbInfo.uResult=cSuccess;
            }
        }
    }
    else if(uStag==3)    // srchGcSrcF2hTab  //chkPWRCore1
    {
        g16GbCounter=0;

        if((gsGbInfo.uGreyBoxItem==cGCPartialS2Tfour2OneFull))
        {
            mSetGcFlag(cBrkBgdGcF);
        }
    }
    else if(uStag==4)    // mGetGcState==cGcMoveData
    {
        g16GbCounter++;

        if(gsGcInfo.uGcState==cGcMoveData)
        {
            if((gsGbInfo.uGreyBoxItem==cGCPartialS2Tfour2OneFull)&&(g16GbCounter%100==0))
            {
                g16GbCounter=0;
                mSetGcFlag(cBrkBgdGcF);
            }
        }
        else if(gsGcInfo.uGcState==cGcPostWriteRead)
        {
            if((gsGbInfo.uGreyBoxItem==cGCPartialS2Tfour2OneFull)&&(g16GbCounter%100==0))
            {
                g16GbCounter=0;
                mSetGcFlag(cBrkBgdGcF);
            }
        }
    }
    else
    {}
}    /* chkGreyBoxGc */

#if !_CPUID
WORD getGreyBoxDifferFBlk(WORD u16FBlock, BYTE uCh, BYTE uIntlvIdx, BYTE uPlaneIdx)
{
    TASKENTRY usTskEntry;
    WORD u16FBlockTemp=c16BitFF;

    usTskEntry.uTskTyp=cTskGetDifferAddr;
    gsTskFifoCtrl.u16PopFBlk=u16FBlock;
    gsTskFifoCtrl.u16PushFBlk=uCh;
    gsTskFifoCtrl.u16Seed=uIntlvIdx;
    gsTskFifoCtrl.u16EraseCnt=uPlaneIdx;

    insertTaskFifo(usTskEntry);

    while(gsTskFifoCtrl.u32HeadPtr!=gsTskFifoCtrl.u32TailPtr)
        ;

    u16FBlockTemp=gsTskFifoCtrl.u16FBlk;

    gsTskFifoCtrl.u16FBlk=c16BitFF;
    gsTskFifoCtrl.u16PopFBlk=c16FBlockInitValue;
    gsTskFifoCtrl.u16PushFBlk=c16FBlockInitValue;

    return u16FBlockTemp;
}    /* getGreyBoxDifferFBlk */

#endif/* if !_CPUID */

void saveRamInfo()
{
#if 0    // _CPUID
    BYTE uPageLoop;
    ADDRINFO usTmpAddrInfo;

    // save as Fw-Information
    waitAllChCeBz();
    gpFlashAddrInfo=&usTmpAddrInfo;
    g16FBlock=g16FirstFBlock;
    gPlaneAddr=0x00;
    gCh=0x00;
    gIntlvAddr=0x00;
    g16FPage=0x00;
    mSetTabSpr(gpFlashAddrInfo, cBit5);    // gTabSpare=1;
    gSectorH=0;
    mClrMlcMoBit(g16FBlock);
    // waitAllChCeBz();
    setFLActCh(0x00);
    flashErase(0x00);

    // H2F c32H2fTabRamSize
    for(uPageLoop=0; uPageLoop<((c32H2fTabRamSize>>cSingleSectorShift)/gSectorPerPlaneH); uPageLoop++)
    {
        setSprByteOfTabBlk(cGreyBoxBlockID, cGreyBoxH2f, uPageLoop, cZero, cZero, gPlaneAddr, cZero);
        // waitAllChCeBz();
        setFLActCh(0);
        mSetFRwParam(c16H2fTabSIdx, gSectorPerPlaneH, c16Bit4|c16Bit14, cVenderWrite);
        flashProgPage(c16H2fTabSIdx, gSectorPerPlaneH, c16Bit4|c16Bit14);
        g16FPage++;
    }

    // DTCM (Core0) cDtcmSize
    fillCcmVal((BYTE *)&garH2f1kTable[0][0], c32H2fTabRamSize, cZero);    // clear tsb 64k bytes
    copyCcmVal((BYTE *)&garH2f1kTable[0][0], (BYTE *)c32GreyBoxBuf, c16DccmSizeByte);

    for(uPageLoop=0; uPageLoop<((c16DccmSizeByte>>cSingleSectorShift)/gSectorPerPlaneH); uPageLoop++)
    {
        // waitAllChCeBz();
        setFLActCh(0);
        setSprByteOfTabBlk(cGreyBoxBlockID, cGreyBoxDtcmCore0, uPageLoop, cZero, cZero, gPlaneAddr, cZero);
        mSetFRwParam(c16H2fTabSIdx, gSectorPerPlaneH, c16Bit4|c16Bit14, cVenderWrite);
        flashProgPage(c16H2fTabSIdx, gSectorPerPlaneH, c16Bit4|c16Bit14);
        g16FPage++;
    }

    // DTCM (Core1) cDtcmSize
    fillCcmVal((BYTE *)&garH2f1kTable[0][0], c32H2fTabRamSize, cZero);    // clear tsb 64k bytes
    copyCcmVal((BYTE *)&garH2f1kTable[0][0], (BYTE *)cDtcmAddr, c16DccmSizeByte);

    for(uPageLoop=0; uPageLoop<((c16DccmSizeByte>>cSingleSectorShift)/gSectorPerPlaneH); uPageLoop++)
    {
        // waitAllChCeBz();
        setFLActCh(0);
        setSprByteOfTabBlk(cGreyBoxBlockID, cGreyBoxDtcmCore1, uPageLoop, cZero, cZero, gPlaneAddr, cZero);
        mSetFRwParam(c16H2fTabSIdx, gSectorPerPlaneH, c16Bit4|c16Bit14, cVenderWrite);
        flashProgPage(c16H2fTabSIdx, gSectorPerPlaneH, c16Bit4|c16Bit14);
        g16FPage++;
    }

    // STCM
    fillCcmVal((BYTE *)&garH2f1kTable[0][0], c32H2fTabRamSize, cZero);    // clear tsb 64k bytes
    copyCcmVal((BYTE *)&garH2f1kTable[0][0], (BYTE *)cParaAddr, cStcmSize);

    for(uPageLoop=0; uPageLoop<(((cStcmSize+cParaSize)>>cSingleSectorShift)/gSectorPerPlaneH); uPageLoop++)
    {
        // waitAllChCeBz();
        setFLActCh(0);
        setSprByteOfTabBlk(cGreyBoxBlockID, cGreyBoxStcm, uPageLoop, cZero, cZero, gPlaneAddr, cZero);
        mSetFRwParam(c16H2fTabSIdx, gSectorPerPlaneH, c16Bit4|c16Bit14, cVenderWrite);
        flashProgPage(c16H2fTabSIdx, gSectorPerPlaneH, c16Bit4|c16Bit14);
        g16FPage++;
    }

    // CachInfo
    fillCcmVal((BYTE *)&garH2f1kTable[0][0], c32H2fTabRamSize, cZero);    // clear tsb 64k bytes
    copyCcmVal((BYTE *)&garH2f1kTable[0][0], (BYTE *)&gsCacheInfo, c32CacheInfoTabRamSize);

    for(uPageLoop=0; uPageLoop<((c32CacheInfoTabRamSize>>cSingleSectorShift)/gSectorPerPlaneH); uPageLoop++)
    {
        // waitAllChCeBz();
        setFLActCh(0);
        setSprByteOfTabBlk(cGreyBoxBlockID, cGreyBoxCachInfo, uPageLoop, cZero, cZero, gPlaneAddr, cZero);
        mSetFRwParam(c16H2fTabSIdx, gSectorPerPlaneH, c16Bit4|c16Bit14, cVenderWrite);
        flashProgPage(c16H2fTabSIdx, gSectorPerPlaneH, c16Bit4|c16Bit14);
        g16FPage++;
    }

    // F2H
    fillCcmVal((BYTE *)&garH2f1kTable[0][0], c32H2fTabRamSize, cZero);    // clear tsb 64k bytes
    copyCcmVal((BYTE *)&garH2f1kTable[0][0], (BYTE *)&garCacheF2hTab, c32CacheF2hRamSize);

    for(uPageLoop=0; uPageLoop<((c32CacheF2hRamSize>>cSingleSectorShift)/gSectorPerPlaneH); uPageLoop++)
    {
        // waitAllChCeBz();
        setFLActCh(0);
        setSprByteOfTabBlk(cGreyBoxBlockID, cGreyBoxF2h, uPageLoop, cZero, cZero, gPlaneAddr, cZero);
        mSetFRwParam(c16H2fTabSIdx, gSectorPerPlaneH, c16Bit4|c16Bit14, cVenderWrite);
        flashProgPage(c16H2fTabSIdx, gSectorPerPlaneH, c16Bit4|c16Bit14);
        g16FPage++;
    }

    // GreyBox Info
    fillCcmVal((BYTE *)&garH2f1kTable[0][0], c32H2fTabRamSize, cZero);    // clear tsb 64k bytes
    copyCcmVal((BYTE *)&garH2f1kTable[0][0], (BYTE *)&gsGbInfo, sizeof(GBINFO));

    for(uPageLoop=0; uPageLoop<(gSectorPerPlaneH/gSectorPerPlaneH); uPageLoop++)
    {
        // waitAllChCeBz();
        setFLActCh(0);
        setSprByteOfTabBlk(cGreyBoxBlockID, cGreyBoxGbInfo, uPageLoop, cZero, cZero, gPlaneAddr, cZero);
        mSetFRwParam(c16H2fTabSIdx, gSectorPerPlaneH, c16Bit4|c16Bit14, cVenderWrite);
        flashProgPage(c16H2fTabSIdx, gSectorPerPlaneH, c16Bit4|c16Bit14);
        g16FPage++;
    }

    // Save the last gpFlashAddrInfo
    fillCcmVal((BYTE *)&garH2f1kTable[0][0], gSectorPerPageH, cZero);
    copyCcmVal((BYTE *)&garH2f1kTable[0][0], (BYTE *)&gsFlashAddrInfoTemp, sizeof(ADDRINFO));
    // waitAllChCeBz();
    setFLActCh(0);
    setSprByteOfTabBlk(cGreyBoxBlockID, cGreyBoxAddrInfo, cZero, cZero, cZero, gPlaneAddr, cZero);
    mSetFRwParam(c16H2fTabSIdx, gSectorPerPlaneH, c16Bit4|c16Bit14, cVenderWrite);
    flashProgPage(c16H2fTabSIdx, gSectorPerPlaneH, c16Bit4|c16Bit14);
    g16FPage++;

    // Dummy program
    fillCcmVal((BYTE *)&garH2f1kTable[0][0], gSectorPerPageH, cZero);

    while(g16FPage<g16PagePerBlock1_SLC)
    {
        // waitAllChCeBz();
        setFLActCh(0);
        setSprByteOfTabBlk(cGreyBoxBlockID, cGreyBoxDummy, g16FPage, cZero, cZero, gPlaneAddr, cZero);
        mSetFRwParam(c16H2fTabSIdx, gSectorPerPlaneH, c16Bit4|c16Bit14, cVenderWrite);
        flashProgPage(c16H2fTabSIdx, gSectorPerPlaneH, c16Bit4|c16Bit14);
        g16FPage++;
    }
    waitAllChCeBz();
#endif/* if _CPUID */
}    /* saveRamInfo */

#if ((!_ICE_LOAD_ALL)||(_CPUID))
#pragma default_function_attributes =
#endif

#endif/* if _GREYBOX */

#if _INITDRAM
/* Output String by UART*/
void outString(CBYTE *ups, LWORD u32Val)
{
#if (!_CODECOVER)
    BYTE uLoop, uarVal[8];
    BYTE uTempVal;

    rmWaitUartBusy;

    while(*ups!=0x00)
    {
        if(*ups!=cCharAt)
        {
            rmUartTxByte(*ups);
        }
        else
        {
            rmUartTxByte('0');
            rmUartTxByte('x');

            for(uLoop=0; uLoop<8; uLoop++)
            {
                uTempVal=u32Val&0xF;

                if(uTempVal<0xA)
                {
                    uarVal[uLoop]=uTempVal+cAsciiTo0;
                }
                else
                {
                    uarVal[uLoop]=(uTempVal-0xA)+cAsciiToA;
                }

                u32Val=u32Val>>4;    // 0xF

                if(!u32Val)
                {
                    break;
                }
            }

            uLoop++;

            while(uLoop!=0)
            {
                rmWaitUartBusy;
                rmUartTxByte(uarVal[--uLoop]);
            }
        }

        ups++;
    }

#if (!_CODECOVER)
    rmNewLine;
#endif
#endif/* if (!_CODECOVER) */
}    /* outString */

void outInfo(BYTE uInfoType)
{
#if (!_CODECOVER)
    rmNewLine;

    switch(uInfoType)
    {
        /* here is related with Address */
        case cGbHqInfo:
            outString(cVHqInfo, 0);
            outString("rmNvmeLbaLow=@", rmNvmeLbaLow);
            outString("rmNvmeNlb=@", rmNvmeNlb);
            outString("rmNvmeOpCode=@", rmNvmeOpCode);
            outString("rmNvmeCqId=@", rmNvmeCqId);
            outString("rmNvmeSqId=@", rmNvmeSqId);
            outString("rmNvmeSgl=@", rmNvmeSgl);
            break;

        default:
            break;
    }    /* switch */

    rmNewLine;
    rmNewLine;
#endif/* if (!_CODECOVER) */
}    /* outInfo */

/* Output Call Stack by UART*/
void outCS(CBYTE *upCallStack)
{
#if (!_CODECOVER)
    outString((CBYTE *)upCallStack, 0);
#endif/* if (!_CODECOVER) */
}

/* Output Verify Status */
void outSta(CBYTE *upSta)
{
#if (!_CODECOVER)
    rmNewLine;
    outString((CBYTE *)upSta, 0);
#endif/* if (!_CODECOVER) */
}

#endif/* if (_INITDRAM) */







