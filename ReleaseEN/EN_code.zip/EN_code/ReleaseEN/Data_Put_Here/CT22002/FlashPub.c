







#if (!_ICE_LOAD_ALL)
#pragma default_function_attributes = @ ".FSH_PUB"
#endif

void setFRwParam(WORD u16BufPtr, BYTE uSctrCnt, WORD u16Opt, BYTE uOpTyp)
{
    gOpTyp=uOpTyp;
    gpFlashAddrInfo->uRwHalfKb=uSctrCnt;
    gpFlashAddrInfo->u16BufPtr=u16BufPtr;
    gpFlashAddrInfo->u16RwOpt=u16Opt;
}

// void tranCeNum(ADDRINFO *upTmpAddrInfo)    // WORD u16Fblock)
// {
//    upTmpAddrInfo->u16AbstractFBlock=upTmpAddrInfo->u16FBlock;
//    gActiveCe=div(upTmpAddrInfo->u16FBlock, g16FBlockPerCe);
//    upTmpAddrInfo->uCe=gActiveCe;
//    // upTmpAddrInfo->u16FBlock=_lr(rcRemainder);
//    upTmpAddrInfo->u16FBlock=mod(upTmpAddrInfo->u16FBlock, g16FBlockPerCe);
// }

void setFLAddrActCh(BYTE uChNum, ADDRINFO *upAddrInfo)
{
    setFLActCh(uChNum);
    gpFlashAddrInfo=upAddrInfo;
}

WORD tranRsvBlkAddr(BYTE uSysBlkAddr, ADDRINFO *usTmpAddrInfo)
{
#if 0
    WORD u16Rem;

    usTmpAddrInfo->u16FBlock=div(uSysBlkAddr, gTotalIntlvChNum*gPlaneNum);
    u16Rem=uSysBlkAddr%(gTotalIntlvChNum*gPlaneNum);
    usTmpAddrInfo->uPlaneAddr=div(u16Rem, gTotalIntlvChNum)    /* *gLogiPlaneNum*/;
    u16Rem=u16Rem%gTotalIntlvChNum;
    usTmpAddrInfo->uIntlvAddr=div(u16Rem, gTotalChNum);
    usTmpAddrInfo->uCh=u16Rem%gTotalChNum;
    usTmpAddrInfo->uDieAddr=mGetDieAddr(usTmpAddrInfo->uIntlvAddr);

    mClrMlcMoBit(usTmpAddrInfo->u16FBlock);
    // usTmpAddrInfo->ubLsbOnly=1;
    return usTmpAddrInfo->u16FBlock;
#else
    WORD u16Rem;

    usTmpAddrInfo->u16FBlock=uSysBlkAddr/(gTotalIntlvChNum*gPlaneNum);
    u16Rem=uSysBlkAddr%(gTotalIntlvChNum*gPlaneNum);
    usTmpAddrInfo->uPlaneAddr=u16Rem/gTotalIntlvChNum;
    u16Rem=u16Rem%gTotalIntlvChNum;
    usTmpAddrInfo->uIntlvAddr=u16Rem/gTotalChNum;
    usTmpAddrInfo->uCh=u16Rem%gTotalChNum;
    usTmpAddrInfo->uDieAddr=mGetDieAddr(usTmpAddrInfo->uIntlvAddr);
    usTmpAddrInfo->uCe=(BYTE)mGetCEAddr(usTmpAddrInfo->uIntlvAddr);
    mClrMlcMoBit(usTmpAddrInfo->u16FBlock);
    // usTmpAddrInfo->ubLsbOnly=1;
    return usTmpAddrInfo->u16FBlock;
#endif/* if 0 */
}    /* tranRsvBlkAddr */

void getSprByte(BLKSPRINFO *upBlkSprInfo, BYTE uPlane)
{
    BYTE uSprOfst;
    WORD *u16pSprPtr;
    BYTE uLoop;

    // only use plane 0 & 1, 2263 HW issue, get wrong plane 2 spare
#if (!_HwPlane2SprIssue)
    uSprOfst=div(rcP0SprSeed+(uPlane*cSprGrpOffset), 2);
#else
    uSprOfst=div(rcP0SprSeed+((uPlane%2)*cSprGrpOffset), 2);
#endif
    u16pSprPtr=&(upBlkSprInfo->u16Seed);

    for(uLoop=0; uLoop<(cExtSprByteNum/2); uLoop++)
    {
        *u16pSprPtr=r16FLCtrl[uSprOfst+uLoop];
        u16pSprPtr++;
    }
}    /* getSprByte */

// <<< merge 58xt IM3D

void setFLActCh(BYTE uChNum)
{
#if (_CPUID==1)
    gActiveCh=uChNum;
#endif
    uChNum=garChMapTable[uChNum];
    rFLCtrl=(void *)regFSHA[uChNum];
    r16FLCtrl=(void *)reg16FSHA[uChNum];
    r32FLCtrl=(void *)reg32FSHA[uChNum];
    rmSetLdpcChannel(uChNum);
}

void insertTaskFifo(TASKENTRY usTskEntry)
{
    BYTE uHeadPtr=gsTskFifoCtrl.u32HeadPtr;

    while(((gsTskFifoCtrl.u32HeadPtr+1)&cTaskDepMsk)==gsTskFifoCtrl.u32TailPtr)
        ;

    gsTskFifoCtrl.uarTskFifo[uHeadPtr].u16TskSBufPtr=usTskEntry.u16TskSBufPtr;
    gsTskFifoCtrl.uarTskFifo[uHeadPtr].uTskPgOfst=usTskEntry.uTskPgOfst;
    gsTskFifoCtrl.uarTskFifo[uHeadPtr].uTskTyp=usTskEntry.uTskTyp;
    gsTskFifoCtrl.uarTskFifo[uHeadPtr].uTskOpt=usTskEntry.uTskOpt;
    gsTskFifoCtrl.u32HeadPtr=(uHeadPtr+1)&cTaskDepMsk;
}

void setBufStatus(WORD u16BufSecIdx, WORD u16SecCnt, BYTE uTSBx)
{
    // toggle buf bits
    LWORD u32Pat;
    BYTE uShift;
    WORD u16ByteIdx;
    BYTE uSecCnt1;

    u16ByteIdx=(u16BufSecIdx>>5);    // 1 bit for 512Byte, 4k => 1Byte
    uShift=(u16BufSecIdx&0x1F);
    uSecCnt1=32-uShift;

    while(u16SecCnt)
    {
        if(uSecCnt1>u16SecCnt)
        {
            uSecCnt1=u16SecCnt;
        }

        u32Pat=cb32BitNumTab[uSecCnt1];

        rm32BufStatus(u16ByteIdx)=(u32Pat<<uShift);    // fill 1 to toggle the buf flag

        u16SecCnt-=uSecCnt1;
        u16ByteIdx++;

        if(uTSBx==cTsb0)
        {
            if(u16ByteIdx==(cTsb0Size>>5))
            {
                u16ByteIdx=cTsb0StartBufIdx>>5;
            }
        }
        else if(uTSBx==cTsb1)
        {
            if(u16ByteIdx==((cTsb0Size+cTsb1Size)>>5))
            {
                u16ByteIdx=cTsb1StartBufIdx>>5;
            }
        }
        else    // if(uTSBx == C_TSBFull)
        {
            if(u16ByteIdx==(cTsbSize>>5))
            {
                u16ByteIdx=cTsb0StartBufIdx>>5;
            }
        }

        uShift=0;
        uSecCnt1=32;
    }
}    /* setBufStatus */

void tranType2Addr(ADDRINFO *upTmpAddrInfo, WORD u16Ty2Block)
{
    BYTE uAddr;

    // BYTE uPlaneBitCnt, uIntlvBitCnt, uPlaneBitShift, uIntlvBitShift, uChBitShift;

    upTmpAddrInfo->u16FBlock=u16Ty2Block&g16BlockBitMask;
    uAddr=u16Ty2Block>>gBlockBitCnt;
    upTmpAddrInfo->uCh=uAddr/gIntlvPlaneNum;
    uAddr%=gIntlvPlaneNum;
    upTmpAddrInfo->uIntlvAddr=uAddr/gPlaneNum;
    upTmpAddrInfo->uPlaneAddr=uAddr%gPlaneNum;
}

#if (_CPUID==1)
// move from write.c
void setSprByteOfDataBlk(BYTE uProgFifoPtr)
{
    LWORD u32Serial;
    BYTE uPlane=gPlaneAddr, uPlaneCnt=gpFlashAddrInfo->uPlaneCnt, uSavePlaneCnt, uBlkId=gBlkId, uSprOfst, uLoop, uSecNumPadF2h_1, uCh;

    uCh=gActiveCh;

    if(uProgFifoPtr==gProgFifoPtr)
    {
        gpFlashAddrInfo=&garDesAddrInfo[gProgFifoPtr];

        if(gpFlashAddrInfo->uOpTyp==cErrHdlDummyProg)
        {
            uCh=gCh;
            uPlane=0;
            uPlaneCnt=gpFlashAddrInfo->uPlaneCnt;
            uBlkId=gBlkId;
        }
        else
        {
            gsFtlDbg.u16DummyFailType=cSetSprByteOfDataBlk;
            debugWhile();
        }
    }

    if(!gbLsbOnly)
    {
        uSecNumPadF2h_1=gTlcSecNumPadF2h_1;
    }
    else
    {
        uSecNumPadF2h_1=gSlcSecNumPadF2h_1;
    }

    if(uBlkId==cGcDesBlockID)
    {
        if(mGetWriteOpt&cProg16kF2H)
        {
            uPlaneCnt-=gsGcInfo.uGCDesPadF2h4KNum;
        }

#if _EN_RAID_GC
        else if(mGetWriteOpt&cProgPlaneRaid)
        {
            uPlaneCnt-=c4kNumPerRaidPty;
        }
#endif
        u32Serial=gsGcInfo.u32GcDesSerial;
    }
    else if(uBlkId==cCacheBlockID)
    {
#if _ENABLE_RAID
        if((mGetWriteOpt&(cProg32kF2H|cProgPlaneRaid))==(cProg32kF2H|cProgPlaneRaid))
        {
            uPlaneCnt-=c4kNumPerRaidPty;
        }
#endif
        u32Serial=gsCacheInfo.u32CacheBlkSerial;
    }

    uSavePlaneCnt=uPlaneCnt;

    if(mGetWriteOpt&cProg32kF2H)
    {
        uBlkId=cF2hTableID;
    }

    while(uSavePlaneCnt)
    {
        if((gSparePtrHead[uCh]&(cSpareRegisterCnt-1))<4)
        {
            rmSelSprGroup(0);
        }
        else
        {
            rmSelSprGroup(1);
        }

        uSprOfst=(rcSpr0+((gSparePtrHead[uCh]&3)*cSprGrpOffset))>>1;

        if(uBlkId==cGcDesBlockID)
        {
            if(uPlane)
            {
                u32Serial=gsGcInfo.u32FluBlkSerial;
            }
            else
            {
                u32Serial=gsGcInfo.u32GcDesSerial;
            }
        }

        r16FLCtrl[uSprOfst+8]=uBlkId+(gOpTyp<<8);
        r16FLCtrl[uSprOfst+9]=u32Serial&0xFFFF;
        r16FLCtrl[uSprOfst+10]=u32Serial>>16;

        // if(uPlane==0)
        // {
        r16FLCtrl[uSprOfst+11]=mGetGlobEraseCnt(g16AbstrFBlock);
        // }
        // else
        // {
        //    r16FLCtrl[uSprOfst+11]=g32PowerOnCnt&0xFFFF;    // g16PowerOnCnt;
        // }

        uLoop=0;

        while(uLoop<(g4kNumPerPlane<<cFillSpareSizeOfSprSet))
        {
            r16FLCtrl[uSprOfst+uLoop]=garDesF2hInfo[uProgFifoPtr].u16arHPage[(uLoop>>1)+uPlane*g4kNumPerPlane];
            r16FLCtrl[uSprOfst+uLoop+1]=garDesF2hInfo[uProgFifoPtr].u16arHBlock[(uLoop>>1)+uPlane*g4kNumPerPlane];
            uLoop+=2;
        }

        if(uSavePlaneCnt>=(g4kNumPerPlane<<cPlaneShiftOfSprSet))
        {
            uSavePlaneCnt-=(g4kNumPerPlane<<cPlaneShiftOfSprSet);
            uPlane+=cPlaneNumInSprSet;
        }
        else
        {
            uSavePlaneCnt=0;
        }

        gSpareCnt[uCh]++;
        gSparePtrHead[uCh]=addPtrBy1(gSparePtrHead[uCh], cSpareRegisterCnt);

        if((uSavePlaneCnt==0)&&(uBlkId!=cF2hTableID)&&(mGetWriteOpt&cProg16kF2H))
        {
            uBlkId=cF2hTableID;
            uSavePlaneCnt=(uSecNumPadF2h_1>>3);
        }

#if _ENABLE_RAID
        else if((uSavePlaneCnt==0)&&(uBlkId!=cRaidParityID)&&(mGetWriteOpt&cProgPlaneRaid))
        {
            uBlkId=cRaidParityID;
            uSavePlaneCnt=c4kNumPerRaidPty;
        }
#endif
    }
}    /* setSprByteOfDataBlk */

#endif/* if (_CPUID==1) */

#if (!_ICE_LOAD_ALL)
#pragma default_function_attributes =
#endif







