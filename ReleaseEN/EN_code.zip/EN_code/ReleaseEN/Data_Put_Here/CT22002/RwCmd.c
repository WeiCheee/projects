







// #if (_CPUID!=1)
#include "inc/Const.h"
#include "inc/TypeDef.h"
#include "inc/Option.h"
#include "inc/ProType.h"
#include "inc/GlobVarS.h"
#include "inc/GlobVar0.h"
#include "inc/NvmeCtrl.h"
#include "inc/BitDef.h"
#include "inc/NvmeCtrl.h"
#include "inc/Reg.h"
#include "inc/Mac.h"
#include "inc/Rdlink.h"
#include "inc/GreyBox.h"

#if (!_ICE_LOAD_ALL)
#pragma default_function_attributes = @ ".CORE0_ISP"
#endif

#include "TaskFuncForPrj.c"
#include "F2hTab.c"
#include "H2fTab.c"
#include "Read.c"
#include "Write.c"
#include "GcCacheB.c"
#include "GcH2fTab.c"
#include "NvmeIoCmd.c"
// #include "FakeEngine.c"
// #include "FakeScript.c"
#include "TrimCmd.c"
#if (!_ICE_LOAD_ALL)
// #include "Core0TempInvFunc.c"
// #include "BootFshCmdHS.c"
#include "Ftl.c"
#else
#include "Hmb.c"
#endif
#include "NvmeCommonFunc.c"
#include "E2e.c"
#if _EN_WriteZeroNonAlign    // WriteZeroNonAlign_20181031_Chief
void WriteZeroFillup(LWORD u32LBA, BYTE uSCnt)
{
    HADDRINFO usTmpHAddrInfo;
    WORD u16NowNodeIdx;
    BYTE uStartSctr, uEndSctr;
    LWORD u32DesAddr, u32XfrCnt;

    NLOG(cLogHost, RWCMD_C, 3, "WriteZeroFillup u32LBA=0x%08X, uSCnt=0x%04X", u32LBA>>16, u32LBA, uSCnt);
    // step 2 : assign read fifo
    tranLba2HAddr(u32LBA&(~(cSctrPer4k-1)), &usTmpHAddrInfo);

    gsCacheInfo.u16SrchRslFBlock=c16FBlockInitValue;
    gsCacheInfo.u32SrchRslFPage=c32BitFF;
    findReadSrc(g16HBlock, g16HPage, 0);

    u16NowNodeIdx=gsRwCtrl.uarFreeSrcQue[gsRwCtrl.u32FreeSrcFifoHead];
    gpFlashAddrInfo=&garSrcAddrInfo[u16NowNodeIdx];
    g32FPageNoTran=gsCacheInfo.u32SrchRslFPage;
    gpFlashAddrInfo->uPrdPtr=0xF0;
    gpFlashAddrInfo->uTsb4kIdx=0xFF;
    gpFlashAddrInfo->uSrcIdx=u16NowNodeIdx;

    if(gsCacheInfo.u16SrchRslFBlock==c16FBlockInitValue)
    {
        NLOG(cLogHost, RWCMD_C, 2, "Src is dummy u32LBA=0x%08X", u32LBA>>16, u32LBA);
        g16FBlock=g16AbstrFBlock=0;
        mSetFRwParam(g16WriteBufPtr, cSctrPer4k, 0, cSecReadDummy);
    }
    else
    {
        g16FBlock=gsCacheInfo.u16SrchRslFBlock;
        gSectorH=mTranSctr4kAddr(g32FPageNoTran);
        NLOG(cLogHost,
             RWCMD_C,
             4,
             "Src Block=0x%04X, sectorH=0x%04X, g32FPageNoTran=0x%08X",
             g16FBlock,
             gSectorH,
             g32FPageNoTran>>16,
             g32FPageNoTran);
        tranAddrInfo(gpFlashAddrInfo);
        mSetFRwParam(g16WriteBufPtr, cSctrPer4k, c16Bit4, cSecReadData);
    }

    gsRwCtrl.u32FreeSrcFifoHead=(gsRwCtrl.u32FreeSrcFifoHead+1)&(cReadFifoDpt-1);

    while(gsRwCtrl.u32FreeSrcFifoTail!=gsRwCtrl.u32FreeSrcFifoHead)
        ;// 20190103_Chrissu

    NLOG(cLogHost, RWCMD_C, 1, "WriteZeroFillup gsRwCtrl.u32FreeSrcFifoHead=0x%04X", gsRwCtrl.u32FreeSrcFifoHead);
    uStartSctr=u32LBA&(cSctrPer4k-1);
    uEndSctr=uStartSctr+uSCnt;
    u32DesAddr=c32Tsb0SAddr+0x200*(g16WriteBufPtr+uStartSctr);
    u32XfrCnt=0x200*(uEndSctr-uStartSctr);
    NLOG(cLogHost, RWCMD_C, 3, "WriteZeroFillup uStartSctr=0x%04X, uEndSctr=0x%04X, g16WriteBufPtr=0x%04X", uStartSctr, uEndSctr,
         g16WriteBufPtr);
    bopClrRam((LWORD)u32DesAddr, (LWORD)u32XfrCnt, gsNamespace.u32DummyPatt, cClrTsb|cBopWait|cBopEnCrc|cBopGenCrc);
    NLOG(cLogHost, RWCMD_C, 2, "WriteZeroFillup bopClrRam u32DesAddr=0x%08X", g32arTsb0[g16WriteBufPtr+uStartSctr][0]>>16,
         g32arTsb0[g16WriteBufPtr+uStartSctr][0]);

    // step 3 : finish read fifo
}    /* WriteZeroFillup */

void PostWriteZeroFlow()
{
    LWORD u32LBA;
    HADDRINFO usTmpHAddrInfo;
    BYTE uWriteSctrCnt, uSCnt;

    initNewFblkProc(0xFE);
    g16WriteBufPtr=getWriteBufPtr(g16WriteBufPtr);
    rstH2F1KInfo();
    remAllHmbLink();

    while(gsWZCnt)
    {
        gsWZCnt--;

        if((gsWZInfo[gsWZCnt].u32LBA==c32BitFF)||(gsWZInfo[gsWZCnt].uSCnt>7))
        {
            gsWZCnt++;
            break;
        }

        u32LBA=gsWZInfo[gsWZCnt].u32LBA;
        uSCnt=gsWZInfo[gsWZCnt].uSCnt;
        NLOG(cLogHost, RWCMD_C, 4, "PostWriteZeroFlow u32LBA=0x%08X, uSCnt=0x%04X, g16WriteBufPtr=0x%04X",
             gsWZInfo[gsWZCnt].u32LBA>>16, gsWZInfo[gsWZCnt].u32LBA,
             gsWZInfo[gsWZCnt].uSCnt, g16WriteBufPtr);
        gsWZInfo[gsWZCnt].u32LBA=c32BitFF;
        gsWZInfo[gsWZCnt].uSCnt=cBitFF;
        NLOG(cLogHost, RWCMD_C, 0, "PostWriteZeroFlow initNewFblkProc");
        // step 3 : invert buffer flag.
        WriteZeroFillup(u32LBA, uSCnt);
        NLOG(cLogHost, RWCMD_C, 0, "PostWriteZeroFlow WriteZeroFillup");
        invPlaneBufFlagCore0(g16WriteBufPtr, cSctrPer4k, cInvBufFlag);
        NLOG(cLogHost, RWCMD_C, 0, "PostWriteZeroFlow invPlaneBufFlagCore0");
        tranLba2HAddr(u32LBA&(~(cSctrPer4k-1)), &usTmpHAddrInfo);
        NLOG(cLogHost,
             RWCMD_C,
             3,
             " cNvmeCmdWriteZero g16HBlock=0x%04X, g16arH2fTabPtr=0x%04X, g16arH2fTabBlk=0x%04X",
             g16HBlock,
             g16arH2fTabPtr[g16HBlock],
             g16arH2fTabBlk[g16HBlock]);

        gStartSector=0;

        if(mChkChgBlock)
        {
            initNewFblkProc(0xFE);
            mClrChgBlock;

            if(gsRwCtrl.u16OccFSkipSize>=c16WriteBufSize)
            {
                chkBufOccupy(c16Null);
            }
        }

        uWriteSctrCnt=cSctrPer4k-gStartSector;

        if(uWriteSctrCnt>cSctrPer4k)
        {
            uWriteSctrCnt=cSctrPer4k;
            mSetCacheInBufW;
        }
        else
        {
            mClrCacheInBufW;
        }

        // step 3 : update write information and assign part read Fifo
        if(!mChkCacheInBuf(gsRwCtrl.uCachePtr))
        {
            gsRwCtrl.u16arCacheHPage[gsRwCtrl.uCachePtr]=g16HPage;
            gsRwCtrl.u16arCacheHBlock[gsRwCtrl.uCachePtr]=g16HBlock;
            gsRwCtrl.uCacheStartSctr=0;
            NLOG(cLogHost,
                 RWCMD_C,
                 3,
                 "PostWriteZeroFlow gsRwCtrl.uCachePtr=0x%04X ,g16HBlock=0x%04X, g16HPage=0x%04X",
                 gsRwCtrl.uCachePtr,
                 g16HBlock,
                 g16HPage);
        }

        gsRwCtrl.uPrdPtr[gsRwCtrl.uCachePtr]=0xF5;
        gsRwCtrl.uCacheEndSctr=uWriteSctrCnt;

        if(mChkCacheInBufW)
        {
            mSetCacheInBuf(gsRwCtrl.uCachePtr);
        }
        else
        {
            gpFlashAddrInfo=&garDesAddrInfo[gsRwCtrl.u32ProgFifoHead];

            if(mChkNewDesF)
            {
                setWriteDes(gsRwCtrl.u16ProgPageOfst, gpFlashAddrInfo, cWriteCache);
                mClrNewDesF;    // gbNewDesF=0;
            }

            garDesF2hInfo[gsRwCtrl.u32ProgFifoHead].u16arHPage[gsRwCtrl.uCachePtr]=g16HPage;    // gsRwCtrl.u16arCacheHPage[gsRwCtrl.uCachePtr];
            garDesF2hInfo[gsRwCtrl.u32ProgFifoHead].u16arHBlock[gsRwCtrl.uCachePtr]=g16HBlock;    // gsRwCtrl.u16arCacheHBlock[gsRwCtrl.uCachePtr];
            rmSetSrchTgt(gsRwCtrl.uMaskTgtPtr, (g16HBlock<<16)|g16HPage);
            gsRwCtrl.uMaskTgtPtr++;
            setProgFifoOpt(0xFE);    // Temp [D.H]

            NLOG(cLogHost, RWCMD_C, 0, "PostWriteZeroFlow setProgFifoOpt");
        }

        gsCacheInfo.u32WriteSctr2ChgBlk-=uWriteSctrCnt;

        if(!gsCacheInfo.u32WriteSctr2ChgBlk)
        {
            mSetChgBlock;
            mSetCalWriteSctr2ChgBlk;
        }

        if(gsRwCtrl.u16OccFSkipSize>=c16WriteBufSize)
        {
            chkBufOccupy(c16Null);
        }

        NLOG(cLogHost, RWCMD_C, 1, "PostWriteZeroFlow chkBufOccupy g16WriteBufPtr=0x%04X", g16WriteBufPtr);
        g16WriteBufPtr=addWriteBufPtr(g16WriteBufPtr, uWriteSctrCnt);
    }

    if(!gsWZCnt)
    {
        termFlashOperW(0);
        NLOG(cLogHost, RWCMD_C, 0, "PostWriteZeroFlow End");
    }
    else
    {
        NLOG(cLogHost, RWCMD_C, 0, "PostWriteZeroFlow Error LBA/Scnt");
    }

    NLOG(cLogHost, RWCMD_C, 3, " cNvmeCmdWriteZero g16HBlock=0x%04X, g16arH2fTabPtr=0x%04X, g16arH2fTabBlk=0x%04X", g16HBlock,
         g16arH2fTabPtr[g16HBlock], g16arH2fTabBlk[g16HBlock]);
    gsWZCnt=cBitFF;
    rstH2F1KInfo();
    remAllHmbLink();
    // g16FlashWBufPtr=addWriteBufPtr(g16FlashWBufPtr, g16WriteBufPtr);
}    /* PostWriteZeroFlow */

#endif/* if _EN_WriteZeroNonAlign */

void servRwCmdQue()
{
#if (_EN_IOMTRIG&&_EN_VPC_SWAP)||(_EN_Lenovo_RecoveryChk)
    LWORD u32IOMeterS;
#endif

#if _EN_CDMTRIG
    LWORD u32CDMTimer;
#endif

#if _EN_Delay_Dis_LTSSM
    IORestFlg=1;
#endif

    if(gsHmbInfo.uHmbStsChg)    // 20190220_Louis
    {
        NLOG(cLogHost, RWCMD_C, 0, " uHmbStsChg! endOfBgdClnCacheblkProc before servRw!");
        endOfBgdClnCacheblkProc();
    }
    else
    {
        gsRwCtrl.uRwBrk=cRwBrkIdle;
        gsRwCtrl.uTimerFlag=0;
        gsRwCtrl.u32LastTrimLba=c32BitFF;

#if _ENABLE_E2E_CMD_RETRY
        gsE2eInfo.u16CommandRetryPrd=c16BitFF;
#endif
        // mPSChgClrThrottlingInRw;
        // startRtcCounting2s();
#if (_ENABLE_DASP_LED)
        mSetDaspLed;
        rmRtc32kIntEnable;
#endif
        NLOG(cLogHost, RWCMD_C, 0, " serRwCmdQue Start ");
#if _EN_CDMTRIG    // 20190618_ChrisSu
        if(gCDMStatus!=cCDM_Triger)
        {
            u32CDMTimer=rmGetRtc1sTick;

            if(u32CDMTimer>(g32CDMTimer+1))    // over 2S
            {
                InitCDM();

                if(gCDMStatus==cCDM_PrePare)
                {
                    NLOG(cLogHost, RWCMD_C, 0, " CDMPrepare Cancel, RW over 2S ");
                }
            }
        }
#endif/* if _EN_CDMTRIG */

#if (_EN_IOMTRIG&&_EN_VPC_SWAP)
        if((gsIomInfo.u8Status==cIoMeterTrig)||(gsIomInfo1Thr.u8Status==cIoMeterTrig))
        {
            u32IOMeterS=getRtcCurrent1s();

            if(gsIomInfo.u8Status==cIoMeterTrig)
            {
                u32IOMeterS=u32IOMeterS-gsIomInfo.u32TrigTimer;
            }
            else
            {
                u32IOMeterS=u32IOMeterS-gsIomInfo1Thr.u32TrigTimer;
            }

            if(u32IOMeterS>12000)    // 200 mins
            {
                InitIoMeter();
                InitIoMeter1Thr();
                NLOG(cLogHost, RWCMD_C, 0, " IOMeterTrig Over 120mins! ");
            }
            else
            {
                NLOG(cLogHost, RWCMD_C, 2, " IOMeter going %08d S", u32IOMeterS>>16, u32IOMeterS);
            }
        }
        else if(gsIomInfo1Thr.u8Status==cIoMeterChk)
        {
            u32IOMeterS=getRtcCurrent1s();

            if(u32IOMeterS>(gsIomInfo1Thr.u32TrigTimer+1))    // over 2S
            {
                InitIoMeter1Thr();
            }
        }
#endif/* if _EN_IOMTRIG */

#if _EN_Lenovo_RecoveryChk
        if(gsIomInfo_RecoveryCheck.u8Status==cRecoverychkTrig)
        {
            u32IOMeterS=getRtcCurrent1s();
            u32IOMeterS=u32IOMeterS-gsIomInfo_RecoveryCheck.u32TrigTimer;

            if(u32IOMeterS>14400)    // 4hr
            {
                InitIoMeter_RecoveryChk();
                NLOG(cLogHost, RWCMD_C, 0, " IOMeterTrig_Recoverychk Over 4hrs! ");
            }
            else
            {
                NLOG(cLogHost, RWCMD_C, 2, " IOMeter_Recoverychk going %08d S", u32IOMeterS>>16, u32IOMeterS);
            }
        }
#endif/* if _EN_Lenovo_RecoveryChk */

        // do
        while(1)
        {
#if _EN_WriteZeroNonAlign    // WriteZeroNonAlign_20181031_Chief
            if(gsWZCnt)
            {
                NLOG(cLogHost, RWCMD_C, 1, "PostWriteZeroFlow Start gsWZCnt=0x%04X", gsWZCnt);
                PostWriteZeroFlow();
                gsRwCtrl.uRwBrk=cRwBrkNoPrdToDo;
                break;
            }
#endif

            if(gChkTemperature)
            {
                if(!mPSChgChkThrottling)
                {
                    chkThrottlingPowerState(0);
                    gChkTemperature=0;
                }
            }

#if _EN_SLCOpenBlkReadScrub
            if(((!mChkOccFlag(cOccFlushCache))&&(!mChkOccFlag(cOccReadReclaim))&&(!mChkOccFlag(cOccMarkBad)))||mChkHandlePcieErrF)
#else
            if(((!mChkOccFlag(cOccReadReclaim))&&(!mChkOccFlag(cOccMarkBad)))||mChkHandlePcieErrF)
#endif
            {
                postRwTaskToPrdInfo();
            }

            if(gsRwCtrl.uRwBrk)
            {
                break;
            }

            while((gsRwCtrl.u32TrigHostTail!=gsRwCtrl.u32TrigHostHead)&&gsPrdInfo.uFreeHwPrdCnt)
            {
                trigHostRw(gsRwCtrl.uarTrigHostPrd[gsRwCtrl.u32TrigHostTail], c32AutoDmaTrigR, cLastPrd|cTsb|cAutoBufflag|cCrcCheckEn);

                gsRwCtrl.u32TrigHostTail=(gsRwCtrl.u32TrigHostTail+1)&(cPrdDepth-1);
            }

            // while((gsRwCtrl.u32TrigHmbTail!=gsRwCtrl.u32TrigHmbHead)&&gsHmbInfo.uHmbFreeHwPrdCnt)
            // {
            //    postHmbReadData();
            // }

            if((gsPrdInfo.usReadPrdList.u16Trig!=cNull)&&(mChkRwTimeOutFlag||mChkWrStarvation))
            {
                if(gLastTrigPrdTaskType==cNvmeCmdWrite)
                {
#if (_FUA_PERF)
                    if(mChkQueueFuaCmd)
                    {
                        termFuaWFlow();
                    }
                    else
                    {
#if _EN_PROGFAILLOG
                        termFlashOperW(1);
#else
                        termFlashOperW(0);    // 1);
#endif
                    }
#else
#if _EN_PROGFAILLOG
                    termFlashOperW(1);
#else
                    termFlashOperW(0);    // 1);
#endif
#endif/* if (_FUA_PERF) */
                }

                if(!mChkHandlePcieErrF)
                {
                    trigHostPrdTaskR();
                    clrRwTimeOutFlag(cNvmeCmdRead);
                }
            }
            else if(gsPrdInfo.usWritePrdList.u16Trig!=cNull)
            {
                if(mChkGcFlag(cStopBgdClean))
                {
                    mClrGcFlag(cStopBgdClean);
                }

                if(gLastTrigPrdTaskType==cNvmeCmdRead)
                {
                    termFlashOperR();
                }

                // if(gsHmbInfo.uHmbCache4kCnt)
                // {
                //    readHmbData(gsHmbInfo.u16HmbCacheBufPtr,
                //                gsHmbInfo.uHmbCache4kCnt<<cSctrTo4kShift,
                //                0,
                //                cReadFifoDpt,
                //                cHmbWrCache,
                //                cHmbTsbPath|cHmbReadDir|cHmbBufflagChk|cHmbBufflagInv);

                //    gsHmbInfo.uHmbCache4kCnt=0;
                // }
                if(!mChkHandlePcieErrF)
                {
                    prog1stInvQBootInWpro();
                    postFlashAddrInfoW();
                    clrRwTimeOutFlag(cNvmeCmdWrite);
                }
            }

            if(gsPrdInfo.uSeqRCmdCnt)
            {
                trigHostSeqRead(0);
            }

            if(gsPrdInfo.uTrigWCmdCnt)
            {
                chkTrigHostWrQue(2);
            }

            if((!gsRwCtrl.u32SeqRdFlag)&&(!mChkHandlePcieErrF))
            {
                if(gsRwCtrl.uSrchQCnt&&!rmChkNbsQueMt)    // !rmChkBopBz)
                {
                    postSrchF2hTab();
                }

                if(gsRwCtrl.uTabPrdCnt)    // &&gsRwCtrl.uFreeHSgmtCnt)
                {
                    postReadH2fSgmtTab();
                }

#if _EN_RAID_DECODE
                if((gsRwCtrl.u32H2fSgmtRdyTail!=gsRwCtrl.u32H2fSgmtRdyHead)&&(!g32DecodeWait))
#else
                if(gsRwCtrl.u32H2fSgmtRdyTail!=gsRwCtrl.u32H2fSgmtRdyHead)
#endif
                {
                    handleH2fSgmtRdy();
                }

                // if(gsHmbInfo.uHmbSgmtRdyCnt)
                // {
                //    handleHmbSgmtRdy();
                // }

                if(gsRwCtrl.uSrcPrdCnt)
                {
                    postFlashAddrInfoR();
                }
            }

            if(!mChkHandlePcieErrF)
            {
                chkOccAtRWService();
            }
        }

        disSysTmr();

        if((!mChkHandlePcieErrF)||(chkUnderRwProc()!=cUnderRWHdlErr))
        {
#if _EN_RWEND_NOGC    // 20190508_ChrisSu_02
            gGCOpt|=gbRWEndGC;
            termFlashOperRw(1);
            gGCOpt&=~gbRWEndGC;
#else
            termFlashOperRw(1);
#endif
        }

        if(mChkHandlePcieErrF)
        {
            tracePcieEvent(cDebugRwDigit|3);

            // don't do it when hit read ahead but pcie error case
            if(chkUnderRwProc()==cUnderRWHdlErr)
            {
                // tracePcieEvent(cDebugRwDigit|4);
                handlePcieError();
            }
        }

#if 0    // 20190722_SamHu_01
        if(gbUpdIdxF)
        {
            saveIndexBlockCore0();
        }
#endif

#if _EN_CDMTRIG
        if((g32CDM_WSctrCnt>cCDM1200M)&&(gCDMStatus!=cCDM_Triger))
        {
            InitCDM();
            NLOG(cLogGC, RWCMD_C, 0, "CDM_non & Init, over 1200M");
        }
        else if(gCDMStatus!=cCDM_Triger)    // 20190618_ChrisSu
        {
            g32CDMTimer=rmGetRtc1sTick;
        }
#endif
#if (_EN_IOMTRIG&&_EN_VPC_SWAP)
        if((gsIomInfo.u8Status==cIoMeterChk)&&((gsIomInfo.u32SeqLen>0x4C00000)&&(gsIomInfo.u32SeqLen<0x5200000)))
        {
            NLOG(cLogGC, RWCMD_C, 0, "Iometer On!!!!");
            NLOG(cLogGC,
                 RWCMD_C,
                 4,
                 " RanCmd= 0x%08X,SeqCmd= 0x%08X ",
                 gsIomInfo.u32RanCmdCnt>>16,
                 gsIomInfo.u32RanCmdCnt,
                 gsIomInfo.u32SeqCmdCnt>>16,
                 gsIomInfo.u32SeqCmdCnt);
            NLOG(cLogGC, RWCMD_C, 2, " Seqlen=0x%08X ", gsIomInfo.u32SeqLen>>16, gsIomInfo.u32SeqLen);

            gsIomInfo.u32TrigTimer=getRtcCurrent1s();
            gsIomInfo.u8Status=cIoMeterTrig;
        }

        if((gsIomInfo1Thr.u8Status==cIoMeterChk)&&((gsIomInfo1Thr.u32SeqLen>0x4C00000)&&(gsIomInfo1Thr.u32SeqLen<0x5200000)))
        {
            NLOG(cLogGC, RWCMD_C, 0, "Iometer1Thr On!!!!");
            NLOG(cLogGC,
                 RWCMD_C,
                 4,
                 " RanCmd= 0x%08X,SeqCmd= 0x%08X ",
                 gsIomInfo1Thr.u32RanCmdCnt>>16,
                 gsIomInfo1Thr.u32RanCmdCnt,
                 gsIomInfo1Thr.u32SeqCmdCnt>>16,
                 gsIomInfo1Thr.u32SeqCmdCnt);
            NLOG(cLogGC, RWCMD_C, 2, " Seqlen=0x%08X ", gsIomInfo1Thr.u32SeqLen>>16, gsIomInfo1Thr.u32SeqLen);

            gsIomInfo1Thr.u32TrigTimer=getRtcCurrent1s();
            gsIomInfo1Thr.u8Status=cIoMeterTrig;
        }
        else if(gsIomInfo1Thr.u8Status==cIoMeterChk)
        {
            gsIomInfo1Thr.u32TrigTimer=getRtcCurrent1s();
        }
#endif/* if _EN_IOMTRIG */

#if _EN_Lenovo_RecoveryChk
        LWORD u32TrigLowerBound, u32TrigUpperBound;

        if(g32HostTotalDataSectorCnt<=0xEE7C2B0)    // 128GB
        {
            u32TrigLowerBound=0x4200000;
            u32TrigUpperBound=0x4800000;
        }
        else    // 256GB
        {
            u32TrigLowerBound=0x8600000;
            u32TrigUpperBound=0x8C00000;
        }

        if((gsIomInfo_RecoveryCheck.u8Status==cIoMeterChk)&&
           ((gsIomInfo_RecoveryCheck.u32SeqLen>u32TrigLowerBound)&&(gsIomInfo_RecoveryCheck.u32SeqLen<u32TrigUpperBound)))
        {
            NLOG(cLogGC, RWCMD_C, 0, "Iometer RecoveryCheck On!!!!");
            NLOG(cLogGC,
                 RWCMD_C,
                 4,
                 " RanCmd_RecoveryCheck= 0x%08X,SeqCmd_RecoveryCheck= 0x%08X ",
                 gsIomInfo_RecoveryCheck.u32RanCmdCnt>>16,
                 gsIomInfo_RecoveryCheck.u32RanCmdCnt,
                 gsIomInfo_RecoveryCheck.u32SeqCmdCnt>>16,
                 gsIomInfo_RecoveryCheck.u32SeqCmdCnt);
            NLOG(cLogGC, RWCMD_C, 2, " Seqlen_RecoveryCheck=0x%08X ", gsIomInfo_RecoveryCheck.u32SeqLen>>16, gsIomInfo_RecoveryCheck.u32SeqLen);

            gsIomInfo_RecoveryCheck.u32TrigTimer=getRtcCurrent1s();
            gsIomInfo_RecoveryCheck.u8Status=cRecoverychkTrig;
        }
#endif/* if _EN_Lenovo_RecoveryChk */

#if (_ENABLE_DASP_LED)
        rmRtc32kIntDisable;
        mClrDaspLed;
#endif
        NLOG(cLogHost,
             RWCMD_C,
             4,
             "gsCacheInfo.u16ActiveCacheBlock=0x%04x , gsCacheInfo.u32CacheFreePagePtr =0x%08x, g16SlcSortQCnt=0x%04x",
             gsCacheInfo.u16ActiveCacheBlock,
             gsCacheInfo.u32CacheFreePagePtr>>16,
             gsCacheInfo.u32CacheFreePagePtr,
             g16SlcSortQCnt);
        NLOG(cLogHost, RWCMD_C, 1, " serRwCmdQue End, CurPs=%04d", gsPowerState.uDevCurPs);
    }    /* servRwCmdQue */

#if _EN_Delay_Dis_LTSSM
    IORestFlg=0;
#endif    // #if _EN_Delay_Dis_LTSSM
}    /* servRwCmdQue */

#if _EN_CDMTRIG
void InitCDM()
{
    gCDMStatus=cCDM_Non;
    g32CDM_WSctrCnt=0;
    g32CDM_RSctrCnt=0;
    g32CDM_SWCnt=0;
    g32CDM_SRCnt=0;
    g32CDM_WBrkCnt=0;
    g32CDM_RBrkCnt=0;
    g32CDMTimer=0;
}

#endif
void clrRwTimeOutFlag(BYTE uCurPrdTaskType)
{
    if(mChkRwTmrCtrl(cBrkRdoWTmr)&&(gLastTrigPrdTaskType!=uCurPrdTaskType))
    {
        mClrRwTmrCtrl(cBrkRdoWTmr|cEnSysTmr);
        disSysTmr();
    }

    gLastTrigPrdTaskType=uCurPrdTaskType;
}

void postRwTaskToPrdInfo()
{
    PRDQUEUE *upPrdInfo;
    volatile LINKINFO *upInsLlInfo;
    CMDSTRUCT *upIOCmd;
    LWORD u32Dword0, u32Dword2, u32Dword10, u32Dword11, u32Dword12;
    WORD u16SqId, u16PrevNodeIdx, u16NextNodeIdx, u16NowNodeIdx;
    BYTE uOpCode, uTotalPrdTaskCnt;

#if _GREYBOX
    CMDSTRUCT *upGbIOCmd;
#endif

    chkReleaseFreeHwPrd();

    chkHmbPrdDone();

    if(mChkDummyWrite)
    {
        rstH2F1KInfo();
        remAllHmbLink();    // rstHmbTable();
    }

    uTotalPrdTaskCnt=gsPrdInfo.uTotalPrdTaskCnt;

    if(mChkHandlePcieErrF)
    {
        tracePcieEvent(cDebugRwDigit|0);
        gsRwCtrl.uRwBrk=cRwBrkPcieErr;
#if _EN_PCIE_PATH_REC
        mRecPcieErrPath(cErrPostRwTaskToPrdInfo);
#endif
        return;
    }

#if _EN_Liteon_ErrHandle
    else if(rmChkCmdRdy&&!mPSChgChkThrottling&&!gJdgBootGCFlag)    // 20180328_Louis
#else
    else if(rmChkCmdRdy&&!mPSChgChkThrottling)
#endif
    {
        if(mChkRwTmrCtrl(cBrkRwTmr))
        {
            mClrRwTmrCtrl(cBrkRwTmr|cEnSysTmr);
            disSysTmr();
        }

        if(uTotalPrdTaskCnt<cPrdDepth)
        {
            u32Dword0=r32Nvme1[rcFwRqCmd0/4];
            u32Dword2=r32Nvme1[rcFwRqCmd2/4];
            u16SqId=(WORD)(u32Dword2>>16);    // rmNvmeSqId;
            uOpCode=(BYTE)u32Dword0;    // rmNvmeOpCode;
        }
        else
        {
            return;
        }
    }
    else
    {
        if(!uTotalPrdTaskCnt)
        {
#if _EN_Liteon_ErrHandle
            if((gCpu0TOFlag&&mChkRwTmrCtrl(cBrkRwTmr))||mPSChgChkThrottling||gJdgBootGCFlag)
#else
            if((gCpu0TOFlag&&mChkRwTmrCtrl(cBrkRwTmr))||mPSChgChkThrottling)
#endif
            {
#if _EN_Liteon_ErrHandle
                if(gJdgBootGCFlag)
                {
                    NLOG(cLogHost, RWCMD_C, 1, " gJdgBootGCFlag set!! Flag=0x%04x", gJdgBootGCFlag);    // 20180328_Louis
                }
#endif
                tracePcieEvent(cDebugRwDigit|1);
                gsRwCtrl.uRwBrk=cRwBrkTimeout;
            }
            else
            {
                mSetRwTmrCtrl(cBrkRwTmr|cEnSysTmr);
                enSysTmr(cRwIdleTmrVal);
            }
        }

        return;
    }

    while(u16SqId&&((uOpCode==cNvmeCmdRead)||(uOpCode==cNvmeCmdWrite)))
    {
        u32Dword10=r32Nvme1[rcFwRqCmd10/4];
        u32Dword11=r32Nvme1[rcFwRqCmd11/4];
        u32Dword12=r32Nvme1[rcFwRqCmd12/4];

        upIOCmd=&garCmdHistory[g32CmdHistoryPtr];
        g32CmdHistoryPtr++;

        if(g32CmdHistoryPtr>=cCmdHistorySize)
        {
            g32CmdHistoryPtr=0;
        }

        upIOCmd->u32Dword0=u32Dword0|c32Bit10;
        upIOCmd->u32Dword10=u32Dword10;
        upIOCmd->u32Dword11=u32Dword11;
        upIOCmd->u32Dword12=u32Dword12;
        upIOCmd->u32TimeStamp=getRtcCurrent32k();

#if _GREYBOX
        upGbIOCmd=&garGbCmdHistory[g32GbCmdHistoryPtr];
        g32GbCmdHistoryPtr++;

        if(g32GbCmdHistoryPtr>=(cCmdHistorySize*cCmdHistorySize))
        {
            g32GbCmdHistoryPtr=0;
        }

        upGbIOCmd->u32Dword0=u32Dword0|c32Bit10;
        upGbIOCmd->u32Dword10=u32Dword10;
        upGbIOCmd->u32Dword11=u32Dword11;
        upGbIOCmd->u32Dword12=u32Dword12;
        upGbIOCmd->u32TimeStamp=rmGetRtc32kTick;
#endif

        u16NowNodeIdx=gsPrdInfo.uarFreePrdQue[gsPrdInfo.uFreePrdHead];    // gsPrdInfo.usFreePrdList.u16Tail;
        upPrdInfo=&gsPrdInfo.uarPrdQue[u16NowNodeIdx];

        upPrdInfo->u32PrdProcTime=getRtcCurrent32k();

        upPrdInfo->u32LbaAddr=u32Dword10;
        upPrdInfo->u32SctrCnt=(u32Dword12&0x0000FFFF)+1;
        upPrdInfo->u32NsId=rmNvmeNsId;

#if _EN_EarlyBdGC    // 20190620_ChrisSu
        g32EarIOcnt+=upPrdInfo->u32SctrCnt;
#endif

        if(chkCmdInfoError(upPrdInfo->u32SctrCnt, u32Dword10, upPrdInfo->u32NsId))
        {}
        else
        {
            upPrdInfo->u32Prp1H=rmNvmePrp1High;
            upPrdInfo->u32Prp1L=rmNvmePrp1Low;
            upPrdInfo->u32Prp2H=rmNvmePrp2High;
            upPrdInfo->u32Prp2L=rmNvmePrp2Low;
            upPrdInfo->u32LbaAddr+=gsNamespace.usInfo[upPrdInfo->u32NsId-1].u32StartLba;
#if _EN_MAGICCODE
            rmPopNextCmd;
#endif
            upPrdInfo->uOpCode=uOpCode;

#if _GREYBOX
            if((u32Dword12&c32Bit30)&&(uOpCode==cNvmeCmdWrite))
#else
            if(((u32Dword12&c32Bit30)||(!mChkCacheEnable))&&(uOpCode==cNvmeCmdWrite))
#endif
            {
                upPrdInfo->uFua=cHdlNvmeFlush;    // 20190417_ChrisSu
                upPrdInfo->uFuaDone=0;
            }
            else
            {
                upPrdInfo->uFua=0;
                upPrdInfo->uFuaDone=0;
            }

            // upPrdInfo->uFua=(u32Dword12&c32Bit30);    // rmNvmeFua; ?????????????????????
            upPrdInfo->u16Cid=(WORD)(u32Dword0>>16);    // rmNvmeCid;
            upPrdInfo->u16CqId=(WORD)(u32Dword2);    // rmNvmeCqId;
            upPrdInfo->u16SqId=u16SqId;
            upPrdInfo->uSgl=(BYTE)((u32Dword0&0x0000C000)>>8);    // rmNvmeSgl;
            upPrdInfo->ubQRdCmd=0;
            upPrdInfo->ubSetOccF=0;
            upPrdInfo->uHwPrdIdx=cNull;
            upPrdInfo->uUncFlag=0;
            upPrdInfo->uE2eRetry=0;

#if _ENABLE_SECAPI
            upPrdInfo->uSecFlag=0;

            if(gbEnTCG)
            {
                if(gMBRShadow&&gMbrRangeHit)
                {
                    // if host data region is not aligned to 4K, there will be several unused sectors added to make it aligned
                    upPrdInfo->u32LbaAddr+=g32HostTotalDataSectorCnt+gTcgReservedSecShiftCnt;
                    gMbrRangeHit=0;
                    // gMbrRedirectPassAes=1;
                    upPrdInfo->uSecFlag|=cMbrRedirectPassAes;
                }
                else if(gMBRShadow&&gMbrReturnZero)
                {
                    gMbrReturnZero=0;
                    // gMbrDummyReturn=1;
                    // gMbrRedirectPassAes=1;
                    upPrdInfo->uSecFlag|=(cMbrRedirectPassAes|cMbrDummyReturn);
                }
            }
#endif/* if _ENABLE_SECAPI */

            if(uOpCode==cNvmeCmdRead)
            {
#if (_EN_IOMTRIG&&_EN_VPC_SWAP)
                gsIomInfo1Thr.u32ReadCmdCnt++;
#endif
                upInsLlInfo=&gsPrdInfo.usReadPrdList;
            }
            else
            {
                upInsLlInfo=&gsPrdInfo.usWritePrdList;
#if _EN_SKIPGC10MIN                                   // 20190806_ChrisSu
                g32BgdGCSkip10min+=upPrdInfo->u32SctrCnt;
#endif
            }

            mInsNode(u16PrevNodeIdx, upInsLlInfo, u16NextNodeIdx, gsPrdInfo.uarPrdLink, u16NowNodeIdx);
            uTotalPrdTaskCnt++;
            gsPrdInfo.uFreePrdHead=(gsPrdInfo.uFreePrdHead+1)&(cPrdDepth-1);

            gFWShnFlag=0;

#if _EN_IDLEGC_DELAY
            if(g32BgdGCSkipResetCnt>upPrdInfo->u32SctrCnt)
            {
                g32BgdGCSkipResetCnt-=upPrdInfo->u32SctrCnt;
            }
            else if(g32IdleGcDelayTime!=0)
            {
                gBgdGCWakeUp=0;
                g32BgdGCSkipResetCnt=0;
                g32IdleGcDelayTime=0;
            }
#endif
#if !_EN_MAGICCODE
            rmPopNextCmd;
#endif
        }

        if(rmChkCmdRdy)
        {
            if(uTotalPrdTaskCnt<cPrdDepth)
            {
                u32Dword0=r32Nvme1[rcFwRqCmd0/4];
                u32Dword2=r32Nvme1[rcFwRqCmd2/4];
                u16SqId=(WORD)(u32Dword2>>16);    // rmNvmeSqId;
                uOpCode=(BYTE)u32Dword0;    // rmNvmeOpCode;
            }
            else
            {
                break;
            }
        }
        else
        {
            break;
        }
    }

    gsPrdInfo.uTotalPrdTaskCnt=uTotalPrdTaskCnt;

    if(!uTotalPrdTaskCnt)
    {
        tracePcieEvent(0xE2);
        gsRwCtrl.uRwBrk=cRwBrkNoPrdToDo;
    }
    else
    {
        if((gsPrdInfo.usReadPrdList.u16Trig!=cNull)&&(gsPrdInfo.usWritePrdList.u16Trig!=cNull))
        {
            if(!mChkRwTmrCtrl(cEnSysTmr))
            {
                mSetRwTmrCtrl(cBrkRdoWTmr|cEnSysTmr);
                enSysTmr(cRwPreventTO);
            }
        }
    }
}    /* postRwTaskToPrdInfo */

void termFlashOperRw(BYTE uWaitAllRwCmdCompletion)
{
    // if(gLastTrigPrdTaskType==cNvmeCmdRead)
    // {
    termFlashOperR();
    // }
    // else if(gLastTrigPrdTaskType==cNvmeCmdWrite)
    // {
#if (_FUA_PERF)
    if(mChkQueueFuaCmd)
    {
        termFuaWFlow();
    }
    else
    {
#if _EN_PROGFAILLOG
        termFlashOperW(1);
#else
        termFlashOperW(0);    // 1);
#endif
    }
#else
#if _EN_PROGFAILLOG
    termFlashOperW(1);
#else
    termFlashOperW(0);    // 1);
#endif
#endif/* if (_FUA_PERF) */
    // }

    if(uWaitAllRwCmdCompletion)
    {
        while((gsPrdInfo.uTotalPrdTaskCnt||(gsPrdInfo.uFreeHwPrdTail!=gsPrdInfo.uFreeHwPrdHead))&&!mChkHandlePcieErrF)
        {
            chkReleaseFreeHwPrd();
        }
    }

    gLastTrigPrdTaskType=0;
    /*
       * gWriteHMBIndex=0;
       *
       * for(BYTE uIdx=0; uIdx<cHmbRacingFreeCnt; uIdx++)
       * {
       *  g16WriteHMBH2FTable[uIdx]=c16Null;
       * }
       */
}    /* termFlashOperRw */

void trigHostRw(WORD u16PrdInfoIdx, LWORD u32TrigMo, LWORD u32PrdOpt)
{
    PRDQUEUE *upPrdInfo;
    BYTE uHwPrdIdx;

    upPrdInfo=&gsPrdInfo.uarPrdQue[u16PrdInfoIdx];

#if (_GREYBOX)
    if(gsGbInfo.uGreyBoxItem==cErrHdlE2EHostData)
    {
        if((u32TrigMo==c32AutoDmaTrigR)&&(upPrdInfo->ubQRdCmd==1))    // timming : trigger host read and random read
        {
            if(((gsGbInfo.uGreyBoxOpt==cVOpE2EReadErrOnce)&&(gsGbInfo.uStag!=cVsTriggered))||(gsGbInfo.uGreyBoxOpt==cVOpE2EReadErrConti))
            {
                sysDelay(0xa000);
                (*(WORD *)(c32TsbCrcAddr+((upPrdInfo->u16BufPtr)*8)))=c16BitFF;
                outSta(cVTrig);
                gsGbInfo.u32BkValue=upPrdInfo->u32LbaAddr;
                gsGbInfo.uStag=cVsTriggered;
            }
        }
    }
#endif

    // if(!gsPrdInfo.uFreeHwPrdCnt)
    // {
    //    uHwPrdIdx=getFreeHwPrd();
    // }
    // else
    // {
    uHwPrdIdx=gsPrdInfo.uarFreeHwPrdQue[gsPrdInfo.uFreeHwPrdTail];
    gsPrdInfo.uFreeHwPrdTail=(gsPrdInfo.uFreeHwPrdTail+1)&(cHwPrdDepth-1);
    gsPrdInfo.uFreeHwPrdCnt--;

    // }

#if _ENABLE_SECAPI
    if(upPrdInfo->uSecFlag&cMbrRedirectPassAes)
    {
        u32PrdOpt&=~cCrcCheckEn;
    }
    else if(gbEnAes)
    {
        rmAesMode;
        u32PrdOpt|=cAes;
    }
#endif

    if(cCrcCheckEn&&gsWUNCInfo.uWZeroFlag)    // Oscar_20190311
    {
        u32PrdOpt&=~cCrcCheckEn;
    }

    // setHwPrdRw(upPrdInfo);
    // Set Buffer location
    // Set Occupy flag
    if(upPrdInfo->ubSetOccF)    // Enable Occupy flg & Set occupy Address inside
    {
        r32NvmePrd[uHwPrdIdx][0]=u32PrdOpt|cSetTsbOccFlag;
        r32NvmePrd[uHwPrdIdx][3]=(upPrdInfo->u16BufPtr&~(cSctrPer4k-1));

        setFwPreOccuFlag(upPrdInfo->u16BufPtr);
    }
    else
    {
        r32NvmePrd[uHwPrdIdx][0]=u32PrdOpt;
        r32NvmePrd[uHwPrdIdx][3]=0;
    }

    if(mChkDummyWrite&&(upPrdInfo->uOpCode==cNvmeCmdWrite))
    {
        r32NvmePrd[uHwPrdIdx][0]&=~(cAutoBufflag|cAutoRaidFlag|cSetTsbOccFlag);
    }

    r32NvmePrd[uHwPrdIdx][1]=upPrdInfo->u16BufPtr;    // TSB Address
    // r32NvmePrd[uHwPrdIdx][2]=0;//default 0

    // Set Transfer count
    if(u32PrdOpt&cLastPrd)
    {
        r32NvmePrd[uHwPrdIdx][5]=upPrdInfo->u32SctrCnt;    // Transfer Count, sector based unit
    }
    else
    {
        r32NvmePrd[uHwPrdIdx][5]=upPrdInfo->u32RestScrtCnt;
    }

    // LBA only for AES used
    r32NvmePrd[uHwPrdIdx][6]=upPrdInfo->u32LbaAddr;    // LBA Low DW
    // r32NvmePrd[uHwPrdIdx][7]=0;    // LBA High DW, set to 0 for now, assume capacity will not be so high
    // setHwDescRw(upPrdInfo, cAutoCq);
    // Set Desc
    r32NvmeDesc[uHwPrdIdx][2]=upPrdInfo->u32Prp1L;
    r32NvmeDesc[uHwPrdIdx][3]=upPrdInfo->u32Prp1H;
    // r32NvmeDesc[uHwPrdIdx][4]=upPrdInfo->u32Prp2L;
    // r32NvmeDesc[uHwPrdIdx][5]=upPrdInfo->u32Prp2H;
    r32NvmeDesc[uHwPrdIdx][6]=(upPrdInfo->u32SctrCnt<<7);    // (upPrdInfo->u32SctrCnt * 128); //DMA transfer size: DWord mode
    r32NvmeDesc[uHwPrdIdx][7]=((upPrdInfo->u16SqId<<16)|upPrdInfo->u16Cid);

#if _ENABLE_SGLS
    if(upPrdInfo->uSgl)
    {
        r32NvmeDesc[uHwPrdIdx][1]=(c32Bit25|c32Bit24);    // SGL pointer, SGL
    }
    else
#endif
    {
        // Judge whther PRP2 is valid, set the valid bit
        if(upPrdInfo->u32Prp2L||upPrdInfo->u32Prp2H)
        {
            r32NvmeDesc[uHwPrdIdx][4]=upPrdInfo->u32Prp2L;
            r32NvmeDesc[uHwPrdIdx][5]=upPrdInfo->u32Prp2H;
            r32NvmeDesc[uHwPrdIdx][1]=c32Bit25;
        }
        else
        {
            r32NvmeDesc[uHwPrdIdx][1]=0x00000000;
        }
    }

    if(upPrdInfo->uUncFlag==cUncBeforeTrig)
    {
        // rmNvmeSetUncFlag(upPrdInfo->uHwPrdIdx);
        r32NvmeDesc[uHwPrdIdx][0]=c32ManualDmaTrigR;
    }
    else if(upPrdInfo->uFua&cHdlNvmeFlush)    // 20190417_ChrisSu
    {
        r32NvmeDesc[uHwPrdIdx][0]=c32ManualDmaTrigW;
    }
    else
    {
        r32NvmeDesc[uHwPrdIdx][0]=u32TrigMo;
    }

    gsDebugInfo.u32LastHwPrdValidTime=getRtcCurrent32k();

    gsPrdInfo.u16arIdxToPrdInfo[uHwPrdIdx]=u16PrdInfoIdx;
    upPrdInfo->uHwPrdIdx=uHwPrdIdx;
}    /* trigHostRw */

void chkBgdClnBlkProc()
{
    if(mChkDummyWrite)
    {
        return;
    }

    if(mChkFidReset)
    {
        // pushSysSprBlk(gsDMInfo.uSysRsvDlMicCodeBlk);
        fillCcmVal((BYTE *)&gsFwDlInfo, sizeof(gsFwDlInfo), 0x00);
        gsFwDlInfo.uSysRsvFwDlImageBlk=0xFF;
        mClrCacheInfoSpf(cFwCommit);
        progCacheInfoTab();
    }

    mSetGcFlag(cUnderBgdGc);    // 20190508_ChrisSu_01

/*  mark temp
   *  if(!mChkGcFlag(cPwOnGcF))
   *  {
   *      gsGcInfo.u32BgdGcEndTime=rmGetRtc1sTick+gsGcInfo.uBgdGcTimeLimit;
   *  }
   */
    while(!mChkGcFlag(cStopBgdClean)&&!hostRequset())
    {
        if(!hostRequset())
        {
            if((gsCacheInfo.uH2fTabBlockCnt>=gsGcInfo.uGcH2fTabbHiThr)||mChkGcFlag(cReadScrubH2F))
            {
// #if (_ENABLE_DASP_LED)  //Disable GC LED;20181115_Eason_01
//                mSetDaspLed;
//                rmRtc32kIntEnable;
// #endif
                mPushGcQue(cGcTypH2fTab);
                bgdClnH2fTabblkProc();
// #if (_ENABLE_DASP_LED)
//                rmRtc32kIntDisable;
//                mClrDaspLed;
// #endif
            }
        }

        if(!hostRequset())
        {
            if(chkBgdClnCacheBlk()==cTrue)
            {
                if(gsFtlDbg.u64BgdClnProcCnt!=c64BitFF)
                {
                    gsFtlDbg.u64BgdClnProcCnt++;
                }

// #if (_ENABLE_DASP_LED)
//                mSetDaspLed;
//                rmRtc32kIntEnable;
// #endif
                saveRdTimeStamp(16);
                waitHmbPrdDone();
                setGcFlowAndBlkCnt();
                bgdClnCacheblkProc(cMainFunc);

                if(mChkHandlePcieErrF)
                {
                    tracePcieEvent(cDebugRwDigit|8);

                    // don't do it when hit read ahead but pcie error case
                    if(chkUnderRwProc()==cUnderRWHdlErr)
                    {
                        handlePcieError();
                    }
                }

#if (_ENABLE_DASP_LED)
                rmRtc32kIntDisable;
                mClrDaspLed;
#endif
            }
        }

        if(!gsCacheInfo.u16FullCacheBlockCnt)
        {
#if _EN_BgdT2tClnCdm    // ChrisSu_20190329  sync SMI S0322B
            if(gsCacheInfo.u16SpareBlockCnt<cDirtyCdmRsvSprThr)
            {
                if(((gsGcInfo.u32TotalTlcVpc+g32VpcPerTlcBlk)/g32VpcPerTlcBlk)>(gsCacheInfo.u16TLCFullCacheBlockCnt/10*9))
                {
#if _EN_FW_DEBUG_UART
                    NLOG(cLogFTL,
                         RWCMD_C,
                         2,
                         "StopBgdClean, IdealTlcBlkCnt =0x%04X, TLCFullCacheBlockCnt=0x%04X",
                         (gsGcInfo.u32TotalTlcVpc+g32VpcPerTlcBlk)/g32VpcPerTlcBlk,
                         gsCacheInfo.u16TLCFullCacheBlockCnt);
#endif
                    mSetGcFlag(cStopBgdClean);
                }
            }
            else
#endif/* if _EN_BgdT2tClnCdm */
            {
#if (_EN_FW_DEBUG_UART&&_EN_BgdT2tClnCdm)
                NLOG(cLogFTL,
                     RWCMD_C,
                     1,
                     "StopBgdClean, Meet CdmblkThr TotalSpareBlockCnt=0x%04X",
                     gsCacheInfo.u16SpareBlockCnt);
#endif
                mSetGcFlag(cStopBgdClean);
            }
        }

        if((gsCacheInfo.uH2fTabBlockCnt>=gsGcInfo.uGcH2fTabbHiThr)||(chkBgdClnCacheBlk()    /*&&gsHmbInfo.uHmbEnGcCache*/))
        {
            if(mChkGcFlag(cPwOnGcF))
            {
                if((rmGetRtc1sTick>=gsGcInfo.uPwrOnGcTimeLimit)||mPSChgChkThrottling)
                {
                    mSetGcFlag(cStopBgdClean);
                }
            }
            else if(mChkGcFlag(cPwOnExtraGcF))
            {
                if(mChkGcFlag(cGcForceClean))
                {
#if Power_slcQoverflow
#if _EN_VPC_SWAP
                    if((gsCacheInfo.u16SpareBlockCnt>(cMinGCSprCnt/4))&&(gsCacheInfo.u16DynamicSpareCnt>4)&&(g16SlcSortQCnt<g16MaxSlcBlkQ*2/3))
#else
                    if((gsCacheInfo.u16SpareBlockCnt>(cMinGCSprCnt/4))&&(gsCacheInfo.u16DynamicSpareCnt>4)&&(g16SlcSortQCnt<125))
#endif
#else
                    if((gsCacheInfo.u16SpareBlockCnt>(cMinGCSprCnt/4))&&(gsCacheInfo.u16DynamicSpareCnt>4))
#endif
                    {
                        mSetGcFlag(cStopBgdClean);
                        mClrGcFlag(cGcForceClean);
                    }
                    else
                    {
                        gsGcInfo.u32PwrOnGcStartTime=getRtcCurrent1s();
                    }
                }
                else if(((getRtcCurrent1s()-gsGcInfo.u32PwrOnGcStartTime)>=gsGcInfo.u32PwrOnExtraGcTimeLimit)||mPSChgChkThrottling)
                {
                    mSetGcFlag(cStopBgdClean);
                }
            }
        }
        else
        {
            mSetGcFlag(cStopBgdClean);
        }

        if(mChkBadInfoFlag(cBadInfoChg))
        {
            waitHmbPrdDone();
            markBadBlockCore0();
        }

/*
   *      if(!mChkGcFlag(cStopBgdClean))
   *      {
   *          mSetGcFlag(cStopBgdClean);
   *      }
   *      else if(mChkGcFlag(cPwOnGcF))
   *      {
   *          if(rmGetRtc1sTick<gsGcInfo.uPwrOnGcTimeLimit)
   *          {
   *              mClrGcFlag(cStopBgdClean);
   *          }
   *      }
   */
        // saveRdTimeStamp(17);
/*
   *      if((gsBadInfo.uEraseFailQueCnt!=0)||(gsBadInfo.uRdEccFailQueCnt!=0))    // chkMarkBadQue(cWriteFunc)==cTrue)
   *      {
   * #if !_ICE_DEBUG
   *          markBadBlock();
   * #endif
   *      }
   */
    }

    // while(gsCacheInfo.uH2fTabBlockCnt>=gsGcInfo.uGcH2fTabbHiThr)
    //    ;

    mClrGcFlag(cUnderBgdGc);    // 20190508_ChrisSu_01

    while(gsRwCtrl.usSrcCmdList.u16Cnt)
        ;

/*
   *  if(mChkGcFlag(cPwOnGcF))
   *  {
   *      if(rmGetRtc1sTick>g32ForceCleanCnt)
   *      {
   *          g32ForceCleanCnt=rmGetRtc1sTick;
   *      }
   *
   *      if((gsCacheInfo.u16SpareBlockCnt<=gsGcInfo.u16GcCachebActThr)||(gsCacheInfo.uH2fTabBlockCnt>=gsGcInfo.uGcH2fTabbHiThr))
   *      {
   *          gsGcInfo.u32GcLeastBudget=c32PartialCleanRtc32s;
   *      }
   *  }
   *  else
   */

    if((gsCacheInfo.u16SpareBlockCnt>gsGcInfo.u16GcCachebActThr)&&(gsCacheInfo.uH2fTabBlockCnt<gsGcInfo.uGcH2fTabbHiThr))
    {
        gsGcInfo.u32GcLeastBudget=c32PartialCleanRtc20ms;    // c32PartialCleanRtc10ms;
    }
}    /* chkBgdClnBlkProc */

// fill u16SBufIdx~ (u16EBufIdx-1)
void ctrlRangeRaidFlag(WORD u16SBufIdx, WORD u16EBufIdx, BYTE uType)
{
    LWORD u32BufInvBit=0;

    do
    {
        mSetBitMask(u32BufInvBit, u16SBufIdx&0x1F);

        if(((u16SBufIdx&0x1F)==0x1F)||(((u16SBufIdx+1)%c16WriteBufSize)==u16EBufIdx))
        {
#if _ENABLE_RAID
            if(uType==cRaiseBufFlag)
            {
                u32BufInvBit=(~((LWORD)rm32BufRaidStatus(u16SBufIdx>>5)))&u32BufInvBit;    // for termOperW Bop fill Data with Raid Flag
                // NLOG_PCIeErr(cLogPcieErr,
                //       RWCMD_C,
                //       3,
                //       "PCIe Wr: Fill RaidFlag BufPtr=0x%04X, Bit=0x%08X.",u16SBufIdx>>5,u32BufInvBit>>16,u32BufInvBit);
            }
            else
            {
                u32BufInvBit=(((LWORD)rm32BufRaidStatus(u16SBufIdx>>5)))&u32BufInvBit;    // for termOperW Bop fill Data with Raid Flag
                // NLOG_PCIeErr(cLogPcieErr,
                //       RWCMD_C,
                //       3,
                //       "PCIe Wr: Lower RaidFlag BufPtr=0x%04X, Bit=0x%08X.",u16SBufIdx>>5,u32BufInvBit>>16,u32BufInvBit);
            }

            rmSetBufRaid32Sts(u16SBufIdx>>5, u32BufInvBit);
#else/* if _ENABLE_RAID */
            u32BufInvBit=(~((LWORD)rm32BufStatus(u16SBufIdx>>5)))&u32BufInvBit;    // for termOperW Bop fill Data with Raid Flag
            rmSetBuf32Sts(u16SBufIdx>>5, u32BufInvBit);
#endif/* if _ENABLE_RAID */
            u32BufInvBit=0;
        }

        u16SBufIdx=(u16SBufIdx+1)%c16WriteBufSize;
    }
    while(u16SBufIdx!=u16EBufIdx);
}    /* ctrlRangeRaidFlag */

BYTE fillLastProgDes()
{
    BYTE uTempSprStr, u4kCntPtr, uE2eCmprErr, uE2eErrCnt;
    WORD u16StrBufPtr, u16InsideSctrCnt;
    WORD u16SBufIdx, u16EBufIdx;
    LWORD u32CurProgTail;
    LWORD u32LbaAddr;
    ADDRINFO *upTmpAddrInfo;

    u32CurProgTail=gsRwCtrl.u32ProgFifoTail;
    upTmpAddrInfo=&garDesAddrInfo[u32CurProgTail];
    setFLActCh(upTmpAddrInfo->uCh);
    u16StrBufPtr=rmGetFshTsbAddr;

    u16InsideSctrCnt=((c16WriteBufSize+u16StrBufPtr-upTmpAddrInfo->u16BufPtr)%c16WriteBufSize);
#if 0
    if(gsRwCtrl.u32ProgFifoTail!=gsRwCtrl.u32ProgFifoHead)
    {
        NLOG_PCIeErr(cLogPcieErr,
                     RWCMD_C,
                     2,
                     "PCIe Wr: Fill Tail BufPtr=0x%04X, FshPtr=0x%04X.", upTmpAddrInfo->u16BufPtr, u16StrBufPtr);
    }
#endif

#if _EN_FW_DEBUG_UART
    NLOG_PCIeErr(cLogPcieErr, RWCMD_C, 2,
                 " PCIe Wr: Fill Program Des=0x%04X, Sectors=0x%04X.", (WORD)u32CurProgTail, u16InsideSctrCnt);
#endif

    // if((gsRwCtrl.u32ProgFifoTail!=gsRwCtrl.u32ProgFifoHead)&&(upTmpAddrInfo->u16BufPtr!=u16StrBufPtr)&&
    //    (u16InsideSctrCnt<=upTmpAddrInfo->uRwHalfKb))
    // for Jira-155
    if((gsRwCtrl.u32ProgFifoTail!=gsRwCtrl.u32ProgFifoHead)
       &&((upTmpAddrInfo->u16BufPtr!=u16StrBufPtr)||((u16InsideSctrCnt==0)&&(gsPrdInfo.uarPrdQue[upTmpAddrInfo->uPrdPtr].uFua&cHdlNvmeFlush)))    //
                                                                                                                                                  //
                                                                                                                                                  //
                                                                                                                                                  //
                                                                                                                                                  // 20190417_ChrisSu
       &&(u16InsideSctrCnt<=upTmpAddrInfo->uRwHalfKb))
    // test end
    {
#if 0
        // try debug
        if(u16InsideSctrCnt==upTmpAddrInfo->uRwHalfKb)
        {
            // debug, here should not happen.
            NLOG_PCIeErr(cLogPcieErr,
                         RWCMD_C,
                         0,
                         "PCIe Wr: Wait last Des is done.");

            // Wait CPU1 to Program
            while(gsRwCtrl.u32ProgFifoTail==u32CurProgTail)
                ;

            return u16InsideSctrCnt/cSctrPer4k;
        }
#endif

#if _EN_FW_DEBUG_UART
        NLOG_PCIeErr(cLogPcieErr,
                     RWCMD_C,
                     4,
                     " PCIe Wr: Fill Blk=0x%04X, Page=0x%04X, Ch=0x%04X, Intlv=0x%04X.",
                     upTmpAddrInfo->u16FBlock,
                     upTmpAddrInfo->u16FPage,
                     upTmpAddrInfo->uCh,
                     upTmpAddrInfo->uIntlvAddr);
#endif

        // modify Flash Command Queue Spare Byte setting
        // [W] [X] [X] [Y] [Y] [Z] [Z] [W]
        //      |---|-Stuck             |-Start
        //          |-1st Loop Found
        //  |-2nd Loop Found
        uTempSprStr=gSparePtrTail[upTmpAddrInfo->uCh]&(cSpareRegisterCnt-1);

        while(u32CurProgTail!=gSpareDesIdx[upTmpAddrInfo->uCh][uTempSprStr])
        {
            uTempSprStr=(cSpareRegisterCnt+uTempSprStr-1)&(cSpareRegisterCnt-1);    // %(cSpareRegisterCnt);
        }

        while(u32CurProgTail==gSpareDesIdx[upTmpAddrInfo->uCh][uTempSprStr])
        {
            uTempSprStr=(cSpareRegisterCnt+uTempSprStr-1)&(cSpareRegisterCnt-1);    // %(cSpareRegisterCnt);
        }

        gSparePtrHead[upTmpAddrInfo->uCh]=(uTempSprStr+1)&(cSpareRegisterCnt-1);
        gSparePtrTail[upTmpAddrInfo->uCh]=gSparePtrHead[upTmpAddrInfo->uCh];
        gSpareCnt[upTmpAddrInfo->uCh]-=gPlaneNum;
        u4kCntPtr=u16InsideSctrCnt/cSctrPer4k;

        while(u4kCntPtr!=upTmpAddrInfo->uPlaneCnt)
        {
            // while(u4kCntPtr>cMax4kNum);//debug while
            garDesF2hInfo[u32CurProgTail].u16arHBlock[u4kCntPtr]=c16BitFF;
            garDesF2hInfo[u32CurProgTail].u16arHPage[u4kCntPtr]=c16BitFF;
            u4kCntPtr++;
        }

        if(gSecurityOption&cEnE2e)
        {
            uE2eErrCnt=0;

            for(u4kCntPtr=0; u4kCntPtr<upTmpAddrInfo->uPlaneCnt; u4kCntPtr++)
            {
                uE2eCmprErr=0;

                if((garDesF2hInfo[u32CurProgTail].u16arHBlock[u4kCntPtr]!=c16BitFF)&&
                   (garDesF2hInfo[u32CurProgTail].u16arHPage[u4kCntPtr]!=c16BitFF))
                {
                    u16SBufIdx=((upTmpAddrInfo->u16BufPtr+(u4kCntPtr<<cSctrTo4kShift))%c16WriteBufSize);
                    u32LbaAddr=garDesF2hInfo[u32CurProgTail].u16arHBlock[u4kCntPtr]*g32SectorPerBlockH+
                                (garDesF2hInfo[u32CurProgTail].u16arHPage[u4kCntPtr]<<cSctrTo4kShift);
                    bopCopyRam((LWORD)&gCrcDataBuffer[0], (LWORD)c32TsbCrcAddr+(u16SBufIdx<<3), cSctrPer4k<<3, cCopyTsb2Tsb|cBopWait);
                    genInternalDataCrc(u16SBufIdx, cSctrPer4k, u32LbaAddr, cE2eUserData);

                    for(BYTE uSctCnt=0; uSctCnt<cSctrPer4k; uSctCnt++)
                    {
                        // skip AES bypass bit.
                        if(((*(WORD *)(c32TsbCrcAddr+(u16SBufIdx+uSctCnt)*8))&0x7FFF)!=((*(WORD *)(gCrcDataBuffer+uSctCnt*8))&0x7FFF))
                        {
                            uE2eCmprErr=1;
                        }
                    }

                    if(uE2eCmprErr)
                    {
#if _EN_FW_DEBUG_UART
                        NLOG_PCIeErr(cLogPcieErr,
                                     RWCMD_C,
                                     3,
                                     " PCIe Wr: E2e check fail, Invaild garDesF2hInfo, u4kCntPtr=0x%04X, HBlk=0x%04X, HPage=0x%04X.",
                                     (WORD)u4kCntPtr,
                                     garDesF2hInfo[u32CurProgTail].u16arHBlock[u4kCntPtr],
                                     garDesF2hInfo[u32CurProgTail].u16arHPage[u4kCntPtr]);
#endif
                        garDesF2hInfo[u32CurProgTail].u16arHBlock[u4kCntPtr]=c16BitFF;
                        garDesF2hInfo[u32CurProgTail].u16arHPage[u4kCntPtr]=c16BitFF;
                        uE2eErrCnt++;
                    }
                }
                else
                {
                    break;
                }
            }
        }

        gpFlashAddrInfo=upTmpAddrInfo;
        upTmpAddrInfo->uOpTyp=cErrHdlDummyProg;
        // setSprByteOfDataBlk(u32CurProgTail);    // data & F2hTableID
        gProgFifoPtr=u32CurProgTail;

        // wait core1 call setSprByteOfDataBlk
        while(gProgFifoPtr!=cBitFF)
            ;

        // Raising Raid Flag
        u16SBufIdx=u16StrBufPtr;
        u16EBufIdx=(u16SBufIdx+upTmpAddrInfo->uRwHalfKb-u16InsideSctrCnt)%c16WriteBufSize;

        ctrlRangeRaidFlag(u16EBufIdx, u16SBufIdx, cLowerBufFlag);
        ctrlRangeRaidFlag(u16SBufIdx, u16EBufIdx, cRaiseBufFlag);

        // Wait CPU1 to Program
        while(gsRwCtrl.u32ProgFifoTail==u32CurProgTail)
            ;

        return (u16InsideSctrCnt/cSctrPer4k)-uE2eErrCnt;
    }

    return 0;
}    /* fillLastProgDes */

void recovPcieErrW()
{
    LWORD u32ProgFifoTail;
    WORD u16HowFarToReach;
    BYTE uKeepLast4kCnt, uIdx0;

#if _ENABLE_RAID
    LWORD u32CacheFreePagePtr;
#endif

#if _EN_PCIE_TIME_REC
    mRecordPcieTimeStamp(3);
#endif

    while(gsRwCtrl.u32UpdFifoPtr!=gsRwCtrl.u32ProgFifoHead)
    {
        updateF2hTable(gsRwCtrl.u32ProgFifoHead);
    }

    u32ProgFifoTail=(BYTE)gsRwCtrl.u32ProgFifoTail;
    gsPcieErrInfo.uLastPreProgFifoTail=u32ProgFifoTail;
    uKeepLast4kCnt=fillLastProgDes();    // for raid

    // NLOG(cLogPcieErr, RWCMD_C, 3, " PCIe Wr: 1st_Prog Head=0x%04X, 1st_PreProgTail=0x%04X,1st_Prog Tail=0x%04X ",
    // gsRwCtrl.u32ProgFifoHead, gsPcieErrInfo.uLastPreProgFifoTail, gsRwCtrl.u32ProgFifoTail);    // 20190307_Bill_SMI_S0215F

    if(u32ProgFifoTail!=gsRwCtrl.u32ProgFifoHead)
    {
        gsCacheInfo.u32CacheFreePagePtr=garDesAddrInfo[u32ProgFifoTail].u32FPageNoTran;

        if(u32ProgFifoTail!=gsRwCtrl.u32ProgFifoTail)
        {
            // add after program tail ++
            gsCacheInfo.u32CacheFreePagePtr+=g4kNumPerPage;    // maybe it's F2h or Last Des or etc.

            if((gsCacheInfo.u32CacheFreePagePtr%gsCacheInfo.u16TotalPgPerF2hTab)==(gsCacheInfo.u16ValidPgPerF2hTab))
            {
                gsCacheInfo.u32CacheFreePagePtr+=(gsCacheInfo.u16TotalPgPerF2hTab-gsCacheInfo.u16ValidPgPerF2hTab);

                // gsPcieErrInfo.uDebugCnt++;
                while(gsRwCtrl.u32ProgFifoTail!=gsRwCtrl.u32ProgFifoHead)
                    ;
            }
        }
    }

    gsPcieErrInfo.uLastProgFifoHead=(BYTE)gsRwCtrl.u32ProgFifoHead;
    gsPcieErrInfo.uLastProgFifoTrig=(BYTE)gsRwCtrl.u32ProgFifoTrig;
    gsPcieErrInfo.uLastProgFifoTail=(BYTE)gsRwCtrl.u32ProgFifoTail;
    gsPcieErrInfo.uLastBgdProcF=gsGcInfo.ubBgdProcF;
    gsPcieErrInfo.u16LastOrgCacheF2hTabFreePtr=gsCacheInfo.u16CacheF2hTabFreePtr;    // debug
    gsPcieErrInfo.uLastWrKeep4kCnt=0;
    g32NandTempSensor=0;

#if _ENABLE_RAID
    if(gsRwCtrl.u32ProgFifoTail!=gsRwCtrl.u32ProgFifoHead)
    {
        core1TskRstRaidPara();    // reset Hdma in Queue
        gsRwCtrl.u32ProgFifoTail=gsRwCtrl.u32ProgFifoHead;

        while(gsTskFifoCtrl.u32HeadPtr!=gsTskFifoCtrl.u32TailPtr)
            ;
    }
#else
    gsRwCtrl.u32ProgFifoTail=gsRwCtrl.u32ProgFifoTrig=gsRwCtrl.u32ProgFifoHead;
#endif

    // resetAllFlashCore0();

    recovPcieErrW2(uKeepLast4kCnt);

    getWriteSctr2ChgBlk();
    chkWriteSctr2ChgBlk();

    gsCacheInfo.uChkF2hRegion=0;

    if(chkHdlF2hTab(g16FlushChkStart+g16FlushRem4K))
    {
        gsCacheInfo.uChkF2hRegion=1;
    }

    if(gsGcInfo.ubBgdProcF)
    {
        // please reference void chkFlushCacheTabOccF()
        if((gsCacheInfo.u32CacheFreePagePtr%g16ChkFlushSize)<g16FlushStr4K)
        {
#if 1
            if(mChkGcQue(cGcTypFlushF2h))
            {
                mPopGcQue(cGcTypFlushF2h);
            }

            gsGcInfo.ubBgdProcF=0;
            gsRwCtrl.u16OccFSkipSize=0;
            gsRwCtrl.u16OccFSkipStBufPtr=0;

#if _EN_PCIE_PATH_REC
            mRecPcieErrPath(cErrCancelPartWork);
#endif
            /*NLOG_PCIeErr(cLogPcieErr,
               *     RWCMD_C,
               *     0,
               *     " PCIe Wr: Disable Background process Force.");*/
#else
            gsFtlDbg.u16DummyFailType=cRecovPcieErrW1;
            debugWhile();
#endif
        }
        else
        {
            u16HowFarToReach=(g16ChkFlushSize-(gsCacheInfo.u32CacheFreePagePtr%g16ChkFlushSize))*cSctrPer4k;

            if((u16HowFarToReach==g16ChkFlushSize*cSctrPer4k)&&
               ((gsPcieErrInfo.uLastProgFifoTail==gsRwCtrl.u32ProgFifoHead)&&(gsRwCtrl.u16OccFSkipSize==c16WriteBufSize)))
            {
#if 1
                // it should wait flash reset
#if _EN_PCIE_PATH_REC
                mRecPcieErrPath(cErrTrigFlushF2h);
#endif

                if(mChkGcQue(cGcTypFlushF2h))
                {
                    gsGcInfo.ubBgdProcF=cBit7;
#if _EN_FW_DEBUG_UART
                    NLOG_PCIeErr(cLogECC, RWCMD_C, 0, " PCIe Wr: This time Should Flush F2h immediately.");
#endif
                }
#else/* if 0 */
                gsFtlDbg.u16DummyFailType=cRecovPcieErrW2;
                debugWhile();
#endif/* if 0 */
            }
            else
            {
#if _EN_FW_DEBUG_UART
                NLOG_PCIeErr(cLogPcieErr, RWCMD_C, 1, " PCIe Wr: Org Occupy Size = 0x%04X", gsRwCtrl.u16OccFSkipSize);
                NLOG_PCIeErr(cLogPcieErr, RWCMD_C, 1, " PCIe Wr: Org Occupy Ptr = 0x%04X", gsRwCtrl.u16OccFSkipStBufPtr);
                NLOG_PCIeErr(cLogPcieErr, RWCMD_C, 1, " PCIe Wr: How Far to Reach = 0x%04X", u16HowFarToReach);
#endif

                gsRwCtrl.u16OccFSkipSize=c16WriteBufSize-u16HowFarToReach;

#if _ENABLE_RAID
                gsRwCtrl.u16OccFSkipStBufPtr=g16FlashWBufPtr+u16HowFarToReach;
                u32CacheFreePagePtr=gsCacheInfo.u32CacheFreePagePtr-(gsCacheInfo.u32CacheFreePagePtr%g16ChkFlushSize)+g16FlushStr4K;
                chkRaidParityOccF(u32CacheFreePagePtr);
#else
                gsRwCtrl.u16OccFSkipStBufPtr=g16FlashWBufPtr+u16HowFarToReach;
#endif

#if _EN_PCIE_PATH_REC
                mRecPcieErrPath(cErrReCalPartWork);
#endif
#if _EN_FW_DEBUG_UART
                NLOG_PCIeErr(cLogPcieErr, RWCMD_C, 1, " PCIe Wr: New Occupy Size = 0x%04X", gsRwCtrl.u16OccFSkipSize);
                NLOG_PCIeErr(cLogPcieErr, RWCMD_C, 1, " PCIe Wr: New Occupy Ptr = 0x%04X", gsRwCtrl.u16OccFSkipStBufPtr);
#endif

                // NLOG_PCIeErr(cLogPcieErr,RWCMD_C,0," PCIe Wr: Recalculate Stop Buffer Pointer.");
                if(gsRwCtrl.u16OccFSkipStBufPtr==c16WriteBufSize)
                {
                    if(mChkGcQue(cGcTypFlushF2h))
                    {
                        mPopGcQue(cGcTypFlushF2h);
                    }

                    gsGcInfo.ubBgdProcF=0;
                    gsRwCtrl.u16OccFSkipSize=0;
                    gsRwCtrl.u16OccFSkipStBufPtr=0;
                    chkFlushCacheTabOccF();
#if _EN_FW_DEBUG_UART
                    NLOG_PCIeErr(cLogPcieErr, RWCMD_C, 0, " PCIe Wr: Skip GC this time.");
#endif
                }
            }
        }
    }

    for(uIdx0=0; uIdx0<((c16WriteBufSize/cSctrPer4k)/32); uIdx0++)
    {
        g32arFwPreOccuFlag[uIdx0]=0;
    }

    for(uIdx0=0; uIdx0<cHmbRacingFreeCnt; uIdx0++)
    {
        g16WriteHMBH2FTable[uIdx0]=c16Null;
    }

#if _EN_FW_DEBUG_UART
    NLOG_PCIeErr(cLogPcieErr,
                 RWCMD_C,
                 3,
                 " PCIe Wr: After-Prog Head=0x%04X, Tail=0x%04X, Trig=0x%04X,",
                 gsRwCtrl.u32ProgFifoHead,
                 gsRwCtrl.u32ProgFifoTail,
                 gsRwCtrl.u32ProgFifoTrig);
#endif
    g32LastLbaW=0xFFFFFFFF;
    gWriteHMBIndex=0;
    gsPrdInfo.uTrigWCmdCnt=0;
    gsPrdInfo.u16TrigHostRestSectCnt=0;
    gsPrdInfo.u32TrigWrCmdHead=gsPrdInfo.u32TrigWrCmdTail=gsPrdInfo.u32TrigWrCmdTrig=0;

    mClrToDoHdlPcieWErrF;
    mClrDesFullOnPcieWErrF;
}    /* recovPcieErrW */

void recovPcieErrR()
{
    BYTE uIdx0;

    if(mChkReadAhead)
    {
        termContiR();
    }
    else
    {
        gsRwCtrl.u32SeqRdFlag|=cBit1;

        while(gsRwCtrl.u32SeqRdFlag&cBit1)
            ;

        gsRwCtrl.u32SeqRdFlag=0;

        while(gsRwCtrl.u32SeqRdCpu1Flag)
            ;
    }

    for(uIdx0=0; uIdx0<cMaxRH2fTabNum; uIdx0++)
    {
        gsRwCtrl.uarTab2PrdPtr[uIdx0]=cNull;
    }

    for(uIdx0=0; uIdx0<cPrdDepth; uIdx0++)
    {
        gsRwCtrl.uarTabLinkPtr[uIdx0]=cNull;
    }

    clrLastReadGrp();
    gsRwCtrl.uFreeHSgmtCnt=cMaxRH2fTabNum;

    gsRwCtrl.uSrchQTail=gsRwCtrl.uSrchQHead=0;
    gsRwCtrl.uSrchQCnt=0;
    gsRwCtrl.uFreeNbsSlotTail=gsRwCtrl.uFreeNbsSlotHead=0;
    gsRwCtrl.uFreeNbsSlotCnt=cSrchEnginDepth;

    for(uIdx0=0; uIdx0<cSrchEnginDepth; uIdx0++)
    {
        gsRwCtrl.uarFreeNbsSlot[uIdx0]=uIdx0;
    }

    for(uIdx0=0; uIdx0<cSrchQDepth; uIdx0++)
    {
        gsRwCtrl.uarSrchQ2RdHaddr[uIdx0]&=~cBit7;
    }

    gsRwCtrl.uTabPrdTail=gsRwCtrl.uTabPrdHead;
    gsRwCtrl.uTabPrdCnt=0;
    gsCacheInfo.u32H2f1kTabSgmtPrep=0;
    gsRwCtrl.u32H2fSgmtRdyTail=gsRwCtrl.u32H2fSgmtRdyHead;
    gsRwCtrl.uSrcPrdTail=gsRwCtrl.uSrcPrdHead;
    gsRwCtrl.uSrcPrdCnt=0;

    g32LastLbaR=0xFFFFFFFF;
    gsPrdInfo.uQCmdCnt=0;
    gsPrdInfo.uSeqPrdTail=gsPrdInfo.uSeqPrdHead=0;
    gsPrdInfo.uSeqRCmdCnt=0;
    gsRwCtrl.u32TrigHostTail=gsRwCtrl.u32TrigHostHead;
    gsPrdInfo.uSeqRTrigCnt=0;
    bopClrRam((LWORD)&garSrchSrcTab, sizeof(garSrchSrcTab), 0xFFFFFFFF, cClrCore0Dccm|cBopWait);

    for(uIdx0=0; uIdx0<cMaxRH2fTabNum; uIdx0++)
    {
        while(!mChkH2f1kTabSgmtExpire(uIdx0))
        {
            mSetH2f1kTabSgmtExpire(uIdx0);
        }
    }
}    /* recovPcieErrR */

void recovNvmePrd()
{
    BYTE uIdx0, uIdx1;

    // reset Nvme Hw
    for(uIdx0=0; uIdx0<cHwPrdDepth; uIdx0++)
    {
        for(uIdx1=0; uIdx1<cHwPrdEntryCnt; uIdx1++)
        {
            r32NvmeDesc[uIdx0][uIdx1]=0;
            r32NvmePrd[uIdx0][uIdx1]=0;
        }

        gsPrdInfo.uarFreeHwPrdQue[uIdx0]=uIdx0;
    }

    gsPrdInfo.uFreeHwPrdHead=0;
    gsPrdInfo.uFreeHwPrdTail=0;
    gsPrdInfo.uFreeHwPrdCnt=cHwPrdDepth;

    for(uIdx0=0; uIdx0<8; uIdx0++)
    {
        rmDisDmaEngine(uIdx0);
    }

    // return;
    rmBgRstEn;
    _nop();
    _nop();
    _nop();
    _nop();
    _nop();
    rmBgRstOff;

    rmResetRaidFlg;
    rmResetOccupyFlg;
    rmResetBufFlg;

    while(rmChkDpsDppFifoNotEmpty)
    {
        // prevent next time to get wrong HwIdx
        rmPopNextValue;
    }
}    /* recovNvmePrd */

/*
   * void rstHmbTable()
   * {
   *  LWORD u32Cnt;
   *
   *  if(gsHmbInfo.uHmbEnable)
   *  {
   *      while(gsHmbInfo.usHmbList.u16Cnt)
   *      {
   *          remHmbLink(g16arH2fBackup[gsHmbInfo.usHmbList.u16Tail]);
   *      }
   *
   *      for(u32Cnt=cWproGcDesF2hTab00; u32Cnt<=cWproGcInfoPage; u32Cnt++)
   *      {
   *          if(mChkGcInfoHmbLink(u32Cnt))
   *          {
   *              mClrGcInfoHmbLink(u32Cnt);
   *          }
   *      }
   *  }
   * }
   */

void handlePcieError()
{
    BYTE uIdx0, uIdx1, uBkHmbEnable;
    WORD u16PrevNodeIdx, u16NextNodeIdx, u16PrdInfoIdx;
    volatile LINKINFO *upDelLlInfo;

#if _EN_FW_DEBUG_UART
    WORD u16PrdTrig;
#endif

    // gsDebugInfo.u32PcieErrHandleTime=rmGetRtc32kTick;

    // addCmdHistory();
#if _EN_PCIE_TIME_REC
    mRecordPcieTimeStamp(1);
#endif

    if(gLastTrigPrdTaskType==cNvmeCmdWrite)
    {
        if(!mChkDesFullOnPcieWErrF&&(gsRwCtrl.uCachePtr!=0))    // don't let ProgHead == ProgTail
        {
            termFlashOperW(0);    // for rest gsRwCtrl.uCachePtr
        }

#if _EN_PCIE_PATH_REC
        mRecPcieErrPath(cErrInPCIEWrtie);
#endif
        gsPcieErrInfo.u16debugPcieWErrCnt++;
        g32TotalPcieWrErrCnt++;
        // u16KeepCacheInfoLog=cInhandlePcieWrErr_00;
#if _EN_FW_DEBUG_UART
        NLOG(cLogPcieErr, RWCMD_C, 1, " PCIe Write Error Counts : 0x%04X ", gsPcieErrInfo.u16debugPcieWErrCnt);
        // gsPcieErrInfo.u16LastWrStopBufPtr=r32NvmePrd[gsPrdInfo.uarPrdQue[gsPrdInfo.usWritePrdList.u16Tail].uHwPrdIdx][1];
        u16PrdTrig=gsPrdInfo.usWritePrdList.u16Trig;
        NLOG(cLogPcieErr, RWCMD_C, 5, "PCIE ERROR current prd: 0x%04X , LBA:0x%08X, u16LastWrStopBufPtr:0x%08X", u16PrdTrig,
             (WORD)(gsPrdInfo.uarPrdQue[u16PrdTrig].u32LbaAddr>>16), (WORD)(gsPrdInfo.uarPrdQue[u16PrdTrig].u32LbaAddr),
             r32NvmePrd[gsPrdInfo.uarPrdQue[gsPrdInfo.usWritePrdList.u16Tail].uHwPrdIdx][1]>>16,
             r32NvmePrd[gsPrdInfo.uarPrdQue[gsPrdInfo.usWritePrdList.u16Tail].uHwPrdIdx][1]);
#endif
        // gsPcieErrInfo.u16LastWrStopBufPtr=r32NvmePrd[gsPrdInfo.uarPrdQue[gsPrdInfo.usWritePrdList.u16Tail].uHwPrdIdx][1];
    }
    else if(gLastTrigPrdTaskType==cNvmeCmdRead)
    {
#if _EN_PCIE_PATH_REC
        mRecPcieErrPath(cErrInPCIERead);
#endif
        gsPcieErrInfo.u16debugPcieRErrCnt++;
        g32TotalPcieRdErrCnt++;
        // u16KeepCacheInfoLog=cInhandlePcieRdErr_00;
#if _EN_FW_DEBUG_UART
        NLOG(cLogPcieErr, RWCMD_C, 1, " PCIe Read Error Counts : 0x%04X ", gsPcieErrInfo.u16debugPcieRErrCnt);
#endif
    }
    else
    {
        g32TotalPcieOthErrCnt++;    // unexpected Error
        // u16KeepCacheInfoLog=cInhandlePcieOthErr_00;
    }

    enSysTmr(cPcieErrHoldVal);

    while(!gCpu0TOFlag)
        ;

    disSysTmr();

    chkReleaseFreeHwPrd();

    // Clear Read / Write Prd List
    upDelLlInfo=&gsPrdInfo.usReadPrdList;
    uIdx0=2;

    while(uIdx0)
    {
        while(upDelLlInfo->u16Cnt)
        {
            u16PrdInfoIdx=upDelLlInfo->u16Tail;
            uIdx1=gsPrdInfo.uarPrdQue[u16PrdInfoIdx].uHwPrdIdx;
            mDelNode(u16PrevNodeIdx, gsPrdInfo.uarPrdLink, u16PrdInfoIdx, u16NextNodeIdx, upDelLlInfo);
            gsPrdInfo.uarFreePrdQue[gsPrdInfo.uFreePrdTail]=u16PrdInfoIdx;
            gsPrdInfo.uFreePrdTail=(gsPrdInfo.uFreePrdTail+1)&(cPrdDepth-1);
            gsPrdInfo.uTotalPrdTaskCnt--;

            if(uIdx1!=cNull)
            {
                gsPrdInfo.uarFreeHwPrdQue[gsPrdInfo.uFreeHwPrdHead]=uIdx1;
                gsPrdInfo.uFreeHwPrdHead=(gsPrdInfo.uFreeHwPrdHead+1)&(cHwPrdDepth-1);
                gsPrdInfo.uFreeHwPrdCnt++;
            }
        }

        upDelLlInfo->u16Trig=cNull;
        upDelLlInfo=&gsPrdInfo.usWritePrdList;
        uIdx0--;
    }

    while((    /*!rmChkSqEmpty||*/ !rmChkFwRqEmpty||rmChkCmdRdy))
    {
        while(rmChkCmdRdy)
        {
            rmPopNextCmd;
        }
    }

    gsBkPcieErrCacheInfo=gsCacheInfo;
    recovPcieErrW();
    recovPcieErrR();

    while(rmChkBopNbsBz)
        ;

    while(!rmChkNbsQueMt)
    {
        rmPopNbsQue;
        sysDelay(20);
    }

    rstH2F1KInfo();
    gLastTrigPrdTaskType=0;

#if _EN_PCIE_TIME_REC
    mRecordPcieTimeStamp(4);
#endif
    resetAllFlashCore0();
    resetCore1Var();

#if 1
    if(gsGcInfo.ubBgdProcF==cBit7)
    {
#if _EN_PCIE_TIME_REC
        mRecordPcieTimeStamp(5);
#endif

        while(gsHmbInfo.usHmbList.u16Cnt)
        {
            // Is safe to use HMB H2f Table in here?
            remHmbLink(g16arH2fBackup[gsHmbInfo.usHmbList.u16Tail]);
        }

        uBkHmbEnable=gsHmbInfo.uHmbEnable;
        gsHmbInfo.uHmbEnable=cFalse;
#if _EN_PCIE_PATH_REC
        mRecPcieErrPath(cErrFlushF2h);
#endif
        flushCacheF2hTab(cBit1);    // Is safe to use HMB H2f Table in here?
        mPopGcQue(cGcTypFlushF2h);
        gsHmbInfo.uHmbEnable=uBkHmbEnable;
        gsGcInfo.ubBgdProcF=0;
        gsRwCtrl.u16OccFSkipSize=0;
        gsRwCtrl.u16OccFSkipStBufPtr=0;

        if(!gsCacheInfo.uChkF2hRegion)
        {
            chkFlushCacheTabOccF();
        }

#if _EN_FW_DEBUG_UART
        NLOG_PCIeErr(cLogPcieErr, RWCMD_C, 0, " PCIe Wr: Flush F2h Table.");
#endif
#if _EN_PCIE_TIME_REC
        mRecordPcieTimeStamp(6);
#endif
    }
#endif/* if 0 */

    // clrLastReadGrp();    // 20190307_Bill_SMI_S0215F
    recovNvmePrd();
#if _EN_RAID_GC
    gsHmbInfo.uHmbStsChg=cTrue;
    chkHmbStsChg();
    gsCacheInfo.u16PartialParityPtrGc=0;
#endif

    mClrHandlePcieErrF;    // 20190307_Bill_SMI_S0215F
    clrLastReadGrp();    // 20190307_Bill_SMI_S0215F
    progCacheInfoTab();
#if 0
    // debug  Info
    mDebugPCIeErrWhile((gsRwCtrl.u32ProgFifoHead!=gsRwCtrl.u32ProgFifoTail)||(gsRwCtrl.u32ProgFifoHead!=gsRwCtrl.u32ProgFifoTrig))
    ;

    mDebugPCIeErrWhile(
        (gsRwCtrl.u32FreeSrcFifoHead!=gsRwCtrl.u32FreeSrcFifoTail)||(gsRwCtrl.u32FreeSrcFifoHead!=gsRwCtrl.u32FreeSrcFifoTrig))
    ;
#endif
#if _EN_PCIE_TIME_REC
    mRecordPcieTimeStamp(7);
#endif

#if _EN_PCIE_PATH_REC
    gsPcieErrInfo.u32LastPcieErrPath=gsPcieErrInfo.u32CurrPcieErrPath;
    gsPcieErrInfo.u32CurrPcieErrPath=0;
#endif
    // mClrHandlePcieErrF;    // 20190307_Bill_SMI_S0215F
}    /* handlePcieError */

#if _ENABLE_SECAPI
/*============ Can be used as SecIntf_GetReadGHP() ============*/
LWORD GetReadGHP(LWORD u32GHP)
{
    LWORD u32MBRGHP=u32GHP-cTcgTotalHostHPage;

    if(garMBRValidBitMap[u32MBRGHP>>3]&cbBitTab[u32MBRGHP&0x07])
    {
        return u32GHP+cTcgH2fMapSize;
    }

    return u32GHP;
}

#endif/* if _ENABLE_TCG */

void saveRaidAllParity()
{
#if _EN_RAID_GSD
#if  0    // _EN_FW_DEBUG_UART
    NLOG(cLogTempDebug,
         RWCMD_C,
         2,
         "saveRaidAllParity, gsHmbInfo.uHmbStsChg=0x%04X,gsGcInfo.uHMBchg=0x%04X",
         gsHmbInfo.uHmbStsChg,
         gsGcInfo.uHMBchg);
#endif
    WORD u16SbufPtr, u16PtyIdx, u16ParityIdx=0;
    BYTE uPageIdx, uProgCntPerWL, uRaidBlkIdx;

    // if((mGetGcState==cGcMoveData)||(gsHmbInfo.uHmbStsChg))
    if(gsHmbInfo.uHmbStsChg)
    {
        mSetGcFlag(cGcDesFailAbort);

        NLOG(cLogTempDebug,
             RWCMD_C,
             4,
             "mSetGcFlag(cGcDesFailAbort), mGetGcState=0x%04X, gsGcInfo.uHmbGcCachePtr=0x%04X, gsCacheInfo.u16PartialParityPtrGc=0x%04X, gsHmbInfo.uHmbStsChg=0x%04X",
             mGetGcState,
             gsGcInfo.uHmbGcCachePtr,
             gsCacheInfo.u16PartialParityPtrGc,
             gsHmbInfo.uHmbStsChg);
    }
    else
    {
        if(gsHmbInfo.uHmbEnPtCache&&(gsGcInfo.u16GcDesBlock!=c16FBlockInitValue))
        {
            u16SbufPtr=c16GcParitySIdx;    // c16WriteSIdx;
            uProgCntPerWL=mChkMlcMoBit(gsGcInfo.u16GcDesBlock)?cProgCntPerWL:1;

            for(u16PtyIdx=0; u16PtyIdx<(cRaidParityPageNum/uProgCntPerWL); u16PtyIdx++)
            {
                for(uPageIdx=0; uPageIdx<uProgCntPerWL; uPageIdx++)
                {
#if  0    // _EN_FW_DEBUG_UART
                    NLOG(cLogTempDebug, RWCMD_C, 2, "saveRaidAllParity, g32arGcPtyCrc[0x%04X *2]=0x%04X", u16ParityIdx*2,
                         g32arGcPtyCrc[u16ParityIdx*2]);
#endif

                    if((u16PtyIdx<gsCacheInfo.u16PartialParityPtrGc)&&(g32arGcPtyCrc[u16ParityIdx*2]))
                    {
                        mWaitHmbRelease(2);
                        txfrHmbData(cHmbReadData,
                                    u16SbufPtr,
                                    cRaidDataSctrNum,
                                    (u16ParityIdx*cRaidDataSctrNum)<<9,
                                    u16ParityIdx,
                                    cHmbGcPtCache,
                                    cHmbTsbPath|cHmbReadDir|cHmbBufflagChk,
                                    g32arGcPtyCrc[u16ParityIdx*2]);
                        readPtyE2eFromHmb(u16ParityIdx);

                        // mWaitHmbTransferDone();
                        progPartialRaidParityCore0(u16SbufPtr, u16PtyIdx, cRaidGcPty, uPageIdx);
                        // u16SbufPtr=addWriteBufPtr(u16SbufPtr, cRaidDataSctrNum);
                    }
                    else
                    {
                        if(g16arRaidParityPtr[u16ParityIdx]!=c16RaidPtrInitValue)
                        {
                            uRaidBlkIdx=mGetRaidPtyBlkIndex(u16ParityIdx);

                            while(!g16arRaidPtyBlkVpCnt[uRaidBlkIdx])
                                ;

                            g16arRaidPtyBlkVpCnt[uRaidBlkIdx]--;

                            if((!g16arRaidPtyBlkVpCnt[uRaidBlkIdx])&&(uRaidBlkIdx!=gsCacheInfo.uRaidGcPtyBlkIdx))
                            {
                                pushRaidPtyBlkCore0(uRaidBlkIdx);
                            }

                            g16arRaidParityPtr[u16ParityIdx]=c16RaidPtrInitValue;
                        }
                    }

                    u16ParityIdx++;
                }
            }

            mWaitHmbTransferDone();
        }
    }
#endif/* if _EN_RAID_GSD */
}    /* saveRaidAllParity */

void restoRaidAllParity()
{
#if _EN_RAID_GSD
    WORD u16SbufPtr, u16PtyIdx, u16NowNodeIdx, u16ParityIdx=0;
    BYTE uProgCntPerWL, uPageIdx;
#if  0    // _EN_FW_DEBUG_UART
    NLOG(cLogTempDebug, RWCMD_C, 2, "restoRaidAllParity, g16arRaidPtyBlkVpCnt=[0x%04X,0x%04X]", g16arRaidPtyBlkVpCnt[0],
         g16arRaidPtyBlkVpCnt[1]);
    NLOG(cLogTempDebug, RWCMD_C, 2, "gsGcInfo.u16GcDesBlock=0x%04X, gsHmbInfo.uHmbStsChg=0x%04X]", gsGcInfo.u16GcDesBlock,
         gsHmbInfo.uHmbStsChg);
    NLOG(cLogTempDebug,
         RWCMD_C,
         3,
         "mGetGcState=0x%04X, gsGcInfo.uHmbGcCachePtr=0x%04X, mChkGcFlag(cGcDesFailAbort)=0x%04X",
         mGetGcState,
         gsGcInfo.uHmbGcCachePtr,
         mChkGcFlag(cGcDesFailAbort));
#endif

    if(gsHmbInfo.uHmbEnPtCache&&(gsGcInfo.u16GcDesBlock!=c16FBlockInitValue)&&(!gsHmbInfo.uHmbStsChg)&&(!mChkGcFlag(cGcDesFailAbort)))
    {
        u16SbufPtr=c16GcParitySIdx;    // c16ReadSIdx;
        uProgCntPerWL=mChkMlcMoBit(gsGcInfo.u16GcDesBlock)?cProgCntPerWL:1;

        for(u16PtyIdx=0; u16PtyIdx<gsCacheInfo.u16PartialParityPtrGc; u16PtyIdx++)
        {
            for(uPageIdx=0; uPageIdx<uProgCntPerWL; uPageIdx++)
            {
#if    0    // _EN_FW_DEBUG_UART
                NLOG(cLogTempDebug, RWCMD_C, 2, "g16arRaidParityPtr[0x%04X]=0x%04X", u16ParityIdx, g16arRaidParityPtr[u16ParityIdx]);
#endif
                u16NowNodeIdx=gsRwCtrl.uarFreeSrcQue[gsRwCtrl.u32FreeSrcFifoHead];
                gpFlashAddrInfo=&garSrcAddrInfo[u16NowNodeIdx];
                g16FBlock=g16arRaidParityBlk[mGetRaidPtyBlkIndex(u16ParityIdx)];
                g32FPageNoTran=mTranRaidPtyAddr(mGetRaidPtyPagePtr(u16ParityIdx));
                gpFlashAddrInfo->uTsb4kIdx=0xFF;
                gpFlashAddrInfo->uSrcIdx=u16NowNodeIdx;
                tranAddrInfo(gpFlashAddrInfo);
                // tranCeNum(gpFlashAddrInfo);
                gSectorH=0;
                mSetFRwParam(u16SbufPtr, cRaidDataSctrNum, c16Bit1|c16Bit4|c16Bit15, cReadRaidParity);
                gsRwCtrl.u32FreeSrcFifoHead=(gsRwCtrl.u32FreeSrcFifoHead+1)&(cReadFifoDpt-1);

                while(gsRwCtrl.u32FreeSrcFifoTail!=gsRwCtrl.u32FreeSrcFifoHead)
                    ;

                // mWaitHmbRelease(2);
                txfrHmbData(cHmbWriteData,
                            u16SbufPtr,
                            cRaidDataSctrNum,
                            (u16ParityIdx*cRaidDataSctrNum)<<9,
                            u16ParityIdx,
                            cHmbGcPtCache,
                            cHmbTsbPath|cHmbBufflagChk,
                            0);
                writePtyE2e2Hmb(u16SbufPtr>>5, u16ParityIdx);
                mWaitHmbTransferDone();
                // u16SbufPtr=addReadBufPtr(u16SbufPtr, cRaidDataSctrNum);

                u16ParityIdx++;
            }
        }

        // mWaitHmbTransferDone();
    }
#endif/* if _EN_RAID_GSD */
}    /* restoRaidAllParity */

void releaseHwHmbPrd(BYTE uOpt)
{
    mSetOccFlag(uOpt);

    chkReleaseFreeHwPrd();

    if(rmHmbPrdQueTrigIdx!=gsHmbInfo.uHmbHwPrdTail)
    {
        releaseHmbHwPrd();
    }
}

void chkOccAtRWService()
{
#if _EN_SLCOpenBlkReadScrub
    if(mChkGcFlag(cFlushforReclaim)&&(gLastTrigPrdTaskType==cNvmeCmdRead))
    {
        releaseHwHmbPrd(cOccFlushCache);

        if(!gsPrdInfo.uTotalPrdTaskCnt)
        {
            termFlashOperRw(1);
            waitAllChCeBzCore0();
            waitHmbPrdDone();
            flushOpenBlock();
            mClrOccFlag(cOccFlushCache);
        }
    }
    else if(mChkOccFlag(cOccFlushCache))
    {
        mClrOccFlag(cOccFlushCache);
    }
#endif/* if _EN_SLCOpenBlkReadScrub */

    if(mChkGcFlag(cUnderReclaim)||mChkGcFlag(cReadScrubH2F))
    {
        releaseHwHmbPrd(cOccReadReclaim);

        if(!gsPrdInfo.uTotalPrdTaskCnt)
        {
            termFlashOperRw(1);

            if((gsCacheInfo.uH2fTabBlockCnt>=gsGcInfo.uGcH2fTabbHiThr)||mChkGcFlag(cReadScrubH2F))
            {
                g32Rtc32kStartVal=getRtcCurrent32k();
                gsGcInfo.u32BgdGcEndTime=c32PartialCleanRtc20ms;
                mPushGcQue(cGcTypH2fTab);
                waitAllChCeBzCore0();
                waitHmbPrdDone();
                bgdClnH2fTabblkProc();
            }

            if(mChkGcFlag(cUnderReclaim))
            {
                g32Rtc32kStartVal=getRtcCurrent32k();
                waitAllChCeBzCore0();
                waitHmbPrdDone();
                setGcFlowAndBlkCnt();
                gsGcInfo.u32BgdGcEndTime=gsGcInfo.u32GcCachebTime;
                bgdClnCacheblkProc(cWriteFunc);
            }

            mClrOccFlag(cOccReadReclaim);
        }
    }
    else if(mChkOccFlag(cOccReadReclaim))
    {
        mClrOccFlag(cOccReadReclaim);
    }

    if(mChkBadInfoFlag(cBadInfoChg))
    {
        releaseHwHmbPrd(cOccMarkBad);

        if(!gsPrdInfo.uTotalPrdTaskCnt)
        {
            termFlashOperRw(1);
            waitAllChCeBzCore0();
            waitHmbPrdDone();
            markBadBlockCore0();
            mClrOccFlag(cOccMarkBad);
        }
    }
    else if(mChkOccFlag(cOccMarkBad))
    {
        mClrOccFlag(cOccMarkBad);
    }
}    /* chkOccAtRWService */

#if _EN_SLCOpenBlkReadScrub
void flushOpenBlock()
{
    BYTE uProgPage=0, uloop=0, uPtr, uBreak;
    WORD u16BakF2HTabFlushStart, u16BakF2HTabFlushEnd;

    if((gsGcInfo.u16FlushBlk!=c16FBlockInitValue)&&(!mChkSkipGcSrch(gsGcInfo.u16FlushBlk)||mChkGcSrcBlkBmap(gsGcInfo.u16FlushBlk)))
    {
        mSetGcFlushState(cFlushIdle);
        mClrGcFlag(cFlushforReclaim);

        if(!mChkGcSrcBlkBmap(gsGcInfo.u16FlushBlk))
        {
            pushWLReadReclaimQCore0(gsGcInfo.u16FlushBlk);
        }
        else if(!mChkGcFlag(cUnderReclaim))
        {
            mSetGcFlag(cUnderReclaim);
        }

        gsGcInfo.u16FlushBlk=c16FBlockInitValue;
    }

    if((mGetGcFlushState==cWriteDummy)&&
       ((gsCacheInfo.u16ActiveCacheBlock==gsGcInfo.u16FlushBlk)||(gsCacheInfo.u16FluCacheBlock==gsGcInfo.u16FlushBlk)))
    {
        while((uProgPage<8)&&(!mChkCacheInfoFlag(cCacheBlockFull)))
        {
            uBreak=0;
            uPtr=0;

            for(uloop=0; uloop<g4kNumPerPage; uloop++)
            {
                gsRwCtrl.u16arCacheHPage[uloop]=c16BitFF;
                gsRwCtrl.u16arCacheHBlock[uloop]=c16BitFF;
                gsRwCtrl.uPrdPtr[uloop]=0xFE;

                if(mChkNewDesF)
                {
                    setWriteDes(gsRwCtrl.u16ProgPageOfst, &garDesAddrInfo[gsRwCtrl.u32ProgFifoHead], cWriteCache);
                    mClrNewDesF;    // gbNewDesF=0;
                }

                if((uloop==(gsCacheInfo.u4KNumToPadF2h-1))&&(mChkCacheEobFlag(cEob1stF2h)))
                {
                    uBreak=1;
                    // uPtr=4;
                    uPtr=gsCacheInfo.u4KNumToPadF2h;
                }
                else if((uloop==(g4kNumPerPage-c4kNumPerRaidPty-1))&&(mChkCacheEobFlag(cEobRaid)))
                {
                    uBreak=1;
                    uPtr=g4kNumPerPage-c4kNumPerRaidPty;
                }
                else if(uloop==g4kNumPerPage-1)
                {
                    uPtr=g4kNumPerPage;
                }

                if(uPtr!=0)
                {
#if _ENABLE_RAID
                    bopClrRam((LWORD)(c32Tsb0SAddr+(g16FlashWBufPtr<<9)), (uPtr<<(cSctrTo4kShift+9)), (LWORD)0x00000000,
                              cBopWait|cBopTsbFlag|cBopRaidFlag|cClrTsb);
#else
                    bopClrRam((LWORD)(c32Tsb0SAddr+(g16FlashWBufPtr<<9)), (uPtr<<(cSctrTo4kShift+9)), (LWORD)0x00000000,
                              cBopWait|cBopTsbFlag|cClrTsb);
#endif
                }

                garDesF2hInfo[gsRwCtrl.u32ProgFifoHead].u16arHPage[uloop]=c16BitFF;
                garDesF2hInfo[gsRwCtrl.u32ProgFifoHead].u16arHBlock[uloop]=c16BitFF;
#if _ENABLE_RAID
                resetSrchTgt();
#endif
                setProgFifoOpt(cNull);
                gsCacheInfo.u32WriteSctr2ChgBlk-=(uPtr<<cSctrTo4kShift);

                if(gsCacheInfo.u32WriteSctr2ChgBlk==0)
                {
                    mSetChgBlock;
                    mSetCalWriteSctr2ChgBlk;
                }

                if(uBreak)
                {
                    uloop=g4kNumPerPage;
                }
            }

            while(gsRwCtrl.u32UpdFifoPtr!=gsRwCtrl.u32ProgFifoHead)
            {
                updateF2hTable(gsRwCtrl.u32ProgFifoHead);
            }

            if(gsRwCtrl.u16OccFSkipSize>=c16WriteBufSize)
            {
                while(gsRwCtrl.u32ProgFifoTail!=gsRwCtrl.u32ProgFifoHead)
                    ;

                rmChkHdmaDone;

                flushCacheHmbTab();
                flushCacheF2hTab(cBit1);
                mPopGcQue(cGcTypFlushF2h);
                gsGcInfo.ubBgdProcF=0;
                gsRwCtrl.u16OccFSkipSize=0;

                if(!gsCacheInfo.uChkF2hRegion)
                {
                    chkFlushCacheTabOccF();
                }

                if(gsRwCtrl.ubDelayTrigHost)
                {
                    gsFtlDbg.u16DummyFailType=cFlushOpenBlock;
#if (C_Log_SaveMask&C_Debug_P2)    // 20181031_Oscar
                    NLOG(cLogHost, RWCMD_C, 1, " gsRwCtrl.ubDelayTrigHost=0x%04X ", gsRwCtrl.ubDelayTrigHost);
#endif
                    debugWhile();
                }

                waitHmbPrdDone();
            }

            uProgPage++;

            if(mChkCacheInfoFlag(cCacheBlockFull))
            {
                mGetGcFlushState=cFlushActive;
                gsCacheInfo.u16BakF2HTabFlushStart=0;
                gsCacheInfo.u16BakF2HTabFlushEnd=g16ChkFlushSize;
            }
        }

        while(gsRwCtrl.u32ProgFifoTail!=gsRwCtrl.u32ProgFifoHead)
            ;

        rmChkHdmaDone;

        g16WriteBufPtr=g16FlashWBufPtr;
        g32LastLbaW=0xFFFFFFFF;
    }
    else if((mGetGcFlushState==cFlushActive)&&
            ((gsCacheInfo.u16ActiveCacheBlock==gsGcInfo.u16FlushBlk)||(gsCacheInfo.u16FluCacheBlock==gsGcInfo.u16FlushBlk)))
    {
        if(gsCacheInfo.u16BakF2HTabFlushStart!=gsCacheInfo.u16TotalPgPerF2hTab)
        {
            u16BakF2HTabFlushStart=gsCacheInfo.u16F2HTabFlushStart;
            u16BakF2HTabFlushEnd=gsCacheInfo.u16F2HTabFlushEnd;
            gsCacheInfo.u16F2HTabFlushStart=gsCacheInfo.u16BakF2HTabFlushStart;
            gsCacheInfo.u16F2HTabFlushEnd=gsCacheInfo.u16BakF2HTabFlushEnd;
            flushCacheHmbTab();
            flushCacheF2hTab(cBit1|cBit4);

            gsCacheInfo.u16BakF2HTabFlushStart+=g16ChkFlushSize;
            gsCacheInfo.u16BakF2HTabFlushEnd+=g16ChkFlushSize;
            gsCacheInfo.u16F2HTabFlushStart=u16BakF2HTabFlushStart;
            gsCacheInfo.u16F2HTabFlushEnd=u16BakF2HTabFlushEnd;

            if(gsCacheInfo.u16BakF2HTabFlushEnd>=gsCacheInfo.u16TotalPgPerF2hTab)
            {
                gsCacheInfo.u16BakF2HTabFlushEnd=gsCacheInfo.u16TotalPgPerF2hTab;
            }

            if(gsCacheInfo.u16BakF2HTabFlushStart>=gsCacheInfo.u16TotalPgPerF2hTab)
            {
                gsCacheInfo.u16BakF2HTabFlushStart=gsCacheInfo.u16TotalPgPerF2hTab;
            }

            if(gsCacheInfo.u16BakF2HTabFlushStart==gsCacheInfo.u16TotalPgPerF2hTab)
            {
                gsCacheInfo.uFlushCacheBlkBank++;

                if(gsCacheInfo.uFlushCacheBlkBank==gsCacheInfo.uMaxFlushBankNum)
                {
#if _EN_VPC_SWAP
                    if(mChkVPCntValid(gsCacheInfo.u16FluCacheBlock))
#else
                    if(mGetCacheBlkVpCnt(gsCacheInfo.u16FluCacheBlock)!=0)
#endif
                    {
                        mClrSkipGcSrch(gsCacheInfo.u16FluCacheBlock);
                    }
                    else
                    {
                        pushSpareBlockCore0(gsCacheInfo.u16FluCacheBlock, cPushNotErase);
                    }
                }

                gsCacheInfo.u16FluCacheBlock=c16FBlockInitValue;
            }

            while(gsRwCtrl.u32ProgFifoTail!=gsRwCtrl.u32ProgFifoHead)
                ;

            rmChkHdmaDone;
            waitHmbPrdDone();
        }
    }
}    /* flushOpenBlock */

#endif/* if _EN_SLCOpenBlkReadScrub */

#if (!_ICE_LOAD_ALL)
#pragma default_function_attributes =
#endif







