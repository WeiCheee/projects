







#include "inc/DebugLog.h"
#include "inc/EventLogIDX.h"
#include "inc/EventLogFunctionIDX.h"
#include "inc/TypeDef.h"
#include "inc/Option.h"
#include "inc/ProType.h"
#include "inc/Reg.h"
#include "inc/NvmeCtrl.h"
#include "inc/table.h"
#include "inc/GlobVar0.h"
#include "inc/GlobVarS.h"
#include "inc/GlobVarT.h"
#include "inc/Mac.h"
#include "inc/GreyBox.h"
#include "inc/Rdlink.h"
#include "inc/RdlinkFunc.h"
#include "inc/BitDef.h"
#include "inc/Asm.h"
#include "common/ID.h"

// SMI VU
#if (!_ICE_LOAD_ALL)
#pragma default_function_attributes = @ ".CORE0_LITEONVU"
#endif
#include "I2cCtrl.c"

void VscMPPreformat()    // MPFormat_Chief_20181109
{
    readWproPageCore0(cWproGetLogPg, cNvmeGetLogSIdx, 0);

    bopClrRam((LWORD)(BYTE *)(&gpGetLog->usSmartLog), 0x200, 0x00, cBopWait|cClrTsb);
    bopClrRam((LWORD)(BYTE *)(&gpGetLog->usSmartLog.usSmart.usCnt), sizeof(SMARTCNT), 0x00, cBopWait|cClrTsb);
    bopClrRam((LWORD)(BYTE *)(&gsSmart.usCnt), sizeof(SMARTCNT), 0x00, cBopWait|cClrCore0Dccm);

#if _ENABLE_SMART_LS
    gpGetLog->usSmartLog.uAvailableSpareThreshold=gsLightSwitch.usSmartLs.uAvaliableSpareThres;
#else
    gpGetLog->usSmartLog.uAvailableSpareThreshold=0x10;
#endif

    gpGetLog->usSmartLog.u64arPowerCycles[0]++;
    g64TotalHostRdSecCnt=0;
    gsFtlDbg.u64TotalHostWrSecCnt=0;
    g64HostRdCmdCnt=0;
    g64HostWrCmdCnt=0;
    gsFtlDbg.u32PowerOnCnt=0;
    gsFtlDbg.u32UGSDPwrOnCnt=0;
    gsFtlDbg.u32PlpScpCompleteCnt=0;
    gsFtlDbg.u32PlpScpGpioInitCnt=0;

    gsFtlDbg.u32SlcVthTrackingFailCnt=0;
    gsFtlDbg.u32TlcVthTrackingFailCnt=0;
    g32E2eDetectCnt=0;
    g32InternalDataPath=0;

    progWproPageCore0(cWproGetLogPg, cNvmeGetLogSIdx);

    // Abort NVMe DST if in Progress
    if(((gsCurrDstResult.uDstStatus>>4)==cOperationShortDstInProgress)||
       ((gsCurrDstResult.uDstStatus>>4)==cOperationExtendedDstInProgress))
    {
        if(!(gsCurrDstResult.uDstStatus&0x0F))
        {
            gsCurrDstResult.uDstStatus|=cOperationAbortUnknowReson;
        }

        updateNvmeDstData(cReadWpro, cDstLogResultUpdate);
    }

    handleCore0VarErase();
    eraseUnitProcCore0(1);

    InitEraseCntCore0();    // 20190506_Louis

    // debug purpose
    while(gsRwCtrl.u32FreeSrcFifoHead!=gsRwCtrl.u32FreeSrcFifoTail)
        ;

    while(gsRwCtrl.u32ProgFifoTail!=gsRwCtrl.u32ProgFifoHead)
        ;

#if _ENABLE_SECAPI
    if(gbSecAPIPendingPCIeReset||gbSecAPIPendingNSSR||gbSecAPIPendingInitATA)
    {
        handleSecFlag();
    }
#endif
#if _EN_E2ENonCRCChk    // Oscar_20190220
    if(gsWUNCInfo.uWZeroFlag)
    {
        gsWUNCInfo.uWZeroFlag=0;
        bopCopyRam(((LWORD)garTsb0[0]), (LWORD)&gsWUNCInfo, sizeof(gsWUNCInfo),
                   cCopyStcm2Tsb|cBopWait);
        progWproPageCore0(cWproWriteUNC, c16Tsb0SIdx);
    }
#endif

    progCacheInfoTab();
}    /* VscMPPreformat */

void VscFOBPreformat()
{
#if _EN_E2ENonCRCChk    // Oscar_20190220
    if(gsWUNCInfo.uWZeroFlag)
    {
        gsWUNCInfo.uWZeroFlag=0;
        bopCopyRam(((LWORD)garTsb0[0]), (LWORD)&gsWUNCInfo, sizeof(gsWUNCInfo),
                   cCopyStcm2Tsb|cBopWait);
        progWproPageCore0(cWproWriteUNC, c16Tsb0SIdx);
    }
#endif

    // Abort NVMe DST if in Progress
    if(((gsCurrDstResult.uDstStatus>>4)==cOperationShortDstInProgress)||
       ((gsCurrDstResult.uDstStatus>>4)==cOperationExtendedDstInProgress))
    {
        if(!(gsCurrDstResult.uDstStatus&0x0F))
        {
            gsCurrDstResult.uDstStatus|=cOperationAbortUnknowReson;
        }

        updateNvmeDstData(cReadWpro, cDstLogResultUpdate);
    }

    handleCore0VarErase();
    eraseUnitProcCore0(1);

    // debug purpose
    while(gsRwCtrl.u32FreeSrcFifoHead!=gsRwCtrl.u32FreeSrcFifoTail)
        ;

    while(gsRwCtrl.u32ProgFifoTail!=gsRwCtrl.u32ProgFifoHead)
        ;

#if _ENABLE_SECAPI
    if(gbSecAPIPendingPCIeReset||gbSecAPIPendingNSSR||gbSecAPIPendingInitATA)
    {
        handleSecFlag();
    }
#endif/* if 0 */
}    /* VscFOBPreformat */

void VscCorePowerLearning(BYTE Corepwr_Param1, BYTE Corepwr_Param2)    // 2019_0315 LeverYu CorePower Learning
{
    BYTE uStatus=0, VSET=0x15;

    VSET=VSET-Corepwr_Param1;

    if(VSET<0x0B)
    {
        VSET=0x0B;
    }
    else if(VSET>0x15)
    {
        VSET=0x15;
    }

    NLOG(cLogAdmin, LITEONVU_C, 2, " Corepwr_Param1=0x%04X ,VSET=0x%04X", Corepwr_Param1, VSET);

    i2cInit();
    i2cMasterStart();

    uStatus=i2cMasterTxData(0x4A);    // Write ACT88325 (Device Address 7h'25)

    if(uStatus)
    {
        return;    // Can not found PMIC device
    }

    i2cMasterTxData(0x43);    // Set Buck2 Sleep Voltage register
    i2cMasterTxData(VSET);    // Set Buck2 PS4 sleep at 0.75V   //0x15: 0.8V
    i2cMasterStop();
}    /* Vui2cSetPmicAct88325 */

void VscClearGlist()
{}

WORD VscWriteEEPROM()
{
    if(Check_EEPROM_Tag(0)==cSuccess)
    {
        // SN
        copyCcmVal(gsLightSwitch.usCidHeader.uarSerialNum, (BYTE *)&garTsb0[0][0xC0], 20);
        copyCcmVal(gsMPInfo.uarSerialNum, (BYTE *)&garTsb0[0][0xC0], 20);
        // EUI64
        copyCcmVal(gsLightSwitch.usNvmeLs.uarEui64, (BYTE *)&garTsb0[0][0xB8], 8);
        copyCcmVal(gsMPInfo.uarEui64, (BYTE *)&garTsb0[0][0xB8], 8);
        // PPID
        copyCcmVal(gsLightSwitch.usVuIdLs.uarEppId, (BYTE *)&garTsb0[0][0xC0], 0x20);
#if (OEM==LENOVO)    // 20190108_SamHu_01 add for Lenovo 1.26 Spec Log DFh
        copyCcmVal(garLenovoLogDFhSN, (BYTE *)&garTsb0[5][0x90], 30);
        copyCcmVal(garLenovoLogDFhNewSN, (BYTE *)&garTsb0[5][0xB0], 30);
#endif
        copyCcmVal(i2cSetPS4CoreIndex, (BYTE *)&garTsb0[0][0x74], 2);

        insertVendorTask(cVendorCore1WriteMPInfo);
        return cStatusSuccess;
    }
    else
    {
        return cStatusInvalidField;
    }
}    /* VscWriteEEPROM */

void VscReadFlashID()
{
    insertVendorTask(cVendorCore1LiteOnVU_ReadFlashId);
}

void VscPCIEConfig()
{
    garTsb0[0][0]=rmCheckCurrentSpeed;
    garTsb0[0][1]=rmCheckCurrentLinkWidth;
    garTsb0[0][0x10]=(BYTE)rmChkPcieLinkCapMaximumLinkSpeed;
    garTsb0[0][0x11]=(BYTE)rmChkPcieLinkCapMaximumLinkWidth;
}

void VscReadDIDVID()
{
    g16arTsb0[0][0]=gsLightSwitch.usNvmeLs.u16Vid;
    g16arTsb0[0][1]=gsLightSwitch.usPcieLs.u16PcieDidLs;
    g16arTsb0[0][2]=gsLightSwitch.usNvmeLs.u16Ssvid;
    g16arTsb0[0][3]=gsLightSwitch.usPcieLs.u16PcieSsidLs;
}

void VscReadFWConfig()
{
    WORD uIdx;

    // 0x0      LITE-ON NVMe VSC
    uIdx=0;
    garTsb0[0x0][uIdx++]='L';
    garTsb0[0x0][uIdx++]='I';
    garTsb0[0x0][uIdx++]='T';
    garTsb0[0x0][uIdx++]='E';
    garTsb0[0x0][uIdx++]='-';
    garTsb0[0x0][uIdx++]='O';
    garTsb0[0x0][uIdx++]='N';
    garTsb0[0x0][uIdx++]=' ';
    garTsb0[0x0][uIdx++]='N';
    garTsb0[0x0][uIdx++]='V';
    garTsb0[0x0][uIdx++]='M';
    garTsb0[0x0][uIdx++]='e';
    garTsb0[0x0][uIdx++]=' ';
    garTsb0[0x0][uIdx++]='V';
    garTsb0[0x0][uIdx++]='S';
    garTsb0[0x0][uIdx++]='C';

    // 0x10    SM2263XT
    uIdx=0x10;
    garTsb0[0x0][uIdx++]='S';
    garTsb0[0x0][uIdx++]='M';
    garTsb0[0x0][uIdx++]='2';
    garTsb0[0x0][uIdx++]='2';
    garTsb0[0x0][uIdx++]='6';
    garTsb0[0x0][uIdx++]='3';
    garTsb0[0x0][uIdx++]='X';
    garTsb0[0x0][uIdx++]='T';

    // 0x20    1.0
    uIdx=0x20;
    garTsb0[0x0][uIdx++]='1';
    garTsb0[0x0][uIdx++]='.';
    garTsb0[0x0][uIdx++]='0';

    // 0x30    Aging
    uIdx=0x30;
    garTsb0[0x0][uIdx++]='A';
    garTsb0[0x0][uIdx++]='g';
    garTsb0[0x0][uIdx++]='i';
    garTsb0[0x0][uIdx++]='n';
    garTsb0[0x0][uIdx++]='g';

    // 0xC0    Fatal Error
    uIdx=0xC0;
    garTsb0[0x0][uIdx++]='F';
    garTsb0[0x0][uIdx++]='a';
    garTsb0[0x0][uIdx++]='t';
    garTsb0[0x0][uIdx++]='a';
    garTsb0[0x0][uIdx++]='l';
    garTsb0[0x0][uIdx++]=' ';
    garTsb0[0x0][uIdx++]='E';
    garTsb0[0x0][uIdx++]='r';
    garTsb0[0x0][uIdx++]='r';
    garTsb0[0x0][uIdx++]='o';
    garTsb0[0x0][uIdx++]='r';

    // 0x100  Cluster
    uIdx=0x100;
    garTsb0[0x0][uIdx++]='C';
    garTsb0[0x0][uIdx++]='l';
    garTsb0[0x0][uIdx++]='u';
    garTsb0[0x0][uIdx++]='s';
    garTsb0[0x0][uIdx++]='t';
    garTsb0[0x0][uIdx++]='e';
    garTsb0[0x0][uIdx++]='r';

    // 0x180  Nand Flash
    uIdx=0x180;
    garTsb0[0x0][uIdx++]='N';
    garTsb0[0x0][uIdx++]='a';
    garTsb0[0x0][uIdx++]='n';
    garTsb0[0x0][uIdx++]='d';
    garTsb0[0x0][uIdx++]=' ';
    garTsb0[0x0][uIdx++]='F';
    garTsb0[0x0][uIdx++]='l';
    garTsb0[0x0][uIdx++]='a';
    garTsb0[0x0][uIdx++]='s';
    garTsb0[0x0][uIdx++]='h';

    // 0x120  Total Cluster Count  //20181225_Chief
    g32arTsb0[0x0][0x120/4]=g16TotalFBlock;

    // 0x124  Current Cluster Count
    g32arTsb0[0x0][0x124/4]=g16TotalFBlock-g16OrgBadBlockCnt-g16LaterBadBlockCnt-gsBadInfo.u16TotalNewBadCnt;

    // 0x128  User Cluster Count
    g32arTsb0[0x0][0x128/4]=g16TotalHBlock;

    // 0x12C  Cluster Size in MB
    g32arTsb0[0x0][0x12C/4]=(g4kNumPerPage*gTotalIntlvChNum*g16PagePerBlock1)>>8;

    // 0x130  Erase Count Entry Size in Byte
    g32arTsb0[0x0][0x130/4]=(((g16TotalFBlock<<1)+511)>>9)<<9;

    // 0x140  Valid Count Entry Size in Byte
    g32arTsb0[0x0][0x140/4]=(((g16TotalFBlock<<2)+511)>>9)<<9;

    // 0x1A0  CH Count
    g32arTsb0[0x0][0x1A0/4]=gTotalChNum;

    // 0x1A4  CE Count
    g32arTsb0[0x0][0x1A4/4]=gIntlvWay;

    // 0x1A8  LUN Count
    g32arTsb0[0x0][0x1A8/4]=1;

    // 0x1AC  Die Count
    g32arTsb0[0x0][0x1AC/4]=gTotalChNum*gIntlvWay;

    // 0x1B0  Plane of Write
    g32arTsb0[0x0][0x1B0/4]=2;

    // 0x1B4  Plane of Read
    g32arTsb0[0x0][0x1B4/4]=2;

    // 0x1B8  LAA Size in Byte
    g32arTsb0[0x0][0x1B8/4]=cSctrPer4k*512;

    // 0x1C0  Page Size in Byte
    g32arTsb0[0x0][0x1C0/4]=gSectorPerPlaneH*512;

    // 0x1C4  Page Count in Block
    g32arTsb0[0x0][0x1C4/4]=g16PagePerBlock1;
}    /* VscReadFWConfig */

void VscReadFWVersion()
{
    LWORD FWOption=rmNvmeCdw13;

    copyCcmVal((UCBYTE *)&garTsb0[0][0], (BYTE *)&cbRevision1, 8);

    if(FWOption==1)
    {
        garTsb0[0][0x07]=SUBVERSION;    // Sub Version
    }
}

BYTE loadIspPageCore0_VU(WORD u16Page, BYTE uType)    // same as loadIspPageCore0()
{
    TASKENTRY usTskEntry;
    LWORD u32HeadPtr=gsTskFifoCtrl.u32HeadPtr;

    usTskEntry.uTskTyp=cTskLoadIspPage;
    usTskEntry.u16TskSBufPtr=u16Page;
    usTskEntry.uTskOpt=uType;
    insertTaskFifo(usTskEntry);

    while(gsTskFifoCtrl.u32HeadPtr!=gsTskFifoCtrl.u32TailPtr)
        ;

    return gsTskFifoCtrl.uarTskFifo[u32HeadPtr].uTskPgOfst;
}

void VscReadBootVersion()
{
    BYTE uarExtFwVersion1[8];
    BYTE uarExtFwVersion2[8];
    BYTE uSlot2PageOffset;

    // Load External FW Version first
    loadIspPageCore0_VU(0x0B, cSysBlockIsp);
    copyCcmVal((BYTE *)uarExtFwVersion1, (BYTE *)&garTsb0[31][0x190], 8);
    uSlot2PageOffset=(cTotalIspCodeSize/gSectorPerPlaneH)+0x0B;
    loadIspPageCore0_VU(uSlot2PageOffset, cSysBlockIsp);
    copyCcmVal((BYTE *)uarExtFwVersion2, (BYTE *)&garTsb0[31][0x190], 8);

    // Init TSB0
    bopClrRam((LWORD)c32Tsb0SAddr, g32HostXfrCnt*512, 0x00000000, cBopWait|cClrTsb);
    copyCcmVal((BYTE *)&garTsb0[0][0x10], (BYTE *)uarExtFwVersion1, 8);
    copyCcmVal((BYTE *)&garTsb0[0][0x18], (BYTE *)uarExtFwVersion2, 8);
}    /* VscReadBootVersion */

void VscReadFWHistory()
{
    if(gsWproInfo.u16arWproIdxPagePtr[cWproWriteUNC]!=c16BitFF)
    {
        readWproPageCore0(cWproWriteUNC, c16Tsb0SIdx, 0);
        copyCcmVal((BYTE *)&garTsb0[0][0x0], (BYTE *)&garTsb0[16][0x0], 8192);
    }
    else
    {
        bopClrRam(c32Tsb0SAddr, gSectorPerPlaneH*512, 0, cClrTsb|cBopWait);
    }
}    /* VscReadBootVersion */

WORD VscReadEEPROM()
{
    BYTE u16Status;

    if(!loadInfoPage(0, gSectorPerPlaneH, c16WriteSIdx, 0, cSysBlockMPInfo, cBit1))
    {
        bopCopyRam((LWORD)&garTsb0[0][0x0], (LWORD)&garTsb0[16][0x0], 8192, cCopyTsb2Tsb|cBopWait);    // Liteon EEPROM is MPInfo Page0 last 8kb
        u16Status=cStatusSuccess;
    }
    else
    {
        u16Status=cStatusInvalidField;
    }

    return u16Status;
}

void VscReadNANDFluchCnt()
{}

void VscReadEraseCnt(BYTE Header_Flag)
{
    if(Header_Flag)
    {
        insertVendorTask(cVendorCore1LiteOnVU_ReadGlobEraseCnt);
    }
    else
    {
        insertVendorTask(cVendorCore1ReadGlobEraseCnt);
    }
}

void avgVpCnt()
{
    WORD u16Fblk, u16TlcIdx=0, u16SlcIdx=0;
    LWORD u32MaxTlcVpCnt=0, u32MaxSlcVpCnt=0;
    LWORD u32MinTlcVpCnt=0xFFFF, u32MinSlcVpCnt=0xFFFF;
    LWORD u32SumTlcVpCnt=0, u32SumSlcVpCnt=0;

    for(u16Fblk=g16FirstFBlock; u16Fblk<g16TotalFBlock; u16Fblk++)
    {
        if(((mGetCacheBlkVpCnt(u16Fblk))!=0)&&(mGetCacheBlkVpCnt(u16Fblk)!=0xFFFF))
        {
            if(mChkMlcMoBit(u16Fblk))
            {
                // TLC
                u16TlcIdx++;
                u32SumTlcVpCnt+=mGetCacheBlkVpCnt(u16Fblk);

                if(mGetCacheBlkVpCnt(u16Fblk)>u32MaxTlcVpCnt)
                {
                    u32MaxTlcVpCnt=mGetCacheBlkVpCnt(u16Fblk);
                }

                if(mGetCacheBlkVpCnt(u16Fblk)<u32MinTlcVpCnt)
                {
                    u32MinTlcVpCnt=mGetCacheBlkVpCnt(u16Fblk);
                }
            }
            else
            {
                // SLC
                u16SlcIdx++;
                u32SumSlcVpCnt+=mGetCacheBlkVpCnt(u16Fblk);

                if(mGetCacheBlkVpCnt(u16Fblk)>u32MaxSlcVpCnt)
                {
                    u32MaxSlcVpCnt=mGetCacheBlkVpCnt(u16Fblk);
                }

                if(mGetCacheBlkVpCnt(u16Fblk)<u32MinSlcVpCnt)
                {
                    u32MinSlcVpCnt=mGetCacheBlkVpCnt(u16Fblk);
                }
            }
        }
    }

    if(u32MinTlcVpCnt==0xFFFF)
    {
        u32MinTlcVpCnt=0;
    }

    if(u32MinSlcVpCnt==0xFFFF)
    {
        u32MinSlcVpCnt=0;
    }

    // TLC
    g32arTsb0[0][0x4]=u32MaxTlcVpCnt;
    g32arTsb0[0][0x5]=u32SumTlcVpCnt/u16TlcIdx;
    g32arTsb0[0][0x6]=u32MinTlcVpCnt;
    g32arTsb0[0][0x7]=gsGcInfo.u32TotalTlcVpc;

    // SLC
    g32arTsb0[0][0x8]=u32MaxSlcVpCnt;
    g32arTsb0[0][0x9]=u32SumSlcVpCnt/u16SlcIdx;
    g32arTsb0[0][0xA]=u32MinSlcVpCnt;
    g32arTsb0[0][0xB]=gsGcInfo.u32TotalSlcVpc;
    g32arTsb0[0][0xC]=u32SumTlcVpCnt;
    g32arTsb0[0][0xD]=u32SumSlcVpCnt;
    g32arTsb0[0][0xE]=u16TlcIdx;
    g32arTsb0[0][0xF]=u16SlcIdx;
    NLOG(cLogAdmin,
         LITEONVU_C,
         4,
         " VscChkVpc() gGcTotalSlcVpc=0x%08X, SumSlcVp=0x%08X",
         (WORD)(gsGcInfo.u32TotalSlcVpc>>16),
         (WORD)(gsGcInfo.u32TotalSlcVpc),
         (WORD)(u32SumSlcVpCnt>>16),
         (WORD)(u32SumSlcVpCnt));

    NLOG(cLogAdmin,
         LITEONVU_C,
         4,
         " VscChkVpc() gGcTotalTlcVpc=0x%08X, SumTlcVp=0x%08X",
         (WORD)(gsGcInfo.u32TotalTlcVpc>>16),
         (WORD)(gsGcInfo.u32TotalTlcVpc),
         (WORD)(u32SumTlcVpCnt>>16),
         (WORD)(u32SumTlcVpCnt));
}    /* avgVpCnt */

void VUchkVpCnt()
{
    WORD u16Hblock, u16H4k, u16Fblock;
    UCLWORD *u32pTsb0=(UCLWORD *)garTsb0[0];
    UCLWORD *u32pH2f=(UCLWORD *)garTsb0[c16Tsb0SIdx+g16H2fTabSctrSize];

    // KSPRINFO usBlkSprInfo;

    bopClrRam(c32Tsb0SAddr, c32Tsb0SizeByte, 0x00000000, cClrTsb|cBopWait);

#if _EN_VPC_SWAP
    g32arCacheBlkVpCnt=(volatile LWORD *)(cCacheBlkVpCntFlushStrAddr);
#if (!_PRJ_BOOT||_ICE_LOAD_ALL||(!_ENABLE_RAID))
    readWproPageCore0(cWproCacheBlkVpCnt, cCacheBlkVpCntFlushStrIdx, 0);
#else
    popVPCfromRaidCore0(cCacheBlkVpCntFlushStrIdx);
#endif
#endif

    for(u16Hblock=0; u16Hblock<g16TotalHBlock; u16Hblock++)
    {
        if(g16arH2fTabPtr[u16Hblock]!=c16H2FTabInitValue)
        {
            swapH2fTable(u16Hblock, c16Tsb0SIdx+g16H2fTabSctrSize, cWaitReadDone);

            rmWaitSysCmdFifoBz;

            // for reset H2f table no wait.
            while(rmChkHdmaBz)
                ;

            for(u16H4k=0; u16H4k<g16PagePerH2fTab; u16H4k++)
            {
                u16Fblock=mGetSrcFBlkAddr(u32pH2f[u16H4k]);

                if(u16Fblock!=c16FBlockInitValue)
                {
                    if((u16Fblock>=g16TotalFBlock)||(u16Fblock<g16FirstFBlock))
                    {
                        NLOG(cLogAdmin, LITEONVU_C, 1, " chkVpCnt0() u16Fblock=0x%04X", u16Fblock);
                    }

                    u32pTsb0[u16Fblock]++;

                    if(mChkMlcMoBit(u16Fblock))
                    {
                        if(u32pTsb0[u16Fblock]>g32VpcPerTlcBlk)
                        {
                            // debugRdlinkDeadLock();
                            NLOG(cLogAdmin,
                                 LITEONVU_C,
                                 3,
                                 " chkVpCnt1() u16Fblock=0x%04X, VPC=0x%08X",
                                 u16Fblock,
                                 u32pTsb0[u16Fblock]>>16,
                                 u32pTsb0[u16Fblock]);
                        }
                    }
                    else
                    {
                        if(u32pTsb0[u16Fblock]>g32VpcPerSlcBlk)
                        {
                            // debugRdlinkDeadLock();
                            NLOG(cLogAdmin,
                                 LITEONVU_C,
                                 3,
                                 " chkVpCnt2() u16Fblock=0x%04X, VPC=0x%08X",
                                 u16Fblock,
                                 u32pTsb0[u16Fblock]>>16,
                                 u32pTsb0[u16Fblock]);
                        }
                    }
                }
            }
        }
    }

    for(u16Fblock=g16FirstFBlock; u16Fblock<g16TotalFBlock; u16Fblock++)
    {
        if(u32pTsb0[u16Fblock]!=mGetCacheBlkVpCnt(u16Fblock))
        {
            NLOG(cLogAdmin,
                 LITEONVU_C,
                 6,
                 " chkVpCnt2() TLCBlk=0x%04X, u16Fblock=0x%04X, RealVPC=0x%08X, tableVPC=0x%08X",
                 mChkMlcMoBit(u16Fblock)?1:0,
                 u16Fblock,
                 u32pTsb0[u16Fblock]>>16,
                 u32pTsb0[u16Fblock],
                 mGetCacheBlkVpCnt(u16Fblock)>>16,
                 mGetCacheBlkVpCnt(u16Fblock));
        }
    }
}    /* chkVpCnt */

void VscReadValidCnt(BYTE Header_Flag)
{
    WORD u16Cnt;
    // LWORD u32arBlkVpCnt[c16MaxBlockNum];
    UCLWORD *ucPtr=(UCLWORD *)garTsb0;

    if(Header_Flag)
    {
        bopClrRam((LWORD)c32Tsb0SAddr, 26*512, 0x00000000, cBopWait|cClrTsb);
        // copyCcmVal((UCBYTE *)&garTsb0[0][0], (UCBYTE *)g16arGlobEraseCnt, (c16MaxBlockNum*2));
        // Table tag
        garTsb0[0][0x0]='V';
        garTsb0[0][0x1]='C';
        garTsb0[0][0x2]='T';
        garTsb0[0][0x3]='B';
        // Type
        garTsb0[0][0x4]=0xFF;
        garTsb0[0][0x5]=0xFF;
        // Version
        garTsb0[0][0x6]=0xFF;
        garTsb0[0][0x7]=0xFF;
        // Length
        g32arTsb0[0][0x2]=g16TotalFBlock*4;
        // EC Information
        avgVpCnt();
    }
    else
    {
        bopClrRam((LWORD)c32Tsb0SAddr, 26*512, 0x00000000, cBopWait|cClrTsb);
        copyCcmVal((UCBYTE *)&garTsb0[0][0], (UCBYTE *)g32arCacheBlkVpCnt, (g16TotalFBlock*4));

        for(u16Cnt=0; u16Cnt<=c16MaxBlockNum; u16Cnt++)
        {
            *ucPtr=*ucPtr&~(c32Bit31|c32Bit30);
            ucPtr++;
            // u32arBlkVpCnt[u16Cnt]=mGetCacheBlkVpCnt(g32arCacheBlkVpCnt[u16Cnt]);
        }
    }

    if(Header_Flag==2)
    {
        VUchkVpCnt();
    }
}    /* VscReadValidCnt */

void VscReadGlist(WORD Header_Flag)
{
    WORD flag=Header_Flag;
    LWORD payloadlen;

    payloadlen=gsBadInfo.u16NewBadInBufPtr*0x10;
    readWproPageCore0(cWproBadInfo, c16Tsb0SIdx, 0);

    if(flag==0)
    {
        // payload only
        if(!gsBadInfo.u16TotalNewBadCnt)
        {
            garTsb0[0][0x0]='N';
            garTsb0[0][0x1]='O';
            garTsb0[0][0x2]='_';
            garTsb0[0][0x3]='N';
            garTsb0[0][0x4]='E';
            garTsb0[0][0x5]='W';
            garTsb0[0][0x6]='_';
            garTsb0[0][0x7]='B';
            garTsb0[0][0x8]='A';
            garTsb0[0][0x9]='D';
        }
        else
        {}
    }
    else if(flag==1)
    {
        // head only

        garTsb0[0][0]='G';
        garTsb0[0][1]='L';
        garTsb0[0][2]='T';
        garTsb0[0][3]='B';

        garTsb0[0][4]=0xFF;    // type
        garTsb0[0][5]=0xFF;
        garTsb0[0][6]=0xFF;    // Version
        garTsb0[0][7]=0xFF;

        garTsb0[0][8]=0xFF;
        garTsb0[0][9]=0xFF;
        garTsb0[0][0x0A]=payloadlen>>8;
        garTsb0[0][0x0B]=payloadlen;

        garTsb0[0][0x10]=gsBadInfo.u16EraseFailFblkCnt>>8;    // erase
        garTsb0[0][0x11]=gsBadInfo.u16EraseFailFblkCnt;
        garTsb0[0][0x12]=gsBadInfo.u16ProgFailFblkCnt>>8;    // prog
        garTsb0[0][0x13]=gsBadInfo.u16ProgFailFblkCnt;
        garTsb0[0][0x14]=(gsBadInfo.u16TotalNewBadCnt-gsBadInfo.u16ProgFailFblkCnt-gsBadInfo.u16EraseFailFblkCnt)>>8;    // ECC
        garTsb0[0][0x15]=gsBadInfo.u16TotalNewBadCnt-gsBadInfo.u16ProgFailFblkCnt-gsBadInfo.u16EraseFailFblkCnt;

        // WORD u16ProgFailFblkCnt;
        // WORD u16EraseFailFblkCnt;

        garTsb0[0][0x16]=gsBadInfo.u16TotalNewBadCnt>>8;
        garTsb0[0][0x17]=gsBadInfo.u16TotalNewBadCnt;
        garTsb0[0][0x18]=gsBadInfo.u16NewBadInBufPtr>>8;
        garTsb0[0][0x19]=gsBadInfo.u16NewBadInBufPtr;
    }
    else if(flag==2)    // for Vendor Specfic Command for Debug Log
    {
        WORD loopcnt;
        BYTE swapdata;
        garTsb0[0][0x6]=(gsBadInfo.u16TotalNewBadCnt-gsBadInfo.u16ProgFailFblkCnt-gsBadInfo.u16EraseFailFblkCnt);    // ECCfail cnt
        garTsb0[0][0x7]=(gsBadInfo.u16TotalNewBadCnt-gsBadInfo.u16ProgFailFblkCnt-gsBadInfo.u16EraseFailFblkCnt)>>8;

        garTsb0[0][0x0A]=payloadlen>>8;
        garTsb0[0][0x0B]=payloadlen;

        for(loopcnt=0; loopcnt<gsBadInfo.u16TotalNewBadCnt; loopcnt++)
        {
            if(garTsb0[loopcnt+1][0x7]==0x80)
            {
                // swap data for AET
                swapdata=garTsb0[loopcnt+1][0x6];
                garTsb0[loopcnt+1][0x6]=garTsb0[loopcnt+1][0x5];
                garTsb0[loopcnt+1][0x5]=garTsb0[loopcnt+1][0x4];
                garTsb0[loopcnt+1][0x4]=garTsb0[loopcnt+1][0x3];
                garTsb0[loopcnt+1][0x3]=swapdata;
            }
        }
    }
}    /* VscReadGlist */

void VscReadECC()
{
    garTsb0[0][0]='E';    // 2019_0513_samke_add_FWtest
    garTsb0[0][1]='C';
    garTsb0[0][2]='C';
    garTsb0[0][3]='B';

    // 2019_0709_samke_add_forSpec
    garTsb0[0][0x10]=gsSmart.usCnt.u64MediaDataIntegrityErr>>24;
    garTsb0[0][0x11]=gsSmart.usCnt.u64MediaDataIntegrityErr>>16;
    garTsb0[0][0x12]=gsSmart.usCnt.u64MediaDataIntegrityErr>>8;
    garTsb0[0][0x13]=gsSmart.usCnt.u64MediaDataIntegrityErr;
}

// 20190503_Jesse_01, Add for Vendor read SCP Counter
void VscReadScpCnt()
{
    bopClrRam((LWORD)c32Tsb0SAddr, g32HostXfrCnt*512, 0x00000000, cBopWait|cClrTsb);

    garTsb0[0][0]='S';
    garTsb0[0][1]='C';
    garTsb0[0][2]='P';
    garTsb0[0][3]=' ';
    garTsb0[0][4]='C';
    garTsb0[0][5]='N';
    garTsb0[0][6]='T';

    g32arTsb0[0][0x4]=gsFtlDbg.u32PlpScpGpioInitCnt;
    g32arTsb0[0][0x5]=gsFtlDbg.u32PlpScpCompleteCnt;
}

WORD VscGetPciePara()
{
    BYTE uRt;
    WORD u16Data0, u16Data1, u16V00, u16V12, u16Vt;
    LWORD u32Vcp2;
    LWORD u32RtcStartTime;
    BYTE u16Status;

    // Init VCCO
    u16Data0=crRead(cAddrAphyLane1|0x2F)&(~cBit6);
    crWrite((cAddrAphyLane1|0x2F), u16Data0);

    u16Data0=crRead(cAddrAphyLane1|0x23)|cBit5;
    crWrite((cAddrAphyLane1|0x23), u16Data0);

    u16Data0=crRead(cAddrAphyLane1|0x23)&(~cBit4);
    crWrite((cAddrAphyLane1|0x23), u16Data0);

    u16Data0=crRead(cAddrAphyLane1|0x22)&0xF0;
    crWrite((cAddrAphyLane1|0x22), u16Data0);

    u16Data0=crRead(cAddrAphyLane1|0x22)|cBit4;
    crWrite((cAddrAphyLane1|0x22), u16Data0);

    u16Data0=crRead(cAddrAphyLane1|0x06)|cBit0;
    crWrite((cAddrAphyLane1|0x06), u16Data0);

    u16Data0=crRead(cAddrAphyLane1|0x06)|cBit1;
    crWrite((cAddrAphyLane1|0x06), u16Data0);

    // wait 8ms
    u32RtcStartTime=getRtcCurrent32k();

    while(chkRtc32kProcTime(u32RtcStartTime)<262) // wait ~8ms
        ;

    // Get VCCO
    u16Data0=(crRead(cAddrAphyLane1|0x2F)&0xF0)|0x0F;
    crWrite((cAddrAphyLane1|0x2F), u16Data0);
    u32RtcStartTime=getRtcCurrent32k();

    while(chkRtc32kProcTime(u32RtcStartTime)<262) // wait ~8ms
        ;

    u16Data1=crRead(cAddrAphyLane1|0x36);
    u16V12=(crRead(cAddrAphyLane1|0x37)<<8)|u16Data1;

    u16Data0=(crRead(cAddrAphyLane1|0x2F)&0xF0)|0x0E;
    crWrite((cAddrAphyLane1|0x2F), u16Data0);
    u32RtcStartTime=getRtcCurrent32k();

    while(chkRtc32kProcTime(u32RtcStartTime)<262) // wait ~8ms
        ;

    u16Data1=crRead(cAddrAphyLane1|0x36);
    u16V00=(crRead(cAddrAphyLane1|0x37)<<8)|u16Data1;

    u16Data0=(crRead(cAddrAphyLane1|0x2F)&0xF0)|0x04;
    crWrite((cAddrAphyLane1|0x2F), u16Data0);
    u32RtcStartTime=getRtcCurrent32k();

    while(chkRtc32kProcTime(u32RtcStartTime)<262) // wait ~8ms
        ;

    u16Data1=crRead(cAddrAphyLane1|0x36);
    u16Vt=(crRead(cAddrAphyLane1|0x37)<<8)|u16Data1;

    u32Vcp2=(LWORD)((u16Vt-u16V00)*1000)/(LWORD)(u16V12-u16V00);    // the unit x1000, ideally the value should between the 400 to 600.

    // Get RT (impedence)
    uRt=crRead(cAddrAphyLane1|0x0A)&0x3F;    // RT range is [5:0]

    if(!loadInfoPage(0, gSectorPerPlaneH, c16WriteSIdx, 0, cSysBlockMPInfo, cBit1))
    {
        bopCopyRam((LWORD)&garTsb0[0][0x0], (LWORD)&garTsb0[16][0x0], 8192, cCopyTsb2Tsb|cBopWait);    // Liteon EEPROM is MPInfo Page0 last 8kb
        g32arTsb0[0][0xB4/4]=u32Vcp2;    // ideally the value should between the 400 to 600, means 0.4 to 0.6 .
        g32arTsb0[0][0xA4/4]=uRt;
        insertVendorTask(cVendorCore1WriteMPInfo);
        u16Status=cStatusSuccess;
    }
    else
    {
        u16Status=cStatusInvalidField;
    }

    return u16Status;
}    /* VscGetPciePara */

void VscCTQcmd()
{
    BYTE uICTemp;
    WORD u16CorePowerIdx, u16BadBlockCnt;
    LWORD u32TxImpedance, u32RxImpedance, u32SpeedDLL;
    WORD u16SLCTr, u16SLCTpro, u16SLCTer;
    WORD u16TLCTr, u16TLCTpro, u16TLCTer;

    loadInfoPage(0, gSectorPerPlaneH, c16WriteSIdx, 0, cSysBlockMPInfo, cBit1);
    bopCopyRam((LWORD)&garTsb0[0][0x0], (LWORD)&garTsb0[16][0x0], 8192, cCopyTsb2Tsb|cBopWait);    // Liteon EEPROM is MPInfo Page0 last 8kb

    u16CorePowerIdx=g16arTsb0[0][0x3A];    // 0x74 (Byte)
    u32TxImpedance=g32arTsb0[0][0x29];    // 0xA4 (Byte)
    u32RxImpedance=g32arTsb0[0][0x29];    // 0xA4(Byte)
    u32SpeedDLL=g32arTsb0[0][0x2D];    // 0xB4(Byte)
    u16SLCTr=g16arTsb0[7][0xB1];    // 0xF62(Byte)
    u16SLCTpro=g16arTsb0[7][0xB0];    // 0xF60(Byte)
    u16SLCTer=g16arTsb0[7][0xB2];    // 0xF64(Byte)
    u16TLCTr=g16arTsb0[7][0x99];    // 0xF32(Byte)
    u16TLCTpro=g16arTsb0[7][0x98];    // 0xF30(Byte)
    u16TLCTer=g16arTsb0[7][0x9A];    // 0xF34(Byte)
    u16BadBlockCnt=g16arTsb0[0][0x31];    // 0x62(Byte)
    uICTemp=garTsb0[0][0x1C];    // 0x1C(Byte)

    bopClrRam((LWORD)g32arTsb0[0], 0x2000, 0x00000000, cBopWait|cClrTsb);

    garTsb0[0][0x0]='C';
    garTsb0[0][0x1]='T';
    garTsb0[0][0x2]='Q';

    g32arTsb0[0][0x1]=u16CorePowerIdx;
    g32arTsb0[0][0x2]=u32TxImpedance;
    g32arTsb0[0][0x3]=u32RxImpedance;
    g32arTsb0[0][0x4]=u32SpeedDLL;
    g32arTsb0[0][0x5]=u16SLCTr;
    g32arTsb0[0][0x6]=u16SLCTpro;
    g32arTsb0[0][0x7]=u16SLCTer;
    g32arTsb0[0][0x8]=u16TLCTr;
    g32arTsb0[0][0x9]=u16TLCTpro;
    g32arTsb0[0][0xA]=u16TLCTer;
    g32arTsb0[0][0xB]=u16BadBlockCnt;
    g32arTsb0[0][0xC]=uICTemp;
}    /* VscCTQcmd */

void nvmeLiteonVendorNonData()
{
    BYTE uFunctionCode, uMode, ucorepwr_param_1, ucorepwr_param_2;
    WORD u16StatusCode=cStatusSuccess;

    if(rmNvmeCdw15!=0x4356544C)    // check signature "LTVC"
    {
        u16StatusCode=cStatusInvalidField;
        manualCompletion(u16StatusCode, 0x0, cNoRwCmd, 0x0);
        return;
    }

    uFunctionCode=rmNVmeLiteonVscFunctionCode;
    uMode=rmNVmeLiteonVscModeCode;
    ucorepwr_param_1=rNvme1[rcFwRqCmd13];
    ucorepwr_param_2=rNvme1[rcFwRqCmd14];

    if(uFunctionCode==cVscFunction_PurageOperation)    // 0x13
    {
        switch(uMode)
        {
            case cVscMode_MP_PREFORMAT:
                VscMPPreformat();
                break;

            case cVscMode_FOB_PREFORMAT:
                VscFOBPreformat();
                break;

            case cVscMode_CorePower_Learning:
                VscCorePowerLearning(ucorepwr_param_1, ucorepwr_param_2);
                break;

            default:
                u16StatusCode=cStatusInvalidOpCode;
                break;
        }    /* switch */
    }
    else if(uFunctionCode==cVscFunction_InternalTableOperation)    // 0x15
    {
        switch(uMode)
        {
            case cVscMode_CLEAR_GLIST:
                VscClearGlist();
                break;

            default:
                u16StatusCode=cStatusInvalidOpCode;
                break;
        }
    }
    else if(uFunctionCode==cVscFunction_SMIVU)    // 0x80
    {
        switch(uMode)
        {
            case cVscMode_GetPciePara:
                u16StatusCode=VscGetPciePara();
                break;

            default:
                u16StatusCode=cStatusInvalidOpCode;
                break;
        }
    }
    else
    {
        u16StatusCode=cStatusInvalidOpCode;
    }

    manualCompletion(u16StatusCode, 0x00, cNoRwCmd, 0);

    // Pop Next Cmd, manual won't use SetDesc()fnction need to POP NEX
    rmPopNextCmd;
}    /* nvmeLiteonVendorNonData */

void nvmeLiteonVendorDataOut()
{
    BYTE uStopBK;
    BYTE uFunctionCode, uMode;
    WORD u16StatusCode=cStatusSuccess;

    uFunctionCode=rmNVmeLiteonVscFunctionCode;
    uMode=rmNVmeLiteonVscModeCode;

    g32HostXfrCnt=rmNvmeVenderLength;    // DWord unit
    g32HostXfrCnt=(g32HostXfrCnt+127)>>7;    // change to sector base, (g32HostXfrCnt<<2)>>9

    if((rmNvmeCdw15!=0x4356544C)||(!g32HostXfrCnt))    // check signature "LTVC"
    {
        u16StatusCode=cStatusInvalidField;
        manualCompletion(u16StatusCode, 0x0, cNoRwCmd, 0x0);
        return;
    }

    disAllChStop((BYTE *)&uStopBK);
    trigNonRWCmd(cTsb0StartBufIdx, g32HostXfrCnt, cTsb0, cNvmeWrite, cManualCq);

    if(uFunctionCode==cVscFunction_EEPROMOperation)    // 0x12
    {
        switch(uMode)
        {
            case cVscMode_EEPROM_WRITE:
                u16StatusCode=VscWriteEEPROM();
                break;

            default:
                u16StatusCode=cStatusInvalidOpCode;
                break;
        }
    }
    else
    {
        u16StatusCode=cStatusInvalidOpCode;
    }

    enAllChStop(uStopBK);
    manualCompletion(u16StatusCode, 0x00, cNoRwCmd, 0);
}    /* nvmeVendorDataOut */

void nvmeLiteonVendorDataIn()
{
    BYTE uFunctionCode, uMode, uHeader_Flag, uLog_Index;
    WORD u16StatusCode=cStatusSuccess;

    NLOG(cLogAdmin, LITEONVU_C, 0, " nvmeLiteonVendorDataIn() ");

    g32HostXfrCnt=rmNvmeVenderLength;    // DWord unit
    g32HostXfrCnt=(g32HostXfrCnt+127)>>7;    // change to sector base, (g32HostXfrCnt<<2)>>9

    if((rmNvmeCdw15!=0x4356544C)||(!g32HostXfrCnt))    // check signature "LTVC"
    {
        u16StatusCode=cStatusInvalidField;
        manualCompletion(u16StatusCode, 0x0, cNoRwCmd, 0x0);
        return;
    }

    bopClrRam((LWORD)c32Tsb0SAddr, g32HostXfrCnt*512, 0x00000000, cBopWait|cClrTsb);

    uFunctionCode=rmNVmeLiteonVscFunctionCode;
    uMode=rmNVmeLiteonVscModeCode;
    uHeader_Flag=rmNVmeLiteonVscHeaderFlag;

    if(uFunctionCode==cVscFunction_DeviceHWCheck)    // 0x10
    {
        switch(uMode)
        {
            case cVscMode_READ_FLASHID:
                VscReadFlashID();
                break;

            case cVscMode_PCIE_CONFIG:
                VscPCIEConfig();
                break;

            case cVscMode_READ_DID_VID:
                VscReadDIDVID();
                break;

#if 0
            case cVscMode_READ_DRAM_VENDOR:
                VscReadDramVendor();
                break;
#endif
            default:
                u16StatusCode=cStatusInvalidOpCode;
                break;
        }    /* switch */
    }
    else if(uFunctionCode==cVscFunction_DeviceFWCheck)    // 0x11
    {
        switch(uMode)
        {
            case cVscMode_READ_FW_CONFIG:
                VscReadFWConfig();
                break;

            case cVscMode_READ_FW_VERSION:
                VscReadFWVersion();
                break;

            case cVscMode_READ_BOOT_VERSION:
                VscReadBootVersion();
                break;

            case cVscMode_READ_FW_HISTORY:
                VscReadFWHistory();
                break;

            default:
                u16StatusCode=cStatusInvalidOpCode;
                break;
        }    /* switch */
    }
    else if(uFunctionCode==cVscFunction_EEPROMOperation)    // 0x12
    {
        switch(uMode)
        {
            case cVscMode_EEPROM_READ:
                u16StatusCode=VscReadEEPROM();
                break;

            default:
                u16StatusCode=cStatusInvalidOpCode;
                break;
        }
    }
    else if(uFunctionCode==cVscFunction_FTLRelatedOperation)    // 0x15
    {
        switch(uMode)
        {
            // case cVscMode_NAND_FLUSH_CNT:
            //    VscReadNANDFluchCnt();
            //    break;

            default:
                u16StatusCode=cStatusInvalidOpCode;
                break;
        }
    }
    else if(uFunctionCode==cVscFunction_InternalTableOperation)    // 0x16
    {
        switch(uMode)
        {
            case cVscMode_READ_ERASE_CNT:
                VscReadEraseCnt(uHeader_Flag);
                break;

            case cVscMode_READ_VAILD_CNT:
                VscReadValidCnt(uHeader_Flag);
                break;

            case cVscMode_READ_GLIST:
                VscReadGlist(uHeader_Flag);
                break;

            case cVscMode_READ_ECC:
                VscReadECC();
                break;

            // 20190503_Jesse_01, Add for Vendor read SCP Counter
            case cVscMode_READ_SCP_CNT:
                VscReadScpCnt();
                break;

            default:
                u16StatusCode=cStatusInvalidOpCode;
                break;
        }    /* switch */
    }
    // 20181225_Jesse_01, Add for "Vendor Specific Command for Debug Log" Rev_0.03
    else if(uFunctionCode==cVscFunction_DebugOperation)    // 0x17
    {
        if(uMode==0x11)
        {
            uHeader_Flag=(rNvme1[rcFwRqCmd12+2])&0x01;    // Command DWord 12 bit_16
            uLog_Index=(rNvme1[rcFwRqCmd12+3]);    // Command DWord 12 bit_24~31

            if(uHeader_Flag)    // bit_16="1" return Header only (every Log Index length)
            {
                g16arTsb0[0][0]=8;    // Return 8 sectors (1024 DWords)
                g16arTsb0[0][1]=1;    // Log Index 1
                g16arTsb0[0][2]=(gsBadInfo.u16NewBadInBufPtr*0x10)/512+1;    // Log Index 2
                g16arTsb0[0][3]=32;    // Log Index 3
                g16arTsb0[0][4]=1;    // Log Index 4
            }
            else if(!uLog_Index)    // uLog_Index="0" return debug message
            {
                readWproPageCore0(cWproEventLog, c16Tsb0SIdx, 0);
            }
            else if(uLog_Index==1)    // uLog_Index="1" return abnormal event table
            {
                readWproPageCore0(cWproEventLog, c16Tsb0SIdx, 0);    // 20190417_Oscar
                bopCopyRam((LWORD)&garTsb0[0][0], (LWORD)&garTsb0[14][0x180], 96, cCopyTsb2Tsb|cBopWait);
            }
            else if(uLog_Index==2)    // uLog_Index="2" return Glist
            {
                VscReadGlist(2);    // samke fix
            }

#if _EN_KEEP_RW_ON_ERROR
            else if(uLog_Index==3)    // uLog_Index="3" return While ID
            {
                readWproPageCore0(cWproErrorInfo, c16Tsb0SIdx, 0);
            }
#endif
            else if(uLog_Index==4)    // uLog_Index="4" return CTQ cmd    //20190625_Oscar
            {
                VscCTQcmd();
            }
        }
        else
        {
            u16StatusCode=cStatusInvalidOpCode;
        }
    }
    else
    {
        u16StatusCode=cStatusInvalidOpCode;
    }

    if(u16StatusCode!=cStatusSuccess)
    {
        manualCompletion(u16StatusCode, 0x0, cNoRwCmd, 0x0);
    }
    else if((uFunctionCode==cVscFunction_DebugOperation)&&(uMode==0x11))    // 20190802_Oscar_Add for "Vendor Specific Command for Debug
                                                                            // Log"
    {
        trigNonRWCmd(cTsb0StartBufIdx+rmNvmeCdw13, g32HostXfrCnt, cTsb0, cNvmeRead, cAutoCq);    // Command Dword 13 "Starting Block Index" (1
                                                                                                 // Block = 512 Bytes)
    }
    else
    {
        trigNonRWCmd(cTsb0StartBufIdx, g32HostXfrCnt, cTsb0, cNvmeRead, cAutoCq);
    }
}    /* nvmeLiteonVendorDataIn */

#if (!_ICE_LOAD_ALL)
#pragma default_function_attributes =
#endif







