







#ifndef _FUNCPTR_C_
#define _FUNCPTR_C_

#include "inc/ProType.h"

#if (_ICE_LOAD_ALL)

void(*const codeFuncPtr[]) (void)=
{
    bootFunc1,
    bootFunc2,
    servRwCmdQue,    // hdlRwTaskInPrdInfo,
    nvmeDeleteSubQueue,
    nvmeCreateSubQueue,
    nvmeDeleteCmplQueue,
    nvmeCreateCmplQueue,
    nvmeGetLogPage,
    nvmeIdentify,
    nvmeAbort,
    nvmeSetFeature,
    nvmeGetFeature,
    nvmeAsynEvent,
    nvmeFwCommit,
    nvmeFwImageDl,
    nvmeNamespaceManagement,
    nvmeNamespaceAttachment,
    nvmeFormat,
    nvmeVendorNonData,
    nvmeVendorDataOut,
    nvmeVendorDataIn,
    dummyFunc,    // nvmeVuCmdNonData,
    dummyFunc,    // nvmeVuCmdDataOut,
    dummyFunc,    // nvmeVuCmdDataIn,
    chkBgdClnBlkProc,
    nvmeFlush,
    nvmeWriteUncorrectable,
    nvmeCompare,
    nvmeWriteZero,
    nvmeDataSetManagemaent,
    nvmeDst,
    handleDst,
    handleAsyncEvent,
    saveRaidAllParity,
    restoRaidAllParity,
    dummyFunc,    // SecAPI_Trusted_Send,
    dummyFunc,    // SecAPI_Trusted_Receive,
    nvmeDirectiveSend,
    nvmeDirectiveRece,
    nvmeSanitize,
    sanitizeContinueOperation,
    nvmeLiteonVendorNonData,
    nvmeLiteonVendorDataOut,
    nvmeLiteonVendorDataIn,
    chkVpCnt,    // 20190618_Louis_01
};

void(*const codeFuncPtr2[]) (BYTE)=
{
    termFlashOperRw,
    dummyFunc2,    // processTrim
    resetCpu,
};

#else/* if (_ICE_LOAD_ALL) */

#pragma default_variable_attributes = @ ".CORE0_FUNCPTR"

#if _PRJ_MAIN
void(*const codeFuncPtr[]) (void)=
{
    0x00000000,    // 0
    0x00000000,    // 1
    0x00000000,    // 2
    0x00000000,    // 3
    0x00000000,    // 4
    0x00000000,    // 5
    0x00000000,    // 6
    0x00000000,    // 7
    0x00000000,    // 8
    0x00000000,    // 9
    0x00000000,    // 10
    0x00000000,    // 11
    0x00000000,    // 12
    0x00000000,    // 13
    0x00000000,    // 14
    0x00000000,    // 15
    0x00000000,    // 16
    0x00000000,    // 17
    0x00000000,    // 18
    0x00000000,    // 19
    0x00000000,    // 20
    0x00000000,    // 21
    0x00000000,    // 22
    0x00000000,    // 23
    0x00000000,    // 24
    0x00000000,    // 25
    0x00000000,    // 26
    0x00000000,    // 27
    0x00000000,    // 28
    0x00000000,    // 29
    0x00000000,    // 30
    0x00000000,    // 31
    0x00000000,    // 32
    0x00000000,    // 33
    0x00000000,    // 34
    0x00000000,    // 35
    0x00000000,    // 36
    0x00000000,    // 37
    0x00000000,    // 38
    0x00000000,    // 39
    0x00000000,    // 40
    0x00000000,    // 41
    0x00000000,    // 42
    0x00000000,    // 43
    0x00000000,    // 44
    0x00000000,    // 45
};

void(*const codeFuncPtr2[]) (BYTE)=
{
    0x00000000,    // 41
    0x00000000,    // 42
    0x00000000,    // 43
};

#endif/* if _PRJ_MAIN */

#if _PRJ_BOOT1
void(*const codeFuncPtr[]) (void)=
{
    bootFunc1,
    dummyFunc,    // bootFunc2,
    dummyFunc,    // servRwCmdQue,
    dummyFunc,    // nvmeDeleteSubQueue,
    dummyFunc,    // nvmeCreateSubQueue,
    dummyFunc,    // nvmeDeleteCmplQueue,
    dummyFunc,    // nvmeCreateCmplQueue,
    dummyFunc,    // nvmeGetLogPage,
    dummyFunc,    // nvmeIdentify,
    dummyFunc,    // nvmeAbort,
    dummyFunc,    // nvmeSetFeature,
    dummyFunc,    // nvmeGetFeature,
    dummyFunc,    // nvmeAsynEvent,
    dummyFunc,    // nvmeFwCommit,
    dummyFunc,    // nvmeFwImageDl,
    dummyFunc,    // nvmeNamespaceManagement,
    dummyFunc,    // nvmeNamespaceAttachment,
    dummyFunc,    // nvmeFormat,
    dummyFunc,    // nvmeVendorNonData
    dummyFunc,    // nvmeVendorDataOut
    dummyFunc,    // nvmeVendorDataIn
    dummyFunc,    // nvmeVuCmdNonData
    dummyFunc,    // nvmeVuCmdDataOut
    dummyFunc,    // nvmeVuCmdDataIn
    dummyFunc,    // chkBgdClnBlkProc
    dummyFunc,    // nvmeFlush,
    dummyFunc,    // nvmeWriteUncorrectable
    dummyFunc,    // nvmeCompare,
    dummyFunc,    // nvmeWriteZero,
    dummyFunc,    // nvmeDataSetManagemaent,
    dummyFunc,    // trustedSend,
    dummyFunc,    // trustedReceive,
    dummyFunc,    // nvmeDst,
    dummyFunc,    // handleDst,
    dummyFunc,    // handleAsyncEvent,
    dummyFunc,    // saveRaidAllParity,
    dummyFunc,    // restoRaidAllParity,
    dummyFunc,    // nvmeDirectiveSend,
    dummyFunc,    // nvmeDirectiveRece,
    dummyFunc,    // nvmeSanitize,
    dummyFunc,    // sanitizeContinueOperation,
    dummyFunc,    // nvmeVendorNonData;
    dummyFunc,    // nvmeVendorDataOut;
    dummyFunc,    // nvmeVendorDataIn;
    dummyFunc,    // chkVpCnt
};

void(*const codeFuncPtr2[]) (BYTE)=
{
    dummyFunc2,    // termFlashOperRw,
    dummyFunc2,    // processTrim,
    resetCpu,
};

#endif/* if _PRJ_BOOT1 */

#if _PRJ_BOOT2
void(*const codeFuncPtr[]) (void)=
{
    dummyFunc,    // bootFunc1,
    bootFunc2,
    dummyFunc,    // servRwCmdQue,
    dummyFunc,    // nvmeDeleteSubQueue,
    dummyFunc,    // nvmeCreateSubQueue,
    dummyFunc,    // nvmeDeleteCmplQueue,
    dummyFunc,    // nvmeCreateCmplQueue,
    dummyFunc,    // nvmeGetLogPage,
    dummyFunc,    // nvmeIdentify,
    dummyFunc,    // nvmeAbort,
    dummyFunc,    // nvmeSetFeature,
    dummyFunc,    // nvmeGetFeature,
    dummyFunc,    // nvmeAsynEvent,
    dummyFunc,    // nvmeFwCommit,
    dummyFunc,    // nvmeFwImageDl,
    dummyFunc,    // nvmeNamespaceManagement,
    dummyFunc,    // nvmeNamespaceAttachment,
    dummyFunc,    // nvmeFormat,
    dummyFunc,    // nvmeVendorNonData
    dummyFunc,    // nvmeVendorDataOut
    dummyFunc,    // nvmeVendorDataIn
    dummyFunc,    // nvmeVuCmdNonData
    dummyFunc,    // nvmeVuCmdDataOut
    dummyFunc,    // nvmeVuCmdDataIn
    dummyFunc,    // chkBgdClnBlkProc
    dummyFunc,    // nvmeFlush,
    dummyFunc,    // nvmeWriteUncorrectable
    dummyFunc,    // nvmeCompare,
    dummyFunc,    // nvmeWriteZero,
    dummyFunc,    // nvmeDataSetManagemaent,
    dummyFunc,    // trustedSend,
    dummyFunc,    // trustedReceive,
    dummyFunc,    // nvmeDst,
    dummyFunc,    // handleDst,
    dummyFunc,    // handleAsyncEvent,
    dummyFunc,    // saveRaidAllParity,
    dummyFunc,    // restoRaidAllParity,
    dummyFunc,    // nvmeDirectiveSend,
    dummyFunc,    // nvmeDirectiveRece,
    dummyFunc,    // nvmeSanitize,
    dummyFunc,    // sanitizeContinueOperation,
    dummyFunc,    // nvmeVendorNonData;
    dummyFunc,    // nvmeVendorDataOut;
    dummyFunc,    // nvmeVendorDataIn;
    dummyFunc,    // chkVpCnt
};

void(*const codeFuncPtr2[]) (BYTE)=
{
    dummyFunc2,    // termFlashOperRw,
    dummyFunc2,    // processTrim
    resetCpu,
};

#endif/* if _PRJ_BOOT2 */

#if _PRJ_ISP
void(*const codeFuncPtr[]) (void)=
{
    dummyFunc,    // bootFunc1,
    dummyFunc,    // bootFunc2,
    servRwCmdQue,
    dummyFunc,    // nvmeDeleteSubQueue,
    dummyFunc,    // nvmeCreateSubQueue,
    dummyFunc,    // nvmeDeleteCmplQueue,
    dummyFunc,    // nvmeCreateCmplQueue,
    dummyFunc,    // nvmeGetLogPage,
    dummyFunc,    // nvmeIdentify,
    dummyFunc,    // nvmeAbort,
    dummyFunc,    // nvmeSetFeature,
    dummyFunc,    // nvmeGetFeature,
    dummyFunc,    // nvmeAsynEvent,
    dummyFunc,    // nvmeFwCommit,
    dummyFunc,    // nvmeFwImageDl,
    dummyFunc,    // nvmeFormat,
    dummyFunc,    // nvmeNamespaceManagement,
    dummyFunc,    // nvmeNamespaceAttachment,
    dummyFunc,    // nvmeVendorNonData
    dummyFunc,    // nvmeVendorDataOut
    dummyFunc,    // nvmeVendorDataIn
    dummyFunc,    // nvmeVuCmdNonData
    dummyFunc,    // nvmeVuCmdDataOut
    dummyFunc,    // nvmeVuCmdDataIn
    chkBgdClnBlkProc,
    nvmeFlush,
    dummyFunc,    // nvmeWriteUncorrectable,
    dummyFunc,    // nvmeCompare,
    nvmeWriteZero,
    nvmeDataSetManagemaent,
    dummyFunc,    // nvmeDst
    dummyFunc,    // handleDst,
    dummyFunc,    // handleAsyncEvent,
    saveRaidAllParity,
    restoRaidAllParity,
#if _ENABLE_SECAPI
    SecAPI_Trusted_Send,
    SecAPI_Trusted_Receive,
#else
    dummyFunc,    // SecAPI_Trusted_Send,
    dummyFunc,    // SecAPI_Trusted_Receive,
#endif
    dummyFunc,    // nvmeDirectiveSend,
    dummyFunc,    // nvmeDirectiveRece,
    dummyFunc,    // nvmeSanitize,
    dummyFunc,    // sanitizeContinueOperation,
    dummyFunc,    // nvmeVendorNonData;
    dummyFunc,    // nvmeVendorDataOut;
    dummyFunc,    // nvmeVendorDataIn;
    chkVpCnt,    // chkVpCnt
};

void(*const codeFuncPtr2[]) (BYTE)=
{
    termFlashOperRw,
    processTrim,
    resetCpu,
};

#endif/* if _PRJ_ISP */

#if _PRJ_NVME
void(*const codeFuncPtr[]) (void)=
{
    dummyFunc,    // bootFunc1,
    dummyFunc,    // bootFunc2,
    dummyFunc,    // servRwCmdQue,
    nvmeDeleteSubQueue,
    nvmeCreateSubQueue,
    nvmeDeleteCmplQueue,
    nvmeCreateCmplQueue,
    nvmeGetLogPage,
    nvmeIdentify,
    nvmeAbort,
    nvmeSetFeature,
    nvmeGetFeature,
    nvmeAsynEvent,
    nvmeFwCommit,
    nvmeFwImageDl,
    nvmeFormat,
    nvmeNamespaceManagement,
    nvmeNamespaceAttachment,
    dummyFunc,    // nvmeVendorNonData,
    dummyFunc,    // nvmeVendorDataOut,
    dummyFunc,    // nvmeVendorDataIn,
    dummyFunc,    // nvmeVuCmdNonData,
    dummyFunc,    // nvmeVuCmdDataOut,
    dummyFunc,    // nvmeVuCmdDataIn,
    dummyFunc,    // chkBgdClnBlkProc
    dummyFunc,    // nvmeFlush,
    nvmeWriteUncorrectable,
    nvmeCompare,
    dummyFunc,    // nvmeWriteZero,
    dummyFunc,    // nvmeDataSetManagemaent,
    nvmeDst,
    handleDst,
    handleAsyncEvent,
    dummyFunc,    // saveRaidAllParity,
    dummyFunc,    // restoRaidAllParity,
    dummyFunc,    // SecAPI_Trusted_Send,
    dummyFunc,    // SecAPI_Trusted_Receive,
    nvmeDirectiveSend,
    nvmeDirectiveRece,
    nvmeSanitize,
    sanitizeContinueOperation,
    dummyFunc,    // nvmeVendorNonData;
    dummyFunc,    // nvmeVendorDataOut;
    dummyFunc,    // nvmeVendorDataIn;
    chkVpCnt,    // chkVpCnt
};

void(*const codeFuncPtr2[]) (BYTE)=
{
    dummyFunc2,    // termFlashOperRw,
    dummyFunc2,    // processTrim
    resetCpu,
};

#endif/* if _PRJ_NVME */

#if _PRJ_SMIVU
void(*const codeFuncPtr[]) (void)=
{
    dummyFunc,    // bootFunc1,
    dummyFunc,    // bootFunc2,
    dummyFunc,    // servRwCmdQue,
    dummyFunc,    // nvmeDeleteSubQueue,
    dummyFunc,    // nvmeCreateSubQueue,
    dummyFunc,    // nvmeDeleteCmplQueue,
    dummyFunc,    // nvmeCreateCmplQueue,
    dummyFunc,    // nvmeGetLogPage,
    dummyFunc,    // nvmeIdentify,
    dummyFunc,    // nvmeAbort,
    dummyFunc,    // nvmeSetFeature,
    dummyFunc,    // nvmeGetFeature,
    dummyFunc,    // nvmeAsynEvent,
    dummyFunc,    // nvmeFwCommit,
    dummyFunc,    // nvmeFwImageDl,
    dummyFunc,    // nvmeFormat,
    dummyFunc,    // nvmeNamespaceManagement,
    dummyFunc,    // nvmeNamespaceAttachment,
    nvmeVendorNonData,
    nvmeVendorDataOut,
    nvmeVendorDataIn,
    dummyFunc,    // nvmeVuCmdNonData,
    dummyFunc,    // nvmeVuCmdDataOut,
    dummyFunc,    // nvmeVuCmdDataIn,
    dummyFunc,    // chkBgdClnBlkProc
    dummyFunc,    // nvmeFlush,
    dummyFunc,    // nvmeWriteUncorrectable
    dummyFunc,    // nvmeCompare,
    dummyFunc,    // nvmeWriteZero,
    dummyFunc,    // nvmeDataSetManagemaent,
    dummyFunc,    // nvmeDst
    dummyFunc,    // handleDst
    dummyFunc,    // handleAsyncEvent,
    dummyFunc,    // saveRaidAllParity,
    dummyFunc,    // restoRaidAllParity,
    dummyFunc,    // SecAPI_Trusted_Send,
    dummyFunc,    // SecAPI_Trusted_Receive,
    dummyFunc,    // nvmeDirectiveSend,
    dummyFunc,    // nvmeDirectiveRece,
    dummyFunc,    // nvmeSanitize,
    dummyFunc,    // sanitizeContinueOperation,
    nvmeLiteonVendorNonData,
    nvmeLiteonVendorDataOut,
    nvmeLiteonVendorDataIn,
    chkVpCnt,    // chkVpCnt
};

void(*const codeFuncPtr2[]) (BYTE)=
{
    dummyFunc2,    // termFlashOperRw,
    dummyFunc2,    // processTrim
    resetCpu,
};

#endif/* if _PRJ_SMIVU */
#pragma default_function_attributes =

#endif    // #if (!_ICE_LOAD_ALL)
#endif    // #ifndef _FUNCPTR_C_







