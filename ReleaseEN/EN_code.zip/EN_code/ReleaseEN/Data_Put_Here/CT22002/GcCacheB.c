







#include "inc/ProType.h"
// #include "inc/FlashCtrl.h"
#include "inc/GlobVar0.h"
#include "inc/Const.h"
#include "inc/GlobVarS.h"
#include "inc/GlobVarT.h"
#include "inc/Reg.h"
#include "inc/FtlCtrl.h"
#include "inc/Mac.h"
#include "inc/BitDef.h"
#if _EN_FW_DEBUG_UART
#include "inc/DebugLog.h"
#include "inc/EventLogIDX.h"
#include "inc/EventLogFunctionIDX.h"
#endif

#if _PRJ_ISP||(_PRJ_SMIVU&&_GREYBOX)

void bgdClnCacheblkProc(BYTE uCaller)
{
    LWORD u32Temp, u32Fpage, u32TabAddr;
    WORD u16RbufPtr, u16WbufPtr, u16NowNodeIdx, u16Fblock, u16F2hTabOffset, u16TotalGc4kCnt;
    UCLWORD *upSrcFAddrTab;
    F2HTABLE *upDesF2hTabPtr;
    BYTE uChkBreakGC, uChkStaus, uNoHMBPartialGCCnt, uWproIdx;

#if (C_Log_SaveMask&C_Debug_P1)
    NLOG(cLogGC, GCCACHEB_C, 1, "GC Start Caller: 0x%04X", uCaller);
#endif

    if(uCaller==cWriteFunc)
    {
        mSetGcFlag(cUnderFgdGc);
    }

    while(gsRwCtrl.u16ProgPageOfst)
        ;

    save1stCacheInfoBefW();
    // mSetInGcFlow;
    prog1stInvQBootInWpro();
    rstRdyTyp();
    // bkOneShotChPtr();

#if 0    // _EN_FW_DEBUG_UART //Chief_Disable Log_20181123
    NLOG(cLogGC, GCCACHEB_C, 1, "GcStr~ GC flag: 0x%04X ", gsGcInfo.u32GcFlag);
#endif

    if(mGetGcState==cGcStateIdle)
    {
#if (C_Log_SaveMask&C_Debug_P1)
        NLOG(cLogGC, GCCACHEB_C, 2, "GC Start state: 0x%04X flow: 0x%04X ", mGetGcState, mGetGcFlow);
#endif
    }

    do
    {
        while(mGetGcFlow==cGcFlowIdl)
            ;

#if _EN_RAID_GC

        if(gsHmbInfo.uHmbStsChg)
        {
            chkHmbStsChg();
            break;
        }
#endif

        if(mGetGcState==cGcStateIdle)
        {
            initGcProcCore0();
#if (C_Log_SaveMask&C_Debug_P2)
            NLOG(cLogGC,
                 GCCACHEB_C,
                 7,
                 "TotalSpareCnt: 0x%04X, SLCSpareCnt: 0x%04X, DynamicSpareCnt: 0x%04X, SLCFullCnt: 0x%04X, TLCFullCnt: 0x%04X, GcCachebTime: 0x%08X, Gc Idle",
                 gsCacheInfo.u16SpareBlockCnt,
                 gsCacheInfo.u16SLCSpareCnt,
                 gsCacheInfo.u16DynamicSpareCnt,
                 gsCacheInfo.u16FullCacheBlockCnt,
                 gsCacheInfo.u16TLCFullCacheBlockCnt,
                 gsGcInfo.u32GcCachebTime>>16,
                 gsGcInfo.u32GcCachebTime);
#endif

            if(mGetGcState==cGcBuildSrc)
            {
#if (C_Log_SaveMask&C_Debug_P1)
                NLOG(cLogGC, GCCACHEB_C, 0, "GC state cGcStateIdle Finish!");
#endif
            }

            if(!gsGcInfo.u32GcCachebTime)
            {
                debugDeadLock(0x35);
            }
        }

        if((mGetGcState==cGcBuildSrc)&&!mChkGcFlag(cBrkBgdGcF))
        {
            u32Temp=getRtcCurrent32k();
            selectSrcBlk();

#if _EN_FW_DEBUG_UART
            NLOG(cLogGC, GCCACHEB_C, 1, "Total GcSrcBlkCnt: 0x%04X ", gsGcInfo.uGcSrcBlkCnt);
            NLOG(cLogGC, GCCACHEB_C, 2, "gsGcInfo.u32TotalSrcBlkVpc: 0x%08X ", gsGcInfo.u32TotalSrcBlkVpc>>16, gsGcInfo.u32TotalSrcBlkVpc);
#endif

            if(!gsGcInfo.uGcSrcBlkCnt)
            {
                if(gsGcInfo.uGcDesBlkCnt)
                {
                    gcDesBlkFullSettingCore0();
                }

                break;
            }
            else
            {
                initGcDesFblkProc();
#if (C_Log_SaveMask&C_Debug_P2)
                NLOG(cLogGC, GCCACHEB_C, 1, "GC des block: 0x%04X ", gsGcInfo.u16GcDesBlock);
#endif
            }

            if(mGetWproPagePtr(cWproGcInfoPage)<gsWproInfo.u16PagePerBlock3)
            {
                loadGcInfoTab(cWproGcInfoPage, c16GcDesF2hSIdx, 0);    // , cWaitReadDone);
            }
            else
            {
                bopClrRam((LWORD)&garTsb0[c16GcDesF2hSIdx], c32CacheF2hRamSize*2, 0xFFFFFFFF, cClrTsb|cBopWait);
            }

            buildSrcFaddrDesF2hTab();
            waitAllChCeBzCore0();
            gsGcInfo.u32GcLastX2TBuildSrcTabTime+=chkRtc32kProcTime(u32Temp);

            if(mGetGcState==cGcMoveData)
            {
#if (C_Log_SaveMask&C_Debug_P1)
                NLOG(cLogGC, GCCACHEB_C, 0, "GC state cGcBuildSrc Finish!");
#endif
            }
        }

        if(!mChkGcFlag(cBrkBgdGcF))
        {
            getBrkBgdGcF();
        }

        if((mGetGcState==cGcMoveData)&&!mChkGcFlag(cBrkBgdGcF))
        {
            u32Temp=getRtcCurrent32k();

            if(g16ReadBufPtr!=c16ReadSIdx)
            {
                gsRwCtrl.u32SeqRdFlag|=cBit2;

                while(gsRwCtrl.u32SeqRdFlag&cBit2)
                    ;
            }

            rstH2F1KInfo();
            u16RbufPtr=u16WbufPtr=c16CopySIdx;
            gsGcInfo.uGcWr4kPtr=gsGcInfo.uGcRd4kPtr=0;
            mSetGcFlag(cGcNewDesF);
            mSetGcFlag(cGcLoadNextF2hTab);
            uChkBreakGC=0;
            uNoHMBPartialGCCnt=0;

            if(!gsHmbInfo.uHmbEnGcCache)
            {
                u16TotalGc4kCnt=gsGcInfo.u32Prog4kCntPerChPg*gsGcInfo.uGCDesPagePerWL;
            }
            else
            {
                if(mChkGcFlag(cUnderBgdGc))    // 20190802_Louis
                {
                    u16TotalGc4kCnt=gsGcInfo.u32Prog4kCntPerChPg*gsGcInfo.uGCDesPagePerWL;
                }
                else
                {
                    u16TotalGc4kCnt=gsGcInfo.u32Prog4kCntPerChPg*gsGcInfo.uGCDesPagePerWL*cMaxHmbGcCacheNum;
                }

                gsGcInfo.u16HmbGcCache4kCnt=u16TotalGc4kCnt;
            }

            gsGcInfo.uPreProgFifo=gsRwCtrl.u32ProgFifoHead;
            // gsGcInfo.uPreSrcFifo=gsRwCtrl.u32FreeSrcFifoHead;
            gsGcInfo.uLoadGCTabIdx=(gsGcInfo.u32GcSrcF4kPtr/gsGcInfo.u16GCDesTotalPgPerF2hTab)*gsGcInfo.uPartTabSizeInBank;
            gsGcInfo.uLoadGCTabIdx=gsGcInfo.uLoadGCTabIdx+
                                    (((gsGcInfo.u32GcSrcF4kPtr%gsGcInfo.u16GCDesTotalPgPerF2hTab)+gsGcInfo.u16DumF2h4K)/
                                     gsGcInfo.u16EntryInPlane);

            gsGcInfo.u32GCInfoTabSize=(gsGcInfo.uLoadGCTabIdx/gsGcInfo.uPartTabSizeInBank)*gsGcInfo.u16GCDesTotalPgPerF2hTab;

            if(gsGcInfo.uLoadGCTabIdx%gsGcInfo.uPartTabSizeInBank)
            {
                gsGcInfo.u32GCInfoTabSize=gsGcInfo.u32GCInfoTabSize+gsGcInfo.u16RemainF2h4k+
                                           (((gsGcInfo.uLoadGCTabIdx%gsGcInfo.uPartTabSizeInBank)-1)*gsGcInfo.u16EntryInPlane);
            }

            chkExitGcCondition();    // 20190719_Louis

            while(u16TotalGc4kCnt&&!mChkGcFlag(cGcDesFailAbort))
            {
                while(mGetSrcOccpyCnt()>=cReadSafetyFifoDpt)
                {
                    if(gsHmbInfo.uHmbEnGcCache)
                    {
                        u16WbufPtr=setWriteGcDataHmb(u16TotalGc4kCnt, u16WbufPtr);
                    }
                }

                if(chkLoadGCInfoTab()||mChkGcFlag(cGcLoadNextF2hTab))
                {
                    if(chkLoadGCInfoTab())
                    {
                        uChkStaus=0;
                    }
                    else
                    {
                        uChkStaus=1;
                    }

                    u16WbufPtr=loadPartialGCTab(u16TotalGc4kCnt, u16WbufPtr);

                    u32TabAddr=getGcTabAddr(gsGcInfo.u32GcSrcF4kPtr);
                    upDesF2hTabPtr=(F2HTABLE *)u32TabAddr;
                    upSrcFAddrTab=(UCLWORD *)(u32TabAddr+gsGcInfo.u16GapOfMoveTab);
                    u16Fblock=mGetSrcFBlkAddr(*upSrcFAddrTab);
                    u32Fpage=mGetSrcFPageAddr(*upSrcFAddrTab);

                    if((gsGcInfo.u32GcSrcF4kPtr&&
                        (gsGcInfo.u32GcSrcF4kPtr>(gsGcInfo.u32GCInfoTabSize-(gsGcInfo.u32GCInfoTabSize%gsGcInfo.u32Prog4kCntPerChIntPlnWl))))||
                       (gsGcInfo.u32GcSrcF4kPtr<(gsGcInfo.u32GCInfoTabSize-gsGcInfo.u16EntryInPlane)))
                    {
                        if(uChkStaus)
                        {
                            if((gsGcInfo.uLoadGCTabIdx%gsGcInfo.uPartTabSizeInBank)==1)
                            {
                                if(gsGcInfo.u32GcSrcF4kPtr<(gsGcInfo.u32GCInfoTabSize-gsGcInfo.u16RemainF2h4k))
                                {
                                    gsFtlDbg.u16DummyFailType=cBgdClnCacheblkProc1;
#if (C_Log_SaveMask&C_Debug_P1)
                                    NLOG(cLogGC,
                                         GCCACHEB_C,
                                         3,
                                         "cGcMoveData , GC While 01: gsGcInfo.u32GcSrcF4kPtr = 0x%04X , gsGcInfo.u32GCInfoTabSize = 0x%04X , gsGcInfo.u16RemainF2h4k = 0x%04X",
                                         gsGcInfo.u32GcSrcF4kPtr,
                                         gsGcInfo.u32GCInfoTabSize,
                                         gsGcInfo.u16RemainF2h4k);
#endif
                                    debugWhile();
                                }
                            }
                            else
                            {
                                gsFtlDbg.u16DummyFailType=cBgdClnCacheblkProc2;
#if (C_Log_SaveMask&C_Debug_P1)
                                NLOG(cLogGC,
                                     GCCACHEB_C,
                                     2,
                                     "cGcMoveData , GC While 02 : gsGcInfo.uLoadGCTabIdx = 0x%04X , gsGcInfo.uPartTabSizeInBank =  0x%04X",
                                     gsGcInfo.uLoadGCTabIdx,
                                     gsGcInfo.uPartTabSizeInBank);
#endif
                                debugWhile();
                            }
                        }
                    }

                    if(chkLoadGCInfoTab()&&(mChkGcFlag(cGcLoadNextF2hTab))&&(gsGcInfo.u32GCInfoTabSize%gsGcInfo.u32Prog4kCntPerChIntPlnWl))
                    {
                        u16WbufPtr=loadPartialGCTab(u16TotalGc4kCnt, u16WbufPtr);
                    }

                    mClrGcFlag(cGcLoadNextF2hTab);
                }

                if((u16Fblock>=g16TotalFBlock)&&(u16Fblock!=c16FBlockInitValue))
                {
                    uWproIdx=cWproGcDesF2hTab00+(u16Fblock-g16TotalFBlock);

                    while(gsGcInfo.uGcRd4kPtr<g4kNumPerPage)
                    {
                        if((gsGcInfo.u32GcSrcF4kPtr&(g4kNumPerPlane-1))==0)
                        {
                            u16F2hTabOffset=(gsGcInfo.u32GcSrcF4kPtr%gsGcInfo.u16GCDesTotalPgPerF2hTab);

                            while(u16F2hTabOffset<gsGcInfo.u16GCDesValidPgPerF2hTab)
                                ;

                            u16F2hTabOffset-=gsGcInfo.u16GCDesValidPgPerF2hTab;

#if !_EN_RAID_GC

                            if(gsGcInfo.uGCDesPadF2h4KNum)
                            {
                                if(u16F2hTabOffset<gsGcInfo.uGCDesPadF2h4KNum)
                                {
                                    u16F2hTabOffset+=gsGcInfo.uGCDesProgF2HRem4KNum;
                                }
                                else
                                {
                                    u16F2hTabOffset-=gsGcInfo.uGCDesPadF2h4KNum;
                                }
                            }
#endif
                            u16F2hTabOffset=(u16F2hTabOffset/g4kNumPerPlane);

                            // loadGcInfoTab(uWproIdx, u16RbufPtr|c16Bit15, u16F2hTabOffset|cBit7, 0);
                            u16NowNodeIdx=gsRwCtrl.uarFreeSrcQue[gsRwCtrl.u32FreeSrcFifoHead];
                            gpFlashAddrInfo=&garSrcAddrInfo[u16NowNodeIdx];
                            g16FBlock=gsWproInfo.u16arWproBlk[mGetWproBlkIdx(uWproIdx)];
                            g32FPageNoTran=mGetWproPagePtr(uWproIdx)+u16F2hTabOffset;
                            g16FPage=g32FPageNoTran;

                            if(gsHmbInfo.uHmbEnGcCache)
                            {
                                gpFlashAddrInfo->uTsb4kIdx=u16RbufPtr>>cSctrTo4kShift;
                            }
                            else
                            {
                                gpFlashAddrInfo->uTsb4kIdx=0xFF;
                            }

                            gpFlashAddrInfo->uSrcIdx=u16NowNodeIdx;
                            tranAddrInfoTo2Ch(gpFlashAddrInfo);
                            gpFlashAddrInfo->uPrdPtr=0xFF;
                            gOpTyp=cMoveReadData;
                            gSectorH=0;
                            gpFlashAddrInfo->u16BufPtr=u16RbufPtr;
#if _EN_RAID_GC
                            gpFlashAddrInfo->u16RwOpt=c16Bit1|c16Bit4|c16Bit6|c16Bit11|c16Bit15;
#else
                            gpFlashAddrInfo->u16RwOpt=c16Bit1|c16Bit4|c16Bit6|c16Bit15;
#endif
                            gpFlashAddrInfo->uPlaneCnt=g4kNumPerPlane;
                            gpFlashAddrInfo->uRwHalfKb=gSectorPerPlaneH;
                            gsRwCtrl.u32FreeSrcFifoHead=(gsRwCtrl.u32FreeSrcFifoHead+1)&(cReadFifoDpt-1);
                            u16RbufPtr=addCopyBufPtrGc(u16RbufPtr, gSectorPerPlaneH);
                        }

                        gsGcInfo.uGcRd4kPtr++;
                        gsGcInfo.u32GcSrcF4kPtr++;
                        upSrcFAddrTab--;
                        u16TotalGc4kCnt--;

#if _EN_RAID_GC

                        if((gsGcInfo.u32GcSrcF4kPtr%gsGcInfo.u16GCDesTotalPgPerF2hTab)==(gsGcInfo.u16GCDesTotalPgPerF2hTab-c4kNumPerRaidPty))
                        {
                            u16Fblock=mGetSrcFBlkAddr(*upSrcFAddrTab);
                            u32Fpage=mGetSrcFPageAddr(*upSrcFAddrTab);
                            break;
                        }
#endif
                    }
                }
                else
                {
                    u16NowNodeIdx=gsRwCtrl.uarFreeSrcQue[gsRwCtrl.u32FreeSrcFifoHead];
                    gpFlashAddrInfo=&garSrcAddrInfo[u16NowNodeIdx];
                    g16FBlock=u16Fblock;
                    g32FPageNoTran=u32Fpage;

                    if(gsHmbInfo.uHmbEnGcCache)
                    {
                        gpFlashAddrInfo->uTsb4kIdx=u16RbufPtr>>cSctrTo4kShift;    // 0xFF;
                    }
                    else
                    {
                        gpFlashAddrInfo->uTsb4kIdx=0xFF;
                    }

                    gpFlashAddrInfo->uSrcIdx=u16NowNodeIdx;
                    tranAddrInfo(gpFlashAddrInfo);
                    gpFlashAddrInfo->uPrdPtr=0xFF;

                    if(g16FBlock==c16FBlockInitValue)
                    {
                        gOpTyp=cGcHdmaDummy;
                    }
                    else
                    {
                        gOpTyp=cMoveReadData;
                    }

                    gSectorH=mTranSctr4kAddr(g32FPageNoTran);
                    gpFlashAddrInfo->u16BufPtr=u16RbufPtr;
                    gpFlashAddrInfo->u16RwOpt=c16Bit1|c16Bit4|c16Bit6|c16Bit15;
                    gpFlashAddrInfo->uPlaneCnt=0;

                    do
                    {
                        gpFlashAddrInfo->uPlaneCnt++;
                        gsGcInfo.uGcRd4kPtr++;
                        gsGcInfo.u32GcSrcF4kPtr++;
                        upSrcFAddrTab--;
                        u16TotalGc4kCnt--;
                        u16Fblock=mGetSrcFBlkAddr(*upSrcFAddrTab);
                        u32Fpage=mGetSrcFPageAddr(*upSrcFAddrTab);
                    }
                    while(u16TotalGc4kCnt&&(gsGcInfo.uGcRd4kPtr<g4kNumPerPage)&&
                          ((u32Fpage==(g32FPageNoTran+gpFlashAddrInfo->uPlaneCnt))&&
                           (u16Fblock==g16FBlock)||(g16FBlock==c16FBlockInitValue))&&
                          (((BYTE)u32Fpage&(g4kNumPerPage-1))!=0)
                          );

                    gpFlashAddrInfo->uRwHalfKb=gpFlashAddrInfo->uPlaneCnt<<cSctrTo4kShift;

                    if((gpFlashAddrInfo->uRwHalfKb+gSectorH)>gSectorPerPlaneH)
                    {
                        gpFlashAddrInfo->u16RwOpt|=c16Bit0;
                    }

                    gsRwCtrl.u32FreeSrcFifoHead=(gsRwCtrl.u32FreeSrcFifoHead+1)&(cReadFifoDpt-1);
                    u16RbufPtr=addCopyBufPtrGc(u16RbufPtr, gpFlashAddrInfo->uRwHalfKb);
                }

                chkExitGcCondition();    // 20190802_Louis

                while(gsGcInfo.uGcWr4kPtr!=gsGcInfo.uGcRd4kPtr)
                {
                    if(!gsHmbInfo.uHmbEnGcCache)
                    {
                        gpFlashAddrInfo=&garDesAddrInfo[gsGcInfo.uPreProgFifo];
                        garDesF2hInfo[gsGcInfo.uPreProgFifo].u16arHPage[gsGcInfo.uGcWr4kPtr]=upDesF2hTabPtr->u16HPage;
                        garDesF2hInfo[gsGcInfo.uPreProgFifo].u16arHBlock[gsGcInfo.uGcWr4kPtr]=upDesF2hTabPtr->u16HBlock;
                        upDesF2hTabPtr--;

                        if(mChkGcFlag(cGcNewDesF))
                        {
#if _GREYBOX

                            if((gsGbInfo.uGreyBoxOpt==cVOpProgLastF2H)&&(gsGbInfo.uStag==cVsIdl))
                            {
                                if(gsGbInfo.uGreyBoxItem==cUGSDS2TID)
                                {
                                    trigGreyBox(cTrue);
                                }
                                else if(gsGbInfo.uGreyBoxItem==cUGSDReclaimID)
                                {
                                    if((mChkGcSrcBlkBmap(*(WORD *)(c32GreyBoxBuf+cGbInfoReclimFBlk1)))||
                                       (mChkGcSrcBlkBmap(*(WORD *)(c32GreyBoxBuf+cGbInfoReclimFBlk2)))||
                                       (mChkGcSrcBlkBmap(*(WORD *)(c32GreyBoxBuf+cGbInfoReclimFBlk3))))
                                    {
                                        trigGreyBox(cTrue);
                                    }
                                }
                                else if((gsGbInfo.uGreyBoxItem==cUGSDT2TID)&&(mGetGcFlow==cGcFlowT2T))
                                {
                                    trigGreyBox(cTrue);
                                }
                                else if((gsGbInfo.uGreyBoxItem==cUGSDS2SID)&&(mGetGcFlow==cGcFlowS2S))
                                {
                                    trigGreyBox(cTrue);
                                }
                                else if((gsGbInfo.uGreyBoxItem==cUGSDonWearleveling)&&(mGetGcFlow==cGcFlowT2T))
                                {
                                    trigGreyBox(cTrue);
                                }
                            }
                            else if((gsGbInfo.uGreyBoxItem==cRAIDEncOnGc)&&(gsGbInfo.uStag==cVsIdl))
                            {
                                gsGbInfo.uStag=cVsTriggered;
                            }
#endif/* if (_GREYBOX) */
                            setWriteDes(gsRwCtrl.u16ProgPageOfst, gpFlashAddrInfo, cGcDesBlockID);
                            mClrGcFlag(cGcNewDesF);
                        }
                    }

                    gsGcInfo.u32GcDesF4kPtr++;

                    if(!(gsGcInfo.u32GcDesF4kPtr&(gsGcInfo.u32Prog4kCntPerChPg-1)))
                    {
                        if((!gsHmbInfo.uHmbEnGcCache&&chkAddGcOneShotPtr())||(!(gsGcInfo.u32GcDesF4kPtr%gsGcInfo.u16GCDesTotalPgPerF2hTab)))
                        {
                            u32TabAddr=getGcTabAddr(gsGcInfo.u32GcDesF4kPtr);
                            upDesF2hTabPtr=(F2HTABLE *)u32TabAddr;
                            upSrcFAddrTab=(UCLWORD *)(u32TabAddr+gsGcInfo.u16GapOfMoveTab);
                        }
                        else
                        {
                            if(!gsHmbInfo.uHmbEnGcCache)
                            {
                                u32TabAddr=g4kNumPerPage*(gTotalIntlvChNum-gTotalChNum);
                                upSrcFAddrTab-=u32TabAddr;
                                upDesF2hTabPtr-=u32TabAddr;
                            }

                            if(upSrcFAddrTab<(UCLWORD *)(c16GcMoveDesAddr+gsGcInfo.u16GapOfMoveTab))
                            {
                                upSrcFAddrTab+=(gsGcInfo.u16GapOfMoveTab/4);
                                upDesF2hTabPtr+=(gsGcInfo.u16GapOfMoveTab/4);
                            }
                        }

                        u16Fblock=mGetSrcFBlkAddr(*upSrcFAddrTab);
                        u32Fpage=mGetSrcFPageAddr(*upSrcFAddrTab);
                    }

                    if(!(gsGcInfo.u32GcDesF4kPtr%gsGcInfo.u16GCDesTotalPgPerF2hTab))
                    {
                        gsGcInfo.uGcDesF2hTabBank++;

                        if(gsGcInfo.uGcDesF2hTabBank==gsGcInfo.uGCDesF2hBankNum)
                        {
#if (_EN_GCPWR&&(!_EN_RAID_GC))
                            mSetGcState(cGcPostWriteRead);
#else
#if _EN_CHK_FINGER_FAIL
                            mSetGcState(cGcChkFingerFail);
#else
                            mSetGcState(cGcFlushH2F);
#endif
#endif
                        }
                    }

                    if(!gsHmbInfo.uHmbEnGcCache)
                    {
                        u16WbufPtr=setProgFifoOptGc(u16WbufPtr, cMoveProgData);
                    }
                    else
                    {
                        gsGcInfo.uGcWr4kPtr++;

                        if(gsGcInfo.uGcWr4kPtr==g4kNumPerPage)
                        {
                            gsGcInfo.uGcWr4kPtr=gsGcInfo.uGcRd4kPtr=0;
                        }

                        u16WbufPtr=setWriteGcDataHmb(u16TotalGc4kCnt, u16WbufPtr);
                    }
                }

                chkExitGcCondition();    // 20190802_Louis

                if(!u16TotalGc4kCnt)
                {
#if _EN_RAID_GC
                    WORD u16HmbXfrUnit=0;
#endif

                    if(gsHmbInfo.uHmbEnGcCache)
                    {
                        while((gsGcInfo.u16HmbGcCache4kCnt-u16TotalGc4kCnt)>=(cHmbChunkSctrSize>>cSctrTo4kShift))
                        {
                            mWaitHmbRelease(2);
                            txfrHmbData(cHmbWriteData,
                                        u16WbufPtr,
                                        cHmbChunkSctrSize,
                                        (gsGcInfo.uHmbGcCachePtr*cHmbChunkSctrSize)<<9,
                                        gsGcInfo.uHmbGcCachePtr,
                                        cHmbGcCache,
                                        cHmbTsbPath|cHmbBufflagChk,
                                        0);
                            writeE2eCrc2Hmb(u16WbufPtr>>5);
                            u16WbufPtr=addCopyBufPtrGc(u16WbufPtr, cHmbChunkSctrSize);
                            gsGcInfo.uHmbGcCachePtr=addPtrBy1(gsGcInfo.uHmbGcCachePtr, gsGcInfo.uMaxHmbGcCacheNum);
                            gsGcInfo.uHmbGcCacheCnt++;
                            gsGcInfo.u16HmbGcCache4kCnt-=(cHmbChunkSctrSize>>cSctrTo4kShift);
                        }

                        if(!gsGcInfo.uHmbGcCachePtr||(mGetGcState!=cGcMoveData))
                        {
                            mSetGcFlag(cGcDownstrHmb);
                            mSetGcFlag(cGcWaitSrcDone);
                            upDesF2hTabPtr=(F2HTABLE *)getGcTabAddr(gsGcInfo.u32GcDesF4kPtr2);

                            if(mChkHandlePcieErrF)
                            {
                                setBufStatus(c16Tsb0SIdx, c16Tsb0Size, cTsb0);
                                sysDelay(0xFFFF);

                                while(gsRwCtrl.u32FreeSrcFifoTail!=gsRwCtrl.u32FreeSrcFifoHead)
                                {
                                    rmResetBufFlg;
                                }
                            }
                        }
                    }
                    else
                    {
                        while((gsRwCtrl.u32FreeSrcFifoTail!=gsRwCtrl.u32FreeSrcFifoHead)||g32DecodeWait)
                            ;

                        gsRwCtrl.u32ProgFifoHead=gsGcInfo.uPreProgFifo;

                        uNoHMBPartialGCCnt++;

                        if(uNoHMBPartialGCCnt==cMaxHmbGcCacheNum)
                        {
                            uNoHMBPartialGCCnt=0;
                            uChkBreakGC=1;
                        }
                    }

                    u16RbufPtr=u16WbufPtr=c16CopySIdx;

                    if(mChkGcFlag(cGcDownstrHmb))
                    {
                        BYTE uTsbCtrlFlag=cFalse;

#if _EN_PROGFAILLOG

                        while(gsGcInfo.uHmbGcCacheCnt&&!mChkGcFlag(cGcDesFailAbort))
#else

                        while(gsGcInfo.uHmbGcCacheCnt)
#endif
                        {
                            while(gsGcInfo.u32GcDesF4kPtr2!=gsGcInfo.u32GcDesF4kPtr)
                            {
                                if(addWrFfPtrBy1(gsGcInfo.uPreProgFifo)==gsRwCtrl.u32ProgFifoTail)
                                {
                                    break;
                                }

                                gpFlashAddrInfo=&garDesAddrInfo[gsGcInfo.uPreProgFifo];
                                garDesF2hInfo[gsGcInfo.uPreProgFifo].u16arHPage[gsGcInfo.uGcWr4kPtr]=upDesF2hTabPtr->u16HPage;
                                garDesF2hInfo[gsGcInfo.uPreProgFifo].u16arHBlock[gsGcInfo.uGcWr4kPtr]=upDesF2hTabPtr->u16HBlock;
                                upDesF2hTabPtr--;

                                if(mChkGcFlag(cGcNewDesF))
                                {
#if _GREYBOX

                                    if((gsGbInfo.uGreyBoxOpt==cVOpProgLastF2H)&&(gsGbInfo.uStag==cVsIdl))
                                    {
                                        if(gsGbInfo.uGreyBoxItem==cUGSDS2TID)
                                        {
                                            trigGreyBox(cTrue);
                                        }
                                        else if(gsGbInfo.uGreyBoxItem==cUGSDReclaimID)
                                        {
                                            if((mChkGcSrcBlkBmap(*(WORD *)(c32GreyBoxBuf+cGbInfoReclimFBlk1)))||
                                               (mChkGcSrcBlkBmap(*(WORD *)(c32GreyBoxBuf+cGbInfoReclimFBlk2)))||
                                               (mChkGcSrcBlkBmap(*(WORD *)(c32GreyBoxBuf+cGbInfoReclimFBlk3))))
                                            {
                                                trigGreyBox(cTrue);
                                            }
                                        }
                                        else if((gsGbInfo.uGreyBoxItem==cUGSDT2TID)&&(mGetGcFlow==cGcFlowT2T))
                                        {
                                            trigGreyBox(cTrue);
                                        }
                                        else if((gsGbInfo.uGreyBoxItem==cUGSDS2SID)&&(mGetGcFlow==cGcFlowS2S))
                                        {
                                            trigGreyBox(cTrue);
                                        }
                                        else if((gsGbInfo.uGreyBoxItem==cUGSDonWearleveling)&&(mGetGcFlow==cGcFlowT2T))
                                        {
                                            trigGreyBox(cTrue);
                                        }
                                    }
                                    else if((gsGbInfo.uGreyBoxItem==cRAIDEncOnGc)&&(gsGbInfo.uStag==cVsIdl))
                                    {
                                        gsGbInfo.uStag=cVsTriggered;
                                    }
#endif/* if (_GREYBOX) */
                                    setWriteDes(gsRwCtrl.u16ProgPageOfst, gpFlashAddrInfo, cGcDesBlockID);
                                    mClrGcFlag(cGcNewDesF);
                                }

                                gsGcInfo.u32GcDesF4kPtr2++;

                                if(!(gsGcInfo.u32GcDesF4kPtr2&(gsGcInfo.u32Prog4kCntPerChPg-1)))
                                {
                                    gsGcInfo.uGcIntlvPtr++;

                                    if(gsGcInfo.uGcIntlvPtr==gIntlvWay)
                                    {
                                        gsGcInfo.uGcIntlvPtr=0;
                                        gsGcInfo.uSrcHandlePageType++;

                                        if(gsGcInfo.uSrcHandlePageType==gsGcInfo.uGCDesPagePerWL)
                                        {
                                            gsGcInfo.uSrcHandlePageType=0;
                                            gsGcInfo.u16GcOneShotPtr++;
                                        }
                                    }

                                    if(!(gsGcInfo.u32GcDesF4kPtr2%gsGcInfo.u16GCDesTotalPgPerF2hTab))
                                    {
                                        upDesF2hTabPtr=(F2HTABLE *)getGcTabAddr(gsGcInfo.u32GcDesF4kPtr2);
                                    }
                                    else if(upDesF2hTabPtr<(F2HTABLE *)c16GcMoveDesAddr)
                                    {
                                        upDesF2hTabPtr+=(gsGcInfo.u16GapOfMoveTab/4);
                                    }
                                }

                                u16WbufPtr=setProgFifoOptGc(u16WbufPtr, cMoveProgData);

                                if(mChkGcFlag(cGcNewDesF))
                                {
                                    if(mChkGcFlag(cGcWaitSrcDone))
                                    {
                                        if((gsRwCtrl.u32FreeSrcFifoTail==gsRwCtrl.u32FreeSrcFifoHead)&&!g32DecodeWait&&!rmChkHdmaBz)
                                        {
                                            break;
                                        }
                                    }
                                    else
                                    {
                                        gsRwCtrl.u32ProgFifoHead=gsGcInfo.uPreProgFifo;
#if _EN_RAID_GC

                                        if((!rmChkBopBz)&&
                                           ((gsGcInfo.u32GcDesF4kPtr2%gsGcInfo.u16GCDesTotalPgPerF2hTab)>=
                                            (gsGcInfo.u16HmbXfrUnit+(cHmbChunkSctrSize>>cSctrTo4kShift))))
#else

                                        if(!rmChkBopBz)
#endif
                                        {
                                            break;
                                        }
                                    }
                                }
                            }

                            if(mChkGcFlag(cGcWaitSrcDone))
                            {
                                mWaitHmbTransferDone();

                                while((gsRwCtrl.u32FreeSrcFifoTail!=gsRwCtrl.u32FreeSrcFifoHead)||g32DecodeWait||rmChkHdmaBz)
                                    ;

                                gsRwCtrl.u32ProgFifoHead=gsGcInfo.uPreProgFifo;
                                mClrGcFlag(cGcWaitSrcDone);
                            }
                            else if(uTsbCtrlFlag!=cTrue)
                            {
                                while(rmChkBopBz)
                                    ;

                                WORD u16BufIdx=u16RbufPtr>>5;
                                WORD u16Loop=cHmbChunkSctrSize>>5;

                                while(u16Loop)
                                {
#if _EN_RAID_GC
                                    rmSetBufRaid32Sts(u16BufIdx, 0xFFFFFFFF);    // 64k alignment
#else
                                    rmSetBuf32Sts(u16BufIdx, 0xFFFFFFFF);    // 64k alignment
#endif
                                    u16BufIdx++;
                                    u16Loop--;
                                }

                                u16RbufPtr=addCopyBufPtrGc(u16RbufPtr, cHmbChunkSctrSize);
                            }

#if _EN_RAID_GC

                            if(rm32BufRaidStatus((u16RbufPtr>>5)+((cHmbChunkSctrSize>>5)-1)))
                            {
                                uTsbCtrlFlag=cTrue;
                            }
                            else
                            {
                                uTsbCtrlFlag=cFalse;

                                if(mChkGcFlag(cGcDownstrHmbRaidParity))
                                {
                                    mClrGcFlag(cGcDownstrHmbRaidParity);
                                    chkTrigHmbPtyQue();
                                }

                                mWaitHmbTransferDone();
                                txfrHmbData(cHmbReadData,
                                            u16RbufPtr,
                                            cHmbChunkSctrSize,
                                            (gsGcInfo.uHmbGcCachePtr*cHmbChunkSctrSize)<<9,
                                            gsGcInfo.uHmbGcCachePtr,
                                            cHmbGcCache,
                                            cHmbTsbPath|cHmbReadDir|cHmbBufflagChk,
                                            g32arGcDataCrc[gsGcInfo.uHmbGcCachePtr*2]);
                                readE2eCrcFromHmb();
                                gsGcInfo.uHmbGcCachePtr=addPtrBy1(gsGcInfo.uHmbGcCachePtr, gsGcInfo.uMaxHmbGcCacheNum);
                                gsGcInfo.uHmbGcCacheCnt--;
                                u16HmbXfrUnit+=(cHmbChunkSctrSize>>cSctrTo4kShift);
                                gsGcInfo.u16HmbXfrUnit+=(cHmbChunkSctrSize>>cSctrTo4kShift);

                                if(u16HmbXfrUnit>=g16ProgRaidUnit)
                                {
                                    u16HmbXfrUnit-=g16ProgRaidUnit;

                                    if(gsGcInfo.u16HmbXfrUnit>=gsGcInfo.u16RaidStrAddr)
                                    {
                                        mSetGcFlag(cGcDownstrHmbRaidParity);

                                        if(gsGcInfo.u16HmbXfrUnit>=gsGcInfo.u16GCDesTotalPgPerF2hTab)
                                        {
                                            gsGcInfo.u16HmbXfrUnit-=gsGcInfo.u16GCDesTotalPgPerF2hTab;

                                            while(gsGcInfo.u16HmbXfrUnit)
                                                ;
                                        }
                                    }
                                    else
                                    {
                                        chkTrigHmbPtyQue();
                                    }
                                }
                            }

#else/* if _EN_RAID_GC */
                            mWaitHmbRelease(2);
                            txfrHmbData(cHmbReadData,
                                        u16RbufPtr,
                                        cHmbChunkSctrSize,
                                        (gsGcInfo.uHmbGcCachePtr*cHmbChunkSctrSize)<<9,
                                        gsGcInfo.uHmbGcCachePtr,
                                        cHmbGcCache,
                                        cHmbTsbPath|cHmbReadDir|cHmbBufflagChk,
                                        g32arGcDataCrc[gsGcInfo.uHmbGcCachePtr*2]);
                            readE2eCrcFromHmb();
                            gsGcInfo.uHmbGcCachePtr=addPtrBy1(gsGcInfo.uHmbGcCachePtr, gsGcInfo.uMaxHmbGcCacheNum);
                            gsGcInfo.uHmbGcCacheCnt--;
#endif/* if _EN_RAID_GC */
                        }

#if _EN_PROGFAILLOG

                        if(mChkGcFlag(cGcDesFailAbort))
                        {
#if _EN_FW_DEBUG_UART
                            NLOG(cLogGC,
                                 GCCACHEB_C,
                                 4,
                                 "cGcDesFailAbort enter: rmChkHdmaCmdFifoDpt: 0x%04X, rmChkBopCmdFifoDpt: 0x%04X, rmHmbPrdQueTrigIdx: 0x%04X, rmHmbPrdQueHeadIdx: 0x%04X",
                                 rmChkHdmaCmdFifoDpt,
                                 rmChkBopCmdFifoDpt,
                                 rmHmbPrdQueTrigIdx,
                                 rmHmbPrdQueHeadIdx);
#endif
                            BYTE uHmbPrdTrigIdx=rmHmbPrdQueTrigIdx;
                            WORD u16BufIdx, u16Loop, u16OrgBufIdx;

                            while((uHmbPrdTrigIdx!=rmHmbPrdQueHeadIdx)&&(!mChkHandlePcieErrF))
                            {
                                setBufStatus(c16Tsb0SIdx, c16Tsb0Size, cTsb0);
                                setBufStatus(c16Tsb1SIdx, c16Tsb1Size, cTsb1);

                                rmResetBufFlg;

                                while((uHmbPrdTrigIdx==rmHmbPrdQueTrigIdx)&&(!mChkHandlePcieErrF))
                                    ;

                                uHmbPrdTrigIdx=rmHmbPrdQueTrigIdx;
                            }

                            waitHmbPrdDone();
                            rmResetBufFlg;

                            volatile BYTE uBufferLoop=0;

                            while((gsRwCtrl.u32ProgFifoTail!=gsRwCtrl.u32ProgFifoHead)||rmChkHdmaBz)
                            {
                                while(rmChkHdmaBz)
                                {
#if 0
                                    NLOG(cLogGC, GCCACHEB_C, 1, "rHdmaCtrl[rcHdmaCmdQDepth]=0x%04X", rHdmaCtrl[rcHdmaCmdQDepth]);
#endif
                                    u16BufIdx=0;
                                    u16Loop=c16Tsb0Size>>5;

                                    while(u16Loop)
                                    {
                                        rmSetBufRaid32Sts(u16BufIdx, 0xFFFFFFFF);

                                        u16BufIdx++;
                                        u16Loop--;
                                    }

                                    rmResetRaidFlg;

                                    rmSetBuf32Sts(c16GcParitySIdx>>5, 0xFFFFFFFF);
                                    rmResetBufFlg;
                                }

                                while(rmChkBopBz)
                                {
#if 0
                                    NLOG(cLogGC, GCCACHEB_C, 1, "rBopCtrl[rcBopCmdFifoDpt]=0x%04X", rBopCtrl[rcBopCmdFifoDpt]);
#endif
                                    LWORD u32BufMsk=0;
                                    u16BufIdx=((LWORD)gCrcDataBuffer-c32Tsb0SAddr)>>9;
                                    u16OrgBufIdx=u16BufIdx>>5;
                                    u16Loop=cCrcDataBufferSize/cSectorSize;

                                    while(u16Loop)
                                    {
                                        u32BufMsk|=cb32BitTab[u16BufIdx&0x1F];
                                        u16BufIdx++;
                                        u16Loop--;
                                    }

                                    rmSetBuf32Sts(u16OrgBufIdx, u32BufMsk);

                                    if((rm32BufStatus(u16OrgBufIdx)&u32BufMsk)==u32BufMsk)
                                    {
                                        rmSetBuf32Sts(u16OrgBufIdx, u32BufMsk);
                                    }
                                }

                                setBufStatus(garDesAddrInfo[gsRwCtrl.u32ProgFifoTail].u16BufPtr,
                                             garDesAddrInfo[gsRwCtrl.u32ProgFifoTail].uRwHalfKb,
                                             cTsb0);
#if 0
                                uBufferLoop=(garDesAddrInfo[gsRwCtrl.u32ProgFifoTail].u16BufPtr)>>5;
                                NLOG(cLogGC,
                                     GCCACHEB_C,
                                     6,
                                     "u32ProgFifoTail=0x%04X, u32ProgFifoHead=0x%04X, TsbBufFlag=0x%08X, RaidBufFlag=0x%08X",
                                     gsRwCtrl.u32ProgFifoTail,
                                     gsRwCtrl.u32ProgFifoHead,
                                     (r32TsbCtrl[(rcBuf0Flag/4)+(uBufferLoop)])>>16,
                                     r32TsbCtrl[(rcBuf0Flag/4)+(uBufferLoop)],
                                     ((r32TsbCtrl[(rcBuf0RaidFlag/4)+(uBufferLoop)]))>>16,
                                     (r32TsbCtrl[(rcBuf0RaidFlag/4)+(uBufferLoop)]));
#endif
                                rmResetBufFlg;
                            }

                            gsGcInfo.uHmbGcCacheCnt=0;
                            gsGcInfo.uHmbGcCachePtr=0;
                            gsHmbPtyInfo.u32HmbPtyTail=gsHmbPtyInfo.u32HmbPtyHead;
                            mClrGcFlag(cGcDownstrHmb);
                            mSetGcFlag(cBrkBgdGcF);
                            break;
                        }
#endif/* if _EN_PROGFAILLOG */

                        while(rmChkBopBz)
                            ;

                        WORD u16BufIdx=u16RbufPtr>>5;
                        WORD u16Loop=cHmbChunkSctrSize>>5;

                        while(u16Loop)
                        {
#if _EN_RAID_GC
                            rmSetBufRaid32Sts(u16BufIdx, 0xFFFFFFFF);    // 64k alignment
#else
                            rmSetBuf32Sts(u16BufIdx, 0xFFFFFFFF);    // 64k alignment
#endif
                            u16BufIdx++;
                            u16Loop--;
                        }

#if _EN_RAID_GC

                        if(mChkGcFlag(cGcDownstrHmbRaidParity))
                        {
                            mClrGcFlag(cGcDownstrHmbRaidParity);
                            chkTrigHmbPtyQue();
                        }
#endif
                        mClrGcFlag(cGcDownstrHmb);
                        mWaitHmbTransferDone();
                    }

                    while(gsRwCtrl.u32ProgFifoTail!=gsRwCtrl.u32ProgFifoHead)
                        ;

                    u16RbufPtr=u16WbufPtr=c16CopySIdx;
                    gsGcInfo.u32GcDesbFreePagePtr+=gsRwCtrl.u16ProgPageOfst;
                    gsRwCtrl.u16ProgPageOfst=0;
                    gsRwCtrl.u32SrchFifoPtr=gsRwCtrl.u32UpdFifoPtr=gsRwCtrl.u32ProgFifoTail;

                    if((uChkBreakGC&&!gsHmbInfo.uHmbEnGcCache)||(gsHmbInfo.uHmbEnGcCache&&!gsGcInfo.uHmbGcCachePtr))
                    {
                        if(!mChkGcFlag(cBrkBgdGcF))
                        {
                            getBrkBgdGcF();
                        }

#if _GREYBOX
                        chkGreyBoxGc(4);
#endif
                        uChkBreakGC=0;
                    }

                    if(mGetGcState==cGcMoveData)
                    {
                        if(!mChkGcFlag(cBrkBgdGcF))
                        {
                            if(!gsHmbInfo.uHmbEnGcCache)
                            {
                                u16TotalGc4kCnt=gsGcInfo.u32Prog4kCntPerChPg*gsGcInfo.uGCDesPagePerWL;
                            }
                            else
                            {
                                if(mChkGcFlag(cUnderBgdGc))
                                {
                                    u16TotalGc4kCnt=gsGcInfo.u32Prog4kCntPerChPg*gsGcInfo.uGCDesPagePerWL;
                                }
                                else
                                {
                                    u16TotalGc4kCnt=gsGcInfo.u32Prog4kCntPerChPg*gsGcInfo.uGCDesPagePerWL*cMaxHmbGcCacheNum;
                                }

                                gsGcInfo.u16HmbGcCache4kCnt=u16TotalGc4kCnt;
                            }
                        }
                    }
                    else
                    {
#if (_EN_GCPWR&&(!_EN_RAID_GC))
                        bopClrRam((LWORD)g32arGcInvaildPageBimap, c16RaidBufSize, 0x00000000, cClrTsb|cBopWait);
#else
                        bopClrRam((LWORD)&g32GcSkipSrcHblkSrch, c16MaxH2fTabNum/8, 0x00000000, cClrTsb|cBopWait);
#endif
                    }

                    if(mGetGcFlow==cGcFlowS2S)
                    {
                        gsRwCtrl.u32SeqRdFlag|=cBit2;

                        while(gsRwCtrl.u32SeqRdFlag&cBit2)
                            ;
                    }
                }

                chkExitGcCondition();    // 20190802_Louis
            }

            gsGcInfo.u32GcLastX2TMoveDataTime+=chkRtc32kProcTime(u32Temp);

            if(mGetGcState==cGcFlushH2F)
            {
#if (C_Log_SaveMask&C_Debug_P1)
                NLOG(cLogGC, GCCACHEB_C, 0, "GC state cGcMoveData Finish!");
#endif
            }
        }

#if (_EN_GCPWR&&(!_EN_RAID_GC))

        if((gsGcInfo.uGcState==cGcPostWriteRead)&&!mChkGcFlag(cBrkBgdGcF))
        {
            u32Temp=getRtcCurrent32k();
            waitAllChCeBzCore0();

            while(gsGcInfo.uGcDesF2hTabPWRBank<gsGcInfo.uGCDesF2hBankNum)
            {
                gsGcInfo.uGcBrkPwr=0;
                chkPostWriteRead(gsGcInfo.uGcDesF2hTabPWRBank);

                while(gsTskFifoCtrl.u32HeadPtr!=gsTskFifoCtrl.u32TailPtr)
                {
                    if((gsGcInfo.uGcBrkPwr==0)&&getBrkBgdGcF())
                    {
                        gsGcInfo.uGcBrkPwr=1;
                    }
                }

                if(!mChkGcFlag(cBrkBgdGcF))
                {
                    gsGcInfo.uGcDesF2hTabPWRBank++;
                }
                else
                {
                    break;
                }
            }

            while(gsTskFifoCtrl.u32HeadPtr!=gsTskFifoCtrl.u32TailPtr)
                ;

            // gsGcInfo.u32GcLastX2TPostWRTime+=(rmGetRtc32kTick-u32Temp);
            gsGcInfo.u32GcLastX2TPostWRTime+=chkRtc32kProcTime(u32Temp);

            if(gsGcInfo.uGcDesF2hTabPWRBank==gsGcInfo.uGCDesF2hBankNum)
            {
                mSetGcState(cGcFlushH2F);
                bopClrRam((LWORD)&g32GcSkipSrcHblkSrch, c16MaxH2fTabNum/8, 0x00000000, cClrTsb|cBopWait);
            }
        }
#endif/* if (_EN_GCPWR&&(!_EN_RAID_GC)) */

#if _EN_CHK_FINGER_FAIL

        if(!mChkGcFlag(cBrkBgdGcF))
        {
            getBrkBgdGcF();
        }

        /* Here to check finger fail failure */
        if((mGetGcState==cGcChkFingerFail)&&!mChkGcFlag(cBrkBgdGcF))
        {
            if((mChkMlcMoBit(gsGcInfo.u16GcDesBlock))&&(chkFingerFailCore0()==cFail))
            {
                /* swap active block, data is keeped in original source block */
                break;
            }
            else
            {
                mSetGcState(cGcFlushH2F);
                bopClrRam((LWORD)&g32GcSkipSrcHblkSrch, c16MaxH2fTabNum/8, 0x00000000, cClrTsb|cBopWait);
            }
        }
        /**************************************/
#endif/* #if _EN_CHK_FINGER_FAIL */

        if((mGetGcState==cGcFlushH2F)&&!mChkGcFlag(cBrkBgdGcF))
        {
            u32Temp=getRtcCurrent32k();
            flushGcDesF2hTab();
            // gsGcInfo.u32GcLastX2TFlushF2hTabTime+=(rmGetRtc32kTick-u32Temp);
            gsGcInfo.u32GcLastX2TFlushF2hTabTime+=chkRtc32kProcTime(u32Temp);

            if(gsGcInfo.uGcDesF2hTabUpdBank==gsGcInfo.uGCDesF2hBankNum)
            {
#if _GREYBOX

                if(gsGbInfo.uGreyBoxItem==cRAIDDecOnMoveReadData)
                {
                    gsGbInfo.uResult=cSuccess;
                }
                else if(((gsGbInfo.uGreyBoxItem==cGCS2TThree2OneFull)&&(mGetGcFlow==cGcFlowS2T))||
                        (((gsGbInfo.uGreyBoxItem==cGCT2TX2OneNotFull)||(gsGbInfo.uGreyBoxItem==cGCT2TSixteen2OneMoreFull))&&
                         (mGetGcFlow==cGcFlowT2T))||((gsGbInfo.uGreyBoxItem==cGCS2SThirtytwo2OneNotFull)&&(mGetGcFlow==cGcFlowS2S)))
                {
                    gsGbInfo.uResult=cSuccess;
                }
#endif

                gcDesBlkFullSettingCore0();
#if 0    // _EN_FW_DEBUG_UART //Chief_Disable Log_20181123
                NLOG(cLogGC, GCCACHEB_C, 0, "Gc Done!!");
                NLOG(cLogGC, GCCACHEB_C, 1, "gsCacheInfo.u16SLCSpareCnt: 0x%04X ", gsCacheInfo.u16SLCSpareCnt);
                NLOG(cLogGC, GCCACHEB_C, 1, "gsCacheInfo.u16DynamicSpareCnt: 0x%04X ", gsCacheInfo.u16DynamicSpareCnt);
                NLOG(cLogGC, GCCACHEB_C, 1, "gsCacheInfo.u16FullCacheBlockCnt: 0x%04X ", gsCacheInfo.u16FullCacheBlockCnt);
                NLOG(cLogGC, GCCACHEB_C, 1, "gsCacheInfo.u16TLCFullCacheBlockCnt: 0x%04X ", gsCacheInfo.u16TLCFullCacheBlockCnt);
                NLOG(cLogGC, GCCACHEB_C, 1, "gsGcInfo.u32GcCachebTime: 0x%04X ", gsGcInfo.u32GcCachebTime);
#endif

                if(mGetGcState==cGcStateIdle)
                {
#if (C_Log_SaveMask&C_Debug_P1)
                    NLOG(cLogGC, GCCACHEB_C, 0, "GC state cGcFlushH2F Finish!");
#endif
                }
            }
        }

        // rstRdyTyp();
    }
    while((getBrkBgdGcF()!=cTrue)&&(chkExitGcProc()!=cTrue));

    endOfBgdClnCacheblkProc();
#if _GREYBOX
    chkGreyBoxGc(2);
#endif/* if _GreyBox */
#if (C_Log_SaveMask&C_Debug_P1)
    NLOG(cLogGC, GCCACHEB_C, 0, "GC End");
#endif
}    /* bgdClnCacheblkProc */

void flushGcDesF2hTab()
{
    BYTE uGcDesF2hTabUpdBank, uH2fTabIdx, uH2fTabCnt, uGcDesF2hTabBankBuf=0xFF;
    WORD u16Hblock, u16arH2fTab[4];
    F2HTABLE *upDesF2hTab, *upEofDesF2hTab;

    // gsCacheInfo.u15ActiveH2fTab=c15BitFF;
#if _EN_VPC_SWAP
    g32arCacheBlkVpCnt=(volatile LWORD *)(cCacheBlkVpCntGCFlushStrAddr);
    readWproPageCore0(cWproCacheBlkVpCnt, cCacheBlkVpCntGCFlushStrIdx, 0);
#endif

    while((gsGcInfo.uGcDesF2hTabUpdBank<gsGcInfo.uGCDesF2hBankNum)&&(getBrkBgdGcF()!=cTrue))
    {
        if(uGcDesF2hTabBankBuf!=gsGcInfo.uGcDesF2hTabUpdBank)
        {
            loadGcInfoTab(cWproGcDesF2hTab00+gsGcInfo.uGcDesF2hTabUpdBank, c16GcFlushF2hIdx, cBit6);    // , cWaitReadDone);
            uGcDesF2hTabBankBuf=gsGcInfo.uGcDesF2hTabUpdBank;
        }

        uH2fTabCnt=0;
        upDesF2hTab=gsGcInfo.upFlushDesF2hTabSt;
        upEofDesF2hTab=(F2HTABLE *)c16GcFlushF2hAddr-1;

        while(upDesF2hTab!=upEofDesF2hTab)
        {
            u16Hblock=upDesF2hTab->u16HBlock&~c16Bit15;
            upDesF2hTab--;

            if((u16Hblock!=c15BitFF)&&!mChkSkipGcSrcHblkSrch(u16Hblock))
            {
                mSetSkipGcSrcHblkSrch(u16Hblock);
                u16arH2fTab[uH2fTabCnt]=u16Hblock;

                if(g16arH2fTabPtr[u16Hblock]!=c16BitFF)
                {
                    readH2fTable(c16Tsb0SIdx+(uH2fTabCnt<<gGCH2fTabShiftSize), u16Hblock, c16Bit0|c16Bit4|c16Bit15, 0);
                }
                else
                {
                    bopClrRam(c32Tsb0SAddr+(c16Tsb0SIdx+(uH2fTabCnt<<gGCH2fTabShiftSize))<<9, (LWORD)g16PagePerH2fTab<<2, cUncTypeMask,
                              cClrTsb|cBopWait);
                }

                uH2fTabCnt++;

                if(uH2fTabCnt>=(c16FlushGcDesF2hSctrSize/g16H2fTabSctrSize))
                {
                    break;
                }
            }
        }

        mWaitHmbTransferDone();

        while((gsRwCtrl.u32FreeSrcFifoTail!=gsRwCtrl.u32FreeSrcFifoHead)||g32DecodeWait)
            ;

        uGcDesF2hTabUpdBank=gsGcInfo.uGcDesF2hTabUpdBank;

        for(uH2fTabIdx=0; uH2fTabIdx<uH2fTabCnt; uH2fTabIdx++)
        {
            // uGcDesF2hTabUpdBank=gsGcInfo.uGcDesF2hTabUpdBank;

            // do
            while(uGcDesF2hTabUpdBank<gsGcInfo.uGCDesF2hBankNum)
            {
                if(uGcDesF2hTabBankBuf!=uGcDesF2hTabUpdBank)
                {
                    loadGcInfoTab(cWproGcDesF2hTab00+uGcDesF2hTabUpdBank, c16GcFlushF2hIdx, cBit6);    // , cWaitReadDone);
                    uGcDesF2hTabBankBuf=uGcDesF2hTabUpdBank;
                }

                if(popGcDesF2hTab(u16arH2fTab[uH2fTabIdx],
                                  gsGcInfo.u16GCDesTotalPgPerF2hTab-1+(uGcDesF2hTabUpdBank*gsGcInfo.u16GCDesTotalPgPerF2hTab),
                                  c16Tsb0SIdx+(uH2fTabIdx<<gGCH2fTabShiftSize), c16GcFlushF2hIdx))
                {
                    break;
                }

                uGcDesF2hTabUpdBank++;
            }

            // while(uGcDesF2hTabUpdBank<gsGcInfo.uGCDesF2hBankNum);
        }

        if((gsCacheInfo.u16H2fTabFreePagePtr+uH2fTabCnt)>=gsCacheInfo.u16H2fTabPagePerBlk3)
        {
            mSetGcFlag(cGcSkipPrgCacheInfo);
        }
        else
        {
            mClrGcFlag(cGcSkipPrgCacheInfo);
        }

        for(uH2fTabIdx=0; uH2fTabIdx<uH2fTabCnt; uH2fTabIdx++)
        {
            mSetCacheInfoChangeFlag(cH2fChg);

            if(mChkHmbLink(u16arH2fTab[uH2fTabIdx]))
            {
#if _ENABLE_HMB_FLUSH

                while(mChkHmbTabDirty(mGetHmbLink(u16arH2fTab[uH2fTabIdx])))
                    ;
#endif
                remHmbLink(u16arH2fTab[uH2fTabIdx]);
                progH2fTableCore0(c16Tsb0SIdx+(uH2fTabIdx<<gGCH2fTabShiftSize),
                                  u16arH2fTab[uH2fTabIdx],
                                  c16Bit0|c16Bit2|c16Bit15,
                                  cInflushTlcF2hTab_00,
                                  0);
#if _EN_HMB    // &&(!_PRJ_BOOT||_ICE_LOAD_ALL))

                if(gsHmbInfo.uHmbEnable)    // &&(gsHmbInfo.usHmbList.u16Cnt<c16HmbMaxTableNum))
                {
                    writeHmbH2fTab(c16Tsb0SIdx+(uH2fTabIdx<<gGCH2fTabShiftSize), u16arH2fTab[uH2fTabIdx], 0);
#if _GREYBOX

                    if((gsGbInfo.uGreyBoxItem==cUGSDS2TID)&&(gsGbInfo.uGreyBoxOpt==cVOpProgH2fonHmb))
                    {
                        triggerUGSD(cFalse);
                    }
                    else if((gsGbInfo.uGreyBoxItem==cUGSDT2TID)&&(gsGbInfo.uGreyBoxOpt==cVOpProgH2fonHmb)&&(mGetGcFlow==cGcFlowT2T))
                    {
                        triggerUGSD(cFalse);
                    }
                    else if((gsGbInfo.uGreyBoxItem==cUGSDS2SID)&&(gsGbInfo.uGreyBoxOpt==cVOpProgH2fonHmb)&&(mGetGcFlow==cGcFlowS2S))
                    {
                        triggerUGSD(cFalse);
                    }
#endif
                }
#endif/* if _EN_HMB */
            }
            else
            {
#if _GREYBOX

                if((gsGbInfo.uGreyBoxOpt==cVOpProgH2fxHmb)&&(gsGbInfo.uStag==cVsIdl))
                {
                    if((gsGbInfo.uGreyBoxItem==cUGSDS2TID)&&(gsGcInfo.uGcDesF2hTabUpdBank))
                    {
                        trigGreyBox(cTrue);
                    }
                    else if(gsGbInfo.uGreyBoxItem==cUGSDReclaimID)
                    {
                        if((mChkGcSrcBlkBmap(*(WORD *)(c32GreyBoxBuf+cGbInfoReclimFBlk1)))||
                           (mChkGcSrcBlkBmap(*(WORD *)(c32GreyBoxBuf+cGbInfoReclimFBlk2)))||
                           (mChkGcSrcBlkBmap(*(WORD *)(c32GreyBoxBuf+cGbInfoReclimFBlk3))))
                        {
                            trigGreyBox(cTrue);
                        }
                    }
                    else if((gsGbInfo.uGreyBoxItem==cUGSDT2TID)&&(gsGcInfo.uGcDesF2hTabUpdBank)&&(mGetGcFlow==cGcFlowT2T))
                    {
                        trigGreyBox(cTrue);
                    }
                    else if((gsGbInfo.uGreyBoxItem==cUGSDS2SID)&&(mGetGcFlow==cGcFlowS2S))
                    {
                        trigGreyBox(cTrue);
                    }
                }
#endif/* if (_GREYBOX) */
                progH2fTableCore0(c16Tsb0SIdx+(uH2fTabIdx<<gGCH2fTabShiftSize),
                                  u16arH2fTab[uH2fTabIdx],
                                  c16Bit0|c16Bit2|c16Bit15,
                                  cInflushTlcF2hTab_00,
                                  0);
            }
        }

        mWaitHmbTransferDone();
        waitProgH2fTxDataCore0();

        if(mChkGcFlag(cGcSkipPrgCacheInfo))
        {
#if _EN_VPC_SWAP
            progWproPageCore0(cWproCacheBlkVpCnt, cCacheBlkVpCntGCFlushStrIdx|c16Bit15);
#endif
            // waitAllChCeBzCore0(); // wait in progCacheInfoTab()
            progCacheInfoTab();
            mClrGcFlag(cGcSkipPrgCacheInfo);
        }

        if(uGcDesF2hTabUpdBank!=gsGcInfo.uGcDesF2hTabUpdBank)
        {
            gsGcInfo.upFlushDesF2hTabSt=(F2HTABLE *)c16GcFlushF2hAddr+(gsGcInfo.u16GCDesTotalPgPerF2hTab-1);
            gsGcInfo.uGcDesF2hTabUpdBank=uGcDesF2hTabUpdBank;
        }
        else if(upDesF2hTab==upEofDesF2hTab)
        {
            gsGcInfo.upFlushDesF2hTabSt=(F2HTABLE *)c16GcFlushF2hAddr+(gsGcInfo.u16GCDesTotalPgPerF2hTab-1);
            gsGcInfo.uGcDesF2hTabUpdBank++;
        }
        else
        {
            gsGcInfo.upFlushDesF2hTabSt=upDesF2hTab;
        }

#if _GREYBOX
        chkGreyBoxGc(4);
#endif
    }

#if _EN_Liteon_ErrHandle    // 20190618_Louis_01
    BYTE uSrcBlkIdx;
    LWORD u32VpcPerBlk;

    if(gsGcInfo.uGcDesF2hTabUpdBank==gsGcInfo.uGCDesF2hBankNum)
    {
        if(mGetGcFlow==cGcFlowS2S)
        {
            u32VpcPerBlk=g32VpcPerSlcBlk;
        }
        else
        {
            u32VpcPerBlk=g32VpcPerTlcBlk;
        }

        if((gsGcInfo.u32TotalSrcBlkVpc<u32VpcPerBlk)||(gGCOpt&gbGCSrcVpcChk))
        {
            for(uSrcBlkIdx=0; uSrcBlkIdx<cMaxGcSrcBlkNum; uSrcBlkIdx++)
            {
                if((gsGcInfo.u16GcSrcBlock[uSrcBlkIdx]!=cInvldFBlk)&&(mGetCacheBlkVpCnt(gsGcInfo.u16GcSrcBlock[uSrcBlkIdx]&c15BitFF)))
                {
                    NLOG(cLogTempDebug,
                         GCCACHEB_C,
                         7,
                         "1. Vpc need to rebuild! mGetGcFlow=0x%04x, blk[0x%04x]=0x%04x, Vpc=0x%08x, u32VpcPerBlk=0x%08x",
                         mGetGcFlow,
                         uSrcBlkIdx,
                         (gsGcInfo.u16GcSrcBlock[uSrcBlkIdx]&c15BitFF),
                         (mGetCacheBlkVpCnt(gsGcInfo.u16GcSrcBlock[uSrcBlkIdx]&c15BitFF))>>16,
                         (mGetCacheBlkVpCnt(gsGcInfo.u16GcSrcBlock[uSrcBlkIdx]&c15BitFF)),
                         u32VpcPerBlk>>16,
                         u32VpcPerBlk);
#if _EN_KEEP_RW_ON_ERROR
                    gGCOpt|=gbGCVpcMismatch;
#else
                    debugLoop(c32VpcMismatch);
#endif
                    break;
                }
            }

            gGCOpt&=~gbGCSrcVpcChk;
        }

        if((gGCOpt&gbGCVpcMismatch)&&!(gJdgBootGCFlag&cVpcNeedRebuild))
        {
            NLOG(cLogGC, GCCACHEB_C, 0, "GC Vpc need to rebuild!");
            gJdgBootGCFlag|=cVpcNeedRebuild;
        }
    }
#endif/* if _EN_Liteon_ErrHandle */

#if _EN_VPC_SWAP
    mWaitHmbTransferDone();
    // prevent swap WPRO ram overwrite
    bopCopyRam(cCacheBlkVpCntEndGCFlushStrAddr,
               (LWORD)g32arCacheBlkVpCnt,
               c32CacheBlkVpCntVarSize,
               cCopyTsb2Tsb|cBopWait);
    g32arCacheBlkVpCnt=(volatile LWORD *)(cCacheBlkVpCntEndGCFlushStrAddr);
    progWproPageCore0(cWproCacheBlkVpCnt, cCacheBlkVpCntEndGCFlushStrIdx);
#endif/* if _EN_VPC_SWAP */

    if(mChkGcFlag(cUnderBgdGc))
    {
        waitHmbPrdDone();
    }
}    /* flushGcDesF2hTab */

BYTE popGcDesF2hTab(WORD u16Hblock, LWORD u32F4kBase, WORD u16H2fBufIdx, WORD u16F2hBufIdx)
{
    BYTE uSearchFinish, uFlag;
    WORD u16OrgFblk, u16StartUnit, u16UnitLen=gsGcInfo.u16GCDesTotalPgPerF2hTab, u16FirstStartUnit, u16PrevOrgFblk=c16FBlockInitValue,
         u16PrevOrgFblkVpc=0;
    LWORD u32FMapG=mSetH2fSrcFAddr(gsGcInfo.u16GcDesBlock, 0), u32GcDesBlkVpc=0, u32F4kBase2, u32Hblock=u16Hblock<<16;
    UCLWORD *u32pF2hTabSt=(UCLWORD *)garTsb0[u16F2hBufIdx], *u32pF2hTab, *u32pH2FTabSt=(UCLWORD *)garTsb0[u16H2fBufIdx], *u32pH2FTab;

    if(bopSrchRam((LWORD)u32pF2hTabSt, u32Hblock, 0xFFFF0000, 0, u16UnitLen, cBopSrchDat|cBopLwordMo|cBopWait|cBopNotRstFlag)!=c16BitFF)
    {
        u16FirstStartUnit=rmGetSrchRslOfst;

        do
        {
            u16StartUnit=rmGetSrchRslOfst;
#if (_EN_GCPWR&&(!_EN_RAID_GC))
            u32F4kBase2=u32F4kBase-u16StartUnit;
#else
            u32F4kBase2=u32FMapG|(u32F4kBase-u16StartUnit);
#endif
            u32pF2hTab=u32pF2hTabSt+u16StartUnit;

            do
            {
                u16StartUnit++;

                if(u16StartUnit<u16UnitLen)
                {
                    if((*(u32pF2hTab+1)&0xFFFF0000)==u32Hblock)
                    {
                        uFlag=cTrue;
                    }
                    else
                    {
                        rmSetBopDesAddr(u16StartUnit);
                        rmTrigBopOpWoPause(cBopSrchOp);
                        uFlag=cFalse;
                    }
                }
                else
                {
                    uFlag=cFalse;
                }

                u32pH2FTab=u32pH2FTabSt+(WORD)*u32pF2hTab;
                u16OrgFblk=mGetSrcFBlkAddr(*u32pH2FTab);

                if((u16OrgFblk!=c16FBlockInitValue)&&mChkGcSrcBlkBmap(u16OrgFblk))
                {
#if (_EN_GCPWR&&(!_EN_RAID_GC))

                    if(!mGetInvalidGcDesPage((u32F4kBase2/g4kNumPerPlane)))
#else

                    if(1)
#endif
                    {
                        if(u16PrevOrgFblk!=u16OrgFblk)
                        {
                            if(u16PrevOrgFblk!=c16FBlockInitValue)
                            {
                                g32arCacheBlkVpCnt[u16PrevOrgFblk]-=u16PrevOrgFblkVpc;

                                if(!mGetCacheBlkVpCnt(u16PrevOrgFblk))
                                {
                                    setZeroVpcBlock(u16PrevOrgFblk);
#if _EN_FW_DEBUG_UART
                                    NLOG(cLogGC, GCCACHEB_C, 1, "zero VPC source block: 0x%04X ", u16PrevOrgFblk);
#endif
                                }
                            }

                            u16PrevOrgFblk=u16OrgFblk;
                            u16PrevOrgFblkVpc=1;
                        }
                        else
                        {
                            u16PrevOrgFblkVpc++;
                        }

#if (_EN_GCPWR&&(!_EN_RAID_GC))
                        *u32pH2FTab=(*u32pH2FTab&(c32Bit30|c32Bit31))|u32FMapG|u32F4kBase2;
#else
                        *u32pH2FTab=(*u32pH2FTab&(c32Bit30|c32Bit31))|u32F4kBase2;
#endif
                        u32GcDesBlkVpc++;
                    }
                    else
                    {
                        gsGcInfo.u32PWRFailCnt++;
                    }
                }

                u32pF2hTab++;
                u32F4kBase2--;
            }
            while(uFlag!=cFalse);

            while(rmChkBopBz)
                ;
        }
        while(rmChkSrchValFind&&(u16StartUnit<u16UnitLen));

        if(u16PrevOrgFblkVpc)
        {
            g32arCacheBlkVpCnt[u16PrevOrgFblk]-=u16PrevOrgFblkVpc;

            if(!mGetCacheBlkVpCnt(u16PrevOrgFblk))
            {
                setZeroVpcBlock(u16PrevOrgFblk);
#if _EN_FW_DEBUG_UART
                NLOG(cLogGC, GCCACHEB_C, 1, "zero VPC source block: 0x%04X ", u16PrevOrgFblk);
#endif
            }
        }

#if _EN_RAID_GC

        if(u16FirstStartUnit!=(gsGcInfo.uGCDes4KNumOfF2hTab+c4kNumPerRaidPty))
#else

        if(u16FirstStartUnit!=gsGcInfo.uGCDes4KNumOfF2hTab)
#endif
        {
            uSearchFinish=cTrue;
        }
        else
        {
            uSearchFinish=cFalse;
        }
    }
    else
    {
        uSearchFinish=cTrue;
    }

    rmSetSrchDefault;
    g32arCacheBlkVpCnt[gsGcInfo.u16GcDesBlock]+=u32GcDesBlkVpc;

#if _EN_VPC_SWAP

    if(g32arCacheBlkVpCnt[gsGcInfo.u16GcDesBlock])
    {
        mSetVPCntValid(gsGcInfo.u16GcDesBlock);
    }
#endif

    if(mGetGcFlow==cGcFlowS2T)
    {
        gsGcInfo.u32TotalSlcVpc-=u32GcDesBlkVpc;
        gsGcInfo.u32TotalTlcVpc+=u32GcDesBlkVpc;
    }

    return uSearchFinish;
}    /* popGcDesF2hTab */

/*
   * void initGcProc(void)
   * {
   *  mSetGcState(cGcBuildSrc);
   *  gsGcInfo.uGcSrcF2hTabBank=0;
   *  gsGcInfo.u16GcSrcStUnit=0;
   *  gsGcInfo.uGcDesF2hTabBank=0;
   *  gsGcInfo.uGcDesF2hTabUpdBank=0;
   *  gsGcInfo.uGcDesF2hTabBuildBank=0;
   *  gsGcInfo.u16PwrStrPage=0;
   *  gsGcInfo.uGcDesF2hTabPWRBank=0;
   *
   *  while(gsGcInfo.uGcSrcBlkCnt)
   *      ;
   *
   *  gsGcInfo.u16GcIncompleteSrchFblk=cInvldFBlk;
   *  gsGcInfo.u16GcIncompleteSrchHblk=0xFFFF;
   *  gsGcInfo.u16GcIncompleteSrchHpg=0xFFFF;
   *  gsGcInfo.uGcIncompleteSrchSrcBlkPtr=0xFF;
   *
   *  // bopClrRam((LWORD)&g32GcS2tH2fSkpSrcHblkSrch, c16MaxH2fTabNum/8, 0x00000000, cClrTsb|cBopWait);
   *
   *  gsGcInfo.u16GcPwReadPagePtr=0;
   *  gsGcInfo.u16GcDesF2hUpdSrcStUnit=0;
   *  gsGcInfo.u32GcSrcF4kPtr=0;
   *  gsGcInfo.u32GcDesF4kPtr=0;
   *  // gsGcInfo.u16GcDesF2hTabFreePtr=g16TotalTlcPgPerF2hTab-1;
   *  // gsGcInfo.u16SrcHandlePage=gsGcInfo.u16DesHandlePage=0;
   *  gsGcInfo.u16GcOneShotPtr=0;
   *  gsGcInfo.uGcIntlvPtr=0;
   *  gsGcInfo.uSrcHandlePageType=0;
   *  gsGcInfo.uLoadGCTabIdx=0;
   *
   *  if((mGetGcFlow==cGcFlowS2T)||(mGetGcFlow==cGcFlowS2S))
   *  {
   *      gsGcInfo.uTotalBankOfF2hTab=gTotalBankOfF2hTab;
   *  }
   *  else
   *  {
   *      gsGcInfo.uTotalBankOfF2hTab=gTotalTlcBankOfF2hTab;
   *  }
   * } */   /* initGcProc */

void endOfBgdClnCacheblkProc(void)
{
    waitAllChCeBzCore0();

#if _EN_PROGFAILLOG

    while(gsTskFifoCtrl.u32HeadPtr!=gsTskFifoCtrl.u32TailPtr)
        ;
#endif

    if(mChkGcFlag(cGcForceClean))
    {
        // mClrGcFlag(cGcForceClean);
        gsFtlDbg.u32ForceCleanCnt++;
    }

    // addRrBufPtr=addReadBufPtr;

    if(mChkGcFlag(cBrkBgdGcF))
    {
        mClrGcFlag(cBrkBgdGcF);
    }

    if(mChkGcFlag(cGcDesFailAbort))
    {
        if(gsGcInfo.uGcDesBlkCnt)
        {
#if _EN_RAID_GC
            rstRaidEngVarCore0(cRaidGcBlk);
#endif
            gcDesBlkFullSettingCore0();
        }

        mClrGcFlag(cGcDesFailAbort);
        gsRwCtrl.u32FreeSrcFifoTail=gsRwCtrl.u32FreeSrcFifoTrig=gsRwCtrl.u32FreeSrcFifoHead;
        gsRwCtrl.u32SrchFifoPtr=gsRwCtrl.u32UpdFifoPtr=gsRwCtrl.u32ProgFifoTail=gsRwCtrl.u32ProgFifoTrig=gsRwCtrl.u32ProgFifoHead;
        gsRwCtrl.usSrcCmdList.u16Cnt=0;
        gsRwCtrl.u16ProgPageOfst=0;
        gsGcInfo.uHmbGcCachePtr=0;
        gsGcInfo.uHmbGcCacheCnt=0;
        gsGcInfo.u16HmbGcCache4kCnt=0;
        gsGcInfo.u16GcDesPfBlock=c16FBlockInitValue;
        rmResetBufFlg;
        rmResetRaidFlg;
    }

#if _EN_RAID_GC
    chkHmbStsChg();
#endif

    chkPushSpareQCore0(0);
    // mClrInGcFlow;
    // restoOneShotChPtr();
    rstRdyTyp();
    mClrGcFlag(cUnderFgdGc);
}    /* endOfBgdClnCacheblkProc */

void initGCDesVariable()
{
    if(mGetGcFlow==cGcFlowS2S)
    {
        gsGcInfo.uGCDesPagePerWL=1;
        gsGcInfo.uGCDesF2hBankNum=gTotalBankOfF2hTab;
        gsGcInfo.u16GcDesF2hTabFreePtr=g16TotalPgPerF2hTab-1;
        gsGcInfo.uGCDes4KNumOfF2hTab=gTotal4kNumOfF2hTab;
        gsGcInfo.u16GCDesValidPgPerF2hTab=g16ValidPgPerF2hTab;
        gsGcInfo.u16GCDesTotalPgPerF2hTab=g16TotalPgPerF2hTab;

        gsGcInfo.uGCDesPadF2h4KNum=gSlcPadF2h4KNum;
        gsGcInfo.uGCDesProgF2HRem4KNum=gSlcProgF2HRem4KNum;
        gsGcInfo.u16ProgRaidChStr4K=g16SlcProgRaidChStr4K;
        gsGcInfo.u16PadF2hTabPgStr=g16SlcPadF2hTabPgStr;
        gsGcInfo.u16PadF2hTabPgEnd=g16SlcPadF2hTabPgEnd;
        gsGcInfo.u16ProgF2hTabStr=g16SlcProgF2hTabStr;
        gsGcInfo.u16ProgF2hTabEnd=g16SlcProgF2hTabEnd;

#if _EN_RAID_GC
        gsCacheInfo.u16PartialParityNumGc=g16SlcPartialParityNum;
        gsGcInfo.u16GCDesProgRaidChStr4K=g16SlcProgRaidChStr4K;
        gsGcInfo.u16RaidStrAddr=g16SlcRaidStrAddr[0];
#endif
    }
    else
    {
        gsGcInfo.uGCDesPagePerWL=cProgCntPerWL;
        gsGcInfo.uGCDesF2hBankNum=gTotalTlcBankOfF2hTab;
        gsGcInfo.u16GcDesF2hTabFreePtr=g16TotalTlcPgPerF2hTab-1;
        gsGcInfo.uGCDes4KNumOfF2hTab=gTlcTotal4kNumOfF2hTab;
        gsGcInfo.u16GCDesValidPgPerF2hTab=g16TlcValidPgPerF2hTab;
        gsGcInfo.u16GCDesTotalPgPerF2hTab=g16TotalTlcPgPerF2hTab;

        gsGcInfo.uGCDesPadF2h4KNum=gTlcPadF2h4KNum;
        gsGcInfo.uGCDesProgF2HRem4KNum=gTlcProgF2HRem4KNum;
        gsGcInfo.u16ProgRaidChStr4K=g16TlcProgRaidChStr4K;
        gsGcInfo.u16PadF2hTabPgStr=g16PadF2hTabPgStr;
        gsGcInfo.u16PadF2hTabPgEnd=g16PadF2hTabPgEnd;
        gsGcInfo.u16ProgF2hTabStr=g16ProgF2hTabStr;
        gsGcInfo.u16ProgF2hTabEnd=g16ProgF2hTabEnd;

#if _EN_RAID_GC
        gsCacheInfo.u16PartialParityNumGc=g16TlcPartialParityNum;
        gsGcInfo.u16GCDesProgRaidChStr4K=g16TlcProgRaidChStr4K;
        gsGcInfo.u16RaidStrAddr=g16RaidStrAddr[0];
#endif
    }

#if _EN_RAID_GC
    WORD u16ParityIdx, u16RaidPty;
    BYTE uRaidBlkIdx, uPageSel;

    if(gsCacheInfo.u16PartialParityNumGc<((g16SlcPartialParityNum>g16TlcPartialParityNum)?g16SlcPartialParityNum:g16TlcPartialParityNum))
    {
        u16ParityIdx=gsCacheInfo.u16PartialParityNumGc;

        while(u16ParityIdx<(cRaidParityPageNum/gsGcInfo.uGCDesPagePerWL))
        {
            for(uPageSel=0; uPageSel<gsGcInfo.uGCDesPagePerWL; uPageSel++)
            {
                u16RaidPty=u16ParityIdx*gsGcInfo.uGCDesPagePerWL+uPageSel;

                if(g16arRaidParityPtr[u16RaidPty]!=c16RaidPtrInitValue)
                {
                    uRaidBlkIdx=mGetRaidPtyBlkIndex(u16RaidPty);

                    while(!g16arRaidPtyBlkVpCnt[uRaidBlkIdx])
                        ;

                    g16arRaidPtyBlkVpCnt[uRaidBlkIdx]--;

                    if((!g16arRaidPtyBlkVpCnt[uRaidBlkIdx])&&(uRaidBlkIdx!=gsCacheInfo.uRaidGcPtyBlkIdx))
                    {
                        pushRaidPtyBlkCore0(uRaidBlkIdx);
#if _EN_FW_DEBUG_UART
                        NLOG(cLogRAID,
                             GCCACHEB_C,
                             2,
                             "g16arRaidParityBlk[0x%04X]: 0x%04X ",
                             uRaidBlkIdx,
                             g16arRaidParityBlk[uRaidBlkIdx]);
#endif
                    }

                    g16arRaidParityPtr[u16RaidPty]=c16RaidPtrInitValue;
                }
            }

            u16ParityIdx++;
        }
    }
#endif/* if _EN_RAID_GC */

    gsGcInfo.uMaxHmbGcCacheNum=gsGcInfo.u32Prog4kCntPerChPg*gsGcInfo.uGCDesPagePerWL*cSctrPer4k*cMaxHmbGcCacheNum/cHmbChunkSctrSize;
    gsGcInfo.u32Prog4kCntPerChIntPlnWl=gTotalIntlvChNum*g4kNumPerPage*gsGcInfo.uGCDesPagePerWL;
    gsGcInfo.uPartTabSizeInBank=gsGcInfo.uGCDes4KNumOfF2hTab/g4kNumPerPlane;
    gsGcInfo.u16RemainF2h4k=((gsGcInfo.u16GCDesTotalPgPerF2hTab>>10)%g4kNumPerPlane)<<10;

    if(!gsGcInfo.u16RemainF2h4k)
    {
        gsGcInfo.u16RemainF2h4k=gsGcInfo.u16EntryInPlane;
    }

    gsGcInfo.u16DumF2h4K=gsGcInfo.u16EntryInPlane-gsGcInfo.u16RemainF2h4k;

    if(mGetGcFlow!=cGcFlowT2T)
    {
        gsGcInfo.uTotalBankOfF2hTab=gTotalBankOfF2hTab;
        gsGcInfo.u16TotalPgPerF2hTab=g16TotalPgPerF2hTab;
        gsGcInfo.u16ValidPgPerF2hTab=g16ValidPgPerF2hTab;
    }
    else
    {
        gsGcInfo.uTotalBankOfF2hTab=gTotalTlcBankOfF2hTab;
        gsGcInfo.u16TotalPgPerF2hTab=g16TotalTlcPgPerF2hTab;
        gsGcInfo.u16ValidPgPerF2hTab=g16TlcValidPgPerF2hTab;
    }

    gsGcInfo.upFlushDesF2hTabSt=(F2HTABLE *)c16GcFlushF2hAddr+(gsGcInfo.u16GCDesTotalPgPerF2hTab-1);
    gsGcInfo.upBuildSrcF2hTabSt=(F2HTABLE *)garTsb0[c16GcSrcBlk0F2hSIdx]+(gsGcInfo.u16TotalPgPerF2hTab-1);
}    /* initGCDesVariable */

// add minvpc SrcBlk, and clean related SrcSkipHtab.
//
void addNewGcSrcBlk()
{
    // LWORD u32TotalVpcOfSrcBlk=0;
    // LWORD u32DiffVPC=0;
    // WORD u16FBlk=cInvldFBlk;
    BYTE    /*uNowGcSrcBlkIdx,*/ uLp=cMaxGcSrcBlkNum, uMinSrcBlkCnt;

    // BYTE uTailPtrTemp=0;

// test by yhlin
// #if _EN_Dynamic_Fix_Boundary
//    WORD u16StartFblock=g16FirstFBlock;
//    WORD u16endFblock=g16TotalFBlock;
// #endif
// test end

    gsGcInfo.u32TotalSrcBlkVpc=0;

    if(mChkGcQue(cGcTypTLCWearLvl)&&(mGetGcFlow==cGcFlowT2T)&&(gsCacheInfo.u16TLCFullCacheBlockCnt<g16TlcFullCachebGcThr))
    {
        mSetGcFlag(cGcSrchWearF);
    }

    if(mChkGcFlag(cPwOnGcF|cPwOnExtraGcF))
    {
        if(mGetGcFlow!=cGcFlowT2T)
        {
            uMinSrcBlkCnt=4;
        }
        else
        {
            uMinSrcBlkCnt=6;
        }
    }
    else
    {
        if(mGetGcFlow!=cGcFlowT2T)
        {
            uMinSrcBlkCnt=gsGcInfo.uS2TAmpFactor;
        }
        else
        {
            uMinSrcBlkCnt=gsGcInfo.uT2TOpFactor;
        }
    }

    if(mChkGcFlag(cPwOnGcF|cPwOnExtraGcF))
    {
        gsGcInfo.uGcMaxSrcBlkCnt=uMinSrcBlkCnt;
    }
    else
    {
        gsGcInfo.uGcMaxSrcBlkCnt=1;

        while(uLp>0)
        {
            if(gsGcInfo.uGcMaxSrcBlkCnt<uMinSrcBlkCnt)
            {
                gsGcInfo.uGcMaxSrcBlkCnt<<=1;
                uLp>>=1;
            }
            else
            {
                break;
            }
        }
    }

    if(gsGcInfo.uGcMaxSrcBlkCnt>cMaxGcSrcBlkNum)
    {
        gsGcInfo.uGcMaxSrcBlkCnt=cMaxGcSrcBlkNum;
    }

#if _EN_VPC_SWAP
    g32arCacheBlkVpCnt=(volatile LWORD *)(cCacheBlkVpCntGetGCSrcStrAddr);
    readWproPageCore0(cWproCacheBlkVpCnt, cCacheBlkVpCntGetGCSrcStrIdx, 0);
#endif

    getGcSrcBlkCore0();

// =====
// move to getGcSrcBlk
#if 0

    while(gsGcInfo.uGcSrcBlkCnt<gsGcInfo.uGcMaxSrcBlkCnt)
    {
        uNowGcSrcBlkIdx=gsGcInfo.uGcSrcBlkIdx[gsGcInfo.uGcSrcBlkCnt];

        // if(mChkGcFlag(cGcSrchWearF))
        // {
        //    break;
        // }
        // else
        // {
        if((mGetGcFlow==cGcFlowS2T)||(mGetGcFlow==cGcFlowS2S))
        {
            if(mChkGcQue(cGcTypSLCWearLvl)&&(gsCacheInfo.u16SpareBlockCnt>cMinGCSprCnt)&&(uTailPtrTemp<gsGcInfo.uGCSLCWLCnt))
            {
                u16FBlk=gsGcInfo.u16GcWLSlcBlock[uTailPtrTemp];
                uTailPtrTemp++;

                if(u16FBlk==0xFFFF)
                {
                    while(1)
                        ;
                }
            }
            else
            {
#if _EN_Dynamic_Fix_Boundary

                if(gStaticMode==cDynamicMode)
                {
                    if(gsCacheInfo.u16DynamicSpareCnt<g16TLCGCSpareCnt)
                    {
                        u16StartFblock=g16StaticBound;
                        u16endFblock=g16TotalFBlock;
                    }
                }
                else if(gStaticMode==cStartStaticMode)
                {
                    if(gsCacheInfo.u16SLCSpareCnt<gsGcInfo.u16GcCachebActThr)
                    {
                        u16StartFblock=g16FirstFBlock;
                        u16endFblock=g16StaticBound;
                    }
                    else
                    {
                        u16StartFblock=g16StaticBound;
                        u16endFblock=g16TotalFBlock;
                    }
                }

                rmSetSrchLorBound(1);
                u16FBlk=
                    bopSrchRam((LWORD)g32arCacheBlkVpCnt, c32Bit30-1, c32BitFF, u16StartFblock, u16endFblock, cBopSrchMin|
                               cBopLwordMo|cBopWait);
#else/* if _EN_Dynamic_Fix_Boundary */
                rmSetSrchLorBound(1);
                u16FBlk=
                    bopSrchRam((LWORD)g32arCacheBlkVpCnt, c32Bit30-1, c32BitFF, g16FirstFBlock, g16TotalFBlock, cBopSrchMin|
                               cBopLwordMo|cBopWait);
#endif/* if _EN_Dynamic_Fix_Boundary */
            }
        }
        else
        {
            // if((mChkGcQue(cGcTypTLCWearLvl)||mChkGcQue(cGcTypReadReclaim))&&(gsCacheInfo.u16TLCFullCacheBlockCnt<g16TlcFullCachebGcThr))
            if(gsGcInfo.uGcPrioTlcBlkNumPtr&&(gsCacheInfo.u16TLCFullCacheBlockCnt<g16TlcFullCachebGcThr))
            {
                if(uTailPtrTemp<gsGcInfo.uGcPrioTlcBlkNumPtr)
                {
                    u16FBlk=gsGcInfo.u16Gc1stPrioTlcBlock[uTailPtrTemp];
                    uTailPtrTemp++;

                    if(u16FBlk==0xFFFF)
                    {
                        while(1)
                            ;
                    }
                }
                else
                {
                    rmSetSrchLorBound(c32Bit30+1);
                    u16FBlk=
                        bopSrchRam((LWORD)g32arCacheBlkVpCnt, c32Bit31-1, c32BitFF, g16FirstFBlock, g16TotalFBlock, cBopSrchMin|
                                   cBopLwordMo|cBopWait);
                }

                if((gsGcInfo.u32TotalSrcBlkVpc+mGetCacheBlkVpCnt(u16FBlk))>(g32VpcPerTlcBlk+((gsGcInfo.uGcSrcBlkCnt+1)<<4)))
                {
                    if(gsGcInfo.uGcPrioTlcBlkNumPtr||gsGcInfo.uGCSLCWLCnt)
                    {
                        rmSetSrchLorBound(0);
                        return;
                    }
                }
            }
            else
            {
                rmSetSrchLorBound(c32Bit30+1);
                u16FBlk=
                    bopSrchRam((LWORD)g32arCacheBlkVpCnt, c32Bit31-1, c32BitFF, g16FirstFBlock, g16TotalFBlock, cBopSrchMin|
                               cBopLwordMo|cBopWait);
            }
        }

        rmSetSrchLorBound(0);
        // }

        if(u16FBlk==cInvldFBlk)
        {
            return;
        }

        if(mChkSkipGcSrch(u16FBlk))
        {
            continue;
        }

        if((mGetGcFlow==cGcFlowS2S)&&((mGetCacheBlkVpCnt(u16FBlk)+gsGcInfo.u32TotalSrcBlkVpc)>g32VpcPerSlcBlk))
        {
            return;
        }

        gsGcInfo.u16GcSrcBlock[uNowGcSrcBlkIdx]=u16FBlk;
        gsGcInfo.u32GcSrcBlkVpc[uNowGcSrcBlkIdx]=mGetCacheBlkVpCnt(u16FBlk);
        gsGcInfo.u32TotalSrcBlkVpc+=mGetCacheBlkVpCnt(u16FBlk);

        if(!mChkSkipGcSrch(u16FBlk))
        {
            mSetSkipGcSrch(u16FBlk);
        }

        if(!mChkGcSrcBlkBmap(u16FBlk))
        {
            mSetGcSrcBlkBmap(u16FBlk);
        }

        // if(mGetGcFlow!=cGcFlowT2T)
        // {
        if(gsGcInfo.uGcSkipPopSrcBlockCnt<cMaxSkipGcSrcBlkNum)
        {
            mSetSlcSkipRam(u16FBlk);
            gsGcInfo.u16arGcSkipPopSrcBlock[gsGcInfo.uGcSkipPopSrcBlockCnt]=u16FBlk;
            gsGcInfo.uGcSkipPopSrcBlockCnt++;
        }

        // }

        gsGcInfo.uGcSrcBlkCnt++;
#if _EN_FW_DEBUG_UART
        NLOG(cLogGC, GCCACHEB_C, 1, "GC source block cnt: 0x%04X ", gsGcInfo.uGcSrcBlkCnt);
        NLOG(cLogGC, GCCACHEB_C, 1, "GC source block: 0x%04X ", u16FBlk);
        NLOG(cLogGC, GCCACHEB_C, 2, "GC source VPC: 0x%08X ", mGetCacheBlkVpCnt(u16FBlk)>>16, mGetCacheBlkVpCnt(u16FBlk));
#endif

        if((mGetGcFlow==cGcFlowS2T)&&!mChkGcFlag(cUnderBgdGc)&&(gsGcInfo.uGcSrcBlkCnt>cMinS2SSrcBlkNum)&&
           (gsGcInfo.u32TotalSrcBlkVpc<g32VpcPerSlcBlk))
        {
            mSetGcFlow(cGcFlowS2S);
            gsGcInfo.uGcMaxSrcBlkCnt=cMaxGcSrcBlkNum;
        }
    }

    if(mGetGcFlow==cGcFlowS2S)
    {
        return;
    }

    if((gsGcInfo.u32TotalSrcBlkVpc<g32VpcPerTlcBlk)&&(gsGcInfo.uGcSrcBlkCnt<cMaxGcSrcBlkNum))
    {
        uNowGcSrcBlkIdx=gsGcInfo.uGcSrcBlkIdx[gsGcInfo.uGcSrcBlkCnt];
        u32DiffVPC=g32VpcPerTlcBlk-gsGcInfo.u32TotalSrcBlkVpc;

        if(mGetGcFlow!=cGcFlowT2T)
        {
            rmSetSrchLorBound(1);
            u16FBlk=
                bopSrchRam((LWORD)g32arCacheBlkVpCnt, u32DiffVPC, c32BitFF, g16FirstFBlock, g16TotalFBlock, cBopSrchMax|
                           cBopLwordMo|cBopWait);
        }
        else
        {
            rmSetSrchLorBound(c32Bit30+1);
            u16FBlk=
                bopSrchRam((LWORD)g32arCacheBlkVpCnt, (c32Bit30+u32DiffVPC), c32BitFF, g16FirstFBlock, g16TotalFBlock, cBopSrchMax|
                           cBopLwordMo|cBopWait);
        }

        rmSetSrchLorBound(0);

        if(u16FBlk==cInvldFBlk)
        {
            return;
        }

        gsGcInfo.u16GcSrcBlock[uNowGcSrcBlkIdx]=u16FBlk;
        gsGcInfo.u32GcSrcBlkVpc[uNowGcSrcBlkIdx]=mGetCacheBlkVpCnt(u16FBlk);
        gsGcInfo.u32TotalSrcBlkVpc+=mGetCacheBlkVpCnt(u16FBlk);

        if(!mChkSkipGcSrch(u16FBlk))
        {
            mSetSkipGcSrch(u16FBlk);
        }

        if(!mChkGcSrcBlkBmap(u16FBlk))
        {
            mSetGcSrcBlkBmap(u16FBlk);
        }

        // if(mGetGcFlow!=cGcFlowT2T)
        // {
        if(gsGcInfo.uGcSkipPopSrcBlockCnt<cMaxSkipGcSrcBlkNum)
        {
            mSetSlcSkipRam(u16FBlk);
            gsGcInfo.u16arGcSkipPopSrcBlock[gsGcInfo.uGcSkipPopSrcBlockCnt]=u16FBlk;
            gsGcInfo.uGcSkipPopSrcBlockCnt++;
        }

        // }

        gsGcInfo.uGcSrcBlkCnt++;
    }
#endif/* if 0 */
// =====
}    /* addNewGcSrcBlk */

//
// delete GcSrcBlkPtr and sort uGcSrcBlkIdx array.
//
/*
   * void deleteGcSrcBlk(BYTE uInvalidBlkPtr)
   * {
   *  BYTE uEmptyGcSrcBlkIdx=gsGcInfo.uGcSrcBlkIdx[uInvalidBlkPtr];
   *  BYTE uNowBlkPtr=uInvalidBlkPtr;
   *
   *  mGet16GcSrcBlock(uInvalidBlkPtr)|=c16Bit15;     // Easy to see which Blk was deleted
   *
   *  while(uNowBlkPtr<(gsGcInfo.uGcSrcBlkCnt-1))
   *  {
   *      gsGcInfo.uGcSrcBlkIdx[uNowBlkPtr]=gsGcInfo.uGcSrcBlkIdx[uNowBlkPtr+1];
   *      uNowBlkPtr++;
   *  }
   *
   *  gsGcInfo.uGcSrcBlkIdx[uNowBlkPtr]=uEmptyGcSrcBlkIdx;
   *  gsGcInfo.uGcSrcBlkCnt--;
   * }
   */

void selectSrcBlk()
{
    /*
       * WORD u16SrcFblock;
       * BYTE uNowGcSrcBlkIdx, uGcSrcBlkPtr;
       *
       * if(gsGcInfo.u16GcIncompleteSrchFblk==cInvldFBlk)
       * {
       *  for(uGcSrcBlkPtr=0; uGcSrcBlkPtr<gsGcInfo.uGcSrcBlkCnt; )
       *  {
       *      uNowGcSrcBlkIdx=gsGcInfo.uGcSrcBlkIdx[uGcSrcBlkPtr];
       *      u16SrcFblock=gsGcInfo.u16GcSrcBlock[uNowGcSrcBlkIdx];
       *
       *      if(!mChkGcSrcBlkBmap(u16SrcFblock))
       *      {
       *          deleteGcSrcBlk(uGcSrcBlkPtr);
       *
       *          if(!uGcSrcBlkPtr)
       *          {
       *              gsGcInfo.uGcSrcF2hTabBank=0;
       *              gsGcInfo.u16GcSrcStUnit=0;
       *          }
       *
       *          if(gsGcInfo.u16GcIncompleteSrchFblk==u16SrcFblock)
       *          {
       *              gsGcInfo.u16GcIncompleteSrchFblk=cInvldFBlk;
       *          }
       *
       *          continue;
       *      }
       *
       *      uGcSrcBlkPtr++;
       *  }
       * }
       */

    if(!gsGcInfo.uGcSrcBlkCnt)
    {
        bopClrRam((LWORD)&g32GcSkipSrcHblkSrch, c16MaxH2fTabNum/8, 0x00000000, cClrTsb|cBopWait);
        addNewGcSrcBlk();
        initGCDesVariable();
#if S_NvmeQRWT_timeout

        if(mGetGcFlow==cGcFlowT2T)
        {
            LWORD u32AvgVpc, u32Tmp1, u32Tmp2;
            BYTE uT2TOpFactor;

            gsGcInfo.u32GcCachebTime=((gsGcInfo.u32GcLastS2TProcTime/(cProgCntPerWL-1))/(g16PagePerBlock1_SLC/cProgCntPerWL))+
                                      c32PartialCleanRtc5ms;

            u32AvgVpc=(gsGcInfo.u32TotalSrcBlkVpc+gsGcInfo.uGcSrcBlkCnt-1)/gsGcInfo.uGcSrcBlkCnt;
            u32Tmp1=(g32VpcPerTlcBlk+u32AvgVpc-1)/u32AvgVpc;
            u32AvgVpc=g32VpcPerTlcBlk-u32AvgVpc;
            u32Tmp2=(g32VpcPerTlcBlk+u32AvgVpc-1)/u32AvgVpc;

            if(u32Tmp1>u32Tmp2)
            {
                uT2TOpFactor=u32Tmp1;
            }
            else
            {
                uT2TOpFactor=u32Tmp2;
            }

            gsGcInfo.u32GcCachebTime+=((gsGcInfo.u32GcLastT2TProcTime*uT2TOpFactor)/(g16PagePerBlock1_SLC/cProgCntPerWL))+c32PartialCleanRtc5ms;
            gsGcInfo.u32GcCachebTime<<=1;
        }
#endif/* if S_NvmeQRWT_timeout */
#if _EN_FW_DEBUG_UART
        NLOG(cLogGC,
             GCCACHEB_C,
             7,
             "GC flow: 0x%04X, S2TAmpFtr: 0x%04X, T2TOpFtr: 0x%04X, MaxSrcBlkCnt: 0x%04X, TotalSrcBlkCnt: 0x%04X, TotalSrcBlkVpc: 0x%08X ",
             mGetGcFlow,
             gsGcInfo.uS2TAmpFactor,
             gsGcInfo.uT2TOpFactor,
             gsGcInfo.uGcMaxSrcBlkCnt,
             gsGcInfo.uGcSrcBlkCnt,
             gsGcInfo.u32TotalSrcBlkVpc>>16,
             gsGcInfo.u32TotalSrcBlkVpc);
#endif
#if _GREYBOX
        chkGreyBoxGc(0);
#endif/* if _GreyBox */
    }
}    /* selectSrcBlk */

void buildSrcFaddrDesF2hTab()
{
    F2HTABLE *upSrcF2hTab, *upEofSrcF2hTab;
    WORD u16Hblock;

/* Search H2F for F2H of each SrcBlk. */
    gsGcInfo.u16BuSrcActH2fTab=0xFFFF;

    while(gsGcInfo.uGcSrcBlkCnt&&(gsGcInfo.uGcDesF2hTabBuildBank<gsGcInfo.uGCDesF2hBankNum)&&(getBrkBgdGcF()!=cTrue))
    {
        waitAllChCeBzCore0();
        disableLdpcPipe();

        mSetGcFlag(cGcReadF2h);

#if (_EN_RDLINK_PF)

        if(readCacheF2hTab(c16GcSrcBlk0F2hSIdx, mGet16GcSrcBlock(cGcHeadSrcBlk),
                           (gsGcInfo.uGcSrcF2hTabBank*gsGcInfo.u16TotalPgPerF2hTab)+gsGcInfo.u16ValidPgPerF2hTab,
                           cF2hTableID)!=cRdFcbStsSuccess)
#else

        if(readCacheF2hTab(c16GcSrcBlk0F2hSIdx, mGet16GcSrcBlock(cGcHeadSrcBlk),
                           (gsGcInfo.uGcSrcF2hTabBank*gsGcInfo.u16TotalPgPerF2hTab)+gsGcInfo.u16ValidPgPerF2hTab, cF2hTableID)!=cTrue)
#endif
        {
            mSetGcFlag(cGcRebuF2hTab);
            buildValidCachePageCore0();
        }

        mClrGcFlag(cGcReadF2h);

        waitAllChCeBzCore0();
        enableLdpcPipe();

        upSrcF2hTab=gsGcInfo.upBuildSrcF2hTabSt;
        upEofSrcF2hTab=(F2HTABLE *)garTsb0[c16GcSrcBlk0F2hSIdx]-1;

        while(upSrcF2hTab!=upEofSrcF2hTab)
        {
            u16Hblock=upSrcF2hTab->u16HBlock&~c16Bit15;

            if((u16Hblock!=c15BitFF)&&!mChkSkipGcSrcHblkSrch(u16Hblock))
            {
                if(g16arH2fTabPtr[u16Hblock]!=0xFFFF)
                {
                    if(gsGcInfo.u16BuSrcActH2fTab!=u16Hblock)
                    {
                        readH2fTable(c16GcBuSrcH2fIdx, u16Hblock, c16Bit0|c16Bit4|c16Bit15, 0);
                        gsGcInfo.u16BuSrcActH2fTab=u16Hblock;
                    }

                    F2HTABLE *upSrcF2hTab2=(upSrcF2hTab-1);

                    while((upSrcF2hTab2>upEofSrcF2hTab)&&((upSrcF2hTab2->u16HBlock&~c16Bit15)==u16Hblock))
                    {
                        upSrcF2hTab--;
                        upSrcF2hTab2--;
                    }
                }

                if(gsGcInfo.u16GcIncompleteSrchFblk!=cInvldFBlk)
                {
                    srchGcSrcF2hTab(gsGcInfo.u16GcIncompleteSrchHblk, 1);
                }
                else
                {
                    srchGcSrcF2hTab(u16Hblock, 0);
                }

#if _GREYBOX
                chkGreyBoxGc(3);
#endif

                if(!gsGcInfo.u16GcDesF2hTabFreePtr)    // ==gTotal4kNumOfF2hTab)
                {
                    if(gsHmbInfo.uHmbEnGcCache)
                    {
                        writeHmbGcInfoTab(c16GcDesF2hSIdx, cWproGcDesF2hTab00+gsGcInfo.uGcDesF2hTabBuildBank, 0);
                    }

                    progWproPageCore0(cWproGcDesF2hTab00+gsGcInfo.uGcDesF2hTabBuildBank, c16GcDesF2hSIdx);
                    gsGcInfo.uGcDesF2hTabBuildBank++;
                    gsGcInfo.u16GcDesF2hTabFreePtr=gsGcInfo.u16GCDesTotalPgPerF2hTab-1;
                    mWaitHmbTransferDone();
                    bopClrRam((LWORD)&garTsb0[c16GcDesF2hSIdx], c32CacheF2hRamSize*2, 0xFFFFFFFF, cClrTsb|cBopWait);

#if _GREYBOX

                    if((gsGbInfo.uGreyBoxOpt==cVOpProgWproGcInfo)&&(gsGbInfo.uStag==cVsIdl)&&
                       (((gsGbInfo.uGreyBoxItem==cUGSDT2TID)&&(mGetGcFlow==cGcFlowT2T))||
                        ((gsGbInfo.uGreyBoxItem==cUGSDS2SID)&&(mGetGcFlow==cGcFlowS2S))||
                        ((gsGbInfo.uGreyBoxItem==cUGSDonWearleveling)&&(mGetGcFlow==cGcFlowT2T))))
                    {
                        gGbGcSrcBlkCnt=1;
                    }
#endif

                    if(gsGcInfo.uGcDesF2hTabBuildBank==gsGcInfo.uGCDesF2hBankNum)
                    {
                        break;
                    }
                }

                if(gsGcInfo.u16GcIncompleteSrchFblk==cInvldFBlk)
                {
                    mSetSkipGcSrcHblkSrch(u16Hblock);

                    if(!gsGcInfo.u32GcSrcBlkVpc[gsGcInfo.uGcSrcBlkIdx[cGcHeadSrcBlk]])
                    {
                        upSrcF2hTab=upEofSrcF2hTab;
                    }
                    else
                    {
                        upSrcF2hTab--;
                    }
                }

                if(!mChkGcFlag(cGcRebuF2hTab))
                {
                    if(getBrkBgdGcF()==cTrue)
                    {
                        break;
                    }
                }
            }
            else
            {
                upSrcF2hTab--;
            }
        }

        mClrGcFlag(cGcRebuF2hTab);

        /* End of Src F2h tab */
        if(upSrcF2hTab==upEofSrcF2hTab)
        {
            gsGcInfo.upBuildSrcF2hTabSt=(F2HTABLE *)garTsb0[c16GcSrcBlk0F2hSIdx]+(gsGcInfo.u16TotalPgPerF2hTab-1);
            gsGcInfo.uGcSrcF2hTabBank++;

            while(gsGcInfo.uGcSrcBlkCnt&&
                  (!gsGcInfo.u32GcSrcBlkVpc[gsGcInfo.uGcSrcBlkIdx[cGcHeadSrcBlk]]||
                   (gsGcInfo.uGcSrcF2hTabBank==gsGcInfo.uTotalBankOfF2hTab)))
            {
                gsGcInfo.uGcSrcF2hTabBank=0;

                if(gsGcInfo.u16GcIncompleteSrchFblk!=cInvldFBlk)
                {
                    if(!gsGcInfo.uGcIncompleteSrchSrcBlkPtr)
                    {
                        gsGcInfo.u16GcIncompleteSrchFblk=cInvldFBlk;
                    }
                    else
                    {
                        gsGcInfo.uGcIncompleteSrchSrcBlkPtr--;
#if _GREYBOX
                        chkGreyBoxGc(3);
#endif
                    }
                }

                deleteGcSrcBlkCore0(cGcHeadSrcBlk);
            }
        }
        else
        {
            gsGcInfo.upBuildSrcF2hTabSt=upSrcF2hTab;
        }

#if _GREYBOX
        chkGreyBoxGc(3);
#endif
    }

    if((getBrkBgdGcF()!=cTrue)||!gsGcInfo.uGcSrcBlkCnt)
    {
        while(gsGcInfo.uGcDesF2hTabBuildBank<gsGcInfo.uGCDesF2hBankNum)
        {
            LWORD *u32pSrcFAddrTab;
#if _EN_RAID_GC
            gsGcInfo.u16GcDesF2hTabFreePtr=gsGcInfo.uGCDes4KNumOfF2hTab+c4kNumPerRaidPty;
#else
            gsGcInfo.u16GcDesF2hTabFreePtr=gsGcInfo.uGCDes4KNumOfF2hTab;
#endif
            u32pSrcFAddrTab=(LWORD *)garTsb0[c16GcDesF2hSIdx+(gsGcInfo.uGCDes4KNumOfF2hTab<<3)]+(gsGcInfo.u16GcDesF2hTabFreePtr-1);

            while(gsGcInfo.u16GcDesF2hTabFreePtr)
            {
                *u32pSrcFAddrTab=mSetH2fSrcFAddr(g16TotalFBlock+gsGcInfo.uGcDesF2hTabBuildBank, 0);
                u32pSrcFAddrTab--;
                gsGcInfo.u16GcDesF2hTabFreePtr--;
#if _EN_RAID_GC

                if(gsGcInfo.u16GcDesF2hTabFreePtr==c4kNumPerRaidPty)
                {
                    break;
                }
#endif
            }

            if(gsHmbInfo.uHmbEnGcCache)
            {
                writeHmbGcInfoTab(c16GcDesF2hSIdx, cWproGcDesF2hTab00+gsGcInfo.uGcDesF2hTabBuildBank, 0);
            }

            progWproPageCore0(cWproGcDesF2hTab00+gsGcInfo.uGcDesF2hTabBuildBank, c16GcDesF2hSIdx);
            gsGcInfo.uGcDesF2hTabBuildBank++;
            gsGcInfo.u16GcDesF2hTabFreePtr=gsGcInfo.u16GCDesTotalPgPerF2hTab-1;
            mWaitHmbTransferDone();
            bopClrRam((LWORD)&garTsb0[c16GcDesF2hSIdx], c32CacheF2hRamSize*2, 0xFFFFFFFF, cClrTsb|cBopWait);

#if _EN_Liteon_ErrHandle    // 20190618_Louis_01

            if(gsGcInfo.uGcDesF2hTabBuildBank==gsGcInfo.uGCDesF2hBankNum)
            {
                LWORD u32VpcPerBlk;

                if(mGetGcFlow==cGcFlowS2S)
                {
                    u32VpcPerBlk=g32VpcPerSlcBlk;
                }
                else
                {
                    u32VpcPerBlk=g32VpcPerTlcBlk;
                }

                if(gsGcInfo.u32TotalSrcBlkVpc>u32VpcPerBlk)
                {
                    NLOG(cLogTempDebug,
                         GCCACHEB_C,
                         5,
                         "GC source block Vpc check! mGetGcFlow=0x%04x, TotalSrcBlkVpc=0x%08x, u32VpcPerBlk=0x%08x",
                         mGetGcFlow,
                         gsGcInfo.u32TotalSrcBlkVpc>>16,
                         gsGcInfo.u32TotalSrcBlkVpc,
                         u32VpcPerBlk>>16,
                         u32VpcPerBlk);
#if _EN_KEEP_RW_ON_ERROR
                    gGCOpt|=gbGCSrcVpcChk;
#endif
                }
            }
#endif/* if _EN_Liteon_ErrHandle */
        }
    }

    if(gsGcInfo.uGcDesF2hTabBuildBank<gsGcInfo.uGCDesF2hBankNum)
    {
#if _GREYBOX

        if((gsGbInfo.uGreyBoxOpt==cVOpProgWproGcInfo)&&(gsGbInfo.uStag==cVsIdl)&&
           (gsGcInfo.uGcDesF2hTabBuildBank==(gsGcInfo.uGCDesF2hBankNum-1)))
        {
            if(gsGbInfo.uGreyBoxItem==cUGSDS2TID)
            {
                trigGreyBox(cTrue);
            }
            else if(gsGbInfo.uGreyBoxItem==cUGSDReclaimID)
            {
                if((mChkGcSrcBlkBmap(*(WORD *)(c32GreyBoxBuf+cGbInfoReclimFBlk1)))||
                   (mChkGcSrcBlkBmap(*(WORD *)(c32GreyBoxBuf+cGbInfoReclimFBlk2)))||
                   (mChkGcSrcBlkBmap(*(WORD *)(c32GreyBoxBuf+cGbInfoReclimFBlk3))))
                {
                    trigGreyBox(cTrue);
                }
            }
        }
        else if((gsGbInfo.uGreyBoxOpt==cVOpProgWproGcInfo)&&(gsGbInfo.uStag==cVsIdl))
        {
            if((gsGbInfo.uGreyBoxItem==cUGSDT2TID)&&(mGetGcFlow==cGcFlowT2T))
            {
                trigGreyBox(cTrue);
            }
            else if((gsGbInfo.uGreyBoxItem==cUGSDS2SID)&&(mGetGcFlow==cGcFlowS2S))
            {
                trigGreyBox(cTrue);
            }
            else if((gsGbInfo.uGreyBoxItem==cUGSDonWearleveling)&&(mGetGcFlow==cGcFlowT2T))
            {
                trigGreyBox(cTrue);
            }
        }
#endif/* if _GREYBOX */

        if(gsHmbInfo.uHmbEnGcCache)
        {
            writeHmbGcInfoTab(c16GcDesF2hSIdx, cWproGcInfoPage, 0);
        }

        progWproPageCore0(cWproGcInfoPage, c16GcDesF2hSIdx);
        mWaitHmbTransferDone();
    }
    else
    {
        remWproPageCore0(cWproGcInfoPage);
        mSetGcState(cGcMoveData);
    }
}    /* buildSrcFaddrDesF2hTab */

//
// Return true for exit
//
BYTE chkExitGcProc()
{
    // if(gbTrimCmd&&!mChkGcFlag(cGcForceClean))
    // {
    //    setHostWr4kCntFull();
    // }
    // else if(mChkGcFlag(cGcFlushDesTab))
    // {
    //    return cFalse;
    // }
    // else if(!gsGcInfo.uGcSrcBlkCnt)
    // {}
    if(mChkGcFlag(cGcSpareNotEnough))
    {
        NLOG(cLogGC, GCCACHEB_C, 0, "Spare Not Enough");
        return cFalse;
    }

    if(!gsGcInfo.uGcDesBlkCnt)
    {}
    // else if(gsCacheInfo.u16SpareBlockCnt<=cSprbCnt2ExitGc)
    else if(mChkGcQue(cGcTypH2fTab))    // gsCacheInfo.uH2fTabBlockCnt>gsGcInfo.uGcH2fTabbHiThr)
    {}
    else if(g16PushSpareCnt>gsGcInfo.uPushSprbHiThr)
    {}
    else if(mChkGcFlag(cUnderBgdGc)&&((gsCacheInfo.u16SpareBlockCnt+g16PushSpareCnt)>gsGcInfo.u16BgdGcCachebActThr))
    {}
    // else if(gsCacheInfo.u16FullCacheBlockCnt==0)
    // {}
    else
    {
        return cFalse;
    }

    return cTrue;
}    /* chkExitGcProc */

BYTE setGcFlowAndBlkCnt()    // BYTE uCaller)
{
    if(mGetGcFlow==cGcFlowIdl)
    {
        LWORD u32AvgVpc;
        WORD u16TotalTlcFblkCap;

        if(gsHmbInfo.uHmbSwichChkTimer==cTrue)
        {
            if(gsGcInfo.u32GcMaxS2TProcTime)
            {
                gsGcInfo.u32GcLastS2TProcTime=gsGcInfo.u32GcMaxS2TProcTime;
            }

            if(gsGcInfo.u32GcMaxT2TProcTime)
            {
                gsGcInfo.u32GcLastT2TProcTime=gsGcInfo.u32GcMaxT2TProcTime;
            }

            gsHmbInfo.uHmbSwichChkTimer=cFalse;
        }

        u32AvgVpc=(gsGcInfo.u32TotalSlcVpc+gsCacheInfo.u16FullCacheBlockCnt-1)/gsCacheInfo.u16FullCacheBlockCnt;
        gsGcInfo.uS2TAmpFactor=(g32VpcPerTlcBlk+u32AvgVpc-1)/u32AvgVpc;
        gsGcInfo.u32GcCachebTime=((gsGcInfo.u32GcLastS2TProcTime/(cProgCntPerWL-1))/(g16PagePerBlock1_SLC/cProgCntPerWL))+
                                  c32PartialCleanRtc5ms;

#if (_EN_IOMTRIG&&_EN_VPC_SWAP)
        g32SLCAvgVpc=u32AvgVpc;

        if(((g32SLCAvgVpc*100/g32VpcPerSlcBlk)<50)&&((gsIomInfo.u8Status==cIoMeterTrig)||(gsIomInfo1Thr.u8Status==cIoMeterTrig)))
        {
            mSetGcFlow(cGcFlowS2S);
        }
        else
#endif
#if _EN_VPC_SWAP

        if((gsCacheInfo.u16TLCFullCacheBlockCnt>g16TlcFullCachebGcThr)||
           (gsGcInfo.uGcPrioTlcBlkNumPtr&&(gsCacheInfo.u16SpareBlockCnt>cMinGCSprCnt)&&(g16SlcSortQCnt<(g16MaxSlcBlkQ*5/6))))    // 20190528_Louis_04
#else

        if((gsCacheInfo.u16TLCFullCacheBlockCnt>g16TlcFullCachebGcThr)||
           (gsGcInfo.uGcPrioTlcBlkNumPtr&&(gsCacheInfo.u16SpareBlockCnt>cMinGCSprCnt)&&(g16SlcSortQCnt<125)))    // 20190218_Louis
#endif
        {
            mSetGcFlow(cGcFlowT2T);
        }
        else
        {
#if _EN_BgdT2tClnCdm    // ChrisSu_20190329  sync SMI S0322B

            if((mChkGcFlag(cUnderBgdGc))&&(cDirtyCdmRsvSprThr>gsCacheInfo.u16SpareBlockCnt))
            {
                if(!gsCacheInfo.u16FullCacheBlockCnt)
                {
                    mSetGcFlow(cGcFlowT2T);
#if _EN_FW_DEBUG_UART
                    NLOG(cLogGC, GCCACHEB_C, 0, "SetDirtyCdm Bgd T2T");
#endif
                }
                else
                {
                    mSetGcFlow(cGcFlowS2T);
                }
            }
            else
#endif
            {
                mSetGcFlow(cGcFlowS2T);
            }
        }

        u16TotalTlcFblkCap=((g32TotalDatSector>>3)+g32VpcPerTlcBlk-1)/g32VpcPerTlcBlk;    // 20190611_Louis

        if((!gsCacheInfo.u16FullCacheBlockCnt)||((gsCacheInfo.u16DynamicSpareCnt<=4)&&(gsCacheInfo.u16TLCFullCacheBlockCnt>u16TotalTlcFblkCap)))
        {
            mSetGcFlow(cGcFlowT2T);
        }

        if(!gsCacheInfo.u16DynamicSpareCnt)    // 20190513_Bruce
        {
            mSetGcFlow(cGcFlowS2S);
        }

        if(mGetGcFlow==cGcFlowT2T)
        {
            u32AvgVpc=(gsGcInfo.u32TotalTlcVpc+gsCacheInfo.u16TLCFullCacheBlockCnt-1)/gsCacheInfo.u16TLCFullCacheBlockCnt;

            if(gsCacheInfo.u16TLCFullCacheBlockCnt>g16TlcFullCachebGcThr)
            {
                // while(u32AvgVpc>g32VpcPerTlcBlk);
                if(u32AvgVpc>g32VpcPerTlcBlk)
                {
#if _EN_KEEP_RW_ON_ERROR    // 20190528_Chief_VPC_Correct
                    u32AvgVpc=g32VpcPerTlcBlk-1;
#else
                    gsFtlDbg.u16DummyFailType=c32VpcOverMaxTlcBlk;
                    debugWhile();
#endif
                }

                LWORD u32T2TOpFactor, u32Tmp1, u32Tmp2;
                u32Tmp1=(g32VpcPerTlcBlk+u32AvgVpc-1)/u32AvgVpc;
                u32AvgVpc=g32VpcPerTlcBlk-u32AvgVpc;
                u32Tmp2=(g32VpcPerTlcBlk+u32AvgVpc-1)/u32AvgVpc;

                if(u32Tmp1>u32Tmp2)
                {
                    u32T2TOpFactor=u32Tmp1;
                }
                else
                {
                    u32T2TOpFactor=u32Tmp2;
                }

                if(u32T2TOpFactor>cMaxGcSrcBlkNum)
                {
                    gsGcInfo.uT2TOpFactor=cMaxGcSrcBlkNum;
                }
                else
                {
                    gsGcInfo.uT2TOpFactor=u32T2TOpFactor;
                }

#if _EN_FW_DEBUG_UART
                NLOG(cLogGC, GCCACHEB_C, 2, "Empty AvgVpc: 0x%04X, T2TOpFactor: 0x%04X ", u32AvgVpc, gsGcInfo.uT2TOpFactor);
#endif
                gsGcInfo.u32GcCachebTime+=((gsGcInfo.u32GcLastT2TProcTime*u32T2TOpFactor)/(g16PagePerBlock1_SLC/cProgCntPerWL))+
                                           c32PartialCleanRtc5ms;
            }
            else
            {
                gsGcInfo.uT2TOpFactor=2;
                gsGcInfo.u32GcCachebTime=c32PartialCleanRtc50ms;
            }

            if(!gsGcInfo.u32GcCachebTime)
            {
                debugDeadLock(0x31);
            }
        }

        if(gsGcInfo.u32GcCachebTime<gsGcInfo.u32GcLeastBudget)
        {
            gsGcInfo.u32GcCachebTime=gsGcInfo.u32GcLeastBudget;
        }

        if(mChkGcQue(cGcTypForeGrnd)&&(gsCacheInfo.u16SpareBlockCnt>2))
        {
#if _EN_Dynamic_Fix_Boundary

            if(mGetGcFlow==cGcFlowS2T)
            {
                if(gsCacheInfo.u16SpareBlockCnt<gsGcInfo.u16GcCachebActThr)
                {
                    if(!gsCacheInfo.u16SpareBlockCnt)
                    {
                        gsGcInfo.u32GcCachebTime=(gsGcInfo.u32GcCachebTime*gsGcInfo.u16GcCachebActThr);
                    }
                    else
                    {
                        gsGcInfo.u32GcCachebTime=(gsGcInfo.u32GcCachebTime*(gsGcInfo.u16GcCachebActThr/gsCacheInfo.u16SpareBlockCnt));
                    }
                }
            }
            else if((mGetGcFlow==cGcFlowT2T)&&(gsCacheInfo.u16DynamicSpareCnt<g16TLCGCSpareCnt_Ori))
            {
                if(!gsCacheInfo.u16DynamicSpareCnt)
                {
                    gsGcInfo.u32GcCachebTime=(gsGcInfo.u32GcCachebTime*g16TLCGCSpareCnt_Ori);
                }
                else
                {
                    gsGcInfo.u32GcCachebTime=(gsGcInfo.u32GcCachebTime*(g16TLCGCSpareCnt_Ori/gsCacheInfo.u16DynamicSpareCnt));
                }
            }

#else/* if _EN_Dynamic_Fix_Boundary */

            if(gsCacheInfo.u16SpareBlockCnt<gsGcInfo.u16GcCachebActThr)
            {
                gsGcInfo.u32GcCachebTime=(gsGcInfo.u32GcCachebTime*(gsGcInfo.u16GcCachebActThr/gsCacheInfo.u16SpareBlockCnt));
            }
#endif/* if _EN_Dynamic_Fix_Boundary */
        }

        if(gsCacheInfo.u16DynamicSpareCnt<4)
        {
            gsGcInfo.u32GcCachebTime<<=1;
        }
    }

    return cTrue;
}    /* setGcFlowAndBlkCnt */

#if _EN_RAID_GC
void chkHmbStsChg()
{
    if(gsHmbInfo.uHmbStsChg)
    {
#if _EN_FW_DEBUG_UART
        NLOG(cLogGC,
             GCCACHEB_C,
             2,
             "chkHmbStsChg, gsHmbInfo.uHmbStsChg: 0x%04X, gsGcInfo.uGcDesBlkCnt: 0x%04X ",
             gsHmbInfo.uHmbStsChg,
             gsGcInfo.uGcDesBlkCnt);
#endif

        if(gsGcInfo.uGcDesBlkCnt)
        {
            rstRaidEngVarCore0(cRaidGcBlk);
            gcDesBlkFullSettingCore0();
        }

        gsCacheInfo.u16PartialParityPtrGc=0;
        gsHmbInfo.uHmbStsChg=cFalse;
        gsGcInfo.uHMBchg=cFalse;
    }
}    /* chkHmbStsChg */

void chkTrigHmbPtyQue()
{
    WORD u16BufPtr, u16ParityIdx, u16ParityPtr;
    BYTE uPagePerWL, uTotalPtyCnt, uRetVal=cFalse;

    // if(gsHmbPtyInfo.u32HmbPtyTail!=gsHmbPtyInfo.u32HmbPtyHead)
    do
    {
#if _EN_PROGFAILLOG

        while((gsHmbPtyInfo.u32HmbPtyTail==gsHmbPtyInfo.u32HmbPtyHead)&&!mChkGcFlag(cGcDesFailAbort))
            ;

        if(mChkGcFlag(cGcDesFailAbort))
        {
            break;
        }

#else

        while(gsHmbPtyInfo.u32HmbPtyTail==gsHmbPtyInfo.u32HmbPtyHead)
            ;
#endif
        u16BufPtr=gsHmbPtyInfo.uarHmbPtyQ[gsHmbPtyInfo.u32HmbPtyTail].u16BufPtr;
        u16ParityPtr=gsHmbPtyInfo.uarHmbPtyQ[gsHmbPtyInfo.u32HmbPtyTail].u16PtyIdx;
        uPagePerWL=gsHmbPtyInfo.uarHmbPtyQ[gsHmbPtyInfo.u32HmbPtyTail].uPagePerWL;
        u16ParityIdx=(u16ParityPtr*uPagePerWL)+gsHmbPtyInfo.uarHmbPtyQ[gsHmbPtyInfo.u32HmbPtyTail].uPageSel;

        mWaitHmbRelease(2);

        if(gsHmbPtyInfo.uarHmbPtyQ[gsHmbPtyInfo.u32HmbPtyTail].uXfrDir==cWriteHmbPty)
        {
            txfrHmbData(cHmbWriteData,
                        u16BufPtr,
                        cRaidDataSctrNum,
                        (u16ParityIdx*cRaidDataSctrNum)<<9,
                        u16ParityIdx,
                        cHmbGcPtCache,
                        cHmbTsbPath|cHmbBufflagChk,
                        0);
            writePtyE2e2Hmb(u16BufPtr>>5, u16ParityIdx);
        }
        else
        {
            txfrHmbData(cHmbReadData,
                        u16BufPtr,
                        cRaidDataSctrNum,
                        (u16ParityIdx*cRaidDataSctrNum)<<9,
                        u16ParityIdx,
                        cHmbGcPtCache,
                        cHmbTsbPath|cHmbReadDir|cHmbBufflagChk,
                        g32arGcPtyCrc[u16ParityIdx*2]);
            readPtyE2eFromHmb(u16ParityIdx);

            if(uPagePerWL!=cProgCntPerWL)
            {
                uTotalPtyCnt=(BYTE)(g16SlcPartialParityNum>>cRaidStringShiftBit);
            }
            else
            {
                uTotalPtyCnt=(BYTE)(g16TlcPartialParityNum>>cRaidStringShiftBit);
            }

            if((u16ParityPtr>>cRaidStringShiftBit)==(uTotalPtyCnt-1))
            {
                uRetVal=cFalse;
            }
            else
            {
                uRetVal=cTrue;
            }
        }

        gsHmbPtyInfo.u32HmbPtyTail=addPtrBy1(gsHmbPtyInfo.u32HmbPtyTail, cHmbPtyQueDpt);
    }
    while(uRetVal);
}    /* chkTrigHmbPtyQue */

#endif/* if _EN_RAID_GC */

void srchGcSrcF2hTab(WORD u16Hblock, BYTE uImcomSrch)
{
    BYTE uGcSrcBlkPtr, uFlag;

#if _EN_RAID_GC
    BYTE uGCDes4KNumOfF2hTab=gsGcInfo.uGCDes4KNumOfF2hTab+c4kNumPerRaidPty;
    WORD u16TlcRaidParityStr4k=gsGcInfo.u16GCDesTotalPgPerF2hTab-gsGcInfo.u16GCDesProgRaidChStr4K;
#else
    BYTE uGCDes4KNumOfF2hTab=gsGcInfo.uGCDes4KNumOfF2hTab;
#endif
    WORD u16H2FStartUnit, u16GcSrcFblk;
    LWORD u32SrchPtn, u32GcSrcBlkVpc, u32HMap, u32HMapSt=(LWORD)u16Hblock<<16;
    UCLWORD *u32pH2FTabSt=(UCLWORD *)c16GcBuSrcH2fAddr, *u32pH2FTab;
    UCLWORD *u32pDesF2hTab=(UCLWORD *)garTsb0[c16GcDesF2hSIdx]+gsGcInfo.u16GcDesF2hTabFreePtr;
    UCLWORD *u32pSrcFAddrTab=(UCLWORD *)garTsb0[c16GcDesF2hSIdx+(gsGcInfo.uGCDes4KNumOfF2hTab<<3)]+gsGcInfo.u16GcDesF2hTabFreePtr;

    if(g16arH2fTabPtr[u16Hblock]!=0xFFFF)
    {
        // if(gsGcInfo.u16BuSrcActH2fTab!=u16Hblock)
        // {
        //    readH2fTable(c16GcBuSrcH2fIdx, u16Hblock, c16Bit0|c16Bit4|c16Bit15, cWaitReadDone);
        //    gsGcInfo.u16BuSrcActH2fTab=u16Hblock;
        // }
        mWaitHmbTransferDone();

        while(gsRwCtrl.u32FreeSrcFifoTail!=gsRwCtrl.u32FreeSrcFifoHead)
            ;

        if(uImcomSrch)
        {
            uGcSrcBlkPtr=gsGcInfo.uGcIncompleteSrchSrcBlkPtr;
        }
        else
        {
            uGcSrcBlkPtr=0;
        }

        while(uGcSrcBlkPtr<gsGcInfo.uGcSrcBlkCnt)
        {
            u16GcSrcFblk=mGet16GcSrcBlock(uGcSrcBlkPtr);
            u32GcSrcBlkVpc=gsGcInfo.u32GcSrcBlkVpc[gsGcInfo.uGcSrcBlkIdx[uGcSrcBlkPtr]];

            if((u16GcSrcFblk==gsGcInfo.u16GcIncompleteSrchFblk)&&(u16Hblock==gsGcInfo.u16GcIncompleteSrchHblk))
            {
                u16H2FStartUnit=gsGcInfo.u16GcIncompleteSrchHpg;
                gsGcInfo.u16GcIncompleteSrchFblk=cInvldFBlk;

                if(u16H2FStartUnit>=g16PagePerH2fTab)
                {
                    uGcSrcBlkPtr++;
                    continue;
                }
            }
            else
            {
                u16H2FStartUnit=0;
            }

            u32SrchPtn=u16GcSrcFblk<<c32SrcFPageAddrBitNum;

            if(bopSrchRam((LWORD)c16GcBuSrcH2fAddr, u32SrchPtn, c16FBlockInitValue<<c32SrcFPageAddrBitNum, u16H2FStartUnit,
                          g16PagePerH2fTab,
                          cBopSrchDat|cBopLwordMo|cBopWait|cBopNotRstFlag)!=cSrchNotFound)
            {
                do
                {
                    u16H2FStartUnit=rmGetSrchRslOfst;
                    u32pH2FTab=u32pH2FTabSt+u16H2FStartUnit;
                    u32HMap=u32HMapSt+u16H2FStartUnit;

                    do
                    {
                        u16H2FStartUnit++;

                        if(u16H2FStartUnit<g16PagePerH2fTab)
                        {
                            if((*(u32pH2FTab+1)&(c16FBlockInitValue<<c32SrcFPageAddrBitNum))==u32SrchPtn)
                            {
                                uFlag=cTrue;
                            }
                            else
                            {
                                rmSetBopDesAddr(u16H2FStartUnit);
                                rmTrigBopOpWoPause(cBopSrchOp);
                                uFlag=cFalse;
                            }
                        }
                        else
                        {
                            uFlag=cFalse;
                        }

                        *u32pSrcFAddrTab=*u32pH2FTab;
                        u32pSrcFAddrTab--;
                        *u32pDesF2hTab=u32HMap;
                        u32pDesF2hTab--;

                        if(!u32GcSrcBlkVpc)
                        {
#if 0    // _DEBUG_VPCNT
                            chkVpCntInGc();
#endif
                            gsFtlDbg.u16DummyFailType=cSrchGcSrcF2hTab;
#if (C_Log_SaveMask&C_Debug_P1)
                            NLOG(cLogGC,
                                 GCCACHEB_C,
                                 2,
                                 "srchGcSrcF2hTab , GC While 03 : u32GcSrcBlkVpc =  0x%04X , uGcSrcBlkPtr = 0x%04X",
                                 gsGcInfo.u32GcSrcBlkVpc[gsGcInfo.uGcSrcBlkIdx[uGcSrcBlkPtr]],
                                 uGcSrcBlkPtr);
#endif
#if _EN_KEEP_RW_ON_ERROR    // 20190618_Louis_01
                            gGCOpt|=gbGCVpcMismatch;
#else
                            debugLoop(c32VpcMismatch);
#endif
                        }
                        else
                        {
                            u32GcSrcBlkVpc--;
                        }

                        if(gsGcInfo.u16GcDesF2hTabFreePtr==uGCDes4KNumOfF2hTab)
                        {
                            for(BYTE uLoop=0; uLoop<gsGcInfo.uGCDes4KNumOfF2hTab; uLoop++)
                            {
                                *u32pSrcFAddrTab=mSetH2fSrcFAddr((g16TotalFBlock+gsGcInfo.uGcDesF2hTabBuildBank), 0);
                                u32pSrcFAddrTab--;
                            }

                            gsGcInfo.u16GcDesF2hTabFreePtr=0;
                            gsGcInfo.u16GcIncompleteSrchFblk=u16GcSrcFblk;
                            gsGcInfo.u16GcIncompleteSrchHblk=u16Hblock;
                            gsGcInfo.u16GcIncompleteSrchHpg=u16H2FStartUnit;
                            gsGcInfo.uGcIncompleteSrchSrcBlkPtr=uGcSrcBlkPtr;
                            gsGcInfo.u32GcSrcBlkVpc[gsGcInfo.uGcSrcBlkIdx[uGcSrcBlkPtr]]=u32GcSrcBlkVpc;

                            while(rmChkBopBz)
                                ;

                            rmSetSrchDefault;
                            return;
                        }
                        else
                        {
                            gsGcInfo.u16GcDesF2hTabFreePtr--;

#if _EN_RAID_GC

                            // while(chkSkipGcDesRaidPty(gsGcInfo.u16GcDesF2hTabFreePtr))
                            while((gsGcInfo.u16GcDesF2hTabFreePtr<=u16TlcRaidParityStr4k)&&
                                  ((gsGcInfo.u16GcDesF2hTabFreePtr&(g16ProgRaidUnit-1))<c4kNumPerRaidPty))
                            {
                                u32pSrcFAddrTab--;
                                u32pDesF2hTab--;
                                gsGcInfo.u16GcDesF2hTabFreePtr--;
                            }
#endif
                        }

                        u32pH2FTab++;
                        u32HMap++;
                    }
                    while(uFlag!=cFalse);

                    while(rmChkBopBz)
                        ;
                }
                while(rmChkSrchValFind&&(u16H2FStartUnit<g16PagePerH2fTab));
            }

            gsGcInfo.u32GcSrcBlkVpc[gsGcInfo.uGcSrcBlkIdx[uGcSrcBlkPtr]]=u32GcSrcBlkVpc;
            uGcSrcBlkPtr++;
        }

        rmSetSrchDefault;
    }
}    /* srchGcSrcF2hTab */

/*
   * void setOddPlaneProgGc(WORD u16ProgPageOfst)
   * {
   #if 1    // _DIS_Data_OddPlaneProg
   *  mClrGcFlag(cOddPlaneProg);
   #else
   *  if((gsGcInfo.u32GcDesbFreePagePtr+u16ProgPageOfst)&(g4kNumPerPage-1))
   *  {
   *      mSetGcFlag(cOddPlaneProg);
   *  }
   *  else if((g16ValidPgPerF2hTab-mod((gsGcInfo.u32GcDesbFreePagePtr+u16ProgPageOfst), g16TotalPgPerF2hTab))==0)
   *  {
   *      mClrGcFlag(cOddPlaneProg);
   *  }
   *  else if((g16ValidPgPerF2hTab-mod((gsGcInfo.u32GcDesbFreePagePtr+u16ProgPageOfst), g16TotalPgPerF2hTab))<g4kNumPerPage)
   *  {
   *      mSetGcFlag(cOddPlaneProg);
   *  }
   *  else
   *  {
   *      mClrGcFlag(cOddPlaneProg);
   *  }
   *
   *  if(!mChkFLParam(cMPlaneMo))
   *  {
   *      mClrGcFlag(cOddPlaneProg);
   *  }
   #endif
   * }
   */

void addGcDesSerial()
{
    if(gsGcInfo.u32GcDesSerial==c32InitSerialVal)
    {
        gsGcInfo.u32GcDesSerial=addPtrBy1(gsCacheInfo.u32CacheBlkSerial, c32MaxCacheSerial);
    }
    else if(judgeSerial(gsGcInfo.u32GcDesSerial, gsCacheInfo.u32CacheBlkSerial)==cSerialSmaller)
    {
        gsGcInfo.u32GcDesSerial=addPtrBy1(gsCacheInfo.u32CacheBlkSerial, c32MaxCacheSerial);
    }
    else
    {
        gsGcInfo.u32GcDesSerial=addPtrBy1(gsGcInfo.u32GcDesSerial, c32MaxCacheSerial);
    }
}    /* addGcDesSerial */

void initGcDesFblkProc()
{
    // WORD u16Fblock;

    if(mChkGcFlag(cGcDesFull))
    {
        mClrGcFlag(cGcDesFull);

        if(mGetGcFlow==cGcFlowS2S)
        {
            gsGcInfo.u16GcDesBlock=popSpareBlockCore0(cPopMinErsCnt|cPopSlcBlock|cPopDataBlock);
        }
        else if(mChkGcFlag(cGcSrchWearF))
        {
#if _EN_VPC_SWAP
            gsGcInfo.u16GcDesBlock=popSpareBlockCore0(cPopLargeErsCnt);
#else
            gsGcInfo.u16GcDesBlock=popSpareBlockCore0(cPopLargeErsCnt);
#endif
        }
        else
        {
#if _EN_VPC_SWAP
            gsGcInfo.u16GcDesBlock=popSpareBlockCore0(cPopMinErsCnt);
#else
            gsGcInfo.u16GcDesBlock=popSpareBlockCore0(cPopMinErsCnt);
#endif
        }

#if 0
        NLOG(cLogGC, GCCACHEB_C, 1, "GC des block: 0x%04X ", gsGcInfo.u16GcDesBlock);
#endif

        // gsTskFifoCtrl.u16PopFBlk=c16FBlockInitValue;
        if(mGetGcFlow==cGcFlowS2S)
        {
            gsGcInfo.u16GcDesSLCBlock=gsGcInfo.u16GcDesBlock;
            gsGcInfo.uGcDesType=cWriteGcDes;

            insSlcSortQCore0(gsGcInfo.u16GcDesBlock);
        }
        else
        {
            gsGcInfo.u16GcDesTLCBlock=gsGcInfo.u16GcDesBlock;
            gsGcInfo.uGcDesType=cWriteGcTLCDes;
        }

        gsGcInfo.u32GcDesbFreePagePtr=0;
        gsGcInfo.uGcDesBlkCnt++;
        gsGcInfo.u32FluBlkSerial=gsCacheInfo.u32FluBlkSerial;

        if(gsCacheInfo.u32FluBlkSerial==c32InitSerialVal)
        {
            gsGcInfo.u32FluBlkSerial=gsCacheInfo.u32CacheBlkSerial;
        }

#if _EN_RAID_GC
        gsCacheInfo.uRaidPtrGc=0;
        gsCacheInfo.uRaidF2HBankGc=0;
        gsCacheInfo.u16PartialParityPtrGc=0;
        // gsCacheInfo.u16PartialParityNumGc=g16TlcPartialParityNum;
#endif
        addGcDesSerial();
        progCacheInfoTab();
    }

    // rstRdyTyp();
    // setOddPlaneProgGc(0);
#if _GREYBOX
    chkGreyBoxGc(1);
#endif
}    /* initGcDesFblkProc */

/*
   * void updateGcDesF2hTab()
   * {
   *  BYTE uPlaneCnt;
   *
   *  while(gsRwCtrl.u32UpdFifoPtr!=gsRwCtrl.u32ProgFifoTail)
   *  {
   *      uPlaneCnt=garDesAddrInfo[gsRwCtrl.u32UpdFifoPtr].uPlaneCnt;
   *
   *      while(uPlaneCnt!=0)
   *      {
   *          gsGcInfo.u32GcDesbFreePagePtr++;
   *          gsRwCtrl.u16ProgPageOfst--;
   *          uPlaneCnt--;
   *      }
   *
   *      gsRwCtrl.u32UpdFifoPtr=addWrFfPtrBy1(gsRwCtrl.u32UpdFifoPtr);
   *  }
   * }
   */

/*
   * void gcDesBlkFullSetting()
   * {
   *  BYTE uWproIdx;
   *  WORD u16Fblock;
   *  LWORD u32Sum;
   *
   *  u32Sum=gsGcInfo.u32GcLastX2TBuildSrcTabTime+gsGcInfo.u32GcLastX2TMoveDataTime+gsGcInfo.u32GcLastX2TPostWRTime+
   *          gsGcInfo.u32GcLastX2TFlushF2hTabTime;
   *
   *  if(mGetGcFlow!=cGcFlowT2T)
   *  {
   *      gsGcInfo.u32GcLastS2TProcTime=u32Sum;
   *
   *      if(u32Sum>gsGcInfo.u32GcMaxS2TProcTime)
   *      {
   *          gsGcInfo.u32GcMaxS2TProcTime=u32Sum;
   *          gsGcInfo.u32GcMaxS2TBuildSrcTabTime=gsGcInfo.u32GcLastX2TBuildSrcTabTime;
   *          gsGcInfo.u32GcMaxS2TMoveDataTime=gsGcInfo.u32GcLastX2TMoveDataTime;
   *          gsGcInfo.u32GcMaxS2TPostWRTime=gsGcInfo.u32GcLastX2TPostWRTime;
   *          gsGcInfo.u32GcMaxS2TFlushF2hTabTime=gsGcInfo.u32GcLastX2TFlushF2hTabTime;
   *      }
   *  }
   *  else
   *  {
   *      gsGcInfo.u32GcLastT2TProcTime=u32Sum;
   *
   *      if(u32Sum>gsGcInfo.u32GcMaxT2TProcTime)
   *      {
   *          gsGcInfo.u32GcMaxT2TProcTime=u32Sum;
   *          gsGcInfo.u32GcMaxT2TBuildSrcTabTime=gsGcInfo.u32GcLastX2TBuildSrcTabTime;
   *          gsGcInfo.u32GcMaxT2TMoveDataTime=gsGcInfo.u32GcLastX2TMoveDataTime;
   *          gsGcInfo.u32GcMaxT2TPostWRTime=gsGcInfo.u32GcLastX2TPostWRTime;
   *          gsGcInfo.u32GcMaxT2TFlushF2hTabTime=gsGcInfo.u32GcLastX2TFlushF2hTabTime;
   *      }
   *  }
   *
   *  gsGcInfo.u32GcLastX2TBuildSrcTabTime=0;
   *  gsGcInfo.u32GcLastX2TMoveDataTime=0;
   *  gsGcInfo.u32GcLastX2TPostWRTime=0;
   *  gsGcInfo.u32GcLastX2TFlushF2hTabTime=0;
   *
   *  mSetGcFlag(cGcDesFull);
   *
   *  if(gsGcInfo.u16GcDesBlock!=c16FBlockInitValue)
   *  {
   *      if(mGetCacheBlkVpCnt(gsGcInfo.u16GcDesBlock))
   *      {
   *          mClrSkipGcSrch(gsGcInfo.u16GcDesBlock);
   *      }
   *      else
   *      {
   *          pushSpareBlockCore0(gsGcInfo.u16GcDesBlock, cPushNotErase|cPushDataBlock);
   *      }
   *  }
   *
   *  gsGcInfo.u16GcDesSLCBlock=c16FBlockInitValue;
   *  gsGcInfo.u16GcDesTLCBlock=c16FBlockInitValue;
   *  gsGcInfo.u16GcDesBlock=c16FBlockInitValue;
   *  gsGcInfo.uGcDesBlkCnt--;
   *
   *  if(!gsGcInfo.uGcDesBlkCnt)
   *  {
   *      while(gsGcInfo.uGcSrcBlkCnt)
   *      {
   *          u16Fblock=mGet16GcSrcBlock(cGcHeadSrcBlk);
   *
   *          if(mGetCacheBlkVpCnt(u16Fblock))
   *          {
   *              if(mChkSkipGcSrch(u16Fblock))
   *              {
   *                  mClrSkipGcSrch(u16Fblock);
   *              }
   *
   *              if(mChkGcSrcBlkBmap(u16Fblock))
   *              {
   *                  mClrGcSrcBlkBmap(u16Fblock);
   *              }
   *          }
   *
   *          deleteGcSrcBlk(cGcHeadSrcBlk);
   *      }
   *
   *      while(gsGcInfo.uGcSkipPopSrcBlockCnt)
   *      {
   *          gsGcInfo.uGcSkipPopSrcBlockCnt--;
   *          u16Fblock=gsGcInfo.u16arGcSkipPopSrcBlock[gsGcInfo.uGcSkipPopSrcBlockCnt];
   *
   *          if(!mChkSlcSkipBit(u16Fblock))
   *          {
   *              mClrSlcSkipRam(u16Fblock);
   *          }
   *
   *          if(mGetCacheBlkVpCnt(u16Fblock))
   *          {
   *              if(mChkSkipGcSrch(u16Fblock))
   *              {
   *                  mClrSkipGcSrch(u16Fblock);
   *              }
   *
   *              if(mChkGcSrcBlkBmap(u16Fblock))
   *              {
   *                  mClrGcSrcBlkBmap(u16Fblock);
   *              }
   *          }
   *
   #if _EN_SLCOpenBlkReadScrub
   *          if(u16Fblock==gsGcInfo.u16FlushBlk)
   *          {
   *              mSetGcFlushState(cFlushIdle);
   *              mClrGcFlag(cFlushforReclaim);
   *              gsGcInfo.u16FlushBlk=c16FBlockInitValue;
   *          }
   #endif
   *
   *          gsGcInfo.u16arGcSkipPopSrcBlock[gsGcInfo.uGcSkipPopSrcBlockCnt]=cInvldFBlk;
   *      }
   *
   *      uWproIdx=cWproGcDesF2hTab00;
   *
   *      do
   *      {
   *          remWproPageCore0(uWproIdx);
   *
   *          uWproIdx++;
   *      }
   *      while(uWproIdx<=cWproGcInfoPage);
   *
   *      // while(gsWproInfo.u16arWproIdxPagePtr[cWproGcInfoPage]<gsWproInfo.u16PagePerBlock3);
   *
   *      mSetGcFlow(cGcFlowIdl);
   *      mSetGcState(cGcStateIdle);
   *
   *      resetGCFlagCore0();
   *      //
   *      //     if(mChkGcQue(cGcTypTLCWearLvl))
   *      // {
   *      //  gsCacheInfo.u16TLCGcWLCnt++;
   *      //  mClrGcFlag(cGcSrchWearF);
   *      // }
   *      //
   *      //
   *      // if(!gsGcInfo.uGcPrioTlcBlkNumPtr)
   *      // {
   *      //  if(mChkGcQue(cGcTypTLCWearLvl))
   *      //  {
   *      //      mPopGcQue(cGcTypTLCWearLvl);
   *      //  }
   *      // }
   *      //
   *      // if(!gsGcInfo.uGcPrioTlcBlkNumPtr&&!gsGcInfo.uGCSLCReclaimPtr)
   *      // {
   *      //  mClrGcFlag(cUnderReclaim);
   *      // }
   *  }
   * }  */      /* gcDesBlkFullSettg */

/*
   * Purpose:
   *  Return 4KCnt to be programmed.
   */
// BYTE getTotalGc4kCnt()
// {
//    return g4kNumPerPage*gTotalChNum*cProgCntPerWL;
// }
#if 0
BYTE chkBgdWlColdBlk(BYTE uBopSrchF, BYTE uTyp)
{
    return 0;
    /*
       * WORD u16MinSprErsCnt, u16MinDatErsCnt;
       * WORD u16MinSLCErsCnt, u16MinMLCErsCnt;
       * WORD u16SrchStartBlk;
       * WORD u16SrchEndBlk;
       * WORD u16WlThr;
       *
       * if(uTyp==cWLTyp_SLC)
       * {
       * u16WlThr=((cbCidTable[0x03]*0x0100)+cbCidTable[0x02]);
       * }
       * else
       * {
       * u16WlThr=((cbCidTable[0x2A]*0x0100)+cbCidTable[0x29]);
       * }
       *
       * u16SrchStartBlk=g16FirstFBlock;
       * u16SrchEndBlk=g16TotalFBlock;
       *
       * rmSetSrchLorBound(0);
       * // L06B GC slc spare
       * bopSrchRam((LWORD)g32arGlobEraseCnt, c31BitFF, u16SrchStartBlk, u16SrchEndBlk,
       * uBopSrchF|cBopLwordMo|cBopSrchSkip|cBopWait);
       * u16MinSLCErsCnt=rmGetSrchRslVal;    // &c15BitFF;
       * // L06B GC mlc spare
       * rmSetSrchLorBound(0);
       * bopSrchRam((LWORD)g32arGlobEraseCnt, c31BitFF, u16SrchStartBlk, u16SrchEndBlk,
       * uBopSrchF|cBopLwordMo|cBopWait);
       * u16MinMLCErsCnt=rmGetSrchRslVal;    // &c15BitFF;
       * u16MinSprErsCnt=(u16MinSLCErsCnt<=u16MinMLCErsCnt)?u16MinSLCErsCnt:u16MinMLCErsCnt;
       * // L06B GC slc data
       * rmSetSrchLorBound(0);
       * // bopSrchRam((LWORD)g32arGlobEraseCnt, c31BitFF, u16SrchStartBlk, u16SrchEndBlk,
       * cBopSrchMin|cBopLwordMo|cBopSrchSkip|cBopWait);
       * bopSrchRam((LWORD)g32arGlobEraseCnt, c32BitFF, u16SrchStartBlk, u16SrchEndBlk,
       * cBopSrchMin|cBopLwordMo|cBopSrchSkip|cBopWait);
       * u16MinSLCErsCnt=rmGetSrchRslVal;    // &c15BitFF;
       * // L06B GC mlc data
       * rmSetSrchLorBound(0);
       * // bopSrchRam((LWORD)g32arGlobEraseCnt, c31BitFF, u16SrchStartBlk, u16SrchEndBlk,
       * cBopSrchMin|cBopLwordMo|cBopWait);
       * bopSrchRam((LWORD)g32arGlobEraseCnt, c32BitFF, u16SrchStartBlk, u16SrchEndBlk,
       * cBopSrchMin|cBopLwordMo|cBopWait);
       * u16MinMLCErsCnt=rmGetSrchRslVal;    // &c15BitFF;
       * u16MinDatErsCnt=(u16MinSLCErsCnt<=u16MinMLCErsCnt)?u16MinSLCErsCnt:u16MinMLCErsCnt;
       *
       * rmSetSrchLorBound(0);
       *
       * if((u16MinSprErsCnt>u16MinDatErsCnt)&&((u16MinSprErsCnt-u16MinDatErsCnt)>u16WlThr))
       * {
       * return cTrue;
       * }
       * else
       * {
       * return cFalse;
       * }
       */
}

#endif
#endif/* if _PRJ_ISP */

BYTE hostRequset(void)
{
    if((mChkGcFlag(cPwOnGcF)||mChkGcFlag(cPwOnExtraGcF)||mChkGcFlag(cPwOnH2FGcF))&&(gGCOpt&gbPwOnGC))    // 20190508_ChrisSu_01
    {
        return 0;
    }
    else
    {
        return (rmChkCmdRdy&&rmChkCcRdy)||
               (mNvmeChkCcEnOn||mPcieChkRst||mPcieChkPerst||mNvmeChkNssr||mPcieChkFlr||mNvmeChkRst||mNvmeChkShn||rmChkPcieD3State);                               //
                                                                                                                                                                  // for
        // Jira-15
    }
}    /* bgdClnCacheblkProc */

WORD addCopyBufPtrGc(WORD u16SbufPtr, LWORD u32AddCnt)
{
    u32AddCnt=u32AddCnt&(c16WriteBufSize-1);    // mod(u32AddCnt, c16CopyBufSize);

    u16SbufPtr+=u32AddCnt;

    if(u16SbufPtr>=(c16CopySIdx+c16WriteBufSize))
    {
        u16SbufPtr-=c16WriteBufSize;
    }

    return u16SbufPtr;
}    /* addNewGcSrcBlk */

/*
   * BYTE cmprReadSrc(WORD u16Hblock, WORD u16H4k, WORD u16GcSrcBlock, LWORD u32F4k)    // , BYTE uCmprTyp)
   * {
   *  H2FTABLER usH2fTable;
   *
   *  u16Hblock&=~c16Bit15;
   *
   *  // if (chkSrcInH2fTab(u16Hblock, u16H4k, &usH2fTable))
   *  if(chkSrcInH2f1kTab(u16Hblock, u16H4k, &usH2fTable))
   *  {
   *      if(((usH2fTable.u16FBlock==u16GcSrcBlock))&&(usH2fTable.u32F4k==u32F4k))    // chkH2fTabFpageHit(u16H4k, u16Fpage, &usH2fTable))
   *      {
   *          return cTrue;
   *      }
   *      else
   *      {
   *          return cFalse;
   *      }
   *  }
   *  else
   *  {
   *      return cFalse;
   *  }
   * }    cmprReadSrc */
void addDesAddrInfoGc()
{
    garDesAddrInfo[gsGcInfo.uPreProgFifo].uAddrOpt&=~(cDone|cProgFail);
    gsGcInfo.uPreProgFifo=addWrFfPtrBy1(gsGcInfo.uPreProgFifo);
    mSetGcFlag(cGcNewDesF);
    gsGcInfo.uOneShotChPtr=addPtrBy1(gsGcInfo.uOneShotChPtr, gTotalChNum);
}    /* addDesAddrInfoGc */

WORD setProgFifoOptGc(WORD u16WbufPtr, BYTE uOpTyp)
{
    gsGcInfo.uGcWr4kPtr++;
    // gsGcInfo.u16GcDesbPage2ChgBlk--;

    if(gsGcInfo.uGcWr4kPtr==g4kNumPerPage)
    {
        gSectorH=0;
        gpFlashAddrInfo->u16BufPtr=u16WbufPtr;
        gOpTyp=uOpTyp;
        gsRwCtrl.u16ProgPageOfst+=gsGcInfo.uGcWr4kPtr;
        gpFlashAddrInfo->uPrdPtr=0xFF;
        gpFlashAddrInfo->uPlaneCnt=gsGcInfo.uGcWr4kPtr;
        gsGcInfo.uGcWr4kPtr=gsGcInfo.uGcRd4kPtr=0;

        // if(gsHmbInfo.uHmbEnGcCache&&mChkFLOption(cEnCacheProg)&&
        //   (((mGetPageSelCmd(gpFlashAddrInfo)==cSlcCmd)||(mGetPageSelCmd(gpFlashAddrInfo)==cMsbPreFixCmd))&&
        //    (g16FPage!=(g16PagePerBlock1_SLC-1))))
        if(gsHmbInfo.uHmbEnGcCache&&mChkFLOption(cEnCacheProg)&&(g16FPage!=(g16PagePerBlock1_SLC-1)))
        {
            gpFlashAddrInfo->u16RwOpt|=c16Bit0|c16Bit1|c16Bit2|c16Bit3|c16Bit6|c16Bit7|c16Bit15;
            gOpTyp=cCacheProgData;
        }
        else
        {
            gpFlashAddrInfo->u16RwOpt|=c16Bit0|c16Bit1|c16Bit2|c16Bit6|c16Bit7|c16Bit15;
        }

        gpFlashAddrInfo->uRwHalfKb=gSectorPerPageH;
        // gpFlashAddrInfo->u32Serial=u32GcDesSerial;
        addDesAddrInfoGc();
        return addCopyBufPtrGc(u16WbufPtr, gSectorPerPageH);
    }

    return u16WbufPtr;
}    /* setProgFifoOptGc */

WORD loadPartialGCTab(WORD u16TotalGc4kCnt, WORD u16WbufPtr)
{
    WORD u16DesF2Hbuf, u16SrcFAddrbuf;
    BYTE uPageOfst;

    uPageOfst=gsGcInfo.uPartTabSizeInBank-1-(gsGcInfo.uLoadGCTabIdx%gsGcInfo.uPartTabSizeInBank);

    u16DesF2Hbuf=c16GcMoveDesAddrIdx+gSectorPerPlaneH;
    u16SrcFAddrbuf=c16GcMoveDesAddrIdx+(gSectorPerPlaneH*3);

    if(gsGcInfo.uLoadGCTabIdx&cBit0)
    {
        u16DesF2Hbuf=c16GcMoveDesAddrIdx;
        u16SrcFAddrbuf=c16GcMoveDesAddrIdx+(gSectorPerPlaneH*2);
    }

    if(mChkGcInfoHmbLink(cWproGcDesF2hTab00+gsGcInfo.uGcDesF2hTabBank))
    {
        readHmbGcInfoTab(u16DesF2Hbuf, cWproGcDesF2hTab00+gsGcInfo.uGcDesF2hTabBank, 0, uPageOfst|cBit7);
        uPageOfst=uPageOfst+gsGcInfo.uPartTabSizeInBank;
        readHmbGcInfoTab(u16SrcFAddrbuf, cWproGcDesF2hTab00+gsGcInfo.uGcDesF2hTabBank, cWaitReadDone, uPageOfst|cBit7);

        if(mChkGcFlag(cGcHmbGcInfoFail))
        {
            mClrGcFlag(cGcHmbGcInfoFail);
            uPageOfst=gsGcInfo.uPartTabSizeInBank-1-(gsGcInfo.uLoadGCTabIdx%gsGcInfo.uPartTabSizeInBank);
            mClrGcInfoHmbLink(cWproGcDesF2hTab00+gsGcInfo.uGcDesF2hTabBank);
        }

#if  0
        NLOG(cLogGC,
             GCCACHEB_C,
             2,
             "Load Partial GcInfo from HMB, GcTabIdx: 0x%04X, GcDesF2hTabBank: 0x%04X",
             gsGcInfo.uLoadGCTabIdx,
             gsGcInfo.uGcDesF2hTabBank);
#endif
    }

    // else
    if(!mChkGcInfoHmbLink(cWproGcDesF2hTab00+gsGcInfo.uGcDesF2hTabBank))
    {
        if(gsHmbInfo.uHmbEnGcCache)
        {
            while(gsRwCtrl.u32FreeSrcFifoTail!=gsRwCtrl.u32FreeSrcFifoHead)
            {
                u16WbufPtr=setWriteGcDataHmb(u16TotalGc4kCnt, u16WbufPtr);
            }
        }

        readWproPageCore0(cWproGcDesF2hTab00+gsGcInfo.uGcDesF2hTabBank, u16DesF2Hbuf, uPageOfst|cBit7);
        uPageOfst=uPageOfst+gsGcInfo.uPartTabSizeInBank;
        readWproPageCore0(cWproGcDesF2hTab00+gsGcInfo.uGcDesF2hTabBank, u16SrcFAddrbuf, uPageOfst|cBit7);

#if  0
        NLOG(cLogGC,
             GCCACHEB_C,
             2,
             "Load Partial GcInfo from Wpro, GcTabIdx: 0x%04X, GcDesF2hTabBank: 0x%04X",
             gsGcInfo.uLoadGCTabIdx,
             gsGcInfo.uGcDesF2hTabBank);
#endif
    }

    gsGcInfo.uLoadGCTabIdx++;

    if((gsGcInfo.uLoadGCTabIdx%gsGcInfo.uPartTabSizeInBank)==1)
    {
        gsGcInfo.u32GCInfoTabSize+=gsGcInfo.u16RemainF2h4k;
    }
    else
    {
        gsGcInfo.u32GCInfoTabSize+=gsGcInfo.u16EntryInPlane;    // *gsGcInfo.uLoadGCTabIdx;
    }

    return u16WbufPtr;
}    /* loadPartialGCTab */

BYTE chkLoadGCInfoTab()
{
    if((gsGcInfo.u32GcSrcF4kPtr==(gsGcInfo.u32GCInfoTabSize-(gsGcInfo.u32GCInfoTabSize%gsGcInfo.u32Prog4kCntPerChIntPlnWl)))&&
       (gsGcInfo.uLoadGCTabIdx<(gsGcInfo.uGCDesF2hBankNum*gsGcInfo.uPartTabSizeInBank)))
    {
        return cTrue;
    }
    else
    {
        return cFalse;
    }
}    /*ChkLoadGCInfoTab*/

void loadGcInfoTab(BYTE uWproIdx, WORD u16SbufPtr, BYTE uStartPageOffset)    // , WORD u16RwOpt)
{
    if(mChkGcInfoHmbLink(uWproIdx))
    {
        readHmbGcInfoTab(u16SbufPtr, uWproIdx, cWaitReadDone, uStartPageOffset);    // for laod 96KB or 48KB or 16KB table

        if(mChkGcFlag(cGcHmbGcInfoFail))
        {
            mClrGcFlag(cGcHmbGcInfoFail);
            mClrGcInfoHmbLink(uWproIdx);
        }
    }

    // else
    if(!mChkGcInfoHmbLink(uWproIdx))
    {
        // gsRwCtrl.u32FreeSrcFifoHead=gsGcInfo.uPreSrcFifo;

        // while(gsRwCtrl.u32FreeSrcFifoTrig!=gsRwCtrl.u32FreeSrcFifoHead)
        //    ;

        uStartPageOffset&=~cBit6;
        readWproPageCore0(uWproIdx, u16SbufPtr, uStartPageOffset);

        // gsGcInfo.uPreSrcFifo=gsRwCtrl.u32FreeSrcFifoHead;
    }
}    /* loadGcInfoTab */

WORD setWriteGcDataHmb(WORD u16TotalGc4kCnt, WORD u16WbufPtr)
{
    waitHmbPrdDone();

    while((gsGcInfo.u16HmbGcCache4kCnt-u16TotalGc4kCnt)>=(cHmbChunkSctrSize>>cSctrTo4kShift))
    {
        if(gsHmbInfo.uHmbFreeHwPrdCnt<3)
        {
            break;
        }
        else
        {
            txfrHmbData(cHmbWriteData,
                        u16WbufPtr,
                        cHmbChunkSctrSize,
                        (gsGcInfo.uHmbGcCachePtr*cHmbChunkSctrSize)<<9,
                        gsGcInfo.uHmbGcCachePtr,
                        cHmbGcCache,
                        cHmbTsbPath|cHmbBufflagChk,
                        0);
            writeE2eCrc2Hmb(u16WbufPtr>>5);
            u16WbufPtr=addCopyBufPtrGc(u16WbufPtr, cHmbChunkSctrSize);
            gsGcInfo.uHmbGcCachePtr=addPtrBy1(gsGcInfo.uHmbGcCachePtr, gsGcInfo.uMaxHmbGcCacheNum);
            gsGcInfo.uHmbGcCacheCnt++;
            gsGcInfo.u16HmbGcCache4kCnt-=(cHmbChunkSctrSize>>cSctrTo4kShift);
        }
    }

    return u16WbufPtr;
}    /* setWriteGcDataHmb */

BYTE chkAddGcOneShotPtr()
{
    gsGcInfo.uSrcHandlePageType++;

    if(gsGcInfo.uSrcHandlePageType==gsGcInfo.uGCDesPagePerWL)
    {
        gsGcInfo.uSrcHandlePageType=0;
        gsGcInfo.uGcIntlvPtr++;

        if(gsGcInfo.uGcIntlvPtr==gIntlvWay)
        {
            gsGcInfo.uGcIntlvPtr=0;
            gsGcInfo.u16GcOneShotPtr++;
        }

        return cTrue;
    }

    return cFalse;
}    /* chkAddGcOneShotPtr */

LWORD getGcTabAddr(LWORD u32TabAddr)
{
    LWORD u32PartTabBase;

    if(!gsHmbInfo.uHmbEnGcCache)
    {
        u32TabAddr=((gsGcInfo.u16GcOneShotPtr*gsGcInfo.u32Prog4kCntPerChIntPlnWl)+(gsGcInfo.uGcIntlvPtr*gsGcInfo.u32Prog4kCntPerChPg));
    }

    u32PartTabBase=u32TabAddr/gsGcInfo.u16GCDesTotalPgPerF2hTab;
    u32TabAddr=(u32TabAddr%gsGcInfo.u16GCDesTotalPgPerF2hTab)+gsGcInfo.u16DumF2h4K;
    u32PartTabBase=(u32PartTabBase*gsGcInfo.uPartTabSizeInBank)+(u32TabAddr/gsGcInfo.u16EntryInPlane);
    u32PartTabBase=(gsGcInfo.u16EntryInPlane<<1)-((u32PartTabBase&0x1)*gsGcInfo.u16EntryInPlane)-1;
    // u32TabAddr=(LWORD)c16GcMoveDesAddr+((u32PartTabBase-(u32TabAddr%gsGcInfo.u16EntryInPlane))<<2);
    return (LWORD)c16GcMoveDesAddr+((u32PartTabBase-(u32TabAddr%gsGcInfo.u16EntryInPlane))<<2);
}    /* getGcTabAddr */

void chkExitGcCondition()    // 20190802_Louis
{
    if(gsHmbInfo.uHmbEnable&&(rmChkPcieD3State||mPcieChkRst||mPcieChkPerst||mNvmeChkNssr||mPcieChkFlr||mNvmeChkRst))
    {
        NLOG(cLogGC, GCCACHEB_C, 0, "Receive D0 to D3 or Reset! Exit GC!");
        mSetGcFlag(cBrkBgdGcF);
        mSetGcFlag(cGcDesFailAbort);
    }
}







