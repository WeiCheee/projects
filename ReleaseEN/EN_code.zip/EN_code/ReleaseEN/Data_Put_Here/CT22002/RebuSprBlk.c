







#if _EN_CHRONUS_UART_DEBUG
#include "inc/DebugLog.h"
#include "inc/EventLogIDX.h"
#include "inc/EventLogFunctionIDX.h"
#endif

void addReBuCacheBlock(RLFLUSHF2HTAB *upFlushF2hTab, LWORD u32Serial, WORD u16FBlock, BYTE uBank)
{
    if(upFlushF2hTab->uCnt<cMaxReBuBankNum)
    {
        upFlushF2hTab->u32arSerial[upFlushF2hTab->uCnt]=u32Serial;
        upFlushF2hTab->u16arBlock[upFlushF2hTab->uCnt]=u16FBlock;
        upFlushF2hTab->uarBankNum[upFlushF2hTab->uCnt]=uBank;
        upFlushF2hTab->uCnt++;
    }
    else
    {
#if _EN_KEEP_RW_ON_ERROR
        relinkKeepRwonError(((uBank<<8)|cAddReBuCacheBlock), (WORD)u16FBlock, (WORD)(u32Serial&0xFFFF), (WORD)(u32Serial>>16));
#else
        relinkSaveDummyQBAnalysis(uBank, (WORD)(u16FBlock), (WORD)(u32Serial>>16), (WORD)(u32Serial&0xFFFF));
        relinkSaveQBDummy(cAddReBuCacheBlock);
#endif
    }
}    /* addReBuCacheBlock */

void addRdlinkReBuCacheBlock(WORD u16FBlock, BYTE uBank)
{
    if(gsRdlinkInfo.uRebuCachebCnt<cMaxReBuCacheBlockNum)
    {
        gsRdlinkInfo.u16arReBuCacheBlock[gsRdlinkInfo.uRebuCachebCnt]=u16FBlock;
        gsRdlinkInfo.uarReBuCacheBlockBank[gsRdlinkInfo.uRebuCachebCnt]=uBank;
        gsRdlinkInfo.uRebuCachebCnt++;
    }
    else
    {
#if _EN_KEEP_RW_ON_ERROR
        relinkKeepRwonError(((uBank<<8)|cAddReBuCacheBlock), (WORD)u16FBlock, (WORD)gsRdlinkInfo.uRebuCachebCnt, 0);
#else
        relinkSaveDummyQBAnalysis(uBank, (WORD)(u16FBlock), (WORD)gsRdlinkInfo.uRebuCachebCnt, 0);
        relinkSaveQBDummy(cAddRdlinkReBuCacheBlock);
#endif
    }
}    /* addRdlinkReBuCacheBlock */

void reSortGcBlk()
{
    WORD u16Idx, u16Idx2;
    WORD u16Loop1, u16Loop2, u16Loop3;
    BYTE uSerial, uSrchCnt, uChange;
    BYTE uMaxSrchLoop=128;

    u16Loop1=1;

    do
    {
        u16Idx=g16arFoundCacheIdx[u16Loop1];

        if(garFoundCacheQ[u16Idx].uBlkType==cFoundGcDes)    // &&(garFoundCacheQ[u16Idx].u16Fblock<g16FirstTLCBlock))    // GcDes Slc
        {
            uSerial=garFoundCacheQ[u16Idx].uGcFluBlkSn_B0;
            u16Loop2=u16Loop1;
            uSrchCnt=0;
            uChange=0;

            do
            {
                uSrchCnt++;
                u16Loop2--;
                u16Idx2=g16arFoundCacheIdx[u16Loop2];

                if((garFoundCacheQ[u16Idx2].uBlkType==cFoundCache)&&(uSerial==(garFoundCacheQ[u16Idx2].u32Serial&0xFF)))
                {
                    for(u16Loop3=u16Loop1; u16Loop3>u16Loop2; u16Loop3--)
                    {
                        g16arFoundCacheIdx[u16Loop3]=g16arFoundCacheIdx[u16Loop3-1];
                        uChange=1;
                    }

                    break;
                }
            }
            while((u16Loop2!=0)||(uSrchCnt==uMaxSrchLoop));

            if(uChange==1)
            {
                g16arFoundCacheIdx[u16Loop2]=u16Idx;
            }
        }

        u16Loop1++;
    }
    while(u16Loop1<g16FoundCachebCnt);
}    /* reSortGcBlk */

/*
   * BYTE chkSeedGrp(WORD u16Seed)
   * {
   *  BYTE uSeedGrp;
   *  WORD u16Fpage, u16Idx;
   *
   *  for(u16Fpage=0; u16Fpage<g16PagePerBlock1_SLC; u16Fpage++)
   *  {
   *      for(uSeedGrp=0; uSeedGrp<cSeedGrpNum; uSeedGrp++)
   *      {
   *          u16Idx=uSeedGrp*g16PagePerBlock1_SLC+u16Fpage;
   *
   *          if(u16Seed==g16arSeedTable[u16Idx])
   *          {
   *              break;
   *          }
   *      }
   *
   *      if(uSeedGrp!=cSeedGrpNum)
   *      {
   *          break;
   *      }
   *  }
   *  return uSeedGrp;
   * }
   */

void addBlock2CacheQ(WORD u16FBlock, BYTE uBlockID, BYTE uBlkType)
{
    BLKSPRINFO usBlkSprInfo;

    if((u16FBlock>=g16FirstFBlock)&&(u16FBlock<g16TotalFBlock))
    {
        if((!get1stPageInfo(u16FBlock, cNoAnyMode, &usBlkSprInfo))||(mGetMetaBlockId(usBlkSprInfo)==0xFF))
        {
            /*
               *  do not push at this step, handle after finish read link.
               */
        }
        else if(mGetMetaBlockId(usBlkSprInfo)==uBlockID)
        {
            if(uBlockID==cGcDesBlockID)
            {
                sortFoundCacheQ(mGetMetaBlkSn(usBlkSprInfo), u16FBlock, mGetMetaOpTyp(usBlkSprInfo), uBlkType);
            }
            else
            {
                sortFoundCacheQ(mGetMetaBlkSn(usBlkSprInfo), u16FBlock, 0, uBlkType);
            }

            setBlkSerial(cCacheBlockID, mGetMetaBlkSn(usBlkSprInfo));
        }
        else
        {
#if _EN_KEEP_RW_ON_ERROR
            relinkKeepRwonError(cAddBlock2CacheQ, u16FBlock, (WORD)uBlockID, (WORD)mGetMetaBlockId(usBlkSprInfo));

            if(u16FBlock==gsRdlinkInfo.u16BkActiveCacheBlock)
            {
                mSetCacheInfoFlag(cCacheBlockFull);
                gsCacheInfo.u16ActiveCacheBlock=c16FBlockInitValue;
                gsCacheInfo.u32CacheFreePagePtr=c32BitFF;
                g16BkRdActiveCacheBlock=c16FBlockInitValue;
                g32BkRdCacheFreePagePtr=c32BitFF;
                gsRdlinkInfo.u16BkActiveCacheBlock=c16FBlockInitValue;
            }
            else if(u16FBlock==gsRdlinkInfo.u16BkFluCacheBlock)
            {
                gsRdlinkInfo.u16BkFluCacheBlock=c16FBlockInitValue;
            }
#else
            relinkSaveDummyQBAnalysis(u16FBlock, (WORD)uBlockID, (WORD)mGetMetaBlockId(usBlkSprInfo), 0);
            relinkSaveQBDummy(cAddBlock2CacheQ);
#endif/* if _EN_KEEP_RW_ON_ERROR */
        }
    }
}    /* addBlock2CacheQ */

/*
   * void scanTlcFBlock()
   * {
   *  // L06B rebuild flow need modify this function.
   *  WORD u16Fblock;
   *  BLKSPRINFO usBlkSprInfo[cMaxBankNum];
   *
   *  BYTE uSeedGrp;
   *
   *  // disable UNC stop
   *  setSelMulFL(1);
   *  rmDisUNCStop;
   *  rmDisOnesCntStop;
   *  setSelMulFL(0);
   *
   *  // debugLoop();
   *
   *  for(u16Fblock=g16FirstTLCBlock; u16Fblock<g16TotalFBlock; u16Fblock++)
   *  {
   *      if(!garGlobEraseCnt[u16Fblock].ubPopped)
   *      {
   *          if(gsRdlinkInfo.ubDoNotScanAllBlk)
   *          {
   *              gsCacheInfo.u16TLCSprBlockCnt++;
   *          }
   *          else if(gsRdlinkInfo.ubCacheInfoValid)
   *          {
   *              gsCacheInfo.u16TLCSprBlockCnt++;
   *              dummyProgBlk(u16Fblock);    // keep all block are closed
   *          }
   *          else
   *          {
   *              // bopClrRam((LWORD)&usBlkSprInfo, sizeof(usBlkSprInfo), 0xFFFF_FFFF, cClrDccm|cBopWait);
   *              fillCcmVal((BYTE *)&usBlkSprInfo, sizeof(usBlkSprInfo), 0xFF);
   *              // following are Ecc ok and match gCardOpNum
   *              getTlcF2hSprInfo(u16Fblock, usBlkSprInfo);
   *
   *              if(gbEccFail)
   *              {
   *                  // setErrorBlock(u16Fblock, 0xFFFF, 0x001|c16Bit15);//mark later
   *                  gsCacheInfo.u16TLCSprBlockCnt++;
   *              }
   *              else
   *              {
   *                  for(uSeedGrp=0; uSeedGrp<gTotalBankOfF2hTab; uSeedGrp++)
   *                  {
   *                      if(mGetMetaBlockId(usBlkSprInfo[uSeedGrp])!=cF2hTableID)
   *                      {
   *                          break;
   *                      }
   *                  }
   *
   *                  if(uSeedGrp==gTotalBankOfF2hTab)
   *                  {
   *                      sortFoundTLCQ(usBlkSprInfo, u16Fblock, 1);
   *                      garGlobEraseCnt[u16Fblock].u16EraseCnt++;    // Hank, TLC doesn't save serial
   *                      mSetPopDeniedF(u16Fblock);
   *                  }
   *                  else    // Cache Info Valid or half or empty
   *                  {
   *                      gsCacheInfo.u16TLCSprBlockCnt++;
   *                  }
   *              }
   *          }
   *      }
   *  }
   *
   * #if _EN_ReGcDesTLC
   *  if(gsRdlinkInfo.ubCacheInfoValid)
   *  {
   *
   *      if(g16BkGcDesTlcBlock!=0xFFFF)
   *      {
   *          // bopClrRam((LWORD)&usBlkSprInfo, sizeof(usBlkSprInfo), 0xFFFF_FFFF, cClrDccm|cBopWait);
   *          fillCcmVal((BYTE *)&usBlkSprInfo, sizeof(usBlkSprInfo), 0xFF);
   *
   *          // following are Ecc ok and match gCardOpNum
   *          getF2hSprInfo(g16BkGcDesTlcBlock, usBlkSprInfo);
   *
   *          if(gbEccFail)
   *          {
   *
   *              pushSpareBlock(g16BkGcDesTlcBlock, cPushNotErase);
   *              g16BkGcDesTlcBlock=0xFFFF;
   *          }
   *          else
   *          {
   *              for(uSeedGrp=0; uSeedGrp<gTotalBankOfF2hTab; uSeedGrp++)
   *              {
   *                  if(mGetMetaBlockId(usBlkSprInfo[uSeedGrp])!=cF2hTableID)
   *                  {
   *                      break;
   *                  }
   *              }
   *
   *              if(uSeedGrp==gTotalBankOfF2hTab)
   *              {
   *                  sortFoundTLCQ(usBlkSprInfo, g16BkGcDesTlcBlock, 1);
   *              }
   *              else        // half or ecc fail due to spor
   *              {
   *                  pushSpareBlock(g16BkGcDesTlcBlock, cPushNotErase);
   *                  g16BkGcDesTlcBlock=0xFFFF;
   *              }
   *          }
   *      }
   *  }
   * #endif
   *
   *  setSelMulFL(1);
   *  rmEnUNCStop;
   *  rmEnOnesCntStop;
   *  resetECC();
   *  setSelMulFL(0);
   *
   *  setSprOnesCntCondition(cEnSprOnesCntSetting);
   *
   * #if _EN_ALL_SLC_BLK
   *  if(gsCacheInfo.u16TLCSprBlockCnt!=0)
   *  {
   *      debugDeadLock(0);
   *  }
   * #endif
   * }
   */

void dummyProgBlk(WORD u16FBlock)
{
#if _TEMP_MARK
    BLKSPRINFO usBlkSprInfo;

    get1stPageInfo(u16FBlock, cReadWithoutRetry|cReadLastPage, &usBlkSprInfo);

    if(!gbEccFail&&gbOnesCntFail)
    {
        destroySrcBlock(u16FBlock);
    }
#endif
}

void setBlkSerial(BYTE uType, LWORD u32BlkSerial)
{
    LWORD *u32pSerial;

    switch(uType)
    {
        case cCacheBlockID:
        case cGcDesBlockID:
            u32pSerial=&gsCacheInfo.u32CacheBlkSerial;
            break;

        /*
           * case cH2fTableID:
           *  u32pSerial= &gsRdlinkInfo.u32H2fTabBlkSerial;
           *  break;
           */
        case cCacheInfoTableID:
            u32pSerial=&gsCacheInfo.u32CacheInfoSerial;
            break;

        default:

#if _EN_KEEP_RW_ON_ERROR
            relinkKeepRwonError(cSetBlkSerial, (WORD)uType, (WORD)(u32BlkSerial&0xFFFF), (WORD)(u32BlkSerial>>16));
#else
            relinkSaveDummyQBAnalysis((WORD)uType, (WORD)(u32BlkSerial>>16), (WORD)(u32BlkSerial&0xFFFF), 0);
            relinkSaveQBDummy(cSetBlkSerial);
#endif

            break;
    }    /* switch */

    if((*u32pSerial)==c32InitSerialVal)
    {
        (*u32pSerial)=u32BlkSerial;
    }
    else
    {
        if(judgeSerial(u32BlkSerial, (*u32pSerial))==cSerialLarger)
        {
            (*u32pSerial)=u32BlkSerial;
        }
    }
}    /* setBlkSerial */

#if 0
void dummyProgTab(BYTE uType, BYTE uBID)
{
    BYTE uPageOfst, uPlaneAddr;
    ADDRINFO usTmpAddrInfo;
    BYTE uBzBitMap=0;

    // BYTE uLoop;
    // WORD u16BufAddr;

    for(uPageOfst=0; uPageOfst<gTotalPlaneOfCacheInfoTab; uPageOfst+=gPlaneNum)
    {
        setWriteDes(uPageOfst, &usTmpAddrInfo, uType);
        setFLAddrActCh(gActiveCh, &usTmpAddrInfo);
        gSectorH=0;

        if(!mChkBitMask(uBzBitMap, gActiveCh))
        {
            mSetBitMask(uBzBitMap, gActiveCh);
        }

        mSetFRwParam(c16Tsb0SIdx+(uPageOfst*gSectorPerPlaneH), gSectorPerPageH, c16Bit0|c16Bit2|c16Bit15, cPwrOnDummyProg);
        waitCmdFifoDpt(gActiveCh, &usTmpAddrInfo);

        for(uPlaneAddr=0; uPlaneAddr<gPlaneNum; uPlaneAddr++)
        {
            if(uType==cWriteH2fTab)
            {
                setSprByteOfTabBlk(uBID, 0xFFFF, 0xFFFF, gsCacheInfo.uActH2fTabBlkIdx, gsCacheInfo.u32H2fTabBlkSerial, uPlaneAddr,
                                   0xFFFF);
            }
            else
            {
                setSprByteOfTabBlk(uBID, uPageOfst+uPlaneAddr, 0xFFFF, 0xFFFF, gsCacheInfo.u32CacheBlkSerial, uPlaneAddr, 0xFFFF);
            }
        }

        waitChCeBz(gActiveCh, gIntlvAddr, 0);
        flashProgPage(mGetWriteBuf, mGetProgSctrCnt, mGetWriteOpt);
        // gsRwCtrl.uWaitFlag[gActiveCh][gActiveCe][gIntlvAddr]=gOpTyp;
        setBzInfo(gOpTyp, gActiveCh, gIntlvAddr);
        // gsRwCtrl.usWaitInfo[gActiveCh][gIntlvAddr].uStatusErrStop=0;    // 1;
    }

    waitAllChCeBz();
}    /* dummyProgTab */

#endif/* if 0 */

#if 0    // temp remove
BYTE chkReadTabEcc(BYTE uType)
{
    ADDRINFO usTmpAddrInfo;
    BLKSPRINFO usBlkSprInfo;
    WORD u16FBlock, u16PagePtr;
    BYTE uTotalPlaneOfTab, uPageOfst;

    switch(uType)
    {
/*
   *      case cWriteCacheInfoTab:
   *          u16FBlock=gsCacheInfo.u16CacheInfoBlk;
   *          u16PagePtr=gsCacheInfo.u16CacheInfoFreePagePtr-gTotalPlaneOfCacheInfoTab;
   *          uTotalPlaneOfTab=gTotalPlaneOfCacheInfoTab;
   *          break;
   */
        case cWriteH2fTab:
            u16FBlock=g16arH2fTabBlk[gsCacheInfo.uActH2fTabBlkIdx];
            // u16PagePtr=(gsCacheInfo.u16H2fTabFreePagePtr-1)<<gsCacheInfo.uH2fTabProgSlotShift;    // -gTotalPlaneOfH2fTab;
            u16PagePtr=(gsCacheInfo.u16H2fTabFreePagePtr-1)<<2;    // temp use 2
            uTotalPlaneOfTab=gTotalPlaneOfH2fTab;
            break;

        default:
            break;
    }

    for(uPageOfst=0; uPageOfst<uTotalPlaneOfTab; uPageOfst++)
    {
        usTmpAddrInfo.u16FBlock=u16FBlock;
        usTmpAddrInfo.u16FPage=u16PagePtr+uPageOfst;
        // usTmpAddrInfo.ubLsbOnly=1;
        tranAddrInfo(&usTmpAddrInfo);
        // tranCeNum(&usTmpAddrInfo);
        setFLAddrActCh(usTmpAddrInfo.uCh, &usTmpAddrInfo);
        gSectorH=0;
        mSetFRwParam(c16Tsb0SIdx+(uPageOfst*gSectorPerPlaneH), gSectorPerPlaneH, c16Bit4|c16Bit5|c16Bit10, cReadData);
        flashReadPage();

        getSprByte(&usBlkSprInfo, usTmpAddrInfo.uPlaneAddr);

        if(gbEccFail||gbSprEccFail||gbDataEccFail)    // gbOnesCntFail /*|| rFLCtrl[rcLdpcEccErrCnt_L]>10*/)
        {
            return cFalse;
        }
    }

    return cTrue;
}    /* chkReadTabEcc */

#endif/* if 0 */

void rebuSpareFblock()
{
    BYTE uBlkID, uGood;
    WORD u16FBlock=g16FirstFBlock;
    // LWORD u32TempSerial;
    BLKSPRINFO usBlkSprInfo;

    /*
       *  A. scan non pop bit block to build H2f table block & Data block re build Q
       *  B. calcuate spare block count
       *  C. copy cache info table to new flash address
       */

    saveRdTimeStamp(2);

    // disable UNC stop
    setSelMulFL(1);
    rmDisUnCorrErrStop;
    setSelMulFL(0);
    ctrlOnesCntStop(0);

#if !_EN_Always_DynamicMode
    gsCacheInfo.u16SpareBlockCnt=0;
    gsCacheInfo.u16TLCSprBlockCnt=0;
#endif
#if _EN_Dynamic_Fix_Boundary
    gsCacheInfo.u16SLCSpareCnt=0;
    gsCacheInfo.u16DynamicSpareCnt=0;
#if _EN_Always_DynamicMode
    gsCacheInfo.u16SpareBlockCnt=0;
#endif
#endif

    g16FoundCachebCnt=0;

    for(; u16FBlock<g16TotalFBlock; u16FBlock++)
    {
        if(!mChkPoppedBitRL(u16FBlock))
        {
            if(gsRdlinkInfo.ubDoNotScanAllBlk)
            {
                addSpareBlockCnt(u16FBlock);
            }
            else
            {
                if(!mChkMlcMoBit(u16FBlock))    // SLC
                {
                    uGood=get1stPageInfo(u16FBlock, cReadOnePage|cReadWithoutRetry, &usBlkSprInfo);
                }
                else if(gsRdlinkInfo.ubCacheInfoValid)    // TLC
                {
                    mClrMlcMoBit(u16FBlock);
                    uGood=get1stPageInfo(u16FBlock, cReadOnePage|cReadWithoutRetry, &usBlkSprInfo);

                    if(uGood&&(mGetMetaBlockId(usBlkSprInfo)==cH2fTableID))
                    {}
                    else
                    {
                        mSetMlcMoBit(u16FBlock);
                        addSpareBlockCnt(u16FBlock);
                        continue;
                    }
                }
                else
                {
                    // try both slc/mlc mode
                    // get1stPageInfo(u16Fblock, , &usBlkSprInfo);
#if _EN_KEEP_RW_ON_ERROR    // Chief_20190305
                    mSetCacheInfoSpf(crelinkWhileFormat);
                    relinkKeepRwonError(cRebuSpareFblock, u16FBlock, 0x00, 0x00);
#else
                    relinkSaveQBDummy(cRebuSpareFblock);    // debug??????????????????????????
#endif
                }

                if(!uGood)
                {
                    addSpareBlockCnt(u16FBlock);
                }
                else
                {
                    uBlkID=mGetMetaBlockId(usBlkSprInfo);

                    switch(uBlkID)
                    {
                        case cCacheBlockID:
                        case cGcDesBlockID:
/*
   *                          if(uBlkID==cGcDesBlockID)
   *                          {
   *                              u32TempSerial=g32BkGcDesSerial;
   *                          }
   *                          else if(uBlkID==cCacheBlockID)
   *                          {
   *                              u32TempSerial=g32BkCacheBlkSerial;
   *                          }
   *
   *                          if(!gsRdlinkInfo.ubCacheInfoValid||(u32TempSerial==c32InitSerialVal)||
   *                             (judgeSerial(mGetMetaBlkSn(usBlkSprInfo), u32TempSerial)==cSerialLarger))
   *                          {
   *                              if(uBlkID==cGcDesBlockID)
   *                              {
   *                                  sortFoundCacheQ(mGetMetaBlkSn(usBlkSprInfo), u16FBlock, mGetMetaOpTyp(usBlkSprInfo), cFoundGcDes);
   *                              }
   *                              else if(uBlkID==cCacheBlockID)
   *                              {
   *                                  sortFoundCacheQ(mGetMetaBlkSn(usBlkSprInfo), u16FBlock, 0, cFoundCache);
   *                              }
   *
   *                              mSetPopDeniedF(u16FBlock);
   *                          }
   *                          else    // unfull Gc SLC block, push to spare temporarily
   */
                        {
                            addSpareBlockCnt(u16FBlock);
                        }

                            mSetGlobEraseCntRL(u16FBlock, mGetMetaEraseCnt(usBlkSprInfo));
                            setGlobEraseCnt1Blk(u16FBlock, g16arTempGlobEraseCnt[u16FBlock], (mChkPoppedBitRL(u16FBlock))?1:0);
                            setBlkSerial(cCacheBlockID, mGetMetaBlkSn(usBlkSprInfo));

                            break;

                        case cH2fTableID:

                            if(gsRdlinkInfo.ubCacheInfoValid)
                            {
                                sortFoundH2fTabQ(mGetMetaH2fIdx(usBlkSprInfo), mGetMetaEraseCnt(usBlkSprInfo), u16FBlock,
                                                 mGetMetaBlkSn(usBlkSprInfo));
                            }
                            else
                            {
                                addSpareBlockCnt(u16FBlock);
                            }

                            break;

                        case cRDT_BlockID:
                        case cWPROBlockID:
                        case cF2hTableID:    // read last page may get F2H table
                            addSpareBlockCnt(u16FBlock);
                            break;

                        default:
                            /* temp remove
                               *                      if(mGetMetaBlockId(usBlkSprInfo)!=0xFF)
                               *                      {
                               *                          debugLoop();
                               *                          // garAbnormalBlk[gAbnormalCnt]=u16Fblock;
                               *                          // gAbnormalCnt++;
                               *                          setErrorBlock(u16FBlock, mGetMetaEraseCnt(usBlkSprInfo),
                               * mGetMetaBlockId(usBlkSprInfo));    // |c16Bit15);//mark
                               *
                               *
                               *
                               *                                                                                                              //
                               * later
                               *                      }
                               *                      else
                               */
                            addSpareBlockCnt(u16FBlock);

                            break;
                    }    /* switch */
                }    /* switch */
            }
        }
    }

    setSelMulFL(1);
    rmEnUnCorrErrStop;
    resetEcc();
    setSelMulFL(0);
    ctrlOnesCntStop(3);
    // gbDontRetry=0;

    if(gsRdlinkInfo.ubCacheInfoValid)
    {
        addBlock2CacheQ(gsRdlinkInfo.u16BkActiveCacheBlock, cCacheBlockID, cFoundCache);

        if(gsRdlinkInfo.u16BkFluCacheBlock!=gsRdlinkInfo.u16BkActiveCacheBlock)
        {
            addBlock2CacheQ(gsRdlinkInfo.u16BkFluCacheBlock, cCacheBlockID, cFoundCache);
        }

        // addBlock2CacheQ(gsRdlinkInfo.u16BkActiveGcDesBlock, cGcDesBlockID, cFoundGcDes);
    }

    saveRdTimeStamp(3);

    // 3. if last found block is gc slc, insert it to front of last cache
    if(g16FoundCachebCnt>1)
    {
        reSortGcBlk();
    }

#if _EN_CHRONUS_UART_DEBUG
    gsFtlDbg.uUgsdCacheBlock=garFoundCacheQ[g16FoundCachebCnt-1].u16FBlock;
    NLOG(cLogBuild, REBUSPRBLK_C, 1, "Cache Block: 0x%04X ", gsFtlDbg.uUgsdCacheBlock);
#endif

    saveRdTimeStamp(4);
}    /* rebuSpareFblock */

#if (!_HwPlane2SprIssue)
BYTE get1stPageInfo(WORD u16FBlock, BYTE uMode, BLKSPRINFO *upBlkSprInfo)
{
    ADDRINFO usTmpAddrInfo[cMaxChNum];
    WORD u16Fpage;
    BYTE uIntlvAddr, uDieAddr, uPlaneAddr, uCh, uGood=0;
    WORD u16PagePerBlock1;

    fillCcmVal((BYTE *)&usTmpAddrInfo, sizeof(usTmpAddrInfo), 0x0);

    setSelMulFL(1);
    resetEcc();
    setSelMulFL(0);
    upBlkSprInfo->u16Spr8.us2BYTE.LowByte=0xFF;

    if(!mChkMlcMoBit(u16FBlock))
    {
        u16PagePerBlock1=g16PagePerBlock1_SLC;
    }
    else
    {
        u16PagePerBlock1=g16PagePerBlock1;
    }

    if(uMode&cReadLastPage)
    {
        u16Fpage=u16PagePerBlock1-1;
    }
    else
    {
        u16Fpage=0;
    }

    if(uMode&cReadOnePage)
    {
        u16PagePerBlock1=u16Fpage+2;
    }

    while(u16Fpage<u16PagePerBlock1)
    {
        for(uIntlvAddr=0; uIntlvAddr<gIntlvWay; uIntlvAddr++)
        {
            uDieAddr=mGetDieAddr(uIntlvAddr);

            for(uCh=0; uCh<gTotalChNum; uCh++)
            {
                usTmpAddrInfo[uCh].u16FBlock=u16FBlock;
                usTmpAddrInfo[uCh].u16FPage=u16Fpage;
                usTmpAddrInfo[uCh].uIntlvAddr=uIntlvAddr;
                usTmpAddrInfo[uCh].uCe=(BYTE)mGetCEAddr(usTmpAddrInfo[uCh].uIntlvAddr);
                usTmpAddrInfo[uCh].uDieAddr=uDieAddr;
                usTmpAddrInfo[uCh].u16RwOpt=c16Bit0|c16Bit15;
                usTmpAddrInfo[uCh].uPlaneAddr=0;
                usTmpAddrInfo[uCh].uCh=uCh;
                usTmpAddrInfo[uCh].uOpTyp=cReadCmdAle;
                setFLAddrActCh(uCh, &usTmpAddrInfo[uCh]);
                assignFreeBtSrcAddrInfo();
            }
        }

        waitCmdAllDone(cWaitTrigRCnt);

        for(uIntlvAddr=0; uIntlvAddr<gIntlvWay; uIntlvAddr++)
        {
            uDieAddr=mGetDieAddr(uIntlvAddr);

            rstUNCStsCore0();

            for(uCh=0; uCh<gTotalChNum; uCh++)
            {
                usTmpAddrInfo[uCh].uCh=uCh;
                usTmpAddrInfo[uCh].uIntlvAddr=uIntlvAddr;
                usTmpAddrInfo[uCh].uDieAddr=uDieAddr;
                usTmpAddrInfo[uCh].uCe=(BYTE)mGetCEAddr(usTmpAddrInfo[uCh].uIntlvAddr);

                setFLAddrActCh(uCh, &usTmpAddrInfo[uCh]);

                if(uMode&cReadRtyResetVth)
                {
                    mSetFRwParam(c16Tsb0SIdx, 0, c16Bit0|c16Bit2|c16Bit5|c16Bit10|c16Bit14|c16Bit15, cReadData);
                }
                else
                {
                    if(uMode&cReadSprData)
                    {
                        mSetFRwParam(c16Tsb0SIdx, gSectorPerPageH, c16Bit0|c16Bit2|c16Bit4|c16Bit5|c16Bit10|c16Bit15, cReadData);
                    }
                    else
                    {
                        mSetFRwParam(c16Tsb0SIdx, 0, c16Bit0|c16Bit2|c16Bit5|c16Bit10|c16Bit15, cReadData);
                    }
                }

                if(uMode&cReadSprData)
                {
                    gPlaneAddr=uPlaneAddr;
                    assignFreeBtSrcAddrInfo();
                }
                else
                {
                    for(uPlaneAddr=0; uPlaneAddr<gPlaneNum; uPlaneAddr++)
                    {
                        gPlaneAddr=uPlaneAddr;
                        assignFreeBtSrcAddrInfo();
                    }
                }
            }

            waitCmdAllDone(cWaitTrigRCnt|cWaitCmdBz);
#if 0
            // (F) here need modify other way to discover Ecc fail
            for(uCh=0; uCh<gTotalChNum; uCh++)
            {
                setFLActCh(uCh);

                if(uMode&cReadWithoutRetry)
                {
                    gPlaneUNCSts[uCh]=0;
                    mWaitCmdFifoBz;

                    if(rmChkUNC)
                    {
                        if(rmChkEccFail)
                        {
                            gPlaneUNCSts[uCh]|=rmGetPlaneUNCBit;
                            gbEccFail=1;
                        }

                        if(rmChkOnesCntFail)
                        {
                            gPlaneUNCSts[uCh]|=rmGetPlnDataOverOnesCnt;
                            gbOnesCntFail=1;
                            rmResetOnesCnt;
                        }

                        rmResetEccSts;
                    }
                }
                else
                {
                    jdgReadRetry(&usTmpAddrInfo[uCh], 0);
                }
            }
#endif/* if 0 */

            for(uCh=0; uCh<gTotalChNum; uCh++)
            {
                setFLActCh(uCh);

                for(uPlaneAddr=0; uPlaneAddr<gPlaneNum; uPlaneAddr++)
                {
                    if(!mChkBitMask(gPlaneUNCSts[uCh], uPlaneAddr))
                    {
                        getSprByte(upBlkSprInfo, uPlaneAddr);
                        uGood=1;
                        return uGood;
                    }
                    else
                    {
                        uGood=0;
                    }
                }
            }
        }

        // if(uMode&cReadOnePage)
        // {
        // break;
        // }

        u16Fpage++;
    }

    waitAllChCeBzBtCore0();
    return uGood;
}    /* get1stPageInfo */

#else/* if (!_HwPlane2SprIssue) */
BYTE get1stPageInfo(WORD u16FBlock, BYTE uMode, BLKSPRINFO *upBlkSprInfo)
{
    ADDRINFO usTmpAddrInfo[cMaxChNum];
    WORD u16Fpage;
    BYTE uIntlvAddr, uDieAddr, uPlaneAddr, uCh, uGood=cTrue;
    WORD u16PagePerBlock1;
    BYTE uPlaneAddr1;
    LWORD u32FirstFullH2fTabBmp=(0x1UL<<(gPage4kPerH2fTab/g4kNumPerPlane))-1;
    BYTE u32CurH2fTabBmp=0;
    BYTE uBlkID=0xFF;    // =mGetMetaBlockId(usBlkSprInfo);

    fillCcmVal((BYTE *)&usTmpAddrInfo, sizeof(usTmpAddrInfo), 0x0);

    setSelMulFL(1);
    resetEcc();
    setSelMulFL(0);
    upBlkSprInfo->u16Spr8.us2BYTE.LowByte=0xFF;

    if(!mChkMlcMoBit(u16FBlock))
    {
        u16PagePerBlock1=g16PagePerBlock1_SLC;
    }
    else
    {
        u16PagePerBlock1=g16PagePerBlock1;
    }

    if(uMode&cReadLastPage)
    {
        u16Fpage=u16PagePerBlock1-1;
    }
    else
    {
        u16Fpage=0;
    }

    if(uMode&cReadOnePage)
    {
        u16PagePerBlock1=u16Fpage+2;
    }

    while(u16Fpage<u16PagePerBlock1)
    {
        for(uIntlvAddr=0; uIntlvAddr<gIntlvWay; uIntlvAddr++)
        {
            uDieAddr=mGetDieAddr(uIntlvAddr);

            for(uCh=0; uCh<gTotalChNum; uCh++)
            {
                usTmpAddrInfo[uCh].u16FBlock=u16FBlock;
                usTmpAddrInfo[uCh].u16FPage=u16Fpage;
                usTmpAddrInfo[uCh].uIntlvAddr=uIntlvAddr;
                usTmpAddrInfo[uCh].uCe=(BYTE)mGetCEAddr(usTmpAddrInfo[uCh].uIntlvAddr);
                usTmpAddrInfo[uCh].uDieAddr=uDieAddr;
                usTmpAddrInfo[uCh].u16RwOpt=c16Bit0|c16Bit15;
                usTmpAddrInfo[uCh].uPlaneAddr=0;
                usTmpAddrInfo[uCh].uCh=uCh;
                usTmpAddrInfo[uCh].uOpTyp=cReadCmdAle;

                gpFlashAddrInfo=&usTmpAddrInfo[uCh];
                assignFreeBtSrcAddrInfo();
            }
        }

        waitCmdAllDone(cWaitTrigRCnt);

        for(uIntlvAddr=0; uIntlvAddr<gIntlvWay; uIntlvAddr++)
        {
            uDieAddr=mGetDieAddr(uIntlvAddr);
            rstUNCStsCore0();

            for(uPlaneAddr=0; uPlaneAddr<gPlaneNum; uPlaneAddr+=2)
            {
                for(uCh=0; uCh<gTotalChNum; uCh++)
                {
                    usTmpAddrInfo[uCh].uCh=uCh;
                    usTmpAddrInfo[uCh].uIntlvAddr=uIntlvAddr;
                    usTmpAddrInfo[uCh].uDieAddr=uDieAddr;
                    usTmpAddrInfo[uCh].uCe=(BYTE)mGetCEAddr(usTmpAddrInfo[uCh].uIntlvAddr);
                    gpFlashAddrInfo=&usTmpAddrInfo[uCh];

                    if(uMode&cReadRtyResetVth)
                    {
                        mSetFRwParam(c16Tsb0SIdx, 0, c16Bit0|c16Bit2|c16Bit5|c16Bit10|c16Bit14|c16Bit15, cReadData);
                    }
                    else
                    {
                        if(uMode&cReadSprData)
                        {
                            mSetFRwParam(c16Tsb0SIdx, gSectorPerPlaneH<<1, c16Bit0|c16Bit2|c16Bit4|c16Bit5|c16Bit10|c16Bit15, cReadData);
                        }
                        else
                        {
                            mSetFRwParam(c16Tsb0SIdx, 0, c16Bit0|c16Bit2|c16Bit5|c16Bit10|c16Bit15, cReadData);
                        }
                    }

                    gPlaneUNCSts[uCh]=0;

                    if(uMode&cReadSprData)
                    {
                        gPlaneAddr=uPlaneAddr;
                        assignFreeBtSrcAddrInfo();
                    }
                    else
                    {
                        for(uPlaneAddr1=uPlaneAddr; uPlaneAddr1<uPlaneAddr+2; uPlaneAddr1++)
                        {
                            gPlaneAddr=uPlaneAddr1;
                            assignFreeBtSrcAddrInfo();
                        }
                    }
                }

                waitCmdAllDone(cWaitTrigRCnt|cWaitCmdBz);
#if 1
                // (F) here need modify other way to discover Ecc fail
                for(uCh=0; uCh<gTotalChNum; uCh++)
                {
                    setFLActCh(uCh);

                    mWaitCmdFifoBz;

                    if(!rmChkUNC)
                    {
                        getSprByte(upBlkSprInfo, 0);

                        if(uBlkID==0xFF)
                        {
                            uBlkID=mGetMetaBlockId((*upBlkSprInfo));
                        }

                        if(uBlkID!=cH2fTableID)
                        {
                            // if cache/GcDes block, found any plane is good then return good.
                            return cTrue;
                        }
                        else
                        {
                            if(u16Fpage==0)
                            {
                                BYTE uPlaneOfs=uPlaneAddr+uCh*gPlaneNum+uIntlvAddr*gPlaneNum*gTotalChNum;
                                u32CurH2fTabBmp|=(0x3UL<<uPlaneOfs);    // 2 planes read

                                if((u32CurH2fTabBmp&u32FirstFullH2fTabBmp)==u32FirstFullH2fTabBmp)
                                {
                                    // if fit the size of H2f tab, this H2f block is valid.
                                    return cTrue;
                                }
                            }
                        }

                        /*
                           *  If full page of  h2f table are good then return true, else there are any UNC fail return false.
                           */
                    }
                    else
                    {
                        if(uMode&cReadWithoutRetry)
                        {
                            if(rmChkEccFail)
                            {
                                gPlaneUNCSts[uCh]|=rmGetPlaneUNCBit;
                                gbEccFail=1;
                            }

                            if(rmChkOnesCntFail)
                            {
                                gPlaneUNCSts[uCh]|=rmGetPlnDataOverOnesCnt;
                                gbOnesCntFail=1;
                                rmResetOnesCnt;
                            }
                        }
                        else if(!rmChkUnCorrErrStop)
                        {
                            debugDeadLock(0x00E8);    // ensure core1 will do read retry.
                        }

                        rmResetEccSts;
                        uGood=cFalse;
                    }
                }
#else/* if 1 */
                for(uCh=0; uCh<gTotalChNum; uCh++)
                {
                    for(uPlaneAddr1=uPlaneAddr; uPlaneAddr1<uPlaneAddr+2; uPlaneAddr1++)
                    {
                        if(!mChkBitMask(gPlaneUNCSts[uCh], uPlaneAddr1))
                        {
                            getSprByte(upBlkSprInfo, uPlaneAddr1);
                            waitAllChCeBzBtCore0();
                            uGood=1;
                            return uGood;
                        }
                        else
                        {
                            uGood=0;
                        }
                    }
                }
#endif/* if 1 */
            }
        }

        // if(uMode&cReadOnePage)
        // {
        // break;
        // }

        u16Fpage++;
    }

    waitAllChCeBzBtCore0();

    return uGood;
}    /* get1stPageInfo */

BYTE getPageInfo(WORD u16FBlock, WORD u16Fpage, BYTE uMode, BLKSPRINFO *upBlkSprInfo)
{
    ADDRINFO usTmpAddrInfo[cMaxChNum];
    BYTE uIntlvAddr, uDieAddr, uPlaneAddr, uCh, uGood=cTrue;
    BYTE uPlaneAddr1;

    fillCcmVal((BYTE *)&usTmpAddrInfo, sizeof(usTmpAddrInfo), 0x0);

    setSelMulFL(1);
    resetEcc();
    setSelMulFL(0);
    upBlkSprInfo->u16Spr8.us2BYTE.LowByte=0xFF;

    for(uIntlvAddr=0; uIntlvAddr<gIntlvWay; uIntlvAddr++)
    {
        uDieAddr=mGetDieAddr(uIntlvAddr);

        for(uCh=0; uCh<gTotalChNum; uCh++)
        {
            usTmpAddrInfo[uCh].u16FBlock=u16FBlock;
            usTmpAddrInfo[uCh].u16FPage=u16Fpage;
            usTmpAddrInfo[uCh].uIntlvAddr=uIntlvAddr;
            usTmpAddrInfo[uCh].uCe=(BYTE)mGetCEAddr(usTmpAddrInfo[uCh].uIntlvAddr);
            usTmpAddrInfo[uCh].uDieAddr=uDieAddr;
            usTmpAddrInfo[uCh].u16RwOpt=c16Bit0|c16Bit15;
            usTmpAddrInfo[uCh].uPlaneAddr=0;
            usTmpAddrInfo[uCh].uCh=uCh;
            usTmpAddrInfo[uCh].uOpTyp=cReadCmdAle;

            gpFlashAddrInfo=&usTmpAddrInfo[uCh];
            assignFreeBtSrcAddrInfo();
        }
    }

    waitCmdAllDone(cWaitTrigRCnt);

    for(uIntlvAddr=0; uIntlvAddr<gIntlvWay; uIntlvAddr++)
    {
        uDieAddr=mGetDieAddr(uIntlvAddr);
        rstUNCStsCore0();

        for(uPlaneAddr=0; uPlaneAddr<gPlaneNum; uPlaneAddr+=2)
        {
            for(uCh=0; uCh<gTotalChNum; uCh++)
            {
                usTmpAddrInfo[uCh].uCh=uCh;
                usTmpAddrInfo[uCh].uIntlvAddr=uIntlvAddr;
                usTmpAddrInfo[uCh].uDieAddr=uDieAddr;
                usTmpAddrInfo[uCh].uCe=(BYTE)mGetCEAddr(usTmpAddrInfo[uCh].uIntlvAddr);
                gpFlashAddrInfo=&usTmpAddrInfo[uCh];

                if(uMode&cReadRtyResetVth)
                {
                    mSetFRwParam(c16Tsb0SIdx, 0, c16Bit0|c16Bit2|c16Bit5|c16Bit10|c16Bit14|c16Bit15, cReadData);
                }
                else
                {
                    if(uMode&cReadSprData)
                    {
                        mSetFRwParam(c16Tsb0SIdx, gSectorPerPlaneH<<1, c16Bit0|c16Bit2|c16Bit4|c16Bit5|c16Bit10|c16Bit15, cReadData);
                    }
                    else
                    {
                        mSetFRwParam(c16Tsb0SIdx, 0, c16Bit0|c16Bit2|c16Bit5|c16Bit10|c16Bit15, cReadData);
                    }
                }

                gPlaneUNCSts[uCh]=0;

                if(uMode&cReadSprData)
                {
                    gPlaneAddr=uPlaneAddr;
                    assignFreeBtSrcAddrInfo();
                }
                else
                {
                    for(uPlaneAddr1=uPlaneAddr; uPlaneAddr1<uPlaneAddr+2; uPlaneAddr1++)
                    {
                        gPlaneAddr=uPlaneAddr1;
                        assignFreeBtSrcAddrInfo();
                    }
                }
            }

            waitCmdAllDone(cWaitTrigRCnt|cWaitCmdBz);
#if 1
            // (F) here need modify other way to discover Ecc fail
            for(uCh=0; uCh<gTotalChNum; uCh++)
            {
                setFLActCh(uCh);

                mWaitCmdFifoBz;

                if(rmChkUNC)
                {
                    if(uMode&cReadWithoutRetry)
                    {
                        if(rmChkEccFail)
                        {
                            gPlaneUNCSts[uCh]|=rmGetPlaneUNCBit;
                            gbEccFail=1;
                        }

                        if(rmChkOnesCntFail)
                        {
                            gPlaneUNCSts[uCh]|=rmGetPlnDataOverOnesCnt;
                            gbOnesCntFail=1;
                            rmResetOnesCnt;
                        }
                    }
                    else if(!rmChkUnCorrErrStop)
                    {
                        debugDeadLock(0x00E8);    // ensure core1 will do read retry.
                    }

                    rmResetEccSts;
                    waitAllChCeBzBtCore0();
                    return cFalse;
                }
            }
#else/* if 1 */
            for(uCh=0; uCh<gTotalChNum; uCh++)
            {
                for(uPlaneAddr1=uPlaneAddr; uPlaneAddr1<uPlaneAddr+2; uPlaneAddr1++)
                {
                    if(!mChkBitMask(gPlaneUNCSts[uCh], uPlaneAddr1))
                    {
                        getSprByte(upBlkSprInfo, uPlaneAddr1);
                        waitAllChCeBzBtCore0();
                        uGood=1;
                        return uGood;
                    }
                    else
                    {
                        uGood=0;
                    }
                }
            }
#endif/* if 1 */
        }
    }

    waitAllChCeBzBtCore0();

    return uGood;
}    /* get1stPageInfo */

#endif/* if (!_HwPlane2SprIssue) */

void setErrorBlock(WORD u16FBlock, WORD u16EraseCnt, WORD u16Id)
{
    if(gsRdlinkInfo.u16ErrBlkCnt<c16MaxErrBlkNum)
    {
        garErrBlock[gsRdlinkInfo.u16ErrBlkCnt].u16Id=u16Id;
        garErrBlock[gsRdlinkInfo.u16ErrBlkCnt].u16FBlock=u16FBlock;
        garErrBlock[gsRdlinkInfo.u16ErrBlkCnt].u16EraseCnt=u16EraseCnt;
        gsRdlinkInfo.u16ErrBlkCnt++;
    }
    else
    {
#if _EN_KEEP_RW_ON_ERROR
        relinkKeepRwonError(cSetErrorBlock, u16FBlock, u16EraseCnt, u16Id);
#else
        relinkSaveDummyQBAnalysis((WORD)u16FBlock, (WORD)u16EraseCnt, (WORD)u16Id, 0);
        relinkSaveQBDummy(cSetErrorBlock);
#endif
    }
}    /* setErrorBlock */

/*
   * void sortFoundTLCQ(BLKSPRINFO *upBlkSprInfo, WORD u16Fblock, BYTE uBlkType)
   * {
   *  // L06B need modify or remove this function.
   *  LWORD u32MinSn=c32InitSerialVal;
   *  WORD u16Idx=0;
   *  WORD u16Idx2=0;
   *
   *  // BYTE uarQ[cSeedGrpNum]      =
   *  // {
   *  //    0
   *  // };
   *  BLKSPRINFO *upBlkSprInfo1;
   *  BLKSPRINFO *upBkBlkSprInfo=upBlkSprInfo;
   *
   *
   *  while(g16FoundCachebCnt>=cMaxFoundCacheFBlockNum)
   *      ;
   *
   *
   *  if(upBlkSprInfo->u32Serial<u32MinSn)
   *  {
   *      u32MinSn=upBlkSprInfo->u32Serial;
   *  }
   *
   *  // sort serial for 3 group
   *  upBlkSprInfo1=upBkBlkSprInfo;
   *  u16Idx2=0;
   *
   *  if(judgeSerial(upBlkSprInfo->u32Serial, upBlkSprInfo1->u32Serial)==cSerialLarger)
   *  {
   *      u16Idx2++;
   *  }
   *
   *  // upBlkSprInfo1++;
   *  upBlkSprInfo1+=gTotalBankOfF2hTab;
   *
   *  garFoundCacheQ[g16FoundCachebCnt+u16Idx2].u16Fblock=u16Fblock;
   *  garFoundCacheQ[g16FoundCachebCnt+u16Idx2].u32Serial=upBlkSprInfo->u32Serial;
   *  garFoundCacheQ[g16FoundCachebCnt+u16Idx2].uSeedGrp=0;
   *
   *  garFoundCacheQ[g16FoundCachebCnt+u16Idx2].uBlkType=uBlkType;        // 1: GcDes
   *
   *  // upBlkSprInfo++;
   *  upBlkSprInfo+=gTotalBankOfF2hTab;
   *
   *  if(g16FoundCachebCnt!=0)
   *  {
   *      for(u16Idx=0; u16Idx<g16FoundCachebCnt; u16Idx++)
   *      {
   *          if(judgeSerial(u32MinSn, garFoundCacheQ[g16arFoundCacheIdx[u16Idx]].u32Serial)!=cSerialLarger)
   *          {
   *              for(u16Idx2=g16FoundCachebCnt; u16Idx2>u16Idx; u16Idx2--)
   *              {
   *                  g16arFoundCacheIdx[u16Idx2-1]=g16arFoundCacheIdx[u16Idx2-1];
   *              }
   *
   *              break;
   *          }
   *      }
   *  }
   *
   *  g16arFoundCacheIdx[u16Idx]=g16FoundCachebCnt;
   *  g16FoundCachebCnt++;
   * }
   */

void sortFoundCacheQ(LWORD u32Serial, WORD u16FBlock, BYTE uFluBlkSn, BYTE uBlkType)
{
    WORD u16Idx=0;
    WORD u16Idx2;

    while(g16FoundCachebCnt>=cMaxFoundCacheFBlockNum)
        ;

    garFoundCacheQ[g16FoundCachebCnt].u16FBlock=u16FBlock;
    garFoundCacheQ[g16FoundCachebCnt].u32Serial=u32Serial;
    // garFoundCacheQ[g16FoundCachebCnt].uSeedGrp=uSeedGrp;
    garFoundCacheQ[g16FoundCachebCnt].uBlkType=uBlkType;    // 1: GcDes
    garFoundCacheQ[g16FoundCachebCnt].uGcFluBlkSn_B0=uFluBlkSn;

    if(g16FoundCachebCnt!=0)
    {
        for(u16Idx=0; u16Idx<g16FoundCachebCnt; u16Idx++)
        {
            if(judgeSerial(u32Serial, garFoundCacheQ[g16arFoundCacheIdx[u16Idx]].u32Serial)==cSerialSmaller)
            {
                for(u16Idx2=g16FoundCachebCnt; u16Idx2>u16Idx; u16Idx2--)
                {
                    g16arFoundCacheIdx[u16Idx2]=g16arFoundCacheIdx[u16Idx2-1];
                }

                break;
            }
        }
    }

    g16arFoundCacheIdx[u16Idx]=g16FoundCachebCnt;
    g16FoundCachebCnt++;
}    /* sortFoundCacheQ */

void sortFoundH2fTabQ(WORD u16Index,    /*WORD u16Grp,*/ WORD u16EraseCnt, WORD u16FBlock, LWORD u32BlkSerial)
{
    WORD u16Loop0, u16Loop1;
    WORD u16FoundH2fTabWin;

    u16FoundH2fTabWin=getFoundH2fTabWin(u16Index, u32BlkSerial);

    if(u16FoundH2fTabWin==0xFFFF)
    {
        addSpareBlockCnt(u16FBlock);
    }
    else
    {
        garH2fTabQ[u16FoundH2fTabWin].u16FBlock=u16FBlock;
        garH2fTabQ[u16FoundH2fTabWin].u16Index=u16Index;
        garH2fTabQ[u16FoundH2fTabWin].u32H2fTabBlkSerial=u32BlkSerial;
        garH2fTabQ[u16FoundH2fTabWin].u16EraseCnt=u16EraseCnt;

        if(gsRdlinkInfo.u16FoundH2fTabBlkCnt==0)
        {
            garH2fTabQIndex[0]=0;
        }
        else
        {
            for(u16Loop0=0; u16Loop0<gsRdlinkInfo.u16FoundH2fTabBlkCnt; u16Loop0++)
            {
                if(judgeSerial(u32BlkSerial, garH2fTabQ[garH2fTabQIndex[u16Loop0]].u32H2fTabBlkSerial)==cSerialSmaller)
                {
                    // move back
                    for(u16Loop1=gsRdlinkInfo.u16FoundH2fTabBlkCnt; u16Loop1>u16Loop0; u16Loop1--)
                    {
                        garH2fTabQIndex[u16Loop1]=garH2fTabQIndex[u16Loop1-1];
                    }

                    break;    // already got the correct position, insert it later
                }
            }

            garH2fTabQIndex[u16Loop0]=u16FoundH2fTabWin;    // insert to the correct position
        }

        gsRdlinkInfo.u16FoundH2fTabBlkCnt++;
    }
}    /* sortFoundH2fTabQ */

WORD getFoundH2fTabWin(WORD u16Index, LWORD u32Serial)
{
    WORD u16Idx, u16Loop;
    WORD u16H2fTabQWin;

    if(judgeSerial(u32Serial, g32BkH2fTabBlkSerial)==cSerialSmaller)
    {
        return 0xFFFF;
    }

    if(judgeSerial(u32Serial, g32arH2fTabBlkSn[u16Index])==cSerialSmaller)
    {
        return 0xFFFF;
    }

    for(u16Idx=0; u16Idx<gsRdlinkInfo.u16FoundH2fTabBlkCnt; u16Idx++)
    {
        if(garH2fTabQ[garH2fTabQIndex[u16Idx]].u16Index==u16Index)
        {
            if(judgeSerial(u32Serial, garH2fTabQ[garH2fTabQIndex[u16Idx]].u32H2fTabBlkSerial)==cSerialSmaller)
            {
                return 0xFFFF;
            }
            else
            {
                addSpareBlockCnt(garH2fTabQ[garH2fTabQIndex[u16Idx]].u16FBlock);
                u16H2fTabQWin=garH2fTabQIndex[u16Idx];

                for(u16Loop=u16Idx; u16Loop<(gsRdlinkInfo.u16FoundH2fTabBlkCnt-1); u16Loop++)
                {
                    garH2fTabQIndex[u16Loop]=garH2fTabQIndex[u16Loop+1];
                }

                gsRdlinkInfo.u16FoundH2fTabBlkCnt--;

                return u16H2fTabQWin;
            }
        }
    }

    return gsRdlinkInfo.u16FoundH2fTabBlkCnt;
}    /* getFoundH2fTabWin */

void addSpareBlockCnt(WORD u16FBlock)
{
/*
   *  caculate slc/tlc spare block count
   */
#if !_EN_Always_DynamicMode
    if(!mChkMlcMoBit(u16FBlock))
    {
        gsCacheInfo.u16SpareBlockCnt++;
    }
    else
    {
        gsCacheInfo.u16TLCSprBlockCnt++;
    }
#endif
#if _EN_Dynamic_Fix_Boundary
    if(u16FBlock<g16StaticBound)
    {
        gsCacheInfo.u16SLCSpareCnt++;
    }
    else
    {
        gsCacheInfo.u16DynamicSpareCnt++;
    }

#if _EN_Always_DynamicMode
    gsCacheInfo.u16SpareBlockCnt++;
#endif
#endif
}    /* addSpareBlockCnt */







