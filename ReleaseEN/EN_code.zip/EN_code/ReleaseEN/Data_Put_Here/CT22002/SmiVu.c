







#include "inc/DebugLog.h"
#include "inc/EventLogIDX.h"
#include "inc/EventLogFunctionIDX.h"
#include "inc/TypeDef.h"
#include "inc/Option.h"
#include "inc/ProType.h"
#include "inc/Reg.h"
#include "inc/NvmeCtrl.h"
#include "inc/table.h"
#include "inc/GlobVar0.h"
#include "inc/GlobVarS.h"
#include "inc/GlobVarT.h"
#include "inc/Mac.h"
#include "inc/GreyBox.h"
#include "inc/Rdlink.h"
#include "inc/RdlinkFunc.h"
#include "inc/BitDef.h"
#include "inc/Asm.h"

// SMI Vu
#if (!_ICE_LOAD_ALL)
#pragma default_function_attributes = @ ".CORE0_SMIVU"

#include "TaskFuncForPrj.c"
#include "Ftl.c"
#include "F2hTab.c"
#include "H2fTab.c"
#include "Read.c"
#include "NvmeCommonFunc.c"
#endif
#include "NonDataVendorCmd.c"
#include "DataInVendorCmd.c"
#include "DataOutVendorCmd.c"
#include "VendorCmdCommon.c"
#include "SaveIdx.c"
#include "FlashCmdDir.c"

#if _PRJ_SMIVU
// #include "Ftl.c"
// #include "WproBlk.c"
// #include "SprBlk.c"
// #include "SaveIdx.c"
// #include "H2fTab.c"
// #include "Read.c"
// #include "F2hTab.c"
// #include "Core0TempInvFunc.c"
// #include "FlashCtrl.c"
#endif

// #include "Core0TempInvFunc.c"
#if  (!_ICE_LOAD_ALL)
// #include "BootFshCmdHS.c"
#endif

#if _ENABLE_SECAPI
#include "TrimCmd.c"
#include "Write.c"
#endif

#if _GREYBOX
#include "GcH2fTab.c"
#include "GcCacheB.c"
#endif

#if _ENABLE_SECAPI
extern volatile funcptr_st SFP;
#endif

void nvmeVendorNonData()
{
#if 1
    LWORD u32CmdSpecific=0x00;
    WORD u16StatusCode=cStatusSuccess;
    BYTE uCmdType=cNoRwCmd;
    BYTE uSubOpCode;

#if (_EN_CHRONUS_UART_DEBUG)
    if(mChkUartCMDRdy)
    {
        uSubOpCode=gpUartCMD->DW12&0xFF;
        g32CmdPara0=gpUartCMD->DW12;
        g32CmdPara1=gpUartCMD->DW13;
        g32CmdPara2=gpUartCMD->DW14;
        g32CmdPara3=gpUartCMD->DW15;
    }
    else
#endif
    {
        uSubOpCode=rmNvmeSubOpcode;
        g32CmdPara0=r32Nvme1[rcFwRqCmd12/4];
        g32CmdPara1=r32Nvme1[rcFwRqCmd13/4];
        g32CmdPara2=r32Nvme1[rcFwRqCmd14/4];
        g32CmdPara3=r32Nvme1[rcFwRqCmd15/4];
    }

    switch(uSubOpCode)    // (rmNvmeSubOpcode)
    {
        case cNonDataVendorCmdIdResetCpu:
            u16StatusCode=nonDataVendorCmdResetCpu();
            break;

        case cNonDataVendorCmdIdJumpCode:
            // nonDataVendorCmdJumpCode();
            break;

        case cNonDataVendorCmdIdErasePhysicalBlock:
            nonDataVendorCmdErasePhysicalBlock();
            break;

        case cNonDataVendorCmdIdClearSmart:
            nonDataVendorCmdClearSmart();
            break;

        case cNonDataVendorCmdIdVthSet:
            inputVthSet();
            break;

        case cNonDataVendorCmdIdAtaPassthroughErase:
#if _ENABLE_ATA_PASSTHROUGH
            if(gbEnATAPassThrough)
            {
                loadISPCodeCore0(cSecTsbBank, 3);
                SecAPI_NoticeSecCodeSwap(0);
                SFP.gfpSecIntf_VU_EraseUnit();
                SecAPI_NoticeSecCodeSwap(1);
            }
#endif
            break;

        default:
            fillUnknownVendorCmdPattern();
            u16StatusCode=cStatusInvalidOpCode;    // error status
            u32CmdSpecific=0x00;
            uCmdType=cNoRwCmd;
            break;
    }    /* switch */

#if (_EN_CHRONUS_UART_DEBUG)
    if(mChkUartCMDRdy)
    {
        g32arUartCQEntryDW[3]=cStatusSuccess<<17;
        loadISPCodeCore0(cUartTsbBank, 2);
        sendUartCmdRsp(cTsb0StartBufIdx);
    }
    else
#endif
    {
        manualCompletion(u16StatusCode, u32CmdSpecific, uCmdType, 0);
    }

    // Pop Next Cmd, manual won't use SetDesc()fnction need to POP NEX
    rmPopNextCmd;
#endif/* if 1 */
}    /* nvmeVendorNonData */

void nvmeVendorDataOut()
{
#if 1
    WORD u16StatusCode=cStatusSuccess;
    BYTE uStopBK, uSubOpCode;

    disAllChStop((BYTE *)&uStopBK);

#if (_EN_CHRONUS_UART_DEBUG)
    if(mChkUartCMDRdy)
    {
        g32HostXfrCnt=gpUartCMD->DW10;    // DWord unit
    }
    else
#endif
    g32HostXfrCnt=rmNvmeVenderLength;    // DWord unit
    g32HostXfrCnt=(g32HostXfrCnt+127)>>7;    // change to sector base, (g32HostXfrCnt<<2)>>9
    // trigNonRWCmd(cTsb0StartBufIdx, g32HostXfrCnt, cTsb0, cNvmeWrite, cManualCq);

#if (_EN_CHRONUS_UART_DEBUG)
    if(mChkUartCMDRdy)
    {
        uSubOpCode=gpUartCMD->DW12&0xFF;
        g32CmdPara0=gpUartCMD->DW12;
        g32CmdPara1=gpUartCMD->DW13;
        g32CmdPara2=gpUartCMD->DW14;
        g32CmdPara3=gpUartCMD->DW15;
        // bopCopyRam((LWORD)c32Tsb0SAddr, (LWORD)&g32arUartBufTsb0[0][18], (gpUartCMD->DataSecLength*512), cCopyTsb2Tsb|cBopWait);
        bopCopyRam((LWORD)c32Tsb0SAddr, (LWORD)(gp32UartCMDStartAddress+0x12), (gpUartCMD->DataSecLength*512), cCopyTsb2Tsb|cBopWait);
    }
    else
#endif
    {
        uSubOpCode=rmNvmeSubOpcode;
        g32CmdPara0=r32Nvme1[rcFwRqCmd12/4];
        g32CmdPara1=r32Nvme1[rcFwRqCmd13/4];
        g32CmdPara2=r32Nvme1[rcFwRqCmd14/4];
        g32CmdPara3=r32Nvme1[rcFwRqCmd15/4];
        trigNonRWCmd(cTsb0StartBufIdx, g32HostXfrCnt, cTsb0, cNvmeWrite, cManualCq);
    }

    switch(uSubOpCode)    // (rmNvmeSubOpcode)
    {
        case cDataOutVendorCmdIdWriteRam:
            dataOutVendorCmdWriteRam();
            break;

        case cDataOutVendorCmdIdSetCardMode:
            // dataOutVendorCmdSetCardMode();
            break;

        case cDataOutVendorCmdIdWritePhysicalPage:
            dataOutVendorCmdWritePhysicalPage();
            break;

        case cDataOutVendorCmdIdWdPhyProgram:
            dataOutVendorCmdWdPhyProgram();
            break;

#if _ENABLE_SECAPI
        case cDataOutVendorCmdPsidAndMsid:
            bopCopyRam(cTrustedIfSendAddr, cTsb0Addr, 512, cBopWait|cBopTsb2Tsb);

            if(gbEnTCG)
            {
                gInSecApi=1;
                loadISPCodeCore0(cSecTsbBank, 3);
                SecAPI_NoticeSecCodeSwap(0);
                gSecurityErrorCode=SecAPI_SetCPin_Request();
                SecAPI_NoticeSecCodeSwap(1);
                gInSecApi=0;

                if(gSecurityErrorCode)
                {
                    u16StatusCode=cStatusInvalidOpCode;
                }
            }
            else
            {
                u16StatusCode=cStatusInvalidOpCode;
            }
            break;
#endif/* if _ENABLE_SECAPI */

#if _GREYBOX
        case cDataOutVendorCmdIdGreyBoxTrig:
            dataOutVendorCmdGreyBoxTrig();
            break;

        case cDataOutVendorCmdIdGreyBoxFwUniTestIn:
            dataOutVendorCmdGreyBoxFwUniTestIn();
            break;
#endif
        /* Set PSID and MSID */

        default:
            fillUnknownVendorCmdPattern();
            break;
    }    /* switch */

    enAllChStop(uStopBK);
#if (_EN_CHRONUS_UART_DEBUG)
    if(mChkUartCMDRdy)
    {
        // if (u16StatusCode==cFail)
        // g32UartCQEntryDW[3] = cStatusDeviceErr << 17;
        // else
        g32arUartCQEntryDW[3]=cStatusSuccess<<17;
        loadISPCodeCore0(cUartTsbBank, 2);

        sendUartCmdRsp(cTsb0StartBufIdx);
    }
    else
#endif
    {
        manualCompletion(u16StatusCode, 0x00, cNoRwCmd, 0);
    }
#endif/* if 1 */
}    /* nvmeVendorDataOut */

void nvmeVendorDataIn()
{
#if 1
    // BYTE bPreTrigRWCmd  =0;
    BYTE uStatusCode=cSuccess, uSubOpCode;
    // get transfer length from command field

#if (_EN_CHRONUS_UART_DEBUG)
    if(mChkUartCMDRdy)
    {
        g32HostXfrCnt=gpUartCMD->DW10;
    }
    else
#endif
    g32HostXfrCnt=rmNvmeVenderLength;    // DWord unit
    g32HostXfrCnt=(g32HostXfrCnt+127)>>7;    // change to sector base, (g32HostXfrCnt<<2)>>9

    bopClrRam((LWORD)c32Tsb0SAddr, g32HostXfrCnt*512, 0x00000000, cBopWait|cClrTsb);

#if (_EN_CHRONUS_UART_DEBUG)
    if(mChkUartCMDRdy)
    {
        uSubOpCode=gpUartCMD->DW12&0xFF;
        g32CmdPara0=gpUartCMD->DW12;
        g32CmdPara1=gpUartCMD->DW13;
        g32CmdPara2=gpUartCMD->DW14;
        g32CmdPara3=gpUartCMD->DW15;
    }
    else
#endif
    {
        uSubOpCode=rmNvmeSubOpcode;
        g32CmdPara0=r32Nvme1[rcFwRqCmd12/4];
        g32CmdPara1=r32Nvme1[rcFwRqCmd13/4];
        g32CmdPara2=r32Nvme1[rcFwRqCmd14/4];
        g32CmdPara3=r32Nvme1[rcFwRqCmd15/4];
    }

    switch(uSubOpCode)
    {
        case cDataInVendorCmdIdReadDriveInfo:
            uStatusCode=dataInVendorCmdReadDriveInfo();
            break;

        case cDataInVendorCmdIdReadFlashId:
            // g32arTsb0[0][0x1F0/4]=0x32324D53;
            // g32arTsb0[0][0x1F4/4]=0x41413036;
            uStatusCode=dataInVendorCmdReadFlashId();
            break;

        case cDataInVendorCmdIdReadRam:
            uStatusCode=dataInVendorCmdReadRam();
            break;

        case cDataInVendorCmdIdReadLog:
            uStatusCode=dataInVendorCmdReadLog();
            break;

        case cDataInVendorCmdIdReadWproPage:
            uStatusCode=dataInVendorCmdReadWproPage();
            break;

        case cDataInVendorCmdIdFlashConnectivityTest:
            // dataInVendorCmdFlashConnectivityTest();
            break;

        case cDataInVendorCmdIdReadVendorCmdDebugInfo:
            uStatusCode=dataInVendorCmdReadVendorCmdDebugInfo();
            break;

        case cDataInVendorCmdIdReadPhysicalPage:
            uStatusCode=dataInVendorCmdReadPhysicalPage();
            break;

        case cDataInVendorCmdIdReadGlobEraseCnt:
            uStatusCode=dataInVendorCmdReadGlobEraseCnt();
            break;

        case cDataInVendorCmdIdReadGlobReadCnt:
            uStatusCode=dataInVendorCmdReadGlobReadCnt();
            break;

        case cDataInVendorCmdIdLba2Pba:
            uStatusCode=dataInVuCmdLba2Pba();
            break;

        case cDataInVendorCmdIdReadHmbInfo:
            uStatusCode=dataInVuCmdReadHmbInfo();
            break;

        case cDataInVendorCmdIdReadMpInfo:
            uStatusCode=dataInVuCmdReadMpInfo();
            break;

        case cDataInVendorCmdIdReadPcieCfg:
            uStatusCode=dataInVuCmdReadPcieCfg();
            break;

        case cDataInVendorCmdIdWdPhyErase:
            uStatusCode=dataInVendorCmdWdPhyErase();
            break;

        case cDataInVendorCmdIdWdPhyRead:
            uStatusCode=dataInVendorCmdWdPhyRead();
            break;

        case cDataInVendorCmdIdWdCheckSts:
            uStatusCode=dataInVendorCmdWdCheckSts();
            break;

        case cDataInVendorCmdIdReadCr:
            uStatusCode=dataInVuCmdReadCR();
            break;

#if 0
        case cDataInVendorCmdIdSetFeature:
            uStatusCode=dataInVuCmdSetFeature();
            break;

        case cDataInVendorCmdIdReadInfoPg:
            uStatusCode=dataInVendorCmdReadInfoPg();
            break;
#endif
        case cDataInVendorCmdIddoVtDistribution:
            uStatusCode=dataInVendorCmddoVtDistribution();
            break;

        case cDataInVendorCmdIdReadEfuseReg:
            uStatusCode=dataInVendorCmdReadEfuseReg();
            break;

#if _GREYBOX
        case cDataInVendorCmdIdGreyBoxPre:
            uStatusCode=dataInVendorCmdGreyBoxPre();
            break;

        case cDataInVendorCmdIdGreyBoxTrig:
            uStatusCode=dataInVendorCmdGreyBoxTrig();
            break;

        case cDataInVendorCmdIdGreyBoxDone:
            uStatusCode=dataInVendorCmdGreyBoxDone();
            break;

        case cDataInVendorCmdIdGreyBoxInit:
            uStatusCode=dataInVendorCmdGreyBoxInit();
            break;

        case cDataInVendorCmdIdGreyBoxModifyEraseCnt:
            uStatusCode=dataInVendorCmdGreyBoxModifyEraseCnt();
            break;

        case cDataInVendorCmdIdGreyBoxMarkBadBlock:
            uStatusCode=dataInVendorCmdGreyBoxMarkBadBlock();
            break;

        case cDataInVendorCmdIdGreyBoxFwUniTestOut:
            uStatusCode=dataInVendorCmdIdGreyBoxFwUniTestOut();
            break;

        case cDataInVendorCmdGreyBoxGetFwDefPara:
            uStatusCode=dataInVendorCmdGreyBoxGetFwDefPara();
            break;

        case cDataInVendorCmdIdGreyBoxSecurityRW:
            uStatusCode=dataInVendorCmdGreyBoxSecurityRW();
            break;

        case cDataInVendorCmdGreyBoxReadH2fTab:
            uStatusCode=dataInVendorCmdGreyBoxReadH2fTab();
            break;

        case cDataInVendorCmdGreyBoxSaveQBInfo:
            dataInVendorCmdGreyBoxSaveQBInfo();
            break;
#endif/* if _GREYBOX */
        default:
            fillUnknownVendorCmdPattern();
            break;
    }    /* switch */

#if (_EN_CHRONUS_UART_DEBUG)
    if(mChkUartCMDRdy)
    {
        if(uStatusCode==cFail)
        {
            g32arUartCQEntryDW[3]=cStatusDeviceErr<<17;
        }
        else
        {
            g32arUartCQEntryDW[3]=cStatusSuccess<<17;
        }

        loadISPCodeCore0(cUartTsbBank, 2);
        sendUartCmdRsp(cTsb0StartBufIdx);
    }
    else
#endif
    {
        if(uStatusCode==cFail)
        {
            manualCompletion(    /*u16StatusCode*/ cStatusDeviceErr, 0x0, cNoRwCmd, 0x0);
        }
        else
        {
            trigNonRWCmd(cTsb0StartBufIdx, g32HostXfrCnt, cTsb0, cNvmeRead, cAutoCq);
        }
    }
#endif/* if 1 */
}    /* nvmeVendorDataIn */

#if (!_ICE_LOAD_ALL)
#pragma default_function_attributes =
#endif







