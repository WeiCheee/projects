







#include "inc/Option.h"
#include "inc/TypeDef.h"
#include "inc/Reg.h"
#include "inc/ProType.h"

#if (!_ICE_LOAD_ALL)
#pragma default_function_attributes = @ ".POWER_STATE"
#endif

BYTE chkNvmeAllIdle()    // 0 : NVMe busy  1: NVMe idle
{
    // rmChkAuxNvmeIdle doesn't include CQ check, so need a separate check for CQ
    // rmChkAuxNvmeIdle does not include rmChkCmdRdy also
    if((!rmChkAuxNvmeIdle)||(!rmChkCqDbMatch)||(rmChkCmdRdy))
    {
        return 0;    // NVMe busy
    }

    return 1;    // NVMe idle
}

BYTE idleFunction(LWORD u32IdleTimeMs)
{
    BYTE uBreak=0;
    LWORD u32RtcStop=0;

    if(u32IdleTimeMs)
    {
        u32IdleTimeMs-=((u32IdleTimeMs<<5)>>8);    // RTC Deviation, -12.5% (32/256=12.5%)
        u32RtcStop=getRtcCurrentMs()+u32IdleTimeMs;
    }

    do
    {
        if(g32NvmeCondition||mPSChgChkThrottling||pendingAsyncEvent()||mChkSanitizeInProgress
           ||chkDstInProgress()||(gChkTemperature&&(!gApstOngoing)))
        {
            uBreak=2;
        }

        if(!chkNvmeAllIdle())
        {
            uBreak=4;    // NVMe busy
        }
    }
    while((!uBreak)&&u32RtcStop&&(getRtcCurrentMs()<=u32RtcStop));

    if(uBreak)
    {
        return 0;
    }

    return 1;
}    /* idleFunction */

void chkHostEnL1andL1sub()
{
    gSupportL12=0;
    busyHostConfigIdleForL1();
    BYTE bChkHostEnL1=rmChkHostEnL1;

#if _EN_ChkCpuErr_Debug

    if(rmChkCpuErr)
    {
        NLOG(cLogPS, POWERSTATE_C, 0, " ChkCpuErr_HostEnL1 ");
    }
#endif

#if _EN_D3Hot_PS4
    busyHostConfigIdleForL1();

    if(rmChkPcieD3State&&rmChkHostEnPmL12)
    {
        gSupportL12=1;
    }
    else if(bChkHostEnL1)
#else

    if(bChkHostEnL1)
#endif    // _EN_D3Hot_PS4
    {
        // No L1.2 Need to go l1 flow
        // if(rmChkSupportAspmL11&&rmChkHostEnAspmL11)
        // {
        //    gSupportL12=1;
        // }
        busyHostConfigIdleForL1();

        if(rmChkSupportAspmL12&&rmChkHostEnAspmL12)
        {
            gSupportL12=1;
        }

#if _EN_ChkCpuErr_Debug

        if(rmChkCpuErr)
        {
            NLOG(cLogPS, POWERSTATE_C, 0, " ChkCpuErr_HostEnL1 ");
        }
#endif
    }
}    /* chkHostEnL1andL1sub */

#if _FW_HANDLE_L12
BYTE chkEnClkReq()
{
    gSupportL12=0;

    if(rmChkClkReqDeassert)    // Link is in L1.2
    {
        gSupportL12=1;
    }
    else
    {
        waitPclkRdy();    // while(!M_Chk_PCLK); //may in recovery state, need to chk PClk, otherwise PCIe MAC may crash

        // Note: No PCLK when link in L1.2
        if(rmChkHostEnL1)
        {
            if(rmChkSupportAspmL11&&rmChkHostEnAspmL11)
            {
                gSupportL12=1;
            }

            if(rmChkSupportAspmL12&&rmChkHostEnAspmL12)
            {
                gSupportL12=1;
            }
        }
    }

    if(gSupportL12&&(!rmChkClkReqAssertWake))    // enable clk reg isr source)
    {
        rmClrCdiInt;
        rmEnClkReqAssertWake;
    }
    else if(!gSupportL12&&rmChkClkReqAssertWake)
    {
        rmDisClkReqAssertWake;
    }

    return gSupportL12;
}    /* chkEnClkReq */

#endif/* if _FW_HANDLE_L12 */

#if _FW_HANDLE_L12
void enablePcieL12()
{
    LWORD u32Cnt=0;
    BYTE uPlkOffCnt=0;

#if _PHYCHG4_LTR
    waitPclkRdy();    // force link leave L1/L1.2

    if(gLtrEnabled)
    {
        srvLtrSend(0x01);
    }
#endif

    if(!chkHostIdle(1))    // host not idle, return
    {
        waitPclkRdy();    // force link leave L1/L1.2
        return;
    }

#if 1    // S_PhyChg3_DectectCKREQ //(Sam) says ok
    rmSetAuxToPipeDebug;

    while(rmChkClkReqAssert&&(u32Cnt<0x300000))
    {
        rmSetFwDebugSelect;    // for SM2263 only

        if(rmChkPclkOff)
        {
            uPlkOffCnt++;
        }
        else
        {
            // if(gparLS_PHY->L0S_RXOFF) DPHY11_L0s_RX_disable_lane(0); // disable
            rmPcieForceEnterL1;    // force L1, why? Can host issue command here?
            rmEnSwitchAuxClk;    // release clkreq# when L1, enter L1.2
            uPlkOffCnt=0;
        }

        rmClrFwDebugSelect;    // for SM2263 only

        if(!chkHostIdle(1))    // check if there is no host traffic
        {
            // force link leave L1/L1.2
            waitPclkRdy();
            break;
        }

        if(uPlkOffCnt==0xFF)
        {
            break;
        }

        u32Cnt++;
    }

    rmSetAuxToPcieDebug;    // (Sam) bug fix
#else/* if 1 */

    while(rmChkClkReqAssert&&(u32Cnt<0x300000))
    {
        // (A)if(gparLS_PHY->L0S_RXOFF) DPHY11_L0s_RX_disable_lane(0); // disable
        rmPcieForceEnterL1;    // force L1, why? Can host issue command here?
        rmEnSwitchAuxClk;    // release clkreq# when L1, enter L1.2

        if(!chkHostIdle(1))    // check if there is no host traffic
        {
            break;
        }

        u32Cnt++;
    }
#endif/* if 1 */
    rmPcieDisForceEnterL1;    // (Q) disable force L1 to avoid link enter L1 without count

    if(rmChkClkReqDeassert)    // PCIe link is in L1.2
    {
        // gSMART.g64PowerOnL12Cnt++;
        // gTelemetry.g64PowerOnL12Cnt++;
        // DebugLog(C_LOG_PS, 0x0A, 2, (u32Cnt>>16), u32Cnt, 0, 0, 0);//Enter PCIe L1.2
    }
}    /* enablePcieL12 */

#endif    // #if _FW_HANDLE_L12

#if _2260PCIE_WORKAROUND
BYTE disableL12()    // unless
{
    BYTE uEnable=0;

#if _FW_HANDLE_L12
    uEnable=rmChkL1TimeoutEn;
    rmClrL1TimeoutEn;
    rmClrL1Timeout;    // clr int
#endif
    return uEnable;
}

#if _FW_HANDLE_L12
void enableL12()    // unless
{
    rmClrL1Timeout;    // clr int
    rmSetL1TimeoutEn;
}

#endif
#endif/* if _2260PCIE_WORKAROUND */

void waitPclkRdy()
{
#if 1    // CSSD-3550
    rmPcieDisForceEnterL1;
    // rmDisSwitchAuxClk; // Disable enter L1.2
    rmPcieForceLeaveL1;

#if 1

    while(rmChkSwitchAuxClk&&(rmChkLinkCurState==cLtssmL1Idle))
#else

    while(rmChkSwitchAuxClk)
        ;// Wait L0, L1.2 back to L0, HW auto clear
#endif
        while(!rmChkPclkReady)
            ;

    rmPcieDisForceLeaveL1;
#else
    rmDisSwitchAuxClk;    // Disable enter L1.2
    rmPcieForceLeaveL1;

    while(!rmChkPclkReady)
        ;
    rmPcieDisForceLeaveL1;
#endif/* if 1 */
}    /* waitPclkRdy */

void chkAllIdle()
{
    BYTE uCnt;

    // Check system all modules are idle
    for(uCnt=0; uCnt<3; uCnt++)
    {
        if(g32OutputUART||gUART_RxTrigger)
        {
            while(!rmAuxChkAllIdle)
                ;// don't check dram, beacause idle value depanded on dram mode
        }
        else
        {
            while(!rmAuxChkAllIdleWoUart)
                ;
        }
    }
}    /* chkAllIdle */

#if (_ENABLE_NVME_PM)
#if 1
void pllGatingCtrlOnOff(BYTE uPwrState)
{
    if(uPwrState)
    {
        rmSysIdleFshPllOn;
        rmDisFshPllClkGate;
        rmSysIdleLdpcPllOn;
        rmSysIdleDspPllOn;
    }
    else
    {
        rmSysIdleLdpcPllOff;
        rmSysIdleDspPllOff;
        rmEnFlashClkAutoGate;
        rmEnFshPllClkGate;
        rmSysIdleFshPllOff;
    }
}    /* pllGatingCtrlOnOff */

void pllGatingCtrlLockPolling(BYTE uPwrState)
{
    if(uPwrState)
    {
        while(!rmChkFshPllLock)
            ;

        while(!rmChkLdpcPllLock)
            ;

        while(!rmChkDspPllLock)
            ;
    }
    else
    {
        while(rmChkLdpcPllLock)
            ;

        while(rmChkDspPllLock)
            ;

        while(rmChkFshPllLock)
            ;
    }
}    /* pllGatingCtrlLockPolling */

void pllGatingCtrl(BYTE uPwrState)    // power control LDPC/ DSP/ Flash
{
    pllGatingCtrlOnOff(uPwrState);
    pllGatingCtrlLockPolling(uPwrState);
}

#else/* if 1 */
void pllGatingCtrl(BYTE uPwrState)    // power control LDPC/ DSP/ Flash
{
    // Caution: Power down Dsp_Pll and Ldp_Pll first,
    //          then power down Fsh_Pll.
    if(uPwrState)
    {
        rmSysIdleFshPllOn;

        while(!rmChkFshPllLock)
            ;

        rmDisFshPllClkGate;
        rmSysIdleLdpcPllOn;

        while(!rmChkLdpcPllLock)
            ;

        rmSysIdleDspPllOn;

        while(!rmChkDspPllLock)
            ;
    }
    else    // power off
    {
        rmSysIdleLdpcPllOff;    // need rmEnLdpcClkAutoGate be 1
        rmSysIdleDspPllOff;

        while(rmChkLdpcPllLock)
            ;

        while(rmChkDspPllLock)
            ;

        rmEnFlashClkAutoGate;    // [momo] force flash auto gating, wait ctl confirm
        rmEnFshPllClkGate;    // source clock gating, need rmEnFlashClkAutoGate be 0xFF
        rmSysIdleFshPllOff;    // before Pll off, need to set clk gate first

        while(rmChkFshPllLock)
            ;
    }
}    /* pllGatingCtrl */

#endif/* if 1 */
void pwrDomin1Ctrl(BYTE uPwrState)
{
    if(uPwrState)
    {
        while(!rmChkPw1PowerSwitch)
            ;// check pw1_domain power

        while(!rmChkPor1)
            ;// check pw1_domain por

        while(!rmChkPwrDomain1Rst)
            ;

        ;    // check pw1_domain reset done

        rmClrPw1AutoPd;    // clr auto shut down

#if (!_FW_CTRL_LFCK)

        if(rmChkClkReqAssert)    // Link leave L1.2
        {
            // no PCLK when link is in L1.2
            waitPclkRdy();    // wait PCIe MAC clk for PCIe MAC register
        }
#endif
    }
    else
    {
        rmSetPw1AutoPd;
    }
}    /* pwrDomin1Ctrl */

void sysClkPwrMoCtrl(BYTE uPwrState)
{
    if(uPwrState)
    {
        rmSysXtalDiv1;
        rmDisXtalCpuIdleGate;
        rmSysIdleSysPllOn;

        while(!rmChkSysPllLock)
            ;// need to  wait sys pll lock before set sys clk

        rmRestorSysClkPll(g16SysClkPll);

        while(!rmChkSysPllLock)
            ;
    }
    else
    {
        // Sys_Pll power down
        g16SysClkPll=rmGetSysClkPll;    // Store Sys clk
        setSysPllClock(250);    // sysclk default 250Mhz
        rmSysIdleSysPllOff;    // disable sys pll
    }
}    /* sysClkPwrMoCtrl */

#endif/* if (_ENABLE_NVME_PM) */

void setClockGate(BYTE uPwrState)
{
    if(uPwrState)
    {
        // =====================    System /CPU
        rmEnXtalChkCkRq;    // (Sky) //Power off Xtal need to check CLKREQ#

        rmEnCk0ChkIdle;    // if be 1, CPU idle force sys clk div whatever sys idle or not

        rmBusIdleClkDiv16;    // (Sky)
        rmEnBusIdleClkDiv;    // all sys idle -> sys clk div

        // =====================    BCH/LDPC ECC
        rmDisBchDecClkDiv2;

        rmSysEnLdpcClkAutoGate;    // idle -> clk auto gate
        rmEnEncClkAGate;    // idle -> clk auto gate
        rmSysEnBchDecClkAGate;    // idle -> clk auto gate

        // when err bit cnt over threshold and error cnt over threshold, then div clk
        // monitor LDPC error bit distribution
        // confirm with Rex
        // rmSetLdpcClkDivCntThr(8);     // this is error cnt threshold
        // rmSetLdpcClkDiv2ErrThr(100);  // this is performance driving
        // rmSetLdpcClkDiv3ErrThr(80);
        // rmSetLdpcClkDiv4ErrThr(60);
        // rmSetLdpcClkDiv5ErrThr(40);
        // rmSetLdpcClkDiv6ErrThr(20);

        rmSysSetCk4DivCntRst;
        rmSysClrCk4DivCntRst;

        rmSysDisLdpcAutoClkDiv;

#if _LDPC_HD_AUTODIV
        rmSysSetLdpcHDecAutoDiv(1);    // in high power mode, clock div by 2
        rmSysEnLdpcHDecAutoDiv;
#else
        rmSysDisLdpcHDecAutoDiv;
#endif

#if _LDPC_SD_AUTODIV
        rmSysSetLdpcSDecAutoDiv(1);
        rmSysEnLdpcSDecAutoDiv;
#else
        rmSysDisLdpcSDecAutoDiv;
#endif
        // =====================     AHCI
        rmSysEnAhciMemPd;    // can always Pd

        // =====================     NVMe
        //

        // =====================     AES
        if(gbEnAes)
        {
            rmDisAesClkGate;
        }
        else
        {
            rmSysEnFwAesClkGate;    // auto gate
            rmEnAesClkGate;
        }

        // =====================    Flash
        rmEnFlashClkAutoGate;    // Auto Gating Flash clock 0~7

        // =====================    BOP
        // rmEnBopClkAGate;          // [Momo] if enable bop gating will make bop multiple search issue.

        // =====================    RAID
#if _ENABLE_RAID
        rmSysDisRaidClkGate;
#else
        rmSysEnRaidClkGate;    // force gating, not auto
#endif
        rmSysEnRaidClkAutoGate;
        rmSysEnRaidEncClkAutoGate;
        rmSysEnRaidDecClkAutoGate;

        // =====================    RSA
        rmSysEnRsaClkGate;    // not auto
    }
    else    // off
    {
        // =====================    System /CPU
        // (Sky)rmDisCk0ChkIdle; //Mask because Sys clock gating need to check idle
        // rmBusIdleClkDiv4;
        rmDisBusIdleClkDiv;

        // =====================    BCH/LDPC ECC
        rmDisBchDecClkDiv2;

        rmSysDisLdpcClkAutoGate;
        rmDisEncClkAGate;
        rmSysDisBchDecClkAGate;

        // confirm with Rex
        // rmSetLdpcClkDivCntThr(8);
        // rmSetLdpcClkDiv2ErrThr(30);
        // rmSetLdpcClkDiv3ErrThr(0);
        // rmSetLdpcClkDiv4ErrThr(0);
        // rmSetLdpcClkDiv5ErrThr(0);
        // rmSetLdpcClkDiv6ErrThr(0);

        // rmSysSetCk4DivCntRst;
        // rmSysClrCk4DivCntRst;
        rmSysDisLdpcAutoClkDiv;

        rmSysDisLdpcHDecAutoDiv;

        rmSysDisLdpcSDecAutoDiv;

        // =====================     DRAM
        //

        // =====================     AHCI
        rmSysEnAhciMemPd;

        // =====================     NVMe
        //

        // =====================     AES
        rmSysDisFwAesClkGate;
        rmDisAesClkGate;

        // =====================    Flash
        rmDisFlashClkAutoGate;
        rmDisFshPllClkGate;

        // =====================    BOP
        rmDisBopClkAGate;

        // =====================    RAID
        rmSysDisRaidClkGate;
        rmSysDisRaidClkAutoGate;
        rmSysDisRaidEncClkAutoGate;
        rmSysDisRaidDecClkAutoGate;

        // =====================    RSA
        rmSysDisRsaClkGate;
    }
}    /* setClockGate */

#if 0    // Not used
BYTE chkLinkStateIdle()
{
    BYTE uIdle=1;
    LWORD u32Cnt=0;

    if(rmChkClkReqAssert)
    {
        gSupportL12=0;    // PS3/4 shutdown flow will refer it

        while(!rmChkPclkReady)
            ;

        if(rmChkHostEnAspm)    // check host enable aspm
        {
            rmSetAuxToPcieDebug;

            while(rmGetAuxToPcieDebug!=0xE8)
                ;// debug code

            if(rmChkHostEnL1)
            {
                while((rmChkLinkCurState!=cLtssmL1Idle)&&(u32Cnt<0x100000))
                {
                    u32Cnt++;
                }

                if(rmChkLinkCurState!=cLtssmL1Idle)
                {
                    uIdle=0;
                    // DebugLog(C_LOG_PS, 0x52, 0, 0, 0, 0, 0,0);//Abort due to enter L1 fail
                }
            }
            else if(rmChkHostEnL0s)
            {
                while((rmChkLinkCurState!=cLtssmL0s)&&(u32Cnt<0x100000))
                {
                    u32Cnt++;
                }

                if(rmChkLinkCurState!=cLtssmL0s)
                {
                    uIdle=0;
                    // DebugLog(C_LOG_PS, 0x53, 0, 0, 0, 0, 0,0);//Abort due to enter L0s fail
                }
            }
        }
        else
        {
            uIdle=0;
            // DebugLog(C_LOG_PS, 0x54, 0, 0, 0, 0, 0,0);//Abort due to ASPM not enabled
        }
    }

    return uIdle;
}    /* chkLinkStateIdle */

#endif/* if 0 */

void intPwrMoCtrl(BYTE uPwrState)
{
#if (_EN_IDLEGC_DELAY)||(_ENABLE_PM_BACKUP_SMART)
    WORD u16RtcWakeupTime=cPsModeRtcWakeupNeg10Min;
#endif

    if(uPwrState)    // wakeup
    {
        rmNvmeDisFwRqRdyInt;
        rmNvmeDisSqDbInt;

        if(gsLightSwitch.usPhyLs.u16CustomizeF&cEarlyPCIeResetEn)
        {
            rmClrLtssmIntr1En;
        }

        // else
        {
            rmClrLtssmIntr2En;
        }

        rmClrLtssmIntr3En;

        // rmRtc1sIntEnable;
        rmRtc2HzIntEnable;
        // rmRtc1sClearInt;
        // rmRtc32kClearInt;
        rmRtc2HzClearInt;

        while(rmChkRtc2HzInt)
            ;

        rmVic0IntEnable=g32IntSrc;
    }
    else
    {
#if _EN_IDLEGC_DELAY
#if _EN_D3Hot_PS4

        if((!rmChkPcieD3State)&&!mPSChgChkPs34&&chkBgdGCWakeup())
#else    // _EN_D3Hot_PS4
#if (_EN_BgdT2tClnCdm||_EN_EarlyBdGC)    // 20190620_ChrisSu

        if(chkBgdGCWakeup())    // ChrisSu_20190329  only for Lenovo performance
#else

        if(!mPSChgChkPs34&&chkBgdGCWakeup())    // only Standby flow;20181217_Eason
#endif
#endif    // _EN_D3Hot_PS4
        {
            gBgdGCWakeUp=1;

            if(g32IdleGcDelayTime==0)
            {
                // NLOG(cLogThermlPS, POWERSTATE_C, 0, "init g32IdleGcDelayTime!");
                g32IdleGcDelayTime=getRtcCurrentMs();
            }
        }
        else
        {
            gBgdGCWakeUp=0;
            g32IdleGcDelayTime=0;
        }

        if(gBgdGCWakeUp)
        {
#if  (_EN_EarlyBdGC&&_EN_BgdT2tClnCdm)    // 20190620_ChrisSu

            if(gEarGCflag)
            {
                u16RtcWakeupTime=cEarlyGcWakeupTime;
            }
            else
#elif (_EN_EarlyBdGC)

            if(gEarGCflag&&(!mPSChgChkPs34))
            {
                u16RtcWakeupTime=cEarlyGcWakeupTime;
            }
            else if(!mPSChgChkPs34)
#endif
            {
                u16RtcWakeupTime=cBgdGcWakeupTime;
            }
        }
#endif/* if _EN_IDLEGC_DELAY */

        g32IntSrc=rmGetVic0IntSrc;
        rmNvmeEnFwRqRdyInt;
        // rmNvmeEnSqDbInt;
        rmSetLtssmIntr2En;
        rmSetLtssmIntr3En;

        if(gsLightSwitch.usPhyLs.u16CustomizeF&cEarlyPCIeResetEn)
        {
            rmSetLtssmIntr1En;
        }

        rmRtc2HzIntDisable;
        rmRtc2HzClearInt;

        while(rmChkRtc2HzInt)
            ;

#if (_ENABLE_PM_BACKUP_SMART)
#if _EN_D3Hot_PS4

        if(!rmChkPcieD3State)
#endif
        {
            rmSetRtc2HzMaskLo(u16RtcWakeupTime);
            rmRtc2HzReset;
            rmRtc2HzIntEnable;
            gSmartBackup=0;
        }
#endif

        rmVic0DisInt(cIrqThermalTh);
#if _LOAD_OPROM
        rmVic0EnInt(cIrqNvmeCmdRdy|cIrqPcie1|cIrqPcie2);
#else
#if (_EN_CHRONUS_UART_DEBUG)
        // rmVic0EnInt(cIrqNvmeCmdRdy|cIrqPcie1|cIrqEnUart);
        rmVic0EnInt(cIrqNvmeCmdRdy|cIrqPcie1);    // Disable UART_RX_ISR
#else
        rmVic0EnInt(cIrqNvmeCmdRdy|cIrqPcie1);
#endif
#endif
    }
}    /* intPwrMoCtrl */

#if (_ENABLE_NVME_PM)
void cpuPwrMoCtrl(BYTE uPwrMode, BYTE uPwrState)
{
    if(uPwrMode)    // wakeup
    {
        initCache();    // 2263xt need??

        __enableBranchPredict();

        // Wait core1 wake up
        __SEV();

        while(g32Core1State!=cCore1BootState_Finished) // cCore1ReadyState)
            ;
    }
    else
    {
        // Wait core1 sleep
        disableCache();    // 2263xt need??

        __disableBranchPredict();

#if _CORE1_SLEEP
        core1Sleep(uPwrState);
#endif
        g32SleepStartTime1s=getRtcCurrent1s();    // for calc temperature use
    }
}    /* cpuPwrMoCtrl */

#endif/* if (_ENABLE_NVME_PM) */

void initVdt()
{
    rmDisVdt27Fsh2;
    rmDisVdt23Fsh1;
    rmDisVdt18;
    rmDisVdt12Fio;

    // Check Flash Vcore Vdt need enable. VdtFsh1, VdtFsh2.
    if(gsLightSwitch.usVdtLs.VdtEnableBit&cEnVdtFshVcc)
    {
        // Set VDT Flash2
        rmSetVdt27Fsh2(gsLightSwitch.usVdtLs.Vdt27Fsh2Level);
        rmEnVdt27Fsh2;

        while(!rmChkVdt27Fsh2Good)
            ;

        rmClrPwFail27Fsh2;    // (Q) 2262 disable then enable VDT will cause PwFail

        // Set VDT Flash1
        rmSetVdt23Fsh1(gsLightSwitch.usVdtLs.Vdt23Fsh1Level);
        rmEnVdt23Fsh1;
        rmDisVdt23Fsh1FlashWp;

        while(!rmChkVdt23Fsh1Good)
            ;

        rmClrPwFail23Fsh1;    // (Q) 2262 disable then enable VDT will cause PwFail
    }

    // Check Flash IO Vdt need enable.
    if(gsLightSwitch.usVdtLs.VdtEnableBit&cEnVdtFshFio)
    {
        rmSetVdt12Fio(gsLightSwitch.usVdtLs.Vdt12FioLevel);
        rmEnVdt12Fio;

        while(!rmChkVdt12FioGood)
            ;

        rmClrPwFail12Fio;    // (Q) 2262 disable then enable VDT will cause PwFail
    }
}    /* initVdt */

void initAes()
{
    WORD u16Loop;

    rmDisAesClkGate;

    rmHdmaDisAutoAes;    // Disable HDMA AES function
    rmBopDisAutoAes;    // Disable BOP AES function

    // enable AES function
    rmAesKey256bFw;    // Set HDMA/BOP AES key length to 256 bits.
    rmAesKey256b;    // Set Host AES key length to 256 bits.
    // (A)A0 HW issue// M_EnAESMixRW; //After enable, read and write cmds can trig at the same time

    // ====== Initial AES Key ======//
    rmAesNormalMode;    // Switch to normal mode before changing keys
    rmFwAesNormalMode;

    // Default Key
    for(u16Loop=0; u16Loop<cMekSize; u16Loop++)
    {
        rAesCtrl[rcAesDefaultKey00+u16Loop]=0;
        rFwAes[rcAesDefaultKey00+u16Loop]=0;
    }

    // Partition Range Key
    for(u16Loop=0; u16Loop<(cMekSize*cTcgMaxRange); u16Loop++)
    {
        rAesCtrl[rcAesP0Key00+u16Loop]=0;
        rFwAes[rcAesP0Key00+u16Loop]=0;
    }

    rmAesMode;
    rmFwAesMode;
    // =========================//
}    /* initAes */

void disVdtDetect()
{
    rmDisVdt23Fsh1;
    rmDisVdt27Fsh2;
    rmDisVdt18;
    rmDisVdt12Fio;
    // rmDisVdt10;
}

#if (_ENABLE_NVME_PM)
void setAipPwrOff(void)
{
    // Efuse de-select and power down
    rmEfuseSetA0Csb;
    rmEfuseSetA0Pd;

    // AIP circuit power down
    rmSysDisOsc;
    rmSysSetCmlPd;    // Can always PD
    rmSysSetBgBufPd;    // Can always PD
    disVdtDetect();    // disable VDT detect
}

void setIsoFlashIo()
{
    // turn off flash Differential Pair IO
    gDdrValue=rmGetDdrVal;
    rmSetDdrVal(0x08);

    rmSysDisF0RwOe;
    rmSysEnF0RwPu;
    rmSysEnF0DataPd;

    rmSysDisF1RwOe;
    rmSysEnF1RwPu;
    rmSysEnF1DataPd;

    rmSysDisF2RwOe;
    rmSysEnF2RwPu;
    rmSysEnF2DataPd;

    rmSysDisF3RwOe;
    rmSysEnF3RwPu;
    rmSysEnF3DataPd;

    // Flash chip IO ctrl
    rmSysDisFceOe;
    rmSysEnFcePu;
}    /* setIsoFlashIo */

void restorFlashIo()
{
    // Flash chip IO ctrl
    rmSysEnFceOe;
    rmSysDisFcePu;

    rmSysEnF0RwOe;
    rmSysDisF0RwPu;
    rmSysDisF0DataPd;

    rmSysEnF1RwOe;
    rmSysDisF1RwPu;
    rmSysDisF1DataPd;

    rmSysEnF2RwOe;
    rmSysDisF2RwPu;
    rmSysDisF2DataPd;

    rmSysEnF3RwOe;
    rmSysDisF3RwPu;
    rmSysDisF3DataPd;

    rmSetDdrVal(gDdrValue);    // restore Differential Pair IO
}    /* restorFlashIo */

#endif/* if (_ENABLE_NVME_PM) */

void setFlashOdt(BYTE uOdtEnable)
{
    BYTE uCh, uChLoop;
    LWORD u32CtrlOdt;
    BYTE uCtrlOdt;

    BYTE *upIntrfaceSetPtr=&gCh0FshODTAndDrv;

    if(uOdtEnable)
    {
        rmEnOdtTrAuto;

        for(uChLoop=0; uChLoop<gTotalChNum; uChLoop++)
        {
            uCtrlOdt=(upIntrfaceSetPtr[uChLoop*4+0x03]&0x0F);
            u32CtrlOdt=uCtrlOdt<<8|uCtrlOdt;
            uCh=garChMapTable[uChLoop];
            r32SysCtrl1[rcCtrlOdt/4+uCh]=u32CtrlOdt;
        }
    }
    else
    {
        for(uChLoop=0; uChLoop<gTotalChNum; uChLoop++)
        {
            uCh=garChMapTable[uChLoop];
            r32SysCtrl1[rcCtrlOdt/4+uCh]=0;
        }
    }
}    /* setFlashOdt */

void setIsoGpioPuPd()    // set GPIO for low power
{
    BYTE uGpioOe;
    BYTE uGpioVal;

    // GPIO 0
    gGpio0PuBk=rmGpioP0Pu;
    gGpio0PdBk=rmGpioP0Pd;

    uGpioVal=rmGpioP0InputVal;
    uGpioOe=~rmGpioP0Oe;
    rmSetGpioP0Pu((uGpioVal&uGpioOe));
    rmSetGpioP0Pd((~uGpioVal&uGpioOe));

    // GPIO 1 //CSSD-2917
    gGpio1PuBk=rmGpioP1Pu;
    gGpio1PdBk=rmGpioP1Pd;

    uGpioVal=rmGpioP1InputVal;
    uGpioOe=~rmGpioP1Oe;    // 1=output/0=input
    rmSetGpioP1Pu((uGpioVal&uGpioOe));
    rmSetGpioP1Pd((~uGpioVal&uGpioOe));

    // GPIO 2
    gGpio2PuBk=rmGpioP2Pu;
    gGpio2PdBk=rmGpioP2Pd;
    rmSetGpioP2Pu(gGpio2PuBk&0xC0);    // Prevent the default value of PG port is set

    uGpioVal=rmGpioP2InputVal;
    uGpioOe=~(rmGpioP2Oe|(uGpioVal&0x3F));
    rmSetGpioP2Pu((uGpioVal&uGpioOe));
    rmSetGpioP2Pd((~uGpioVal&uGpioOe));
}    /* setIsoGpioPuPd */

void restorGpioPuPd(void)    // resume GPIO from low power
{
    rmSetGpioP0Pu(gGpio0PuBk);
    rmSetGpioP0Pd(gGpio0PdBk);

    rmSetGpioP1Pu(gGpio1PuBk);
    rmSetGpioP1Pd(gGpio1PdBk);
    // rmGpioP12Led(0); //(A) keep previous setting
    // rmGpioP16Led(0); //(A) keep previous setting

    rmSetGpioP2Pu(gGpio2PuBk);
    rmSetGpioP2Pd(gGpio2PdBk);
}

BYTE chkIsrStateEnable(LWORD *u32CPSR)
{
    return !(*u32CPSR&c32Bit7);
}

BYTE chkHostEnAspm()
{
    BYTE uAspmSupport=0;
    LWORD u32CPSRBK=__get_CPSR();

    busyHostConfigIdleForL1();
    BYTE uHostEnAspm=rmChkHostEnAspm;

#if _EN_ChkCpuErr_Debug

    if(rmChkCpuErr)
    {
        NLOG(cLogPS, POWERSTATE_C, 0, " ChkCpuErr_HostEnL1 ");
    }
#endif

#if _EN_D3Hot_PS4

    if(rmChkPcieD3State)
    {
        uHostEnAspm=1;    // D3 doesn't care ASPM
    }
#endif    // _EN_D3Hot_PS4

#if 1    // (S_PS35toPS4DoNotWakeLink)

    if(rmChkKeepPcieLinkSleep)    // Read M_ChkHostEnASPM will wake up PCIe Mac, only L1.2 support
    {
        uAspmSupport=1;
    }
    else
#endif
    {
        if(rmChkClkReqAssert)
        {
            if(chkIsrStateEnable(&u32CPSRBK))
            {
                __disable_irq();
            }

            // waitPclkRdy();  //Wait_PCLK_Ready for 2260, because 2262 don't wait PCLK ready to do M_ChkHostEnASPM check.
#if _EN_D3Hot_PS4

            if(uHostEnAspm)
#else

            if((!rmChkPcieD3State)&&(uHostEnAspm))
#endif    // _EN_D3Hot_PS4
            {
                uAspmSupport=1;
            }
            else
            {
                uAspmSupport=0;
            }

            if(chkIsrStateEnable(&u32CPSRBK))
            {
                __enable_irq();
            }
        }
        else
        {
            uAspmSupport=1;
        }
    }

    return uAspmSupport;
}    /* chkHostEnAspm */

WORD chkWakeUpTimer(BYTE uCurPs)
{
#if (_ENABLE_NVMEFEAT_APST)
    LWORD u32PassTime=getRtcDiffMs();
    WORD u16Diff=0xFFFF;    // wakeup time
    BYTE uAspmSupport=chkHostEnAspm();    // PSF031K

    if(g32ApstEnable&&(uAspmSupport))    // Host enable APST, because PS3/PS4 need APSM enabled
    {
        if(garApstCurrent[uCurPs].uItpt)    // idle timer is non-zero
        {
            if(uCurPs==cPs3)
            {
#if APST_Timer

                if(gApstOperationToPs3==0xFF)    // 20190604_LeverYu_APST timing
                {
                    if(u32PassTime>=g32APSTTimeGap)
                    {
                        u32PassTime=u32PassTime-g32APSTTimeGap;
                    }

                    u16Diff=garApstCurrent[cPs3].uItpt-u32PassTime;
                }
                else if((garApstCurrent[cPs3].uItpt+garApstCurrent[gApstOperationToPs3].uItpt)>u32PassTime)
                {
                    u16Diff=garApstCurrent[cPs3].uItpt+garApstCurrent[gApstOperationToPs3].uItpt-u32PassTime;
                }

#else

                if(garApstCurrent[cPs3].uItpt>g32BackgroundTimeMs)
                {
                    u16Diff=garApstCurrent[cPs3].uItpt-g32BackgroundTimeMs;
                }
#endif /* if APST_Timer */
                else
                {
                    u16Diff=0;    // skip PS3
                }
            }
            else if(garApstCurrent[uCurPs].uItpt>u32PassTime)
            {
                u16Diff=garApstCurrent[uCurPs].uItpt-u32PassTime;
            }
            else
            {
                u16Diff=0;    // skip idle
            }
        }
    }

#else/* if (_ENABLE_NVMEFEAT_APST) */
    WORD u16Diff=0xFFFF;    // wakeup time
#endif/* if (_ENABLE_NVMEFEAT_APST) */

    return u16Diff;
}    /* chkWakeUpTimer */

#if (_ENABLE_NVMEFEAT_APST)
BYTE idleBgTime(LWORD u32TargetBgTime)
{
    LWORD u32BgPassTime=getRtcDiffMs();
    BYTE uHostIdle;

#if APST_Timer

    if(((gsPowerState.uFeatVal.u32Current&cPowerStateMask)==cPs3)&&(gApstOperationToPs3==0xFF)&&(u32BgPassTime>=g32APSTTimeGap))
    {
        u32BgPassTime=u32BgPassTime-g32APSTTimeGap;    // 20190604_LeverYu_APST timing
        NLOG(cLogPS, POWERSTATE_C, 2, " g32APSTTimeGap=0x%08Xms ", g32APSTTimeGap>>16, g32APSTTimeGap);
    }
#endif

    if(u32TargetBgTime>u32BgPassTime)
    {
        u32TargetBgTime=u32TargetBgTime-u32BgPassTime;
    }
    else
    {
        g32BackgroundTimeMs=u32BgPassTime-u32TargetBgTime;    // for PS3 wakeup time
        u32TargetBgTime=0;
    }

    NLOG(cLogPS, POWERSTATE_C, 2, " idleBgTime=0x%08Xms", u32TargetBgTime>>16, u32TargetBgTime);
    uHostIdle=idleFunction(u32TargetBgTime);

    NLOG(cLogPS, POWERSTATE_C, 1, " Host idle=0x%04X ", uHostIdle);

    return uHostIdle;
}    /* idleBgTime */

#endif/* if (_ENABLE_NVMEFEAT_APST) */

#if (_SM226X_A0)
BYTE chkRxAckNum()
{
    BYTE uLowPowerOK=0;

    if(rmChkRxAckSeqNo<0x700)    // boundary = 0x7FF
    {
        uLowPowerOK=1;
    }

    return uLowPowerOK;
}

#endif

#if (_ENABLE_NVME_PM)
void chkPcieEnterLowPwrModeEnPd1()
{
    LWORD u32TmpCnt;

    rmSetPcieDoNotEnterL1;    // Force link keep in L0

    do
    {
        if((rmDetectLinkState==cLtssmL1Idle)||(rmDetectLinkState==cLtssmL123SendEidle))
        {
            u32TmpCnt=0;
        }
        else
        {
            u32TmpCnt++;
        }
    }
    while(u32TmpCnt!=16);    // wait link leave L1 for mac low power mode

    rmSetL1TimerReg(0);    // L1 wait time into L1.2, 8=1ms
    rmClrAutoSendL1SubLtr;
    rmClrPcieDoNotEnterL1;    // Disable force link keep L0
}    /* chkPcieEnterLowPwrModeEnPd1 */

#if 1    // (S_PS35toPS4DoNotWakeLink)
static BYTE chkPcieEnterLowPwrMode(BYTE uExtPhyLatency, BYTE uKeepLinkSleep, BYTE uEnPd1)
{
    BYTE uPcieIdle=1;
    BYTE uLaneActive=0x00;    // bit4 to bit7 for lane 0 to lane 3, low is active
    BYTE uTmpCnt=0;
    LWORD u32Cnt=0;

#if (_ENABLE_STANDBY_KEEP_L1)
    rmSetAutoEnterL1SubState;    // [Momo] LiteOn request, do not entry L1Sub at standby mode
#endif

#if (_EN_PERST_WAKEINLOWPOWER)
    rmClrPerstWakeActive;
    rmSetPerstWake;
    gHandlePerstInIsrForLowPower=0;
#endif

    // Set Aux to PM Mode for
    rmSetAuxToPmDebug;

#if _SM226X_A0

    if(chkNvmeAllIdle()&&chkRxAckNum())    // NVMe idle && PCIe seq
#else

    if(chkNvmeAllIdle())
#endif
    {
        if(!uEnPd1)
        {
            if((!rmChkKeepPcieLinkSleep)||(!rmL1SubInL1N))    // Check flag not be set or not in L1 substate flow
            {
                rmSetPcieDoNotEnterL1;    // Force Link Keep L0
#if 1    //  (S_PCIe_LowPower_Chk_Act_Lane)
                // Use TXelectrical signal to confirm which lanes are not available at L0 state.
                rmSetAuxToPipeDebug;
#endif
                uTmpCnt=0;

                do
                {
                    if((rmDetectLinkState==cLtssmL1Idle)||(rmDetectLinkState==cLtssmL123SendEidle))
                    {
                        uTmpCnt=0;
                    }
                    else
                    {
                        uTmpCnt++;
                    }
                }
                while(uTmpCnt!=16);    // wait link leave L1 for mac low power mode

                rmSetL12SleepTime(0xEF);    // Make sure keep in L1.2 ~15us (for protecting PCIe link)

                // 226X VCCK from 0.75V to 0.9V need 28us
                // DPhy resume only 15us
                // So PS3.5/PS4 will extend DPhy latency to 30us
                if(uExtPhyLatency)
                {
                    setPhyLatency(cSleepFlow);
                }

#if 1    // (S_PCIe_LowPower_Chk_Act_Lane)
                // TXelectrical signal is from bit 2 to 5 of byte offset 0x09. It need to shift left two bits.
                // If the lane are not available in L0 state, this signal will be high.
                // The lanes are inactive lanes when TXelectrical signal is high in L0 state.
                uLaneActive=((~(rmChkMacPhyTxElectrical<<2))&0xF0);
                rmClrAuxDebug;    // Switch back to 0x00
#endif

#if 1    // (S_AllStateResetProtectTimer)
                rmSetAllStateRstProtectTimer;
                rmClrL1PdOnlayL12;
#endif

                // L1 setting
                // if((!rmChkHostEnAspmL12)&&(!rmChkHostEnAspmL11))
                if(!gSupportL12)
                {
                    busyHostConfigIdleForL1();

                    if(!rmChkHostEnAspmL11)
                    {
                        rmSetL1GateWithoutClkreq;
                    }

                    rmSetAppClkPmEn;
                    rmSetHostEnClkPowerState;
#if !_EN_D3Hot_PS4
                    rmSetAutoSendL1SubLtr;    // (Sam) safty, to send LTR in inband
#endif    // _EN_D3Hot_PS4
                }
                else if(uKeepLinkSleep)
                {
                    // Set flag for keeping L1.2, only L1.2 can support.
                    rmSetKeepPcieLinkSleep;
                }
                else
                {
#if _FW_CTRL_LFCK
                    // _FW_CTRL_LFCK option enabled, need to sync NH. wait to implement.
#endif
                }

                // Let MAC enter low power mode
                rmAppL1PwrOffEn(1);
                rmFwSaveStateAck(1);
                // enter L1.2 Immediately
                rmSetL1TimerReg(0);    // L1 wait time into L1.2, 8=1ms
#if _EN_D3Hot_PS4

                if(rmChkPcieD3State)
                {
                    rmClrPcieDstateChangeIntrEn;
                    rmSetD1State;    // D3 prevents drive entering D3, change it to D1
                    rmClrPcieDstateChangeIntr;    // Clear the interrupt status bit due to changing D state value
                    rmSetPcieDstateChangeIntrEn;
                    rmSetD3Changed;    // Restore D3 register in BootISP
                    rmSetFwExtendSyncCnt;
                    rmSetFwExtendSyncEnable;
                    rmSetAutoEnterL1SubState;    // this will be disabled in D3 ISR, re-enables it
                }
#endif
                rmClrPcieDoNotEnterL1;    // Disable force link keep L0
            }
            else
            {
                rmClrAutoSendL1SubLtr;
                rmSetClkReqOeCtln;
                rmSetClkReqICtln;

                while((!rmL1SubInL1U)||(!rmChkPclkReady))
                    ;

                wakeUpPhy(0x01);
                sysDelay(255);    // wake phy need to some time
                wakeUpPhy(0x00);

                rmSetFwSetL1EnterL1Sub;    // Set L1 direct enter L1 substate, Original Mac need L1 back to L0 then enter L1 substate

                while((!rmL1SubInWait4ClkReq)&&(rmDetectLinkState==cLtssmL1Idle))
                    ;

                rmClrClkReqICtln;
                rmClrClkReqOeCtln;

                rmClrKeepPcieLinkSleep;    // clear flag
            }
        }

        // ===== Wait PCIe Mac enter Low power mode
        // Add timeout count prevent hang in waiting low power mode
        // PCIe enter low power mode need 13us, so timeout set ~2ms. (0x100000 cycles take ~88ms => change to 0x6000 cycles)
        while((!rmChkPcieMacLowPower&&!uEnPd1)||((rmDetectLinkState!=cLtssmL1Idle)&&uEnPd1))    // some error case prevention, like link in
                                                                                                // predetect
        {
#if (_EN_PERST_WAKEINLOWPOWER)

            // To prevent race condition of PERST wake event, FW has to check PERST again after FW clear PERST_Wake_Active register.
            // If host did assert PERST# during process, FW should abort power state.
            if(!chkNvmeAllIdle()||mGpioP1GetIsrState(cGpioB1)||rmChkLinkRstDetect||(u32Cnt>0x6000))    // NVMe busy
#else

            if(!chkNvmeAllIdle()||(u32Cnt>0x6000))    // NVMe busy
#endif
            {
                rmSetPcieDoNotEnterL1;    // CSSD-5077
#if 1
                rmSetAuxToPmDebug;
                uTmpCnt=0;

                do
                {
                    if((rmDetectLinkState==cLtssmL1Idle)||(rmDetectLinkState==cLtssmL123SendEidle)||rmChkPmIsNotActive)
                    {
                        uTmpCnt=0;
                    }
                    else
                    {
                        uTmpCnt++;
                    }
                }
                while(uTmpCnt!=16);

                rmClrAuxDebug;
#else/* if 1 */

                while(rmDetectLinkState==cLtssmL1Idle)
                    ;// wait link leave L1 for MAC low power mode
#endif/* if 1 */
                rmAppL1PwrOffEn(0);
                rmFwSaveStateAck(0);
                rmClrPcieDoNotEnterL1;    // Disable force link keep L0 //CSSD-5077
                uPcieIdle=0;
                break;
            }

            u32Cnt++;
        }

        rmSetL1TimerReg(0xFFFF);    // CSSD-5077
        rmClrEletricIdleInt;    // claer interrupt event

        rmSetFwDebugSelect;    // SM2263 only
        // enable clk reg isr source
        rmSetAuxToPipe0Debug;    // (Sam) L1 low power state patch_v2

        rmSetEletricIdleWake;    // Phy eletric not idle wake, like L1 back to L0
        rmEnClkReqAssertWake;    // CLKREQ# aassert wake

        if(!uEnPd1)
        {
#if 1    // (S_PCIe_LowPower_Chk_Act_Lane)

            // if((rmChkEletricalIdleDetect&uLaneActive)!=uLaneActive)    // (Sam) L1 low power state patch_v2
            if(((rmChkEletricalIdleDetect&uLaneActive)!=uLaneActive)||(!rmChkRefClkReqN))    // Sam patch
#else

            if(rmChkEletricalIdleDetect!=0xF0)    // (Sam) L1 low power state patch_v2
#endif
            {
                uPcieIdle=0;
            }

#if _FW_CTRL_LFCK
            else
            {
                rmSetLfckGating;
            }
#endif
        }

        rmClrAuxDebug;
        rmClrFwDebugSelect;    // SM2263 only
    }
    else
    {
        uPcieIdle=0;
    }

    return uPcieIdle;
}    /* chkPcieEnterLowPwrMode */

#endif/* if 1 */
#endif/* if (_ENABLE_NVME_PM) */

void disPcieLowPwrMo(BYTE uExtPhyLatency)
{
    // Force leave PCIe Mac low power to make sure write down PCIe MSIx Table
    rmSetPcieDoNotEnterL1;    // Force link keep L0

#if _FW_CTRL_LFCK
    rmClrLfckGating;

    while(rmDetectLinkState==cLtssmL1Idle)
    {
        rmClrLfckGating;
    }

#else

    while(rmDetectLinkState==cLtssmL1Idle)
        ;
#endif

    rmSetL12SleepTime(0xD2);    // Make sure keep in L1.2 ~4us(default value)

#if (_EN_PERST_WAKEINLOWPOWER)
    gHandlePerstInIsrForLowPower=1;
    rmClrPerstWake;
    rmClrPerstWakeActive;
#endif
    rmClrEletricIdleWake;    // disable EletricIdle Wake source
    rmDisClkReqAssertWake;    // disable EletricIdle Wake source
    rmClrEletricIdleInt;    // clear interrupt event

    rmSetAutoSendL1SubLtr;    // PCIe MAC enter low power need send LTR which value large than host L1.2 LTR threshold

#if _EN_D3Hot_PS4
    rmSetAutoEnterL1SubState;
    rmSetFwExtendSyncDisable;
#else    // _EN_D3Hot_PS4
#if (_ENABLE_STANDBY_KEEP_L1)
    rmClrAutoEnterL1SubState;    // [Momo] LiteOn request, do not entry L1Sub at standby mode
#endif

#if 1    // (S_PS35toPS4DoNotWakeLink)
    rmClrFwSetL1EnterL1Sub;    // Clear L1 direct enter L1 substate, Mac need L1 back to L0 then enter L1 substate
#endif
#endif    // _EN_D3Hot_PS4
    // Clr PCIe Mac enter low power mode
    rmAppL1PwrOffEn(0);
    rmFwSaveStateAck(0);

    // L1 low power mode
    // if((!rmChkHostEnAspmL12)&&(!rmChkHostEnAspmL11))
    {
#if 1    // (S_AllStateResetProtectTimer)
        rmClrAllStateRstProtectTimer;
        rmSetL1PdOnlayL12;
#endif

#if 1    // (S_Inband_PowerState)

        // if(rmChkL1GateWithoutClkreq)
        if(!gSupportL12)
        {
            if(gHostNoSetLtrEn)
            {
                rmClrLtrEnable;
                gHostNoSetLtrEn=0;
            }

            rmClrHostEnAspmL12;
            rmClrHostEnClkPowerState;
        }

#else/* if 1 */
        rmClrHostEnClkPowerState;
#endif/* if 1 */
        rmClrL1GateWithoutClkreq;
        rmClrL1KeepPll;
        // rmSetL1PdOnlayL12;
        rmClrAppClkPmEn;
        // rmClrHostEnClkPowerState;
    }

    if(uExtPhyLatency)
    {
        setPhyLatency(cWakeupFlow);    // set phy latency to default value 15us
    }

#if 0    // _SM226X_A0

    // Backup PCIe MSIx Table
    for(uOffset=0; uOffset<64; uOffset++)
    {
        rmPcieMsixTable(uOffset)=gar32BkMsixTab[uOffset];
    }
#endif

    // rmClrPcieDoNotEnterL1;
}    /* disPcieLowPwrMo */

void restorHwRegFromPs3()
{
    LWORD u32Loop;

    setClockGate(cSleepFlow);    // off

    tran2MemoryEccActiveMo();
    // Setting Sys/Flash/RAID ctrl reg by core1
    core1ResumePs3();    // Setting Sys&Flash ctrl reg by core1, swap core1 to rwisp bank

    // Set Buf Wrap
    initNvmeBufWrap();
    rmSetWaterMark;    // FwRq threshold, exceed threshold will produce interrupt

    // tran2MemoryEccActiveMo();

#if _ENABLE_BUS_ERR_HANDLE
    initBusErrHandler();
#endif

    // Set Uart
    if(g32OutputUART||gUART_RxTrigger)
    {
        initUart();
    }
    else
    {
        rmUartDis;
    }

    // Init variables, need to confirm
    // initFtlVar();   //?????temp mark, need to initial core1 variable ??
    // initNvmeGlobVar();
    // initCore1Var();  //?????temp mark, need to initial core1 variable ??

    // InitFuseStatus();       //Fuse initial from PS3 or PS3.5, //wait to implement
    // O16_STOP_FETCH_COMPARE; //Fused command handled by fw,    //wait to implement

    // Set clock gate
    setClockGate(cWakeupFlow);    // on

    // Init interrupt
    intPwrMoCtrl(cWakeupFlow);

    // Init I2C , 2263xt need??or wait to implement
    // if(gparLS_Thermal->SensorSel.bExternalSensor)
    // {   //enable external temperature sensor(TMP 102)
    //    i2c_Init(0x80);
    // }

#if _EN_NVMEWRDUALENGINE
    rmSwTwoNvmeEngine;
#else
    rmSwOneNvmeEngine;    // there are 2 NVMe Engine, but it has some bug. so switch to one engine mode.
#endif
#if _EN_NVMERDDUALENGINE
    rmSrTwoNvmeEngine;
#else
    rmSrOneNvmeEngine;
#endif

    // rmSetARBSoftReset;    // Reset Hmb
    rmSetHmbSoftReset;
    sysDelay(2);
    // rmClrARBSoftReset; //LeverYu_0813 SMI S0813A  SQ mismatch issue
    rmClrHmbSoftReset;

#if (!_SM226X_A0)
    rmClrAllPrpListErr;
#endif

    if(gsLightSwitch.usNvmeLs.uPreCR)
    {
        rmNvmeTsbReadPreCREn;    // 2263
    }

    // resume HMB setting
#if _EN_DisHMBInReset    // 20190805_Chief_DisHMB

    if(gsHmbInfo.uHmbEnable||(gChkFlag&cEnableFakeHMB))
#else

    if(gsHmbInfo.uHmbEnable)
#endif
    {
        resumeHmbSetting(cReadWpro);
    }

    for(u32Loop=0; u32Loop<cHmbRacingFreeCnt; u32Loop++)
    {
        g16WriteHMBH2FTable[u32Loop]=c16Null;
    }

    gsHmbInfo.uHmbHwPrdTail=rmHmbPrdQueTrigIdx;
    gsHmbInfo.uHmbHwPrdHead=rmHmbPrdQueTrigIdx;
    rmRstCrc32PutAddr;
    gsHmbInfo.uRdCrcIdx=0;
    gsHmbInfo.uWrCrcIdx=0;
}    /* restorHwRegFromPs3 */

#if (_ENABLE_NVME_PM)
void busyHostConfigIdleForL1()
{
    // BYTE uBusy;    // uMasterState;
    // BYTE utmpcount=0;
    BYTE uCurrentDoNotEnterL1;

    rmSetFwDebugSelect;
    rmSetAuxToAspmDebug;
    gMasterState=rmGetMasterState;
    uCurrentDoNotEnterL1=rmChkPcieDoNotEnterL1;

    if((gMasterState==0x00)||(gMasterState==0x01))
    {
        rmSetPcieDoNotEnterL1;
        sysDelay(512);
    }

    do
    {
        rmSetFwDebugSelect;

        while(!rmGetFwDebugSelect)
            ;

        gMasterState=rmGetMasterState;
        rmClrFwDebugSelect;

        while(rmGetFwDebugSelect)
            ;

        gXadmldle=rmGetNoTlpPending;
    }
    while(((gMasterState!=0x0)&&(gMasterState!=0x01))&&(gXadmldle==0));

    rmClrFwDebugSelect;

    if(!uCurrentDoNotEnterL1)
    {
        rmClrPcieDoNotEnterL1;
    }
}    /* busyHostConfigIdleForL1 */

void resumeFromPs3Mo()
{
    // WORD u16SysClkTemp;
    g32PsStepDebug|=c32Bit3;

    // Resume sys clk
    sysClkPwrMoCtrl(cWakeupFlow);

    if(!g32Ps3EnPwrDomain1)    // PS3 enable power domain 1 flow
    {
        // Power domin 1 on
        pwrDomin1Ctrl(cWakeupFlow);

#if 1    // (S_PS35toPS4DoNotWakeLink)

        if(!rmChkKeepPcieLinkSleep)    // if no need to keep L1.2
#endif
        {
            disPcieLowPwrMo(0);
        }

#if _FW_CTRL_LFCK
        else
        {
            rmClrLfckGating;
        }
#endif    // #if _FW_CTRL_LFCK
    }
    else
    {
        rmSetPcieDoNotEnterL1;    // Force link keep L0
    }

    // PHY wakeup event and CrystalPad power control
    rmClrSysCryPadPd;

    // enable Pll
    // pllGatingCtrl(cWakeupFlow);
    pllGatingCtrlOnOff(cWakeupFlow);

    // resume GPIO setting
    restorGpioPuPd();

    // Resume Flash IO
    restorFlashIo();    // back up first
    rmDisFlashClkAutoGate;

    // enable VDT
    initVdt();    // future to implement
    rmClrPwFailPor1;

    // resetting L1.2 timer
    rmSetL1TimerReg((gsLightSwitch.usPcieLs.usLinkStateEntranceIdleTime.u32All&0x0000FFFF)<<3);    // L1 wait time into L1.2, 8=1ms

    if(!g32Ps3EnPwrDomain1)
    {
        // Wakeup Core1
        cpuPwrMoCtrl(cWakeupFlow, cPs0);

        // pw1_domain register setting resume
        g32PsStepDebug|=c32Bit29;
        restorHwRegFromPs3();
        g32PsStepDebug|=c32Bit30;
        // init Bop
        initBop();
        g32PsStepDebug|=c32Bit31;
        pllGatingCtrlLockPolling(cWakeupFlow);
    }
    else
    {
        rmSetAutoSendL1SubLtr;
        g32PsStepDebug|=c32Bit27;
        // Init interrupt
        intPwrMoCtrl(cWakeupFlow);
        g32PsStepDebug|=c32Bit28;
        pllGatingCtrlLockPolling(cWakeupFlow);
        // Wakeup Core1
        cpuPwrMoCtrl(cWakeupFlow, cPs0);
    }
}    /* resumeFromPs3Mo */

BYTE tran2Ps3Mo()
{
    BYTE uPcieIdleState, uPowerStateAbort=0;
    LWORD u32Count=0;

    WORD u16TimeDiff=chkWakeUpTimer(cPs3);

    NLOG(cLogSYS, POWERSTATE_C, 1, " PS3 Timer=0x%04X ms ", u16TimeDiff);
    tracePcieEvent(0x71);

    if(g32Ps3EnPwrDomain1)
    {
        chkPcieEnterLowPwrModeEnPd1();
    }

    if(u16TimeDiff!=0xFFFF)
    {
        gApstPs3ToPs4=1;
    }
    else
    {
        gApstPs3ToPs4=0;
    }

    if(!u16TimeDiff)
    {
        cpuPwrMoCtrl(cWakeupFlow, cPs0);
        core1SwapIspBank();
        return 0;    // skip PS3
    }

    // for get correct UART runtime message
    if(g32OutputUART||gUART_RxTrigger)
    {
        while(!rmAuxChkUartIdle&&u32Count<(0xFFFF*32))    // >=491us
        {
            u32Count++;
        }

        if(!rmAuxChkUartIdle)
        {
            initUart();    // Reset Uart
        }
    }

    // LDPC/DSP/Flash Pll gating //must before Pw1 shutdown because ack in Pw1
    // pllGatingCtrl(cSleepFlow);
    pllGatingCtrlOnOff(cSleepFlow);

    g32PsStepDebug|=c32Bit0;

    // Set flag
    mSetPs3St;

    // set wake up timer
    if(u16TimeDiff!=0xFFFF)
    {
        enSysTmrMs(u16TimeDiff);
    }

    // Set interrupt
#if 1
    intPwrMoCtrl(cSleepFlow);
    // disable VDT isr
    rmVic0DisInt(cIrqVdt18|cIrqVdt23|cIrqVdt27Wdt|cIrqVdtFio);    // cIrqVdt18 dramless not used
#else
    g32IntSrc=rmGetVic0IntSrc;
    rmVic0DisInt(cIrqThermalTh);

    // disable VDT isr
    rmVic0DisInt(cIrqVdt18|cIrqVdt23|cIrqVdt27Wdt|cIrqVdtFio);

    rmRtc1sIntDisable;
    rmRtc1sClearInt;
    rmRtc32kClearInt;
#endif

    // Ck3 output clock auto gating
    rmEnXtalCpuIdleGate;

    // CrystalPad low power control
    if(u16TimeDiff==0xFFFF)
    {
        rmSetSysCryPadPd;    // don't Power down CrystalPad because need to wake up by timer
    }

    if(!g32Ps3EnPwrDomain1)    // Check enable power domain 1 when entry PS3
    {
        rmSetPw1AutoPd;    // Set HW auto shutdown power domain 1
    }

    // set wake up timer
    // if(u16TimeDiff!=0xFFFF)
    // {
    //    enSysTmrMs(u16TimeDiff);
    // }

    // Efuse de-select and power down
    // AIP circuit power down
    setAipPwrOff();

    // Disable flash io
    setIsoFlashIo();

    // Set GPIO low power
    setIsoGpioPuPd();

    // set sys clk
    sysClkPwrMoCtrl(cSleepFlow);

    // wait sys idle
    chkAllIdle();

    // Chk PCIe enter low power mode
    uPcieIdleState=chkPcieEnterLowPwrMode(0, gApstPs3ToPs4, (BYTE)g32Ps3EnPwrDomain1);

    pllGatingCtrlLockPolling(cSleepFlow);

    rmEnSysClkGate;    // for power off sys clk //must be here because interrupt will clear the bit

    asm ("DSB");    // check bus empty
    asm ("ISB");    // check bus empty

    // Cpu0 sleep
    if(uPcieIdleState)
    {
        asm ("NOP");
        asm ("NOP");
        asm ("NOP");
        asm ("NOP");
        asm ("NOP");
        __WFI();    // wait for interrupt
        __enable_irq();    // enable interrupt
        __disable_irq();    // disable interrupt
        asm ("NOP");
        asm ("NOP");
        asm ("NOP");
        asm ("NOP");
    }
    else
    {
        mPSChgClrPs34;    // PS3 abrot flow, host not enable ASPM or LTR
    }

    uPowerStateAbort=tran2ActiveMo(0xFF);    // 0xFF); // for JTAG wake up

    rmTimerDisable;    // force disable timer for the case if drive is not wakeup by timer

    while(rmChkTimerEnable)
        ;

    disSysTmr();    // force disable timer for the case if drive is not wakeup by timer

    return uPowerStateAbort;
}    /* tran2Ps3Mo */

void tran2Ps4MoAbort()
{
    // 1. Resume sys clk
    sysClkPwrMoCtrl(cWakeupFlow);

    // 2. Power on check
    pwrDomin1Ctrl(cWakeupFlow);
    rmClrPw2AutoPd;

    // resetting flag
    rmClrInDevSlp;    // set flag for ROM code judgement
    rmClrImFlash;    // set BOKB flag for set SLC mode in Boot code
    // rmSetDramSetReady;  //for 2262

    disPcieLowPwrMo(1);
#if 1    // (S_PS35toPS4DoNotWakeLink)
    rmClrKeepPcieLinkSleep;    // clear flag
#endif

    // 3. CrystalPad power control
    rmClrSysCryPadPd;
    // clear Allow HW decrease core power from 0.9v to 0.75v => lower core power, shutdown flash power
    rmClrExPwDnEn;
    // adjust por reset voltage TH to default 0.72V  for 0.9V
    rmSysSetPorDefaultVfrLevel;
    // disable bypass shutdown flash of EXPWD_N for PS3.5
    rmDisXtalCpuIdleGate;

    // 4. enable Pll
    pllGatingCtrl(cWakeupFlow);

    // disable flash write protect
    rmSysDisFwp;

    // 6. resume GPIO setting
    restorGpioPuPd();

    // 7. Resume Flash IO
    restorFlashIo();    // back up first
    rmDisFlashClkAutoGate;

    // 8. enable VDT
    initVdt();
    rmClrPwFailPor1;

    // Enable E2E
    if(gSecurityOption&cEnE2e)
    {
        rmEnGlobalCrc;
        rmEnE2eCrc15;
    }

    // Resume interrupt
    intPwrMoCtrl(cWakeupFlow);

    // resetting L1.2 timer
    rmSetL1TimerReg((gsLightSwitch.usPcieLs.usLinkStateEntranceIdleTime.u32All&0x0000FFFF)<<3);    // L1 wait time into L1.2, 8=1ms

    // Enable Clock gate
    setClockGate(cWakeupFlow);

    // Wakeup Core1
    cpuPwrMoCtrl(cWakeupFlow, cPs0);
}    /* resumeFromPs4Mo */

BYTE tran2Ps4Mo()
{
    BYTE uPcieIdleState, uPowerStateAbort=0;
    LWORD u32Count=0;

    // LWORD u32Time;
    // Move to UpdatePowerOnCnt when resume from PS4
    // gTelemetry.g64PowerOnPS4Cnt++; //Smart cnt //Note: TSB2 var, access need before Pw1 off

    gApstPs3ToPs4=0;
    NLOG(cLogPS, POWERSTATE_C, 0, " NVMe PS4 Shutdown Proc Start ");

    chkOverTmpTime();
    // ====== Backup Parameter (DCCM, STCM) =======
// #if (OEM==SAMSUNG)  //2280=0, 2230=6 reduce NAND Driving Setting
//    gChgNANDClock=0x00;
// #endif
    // Backup Parameter table, restore in PS4 BootIsp
    bopCopyRam((LWORD)c32Tsb2ParaAddr, (LWORD)&garParaPageId, cSizeOfParaTab, cCopyStcm2Tsb|cBopWait);

    // Backup PS4 used Core0 DCCM, restore in BootFunc (initSram())
    bopCopyRam(c32Tsb2Ps4BkAddr, c32DccmSAddr, cPs4Core0DccmBkSize, cCopyDccm2Tsb|cBopWait);

    // Backup PS4 used STCM, restore in BootFunc (initSram())
    bopCopyRam((c32Tsb2Ps4BkAddr+cPs4Core0DccmBkSize), (cParaAddr+cSizeOfParaTab), cPs4StcmBkSize, cCopyStcm2Tsb|cBopWait);

    // Backup Diff FBlock info, , restore in BootFunc (initSram())
    gpBkPS4Data->u16BkDiffFBlock0=gsRdlinkInfo.u16DiffFBlock0;
    gpBkPS4Data->u16BkDiffFBlock1=gsRdlinkInfo.u16DiffFBlock1;
    gpBkPS4Data->u16BkDiffFPageNoTran=gsRdlinkInfo.u16DiffFPageNoTran;

    // Dsiable E2E
    if(gSecurityOption&cEnE2e)
    {
        rmDisGlobalCrc;
        rmDisE2eCrc15;
    }

    if(g32OutputUART||gUART_RxTrigger)
    {
        while(!rmAuxChkUartIdle&&u32Count<(0xFFFF*32))    // >=491us
        {
            u32Count++;
        }

        if(!rmAuxChkUartIdle)
        {
            initUart();    // Reset Uart
        }
    }

    // Set flag
    mSetPs4St;

    // Set Device Sleep flag for ROM code
    rmSetInDevSlp;    // set flag for ROM code judgement

#if _INTEL_SYSTEM
    rmSetImFlash;    // set BOKB flag for set SLC mode in boot code
#endif

    // Set Flash (Pw1 func)

    // LDPC/DSP/Flash Pll gating //must before Pw1 shutdown because ack in Pw1
    pllGatingCtrl(cSleepFlow);

    setClockGate(cSleepFlow);

    // Clear and disable all interrupt
    intPwrMoCtrl(cSleepFlow);
    rmVic0DisInt(cIrqVdt18|cIrqVdt23|cIrqVdt27Wdt|cIrqVdtFio);    // diable VDT vic

#if (_ENABLE_PM_BACKUP_SMART)
#if _EN_D3Hot_PS4

    if(!rmChkPcieD3State)
#endif    // _EN_D3Hot_PS4
    {
        rmSetWakeupByTimer;    // PS4 wakeup by timer
    }
#endif

    // PCB component low power control
    rmSetExPwDnEn;    // Allow HW decrease core power from 0.9v to 0.75v => lower core power, shutdown flash power
    rmSysSetPorLowVfrLevel;    // Adjust Por reset voltage Th from 0.75V to 0.68V

    // PHY wakeup event and CrystalPad Low power control
    rmSetSysCryPadPd;

    // Ck3 output clock auto gating
    rmEnXtalCpuIdleGate;

    // pwr2 domain auto shut down when __WFI()
    rmSetPw2AutoPd;

    // pwr1 domain auto shut down when __WFI()
    rmSetPw1AutoPd;

    // Enable Flash write protect
    rmSysEnFwp;    // A2, PS4 resume BSOD issue

    // Efuse de-select and power down
    // AIP circuit power down
    setAipPwrOff();

    // Set GPIO low power
    setIsoGpioPuPd();

    // set flash
    setIsoFlashIo();

    // set sys clk
    sysClkPwrMoCtrl(cSleepFlow);

    // wait sys idle
    chkAllIdle();

    // Set load code from SPI
    rmEnSpi2Iccm;

    uPcieIdleState=chkPcieEnterLowPwrMode(1, 0, 0);
#if 0    // Foce PS4 ABORT
    uPcieIdleState=0;
#endif
    // Power off sys clk
    rmEnSysClkGate;    // must be here because interrupt will clear the bit

    asm ("DSB");    // check bus empty
    asm ("ISB");    // check bus empty

    // CPU sleep
    if(uPcieIdleState)
    {
        asm ("NOP");
        asm ("NOP");
        asm ("NOP");
        asm ("NOP");
        asm ("NOP");
        __WFI();    // wait for interrupt
        __enable_irq();    // enable interrupt
        __disable_irq();    // disable interrupt
        asm ("NOP");
        asm ("NOP");
        asm ("NOP");
        asm ("NOP");
        asm ("NOP");
    }

    asm ("NOP");
    asm ("NOP");
    asm ("NOP");
    asm ("NOP");
    asm ("NOP");
#if _EN_D3Hot_PS4

    if(rmChkPmL12Changed)
    {
        rmClrHostEnPmL12;    // Restores PML12 reg value
        rmClrPmL12Changed;    // clear flag
    }

    if(rmChkD3Changed)
    {
        if(rmChkPcieD1State)
        {
            rmClrPcieDstateChangeIntrEn;
            rmSetD3State;    // Restroes D3 register value
            rmClrPcieDstateChangeIntr;    // Clear the interrupt status bit due to changing D state value
            rmSetPcieDstateChangeIntrEn;
        }

        rmClrD3Changed;    // clear flag
    }
#endif    // _EN_D3Hot_PS4
    mPSChgClrPs34;    // PS4 abrot flow, host not enable ASPM or LTR
    uPowerStateAbort=tran2ActiveMo(0xFF);

    return uPowerStateAbort;
}    /* tran2Ps4Mo */

BYTE setSuspendMo(BYTE uPowerState)
{
    BYTE uPowerStateAbort=0;

    gsPowerState.uDevPrePs=gsPowerState.uDevCurPs;    // back up power state
    gsPowerState.uDevCurPs=uPowerState;    // change power state

/*  //Marked, intPwrMoCtrl() judge;20181217_Eason
   #if _EN_IDLEGC_DELAY
   *  if(chkBgdGCWakeup())
   *  {
   *      gBgdGCWakeUp=1;
   *
   *      if(g32IdleGcDelayTime==0)
   *      {
   *          g32IdleGcDelayTime=getRtcCurrentMs();
   *      }
   *  }
   *  else
   *  {
   *      gBgdGCWakeUp=0;
   *      g32IdleGcDelayTime=0;
   *  }
   #endif
   */
    if(uPowerState==cPs3)
    {
        if(!g32Ps3EnPwrDomain1)
        {
            saveQBInfo(cDevicePs3);    // 20181228_Louis
            /*
               * if(!gsQBootInfo.ubQBootValid)
               * {
               * saveQBInfo(cDevicePs3);
               * }
               * else
               * {
               * while(gsRwCtrl.u32ProgFifoTail!=gsRwCtrl.u32ProgFifoHead)
               *  ;
               *
               * while(gsRwCtrl.u32UpdFifoPtr!=gsRwCtrl.u32ProgFifoHead)
               *  ;
               *
               * while(gsHmbInfo.uHmbCache4kCnt)
               *  ;
               *
               * waitAllChCeBzCore0();
               *
               * while(gsTskFifoCtrl.u32HeadPtr!=gsTskFifoCtrl.u32TailPtr)
               *  ;
               *
               * rstH2F1KInfo();
               * gPowerDownMode=cDevicePs3;
               * }
               */
        }

        cpuPwrMoCtrl(cSleepFlow, cPs3);
        uPowerStateAbort=tran2Ps3Mo();
        // ----------------------------------// resume
#if 1    // (S_PS35toPS4DoNotWakeLink)

        if(uPowerStateAbort&&rmChkKeepPcieLinkSleep)
        {
            disPcieLowPwrMo(0);
            rmClrKeepPcieLinkSleep;    // clear flag
        }
#endif
        // cpuPwrMoCtrl(cWakeupFlow); //[Momo] move to tran2ActiveMo, and tran2Ps3Mo
        // readWproPageCore0(cWproQBootPg, c16Tsb0SIdx, 0);

#if _ENABLE_SECAPI

        if(gbEnAes)
        {
            initAes();
            loadISPCodeCore0(cSecTsbBank, 3);
            SecAPI_NoticeSecCodeSwap(0);
            restoreAesKey();
            // SecAPI_NoticeSecCodeSwap(1);
        }
#endif
    }
    else if(uPowerState==cPs4)
    {
#if _EN_D3Hot_PS4

        if((rmChkPcieD3State||rmChkD3Changed)&&(!gsQBootInfo.ubQBootValid))
        {
            saveQBInfo(cDevicePsD3);    // D3 state to entry PS4
        }
        else if((!rmChkPcieD3State)&&(!rmChkD3Changed))
#endif    // _EN_D3Hot_PS4
        {
            saveQBInfo(cDevicePs4);    // 20181228_Louis
        }

        /*
           * if(!gsQBootInfo.ubQBootValid)
           * {
           *  saveQBInfo(cDevicePs4);
           * }
           * else
           * {
           *  while(gsRwCtrl.u32ProgFifoTail!=gsRwCtrl.u32ProgFifoHead)
           *      ;
           *
           *  while(gsRwCtrl.u32UpdFifoPtr!=gsRwCtrl.u32ProgFifoHead)
           *      ;
           *
           *  while(gsHmbInfo.uHmbCache4kCnt)
           *      ;
           *
           *  waitAllChCeBzCore0();
           *
           *  while(gsTskFifoCtrl.u32HeadPtr!=gsTskFifoCtrl.u32TailPtr)
           *      ;
           *
           *  rstH2F1KInfo();
           *  gPowerDownMode=cDevicePs4;
           * }
           */

        // Load PS4 boot isp code to TSB3 (0x4018_0000)
        loadISPCodeCore0(cPs4ExitBootIsp, 0);
#if 0    // _ENABLE_SECAPI

        if(gbEnTCG||gbEnATAPassThrough||gbEnRpmb)
        {
            loadISPCodeCore0(cSecTsbBank, 3);
            SecAPI_NoticeSecCodeSwap(0);
            SecAPI_NoticeBackupResume_Request(cDevSlpBackup);
            // [D.H] Maybe after security API will refer to the argument. Now both cDevSlpBackup and cSwapBackup are the same flow.
        }
#endif
        // ----------------------------------// enter
        // saveSmartInfo();
        cpuPwrMoCtrl(cSleepFlow, cPs4);
        uPowerStateAbort=tran2Ps4Mo();
        // ----------------------------------// resume
        // cpuPwrMoCtrl(cWakeupFlow); //[Momo] move to tran2ActiveMo

#if 0    // _ENABLE_SECAPI

        if(gbEnAes)
        {
            initAes();
            loadISPCodeCore0(cSecTsbBank, 3);
            SecAPI_NoticeSecCodeSwap(0);
            restoreAesKey();
            // SecAPI_NoticeSecCodeSwap(1);
        }
#endif
        // RestoreFeature4DevSlp();  //future to implement
        // gDevsleepNotice = 0;  //future to implement
    }

    // restore power state
    gsPowerState.uDevCurPs=gsPowerState.uDevPrePs;
    gsPowerState.uDevLastPs=gsPowerState.uDevCurPs;

    return uPowerStateAbort;
}    /* setSuspendMo */

BYTE hdlHipmProc()
{
    BYTE uPowerStateAbort=0;

#if (_EN_WDT)
    rmDisWdt;
#endif

#if _2260PCIE_WORKAROUND
    setExtSync(cEnabled);    // Gen3 config
#endif
    rmClrNvmeFwRqRdyInt;
    rmClrNvmeDoorBellInt;
    __disable_irq();

    if(g32NvmeCondition||(rmDetectLinkState==0x05))    // NVMe event  //20190521_LeverYu_PS3 APST abort
    {
        mPSChgClrPs34;    // clr flag
        uPowerStateAbort=1;

#if _2260PCIE_WORKAROUND
        setExtSync(cDisabled);    // Gen3 config
#endif

#if 1    // (S_PS35toPS4DoNotWakeLink)

        if(rmChkKeepPcieLinkSleep)
        {
            disPcieLowPwrMo(1);
            rmClrKeepPcieLinkSleep;    // clear flag
        }
#endif
        __enable_irq();
        return uPowerStateAbort;
    }

    if(chkHostIdle(1))    // check if there is no host traffic
    {
#if _FW_HANDLE_L12

        // Link state change
        if(mPSChgChkLink12)
        {
            mPSChgClrLink12;    // Clr flag

            if(rmChkClkReqAssert)    // Check link not in L1.2, avoid double increase smart cnt - g64PowerOnL12Cnt
            {
                NLOG(cLogPS, POWERSTATE_C, 0, " hdlHipmProc(), Try to enter L1.2 ");

                if(chkEnClkReq())    // Check PCIe register
                {
                    // 0x5000_1000 ~ 0x5000_1BFF regiter will wake up L1/L1.2
                    enablePcieL12();    // Let PCIe link enter L1.2
                }
                else
                {
                    NLOG(cLogPS,
                         POWERSTATE_C,
                         3,
                         " Deassert=0x%04X, EnL1=0x%04X, EnL0s=0x%04X ",
                         rmChkClkReqDeassert,
                         rmChkHostEnL1,
                         rmChkHostEnL0s);
                    NLOG(cLogPS, POWERSTATE_C, 2, " ClkPS, Support=0x%04X, Enable=0x%04X ", rmChkSupportClkPowerState,
                         rmChkHostEnClkPowerState);
                    NLOG(cLogPS, POWERSTATE_C, 2, " ASPML11, Support=0x%04X, Enable=0x%04X ", rmChkSupportAspmL11, rmChkHostEnAspmL11);
                    NLOG(cLogPS, POWERSTATE_C, 2, " ASPML12, Support=0x%04X, Enable=0x%04X ", rmChkSupportAspmL12, rmChkHostEnAspmL12);
                }
            }
        }

#else/* if _FW_HANDLE_L12 */
#if 1    // (S_PS35toPS4DoNotWakeLink)

        if((rmChkClkReqAssert)||(!rmChkKeepPcieLinkSleep))
        {
#endif
        chkHostEnL1andL1sub();

        // Output rmChkHostEnAspmL11 and rmChkHostEnAspmL12
        if(mPSChgChkPs34)
        {
            // NLOG(cLogPS,
            //     POWERSTATE_C,
            //     2,
            //     "hdlHipmProc(), Host En L11&L12=0x%04X, PsChg=0x%04X",
            //     ((r32Pcie[rcL1SubStateCtrl/4]&0x0C)>>2),
            //     gsPowerState.uPsChg);
            NLOG(cLogPS,
                 POWERSTATE_C,
                 1,
                 "hdlHipmProc(), PsChg=0x%04X",
                 gsPowerState.uPsChg);
        }
    }
#endif/* if _FW_HANDLE_L12 */

#if 0    // _SM226X_A0

        for(uOffset=0; uOffset<64; uOffset++)
        {
            gar32BkMsixTab[uOffset]=rmPcieMsixTable(uOffset);
        }
#endif

        // Device power state change
        if(mPSChgChkPs34)
        {
            // mPSChgClrPs34; //[Momo] If host not set PS0, should be keep original PS

            // if(rmChkAuxNvmeIdle && (!rmChkCmdRdy)) //simple check host cmd
            if(chkNvmeAllIdle())    // NVMe idle
            {
                NLOG(cLogPS, POWERSTATE_C, 1, "goto setSuspendMo(), Next PS=%04d", gsPowerState.uDevNextPs);
#if  0    // _EN_FW_DEBUG_UART
                NLOG(cLogTempDebug,
                     POWERSTATE_C,
                     4,
                     "hdlHipmProc, rmHmbPrdQueTrigIdx=0x%04X, rmHmbPrdQueHeadIdx=0x%04X, uHmbHwPrdTail=0x%04X, uHmbHwPrdHead=0x%04X, ",
                     rmHmbPrdQueTrigIdx,
                     rmHmbPrdQueHeadIdx,
                     gsHmbInfo.uHmbHwPrdTail,
                     gsHmbInfo.uHmbHwPrdHead);
#endif
                uPowerStateAbort=setSuspendMo(gsPowerState.uDevNextPs);
            }
        }
    }

    __enable_irq();

#if _2260PCIE_WORKAROUND
    setExtSync(cDisabled);    // Gen3 config
#endif

#if (_EN_WDT)
    rmEnWdt;
#endif

    return uPowerStateAbort;
}    /* hdlHipmProc */

#endif/* if (_ENABLE_NVME_PM) */

#if (_ENABLE_NVMEFEAT_APST)
void nvmeApstFlow(BYTE uCurPsState)
{
    BYTE uItps, uHostIdle=0;
    LWORD u32Itpt;

#if (APST_Timer==0)
    BYTE uHostPsBk;
#endif

    uItps=garApstCurrent[uCurPsState].uItps;
    u32Itpt=garApstCurrent[uCurPsState].uItpt;

    if(u32Itpt)    // idle timer is non-zero
    {
        // Abort PS3/PS4 APST if host disable ASPM(because we can't truly enter PS3/PS4)
        if(rmChkClkReqAssert)    // Link is not in L1.2
        {
            // waitPclkRdy();    // wait PCIe MAC clk ready, L1.2
            if((!rmChkHostEnAspm)&&(uItps>=cPs3))
            {
                NLOG(cLogPS, POWERSTATE_C, 0, " Host not EnAspm !!!!");
                return;
            }
        }

        if((uCurPsState==cPs3)&&(gApstOperationToPs3!=0xFF))
        {
#if APST_Timer
            u32Itpt+=garApstCurrent[gApstOperationToPs3].uItpt;
            g32APSTTimeGap=getRtcDiffMs();
            NLOG(cLogPS, POWERSTATE_C, 3, "ApstOperationToPs3=0x%04X  u32Itpt=0x%08X ms ", gApstOperationToPs3, u32Itpt>>16, u32Itpt);
            // 20190604_LeverYu_APST timing
#else
            // for APST PS0/PS1/PS2 -> PS3 -> PS4 case
            // u32Itpt+=garApstCurrent[gApstOperationToPs3].uItpt;
            u32Itpt=garApstCurrent[gApstOperationToPs3].uItpt;    // LeverYu_20190131 Edevx pwr state issue
            startRtcCountingMs();
#endif
        }

        uHostIdle=idleBgTime(u32Itpt);

        if(uHostIdle)
        {
            mPSChgSetPs34;
            gsPowerState.uDevNextPs=uItps;    // Change Power State
            // change Host PowerState
#if (APST_Timer==0)
            uHostPsBk=gsPowerState.uFeatVal.u32Current&cPowerStateMask;
#endif
            gsPowerState.uFeatVal.u32Current&=cPowerStateMaskClr;
            gsPowerState.uFeatVal.u32Current|=gsPowerState.uDevNextPs;
            NLOG(cLogPS, POWERSTATE_C, 4, " APST From PS0x%04X to PS0x%04X, idle time=0x%08X ms ", uCurPsState, uItps, u32Itpt>>16, u32Itpt);

#if _ENABLE_NVME_PM

            if(hdlHipmProc())    // abort case
            {
                gApstRetryCnt++;
                mPSChgClrPs34;
                gApstPs3ToPs4=0;
#if APST_Timer
                g32APSTTimeGap=getRtcDiffMs();    // 20190604_LeverYu_APST timing
#else
                gsPowerState.uFeatVal.u32Current&=cPowerStateMaskClr;
                gsPowerState.uFeatVal.u32Current|=uHostPsBk;
#endif
            }
#endif
        }
    }
}    /* nvmeApstFlow */

void hdlHostApstProc()
{
    BYTE uCurPmPsState;

#if (_EN_WDT)
    rmDisWdt;
#endif
    gApstOngoing=1;    // ignore gChkTemperature when doing APST

    uCurPmPsState=gsPowerState.uFeatVal.u32Current&cPowerStateMask;

    // For PS0/1/2 case
    gApstOperationToPs3=0xFF;    // record the PS from operatonal PS mode to PS3

    if(uCurPmPsState<cPs3)
    {
        gApstOperationToPs3=uCurPmPsState;    // record the PS from operatonal PS mode to PS3 //LeverYu_20190710
        nvmeApstFlow(uCurPmPsState);
    }

    // For PS3 to PS4 case
    // The (gsPowerState.uFeatVal.u32Current) should be get current, not used loacal
    if((gsPowerState.uFeatVal.u32Current&cPowerStateMask)==cPs3)
    {
        nvmeApstFlow(cPs3);
    }

    gApstOngoing=0;
#if (_EN_WDT)
    rmEnWdt;
#endif
}    /* hdlHostApstProc */

#endif/* if (_ENABLE_NVMEFEAT_APST) */

#if _ENABLE_STANDBY_MODE
void resumeFromStandbyMo()
{
    gsDebugInfo.u32StandbyMoExitTime1=getRtcCurrent32k();

#if _SLEEP_CK3
    rmSysClrForceClk3SysPll;

    while(!rmChkSysPllLock)
        ;

#elif _SLEEP_DIV4
    rmRestorSysClkPll(g16SysClkPll);

    while(!rmChkSysPllLock)
        ;

#if (_EN_CHRONUS_UART_DEBUG)
    initUart();
#endif
#endif

    _nop();
    _nop();
    _nop();
    _nop();
    _nop();
    _nop();

    intPwrMoCtrl(cWakeupFlow);

    rmSetDdrVal(gDdrValue);
    rmSysDisAllMemPd;

#if 0
    tran2MemoryEccActiveMo();    // wait to implement   //invalid L2 Cache, enable TSB ecc and initial all TSB after power up all memory.
#endif

    rmDisFshPllClkGate;

    if(!gFlashAutoGate)
    {
        rmDisFlashClkAutoGate;
    }

    // SetFlashDriving(1); //resume flash ODT , wait to implement
    setFlashOdt(1);    // resume flash ODT

#if _CORE1_SLEEP
    // while(gsTskFifoCtrl.u32HeadPtr!=gsTskFifoCtrl.u32TailPtr);

    __SEV();    // set event

    while(g32Core1State!=cCore1BootState_Finished) // cCore1ReadyState)
        ;
    // while(gsTskFifoCtrl.u32HeadPtr!=gsTskFifoCtrl.u32TailPtr);
#endif

    gsDebugInfo.u32StandbyMoExitTime3=getRtcCurrent32k();
}    /* resumeFromStandbyMo */

void hdlStandbyProc()
{
    LWORD u32Count;
    WORD u16TimeDiff=0;    // 20181105_Eason

#if (_EN_WDT)
    rmDisWdt;
#endif

    gsDebugInfo.u32StandbyMoEntryTime=getRtcCurrent32k();
#if _EN_CDMTRIG

    if(gCDMStatus==cCDM_Non)    // ChrisSu_20190221
    {
        // gCDMStatus=cCDM_Non;
        g32CDM_WSctrCnt=0;
        g32CDM_RSctrCnt=0;
        g32CDM_SWCnt=0;
        g32CDM_SRCnt=0;
        g32CDM_WBrkCnt=0;
        g32CDM_RBrkCnt=0;
        g32CDMTimer=0;
    }
#endif

    // clear int source
    rmClrNvmeFwRqRdyInt;
    rmClrNvmeDoorBellInt;
    __disable_irq();
    // gLastInt = 0xFF;

    if(rmChkCcRdy)    // Between NVMe reset and set CC RDY, drive can  enter CPU sleep
    {
        // (A) before CC_RDY, drive can stay idle forever
        u16TimeDiff=chkWakeUpTimer(gsPowerState.uDevCurPs);
    }

    // if(g32NvmeCondition||(!chkNvmeAllIdle())||mPSChgChkThrottling)
    // if(g32NvmeCondition||(!chkNvmeAllIdle())||mPSChgChkThrottling||!u16TimeDiff)
    if(!idleFunction(0)||!u16TimeDiff)
    {
        __enable_irq();
        return;
    }

#if 0    // (_EN_IOMTRIG&&_EN_VPC_SWAP)

    if(gsIomInfo.u8Status!=cIoMeterTrig)
    {
        if(gsIomInfo.u8Status==cIoMeterChk)
        {
            NLOG(cLogGC, POWERSTATE_C, 0, " IometerChk Cancle !!!!");
            NLOG(cLogGC,
                 POWERSTATE_C,
                 4,
                 " RanCmd= 0x%08X,SeqCmd= 0x%08X ",
                 gsIomInfo.u32RanCmdCnt>>16,
                 gsIomInfo.u32RanCmdCnt,
                 gsIomInfo.u32SeqCmdCnt>>16,
                 gsIomInfo.u32SeqCmdCnt);
            NLOG(cLogGC, POWERSTATE_C, 2, " Seqlen=0x%08X ", gsIomInfo.u32SeqLen>>16, gsIomInfo.u32SeqLen);
        }

        InitIoMeter();
    }

    if(gsIomInfo1Thr.u8Status!=cIoMeterTrig)
    {
        if(gsIomInfo1Thr.u8Status==cIoMeterChk)
        {
            NLOG(cLogGC, POWERSTATE_C, 0, " Iometer1ThrChk Cancle !!!!");
            NLOG(cLogGC,
                 POWERSTATE_C,
                 4,
                 " RanCmd= 0x%08X,SeqCmd= 0x%08X ",
                 gsIomInfo1Thr.u32RanCmdCnt>>16,
                 gsIomInfo1Thr.u32RanCmdCnt,
                 gsIomInfo1Thr.u32SeqCmdCnt>>16,
                 gsIomInfo1Thr.u32SeqCmdCnt);
            NLOG(cLogGC, POWERSTATE_C, 2, " Seqlen=0x%08X ", gsIomInfo1Thr.u32SeqLen>>16, gsIomInfo1Thr.u32SeqLen);
        }

        InitIoMeter1Thr();
    }
#endif/* if _EN_IOMTRIG */

    NLOG(cLogThermlPS, POWERSTATE_C, 1, " Standby Mode Entry ,idle time=0x%04X ms", u16TimeDiff);

    // (A) Total time = (1/baud rate) * 10b/B * 32B ~= 350us
    u32Count=0;

    if(g32OutputUART||gUART_RxTrigger)
    {
        while(!rmAuxChkUartIdle&&u32Count<(0xFFFF*32))    // >=491us
        {
            u32Count++;
        }

        if(!rmAuxChkUartIdle)
        {
            // skip this sleep if UART RX in
            __enable_irq();
            return;
        }
    }

    rmClrPcieDoNotEnterL1;

    // gSMART.g64IdleSleepCnt++;
    // gTelemetry.g64IdleSleepCnt++;
    mSetStandbySt;

#if _CORE1_SLEEP
    core1Sleep(0);
#endif
    g32SleepStartTime1s=getRtcCurrent1s();    // for calc temperature use

    // SetFlashDriving(0); //disable flash ODT , wait to implement
    setFlashOdt(0);    // disable flash ODT

    gFlashAutoGate=rmChkFlashClkAutoGate;    // backup for resume
    rmEnFlashClkAutoGate;    // for power save

#if 0
    tran2MemoryEccLowPwrMo();    // flush L2 Cache and disable TSB ecc before power down all memory.
    // rmSysEnAllMemPd;    // L2 cache's ECC' sram and TSB0123' ECC's sram will be power down
    M_SysEnAllMemPdExceptRaidNvmeAes;
#else
    rmSysEnLdpcMemPd;
#endif

    rmEnFshPllClkGate;

    intPwrMoCtrl(cSleepFlow);    //

    if(u16TimeDiff!=0xFFFF)    // wait to implement
    {
        enSysTmrMs(u16TimeDiff);
    }

    gDdrValue=rmGetDdrVal;    // backup for resume
    rmSetDdrVal(0x08);

#if (_SLEEP_DIV4||_SLEEP_CK3)    // CK3 is 25MHz
    g16SysClkPll=rmGetSysClkPll;
#endif

    if(g32OutputUART||gUART_RxTrigger)
    {
        while(!rmAuxChkUartIdle)
            ;
    }

#if (_SLEEP_CK3)
    rmSysSetForceClk3SysPll;

    while(rmChkSysPllLock)
        ;

#elif (_SLEEP_DIV4)

    if(!(g16SysClkPll&0x0700))
    {
        rmRestorSysClkPll(g16SysClkPll|0x0200);    // (25*46)/8=143Mhz
    }
    else if(g16SysClkPll&0x0100)
    {
        rmRestorSysClkPll(g16SysClkPll|0x0300);
    }

    while(!rmChkSysPllLock)
        ;

#if (_EN_CHRONUS_UART_DEBUG)
    initUart();
#endif
#endif/* if _SLEEP_CK3 */

    __WFI();    // Sleep and Turn On All Interrupt
    __enable_irq();

    if(mChkStandbySt)
    {
        tran2ActiveMo(0xFF);    // 0xFF);
    }

    disSysTmr();

#if (_EN_WDT)
    rmEnWdt;
#endif
}    /* hdlStandbyProc */

#endif/* if _ENABLE_STANDBY_MODE */

#if ((_ENABLE_STANDBY_MODE)||(_ENABLE_NVME_PM))
BYTE tran2ActiveMo(BYTE uIntSrc)
{
    BYTE uAbort=0;

#if _EN_SKIPGC10MIN
    LWORD u32RTCs;
#endif

    if(mChkAllPs)
    {
#if _ENABLE_NVME_PM

        if(mChkPs3St)
        {
            rmDisSysClkGate;
            resumeFromPs3Mo();

            if(!g32Ps3EnPwrDomain1)
            {
                readWproPageCore0(cWproQBootPg, c16Tsb0SIdx, 0);
            }

            // gSMART.g64PowerOnPS3Cnt++;
            // gTelemetry.g64PowerOnPS3Cnt++;
            if(uIntSrc==0xFF)    // PS3 Abort
            {
                g32PwrOnAbortPs3Cnt++;
                uAbort=1;
            }
            else
            {
                gLowPowerStateRetryCnt=0;
                gApstRetryCnt=0;
                g64PwrOnPs3Cnt++;
            }

            NLOG(cLogThermlPS, POWERSTATE_C, 1, " PS3 State resume, CurPs=%02d, Wake Isr=0x%02X", (gsPowerState.uDevCurPs<<8)|uIntSrc);
            mClrPs3St;
        }

        if(mChkPs4St)
        {
            rmDisSysClkGate;
            tran2Ps4MoAbort();
            readWproPageCore0(cWproQBootPg, c16Tsb0SIdx, 0);    // Restore Tsb2 (0x4018_0000)
            // g32PowerOnAbortPS4Cnt++;
            g32PwrOnAbortPs4Cnt++;
            NLOG(cLogThermlPS, POWERSTATE_C, 1, " PS4 State abort, CurPs=%02d, Wake Isr=0x%02X", (gsPowerState.uDevCurPs<<8)|uIntSrc);
            mClrPs4St;
            uAbort=1;
        }
#endif/* if _ENABLE_NVME_PM */

        if(mChkStandbySt)
        {
            resumeFromStandbyMo();
            NLOG(cLogThermlPS, POWERSTATE_C, 1, " Standby Mode resume, CurPs=%02d, Wake Isr=0x%02X", (gsPowerState.uDevCurPs<<8)|uIntSrc);

            if(uIntSrc==0x15)    // 20190130_SamHu_01 temp add log
            {
                NLOG(cLogThermlPS, POWERSTATE_C, 2, " rmGetPcieIntr01Sts=0x%08X ", rmGetPcieIntr01Sts>>16, rmGetPcieIntr01Sts);
            }

            mClrStandbySt;
        }

        sleepRWTickTemp();

#if _ENABLE_PM_BACKUP_SMART
        rmRtc2HzIntDisable;

        if(uIntSrc==0x0C)
        {
            if(rmGetRtc2HzTick>=cPsModeRtcWakeupPos10Min)
            {
                gSmartBackup=1;
            }

            rmRtc2HzClearInt;

            while(rmChkRtc2HzInt)
                ;
        }

#if _EN_IDLEGC_DELAY
        else if(g32IdleGcDelayTime)
        {
            LWORD u32TimeDiffMs=getRtcCurrentMs();

            if(g32IdleGcDelayTime<=u32TimeDiffMs)    ////Revise BgdGC timer, Eason_20190326_01
            {
                u32TimeDiffMs=u32TimeDiffMs-g32IdleGcDelayTime;
            }
            else
            {
                u32TimeDiffMs=0xFFFFFFFF-g32IdleGcDelayTime+u32TimeDiffMs;
            }

#if _EN_EarlyBdGC    // 20190620_ChrisSu

            if(gEarGCflag)
            {
                if((u32TimeDiffMs)<cEarlyGCTime)
                {
                    gBgdGCWakeUp=0;
                    g32BgdGCSkipResetCnt=cBgdGcResetSctr;
                }
            }
            else
#endif

            if((u32TimeDiffMs)<cIdleGCDelayTime)
            {
                gBgdGCWakeUp=0;
                g32BgdGCSkipResetCnt=cBgdGcResetSctr;
            }
        }

#if _EN_SKIPGC10MIN           // 20190806_ChrisSu
        u32RTCs=getRtcCurrent1s();

        if((u32RTCs>30)&&(u32RTCs<600))
        {
            if((g32BgdGCSkip10min<0x200000)&&(gsGcInfo.u32TotalSlcVpc+gsGcInfo.u32TotalTlcVpc>0x140000))
            {
                gBgdGCWakeUp=0;
                g32BgdGCSkipResetCnt=cBgdGcResetSctr;
                NLOG(cLogThermlPS,
                     POWERSTATE_C,
                     4,
                     "abort BGDGC PWONRTC=%08x, g32BgdGCSkip10min=0x%08X",
                     u32RTCs>>16,
                     u32RTCs,
                     g32BgdGCSkip10min>>16,
                     g32BgdGCSkip10min);
            }
        }
#endif
#endif/* if _EN_IDLEGC_DELAY */
        rmSetRtc2HzMaskLo(0xFFFE);    // resume 1s interrupt
        rmRtc2HzReset;
        rmRtc2HzIntEnable;
#endif/* if _ENABLE_PM_BACKUP_SMART */
    }

    // traceLastIntSrc()
    if((uIntSrc!=0xFF)&&(uIntSrc!=0x0C))
    {
        gsDebugInfo.uarLastIntSrc[gsDebugInfo.uLastIntSrcCnt]=uIntSrc;
        gsDebugInfo.uar32LastIntSrcTimeStamp[gsDebugInfo.uLastIntSrcCnt]=getRtcCurrent32k();
        gsDebugInfo.uLastIntSrcCnt++;

        gsDebugInfo.uLastIntSrcCnt&=0x1F;
    }

    return uAbort;
}    /* tran2ActiveMo */

#else    // For Greybox used
BYTE tran2ActiveMo(BYTE uIntSrc)
{
    // traceLastIntSrc()
    if((uIntSrc!=0xFF)&&(uIntSrc!=0x0C))
    {
        gsDebugInfo.uarLastIntSrc[gsDebugInfo.uLastIntSrcCnt]=uIntSrc;
        gsDebugInfo.uar32LastIntSrcTimeStamp[gsDebugInfo.uLastIntSrcCnt]=getRtcCurrent32k();
        gsDebugInfo.uLastIntSrcCnt++;

        gsDebugInfo.uLastIntSrcCnt&=0x1F;
    }

    return 0;
}

#endif/* if ((_ENABLE_STANDBY_MODE)||(_ENABLE_NVME_PM)) */

// tran2MemoryEccLowPwrMo()
// {
//    // wait to implement
//    // if (gEnTsbEcc)
//    // {
//    //    vSE_TsbEccDisable();
//    // }
// }

void tran2MemoryEccActiveMo()
{
#if _ENABLE_SRAM_ECC_PROTECTION

    if(gSecurityOption&cEnTsbEcc)
    {
        asm ("DSB");    // check bus empty
        // Init Tsb0 ecc
        rmEnTsbEcc;
        rmEnTsbEccErrFlg;
        rmEnTsbEccCorrFlg;
        bopClrRam((LWORD)c32Tsb0SAddr, 256*1024, 0xFFFFFFFF, cBopWait|cClrTsb|cBopEnCrc|cBopGenCrc);
        bopClrRam((LWORD)c32Tsb0SAddr+(256*1024), 128*1024, 0xFFFFFFFF, cBopWait|cClrTsb|cBopEnCrc|cBopGenCrc);    // because 2263 rom buf wrap
        bopClrRam((LWORD)c32Tsb1SAddr, 128*1024, 0xFFFFFFFF, cBopWait|cClrTsb|cBopEnCrc|cBopGenCrc);    // Just generate ECC for CRC region
        bopClrRam((LWORD)0x40100000, 8*1024, 0x00000000, cBopWait|cClrTsb|cBopEnCrc|cBopGenCrc);    // Just generate ECC for CRC region (Spec.
                                                                                                    // TSB9)
        asm ("DSB");

        // Init Tsb4 ecc
        rmEnTsb4Ecc;
        rmEnTsb4EccErrFlg;
        rmEnTsb4EccCorrFlg;
        asm ("DSB");
    }

    if(!(gSecurityOption&cEnE2e))
    {
        bopClrRam((LWORD)c32TsbCrcAddr, 8*1024, 0xFFFFFFFF, cBopWait|cClrTsb);
    }

    // NLOG(cLogTempDebug, POWERSTATE_C, 4, "tran2MemoryEccActiveMo, gSpareCnt: 0x%04X,0x%04X,0x%04X,0x%04X ", gSpareCnt[0], gSpareCnt[1],
    // gSpareCnt[2], gSpareCnt[3]);
#else/* if _ENABLE_SRAM_ECC_PROTECTION */
    _nop();
#endif/* if _ENABLE_SRAM_ECC_PROTECTION */
}    /* tran2MemoryEccActiveMo */

#if 0    // not use, for code size
void cpuSpiLoaderRst()
{
    while(!rmAuxChkAllIdle)
        ;

    __DSB();
    __DMB();
    __ISB();

    rmSysClrSpiRst;    // W1C,HW will reset CPU auto and jump to 0x0000

    while(1)    // KW#160, design HW take action
    {
        _nop();
    }
}

#endif/* if 0 */

#if 0    // not use, for code size
void setAllIntDis()
{
    // !!Must to do for low power
    rmVic0SoftMaskN=0x00000000;    // 1 = Non Masked, 0 = Marsked
    rmVic0IntMode=0x00000000;    // 1 = Pulse Mode, 0 = Level Mode  //skyhsu FFFFFFFF-->E100B77E
    rmVic0IntEnable=0x00000000;
    rmVic0Disable;
}

#endif

//////////////////////////Thermal Throttling
BYTE chkThrottlingPowerState(BYTE uLog)
{
    BYTE uCurTemp=getThermalSensorTemp();

    gThsor0TemperatureBk=uCurTemp;    // for ice check thermal temperature

    chkAerTempThreshold(uCurTemp);
    chkOverTmpTime();

    gsPowerState.uDevNextPs=gsPowerState.uDevCurPs;

    if(gsLightSwitch.usThermalLs.uThermalCtrl&cEnThrottle)
    {
        if(gsPowerState.uDevCurPs==cPs0)
        {
            if(gMt1In&&(uCurTemp>=gMt1In))
            {
                gsPowerState.uDevNextPs=cPs1;
            }
            else if(gMt2In&&(uCurTemp>=gMt2In))
            {
                gsPowerState.uDevNextPs=cPs2;
            }
            else if(uCurTemp>=gMt3In)
            {
                gsPowerState.uDevNextPs=cPsShutdown;
            }
        }
        else if(gsPowerState.uDevCurPs==cPs1)
        {
            if(gMt2In&&(uCurTemp>=gMt2In))
            {
                gsPowerState.uDevNextPs=cPs2;
            }
            else if(gMt1Out&&(uCurTemp<=gMt1Out))
            {
                gsPowerState.uDevNextPs=cPs0;
            }
            else if(uCurTemp>=gMt3In)
            {
                gsPowerState.uDevNextPs=cPsShutdown;
            }
        }
        else if(gsPowerState.uDevCurPs==cPs2)
        {
            if(uCurTemp>=gMt3In)
            {
                gsPowerState.uDevNextPs=cPsShutdown;
            }
            else if(gMt1Out&&(uCurTemp<=gMt1Out))    // (A) spec 1.3 request drive back to PS0 from PS2 directly, skip PS1
            {
                gsPowerState.uDevNextPs=cPs0;
            }
        }
        else if(gsPowerState.uDevCurPs==cPsShutdown)
        {
#if OEM==HP    // no ways back to PS2 PS1 PS0 for HP throttling setting

            if(uCurTemp>=gMt3In+2)    // 92C enter shutdown hang  F.J. Kuo
            {
                gsPowerState.uDevNextPs=cPsUrgentShutdown;
                NLOG(cLogThermlPS, POWERSTATE_C, 0, " Enter High temperature Urgent Shutdown Hang ");
            }

#else

            if(uCurTemp<=gMt3Out)
            {
                if(gMt2In)
                {
                    gsPowerState.uDevNextPs=cPs2;
                }
                else if(gMt1In)
                {
                    gsPowerState.uDevNextPs=cPs1;
                }
                else
                {
                    gsPowerState.uDevNextPs=cPs0;
                }
            }
#endif/* if OEM==HP */
        }
    }

    if(gsPowerState.uDevNextPs!=gsPowerState.uDevCurPs)
    {
        mPSChgSetThrottling;
    }

    // The device power state can not lower than the power state which host issue
    if(gsPowerState.uDevNextPs<gsPowerState.uHostLastPs)    // CSSD-3012
    {
        mPSChgClrThrottling;
    }

    // output log after PS judgment
    if((uLog&cOutputLog)||mPSChgChkThrottling)
    {
        if(gsLightSwitch.usThermalLs.uSensorSel&cAsicSensor0)
        {
            NLOG(cLogThermlPS, POWERSTATE_C, 1, " Sensor0 output=%04d ", gThsor0Temperature);
        }

        if(gsLightSwitch.usThermalLs.uSensorSel&cAsicSensor1)
        {
            NLOG(cLogThermlPS, POWERSTATE_C, 1, " Sensor1 output=%04d ", gThsor1Temperature);
        }

        // if(uCompositeCalculation)
        // {
        //    NLOG(cLogThermlPS, POWERSTATE_C, 0, " uCompositeCalculation ");
        // }
        if(gsLightSwitch.usThermalLs.uSensorSel&cNormalization)
        {
            NLOG(cLogThermlPS, POWERSTATE_C, 1, " NormalizationTemperature=%04d ", uCurTemp);
        }
    }

    return mPSChgChkThrottling;
}    /* chkThrottlingPowerState */

void tran2ThermalThrottlingClock(PSPARAMETER *upsPs)
{
    // Change System clock
    if(upsPs->u16SysClock)    // from para table or lightswitch table
    {
        setSysPllClock(upsPs->u16SysClock);
    }

    // Change Flash clock
    if(upsPs->u16FlashClock)    // from para table or lightswitch table
    {
        // setFlashClock(gsLightSwitch.usThermalLs.usPs0.u16FlashClock);
        g16FlashClkForThermal=upsPs->u16FlashClock;
        changeFlashClock();
    }
}

void tran2ThermalThrottlingState(void)
{
#if _2260PCIE_WORKAROUND
    setExtSync(cEnabled);    // Gen3 config
#endif

    rmClrNvmeFwRqRdyInt;
    rmClrNvmeDoorBellInt;
    __disable_irq();

    if((gsLightSwitch.usThermalLs.uThermalCtrl&cEnShutDownHang)&&(gsPowerState.uDevNextPs==cPsShutdown))
    {
        // save log before hang
        // ThrottlingTelemetryUpdate();  //wait to implement
        // SaveEventLog();               //wait to implement, need to call momo's new log function
    }

    if(g32OutputUART||gUART_RxTrigger)
    {
        while(!rmAuxChkUartIdle)
            ;
    }

    if(gsPowerState.uDevNextPs==cPs0)    // PS0
    {
        tran2ThermalThrottlingClock(&gsLightSwitch.usThermalLs.usPs0);
    }
    else if(gsPowerState.uDevNextPs==cPs1)    // PS1
    {
        tran2ThermalThrottlingClock(&gsLightSwitch.usThermalLs.usPs1);
        g32ThermalMT1TransitionCount++;
        g32ThermalMT1TranCnt++;
    }
    else if(gsPowerState.uDevNextPs==cPs2)    // PS2
    {
        tran2ThermalThrottlingClock(&gsLightSwitch.usThermalLs.usPs2);
        g32ThermalMT2TransitionCount++;
        g32ThermalMT2TranCnt++;
    }

#if OEM==HP    // HP throttling setting F.J. Kuo 20190401
    else if(gsPowerState.uDevNextPs==cPsShutdown)
#else
    else    // ShutDown
#endif
    {
        tran2ThermalThrottlingClock(&gsLightSwitch.usThermalLs.usPsShutdown);

        if(gsLightSwitch.usThermalLs.uThermalCtrl&cEnShutDownHang)
        {
#if (_EN_WDT)
            rmDisWdt;
#endif
            rmSetPhyRst;
            rmEnFlashClkAutoGate;    // for power save
            rmVic0DisInt(cIrqTimerAll|cIrqThermalTh);

#if _CORE1_SLEEP
            core1Sleep(0);
#endif
            rmSysSetForceClk3SysPll;

            __WFI();    // Sleep and Turn On All Interrupt(wait for interrupt)
            __enable_irq();

            while(1)
                ;// KW#96, design FW flow
        }
    }
#if OEM==HP
    else    // cPSUrgentshutdown hang in 92C  F.J. Kuo 20190401
    {
#if (_EN_WDT)
        rmDisWdt;
#endif
        rmSetPhyRst;
        rmEnFlashClkAutoGate;    // for power save
        rmVic0DisInt(cIrqTimerAll|cIrqThermalTh);

#if _CORE1_SLEEP
        core1Sleep(0);
#endif
        rmSysSetForceClk3SysPll;

        __WFI();    // Sleep and Turn On All Interrupt(wait for interrupt)
        __enable_irq();

        while(1)
            ;// KW#96, design FW flow
    }
#endif/* if OEM==HP */

    // SetTLCPartialReadBackPageThreshold(); //2263xt need??  //recalculate parital check threshold, actually we only need to check once.
    while(!rmChkSysPllLock)
        ;

    while(!rmChkLdpcPllLock)
        ;

    rmUartBaudRate=(tran2DecClk()/921600)-1;

    // ThrottlingTelemetryUpdate();   //wait to implement

    gsPowerState.uDevCurPs=gsPowerState.uDevNextPs;
    gsPowerState.uDevLastPs=gsPowerState.uDevCurPs;
    mClrThermalThrottlingReason;

    __enable_irq();

#if _2260PCIE_WORKAROUND
    setExtSync(cDisabled);
#endif
}    /* tran2ThermalThrottlingState */

void chgCurrentPowerState(BYTE uPwrState)
{
    if(uPwrState!=gsPowerState.uDevCurPs)
    {
        if(uPwrState>gsPowerState.uDevCurPs)    // PS0/PS1 change to PS1/PS2
        {
            mClrThermalThrottlingReason;
            gsPowerState.uDevNextPs=uPwrState;
            tran2ThermalThrottlingState();
        }
        else    // if(uPwrState<gsPowerState.uDevCurPs)  // PS1/PS2 change to PS0/PS1
        {
            chkThrottlingPowerState(cOutputLog);    // output log,return gsPowerState.uDevNextPs & mPSChgSetThrottling

            if(mPSChgChkThrottling)
            {
                tran2ThermalThrottlingState();
                mPSChgClrThrottling;
            }
        }
    }
}    /* chgCurrentPowerState */

void getOverTmpElapseTime(BYTE uBitMap)
{
    if(gsSmart.usStatus.uOverTempBitMap&uBitMap)
    {
        if(gsSmart.usStatus.uOverTempBitMap&cOverWcTemp)
        {
            gsSmart.usCnt.u64WcTempElapsedTimeSec+=getRtcDiffWcTemp();
        }
        else    // (gsSmart.usStatus.uOverTempBitMap&cOverCcTemp)
        {
            gsSmart.usCnt.u64CcTempElapsedTimeSec+=getRtcDiffCcTemp();
        }

        gsSmart.usStatus.uOverTempBitMap&=~uBitMap;
    }
}

void chkOverTmpTime()
{
#if _EN_NAND_TEMP
    LWORD u16TempK=mChgCelsiustoKelvin(g32AvgNandTemp);
#else
    LWORD u16TempK=mChgCelsiustoKelvin(getThermalSensorTemp());
#endif

    if(gsLightSwitch.usNvmeLs.u16WcTemp&&gsLightSwitch.usNvmeLs.u16CcTemp)
    {
        if(u16TempK<gsLightSwitch.usNvmeLs.u16WcTemp)
        {
            getOverTmpElapseTime(cOverWcTemp);
            getOverTmpElapseTime(cOverCcTemp);
        }
        else if((u16TempK>=gsLightSwitch.usNvmeLs.u16WcTemp)&&(u16TempK<gsLightSwitch.usNvmeLs.u16CcTemp))
        {
            getOverTmpElapseTime(cOverCcTemp);
            startRtcCountingWcTemp();
        }
        else    // (u16TempK>=gsLightSwitch.usNvmeLs.u16CcTemp))
        {
            getOverTmpElapseTime(cOverWcTemp);
            startRtcCountingCcTemp();
        }
    }
    else if((!gsLightSwitch.usNvmeLs.u16WcTemp)&&gsLightSwitch.usNvmeLs.u16CcTemp)
    {
        if(u16TempK<gsLightSwitch.usNvmeLs.u16CcTemp)
        {
            getOverTmpElapseTime(cOverCcTemp);
        }
        else
        {
            startRtcCountingCcTemp();
        }
    }
    else if(gsLightSwitch.usNvmeLs.u16WcTemp&&(!gsLightSwitch.usNvmeLs.u16CcTemp))
    {
        if(u16TempK<gsLightSwitch.usNvmeLs.u16WcTemp)
        {
            getOverTmpElapseTime(cOverWcTemp);
        }
        else
        {
            startRtcCountingWcTemp();
        }
    }
}    /* chkOverTmpTime */

/*  wait to implement
   * void ThrottlingTelemetryUpdate()
   * {
   *  BYTE uSaveId = 0;
   *  if(gsPowerState.uDevCurPs == C_PS0)
   *  {
   *      gSMART.g64PS0toPS1++;
   *      gTelemetry.g64PS0toPS1++;
   *      uSaveId = C_SaveID_Throttling_0_to_1;
   *  }
   *  else if(gsPowerState.uDevCurPs == C_PS1 && gsPowerState.uDevNextPs == C_PS2)
   *  {
   *      gSMART.g64PS1toPS2++;
   *      gTelemetry.g64PS1toPS2++;
   *      uSaveId = C_SaveID_Throttling_1_to_2;
   *  }
   *  else if(gsPowerState.uDevCurPs == C_PS2 && gsPowerState.uDevNextPs == C_PSShutdown)
   *  {
   *      gSMART.g64PS2toPSShutDown++;
   *      gTelemetry.g64PS2toPSShutDown++;
   *      uSaveId = C_SaveID_Throttling_2_to_ShutDown;
   *  }
   *  else if(gsPowerState.uDevCurPs == C_PS1 && gsPowerState.uDevNextPs == C_PS0)
   *  {
   *      gSMART.g64PS1toPS0++;
   *      gTelemetry.g64PS1toPS0++;
   *      uSaveId = C_SaveID_Throttling_1_to_0;
   *  }
   *  else if(gsPowerState.uDevCurPs == C_PS2 && gsPowerState.uDevNextPs == C_PS1)
   *  {
   *      gSMART.g64PS2toPS1++;
   *      gTelemetry.g64PS2toPS1++;
   *      uSaveId = C_SaveID_Throttling_2_to_1;
   *  }
   *  else if(gsPowerState.uDevCurPs == C_PSShutdown && gsPowerState.uDevNextPs == C_PS2)
   *  {
   *      gSMART.g64PSShutDowntoPS2++;
   *      gTelemetry.g64PSShutDowntoPS2++;
   *      uSaveId = C_SaveID_Throttling_ShutDown_to_2;
   *  }
   *
   #if (!S_Thermal_TestFW)
   *  NLOG(cLogThermlPS, POWERSTATE_C, 0, " ThrottlingTelemetryUpdate ");
   #endif
   * }
   */
#if _ENABLE_SCP_PLP
void hdlPlpScpFlow(BYTE uAbortWait)
{
    BYTE uPlpInit=0;
    LWORD u32Temp1=0, u32Temp2=0;

    // in future, Plp of  device sleep will be designed
    if(mChkNvmeEnPlpScp)
    {
        if(mGpioP2GetIsrState(cGpioB5))    // gpio interrupt source
        {
            u32Temp1=getRtcCurrent32k();

            if(rmGpioP25PlpInitAssert)
            {
                uPlpInit=1;

                // ps4 don't wait 50ms
                while((u32Temp2<c32PartialCleanRtc50ms)&&(!uAbortWait))
                {
                    u32Temp2=chkRtc32kProcTime(u32Temp1);    // rmGetRtc32kTick-u32Temp1;

                    if(rmGpioP25PlpInitDeAssert)
                    {
                        uPlpInit=0;
                        break;
                    }
                }

                if(uPlpInit)
                {
                    mSetGpioInitPlpScp;
                    g32arPlpScpTimeStamp=getRtcCurrent32k();
                    rmSetAllQueStopFetchCmd;
                    rmGpioP20PlpFBackAssert;
                    gsFtlDbg.u32PlpScpGpioInitCnt++;
                    NLOG(cLogHost,
                         POWERSTATE_C,
                         3,
                         " GPIO25 Assert, gHandlePlpScpFlow=0x%04X, PlpScpGpioInitCnt=%08d",
                         gHandlePlpScpFlow,
                         gsFtlDbg.u32PlpScpGpioInitCnt>>16,
                         gsFtlDbg.u32PlpScpGpioInitCnt&0xffff);
                }
            }
            else if(rmGpioP25PlpInitDeAssert)
            {
                uPlpInit=0;

                while((u32Temp2<c32PartialCleanRtc50ms)&&(!uAbortWait))
                {
                    u32Temp2=chkRtc32kProcTime(u32Temp1);    // rmGetRtc32kTick-u32Temp1;

                    if(rmGpioP25PlpInitAssert)
                    {
                        uPlpInit=1;
                        break;
                    }
                }

                if(!uPlpInit)
                {
                    mClrGpioInitPlpScp;
                    rmClrAllQueStopFetchCmd;
                    NLOG(cLogHost, POWERSTATE_C, 1, " GPIO25 De-Assert, gHandlePlpScpFlow=0x%04X ", gHandlePlpScpFlow);
                    rmGpioP20PlpFBackDeAssert;
                }
            }

            gpioClrIsr(rcGpioIntSetP2, cGpioB5);

            if(mGpioP2GetIsrState(cGpioB5))    // hw read check confirm
            {
                gpioClrIsr(rcGpioIntSetP2, cGpioB5);
            }
        }
    }
}    /* hdlPlpScpFlow */

#endif/* if _ENABLE_SCP_PLP */
#if (!_ICE_LOAD_ALL)
#pragma default_function_attributes =
#endif







