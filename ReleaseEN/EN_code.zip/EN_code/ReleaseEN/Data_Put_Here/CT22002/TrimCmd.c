







#include "inc/ProType.h"
// #include "inc/FlashCtrl.h"
#include "inc/GlobVar0.h"
#include "inc/Const.h"
#include "inc/GlobVarS.h"
#include "inc/GlobVarT.h"
#include "inc/Reg.h"
#include "inc/FtlCtrl.h"
#include "inc/Mac.h"
#include "inc/BitDef.h"

#if (_PRJ_ISP||_PRJ_NVME)
void popCacheF2hTab(WORD u16Hblock, TRIMTOUTINFO *upTOutInfo)
{
    WORD u16RslOfst, u16StartUnit=0, u16UnitLen=g16TotalPgPerF2hTab;
    WORD u16RslFBlock;
    WORD u16ActiveCacheBlock, u16FluCacheBlock, u16CacheF2hTabFreePtr;
    LWORD u32SrchF4kBase, u32SrchF4kBaseFlu, u32SrchF4kBaseAct, u32RslFPage;
    UCLWORD *u32pH2fPtr, *u32pUptH2fPtr;
    BYTE uFlag, ubLsb;

    u32pH2fPtr=(UCLWORD *)g32arTsb0[upTOutInfo->u32TrimH2fTabBufIdx];

    u16ActiveCacheBlock=gsCacheInfo.u16ActiveCacheBlock;
    u16FluCacheBlock=gsCacheInfo.u16FluCacheBlock;
    u32SrchF4kBaseAct=gsCacheInfo.u32SrchF4kBase;
    u32SrchF4kBaseFlu=gsCacheInfo.u32SrchF4kBaseFlu;
    u16CacheF2hTabFreePtr=gsCacheInfo.u16CacheF2hTabFreePtr;
    // rmSetSrchMsk(0xFFFF0000);

    while((u16StartUnit<u16UnitLen)&&
          (bopSrchRam((LWORD)garCacheF2hTab, (LWORD)u16Hblock<<16, 0xFFFF0000, u16StartUnit, u16UnitLen,
                      cBopSrchDat|cBopLwordMo|cBopWait|cBopNotRstFlag)!=0xFFFF))
    {
        do
        {
            u16StartUnit=rmGetSrchRslOfst;

            u16RslOfst=u16StartUnit;

            do
            {
                uFlag=0;
                u16StartUnit++;

                if(u16StartUnit<u16UnitLen)
                {
                    if(garCacheF2hTab[u16RslOfst+1].u16HBlock==u16Hblock)
                    {
                        uFlag=1;
                    }
                    else
                    {
                        rmSetBopDesAddr(u16StartUnit);
                        rmTrigBopOpWoPause(cBopSrchOp);
                    }
                }

                if(u16RslOfst>u16CacheF2hTabFreePtr)
                {
                    // Active cache block
                    u16RslFBlock=u16ActiveCacheBlock;
                    u32SrchF4kBase=u32SrchF4kBaseAct;
                }
                else
                {
                    // Flush cache block
                    u16RslFBlock=u16FluCacheBlock;
                    u32SrchF4kBase=u32SrchF4kBaseFlu;
                }

                u32RslFPage=u32SrchF4kBase-u16RslOfst;
                ubLsb=(!mChkMlcMoBit(u16RslFBlock));
                u32pUptH2fPtr=u32pH2fPtr+garCacheF2hTab[u16RslOfst].u16HPage;
                setH2fSrcBlock(u32pUptH2fPtr, u16RslFBlock, u32RslFPage, ubLsb, cTrue);

                *(LWORD *)(&garCacheF2hTab[u16RslOfst])=*(LWORD *)(&garCacheF2hTab[u16RslOfst])|c32Bit31;    // garCacheF2hTab[u16RslOfst].u16HBlock|=c16Bit15;

                u16RslOfst++;
            }
            while(uFlag!=0);

            while(rmChkBopBz)
                ;
        }
        while(rmChkSrchValFind&&(u16StartUnit<u16UnitLen));
    }

    mClrSrcInCache(u16Hblock);
    rmSetSrchDefault;
}    /* popCacheF2hTab */

WORD chkAllEntryValid(WORD *u16pEntryCnt, TRIMTOUTINFO *upTOutInfo, BYTE uOpCode)
{
    WORD u16Loop, u16EntryPtr=0, u16CommandStatus=cStatusSuccess;
    LWORD u32LastTrimLba=c32BitFF;
    TRIMINFO *upTrimInfo=(TRIMINFO *)upTOutInfo->u32TrimSourceEntryAddr;    // g16Trim512BCnt can't be >8

    upTOutInfo->u16TotalValidEntryCnt=0;

    for(u16Loop=0; u16Loop<*u16pEntryCnt; u16Loop++)
    {
        if(upTrimInfo->u32Length!=0)
        {
            if((uOpCode!=cNvmeCmdSanitize)&&(uOpCode!=cNvmeCmdNamespaceManagement))
            {
                // currently support trim all for Format and Sanitize
                u16CommandStatus=chkLbaRange((LWORD)((upTrimInfo->u64StartLba)>>32),
                                             (LWORD)upTrimInfo->u64StartLba,
                                             upTrimInfo->u32Length,
                                             rmNvmeNsId, uOpCode);
                upTrimInfo->u64StartLba+=gsNamespace.usInfo[rmNvmeNsId-1].u32StartLba;
            }

            if(u16CommandStatus)
            {
                break;
            }
            else
            {
                if((LWORD)upTrimInfo->u64StartLba!=u32LastTrimLba)
                {
                    g32arTsb0[cTrimLBAInfoStBuf][u16EntryPtr]=(LWORD)upTrimInfo->u64StartLba;
                    g32arTsb0[cTrimLenInfoStBuf][u16EntryPtr]=upTrimInfo->u32Length;
                    u16EntryPtr++;
                }
                else
                {
                    g32arTsb0[cTrimLenInfoStBuf][u16EntryPtr-1]+=upTrimInfo->u32Length;
                }

                if(gsRwCtrl.uPreTrimCnt!=0)
                {
                    if((LWORD)upTrimInfo->u64StartLba==gsRwCtrl.u32LastTrimLba)
                    {
                        g32arTsb0[cTrimLBAInfoStBuf][u16EntryPtr-1]-=gsRwCtrl.uPreTrimCnt;
                        g32arTsb0[cTrimLenInfoStBuf][u16EntryPtr-1]+=gsRwCtrl.uPreTrimCnt;
                    }

                    gsRwCtrl.uPreTrimCnt=0;
                }

                u32LastTrimLba=(LWORD)upTrimInfo->u64StartLba+upTrimInfo->u32Length;
                upTOutInfo->u16TotalValidEntryCnt++;    // Valid Trim Entry
            }
        }

        upTrimInfo++;
    }

    *u16pEntryCnt=u16EntryPtr;

    if((u16EntryPtr>0)&&(g32arTsb0[cTrimLBAInfoStBuf][u16EntryPtr-1]&(cSctrPer4k-1))&&
       (g32arTsb0[cTrimLenInfoStBuf][u16EntryPtr-1]<(cSctrPer4k-(g32arTsb0[cTrimLBAInfoStBuf][u16EntryPtr-1]&(cSctrPer4k-1)))))
    {
        gsRwCtrl.uPreTrimCnt=0;
    }
    else
    {
        gsRwCtrl.u32LastTrimLba=u32LastTrimLba;
        gsRwCtrl.uPreTrimCnt=u32LastTrimLba&(cSctrPer4k-1);
    }

    return u16CommandStatus;
}    /* chkAllEntryValid */

BYTE chkTimeOut(TRIMTOUTINFO *upTOutInfo)
{
#if _EN_TRIM_TIMEOUT
    if(gCpu0TOFlag)
    {
        if(upTOutInfo->uNowToutUnitCnt<upTOutInfo->uTotalTOutUnitCnt)
        {
            disSysTmr();
            enSysTmr(cPartialCleanTmer100ms);
            upTOutInfo->uNowToutUnitCnt++;
            return cFalse;
        }
        else
        {
            return cTrue;    // real timeout
        }
    }
#endif
    return cFalse;
}    /* chkTimeOut */

BYTE chkH2fTabInvalid(TRIMTOUTINFO *upTOutInfo)
{
    BYTE uInvalid=0;
    WORD u16SrchResult;

    u16SrchResult=bopSrchRam((UCLWORD)&g32arTsb0[upTOutInfo->u32TrimH2fTabBufIdx],
                             0xFFFFFFFF,
                             0xFFFFFFFF,
                             0,
                             g16PagePerH2fTab,
                             cBopSrchMin|cBopLwordMo|cBopWait);
    // u32pH2fPtr+=u16SrchResult;

    if(u16SrchResult!=0xFFFF)
    {
        if(mGetSrcFBlkAddr(g32arTsb0[upTOutInfo->u32TrimH2fTabBufIdx][u16SrchResult])==c16FBlockInitValue)
        {
            uInvalid=1;
        }
    }

    rmSetSrchDefault;

    return uInvalid;
}    /* chkH2fTabInvalid */

void chkTrimH2fChg(TRIMTOUTINFO *upTOutInfo)
{
    WORD u16H2fWrOpt, u16BufIdx, u16HmbCnt;

    if(mChkCacheInfoChangeFlag(cH2fChg))
    {
        waitHmbPrdDone();

        if(mChkHmbLink(upTOutInfo->u16ActiveH2F))
        {
            remHmbLink(upTOutInfo->u16ActiveH2F);
        }

#if _EN_VPC_SWAP
        // prevent cache info program before VPC update
        if(gsCacheInfo.u16H2fTabFreePagePtr==(gsCacheInfo.u16H2fTabPagePerBlk3-1))
        {
            mSetGcFlag(cGcSkipPrgCacheInfo);
        }
#endif

        if(chkH2fTabInvalid(upTOutInfo))
        {
            progH2fTableCore0(upTOutInfo->u32TrimH2fTabBufIdx,
                              upTOutInfo->u16ActiveH2F|c16DropH2fTab,
                              c16Bit0|c16Bit1|c16Bit2|c16Bit15,
                              cInchkTrimH2fChg_00,
                              0);
        }
        else
        {
            u16H2fWrOpt=c16Bit0|c16Bit2|c16Bit15;

            if((!gsHmbInfo.uHmbEnable)||(gsHmbInfo.usHmbList.u16Cnt>=g16HmbMaxTableNum))
            {
                u16H2fWrOpt|=c16Bit1;
            }

            progH2fTableCore0(upTOutInfo->u32TrimH2fTabBufIdx, upTOutInfo->u16ActiveH2F, u16H2fWrOpt, cInchkTrimH2fChg_01, 0);
#if _EN_HMB
            if(gsHmbInfo.uHmbEnable&&(gsHmbInfo.usHmbList.u16Cnt<g16HmbMaxTableNum))
            {
                writeHmbH2fTab(upTOutInfo->u32TrimH2fTabBufIdx, upTOutInfo->u16ActiveH2F, c16Bit1);
            }
#endif
        }

        upTOutInfo->u16ActiveH2F=c16H2FTabInitValue;
    }
    else if(upTOutInfo->u16ActiveH2F!=c16H2FTabInitValue)
    {
        // remove buffer flag
        u16BufIdx=upTOutInfo->u32TrimH2fTabBufIdx>>5;
#if _EN_RAID_H2F
        u16HmbCnt=(g16H2fTabValidSctrSize>>5);
#else
        u16HmbCnt=(g16H2fTabSctrSize>>5);
#endif

        while(u16HmbCnt)
        {
            if(rm32BufStatus(u16BufIdx)==0xFFFFFFFF)
            {
                rmSetBuf32Sts(u16BufIdx, 0xFFFFFFFF);    // 64k alignment
                u16BufIdx++;
                u16HmbCnt--;
            }
        }

        upTOutInfo->u16ActiveH2F=c16H2FTabInitValue;
    }
}    /* chkTrimH2fChg */

BYTE chkEmptyHBlk(WORD u16HBlock)
{
    if((g16arH2fTabPtr[u16HBlock]!=0xFFFF)||mChkSrcInCache(u16HBlock))
    {
        return cFalse;
    }
    else
    {
        return cTrue;
    }
}

BYTE chkTrimHblockChg(WORD u16HBlock, TRIMTOUTINFO *upTOutInfo)
{
    if(chkEmptyHBlk(u16HBlock))
    {
        return cTrue;
    }
    else
    {
        chkTrimH2fChg(upTOutInfo);
        waitHmbPrdDone();

#if _EN_VPC_SWAP
        if((g16PushSpareCnt>(c16MaxPushSprbNum*3/4))||mChkGcFlag(cGcSkipPrgCacheInfo))
        {
            progWproPageCore0(cWproCacheBlkVpCnt, g16VPCTrimStartIdx);
        }

        if(mChkGcFlag(cGcSkipPrgCacheInfo))    // gsCacheInfo.ubSkipPrgCacheInfo)
        {
#if ((!_PRJ_BOOT)||_ICE_LOAD_ALL)
            mClrCacheInfoChangeFlag(cH2fChg);    // gsCacheInfo.ubH2fChg=0;
            waitAllChCeBzCore0();

            progCacheInfoTab();
#endif
            mClrGcFlag(cGcSkipPrgCacheInfo);    // gsCacheInfo.ubSkipPrgCacheInfo=0;
        }
#endif/* if _EN_VPC_SWAP */

        if((g16PushSpareCnt>(c16MaxPushSprbNum*3/4))||(gsCacheInfo.u16SpareBlockCnt<g16TLCGCSpareCnt_Ori))
        {
            if((gsCacheInfo.u16SpareBlockCnt<g16TLCGCSpareCnt_Ori)&&g16PushSpareCnt)
            {
                NLOG(cLogHost, TRIMCMD_C, 1, "Emergency chkTrimHblockChg g16PushSpareCnt =0x%04X", g16PushSpareCnt);
            }

            chkPushSpareQCore0(0);
        }

        swapH2fTable(u16HBlock, upTOutInfo->u32TrimH2fTabBufIdx, cWaitReadDone|cSetBufferFlag);
        upTOutInfo->u16ActiveH2F=u16HBlock;

        if(mChkSrcInCache(u16HBlock))
        {
            popCacheF2hTab(u16HBlock, upTOutInfo);
            mSetCacheInfoChangeFlag(cH2fChg);
        }

        return cFalse;
    }
}    /* chkTrimHblockChg */

void trim4k(WORD u16EntryPtr, TRIMTOUTINFO *upTOutInfo, BYTE uOpCode)
{
    BYTE uTmpTrimSctrCnt, uEmptyHlk;
    LWORD u32TrimLBA, u32TrimSctrCnt, u32DiffValue;
    UCLWORD *u32pH2FStTab=(UCLWORD *)g32arTsb0[upTOutInfo->u32TrimH2fTabBufIdx], *u32pH2FTab;
    WORD u16TotalValid4kInH2f=g32SectorPerBlockH>>cSctrTo4kShift, u16FBlock;

    u32TrimLBA=g32arTsb0[upTOutInfo->u32TrimLbaInfoBufIdx][u16EntryPtr];    // upTrimInfo->u64StartLba;
    u32TrimSctrCnt=g32arTsb0[upTOutInfo->u32TrimLbaInfoBufIdx+4][u16EntryPtr];    // upTrimInfo->u32Length;
#if _EN_WriteZeroNonAlign    // WriteZeroNonAlign_20181031_Chief
    if(((uOpCode==cNvmeCmdWriteZero))&&(gsWZCnt<C_MaxNonAlginCnt)&&    // (uOpCode==cNvmeCmdDataSetMgm)||
       ((u32TrimLBA&(cSctrPer4k-1))||((u32TrimLBA+u32TrimSctrCnt)&(cSctrPer4k-1))))
    {
        LWORD u32TrimLBAend=u32TrimLBA+u32TrimSctrCnt-1;
        LWORD u32LAAs=u32TrimLBA>>3;
        LWORD u32LAAe=u32TrimLBAend>>3;

        NLOG(cLogHost, TRIMCMD_C, 3, " NVMe WZERO Cmd u32TrimLBA=0x%08X, u32TrimSctrCnt=0x%04X", u32TrimLBA>>16, u32TrimLBA, u32TrimSctrCnt);

        if(u32TrimLBA&(cSctrPer4k-1)||(!(u32TrimLBA&cSctrPer4k-1))&&(u32TrimSctrCnt<cSctrPer4k))
        {
            gsWZInfo[gsWZCnt].u32LBA=u32TrimLBA;

            if(u32TrimSctrCnt<=(cSctrPer4k-(u32TrimLBA&(cSctrPer4k-1))))    // ONE LAA
            {
                gsWZInfo[gsWZCnt].uSCnt=u32TrimSctrCnt;
            }
            else
            {
                gsWZInfo[gsWZCnt].uSCnt=cSctrPer4k-u32TrimLBA&(cSctrPer4k-1);    // Over One LAA
            }

            NLOG(cLogHost,
                 TRIMCMD_C,
                 3,
                 " First u32TrimLBA=0x%08X, uSCnt=0x%04X",
                 gsWZInfo[gsWZCnt].u32LBA>>16,
                 gsWZInfo[gsWZCnt].u32LBA,
                 gsWZInfo[gsWZCnt].uSCnt);
            gsWZCnt++;
        }

        if((u32TrimLBAend+1)&(cSctrPer4k-1)&&(u32LAAs!=u32LAAe))
        {
            gsWZInfo[gsWZCnt].u32LBA=u32LAAe<<cSctrTo4kShift;
            gsWZInfo[gsWZCnt].uSCnt=(u32TrimLBAend&(cSctrPer4k-1))+1;
            NLOG(cLogHost,
                 TRIMCMD_C,
                 3,
                 " Second u32TrimLBA=0x%08X, uSCnt=0x%04X",
                 gsWZInfo[gsWZCnt].u32LBA>>16,
                 gsWZInfo[gsWZCnt].u32LBA,
                 gsWZInfo[gsWZCnt].uSCnt);

            gsWZCnt++;
        }
    }
#endif/* if _EN_WriteZeroNonAlign */

    if(u32TrimSctrCnt<cSctrPer4k)
    {
        // if(uType==cNvmeCmdWriteZero)
        // {
        //    u32TrimSctrCnt=cSctrPer4k;
        // }
        // else
#if (C_Log_SaveMask&C_Debug_P2)    // 20181031_Oscar
        NLOG(cLogHost, TRIMCMD_C, 0, " Not enough 4K ");
#endif
        {
            return;
        }
    }

    uTmpTrimSctrCnt=cSctrPer4k-(u32TrimLBA&(cSctrPer4k-1));    // mod(u32TrimLBA, cSctrPer4k);

    if(uTmpTrimSctrCnt!=cSctrPer4k)    /*not 4k align*/
    {
        u32TrimLBA+=uTmpTrimSctrCnt;

        if(u32TrimSctrCnt>=uTmpTrimSctrCnt)
        {
            u32TrimSctrCnt-=(WORD)uTmpTrimSctrCnt;
#if (C_Log_SaveMask&C_Debug_P2)    // 20181031_Oscar
            NLOG(cLogHost,
                 TRIMCMD_C,
                 4,
                 " LBA = 0x%08X align 4K , u32TrimSctrCnt = 0x%04X, uTmpTrimSctrCnt = 0x%04X",
                 u32TrimLBA>>16,
                 u32TrimLBA,
                 u32TrimSctrCnt,
                 uTmpTrimSctrCnt);
#endif
        }
        else
        {
            return;    // u32TrimSctrCnt=0;
        }
    }

#if _ENABLE_SECAPI
    // Security code can't release all TSB0 now. Previous handleSecTrim() has called.
    if(uOpCode!=cNvmeCmdSecuritySend)
#endif
    {
        save1stCacheInfoBefW();
    }

    tranLba2HAddr(u32TrimLBA, &gsWriteHAddrInfo);

    // (T) SwapH2f first here and check cache in F2h
    if((upTOutInfo->u16ActiveH2F!=g16HBlock))
    {
        uEmptyHlk=chkTrimHblockChg(g16HBlock, upTOutInfo);
    }
    else
    {
        uEmptyHlk=(chkEmptyHBlk(g16HBlock)&&(!mChkCacheInfoChangeFlag(cH2fChg)));
    }

    u32pH2FTab=u32pH2FStTab+g16HPage;

    while((u32TrimSctrCnt>=cSctrPer4k)&&(chkTimeOut(upTOutInfo)==cFalse))
    {
        if(g16HPage==u16TotalValid4kInH2f)
        {
            g16HBlock++;
            g16HPage=0;
            uEmptyHlk=chkTrimHblockChg(g16HBlock, upTOutInfo);
            u32pH2FTab=u32pH2FStTab;
        }

        if(g16PushSpareCnt>=(c16MaxPushSprbNum-1))
        {
            uEmptyHlk=chkTrimHblockChg(g16HBlock, upTOutInfo);
        }

        if(uEmptyHlk)
        {
            u32DiffValue=(((LWORD)(u16TotalValid4kInH2f-g16HPage))*cSctrPer4k);

            if(u32TrimSctrCnt>u32DiffValue)
            {
                g16HPage=u16TotalValid4kInH2f;
                u32TrimSctrCnt-=u32DiffValue;
            }
            else
            {
                u32TrimSctrCnt=0;
            }
        }
        else
        {
            // setH2fSrcPageInvalid(u32pH2FTab);
            u16FBlock=mGetSrcFBlkAddr((*u32pH2FTab));

            if(u16FBlock!=c16FBlockInitValue)
            {
                while(!mGetCacheBlkVpCnt(u16FBlock))
                    ;

                g32arCacheBlkVpCnt[u16FBlock]--;
                mDecTotalVpc(u16FBlock);

                if(!mGetCacheBlkVpCnt(u16FBlock))
                {
                    setZeroVpcBlock(u16FBlock);
                }

                *u32pH2FTab=(UCLWORD)(c16FBlockInitValue<<c32SrcFPageAddrBitNum)|c32SrcFPageAddrMask;

                // if(!mChkCacheInfoChangeFlag(cH2fChg))
                // {
                mSetCacheInfoChangeFlag(cH2fChg);
                // }
            }

            u32TrimSctrCnt-=(WORD)cSctrPer4k;
            g16HPage++;
            u32pH2FTab++;
        }
    }
}    /* trim4k */

/*
   * void setH2fSrcPageInvalid(UCLWORD *u32pH2FTab)    // _Uncached H2FTABLE *upH2fTab)
   * {
   *  WORD u16FBlock=mGetSrcFBlkAddr((*u32pH2FTab));
   *
   *  if(u16FBlock!=c16FBlockInitValue)
   *  {
   *      while(!mGetCacheBlkVpCnt(u16FBlock))
   *          ;
   *
   *      g32arCacheBlkVpCnt[u16FBlock]--;
   *      mDecTotalVpc(u16FBlock);
   *
   *      if(!mGetCacheBlkVpCnt(u16FBlock))
   *      {
   *          setZeroVpcBlock(u16FBlock);
   *      }
   *  }
   *
   *  // *u32pH2FTab=0x3FFF_FFFF;
   * u32pH2FTab=(UCLWORD)(c16FBlockInitValue<<c32SrcFPageAddrBitNum)|c32SrcFPageAddrMask;
   *
   *  if(!mChkCacheInfoChangeFlag(cH2fChg))
   *  {
   *      mSetCacheInfoChangeFlag(cH2fChg);    // gsCacheInfo.ubH2fChg=1;
   *  }
   * }
   */

#endif/* if (_PRJ_ISP||_PRJ_NVME) */

#if _PRJ_ISP
void nvmeDataSetManagemaent()
{
    LWORD u32NsId=rmNvmeNsId;

    NLOG(cLogHost, TRIMCMD_C, 2, " NVMe Trim Cmd NSID=%08x ", (WORD)(u32NsId>>16), (WORD)(u32NsId));

    if(gsLightSwitch.usNvmeLs.uOncs&cDatasetManagementCommand)
    {
        // if((u32NsId==cNamespaceNotSpecific)||(!(gsNamespace.uActiveBitMap&cbBitTab[(BYTE)((u32NsId-1)&0x00000007)])))
        // if((u32NsId==cNamespaceNotSpecific)||(u32NsId>gsLightSwitch.usNvme2Ls.u32NamespaceNum)||(!(gsNamespace.uActiveBitMap&cbBitTab[(BYTE)((u32NsId-1)&0x00000007)])))
        //  //tnvme 12:0.1.0
        if((u32NsId==cNamespaceNotSpecific)||(u32NsId>gsLightSwitch.usNvme2Ls.u32NamespaceNum)||
           (!(gsNamespace.uActiveBitMap&cbBitTab[u32NsId-1])))    //
                                                                  // tnvme
                                                                  // 12:0.1.0
        {
            NLOG(cLogHost, TRIMCMD_C, 2, " DataSetManagemaent Invaild Ns Format : 0x%08X", u32NsId>>16, u32NsId);
            manualCompletion(cStatusInvalidNsFormat, 0, cNoRwCmd, 0);
        }
        // Mark for WD Jira-63
        // else if((!rmNvmeAttributeAd)||(rmNvmeAttributeIdr)||(rmNvmeAttributeIdw))    // not trim or invalid command
        // {
        //    manualCompletion(cStatusConflictAttrb, 0, cNoRwCmd, 0);
        // }
        else
        {
            if(rmNvmeAttributeAd)
            {
                bopClrRam((LWORD)g32arTsb0[0], 32*0x200, 0xFFFFFFFF, cBopWait|cClrTsb);
                enableLdpcPipe();
                processTrim(cNvmeCmdDataSetMgm);
                disableLdpcPipe();
            }
            else
            {
                NLOG(cLogHost, TRIMCMD_C, 0, " Non Deallocate Attribute");
                manualCompletion(cStatusSuccess, 0, cNoRwCmd, 0);
            }
        }
    }
    else
    {
        NLOG(cLogHost, TRIMCMD_C, 0, " Not Support DataSetManagemaent");
        manualCompletion(cStatusInvalidOpCode, 0, cNoRwCmd, 0);
    }
}    /* nvmeDataSetManagemaent */

#endif/* if _PRJ_ISP */

void processTrim(BYTE uOpCode)
{
#if (_PRJ_ISP||_PRJ_NVME)
    WORD u16EntryCnt, u16CommandStatus;
    LWORD u32HostXfrCnt;
    TRIMTOUTINFO usTrimTOutInfo;
#if _EN_VPC_SWAP
    LWORD u32CacheBlkVpCntStrAddr;
#endif

#if _ENABLE_SECAPI
#if _EN_VPC_SWAP
#if _PRJ_ISP
    if(gInSecApi)
    {
        backupRwBufferForSecApi(1);         // TSB0 backup
    }
#endif
#endif

    if(uOpCode==cNvmeCmdSecuritySend)
    {
        // usTrimTOutInfo.u32TrimSourceEntryAddr=c32TsbTempCrcAddr;
        // usTrimTOutInfo.u32TrimLbaInfoBufIdx=c16TsbTempCrcIdx;
        usTrimTOutInfo.u32TrimSourceEntryAddr=(LWORD)(&gCrcDataBuffer[0]);
        usTrimTOutInfo.u32TrimLbaInfoBufIdx=(LWORD)(((LWORD)&gCrcDataBuffer[0]-c32Tsb0SAddr)>>9);
        usTrimTOutInfo.u32TrimH2fTabBufIdx=cTsb0StartBufIdx;
#if _EN_VPC_SWAP
        // security command will set no swap wpro
        u32CacheBlkVpCntStrAddr=cCacheBlkVpCntSecuritySendStrAddr;
        g16VPCTrimStartIdx=cCacheBlkVpCntSecuritySendStrIdx;
#endif
    }
    else
#endif /* if _ENABLE_SECAPI */
    {
        usTrimTOutInfo.u32TrimSourceEntryAddr=c32Tsb0SAddr;
        usTrimTOutInfo.u32TrimLbaInfoBufIdx=cTrimLBAInfoStBuf;
        usTrimTOutInfo.u32TrimH2fTabBufIdx=c16TrimH2fTabStBuf;
#if _EN_VPC_SWAP
        // prevent swap WPRO
        u32CacheBlkVpCntStrAddr=cCacheBlkVpCntTrimStrAddr;
        g16VPCTrimStartIdx=cCacheBlkVpCntTrimStrIdx;
#endif
    }

#if _ENABLE_SECAPI_W_DEBUG
    NLOG(cLogSecApiDebug, TRIMCMD_C, 4,
         "  processTrim() - Security Trim, u32TrimSourceEntryAddr = 0x%08X, u32TrimLbaInfoBufIdx = 0x%04X, u32TrimH2fTabBufIdx = 0x%04X",
         usTrimTOutInfo.u32TrimSourceEntryAddr>>16,
         (WORD)usTrimTOutInfo.u32TrimSourceEntryAddr,
         (WORD)usTrimTOutInfo.u32TrimLbaInfoBufIdx,
         (WORD)usTrimTOutInfo.u32TrimH2fTabBufIdx);
#endif

#if _ENABLE_HMB_FLUSH
    BYTE uSgmtIdx;
#endif

    usTrimTOutInfo.u16ActiveH2F=c16H2FTabInitValue;

    if(uOpCode==cNvmeCmdDataSetMgm)
    {
        u16EntryCnt=rmNvmeTrimRangeCnt;    // the number of 16 byte range sets, zero based value, Maximum 256 ranges
        u32HostXfrCnt=(((u16EntryCnt<<4)+511)>>9);    // sector based
        trigNonRWCmd(cTsb0StartBufIdx, u32HostXfrCnt, cTsb0, cNvmeWrite, cManualCq);
#if _EN_Lenovo_RecoveryChk
        if((gsGcInfo.u32TotalSlcVpc+gsGcInfo.u32TotalTlcVpc)<25600)    // 100 MB
        {
            InitIoMeter_RecoveryChk();
            NLOG(cLogHost, TRIMCMD_C, 0, " IOMeter_RecoveryChk Not enough 100M in Trim cmd");
        }
#endif
    }
    else if(uOpCode==cNvmeCmdWriteZero)
    {
        u16EntryCnt=1;
        g32arTsb0[0][1]=rmNvmeWriteZerosNlb;
        g32arTsb0[0][2]=rmNvmeWriteZerosSLbaLow;
        g32arTsb0[0][3]=rmNvmeWriteZerosSLbaHigh;
    }
    else if(uOpCode==cNvmeCmdNamespaceManagement)
    {
#if _EN_E2ENonCRCChk    // Oscar_20190220
        if(gsWUNCInfo.uWZeroFlag)
        {
            gsWUNCInfo.uWZeroFlag=0;
            bopCopyRam(((LWORD)garTsb0[0]), (LWORD)&gsWUNCInfo, sizeof(gsWUNCInfo),
                       cCopyStcm2Tsb|cBopWait);
            progWproPageCore0(cWproWriteUNC, c16Tsb0SIdx);
        }
#endif
        u16EntryCnt=1;
        g32arTsb0[0][1]=gsNamespace.usInfo[rmNvmeNsId-1].u32Size;
        g32arTsb0[0][2]=gsNamespace.usInfo[rmNvmeNsId-1].u32StartLba;
        g32arTsb0[0][3]=0;
    }
    else if(uOpCode==cNvmeCmdSanitize)
    {
#if _EN_E2ENonCRCChk    // Oscar_20190220
        if(gsWUNCInfo.uWZeroFlag)
        {
            gsWUNCInfo.uWZeroFlag=0;
            bopCopyRam(((LWORD)garTsb0[0]), (LWORD)&gsWUNCInfo, sizeof(gsWUNCInfo),
                       cCopyStcm2Tsb|cBopWait);
            progWproPageCore0(cWproWriteUNC, c16Tsb0SIdx);
        }
#endif
        u16EntryCnt=1;
        g32arTsb0[0][1]=g32HostTotalDataSectorCnt;
        g32arTsb0[0][2]=0;
        g32arTsb0[0][3]=0;
    }

    if(mNvmeChkNssr||mPcieChkPerst||mPcieChkRst||mPcieChkFlr||mNvmeChkRst)
    {
        return;
    }

#if _ENABLE_SECAPI
    else if(uOpCode==cNvmeCmdSecuritySend)
    {
        // cNvmeCmdSecuritySend : call in Security code.
        // cNvmeCmdSecurityRecv : call in non-Security code.
#if _ENABLE_SECAPI_W_DEBUG
        TRIMINFO *upTrimInfo=(TRIMINFO *)usTrimTOutInfo.u32TrimSourceEntryAddr;
        NLOG(cLogSecApiDebug, TRIMCMD_C, 1,
             "  processTrim() - Security Trim, TotalCnt = 0x%04X", g16SecTrimPtr);
        NLOG(cLogSecApiDebug, TRIMCMD_C, 4,
             "  processTrim() - Security Trim, LBA = 0x%08X , XfrCnt = 0x%08X",
             (WORD)(upTrimInfo->u64StartLba>>16),
             (WORD)upTrimInfo->u64StartLba,
             (WORD)(upTrimInfo->u32Length>>16),
             (WORD)upTrimInfo->u32Length);
#endif

        u16EntryCnt=g16SecTrimPtr;
        g16SecTrimPtr=0;
    }
#endif/* if _ENABLE_SECAPI */

    u16CommandStatus=chkAllEntryValid(&u16EntryCnt, &usTrimTOutInfo, uOpCode);

#if _ENABLE_SECAPI_W_DEBUG
    NLOG(cLogSecApiDebug, TRIMCMD_C, 1,
         "  processTrim() - Security Trim, u16EntryCnt = 0x%04X", u16EntryCnt);
#endif

#if _ENABLE_SECAPI
    if((uOpCode==cNvmeCmdSecuritySend)&&(!u16CommandStatus))
    {
        bopCopyRam((LWORD)g32arTsb0[usTrimTOutInfo.u32TrimLbaInfoBufIdx],
                   (LWORD)g32arTsb0[cTrimLBAInfoStBuf],
                   u16EntryCnt*4,
                   cCopyTsb2Tsb|cBopWait);
        bopCopyRam((LWORD)g32arTsb0[usTrimTOutInfo.u32TrimLbaInfoBufIdx+4],
                   (LWORD)g32arTsb0[cTrimLenInfoStBuf],
                   u16EntryCnt*4,
                   cCopyTsb2Tsb|cBopWait);
    }
#endif

    if(!u16CommandStatus)
    {
        prog1stInvQBootInWpro();
#if _ENABLE_TRIM
        WORD u16EntryPtr=0;
#if _EN_TRIM_TIMEOUT
        disSysTmr();
        enSysTmr(cPartialCleanTmer100ms);    // use 100ms timer for Trim command

        usTrimTOutInfo.uTotalTOutUnitCnt=div(usTrimTOutInfo.u16TotalValidEntryCnt+cTrimEntriesPerSector-1, cTrimEntriesPerSector);
        usTrimTOutInfo.uTotalTOutUnitCnt*=cTrimTOutUnitCntPerSector;
        usTrimTOutInfo.uNowToutUnitCnt=1;
#endif

#if _ENABLE_HMB_FLUSH
        for(uSgmtIdx=0; uSgmtIdx<cMaxRH2fTabNum; uSgmtIdx++)
        {
            if(mChkRH2fTabDirty(uSgmtIdx))
            {
                modifyHmbByH2f1kTab(uSgmtIdx);
            }
        }
#endif

#if _EN_VPC_SWAP
        g32arCacheBlkVpCnt=(volatile LWORD *)(u32CacheBlkVpCntStrAddr);
        readWproPageCore0(cWproCacheBlkVpCnt, g16VPCTrimStartIdx, 0);
#endif

        while((u16EntryPtr<u16EntryCnt)&&(chkTimeOut(&usTrimTOutInfo)==cFalse))
        {
            trim4k(u16EntryPtr, &usTrimTOutInfo, uOpCode);
            u16EntryPtr++;
        }

        chkTrimH2fChg(&usTrimTOutInfo);
        rstH2F1KInfo();
        waitHmbPrdDone();

#if _EN_VPC_SWAP
        progWproPageCore0(cWproCacheBlkVpCnt, g16VPCTrimStartIdx);

        if(mChkGcFlag(cGcSkipPrgCacheInfo))    // gsCacheInfo.ubSkipPrgCacheInfo)
        {
#if ((!_PRJ_BOOT)||_ICE_LOAD_ALL)
            mClrCacheInfoChangeFlag(cH2fChg);    // gsCacheInfo.ubH2fChg=0;
            waitAllChCeBzCore0();

            progCacheInfoTab();
#endif
            mClrGcFlag(cGcSkipPrgCacheInfo);    // gsCacheInfo.ubSkipPrgCacheInfo=0;
        }
#endif/* if _EN_VPC_SWAP */

        if((mChkGcQue(cGcTypH2fTab))||mChkGcFlag(cReadScrubH2F))
        {
            // rmRtc32kReset;
            g32Rtc32kStartVal=getRtcCurrent32k();
#if _EN_TRIM_TIMEOUT
            // gsGcInfo.u32BgdGcEndTime=rmGetRtc32kTick+c32PartialCleanRtc20ms;
            gsGcInfo.u32BgdGcEndTime=c32PartialCleanRtc20ms;
#else
            // gsGcInfo.u32BgdGcEndTime=rmGetRtc32kTick+c32PartialCleanRtc200ms;
            gsGcInfo.u32BgdGcEndTime=c32PartialCleanRtc200ms;
#endif

#if (_ENABLE_SECAPI&&_PRJ_ISP&&(!_EN_VPC_SWAP))
// Here is just for ISP code. NVMe code bank is avoided.
            if(gInSecApi)
            {
                backupRwBufferForSecApi(1);    // TSB0 backup
            }
#endif
            bgdClnH2fTabblkProc();

#if (_ENABLE_SECAPI&&_PRJ_ISP&&(!_EN_VPC_SWAP))
// Here is just for ISP code. NVMe code bank is avoided.
            if(gInSecApi)
            {
                backupRwBufferForSecApi(0);    // TSB0 restore
            }
#endif
        }

        if(g16PushSpareCnt>gsGcInfo.uPushSprbHiThr)
        {
            chkPushSpareQCore0(0);
        }

        if((!gsGcInfo.u32TotalSlcVpc)&&(!gsGcInfo.u32TotalTlcVpc))    // (uOpCode==cNvmeCmdFormat) 20190109_Louis
        {
            NLOG(cLogHost, TRIMCMD_C, 0, "SLC&TLC Vpc = 0, Save CahceInfoTable!");
            progCacheInfoTab();
        }

#if _EN_TRIM_TIMEOUT
        disSysTmr();
#endif
#endif/* if 0 */

        if((uOpCode==cNvmeCmdDataSetMgm)||(uOpCode==cNvmeCmdWriteZero))
        {
#if _EN_WriteZeroNonAlign    // WUNCTable Chief_21081121
            if(!gsWZCnt)
#endif
            manualCompletion(cStatusSuccess, 0, cNoRwCmd, 0);
#if WZ_debug
            NLOG(cLogHost,
                 TRIMCMD_C,
                 3,
                 " cNvmeCmdWriteZero g16HBlock=0x%04X, g16arH2fTabPtr=0x%04X, g16arH2fTabBlk=0x%04X",
                 g16HBlock,
                 g16arH2fTabPtr[g16HBlock],
                 g16arH2fTabBlk[g16HBlock]);
#endif
        }
    }
    else
    {
        if((uOpCode==cNvmeCmdDataSetMgm)||(uOpCode==cNvmeCmdWriteZero))
        {
            manualCompletion(u16CommandStatus, 0, cNoRwCmd, 0);
        }
    }

    NLOG(cLogHost, TRIMCMD_C, 0, "ProcessTrim () End!");

#if _EN_VPC_SWAP
#if (_ENABLE_SECAPI&&_PRJ_ISP)
    // Here is just for ISP code. NVMe code bank is avoided.
    if(gInSecApi)
    {
        backupRwBufferForSecApi(0);            // TSB0 restore
    }
#endif
#endif

#if _ENABLE_SECAPI_W_DEBUG
    NLOG(cLogSecApiDebug, TRIMCMD_C, 0, "  processTrim() - Security Trim, end");
#endif
#else/* if _PRJ_ISP */
    while(1)
        ;
#endif/* if _PRJ_ISP */
}    /* processTrim */







