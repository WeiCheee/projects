







#include "inc/ProType.h"
#include "common/ID.h"
#include "common/Model.h"

// ***************************** Main Tag *****************************/

// ======= FW Date Code ============
//                "012345"
#define DtCode    "S0128B"

// ========== Main Tag =============
//                       6789ABCDEF
#if (_TSB_BiCS3)
#define cTagMain        "3 01 BiCS3"
#elif (_SANDISK_3D_GEN2)
#define cTagMain        "3 00 BiCS2"
#elif (_SANDISK_3D_GEN3)
#define cTagMain        "3 02 BiCS3"
#elif (_TSB_BiCS4)
#define cTagMain        "5 00 BiCS4"
#else
#define cTagMain        "0 00  UNKN"
#endif

// ========== Other Tag ============
//                       6789ABCDEF
#define cTagIceCore1    " ICE CORE1"
#define cTagIceIsp      " ICE ISP  "
#define cTagCore1       " CORE1    "
#define cTagGreyBox     " GreyBox  "
#define cTagIsp         " ISP      "
#define cTagBoot        " BOOT     "
#define cTagBoot1       " BOOT1    "
#define cTagBoot2       " BOOT2    "
#define cTagNvme        " NVME     "
#define cTagSmiVu       " SMIVU    "
#define cTagHyVu        " HYXVU    "
#define cTagSec         " SEC      "
#define cTagTcg         " TCG      "
#define cTagErrHdl      " ERRHDL   "

#define cMainTag        DtCode cTagMain
#define cIceCore1Tag    DtCode cTagIceCore1
#define cIceIspTag      DtCode cTagIceIsp
#define cCore1Tag       DtCode cTagCore1
#define cISPC1Tag       DtCode cTagIsp
#define cBootC1Tag      DtCode cTagBoot
#define cNvmeC1Tag      DtCode cTagNvme
#define cVUC1Tag        DtCode cTagSmiVu
#define cErrHdlC1Tag    DtCode cTagErrHdl
#define cGreyBoxTag     DtCode cTagGreyBox
#define cIspTag         DtCode cTagIsp
#define cBootTag1       DtCode cTagBoot1
#define cBootTag2       DtCode cTagBoot2
#define cNvmeTag        DtCode cTagNvme
#define cSmiVuTag       DtCode cTagSmiVu
#define cHyVuTag        DtCode cTagHyVu
#define cSecTag         DtCode cTagSec
#define cTcgTag         DtCode cTagTcg

#if (_ICE_LOAD_ALL)

#if _CPUID
#if _PRJ_ISPC1
__root CBYTE cbMainTag[16] @ ".ISP_TAG"=
{
    cISPC1Tag
};
#elif _PRJ_BOOTC1
__root CBYTE cbMainTag[16] @ ".ISP_TAG"=
{
    cBootC1Tag
};
#elif _PRJ_NVMEC1
__root CBYTE cbMainTag[16] @ ".ISP_TAG"=
{
    cNvmeC1Tag
};
#elif _PRJ_SMIVUC1
__root CBYTE cbMainTag[16] @ ".ISP_TAG"=
{
    cVUC1Tag
};
#elif _PRJ_ERRHDLC1
__root CBYTE cbMainTag[16] @ ".ISP_TAG"=
{
    cErrHdlC1Tag
};
#endif/* if _PRJ_ISPC1 */
#else/* if _CPUID */
__root CBYTE cbMainTag[16] @ ".ISP_TAG"=
{
    cIceIspTag
};
#endif/* if _CPUID */

#else/* if (_ICE_LOAD_ALL) */

#if _CPUID
__root CBYTE cbMainTag[16] @ ".MAIN_TAG"=
{
    cCore1Tag
};
#else
__root CBYTE cbMainTag[16] @ ".MAIN_TAG"=
{
#if (_GREYBOX)||(_INITDRAM)
    cGreyBoxTag
#else
    cMainTag
#endif
};
// ---SSDBIN Binary Info-----
// 0x0 ~ 0x0F
__root CBYTE cbHeader[16] @ ".BinaryInfo"=
{'S', 's', 'd', 'B', 'i', 'n', 'T', 'a', 'g', 'N', 'V', 'M', 'e', ' ', ' ', SUBVERSION};
// 0x10~0x37
__root CBYTE cbModelname2[40] @ ".BinaryInfo"=
{MODELNO};
// 0x38-0x3F
__root CBYTE cbRevision1[8] @ ".BinaryInfo"=
{FV_INQ};
// 0x40-0x47
__root CBYTE cbRevision2[8] @ ".BinaryInfo"=
{FV_IDEN};
// 0x48-0x4F
__root CBYTE cbCompamentID[8] @ ".BinaryInfo"=
{0x20, 0x20, 0x20, 0x20, 0x20, 0x20, 0x20, 0x20};
// 0x50-0x53
__root CBYTE cbOEMversion[4] @ ".BinaryInfo"=
{OEM, 0x20, 0x20, 0x20};
// 0x54-0x5F
__root CBYTE cbSupportCapacity[12] @ ".BinaryInfo"=
{'0', 0x20, 0x20, 0x20, 0x20, 0x20, 0x20, 0x20, 0x20, 0x20, 0x20, 0x20};
// 0x60-0x6F
__root CBYTE cbReleaseTime[16] @ ".BinaryInfo"=
{DATETIME};
__root CBYTE cbReserved0[16] @ ".BinaryInfo"=
{0x20, 0x20, 0x20, 0x20, 0x20, 0x20, 0x20, 0x20, 0x20, 0x20, 0x20, 0x20, 0x20, 0x20, 0x20, 0x20};
__root CBYTE cbSecurityVer[8] @ ".BinaryInfo"=
{"SEC01   "};    //
#ifdef TCG_SUPPORT
__root CBYTE cbTCGTag[8] @ ".BinaryInfo"=
{"TCG    "};    //
#endif
// ---SSDBIN Binary Info-----

#endif/* if _CPUID */

#if _PRJ_ISP
__root CBYTE cbIspTag[16] @ ".ISP_TAG"=
{
    cIspTag
};
#endif

#if _PRJ_BOOT1
__root CBYTE cbBootTag[16] @ ".BOOT_TAG"=
{
    cBootTag1
};
#endif

#if _PRJ_BOOT2
__root CBYTE cbBootTag[16] @ ".BOOT_TAG"=
{
    cBootTag2
};
#endif

#if _PRJ_NVME
__root CBYTE cbNvmeTag[16] @ ".NVME_TAG"=
{
    cNvmeTag
};
#endif

#if _PRJ_SMIVU
// __root CBYTE cbNvmeTag[16] @ ".SMIVU_TAG"=
__root CBYTE cbNvmeTag[16] @ ".SMIVU_TAG"=
{
    cSmiVuTag
};
#endif
#endif/* if (_ICE_LOAD_ALL) */







