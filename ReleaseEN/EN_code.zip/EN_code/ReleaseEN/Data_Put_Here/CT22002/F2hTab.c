







#include "inc/ProType.h"
// #include "inc/FlashCtrl.h"
#include "inc/GlobVar0.h"
#include "inc/GlobVarS.h"
#include "inc/GlobVarT.h"
#include "inc/Reg.h"
#include "inc/FtlCtrl.h"
#include "inc/Mac.h"

#if _EN_FW_DEBUG_UART
#include "inc/DebugLog.h"
#include "inc/EventLogIDX.h"
#include "inc/EventLogFunctionIDX.h"
#endif

#if (_PRJ_ISP||_PRJ_BOOT||_PRJ_SMIVU)

BYTE sortF2h(SORTF2HTAB *upSortF2hTab, LWORD *u32pCacheF2hTabSt, LWORD *u32pCacheF2hTabPtr, WORD *u16HblkNum)
{
    WORD u16Hblock;

    while(u32pCacheF2hTabSt!=u32pCacheF2hTabPtr)
    {
        u16Hblock=(WORD)((*u32pCacheF2hTabSt)>>16);

        if(!(u16Hblock&c16Bit15)&&!mChkBitMask((upSortF2hTab->uHBlkBitMap[u16Hblock>>3]), u16Hblock&0x7))
        {
            mSetBitMask(upSortF2hTab->uHBlkBitMap[u16Hblock>>3], u16Hblock&0x7);
            upSortF2hTab->u16HBlock[*u16HblkNum]=u16Hblock;
            (*u16HblkNum)++;
            upSortF2hTab->u16HBlockStartOft[*u16HblkNum]=c16CacheF2hSize-1;

#if (!_PRJ_BOOT)
            if((*u16HblkNum)==gsCacheInfo.u16HblkCntInCache)
            {
                return cTrue;
            }
#endif
        }

        u32pCacheF2hTabSt++;
    }

    return cFalse;
}    /* sortF2h */

void initSortF2HBuffer(SORTF2HTAB *upSortF2hTab)
{
#if _EN_FW_DEBUG_UART&DEBUG_Bill_FTL
    WORD u16F2HStartBak;
#endif
    BYTE uIdx, uSgmt, uOverflow, uH2fTabPtr=0, uSortTabInSegNum=cSortOccSegSize/g16H2fTabSctrSize;
    WORD u16BufIdx, u16HblkNum;
    LWORD *u32pCacheF2hTabSt;
    LWORD *u32pCacheF2hTabEnd;
    LWORD *u32pCacheF2hTabMax;

    // upSortF2hTab->u16ValidHBlkNum=0;
    // upSortF2hTab->u16SortTabPtr=0;
    gsCacheInfo.u32FluValidHBlkNum=0;
    gsCacheInfo.u32FluModifidHBlkNum=0;
    gsCacheInfo.u32ModifyH2fPtrHead=0;
    gsCacheInfo.u32ModifyH2fPtrTail=0;

    // upSortF2hTab->u16ModifyTabPtr=0;
    upSortF2hTab->u32LoadHBlkNum=0;
    upSortF2hTab->u32HblkNum=0;
    upSortF2hTab->u32DoneHBlkNum=0;
    upSortF2hTab->u32LoadH2FPtr=0;
    upSortF2hTab->u32TotalSlcVpc=0;
    upSortF2hTab->u32TotalTlcVpc=0;
    upSortF2hTab->u32arCacheBlkVpCnt[0]=0;
    upSortF2hTab->u32arCacheBlkVpCnt[1]=0;
    upSortF2hTab->u32SortH2FTabNum=((cSortOccSegSize/g16H2fTabSctrSize)*(cSortH2FBufSize/cSortOccSegSize));

    for(uSgmt=1; uSgmt<cSortOccSegNum; uSgmt++)
    {
        // if(uSgmt!=upSortF2hTab->uOccBufSgmt)
        // {
        for(uIdx=0; uIdx<uSortTabInSegNum; uIdx++)
        {
            u16BufIdx=(uSgmt<<8)+(g16H2fTabSctrSize*uIdx);
            upSortF2hTab->u32H2fTableAddr[uH2fTabPtr]=c32Tsb0SAddr+(u16BufIdx<<9);
            upSortF2hTab->u16H2fTableBufPtr[uH2fTabPtr]=u16BufIdx;
            uH2fTabPtr++;
        }

        // }
    }

    // upSortF2hTab->uMaxTabInRamNum=upSortF2hTab->u32SortH2FTabNum;

    if((upSortF2hTab->u32SortH2FTabNum*gTotalPlaneOfH2fTab)>gTotalIntlvChPlaneNum)
    {
        // half table number can fill flash. use prog time to sort flash
        upSortF2hTab->u32ProgH2fTabNum=upSortF2hTab->u32SortH2FTabNum>>1;
    }
    else
    {
        // table can program simultaneously
        upSortF2hTab->u32ProgH2fTabNum=upSortF2hTab->u32SortH2FTabNum;
    }

    upSortF2hTab->u16HBlockStartOft[0]=0;    // for first start
    bopClrRam((LWORD)upSortF2hTab->uHBlkBitMap, (c16MaxH2fTabNum/8), 0x00000000, cClrTsb|cBopWait);
    u32pCacheF2hTabSt=(LWORD *)garCacheF2hTab+gsCacheInfo.u16F2HTabFlushStart;
    u32pCacheF2hTabEnd=(LWORD *)garCacheF2hTab+gsCacheInfo.u16F2HTabFlushEnd;

#if _EN_FW_DEBUG_UART&DEBUG_Bill_FTL
    u16F2HStartBak=gsCacheInfo.u16F2HTabFlushStart;
#endif

    if(gsCacheInfo.u16F2HTabFlushStart>gsCacheInfo.u16F2HTabFlushEnd)
    {
        if(!gsCacheInfo.u16F2HTabFlushEnd)
        {
            u32pCacheF2hTabEnd=(LWORD *)garCacheF2hTab+gsCacheInfo.u16TotalPgPerF2hTab;
            uOverflow=cFalse;
        }
        else
        {
            u32pCacheF2hTabMax=(LWORD *)garCacheF2hTab+gsCacheInfo.u16TotalPgPerF2hTab;
            uOverflow=cTrue;
        }
    }
    else
    {
        uOverflow=cFalse;
    }

    u16HblkNum=0;    // upSortF2hTab->u32HblkNum;

    if(uOverflow)
    {
        if(sortF2h(upSortF2hTab, u32pCacheF2hTabSt, u32pCacheF2hTabMax, &u16HblkNum))
        {
            u32pCacheF2hTabEnd=(LWORD *)garCacheF2hTab;
        }
        /*while(u32pCacheF2hTabSt!=u32pCacheF2hTabMax)
           * {
           *  u16Hblock=(WORD)((*u32pCacheF2hTabSt)>>16);
           *
           *  if(!(u16Hblock&c16Bit15)&&!mChkBitMask((upSortF2hTab->uHBlkBitMap[u16Hblock>>3]), u16Hblock&0x7))
           *  {
           *      mSetBitMask(upSortF2hTab->uHBlkBitMap[u16Hblock>>3], u16Hblock&0x7);
           *      upSortF2hTab->u16HBlock[u16HblkNum]=u16Hblock;
           *      u16HblkNum++;
           *      upSortF2hTab->u16HBlockStartOft[u16HblkNum]=c16CacheF2hSize-1;
           *
           *      if(u16HblkNum==gsCacheInfo.u16HblkCntInCache)
           *      {
           *          u32pCacheF2hTabEnd=(LWORD *)garCacheF2hTab;
           *          break;
           *      }
           *  }
           *
           *  u32pCacheF2hTabSt++;
           * }*/
        else
        {
            u32pCacheF2hTabSt=(LWORD *)garCacheF2hTab;
            sortF2h(upSortF2hTab, u32pCacheF2hTabSt, u32pCacheF2hTabEnd, &u16HblkNum);
        }

        /*while(u32pCacheF2hTabSt!=u32pCacheF2hTabEnd)
           * {
           *  u16Hblock=(WORD)((*u32pCacheF2hTabSt)>>16);
           *
           *  if(!(u16Hblock&c16Bit15)&&!mChkBitMask((upSortF2hTab->uHBlkBitMap[u16Hblock>>3]), u16Hblock&0x7))
           *  {
           *      mSetBitMask(upSortF2hTab->uHBlkBitMap[u16Hblock>>3], u16Hblock&0x7);
           *      upSortF2hTab->u16HBlock[u16HblkNum]=u16Hblock;
           *      u16HblkNum++;
           *      upSortF2hTab->u16HBlockStartOft[u16HblkNum]=c16CacheF2hSize-1;
           *
           *      if(u16HblkNum==gsCacheInfo.u16HblkCntInCache)
           *      {
           *          break;
           *      }
           *  }
           *
           *  u32pCacheF2hTabSt++;
           * }*/
    }
    else
    {
        sortF2h(upSortF2hTab, u32pCacheF2hTabSt, u32pCacheF2hTabEnd, &u16HblkNum);
        /*while(u32pCacheF2hTabSt!=u32pCacheF2hTabEnd)
           * {
           *  u16Hblock=(WORD)((*u32pCacheF2hTabSt)>>16);
           *
           *  if(!(u16Hblock&c16Bit15)&&!mChkBitMask((upSortF2hTab->uHBlkBitMap[u16Hblock>>3]), u16Hblock&0x7))
           *  {
           *      mSetBitMask(upSortF2hTab->uHBlkBitMap[u16Hblock>>3], u16Hblock&0x7);
           *      upSortF2hTab->u16HBlock[u16HblkNum]=u16Hblock;
           *      u16HblkNum++;
           *      upSortF2hTab->u16HBlockStartOft[u16HblkNum]=c16CacheF2hSize-1;
           *
           *      if(u16HblkNum==gsCacheInfo.u16HblkCntInCache)
           *      {
           *          break;
           *      }
           *  }
           *
           *  u32pCacheF2hTabSt++;
           * }*/
    }

    upSortF2hTab->u16HBlockStartOft[u16HblkNum+1]=c16CacheF2hSize-1;    // for CPU1 debug (human)

#if _EN_UART&DEBUG_Bill_FTL
    NLOG(cLogFTL,
         F2HTAB_C,
         3,
         "FlushF2hStr=0x%04X,End=0x%04X ,HBlkNum=0x%04X",
         gsCacheInfo.u16F2HTabFlushStart,
         gsCacheInfo.u16F2HTabFlushEnd,
         u16HblkNum);
#endif

#if (_PRJ_BOOT&&(!_ICE_LOAD_ALL))
    gsCacheInfo.u16F2HTabFlushStart=0;
#else
    gsCacheInfo.u16F2HTabFlushStart=gsCacheInfo.u16F2HTabFlushEnd;
#endif

    upSortF2hTab->u32HblkNum=u16HblkNum;
    gsCacheInfo.ubEnDualCoreFlush=cTrue;
#if _EN_FW_DEBUG_UART&DEBUG_Bill_FTL
    NLOG(cLogFTL, F2HTAB_C, 3, "FlushF2hStr=0x%04X,End=0x%04X ,HBlkNum=0x%04X", u16F2HStartBak, gsCacheInfo.u16F2HTabFlushEnd, u16HblkNum);
#endif
}    /* initSortF2HBuffer */

void reorderF2hEntry(SORTF2HTAB *upSortF2hTab)
{
#if (_PRJ_BOOT&&!_ICE_LOAD_ALL)
    WORD u16StartUnit, u16UnitLen, u16RslOfst;
#else
    WORD u16StartUnit, u16UnitLen;
    LWORD u32FMap2;
#endif
    LWORD u32Hblock;
    WORD *u16pSortRamH2fPage;
    LWORD *u32pSortRamRslOfst, *u32pCacheF2hTab;

    if(gsCacheInfo.u32FluValidHBlkNum!=upSortF2hTab->u32HblkNum)
    {
        u32Hblock=upSortF2hTab->u16HBlock[gsCacheInfo.u32FluValidHBlkNum];

        while(u32Hblock>=g16TotalHBlock)
            ;

        u16StartUnit=0;
        u32Hblock<<=16;

#if (!_PRJ_BOOT||_ICE_LOAD_ALL)
        u16UnitLen=gsCacheInfo.u16CacheF2hTabFreePtr+1;

        BYTE uBlkPtr=0;
        WORD u16ActiveCacheBlock=gsCacheInfo.u16FluCacheBlock;
        LWORD u32FMap=mSetH2fSrcFAddr(u16ActiveCacheBlock, gsCacheInfo.u32SrchF4kBaseFlu);
        u16pSortRamH2fPage=&upSortF2hTab->u16arH2fPage[gsCacheInfo.u32ModifyH2fPtrHead];
        u32pSortRamRslOfst=&upSortF2hTab->u32arRslOfst[gsCacheInfo.u32ModifyH2fPtrHead];

        u32pCacheF2hTab=(LWORD *)(&garCacheF2hTab[u16UnitLen-1]);

        if(((*u32pCacheF2hTab)&0xFFFF0000)==u32Hblock)
        {
            *u32pSortRamRslOfst++=(u32FMap-(u16UnitLen-1));
            *u16pSortRamH2fPage++=*u32pCacheF2hTab;
            *u32pCacheF2hTab=*u32pCacheF2hTab|c32Bit31;
            gsCacheInfo.u32ModifyH2fPtrHead++;
            mIncTotalVpcN2(mChkMlcMoBit(u16ActiveCacheBlock)?0:1, upSortF2hTab->u32TotalSlcVpc, upSortF2hTab->u32TotalTlcVpc, 1);
            upSortF2hTab->u32arCacheBlkVpCnt[0]++;
        }

        if(u16UnitLen!=gsCacheInfo.u16TotalPgPerF2hTab)
        {
            u32pCacheF2hTab=(LWORD *)(&garCacheF2hTab[gsCacheInfo.u16TotalPgPerF2hTab-1]);

            if(((*u32pCacheF2hTab)&0xFFFF0000)==u32Hblock)
            {
                *u32pSortRamRslOfst++=
                    (mSetH2fSrcFAddr(gsCacheInfo.u16ActiveCacheBlock, gsCacheInfo.u32SrchF4kBase)-(gsCacheInfo.u16TotalPgPerF2hTab-1));
                *u16pSortRamH2fPage++=*u32pCacheF2hTab;
                *u32pCacheF2hTab=*u32pCacheF2hTab|c32Bit31;
                gsCacheInfo.u32ModifyH2fPtrHead++;
                mIncTotalVpcN2(mChkMlcMoBit(gsCacheInfo.u16ActiveCacheBlock)?0:1, upSortF2hTab->u32TotalSlcVpc, upSortF2hTab->u32TotalTlcVpc,
                               1);
                upSortF2hTab->u32arCacheBlkVpCnt[1]++;
            }
        }

        LWORD u32ActCacheBlkVpc=gsCacheInfo.u32ModifyH2fPtrHead;
#else/* if (!_PRJ_BOOT||_ICE_LOAD_ALL) */
        u16UnitLen=gsCacheInfo.u16TotalPgPerF2hTab;
        u16pSortRamH2fPage=&upSortF2hTab->u16arH2fPage[gsCacheInfo.u32ModifyH2fPtrHead];
        u32pSortRamRslOfst=&upSortF2hTab->u32arRslOfst[gsCacheInfo.u32ModifyH2fPtrHead];
        u32pCacheF2hTab=(LWORD *)(&garCacheF2hTab[gsCacheInfo.u16TotalPgPerF2hTab-1]);

        if(((*u32pCacheF2hTab)&0xFFFF0000)==u32Hblock)
        {
            *u32pSortRamRslOfst++=(gsCacheInfo.u16TotalPgPerF2hTab-1);
            *u16pSortRamH2fPage++=*u32pCacheF2hTab;
            *u32pCacheF2hTab=*u32pCacheF2hTab|c32Bit31;
            gsCacheInfo.u32ModifyH2fPtrHead++;
        }
#endif/* if (!_PRJ_BOOT||_ICE_LOAD_ALL) */

#if (!_PRJ_BOOT||_ICE_LOAD_ALL)
        do
        {
#endif

        if(bopSrchRam((LWORD)garCacheF2hTab, u32Hblock, 0xFFFF0000, u16StartUnit, u16UnitLen,
                      cBopSrchDat|cBopLwordMo|cBopWait|cBopNotRstFlag)!=0xFFFF)
        {
            do
            {
                u16StartUnit=rmGetSrchRslOfst;
                rmSetBopDesAddr(u16StartUnit+1);
                rmTrigBopOpWoPause(cBopSrchOp);
#if (_PRJ_BOOT&&!_ICE_LOAD_ALL)
                u16RslOfst=u16StartUnit;
#endif
                u32pCacheF2hTab=(LWORD *)(&garCacheF2hTab[u16StartUnit]);
                // u16StartUnit++;

                if((*(u32pCacheF2hTab+1)&0xFFFF0000)==u32Hblock)
                {
#if (!_PRJ_BOOT||_ICE_LOAD_ALL)
                    u32FMap2=u32FMap-u16StartUnit;
#endif

                    do
                    {
#if (_PRJ_BOOT&&!_ICE_LOAD_ALL)
                        *u32pSortRamRslOfst++=u16RslOfst;
#else
                        *u32pSortRamRslOfst++=u32FMap2;
#endif
                        *u16pSortRamH2fPage++=*u32pCacheF2hTab;
                        *u32pCacheF2hTab=*u32pCacheF2hTab|c32Bit31;
                        gsCacheInfo.u32ModifyH2fPtrHead++;
#if (_PRJ_BOOT&&!_ICE_LOAD_ALL)
                        u16RslOfst++;
#else
                        u32FMap2--;
#endif
                        u32pCacheF2hTab++;
                        u16StartUnit++;
                    }
                    while((*(u32pCacheF2hTab+1)&0xFFFF0000)==u32Hblock);

                    while(rmChkBopBz)
                        ;

                    rmSetBopDesAddr(u16StartUnit+1);
                    rmTrigBopOpWoPause(cBopSrchOp);
                }

                // rmSetBopDesAddr(u16StartUnit+1);
                // rmTrigBopOpWoPause(cBopSrchOp);

#if (_PRJ_BOOT&&!_ICE_LOAD_ALL)
                *u32pSortRamRslOfst++=u16RslOfst;
#else
                *u32pSortRamRslOfst++=u32FMap-u16StartUnit;
#endif
                *u16pSortRamH2fPage++=*u32pCacheF2hTab;
                *u32pCacheF2hTab=*u32pCacheF2hTab|c32Bit31;
                gsCacheInfo.u32ModifyH2fPtrHead++;

                while(rmChkBopBz)
                    ;
            }
            while(rmChkSrchValFind);
        }

#if (!_PRJ_BOOT||_ICE_LOAD_ALL)
        u32ActCacheBlkVpc=gsCacheInfo.u32ModifyH2fPtrHead-u32ActCacheBlkVpc;

        mIncTotalVpcN2(mChkMlcMoBit(u16ActiveCacheBlock)?0:1, upSortF2hTab->u32TotalSlcVpc, upSortF2hTab->u32TotalTlcVpc, u32ActCacheBlkVpc);
        upSortF2hTab->u32arCacheBlkVpCnt[uBlkPtr]+=u32ActCacheBlkVpc;
        uBlkPtr++;

        if(u16UnitLen!=gsCacheInfo.u16TotalPgPerF2hTab)
        {
            u16StartUnit=u16UnitLen;
            u16UnitLen=gsCacheInfo.u16TotalPgPerF2hTab;
            u16ActiveCacheBlock=gsCacheInfo.u16ActiveCacheBlock;
            u32ActCacheBlkVpc=gsCacheInfo.u32ModifyH2fPtrHead;
            u32FMap=mSetH2fSrcFAddr(u16ActiveCacheBlock, gsCacheInfo.u32SrchF4kBase);
        }
        else
        {
            break;
        }
    }

    while(1)
        ;
#endif/* if (!_PRJ_BOOT||_ICE_LOAD_ALL) */

        rmSetSrchDefault;
        gsCacheInfo.u32FluValidHBlkNum++;
        upSortF2hTab->u16HBlockStartOft[gsCacheInfo.u32FluValidHBlkNum]=gsCacheInfo.u32ModifyH2fPtrHead;
    }
}    /* reorderF2hEntry */

/*
   * cbit0: flushAll
   * cbit1: Partial
   * cbit2: SendChkStatus
   * cbit3: Flush in Boot, if (_EN_RDLINK_PF==1), only reorderF2hEntry()
   * cbit4: Flush in RW service
   * cbit7: not Push Flush Cache to Spare
   * should only be called after act cache block fulled
   */
void flushCacheF2hTab(BYTE uOpt)
{
    SORTF2HTAB *upSortF2hTab;

    // ADDRINFO usTmpAddrInfo;
    WORD u16HBlock, u16SbufPtr, u16H2fWrOpt;
    BYTE uPopOpt, u16H2FTabNum, uPrePopTyp, uPrePopCacheFlag;

#if _EN_SLCOpenBlkReadScrub
    if((!mChkGcQue(cGcTypFlushF2h))&&(!(uOpt&cBit0))&&(!(uOpt&cBit4))||mChkDummyWrite)
    {
        return;
    }
#else
    if((!mChkGcQue(cGcTypFlushF2h))&&(!(uOpt&cBit0))||mChkDummyWrite)
    {
        return;
    }
#endif

    upSortF2hTab=(SORTF2HTAB *)(cFlushCacheVarStrAddr);

#if _EN_VPC_SWAP
    g32arCacheBlkVpCnt=(volatile LWORD *)(cCacheBlkVpCntFlushStrAddr);
#if (!_PRJ_BOOT||_ICE_LOAD_ALL||(!_ENABLE_RAID))
    readWproPageCore0(cWproCacheBlkVpCnt, cCacheBlkVpCntFlushStrIdx, 0);
#else
    popVPCfromRaidCore0(cCacheBlkVpCntFlushStrIdx);
#endif
#endif

    /*
       * gWriteHMBIndex=0;
       *
       * for(u16HBlock=0; u16HBlock<cHmbRacingFreeCnt; u16HBlock++)
       * {
       *  g16WriteHMBH2FTable[u16HBlock]=c16Null;
       * }
       */
    if(uOpt&cBit0)
    {
        gsCacheInfo.u16F2HTabFlushStart=0;
        gsCacheInfo.u16F2HTabFlushEnd=gsCacheInfo.u16MaxTotalPgPerF2hTab;
    }

    initSortF2HBuffer(upSortF2hTab);

#if (_EN_RDLINK_PF)
    if(uOpt&cBit3)
    {
        while(!(uOpt&cBit1))
            ;

        while(gsCacheInfo.u32FluValidHBlkNum!=upSortF2hTab->u32HblkNum)
        {
            u16HBlock=upSortF2hTab->u16HBlock[gsCacheInfo.u32FluValidHBlkNum];

            while(!mChkSrcInCache(u16HBlock))
                ;

            mClrSrcInCache(u16HBlock);
            reorderF2hEntry(upSortF2hTab);
        }

        // NLOG(cLogBuild, F2HTAB_C, 0, "flush reorder");

        // rstH2F1KInfo();
        gsCacheInfo.ubEnDualCoreFlush=cFalse;
        gsCacheInfo.u32ModifyH2fPtrTail=gsCacheInfo.u32ModifyH2fPtrHead;

        while(upSortF2hTab->u32TotalSlcVpc)
            ;

        while(upSortF2hTab->u32TotalTlcVpc)
            ;

        // while(gsCacheInfo.u32ModifyH2fPtrHead!=gsCacheInfo.u32ModifyH2fPtrTail)
        //    ;// debug

        // mClrFlushF2h;    // TODO: debug purpose, remove it after verify done.

        return;
    }
#endif/* if (_EN_RDLINK_PF) */

    uPrePopCacheFlag=0;

#if (!_PRJ_BOOT||_ICE_LOAD_ALL)
    if(mChkCacheInfoFlag(cCacheBlockFull))
    {
        uPrePopCacheFlag=1;
    }
    else if(gsCacheInfo.uF2hTabBank>=(gsCacheInfo.uMaxBankNum-1))
    {
        if((gsCacheInfo.u32CacheFreePagePtr%gsCacheInfo.u16TotalPgPerF2hTab)>(gsCacheInfo.u16TotalPgPerF2hTab>>1))
        {
            uPrePopCacheFlag=1;
        }
    }
#endif

    while(upSortF2hTab->u32DoneHBlkNum!=upSortF2hTab->u32HblkNum&&(!mChkDummyWrite))
    {
        WORD u16LoadHBlkNum;
        BYTE uMaxLoadSize;

        if(!upSortF2hTab->u32LoadHBlkNum)
        {
            uMaxLoadSize=upSortF2hTab->u32SortH2FTabNum;
        }
        else
        {
            uMaxLoadSize=upSortF2hTab->u32ProgH2fTabNum;
        }

        u16LoadHBlkNum=upSortF2hTab->u32LoadHBlkNum;

        while(uMaxLoadSize&&(u16LoadHBlkNum!=upSortF2hTab->u32HblkNum))
        {
#if _ENABLE_E2E_TAB
            swapH2fTable(upSortF2hTab->u16HBlock[u16LoadHBlkNum],
                         upSortF2hTab->u16H2fTableBufPtr[upSortF2hTab->u32LoadH2FPtr],
                         cWaitReadDone|cSetBufferFlag);
#else
            swapH2fTable(upSortF2hTab->u16HBlock[u16LoadHBlkNum], upSortF2hTab->u16H2fTableBufPtr[upSortF2hTab->u32LoadH2FPtr], cSetBufferFlag);
#endif
            upSortF2hTab->uH2FRamPtr[u16LoadHBlkNum]=upSortF2hTab->u32LoadH2FPtr;
            upSortF2hTab->u32LoadH2FPtr=(upSortF2hTab->u32LoadH2FPtr+1)&(upSortF2hTab->u32SortH2FTabNum-1);
            uMaxLoadSize--;
            u16LoadHBlkNum++;
        }

        // wait read table ready
        while(gsRwCtrl.u32FreeSrcFifoTail!=gsRwCtrl.u32FreeSrcFifoHead)
        {
            if(!uPrePopCacheFlag)
            {
                reorderF2hEntry(upSortF2hTab);
            }
        }

#if (!_PRJ_BOOT||_ICE_LOAD_ALL)
        waitHmbPrdDone();
#endif

        while(rmChkHdmaBz)
            ;

        upSortF2hTab->u32LoadHBlkNum=u16LoadHBlkNum;

        // Pre Erase and search
        if(uPrePopCacheFlag&&(gsCacheInfo.u16PrePopCacheBlock==c16FBlockInitValue))
        {
            uPrePopCacheFlag=0;
            uPrePopTyp=1;
            uPopOpt=chkPopBlkOpt()|cPopSkipChkSts;
            popSpareBlockCore0(uPopOpt);
#if _EN_512Gb_Debug
            NLOG(cLogFTL, F2HTAB_C, 1, "PrePopSpareBlk! u16Fblock=0x%04x", gsTskFifoCtrl.u16PopFBlk);
#endif
        }
        else if(mChkCacheInfoFlag(cH2fTabBlockFull))
        {
            initH2fTabFblock(cPopSkipChkSts);
            uPrePopTyp=2;
        }
        else
        {
            uPrePopTyp=0;
        }

        while(((gsCacheInfo.u32FluModifidHBlkNum-upSortF2hTab->u32DoneHBlkNum)<upSortF2hTab->u32ProgH2fTabNum)&&
              (gsCacheInfo.u32FluModifidHBlkNum!=upSortF2hTab->u32HblkNum))
        {
            if((gsCacheInfo.u32FluValidHBlkNum-upSortF2hTab->u32DoneHBlkNum)<upSortF2hTab->u32ProgH2fTabNum)
            {
                reorderF2hEntry(upSortF2hTab);
            }

            if(mChkDummyWrite)
            {
                return;
            }
        }

        if(uPrePopTyp)
        {
            if(uPrePopTyp==1)
            {
                uPopOpt&=~cPopSkipChkSts;

                TASKENTRY usTskEntry;

                usTskEntry.uTskTyp=cTskPrePopBlkChkStatus;
                usTskEntry.uTskOpt=uPopOpt|cPopSkipErsCmd;

                insertTaskFifo(usTskEntry);

                while(gsTskFifoCtrl.u32HeadPtr!=gsTskFifoCtrl.u32TailPtr)
                {
                    reorderF2hEntry(upSortF2hTab);
                }

                // if(prepopBlkChkStatusCore0(uPopOpt|cPopSkipErsCmd))
                if(gsTskFifoCtrl.u32EraseFail)
                {
                    gsCacheInfo.u16PrePopCacheBlock=popSpareBlockCore0(uPopOpt);
#if _EN_512Gb_Debug
                    NLOG(cLogFTL, F2HTAB_C, 1, "EraseFail:PrePopSpareBlk! u16Fblock=0x%04x", gsCacheInfo.u16PrePopCacheBlock);
#endif
                }
                else
                {
                    gsCacheInfo.u16PrePopCacheBlock=gsTskFifoCtrl.u16PopFBlk;
                }
            }
            else if(uPrePopTyp==2)
            {
                if(prepopBlkChkStatusCore0(cPopMinErsCnt|cPopSlcBlock|cPopSkipErsCmd))
                {
                    g16arH2fTabBlk[gsCacheInfo.uActH2fTabBlkIdx]=popSpareBlockCore0(cPopMinErsCnt|cPopSlcBlock);    // gsTskFifoCtrl.u16PopFBlk;
                }
                else
                {
                    g16arH2fTabBlk[gsCacheInfo.uActH2fTabBlkIdx]=gsTskFifoCtrl.u16PopFBlk;
                }
            }

            // uPrePopTyp=0;
        }

        if((gsCacheInfo.u16H2fTabFreePagePtr+upSortF2hTab->u32ProgH2fTabNum)>=gsCacheInfo.u16H2fTabPagePerBlk3)
        {
            mSetGcFlag(cGcSkipPrgCacheInfo);    // gsCacheInfo.ubSkipPrgCacheInfo=1;
        }

        // else
        // {
        //    gsCacheInfo.ubSkipPrgCacheInfo=0;
        // }

        for(u16H2FTabNum=0; u16H2FTabNum<upSortF2hTab->u32ProgH2fTabNum; u16H2FTabNum++)
        {
            u16SbufPtr=upSortF2hTab->u16H2fTableBufPtr[upSortF2hTab->uH2FRamPtr[upSortF2hTab->u32DoneHBlkNum]];
            u16HBlock=upSortF2hTab->u16HBlock[upSortF2hTab->u32DoneHBlkNum];
            mSetCacheInfoChangeFlag(cH2fChg);

            // when new h2f happened in prog H2f tab
            if(mChkCacheInfoFlag(cH2fTabBlockFull))
            {
                // wait prog h2f done
                // sortF2HTabInBusy(upSortF2hTab);
                waitAllChCeBzCore0();

                while(gsTskFifoCtrl.u32HeadPtr!=gsTskFifoCtrl.u32TailPtr)
                {
                    reorderF2hEntry(upSortF2hTab);
                }

                initH2fTabFblock(cPopSkipChkSts);

                BYTE uSortNum=upSortF2hTab->u32ProgH2fTabNum;

                while(uSortNum&&(gsCacheInfo.u32FluValidHBlkNum!=upSortF2hTab->u32HblkNum))
                {
                    reorderF2hEntry(upSortF2hTab);
                    uSortNum--;
                }

                // 4ch 1way case, modify remain H2f tab in buffer
                while(gsCacheInfo.u32FluModifidHBlkNum<upSortF2hTab->u32LoadHBlkNum)
                    ;

                // check erase H2F tab result
                if(prepopBlkChkStatusCore0(cPopMinErsCnt|cPopSlcBlock|cPopSkipErsCmd))
                {
                    g16arH2fTabBlk[gsCacheInfo.uActH2fTabBlkIdx]=popSpareBlockCore0(cPopMinErsCnt|cPopSlcBlock);    // gsTskFifoCtrl.u16PopFBlk;
                }
                else
                {
                    g16arH2fTabBlk[gsCacheInfo.uActH2fTabBlkIdx]=gsTskFifoCtrl.u16PopFBlk;
                }
            }

#if ((!_PRJ_BOOT)||_ICE_LOAD_ALL)
            if(mChkHmbLink(u16HBlock))
            {
#if _ENABLE_HMB_FLUSH
                while(mChkHmbTabDirty(mGetHmbLink(u16HBlock)))
                    ;
#endif
                remHmbLink(u16HBlock);
            }

#if _EN_RTUpdateH2F_HMB    // ChrisSu_20190329  sync SMI S0322B
            else if(gsHmbInfo.usHmbList.u16Cnt>=g16HmbMaxTableNum)
            {
                remHmbLink(g16arH2fBackup[gsHmbInfo.usHmbList.u16Tail]);
            }
#endif
            u16H2fWrOpt=c16Bit0|c16Bit2|c16Bit3|c16Bit15;

            if(!gsHmbInfo.uHmbEnable||(gsHmbInfo.usHmbList.u16Cnt>=g16HmbMaxTableNum))
            {
                u16H2fWrOpt|=c16Bit1;
            }

            progH2fTableCore0(u16SbufPtr, u16HBlock, u16H2fWrOpt, cInflushCacheF2hTab_00, 0    /*cBypassWaitChDone*/);    // temp disable
                                                                                                                          // cBypassWaitChDone
                                                                                                                          // for replacing spare
                                                                                                                          // byte issue.
#else/* if ((!_PRJ_BOOT)||_ICE_LOAD_ALL) */
            u16H2fWrOpt=c16Bit0|c16Bit1|c16Bit2|c16Bit3|c16Bit15;
            progH2fTableCore0(u16SbufPtr, u16HBlock, u16H2fWrOpt, cInflushCacheF2hTab_00, cInBoot|cInBootWaitAllDie    /*|cBypassWaitChDone*/);
#endif/* if ((!_PRJ_BOOT)||_ICE_LOAD_ALL) */

#if (_EN_HMB)&&((!_PRJ_BOOT)||_ICE_LOAD_ALL)
            if(gsHmbInfo.uHmbEnable&&(gsHmbInfo.usHmbList.u16Cnt<g16HmbMaxTableNum))
            {
                writeHmbH2fTab(u16SbufPtr, u16HBlock, c16Bit1);
            }
#endif

            upSortF2hTab->u32DoneHBlkNum++;
            mClrSrcInCache(u16HBlock);

            if(upSortF2hTab->u32DoneHBlkNum==upSortF2hTab->u32HblkNum)
            {
                break;
            }
        }

        waitProgH2fTxDataCore0();
    }

    rstH2F1KInfo();
    gsCacheInfo.ubEnDualCoreFlush=cFalse;
    gsGcInfo.u32TotalSlcVpc+=upSortF2hTab->u32TotalSlcVpc;
    gsGcInfo.u32TotalTlcVpc+=upSortF2hTab->u32TotalTlcVpc;
    g32arCacheBlkVpCnt[gsCacheInfo.u16FluCacheBlock]+=upSortF2hTab->u32arCacheBlkVpCnt[0];
    g32arCacheBlkVpCnt[gsCacheInfo.u16ActiveCacheBlock]+=upSortF2hTab->u32arCacheBlkVpCnt[1];

#if _EN_VPC_SWAP
    if((gsCacheInfo.u16ActiveCacheBlock>=g16FirstFBlock)&&(gsCacheInfo.u16ActiveCacheBlock<g16TotalFBlock)&&
       g32arCacheBlkVpCnt[gsCacheInfo.u16ActiveCacheBlock])
    {
        mSetVPCntValid(gsCacheInfo.u16ActiveCacheBlock);
    }

    if((gsCacheInfo.u16FluCacheBlock>=g16FirstFBlock)&&(gsCacheInfo.u16FluCacheBlock<g16TotalFBlock)&&
       g32arCacheBlkVpCnt[gsCacheInfo.u16FluCacheBlock])
    {
        mSetVPCntValid(gsCacheInfo.u16FluCacheBlock);
    }
#endif

    while(gsCacheInfo.u32ModifyH2fPtrHead!=gsCacheInfo.u32ModifyH2fPtrTail)
        ;// debug

#if _EN_VPC_SWAP
    // Prog Changed VPCnt
    waitAllChCeBzCore0();
#if (!_PRJ_BOOT||_ICE_LOAD_ALL||(!_ENABLE_RAID))
    progWproPageCore0(cWproCacheBlkVpCnt, cCacheBlkVpCntFlushStrIdx);
#else
    pushVPCtoRaidCore0(cCacheBlkVpCntFlushStrIdx);
#endif
#endif/* if _EN_VPC_SWAP */

    if(mChkGcFlag(cGcSkipPrgCacheInfo))    // gsCacheInfo.ubSkipPrgCacheInfo)
    {
#if ((!_PRJ_BOOT)||_ICE_LOAD_ALL)
        mClrCacheInfoChangeFlag(cH2fChg);    // gsCacheInfo.ubH2fChg=0;
        waitAllChCeBzCore0();
#if _GREYBOX
        if((gsGbInfo.uGreyBoxItem==cUGSDProgWPROID)&&
           ((gsGbInfo.uGreyBoxOpt==cVOpProgCacheInfoH2fFull)||(gsGbInfo.uGreyBoxOpt==cVOpProgCacheInfoH2fFullDone))&&
           (gsGbInfo.uStag==cVsIdl))
        {
            trigGreyBox(cTrue);
        }
#endif
        progCacheInfoTab();
#endif
        mClrGcFlag(cGcSkipPrgCacheInfo);    // gsCacheInfo.ubSkipPrgCacheInfo=0;
    }
}    /* flushCacheF2hTab */

BYTE readCacheF2hTab(WORD u16SbufPtr, WORD u16Fblock, LWORD u32Fpage, BYTE uBlkID)
{
    LWORD u32FpageStart;
    BLKSPRINFO usBlkSprInfo;
    BYTE uPageOfst, uProgCnt, uSecCnt, uRdFifoIdx[4], uRdFifoCnt=0, u4kNumOfF2hTab, uPadFlag=0, uPadF2hSize, uSecNumDummyF2h;
    WORD u16NowNodeIdx;

    rstUNCStsCore0();

    // handle pad page update
    if(mChkMlcMoBit(u16Fblock))    // gsCacheInfo.u16ActiveCacheBlock))
    {
        uPadF2hSize=(gTlcSecNumPadF2h_1>>3)-(gTlcSecNumPadF2h_1?c4kNumPerRaidPty:0);
        u4kNumOfF2hTab=gTlcTotal4kNumOfF2hTab-uPadF2hSize;
        uSecNumDummyF2h=gTlcSecNumDummyF2h;
    }
    else
    {
        uPadF2hSize=(gSlcSecNumPadF2h_1>>3)-(gSlcSecNumPadF2h_1?c4kNumPerRaidPty:0);
        u4kNumOfF2hTab=gTotal4kNumOfF2hTab-uPadF2hSize;
        uSecNumDummyF2h=gSlcSecNumDummyF2h;
    }

    // handle pad page update
    if(uPadF2hSize)
    {
        u32FpageStart=u32Fpage;
        u32Fpage+=uPadF2hSize;
        uPadFlag=1;
    }

    for(uPageOfst=0; uPageOfst<u4kNumOfF2hTab; )
    {
        u16NowNodeIdx=gsRwCtrl.uarFreeSrcQue[gsRwCtrl.u32FreeSrcFifoHead];
        gpFlashAddrInfo=&garSrcAddrInfo[u16NowNodeIdx];
        g16FBlock=u16Fblock;
        g32FPageNoTran=u32Fpage+uPageOfst;
        // g16FPage=mTran4kAddr(g32FPageNoTran);
        gpFlashAddrInfo->uTsb4kIdx=0xFF;
        gpFlashAddrInfo->uSrcIdx=u16NowNodeIdx;
        tranAddrInfo(gpFlashAddrInfo);
        uProgCnt=(gPlaneNum-gPlaneAddr)*g4kNumPerPlane;

        if(uPageOfst+uProgCnt>u4kNumOfF2hTab)
        {
            uProgCnt=g4kNumPerPlane;
        }

        if((!uPadFlag)&&(uPageOfst+uProgCnt>=u4kNumOfF2hTab))
        {
            uSecCnt=(uProgCnt<<cSctrTo4kShift)-uSecNumDummyF2h;
        }
        else
        {
            uSecCnt=(uProgCnt<<cSctrTo4kShift);
        }

        // tranCeNum(gpFlashAddrInfo);
        gpFlashAddrInfo->uPlaneCnt=uProgCnt;
        gSectorH=0;

#if _PRJ_BOOT
        mSetFRwParam(u16SbufPtr, uSecCnt, c16Bit0|c16Bit4|c16Bit5|c16Bit10|c16Bit14|c16Bit15, cF2hReadTab);
#else
        mSetFRwParam(u16SbufPtr, uSecCnt, c16Bit0|c16Bit4|c16Bit5|c16Bit10|c16Bit15, cF2hReadTab);
#endif

        uRdFifoIdx[uRdFifoCnt]=u16NowNodeIdx;    // uNowSrcAddrIdx;
        uRdFifoCnt++;

        gsRwCtrl.u32FreeSrcFifoHead=(gsRwCtrl.u32FreeSrcFifoHead+1)&(cReadFifoDpt-1);
        u16SbufPtr+=uSecCnt;
        uPageOfst+=uProgCnt;

        if(uPadFlag&&(uPageOfst>=u4kNumOfF2hTab))
        {
            uPageOfst=0;
            uPadFlag=0;
            u4kNumOfF2hTab=uPadF2hSize;
            u32Fpage=u32FpageStart;
        }
    }

    while(gsRwCtrl.u32FreeSrcFifoTail!=gsRwCtrl.u32FreeSrcFifoHead)
        ;

    while(uRdFifoCnt!=0)
    {
        uRdFifoCnt--;
#if (_EN_RDLINK_PF)
#if _FIX_CACHE_BUG
        if(!gPlaneUNCSts[garSrcAddrInfo[uRdFifoIdx[uRdFifoCnt]].uCh])    // all plane are good
#else
        if(!mChkBitMask(gPlaneUNCSts[garSrcAddrInfo[uRdFifoIdx[uRdFifoCnt]].uCh], garSrcAddrInfo[uRdFifoIdx[uRdFifoCnt]].uPlaneAddr))
#endif
        {
            setFLActCh(garSrcAddrInfo[uRdFifoIdx[uRdFifoCnt]].uCh);
            getSprByte(&usBlkSprInfo, garSrcAddrInfo[uRdFifoIdx[uRdFifoCnt]].uPlaneAddr);

            if(mGetSprId!=uBlkID)    // if (mGetSprId!=cF2hTableID)
            {
                // TODO: temp solution for the flush cache block change due to the actCacheBlock padding dummy,
                //       find flush cache block from g16BkRdFlushCacheBlock which record at last rdlink.
                if(((mGetSprId==0xFF)||(mGetSprId==cCacheBlockID))&&
                   ((usBlkSprInfo.u16Spr8.us2BYTE.HighByte==cBootMoveCache)||(usBlkSprInfo.u16Spr8.us2BYTE.HighByte==cPwrOnDummyProg)))
                {
                    return cRdFcbStsDummy;
                }

                if(g32Core1State<cCore1BootState_Finished)
                {
                    // TODO: remove while 1 after verify done.
                    volatile BYTE uStop1=1;

                    while(uStop1)
                        ;
                }

                return cRdFcbStsWrongId;
            }
        }
        else
        {
            return cRdFcbStsUnc;
        }
#else/* if (_EN_RDLINK_PF) */
#if _FIX_CACHE_BUG
        if(!gPlaneUNCSts[garSrcAddrInfo[uRdFifoIdx[uRdFifoCnt]].uCh])    // all plane are good
#else
        if(!mChkBitMask(gPlaneUNCSts[garSrcAddrInfo[uRdFifoIdx[uRdFifoCnt]].uCh], garSrcAddrInfo[uRdFifoIdx[uRdFifoCnt]].uPlaneAddr))
#endif
        {
            setFLActCh(garSrcAddrInfo[uRdFifoIdx[uRdFifoCnt]].uCh);
            getSprByte(&usBlkSprInfo, garSrcAddrInfo[uRdFifoIdx[uRdFifoCnt]].uPlaneAddr);

            if(mGetSprId!=uBlkID)    // if (mGetSprId!=cF2hTableID)
            {
                return cFalse;
            }
        }
        else
        {
            return cFalse;
        }
#endif/* if (_EN_RDLINK_PF) */
    }

#if (_EN_RDLINK_PF)
    return cRdFcbStsSuccess;
#else
    return cTrue;
#endif
}    /* readCacheF2hTab */

BYTE chkHdlF2hTab(WORD u16ProgPageOfst)
{
    if((gsCacheInfo.u32CacheFreePagePtr+u16ProgPageOfst)>=(LWORD)(((gsCacheInfo.uF2hTabBank+1)*gsCacheInfo.u16TotalPgPerF2hTab)))
    {
        return cTrue;
    }
    else
    {
        return cFalse;
    }
}

BYTE chkValidF2hTabEntry(LWORD *u32pCacheF2hTabSt, LWORD *u32pCacheF2hTabEnd)
{
    while(u32pCacheF2hTabSt!=u32pCacheF2hTabEnd)
    {
        if(!((*u32pCacheF2hTabSt++)&c32Bit31))
        {
            return cTrue;
        }

        if(!((*u32pCacheF2hTabSt++)&c32Bit31))
        {
            return cTrue;
        }

        if(!((*u32pCacheF2hTabSt++)&c32Bit31))
        {
            return cTrue;
        }

        if(!((*u32pCacheF2hTabSt++)&c32Bit31))
        {
            return cTrue;
        }

        if(!((*u32pCacheF2hTabSt++)&c32Bit31))
        {
            return cTrue;
        }

        if(!((*u32pCacheF2hTabSt++)&c32Bit31))
        {
            return cTrue;
        }

        if(!((*u32pCacheF2hTabSt++)&c32Bit31))
        {
            return cTrue;
        }

        if(!((*u32pCacheF2hTabSt++)&c32Bit31))
        {
            return cTrue;
        }
    }

    return cFalse;
}    /* chkValidF2hTabEntry */

BYTE chkNeedFlushF2H(WORD u16ChkFlushSize, WORD u16ChkEntryNum, WORD u16RemainToWrite)
{
    BYTE uOverflow;
    WORD u16StartEntry, u16StartEntry2;
    LWORD *u32pCacheF2hTabSt;
    LWORD *u32pCacheF2hTabEnd;
    LWORD *u32pCacheF2hTabMax;

#if (_ENABLE_HMB_FLUSH)
    // workaround - rdlink only rebuild 2 banks currently.
    if(gsHmbInfo.u16HmbLastDirtyPtr!=c16Null)
    {
        return cTrue;
    }
#endif

    u16StartEntry=gsCacheInfo.u16TotalPgPerF2hTab+gsCacheInfo.u16CacheF2hTabFreePtr+1-gsRwCtrl.u16ProgPageOfst-u16RemainToWrite-u16ChkFlushSize;

    if(u16StartEntry>=gsCacheInfo.u16TotalPgPerF2hTab)
    {
        u16StartEntry-=gsCacheInfo.u16TotalPgPerF2hTab;
    }

    u16StartEntry2=u16StartEntry;

    gsCacheInfo.u16F2HTabFlushStart=u16StartEntry;
    u32pCacheF2hTabSt=(LWORD *)garCacheF2hTab+u16StartEntry;
    u16StartEntry+=u16ChkEntryNum;

    if(u16StartEntry>=gsCacheInfo.u16TotalPgPerF2hTab)
    {
        u16StartEntry-=gsCacheInfo.u16TotalPgPerF2hTab;
        u32pCacheF2hTabMax=(LWORD *)garCacheF2hTab+gsCacheInfo.u16TotalPgPerF2hTab;
        uOverflow=cTrue;
    }
    else
    {
        uOverflow=cFalse;
    }

    gsCacheInfo.u16F2HTabFlushEnd=u16StartEntry;

    /*
       * NLOG(cLogFTL, F2HTAB_C, 4, "WrPos:0x%04X,BankPos:0x%04X, u16StartEntry:0x%04X, u16ChkEntryNum:0x%04X",
       *  (WORD)gsCacheInfo.u16F2HTabFlushStart,
       *  (WORD)gsCacheInfo.u16F2HTabFlushEnd,
       *  (WORD)u16StartEntry, (WORD)u16ChkEntryNum);
       */

    u32pCacheF2hTabEnd=(LWORD *)garCacheF2hTab+u16StartEntry;

    if(!rmChkBopNbsBz)
    {
        rmSetDmaTsbTail1(cTsb1StartBufIdx+(gsCacheInfo.u16TotalPgPerF2hTab>>7)-1);

        if(bopSrchRam((LWORD)garCacheF2hTab+(u16StartEntry2<<2), 0, c32Bit31, 0, u16ChkEntryNum, cBopSrchDat|cBopLwordMo|cBopWait)!=0xFFFF)
        {
            rmSetDmaTsbTail1(cTsb1StartBufIdx+cTsb1Size-1);
            return cTrue;
        }
        else
        {
            rmSetDmaTsbTail1(cTsb1StartBufIdx+cTsb1Size-1);
            return cFalse;
        }
    }
    else
    {
        if(uOverflow)
        {
            if(chkValidF2hTabEntry(u32pCacheF2hTabSt, u32pCacheF2hTabMax))
            {
                return cTrue;
            }

            return chkValidF2hTabEntry((LWORD *)garCacheF2hTab, u32pCacheF2hTabEnd);
        }
        else
        {
            return chkValidF2hTabEntry(u32pCacheF2hTabSt, u32pCacheF2hTabEnd);
        }
    }
}    /* chkNeedFlushF2H */

WORD subWriteBufPtr(WORD u16BufPtr, WORD u16SectorH)
{
    if(u16BufPtr>=u16SectorH)
    {
        u16BufPtr-=u16SectorH;
    }
    else
    {
        u16BufPtr=(c16WriteSIdx+c16WriteBufSize)-((WORD)u16SectorH-u16BufPtr);
    }

    return u16BufPtr;
}

void chkRaidParityOccF(LWORD u32CacheFreePagePtr)
{
#if 1
    WORD u16RaidStr4k, u16EndPtr, u16StrPtr, u16TotalPgPerF2hTab;

    u16TotalPgPerF2hTab=gsCacheInfo.u16TotalPgPerF2hTab;
    u16RaidStr4k=u16TotalPgPerF2hTab-gsCacheInfo.u16ProgRaidChStr4K-c4kNumPerRaidPty;
    u16StrPtr=u16TotalPgPerF2hTab-((u32CacheFreePagePtr+gsRwCtrl.u16ProgPageOfst)%u16TotalPgPerF2hTab)-(c16WriteBufSize/cSctrPer4k);
    u16EndPtr=u16TotalPgPerF2hTab-((gsCacheInfo.u32CacheFreePagePtr+gsRwCtrl.u16ProgPageOfst)%u16TotalPgPerF2hTab);

    while((u16StrPtr<=u16RaidStr4k)&&(u16StrPtr<u16EndPtr))
    {
        gsRwCtrl.u16OccFSkipStBufPtr=subWriteBufPtr(gsRwCtrl.u16OccFSkipStBufPtr, cRaidDataSctrNum);
        gsRwCtrl.u16OccFSkipSize+=cRaidDataSctrNum;
        u16StrPtr+=(gTotalIntlvChNum*g4kNumPerPage);
    }
#else
    BYTE uOffsetSctrCnt=((gIntlvWay>=4)?1:(4-gIntlvWay))*cRaidDataSctrNum;

    gsRwCtrl.u16OccFSkipStBufPtr=subWriteBufPtr(gsRwCtrl.u16OccFSkipStBufPtr, uOffsetSctrCnt);
    gsRwCtrl.u16OccFSkipSize=uOffsetSctrCnt;
#endif/* if 1 */
}    /* chkRaidParityOccF */

void chkFlushCacheTabOccF()
{
    if(!mChkGcQue(cGcTypFlushF2h))
    {
        if(((gsCacheInfo.u32CacheFreePagePtr+gsRwCtrl.u16ProgPageOfst)%g16ChkFlushSize)==g16FlushStr4K)
        {
            if(!gsCacheInfo.uChkF2hRegion&&chkHdlF2hTab(g16FlushChkStart+gsRwCtrl.u16ProgPageOfst+g16FlushRem4K))
            {
                if(chkNeedFlushF2H(gsCacheInfo.u16F2hChkFlushStart, gsCacheInfo.u16F2hChkFlushSize, g16FlushRem4K))
                {
                    mPushGcQue(cGcTypFlushF2h);
                }

                gsCacheInfo.uChkF2hRegion=1;
            }
            else
            {
                if(chkNeedFlushF2H(g16FlushChkStart, g16ChkFlushSize, g16FlushRem4K))
                {
                    mPushGcQue(cGcTypFlushF2h);
                }
            }

            if((gsWproInfo.uCnt>=(cWproGcThr))&&(gsWproInfo.u16WproFreePagePtr>=(gsWproInfo.u16PagePerBlock3/2)))
            {
                mPushGcQue(cGcTypWPROSwap);
            }

            if(gsGcInfo.uGcQueueCnt)
            {
                gsGcInfo.ubBgdProcF=1;
            }

            if(gsGcInfo.ubBgdProcF)
            {
                if(gInSecApi)
                {
                    gsRwCtrl.u16OccFSkipStBufPtr=g16FlashWBufPtr+g16BackupWriteBufPtr;
                }
                else
                {
                    gsRwCtrl.u16OccFSkipStBufPtr=g16FlashWBufPtr;
                }

#if _ENABLE_RAID
                chkRaidParityOccF(gsCacheInfo.u32CacheFreePagePtr);
#endif
            }
        }
    }
}    /* chkFlushCacheTabOccF */

void chkAddHostWrCnt(BYTE uRwHalfKb, BYTE uChkOccF)
{
    if(gsGcInfo.ubBgdProcF)
    {
        gsRwCtrl.u16OccFSkipSize+=uRwHalfKb;

        while(gsRwCtrl.u16OccFSkipSize>c16WriteBufSize)
            ;
    }
    else if(uChkOccF)
    {
        chkFlushCacheTabOccF();
    }
}

void decFluF2hTabPtr()
{
    // if((gsCacheInfo.u16FlushF2hTabPtr!=0)&&(gsCacheInfo.u16FlushF2hTabPtr!=0xFFFF))
    // {
    //    gsCacheInfo.u16FlushF2hTabPtr--;
    // }
    // else
    // {
    // if(gsCacheInfo.u16FluCacheBlock!=0xFFFF)
    // {
    gsCacheInfo.uFlushCacheBlkBank++;

// #if (!_PRJ_BOOT)||(_ICE_LOAD_ALL)       // ???? should push into spare
    if(gsCacheInfo.uFlushCacheBlkBank==gsCacheInfo.uMaxFlushBankNum)
    {
#if _EN_VPC_SWAP
        if(mChkVPCntValid(gsCacheInfo.u16FluCacheBlock))
#else
        if(mGetCacheBlkVpCnt(gsCacheInfo.u16FluCacheBlock)!=0)
#endif
        {
            mClrSkipGcSrch(gsCacheInfo.u16FluCacheBlock);
        }
        else
        {
            if(mChkGcSrcBlkBmap(gsCacheInfo.u16FluCacheBlock))    // 20190415_Louis
            {
                mClrGcSrcBlkBmap(gsCacheInfo.u16FluCacheBlock);
            }

            if(!mChkSkipGcSrch(gsCacheInfo.u16FluCacheBlock))
            {
                mSetSkipGcSrch(gsCacheInfo.u16FluCacheBlock);
            }

            pushSpareBlockCore0(gsCacheInfo.u16FluCacheBlock, cPushNotErase);
        }
    }

// #endif
    // }

    gsCacheInfo.u16FluCacheBlock=c16FBlockInitValue;
    // gsCacheInfo.u16FlushF2hTabPtr=0xFFFF;
    // }
}    /* decFluF2hTabPtr */

void convrVarActCache2FluCache()
{
    gsPcieErrInfo.u16BkFluCacheBlock=gsCacheInfo.u16FluCacheBlock;
    gsPcieErrInfo.uBkFlushCacheBlkBank=gsCacheInfo.uFlushCacheBlkBank;
    gsPcieErrInfo.u32BkSrchF4kBaseFlu=gsCacheInfo.u32SrchF4kBaseFlu;
    gsPcieErrInfo.u32BkFluBlkSerial=gsCacheInfo.u32FluBlkSerial;
    gsPcieErrInfo.uBkMaxFlushBankNum=gsCacheInfo.uMaxFlushBankNum;

    gsCacheInfo.u16FluCacheBlock=gsCacheInfo.u16ActiveCacheBlock;
    gsCacheInfo.uFlushCacheBlkBank=gsCacheInfo.uF2hTabBank;
    // gsCacheInfo.u16FlushF2hTabPtr=gsCacheInfo.u16TotalPgPerF2hTab-1;
    gsCacheInfo.u32SrchF4kBaseFlu=gsCacheInfo.u32SrchF4kBase;
    gsCacheInfo.u32FluBlkSerial=gsCacheInfo.u32CacheBlkSerial;
    gsCacheInfo.uMaxFlushBankNum=gsCacheInfo.uMaxBankNum;
    // gsCacheInfo.u16FlushTotalPgPerF2hTab=gsCacheInfo.u16TotalPgPerF2hTab;
}

void setCacheBlockFull()
{
    // gsCacheInfo.uF2hTabBank++;
    if(gsCacheInfo.uF2hTabBank==gsCacheInfo.uMaxBankNum)
    {
        mSetCacheInfoFlag(cCacheBlockFull);
        gsCacheInfo.u16CacheBlockCnt--;
        gsCacheInfo.u16ActiveCacheBlock=c16FBlockInitValue;    // MIKEY:reset after progCacheInfoTab for rebuild
    }
    else
    {
        gsCacheInfo.u32SrchF4kBase+=gsCacheInfo.u16TotalPgPerF2hTab;
    }
}

#if _ENABLE_RAID
void resetSrchTgt()
{
    BYTE uReset4kNum=c4kNumPerRaidPty;

    while(uReset4kNum)
    {
        rmSetSrchTgt(gsRwCtrl.uMaskTgtPtr, c32BitFF);
        gsRwCtrl.uMaskTgtPtr++;
        uReset4kNum--;
    }
}

#endif/* if _ENABLE_RAID */

void resetF2hTab(BYTE uStartCachePtr, BYTE uReset4kNum)
{
    WORD *u16pDesF2hHp=(WORD *)(&garDesF2hInfo[gsRwCtrl.u32ProgFifoHead].u16arHPage[uStartCachePtr]);
    WORD *u16pDesF2hHb=(WORD *)(&garDesF2hInfo[gsRwCtrl.u32ProgFifoHead].u16arHBlock[uStartCachePtr]);

    while(uReset4kNum)
    {
        // garDesF2hInfo[gsRwCtrl.u32ProgFifoHead].u16arHPage[uF4k]=0xFFFF;
        // garDesF2hInfo[gsRwCtrl.u32ProgFifoHead].u16arHBlock[uF4k]=0xFFFF;
        *u16pDesF2hHp++=c16BitFF;
        *u16pDesF2hHb++=c16BitFF;
        uReset4kNum--;
    }
}    /* resetF2hTab */

void setF2hProgDesAddr()
{
    WORD u16F2HStarPtr=gsCacheInfo.u16F2hPadStartAddr_2;
    BYTE uProgF2HSize, uF2HRemSize=gsCacheInfo.uProgF2HRem4KNum;

#if (_PRJ_ISP||_EN_RDLINK_PF)
    while(gsRwCtrl.u32UpdFifoPtr!=gsRwCtrl.u32ProgFifoHead)
    {
        updateF2hTable(gsRwCtrl.u32ProgFifoHead);
    }
#endif

#if _PRJ_BOOT
    NLOG(cLogCore1, F2HTAB_C, 1, "gsCacheInfo.u32CacheFreePagePtr =: 0x%04X  ", gsCacheInfo.u32CacheFreePagePtr);
    NLOG(cLogCore1, F2HTAB_C, 1, "gsRwCtrl.u16ProgPageOfst=: 0x%04X  ", gsRwCtrl.u16ProgPageOfst);
    NLOG(cLogCore1, F2HTAB_C, 1, "uF2HRemSize =: 0x%04X  ", uF2HRemSize);
#endif/* if _PRJ_BOOT */

    while(uF2HRemSize)
    {
        // set Prog F2h, close next des addr.
        gpFlashAddrInfo=&garDesAddrInfo[gsRwCtrl.u32ProgFifoHead];

        if(mChkNewDesF)
        {
            setWriteDes(gsRwCtrl.u16ProgPageOfst, gpFlashAddrInfo, cWriteCache);
            gpFlashAddrInfo->uRwHalfKb=0;
            gpFlashAddrInfo->uPrdPtr=0;
            mClrNewDesF;    // gbNewDesF=0;
        }

        // c16Bit9  : program F2h first  page
        // c16Bit10 : program F2h second page
        while(!(gpFlashAddrInfo->u16RwOpt&cProg32kF2H))
            ;

        if(uF2HRemSize>g4kNumPerPage)
        {
            uProgF2HSize=g4kNumPerPage;
            uF2HRemSize-=g4kNumPerPage;
        }
        else
        {
            uProgF2HSize=uF2HRemSize;
            uF2HRemSize=0;
        }

        gpFlashAddrInfo->u16BufPtr=u16F2HStarPtr;
        u16F2HStarPtr+=gSectorPerPageH;
        gpFlashAddrInfo->uPlaneCnt+=uProgF2HSize;
        gsRwCtrl.u16ProgPageOfst+=uProgF2HSize;

        if(!mChkFLOption(cEnCacheProg)||(g16FPage==(g16PagePerBlock1_SLC-1)))
        {
            gpFlashAddrInfo->u16RwOpt|=c16Bit0|c16Bit2|c16Bit15;
            gOpTyp=cProgData;
        }
        else
        {
            gpFlashAddrInfo->u16RwOpt|=c16Bit0|c16Bit2|c16Bit3|c16Bit15;
            gOpTyp=cCacheProgData;
        }

#if _PRJ_BOOT
        gOpTyp=cBootMoveCache;    // modify opt to cBootMoveCache, let core1 parity out. trigHdmaEncData()
#endif
        resetF2hTab(0, uProgF2HSize);
        LWORD *u32pDesF2h=(LWORD *)(&garCacheF2hTab[gsCacheInfo.u16CacheF2hTabFreePtr]);

        do
        {
            *u32pDesF2h--=c32BitFF;
        }
        while(u32pDesF2h>=(LWORD *)garCacheF2hTab);

        // it wll not occupy buffer when prog F2h, so give input 0 for default.
        chkAddHostWrCnt(0, 1);
        // addDesAddrInfo();
        // chkAddProgFifoHead();
#if (!_PRJ_ISP)
        gAddrOpt&=~(cDone|cProgFail);
        gsRwCtrl.u32ProgFifoHead=addWrFfPtrBy1(gsRwCtrl.u32ProgFifoHead);
#else
        chkAddProgFifoHead(cNull);
#endif

        while(gsRwCtrl.u32ProgFifoTail==addWrFfPtrBy1(gsRwCtrl.u32ProgFifoHead))
            ;

        mSetNewDesF;
        // gsRwCtrl.u32OneShotChPtr=addPtrBy1(gsRwCtrl.u32OneShotChPtr, gTotalChNum);
        gsRwCtrl.u32SrchFifoPtr=gsRwCtrl.u32ProgFifoHead;

#if (_PRJ_ISP||_EN_RDLINK_PF)
        updateF2hTable(gsRwCtrl.u32ProgFifoHead);
#endif
    }

    gsCacheInfo.uChkF2hRegion=0;
}    /* setF2hProgDesAddr */

void getSrchResult(BYTE uMaxSrchCnt)
{
    BYTE uQueIdx;

    do
    {
        if(!rmChkNbsQueMt)
        {
            uQueIdx=rmGetNbsQueIdx;

            if(rmChkNbsHitBit(uQueIdx))
            {
                g16arMskRptF2hOfst[gsRwCtrl.u16MskRptF2hBasePtr+uQueIdx]=rmGetNbsHitOfst(uQueIdx);

                *(LWORD *)(&garCacheF2hTab[rmGetNbsHitOfst(uQueIdx)])=cInvalid32Bit;
            }
            else
            {
                g16arMskRptF2hOfst[gsRwCtrl.u16MskRptF2hBasePtr+uQueIdx]=c16BitFF;
            }

            uMaxSrchCnt--;
            rmPopNbsQue;
        }
    }
    while(uMaxSrchCnt);
}    /* getSrchResult */

void mskRptF2hTab()
{
    BYTE uMskPtr, uMskCnt, uMskCnt2;    // , u4kPtr;
    LWORD u32Haddr;

    if(!gsRwCtrl.uMaskTgtPtr)
    {
        return;
    }

    rmEnQuickSrch;

    /*
       * while(uMskPtr!=gsRwCtrl.uProgFifoHead)
       * {
       * for(u4kPtr=0; u4kPtr<g4kNumPerPage; u4kPtr++)
       * {
       * rmSetSrchTgt(uMskCnt, (garDesF2hInfo[uMskPtr].u16arHBlock[u4kPtr]<<16)|garDesF2hInfo[uMskPtr].u16arHPage[u4kPtr]);
       * uMskCnt++;
       * }
       *
       * uMskPtr=addWrFfPtrBy1(uMskPtr);
       * }
       */
    uMskCnt=gsRwCtrl.uMaskTgtPtr;

    while(uMskCnt>cSrchEnginDepth)
        ;

    uMskCnt=0;
    uMskCnt2=gsRwCtrl.uMaskTgtPtr-1;

    while(uMskCnt<uMskCnt2)
    {
        u32Haddr=rmGetSrchTgt(uMskCnt);

        if(u32Haddr!=c32BitFF)
        {
            rmSetSrchTgt(uMskCnt, c32BitFF);
            rmSetSrchThVal(u32Haddr);

            if(rmChkSrchTgt32Vld)
            {
                // garDesF2hInfo[uMskPtr].u16arHBlock[u4kPtr]=c16BitFF;
                uMskPtr=(uMskCnt/g4kNumPerPage)+gsRwCtrl.u32SrchFifoPtr;

                if(uMskPtr>(cWriteFifoDpt-1))
                {
                    uMskPtr-=cWriteFifoDpt;
                }

                garDesF2hInfo[uMskPtr].u16arHBlock[uMskCnt&(g4kNumPerPage-1)]=c16BitFF;
            }
        }

        uMskCnt++;
        // }

        // uMskPtr=addWrFfPtrBy1(uMskPtr);
    }

    gsRwCtrl.uMaskTgtPtr=0;
    rmDisQuickSrch;
}    /* mskRptF2hTab */

BYTE srchDataInF2h()
{
    // BYTE uSrchCnt=0, uSrchPtr=gsRwCtrl.u32SrchFifoPtr, u4kPtr;
    BYTE uSrchCnt=0, uMskCnt=gsRwCtrl.uMaskTgtPtr;
    // WORD u16Hblock;
    LWORD u32Haddr;

    if(!gsRwCtrl.uMaskTgtPtr)
    {
        return 0;
    }

    while(uMskCnt<cSrchEnginDepth)
    {
        rmSetSrchTgt(uMskCnt, c32BitFF);
        uMskCnt++;
    }

    while(uSrchCnt<uMskCnt)
    {
        u32Haddr=rmGetSrchTgt(uSrchCnt);

        if(u32Haddr!=c32BitFF)
        {
            rmSetNbsSrchTgt(uSrchCnt, u32Haddr);
        }
        else
        {
            rmSetNbsSrchTgt(uSrchCnt, 0xFFFF0000);
        }

        uSrchCnt++;
    }

    rmSetNbsActBitVal(c32BitFF);

    while(uSrchCnt>cSrchEnginDepth)
        ;

    return uSrchCnt;
}    /* srchDataInF2h */

void updateF2hTable(LWORD u32ProgFifoHead)
{
    WORD u16Hblock, u16Hpage;
    BYTE uPlanePtr, uPlaneCnt;

#if (_ENABLE_HMB_FLUSH)
    BYTE uSgmtIdx;
#endif
    // F2HTABLE *upF2hTab=garCacheF2hTab+gsCacheInfo.u16CacheF2hTabFreePtr;
    volatile LWORD *u32pF2h=(LWORD *)(&garCacheF2hTab[gsCacheInfo.u16CacheF2hTabFreePtr]);

    while(mChkCacheInfoFlag(cDataProgramFail))
        ;

    if(gsRwCtrl.u32UpdFifoPtr!=gsRwCtrl.u32SrchFifoPtr)
    {
        // invalidOldF2hEntry();
        getSrchResult(gsRwCtrl.uSrchQCntW);
        gsRwCtrl.u16MskRptF2hBasePtr=(gsRwCtrl.u16MskRptF2hBasePtr+gsRwCtrl.uSrchQCntW)&(c16MskRptF2hOfstDpt-1);
        gsRwCtrl.uSrchQCntW=0;

#if _ENABLE_HMB_FLUSH
        // reload g32arH2f1kTabSgmt to quick search feature, whick replace by mask F2h
        for(uSgmtIdx=0; uSgmtIdx<cMaxRH2fTabNum; uSgmtIdx++)
        {
            rmSetSrchTgt(uSgmtIdx, g32arH2f1kTabSgmt[uSgmtIdx]);
        }
#endif
    }

    while(gsRwCtrl.u32UpdFifoPtr!=gsRwCtrl.u32SrchFifoPtr)
    {
#if _EN_DEBUGF2H
        while(garDesAddrInfo[gsRwCtrl.u32UpdFifoPtr].u32FPageNoTran!=gsCacheInfo.u32CacheFreePagePtr)
            ;
#endif
        uPlanePtr=0;
        uPlaneCnt=g4kNumPerPage;

        while(uPlaneCnt!=0)
        {
#if _EN_DEBUGF2H
            while(!(*u32pF2h&c32Bit31))
                ;
#endif
            u16Hblock=garDesF2hInfo[gsRwCtrl.u32UpdFifoPtr].u16arHBlock[uPlanePtr];
            u16Hpage=garDesF2hInfo[gsRwCtrl.u32UpdFifoPtr].u16arHPage[uPlanePtr];

            // upF2hTab->u16HBlock=u16Hblock;
            // upF2hTab->u16HPage=garDesF2hInfo[gsRwCtrl.uUpdFifoPtr].u16arHPage[0][uPlanePtr];    // u16Hpage;
            *u32pF2h=(u16Hblock<<16)|u16Hpage;

#if (_ENABLE_HMB_FLUSH&&(!_PRJ_BOOT||_ICE_LOAD_ALL))
            if((gsHmbInfo.uHmbEnable)&&(!(u16Hblock&c16Bit15))&&(mChkHmbLink(u16Hblock)||(gsHmbInfo.usHmbList.u16Cnt<g16HmbMaxTableNum)))
            {
                *u32pF2h|=c32Bit31;    // upF2hTab->u16HBlock|=c16Bit15;
                modifyH2f1kTabByF2h(u16Hblock, u16Hpage, gsCacheInfo.u32CacheFreePagePtr+uPlanePtr);

                while(mChkSrcInCache(u16Hblock))
                    ;// debug purpose

                // workaround: avoid to search F2h in read flow. In this case, it should find src from RH2f1k table or HMB.
            }
            else
#endif/* if _ENABLE_HMB_FLUSH */

            if((u16Hblock!=c16BitFF)&&!mChkSrcInCache(u16Hblock))
            {
                mSetSrcInCache(u16Hblock);    // Update Hblock Bit Map [CC]
            }

            // upF2hTab--;
            u32pF2h--;
            uPlanePtr++;
            uPlaneCnt--;
        }

        gsCacheInfo.u32CacheFreePagePtr+=g4kNumPerPage;
        gsRwCtrl.u16ProgPageOfst-=g4kNumPerPage;

        if(gsCacheInfo.u16CacheF2hTabFreePtr>g4kNumPerPage)
        {
            gsCacheInfo.u16CacheF2hTabFreePtr-=g4kNumPerPage;    // 0xFFFF: F2hTab is Full, temp condition before progCacheF2h ready.
        }
        else
        {
            if(gsCacheInfo.u16FluCacheBlock!=c16FBlockInitValue)
            {
                decFluF2hTabPtr();
            }

            convrVarActCache2FluCache();
            gsCacheInfo.u16CacheF2hTabFreePtr=gsCacheInfo.u16TotalPgPerF2hTab-1;
            gsCacheInfo.uF2hTabBank++;
            // gsRwCtrl.u16ProgPageOfst=0;
            setCacheBlockFull();
        }

        gsRwCtrl.u32UpdFifoPtr=addWrFfPtrBy1(gsRwCtrl.u32UpdFifoPtr);
    }

    if(gsRwCtrl.u32SrchFifoPtr!=u32ProgFifoHead)
    {
        gsRwCtrl.uSrchQCntW=srchDataInF2h();
        mskRptF2hTab();
        gsRwCtrl.u32SrchFifoPtr=u32ProgFifoHead;
    }
}    /* updateF2hTable */

// cBit0: skip wait ce, for flush cache use
BYTE chkWriteDataDone()    // BYTE uOpt)
{
#if (_PRJ_ISP)
    chkTrigHostWrQue(0);
#endif

    while(gsRwCtrl.u32UpdFifoPtr!=gsRwCtrl.u32ProgFifoHead)
    {
        updateF2hTable(gsRwCtrl.u32ProgFifoHead);
    }

    while((gsRwCtrl.u32ProgFifoTail!=gsRwCtrl.u32ProgFifoHead)&&!mChkHandlePcieErrF)
        ;

    if(mChkHandlePcieErrF)
    {
        disSysTmr();
        enSysTmr(cPcieErrHoldVal);

        while(!gCpu0TOFlag)
            ;

        disSysTmr();

        if(gsRwCtrl.u32ProgFifoTail!=gsRwCtrl.u32ProgFifoHead)
        {
            tracePcieEvent(cDebugRwDigit|7);
            mSetToDoHdlPcieWErrF;
            mSetDesFullOnPcieWErrF;
            gsPcieErrInfo.u16GetWrPrdTailPtr=gsPrdInfo.usWritePrdList.u16Tail;
            return cFalse;
        }
    }

    return cTrue;
}    /* chkWriteDataDone */

#endif/* if (_PRJ_ISP||_PRJ_BOOT||_PRJ_SMIVU||_PRJ_SEC) */

#if (_PRJ_ISP||_PRJ_SMIVU||_PRJ_NVME)
WORD srchSrcInF2hTab(WORD u16Hblock, WORD u16Hpage)
{
    LWORD u32F2hHitPtr;

    u32F2hHitPtr=bopSrchRam((LWORD)garCacheF2hTab,
                            (LWORD)((u16Hblock<<16)+u16Hpage),
                            c32BitFF,
                            0,
                            g16TotalPgPerF2hTab,    // g32MaxCachePageNum,
                            cBopSrchDat|cBopLwordMo|cBopWait);

    // g16F2hTabHitPtr=(WORD)u32F2hHitPtr;

    if(u32F2hHitPtr!=c16BitFF)
    {
        if(u32F2hHitPtr>gsCacheInfo.u16CacheF2hTabFreePtr)
        {
            gsCacheInfo.u16SrchRslFBlock=gsCacheInfo.u16ActiveCacheBlock;
            gsCacheInfo.u32SrchRslFPage=gsCacheInfo.u32SrchF4kBase-u32F2hHitPtr;
        }
        else
        {
            gsCacheInfo.u16SrchRslFBlock=gsCacheInfo.u16FluCacheBlock;
            gsCacheInfo.u32SrchRslFPage=gsCacheInfo.u32SrchF4kBaseFlu-u32F2hHitPtr;
        }

        // return cTrue;
    }

    // else
    // {
    //    return cFalse;
    // }
    return u32F2hHitPtr;
}    /* srchSrcInF2hTab */

#if _ENABLE_HMB_FLUSH

BYTE flushCacheHmbTab()
{
    WORD u16HmbIdx;
    WORD u16Hblock;
    WORD u16H2fWrOpt;
    WORD u16NotRdyHblk;
    BYTE uSgmtIdx;
    BYTE uLoop, uProgCacheInfo=cFalse;

    while(!gBootDone)
        ;

    for(uSgmtIdx=0; uSgmtIdx<cMaxRH2fTabNum; uSgmtIdx++)
    {
        // release all sgmts, and upload to HMB if dirty
        if(mChkRH2fTabDirty(uSgmtIdx))
        {
            modifyHmbByH2f1kTab(uSgmtIdx);
        }
    }

    // workaround: avoid to download the latest upload H2f table which is not ready.
    u16NotRdyHblk=g16WriteHMBH2FTable[subPtrBy1(gWriteHMBIndex, cHmbRacingFreeCnt)];

    for(uLoop=0; uLoop<cHmbRacingFreeCnt; uLoop++)
    {
        g16WriteHMBH2FTable[uLoop]=c16Null;
    }

    gWriteHMBIndex=0;

    while(gsHmbInfo.u16HmbLastDirtyPtr!=c16Null)
    {
        if(mChkCacheInfoFlag(cH2fTabBlockFull))
        {
            // TODO: 1. skip check erase status. 2. think about rdlink
            initH2fTabFblock(cPopSkipChkSts);

            if(prepopBlkChkStatusCore0(cPopMinErsCnt|cPopSlcBlock|cPopSkipErsCmd))
            {
                while(1)
                    ;

                // g16arH2fTabBlk[gsCacheInfo.uActH2fTabBlkIdx]=popSpareBlockCore0(cPopMinErsCnt|cPopSlcBlock);    // gsTskFifoCtrl.u16PopFBlk;
            }
            else
            {
                g16arH2fTabBlk[gsCacheInfo.uActH2fTabBlkIdx]=gsTskFifoCtrl.u16PopFBlk;
            }
        }

        u16HmbIdx=gsHmbInfo.usHmbList.u16Tail;
        u16Hblock=g16arH2fBackup[u16HmbIdx];

        // workaround
        if((g16arH2fBackup[u16HmbIdx]==u16NotRdyHblk)&&    // if current Hblock is latest upload h2f,
           (gsHmbInfo.u16HmbLastDirtyPtr!=u16HmbIdx))    // and there are another dirty H2f
        {
            // flush next h2f and wait previous h2f ready.
            u16HmbIdx=gsHmbInfo.uarHmbLink[u16HmbIdx].u16Next;

            while(u16HmbIdx==c16Null)
                ;

            u16Hblock=g16arH2fBackup[u16HmbIdx];
        }

        u16NotRdyHblk=0xFFFF;

        u16H2fWrOpt=c16Bit0|c16Bit1|c16Bit2    /*|c16Bit3*/|c16Bit15;
        mWaitHmbRelease(1);
        swapH2fTable(u16Hblock, c16H2fTabSIdx, cSetBufferFlag);

        // while(waitHitBufDatRdy(c16H2fTabSIdx+120)!=cTrue)

        if((gsCacheInfo.u16H2fTabFreePagePtr>=(gsCacheInfo.u16H2fTabPagePerBlk3-1))&&(!mChkGcFlag(cGcSkipPrgCacheInfo)))
        {
            mSetGcFlag(cGcSkipPrgCacheInfo);    // notice
        }

        mSetCacheInfoChangeFlag(cH2fChg);    // gsCacheInfo.ubH2fChg=1;
        progH2fTableCore0(c16H2fTabSIdx, u16Hblock, u16H2fWrOpt, cInflushCacheF2hTab_00, 0    /*cBypassWaitChDone*/);    // temp disable
                                                                                                                         // cBypassWaitChDone
                                                                                                                         // for replacing spare
                                                                                                                         // byte issue.

        while(mChkCacheInfoChangeFlag(cH2fChg))
            ;

        insertHmbDirtyLink(u16Hblock, cFalse);
    }

    rstH2F1KInfo();

    if(mChkGcFlag(cGcSkipPrgCacheInfo))    // gsCacheInfo.ubSkipPrgCacheInfo)
    {
#if ((!_PRJ_BOOT)||_ICE_LOAD_ALL)
        mClrCacheInfoChangeFlag(cH2fChg);
        waitAllChCeBzCore0();
#if _GREYBOX
        if((gsGbInfo.uGreyBoxItem==cUGSDProgWPROID)&&
           ((gsGbInfo.uGreyBoxOpt==cVOpProgCacheInfoH2fFull)||(gsGbInfo.uGreyBoxOpt==cVOpProgCacheInfoH2fFullDone))&&
           (gsGbInfo.uStag==cVsIdl))
        {
            trigGreyBox(cTrue);
        }
#endif
        progCacheInfoTab();
        uProgCacheInfo=cTrue;
#endif
        mClrGcFlag(cGcSkipPrgCacheInfo);
    }

    return uProgCacheInfo;
}    /* flushCacheHmbTab */

void modifyHmbByH2f1kTab(BYTE uSgmtIdx)
{
    WORD u16Hblock=g32arH2f1kTabSgmt[uSgmtIdx]>>16;
    WORD u16Hsgmt=g32arH2f1kTabSgmt[uSgmtIdx]&c16BitFF;

    mWaitHmbRelease(1);
    writeHmbH2fTabSgmt(c16H2fTabSIdx+(uSgmtIdx<<2), u16Hblock, u16Hsgmt, cHmbDirtyH2f);
    mClrRH2fTabDirty(uSgmtIdx);
}

void modifyH2f1kTabByF2h(WORD u16Hblock, WORD u16Hpage, LWORD u32NewSrcFpg)
{
    LWORD *upH2fTab;
    LWORD u32H2f1kTabSgmt;
    // WORD u16OrgFblk;
    WORD u16Hsgmt;
    WORD u16HmbIdx;
    BYTE uSgmtIdx;

    while(!gsHmbInfo.uHmbEnable)
        ;

    u16Hsgmt=u16Hpage>>9;
    u32H2f1kTabSgmt=(LWORD)(u16Hblock<<16)|u16Hsgmt;

    uSgmtIdx=srchH2f1kTabSgmt(u32H2f1kTabSgmt);

    if(!mChkHmbLink(u16Hblock))
    {
        gsCacheInfo.uH2f1kSgmtFreePtr=0;

        for(uSgmtIdx=0; uSgmtIdx<cMaxRH2fTabNum; uSgmtIdx++)
        {
            u32H2f1kTabSgmt=(LWORD)(u16Hblock<<16)|uSgmtIdx;
#if _ENABLE_RAID
            setH2f1kTabSgmt(u32H2f1kTabSgmt, cMaxRH2fTabNum);
#else
            setH2f1kTabSgmt(u32H2f1kTabSgmt);
#endif
        }

        uSgmtIdx=u16Hsgmt;
        gsCacheInfo.uH2f1kSgmtFreePtr=subPtrBy1(uSgmtIdx, cMaxRH2fTabNum);

        swapH2fTable(u16Hblock, c16RH2fTabSIdx, cWaitReadDone);

        mWaitHmbRelease(1);

        while(gsHmbInfo.usHmbList.u16Cnt>g16HmbMaxTableNum)
            ;

        writeHmbH2fTab(c16H2fTabSIdx, u16Hblock, cHmbDirtyH2f);
        mWaitHmbTransferDone();    // TODO: workaround
    }
    else if(uSgmtIdx==0xFF)
    {
        // partial download 2KB from HMB
        u16HmbIdx=mGetHmbLink(u16Hblock);
#if _ENABLE_RAID
        uSgmtIdx=setH2f1kTabSgmt(u32H2f1kTabSgmt, cMaxRH2fTabNum);
#else
        uSgmtIdx=setH2f1kTabSgmt(u32H2f1kTabSgmt);
#endif
        mSetH2f1kTabSgmtPrep(uSgmtIdx);
        mWaitHmbRelease(1);
        readHmbH2fTabSgmt(c16RH2fTabSIdx+(uSgmtIdx<<2), u16Hblock, u16Hsgmt, uSgmtIdx, 0);    // cHmbBufflagChk|cHmbBufflagInv  ??
        gsRwCtrl.uarTab2PrdPtr[uSgmtIdx]=0xFF;
        mWaitHmbReadDone(uSgmtIdx);
    }

    // TODO: move to release HMB prd
    while(!mChkHmbLink(u16Hblock))
        ;

    u16HmbIdx=mGetHmbLink(u16Hblock);

    if(!mChkHmbTabDirty(u16HmbIdx))
    {
        insertHmbDirtyLink(u16Hblock, cTrue);
    }

    mSetRH2fTabDirty(uSgmtIdx);

    // get old src addr, update valid count
    upH2fTab=&garH2f1kTable[uSgmtIdx][u16Hpage&(c16RH2fTabSize-1)];
    setH2fSrcBlock(upH2fTab, gsCacheInfo.u16ActiveCacheBlock, u32NewSrcFpg, gbLsbOnlyCurActCBlk, cTrue);
}    /* modifyH2f1kTabByF2h */

#endif/* if (_ENABLE_HMB_FLUSH) */
#endif/* if (_PRJ_ISP||_PRJ_SMIVU) */







