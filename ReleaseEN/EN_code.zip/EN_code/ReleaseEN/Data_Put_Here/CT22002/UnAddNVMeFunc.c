







void enAllChStop(BYTE uStop)
{
    gsFtlDbg.u16DummyFailType=cEnAllChStop;
    debugWhile();
}    /* enAllChStop */

void disAllChStop(BYTE *upStopBK)
{
    gsFtlDbg.u16DummyFailType=cDisAllChStop;
    debugWhile();
}    /* disAllChStop */

void ctrlScrbBothAndEcc(BYTE uScrbMode, BYTE uEccMode)
{
    gsFtlDbg.u16DummyFailType=cCtrlScrbBothAndEcc;
    debugWhile();
}    /* ctrlScrbBothAndEcc */

void flashReadPage()
{
    gsFtlDbg.u16DummyFailType=cFlashReadPage;
    debugWhile();
}

void flashProgPage(WORD u16Buf, BYTE uHalfKB, WORD u16Opt)
{
    gsFtlDbg.u16DummyFailType=cFlashProgPage1;
    debugWhile();
}

void flashErase(WORD u16Opt)
{
    gsFtlDbg.u16DummyFailType=cFlashErase;
    debugWhile();
}

void setSprByteforTest(BYTE uPlaneAddr, WORD u16Spr0, WORD u16Spr1, WORD u16Spr2, WORD u16Spr3, BYTE uTabID, LWORD u32Serial)
{
    gsFtlDbg.u16DummyFailType=cSetSprByteforTest;
    debugWhile();
}

BYTE tranDieIdx2Pba(BYTE uDieIdx, BYTE *upCh, BYTE *upCe, BYTE *upDie)
{
    gsFtlDbg.u16DummyFailType=cTranDieIdx2Pba;
    debugWhile();
}







