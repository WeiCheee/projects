







#include "inc/Option.h"
#include "inc/TypeDef.h"
#include "inc/Reg.h"
#include "inc/GlobVar0.h"
#include "inc/BitDef.h"
#include "inc/ProType.h"

#define cI2cTimeout                 20000

// I2C error code definition.
#define cI2cStsOk          0    // Success
#define cI2cStsFail        1    // Fail, something wrong
#define cI2cStsNoAck       2    // Slave device no response

BYTE i2cChkAck()
{
    WORD uTo=0;

    while(cI2cTimeout>uTo++)
    {
        if(rmI2cImflag)
        {
            rmI2cClrImflag;    // clear imflag
            return cI2cStsOk;
        }

        // release H/W bus resource
        _nop();
        _nop();
        _nop();
    }

    rmI2cClrImflag;    // clear imflag
    return cI2cStsNoAck;
}    /* i2cChkAck */

void i2cInit()
{
    rmI2cDisable;
    _nop();
    _nop();
    _nop();
    rSysCtrl0[rcSysI2cDri]=0x13;
    rmI2cClkPre=255;    // CSSD-2043, CSSD-2044
    rmI2cEn;
    rmI2cDisInt;
    rmNackn;
}

BYTE i2cMasterStart()
{
    rmI2cCmdStart;    // i2c start

    return i2cChkAck();
}

BYTE i2cMasterStop()
{
    rmI2cCmdStop;    // i2c stop

    return i2cChkAck();
}

BYTE i2cMasterTxData(BYTE uData)
{
    rmI2cTxd0=uData;
    rmI2cSendData;

    return i2cChkAck();
}

BYTE i2cMasterRxData(BYTE *upData)
{
    BYTE uResult=cI2cStsOk;

    rmI2cReceiveData;

    uResult=i2cChkAck();

    if(uResult==cI2cStsOk)
    {
        *upData=rmI2cRxd0;
    }

    return uResult;
}

static WORD computeTemperature(WORD u16Data)
{
    WORD u16Temp1;

    if(u16Data&c16Bit15)    // for negative temperatures(twos complement)
    {
        u16Temp1=((WORD)((((u16Data>>4)-1)^0x0FFF)*625/1000)+5);
        return (u16Temp1^0xFFFF)+1;
    }
    else    // for positive temperatures
    {
        u16Temp1=(WORD)((u16Data>>4)*625/1000)+5;
        return u16Temp1;
    }
}

BYTE I2cTemperatureSensor()
{
    BYTE data[2]={0};
    WORD temperaure=0;

    // Configuration Register
    i2cMasterStart();
    i2cMasterTxData(0x90);    // Two-Wire Slave Address Byte+Write_V+
    i2cMasterTxData(0x01);    // Configuration Register Byte

    i2cMasterTxData(0x60);    // MSB of Configuration Register
    i2cMasterTxData(0xA0);    // LSB of Configuration Register
    i2cMasterStop();

    // Temperature Register
    i2cMasterStart();
    i2cMasterTxData(0x90);    // Two-Wire Slave Address Byte+Write_V+
    i2cMasterTxData(0x00);    // Temperature Register Byte
    i2cMasterStop();

    i2cMasterStart();
    i2cMasterTxData(0x91);    // Two-Wire Slave Address Byte+Read_V+
    i2cMasterRxData(&data[0]);    // MSB of Temperature Register
    i2cMasterRxData(&data[1]);    // LSB of Temperature Register
    i2cMasterStop();

    temperaure=(data[0]<<8|data[1]);

    return (computeTemperature(temperaure))/10;
}    /* I2cTemperatureSensor */

#if 1
void i2cSetPmicAct88325_Active()    // ken test VOP 0.9=>0925
{
    BYTE uStatus=0;

    i2cMasterStart();

    uStatus=i2cMasterTxData(0x4A);    // Write ACT88325 (Device Address 7h'25)

    if(uStatus)
    {
        return;    // Can not found PMIC device
    }

    i2cMasterTxData(0x42);    // Set Buck2 Sleep Voltage register
    i2cMasterTxData(0x24);    // Set Buck2 PS4 sleep at 0.75V
    i2cMasterStop();
}

#endif/* if 1 */
void i2cSetPmicAct88325()
{
    BYTE uStatus=0;

    i2cMasterStart();

    uStatus=i2cMasterTxData(0x4A);    // Write ACT88325 (Device Address 7h'25)

    if(uStatus)
    {
        return;    // Can not found PMIC device
    }

    i2cMasterTxData(0x43);    // Set Buck2 Sleep Voltage register

    if(i2cSetPS4CoreIndex[0]!=0x01)
    {
        NLOG(cLogBuild, I2CCTRL_C, 0, " Core Power VSET=0x13");
        i2cMasterTxData(0x13);    // 0.778V
    }
    else
    {
        if(i2cSetPS4CoreIndex[1]<4)
        {
            NLOG(cLogBuild, I2CCTRL_C, 0, " Core Power VSET=0x15");

            i2cMasterTxData(0x15);    // 0.796V
        }
        else if(i2cSetPS4CoreIndex[1]<8)
        {
            NLOG(cLogBuild, I2CCTRL_C, 0, " Core Power VSET=0x13");

            i2cMasterTxData(0x13);    // 0.778V
        }
        else if(i2cSetPS4CoreIndex[1]<12)
        {
            NLOG(cLogBuild, I2CCTRL_C, 0, " Core Power VSET=0x10");

            i2cMasterTxData(0x10);    // 0.750V
        }
        else
        {
            NLOG(cLogBuild, I2CCTRL_C, 0, " Core Power VSET=0x13");

            i2cMasterTxData(0x13);    // 0.778V
        }
    }

    i2cMasterStop();
}    /* i2cSetPmicAct88325 */







