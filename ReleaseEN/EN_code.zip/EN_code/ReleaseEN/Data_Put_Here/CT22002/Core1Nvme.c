







// #if (_CPUID!=1)
#include "inc/Const.h"
#include "inc/TypeDef.h"
#include "inc/Option.h"
#include "inc/ProType.h"
#include "inc/GlobVarS.h"
#include "inc/GlobVar1.h"
#include "inc/GlobVarT.h"
#include "inc/NvmeCtrl.h"
#include "inc/BitDef.h"
#include "inc/NvmeCtrl.h"
#include "inc/Reg.h"
#include "inc/Mac.h"

#if (_GREYBOX)
#include "inc/GreyBox.h"
#endif

#include "inc/DebugLog.h"
#include "inc/EventLogIDX.h"
#include "inc/EventLogFunctionIDX.h"

#pragma default_function_attributes = @ ".CORE1_ISP"

#include "FwCommitDlCore1.c"
#include "FlashCmdSwap.c"
#include "ProgFail.c"

void rstCacheInfoTab(BYTE uMode)
{
    WORD u16Idx;
    WORD u16MaxPushSpareCnt=gsFtlDbg.u16MaxPushSpareCnt;
    WORD u16MinSpareBlockCnt=gsFtlDbg.u16MinSpareBlockCnt;
    // WORD u16RebuGcDesF2hCnt=g16RebuGcDesF2hCnt;
    LWORD u32WearLevelCnt=g32WearLevelCnt;
    LWORD u32ForceCleanCnt=gsFtlDbg.u32ForceCleanCnt;
    LWORD u32PowerOnCnt=gsFtlDbg.u32PowerOnCnt;

#if _EN_VPC_SWAP
    bopClrRam((LWORD)g32arMlcMoBit, c16MaxBlockNum/8, 0x00000000, cClrTsb|cBopWait);
    bopClrRam((LWORD)g32arSkipGcSrch, c16MaxBlockNum/8, 0xFFFFFFFF, cClrTsb|cBopWait);
    bopClrRam((LWORD)g32arVPCntValid, c16MaxBlockNum/8, 0x00000000, cClrTsb|cBopWait);
    bopClrRam((LWORD)g32arCacheBlkVpCnt, c16MaxBlockNum*4, 0x00000000, cClrTsb|cBopWait);
#else
    bopClrRam((LWORD)g32arCacheBlkVpCnt, c16MaxBlockNum*4, c32Bit31, cClrTsb|cBopWait);
#endif
    bopClrRam((LWORD)&g32GcSkipSrcHblkSrch, c16MaxH2fTabNum/8, 0x00000000, cClrTsb|cBopWait);
    // bopClrRam((LWORD)g32arSeedOfst, c16MaxBlockNum/32*2*4, 0x0000_0000, cClrTsb|cBopWait);
    // bopClrRam((LWORD)garH2fTabBlkIndex, (LWORD)g32arDiffType2BitTab-(LWORD)garH2fTabBlkIndex, 0xFFFF_FFFF, cClrTsb|cBopWait);
    // bopClrRam((LWORD)g16arH2fTabPagePtr, (LWORD)g32arGcSrcBlkBitMap-(LWORD)g16arH2fTabPagePtr, 0xFFFFFFFF, cClrTsb|cBopWait);    // kenneth
    bopClrRam((LWORD)g32arH2fTabBlkSn, c16MaxH2fTabBlkNum*4, 0xFFFFFFFF, cClrTsb|cBopWait);
    bopClrRam((LWORD)g16arH2fTabBlkVpCnt, c16MaxH2fTabBlkNum*2, 0x0, cClrTsb|cBopWait);
    bopClrRam((LWORD)g16arH2fTabPtr, (c16MaxH2fTabNum+c16HmbMaxTableNum)*2, 0xFFFFFFFF, cBopWait|cClrTsb);    // TSB1(Cache INFO)
    bopClrRam((LWORD)g16arH2fBackup, (c16HmbMaxTableNum)*2, 0xFFFFFFFF, cBopWait|cClrTsb);
    bopClrRam((LWORD)g16arH2fTabBlk, c16MaxH2fTabBlkNum*2, 0xFFFFFFFF, cBopWait|cClrTsb);    // TSB1(Cache INFO)
    bopClrRam((LWORD)g32arH2fTable, c32H2fTabRamSize, 0xFFFFFFFF, cBopWait|cClrTsb);    // TSB1(H2F_TAB0) //ADDN
    bopClrRam((LWORD)g16arRaidParityPtr, cRaidParityPageNum*2, 0xFFFFFFFF, cBopWait|cClrTsb);    // TSB1(Cache INFO)
    bopClrRam((LWORD)g16arRaidParityBlk, cRaidParityBlockNum*2, 0xFFFFFFFF, cBopWait|cClrTsb);    // TSB1(Cache INFO)
    bopClrRam((LWORD)g16arRaidPtyBlkVpCnt, cRaidParityBlockNum*2, 0x00000000, cBopWait|cClrTsb);    // TSB1(Cache INFO)
    bopClrRam((LWORD)g32arGcSrcBlkBitMap, c16MaxBlockNum/8, 0x0, cClrStcm|cBopWait);

    g16PushSpareCnt=g16PushSpareTail=g16PushSpareHead=0;

    gsFtlDbg.u16MaxPushSpareCnt=u16MaxPushSpareCnt;
    gsFtlDbg.u16MinSpareBlockCnt=u16MinSpareBlockCnt;
    // g16RebuGcDesF2hCnt=u16RebuGcDesF2hCnt;
    g32WearLevelCnt=u32WearLevelCnt;

    gsFtlDbg.u32ForceCleanCnt=u32ForceCleanCnt;
    gsFtlDbg.u32PowerOnCnt=u32PowerOnCnt;

    g32BkRdActCBlkSerial=0;
    g32BkRdFlsCBlkSerial=0;
    g32BkRdCacheFreePagePtr=0;

    g16BkCacheF2hTabFreePtr=g16TotalPgPerF2hTab-1;    // SLC cache only
    g16BkRdActiveCacheBlock=c16FBlockInitValue;
    g16BkRdFlushCacheBlock=c16FBlockInitValue;

    gBkRdActF2hTabBank=0x0;
    gBkRdFlsF2hTabBank=0x0;
    g32MaxS2TGCtime=0;
    g32MaxT2TGCtime=0;

    // bopClrRam((LWORD)garChildOrder, 0x0000_0040, 0xFFFF_FFFF, cClrTsb|cBopWait);
    // bopClrRam((LWORD)g32arGcSrcBlkBitMap, 0x0000_1000, 0x0000_0000, cClrTsb|cBopWait);
    // bopClrRam((LWORD)g32arGcSrcBlkBitMap, (LWORD)gSetMaxPassWord-(LWORD)g32arGcSrcBlkBitMap, 0x00000000, cClrTsb|cBopWait);
    bopClrRam((LWORD)garCacheF2hTab, c32CacheF2hRamSize, 0xFFFFFFFF, cClrTsb|cBopWait);
    // bopClrRam((LWORD)garChildF2hTab, c32ChildF2hRamSize, 0xFFFF_FFFF, cClrTsb|cBopWait);
    // rmEnClrSkipRam;

    gsCacheInfo.u32CacheBlkSerial=c32InitSerialVal;
    gsCacheInfo.u32FluBlkSerial=c32InitSerialVal;
    gsCacheInfo.u32H2fTabBlkSerial=c32InitSerialVal;

    mSetCacheInfoFlag(cCacheBlockFull);
    mSetCacheInfoFlag(cH2fTabBlockFull);
    gsCacheInfo.uChkF2hRegion=0;
    gsCacheInfo.u16CacheF2hTabFreePtr=0;
    gsCacheInfo.u16CacheBlockCnt=0;
    gsCacheInfo.uH2fTabBlockCnt=0;
    gsCacheInfo.u16FullCacheBlockCnt=0;
    gsCacheInfo.u16TLCFullCacheBlockCnt=0;
    gsCacheInfo.u16HblkCntInCache=0;
    gsCacheInfo.u16ActiveCacheBlock=c16FBlockInitValue;
    gsCacheInfo.u16FluCacheBlock=c16FBlockInitValue;
    gsCacheInfo.u16H2fTabPagePerBlk3=(g16PagePerBlock3_SLC*gSectorPerPlaneH)/g16H2fTabSctrSize;
    // gsCacheInfo.u16ActiveH2fTab=c16BitFF;
    gsGcInfo.u32TotalSlcVpc=0;
    gsGcInfo.u32TotalTlcVpc=0;
    // rstH2F1KInfo();
    rmAutoClrSkipRam;
    gsCacheInfo.u16MlcMoSkipCnt=0;
    gsCacheInfo.u16SlcMoSkipCnt=0;

    gsCacheInfo.u16RaidPtyPagePerBlk3=(g16PagePerBlock3_SLC*gSectorPerPlaneH)/cRaidDataSctrNum;
    gsCacheInfo.u16RaidPtyFreePagePtr=c16BitFF;
    gsCacheInfo.u16RaidGcPtyFreePagePtr=c16BitFF;
    gsCacheInfo.uRaidPtyBlockCnt=0;
    gsCacheInfo.uRaidPtyBlkIdx=0;
    gsCacheInfo.uRaidGcPtyBlkIdx=0;

    for(u16Idx=g16FirstFBlock; u16Idx<g16TotalFBlock; u16Idx++)
    {
        if(u16Idx<g16StaticBound)
        {
            mClrMlcMoBit(u16Idx);
        }
        else
        {
            mSetMlcMoBit(u16Idx);
        }

        if(mChkMlcMoBit(u16Idx))
        {
            gsCacheInfo.u16SlcMoSkipCnt++;
        }

#if !_EN_Dynamic_Fix_Boundary
        if(!mChkMlcMoBit(u16Idx))
        {
            mClrMlcMoBit(u16Idx);
            gsCacheInfo.u16MlcMoSkipCnt++;
        }
#endif
    }

    for(u16Idx=0; u16Idx<cMaxGcSrcBlkNum; u16Idx++)
    {
        gsGcInfo.u16GcSrcBlock[u16Idx]=cInvldFBlk;
        gsGcInfo.uGcSrcBlkIdx[u16Idx]=u16Idx;
    }

    for(u16Idx=0; u16Idx<cMaxGcPrioBlkNum; u16Idx++)
    {
        gsGcInfo.u16Gc1stPrioTlcBlock[u16Idx]=0xFFFF;
        gsGcInfo.uGc1stPrioTlcBlockTyp[u16Idx]=0xFF;
        gsGcInfo.u16GcRCSlcBlock[u16Idx]=0xFFFF;
    }

    funcTskInitSlcQ(0);
    gsGcInfo.u32GcFlag=0;
    mSetGcFlag(cStopBgdClean);
    gsGcInfo.u16GcDesBlock=c16FBlockInitValue;
    gsGcInfo.u32GcDesSerial=c32InitSerialVal;
    // gsGcInfo.u16GcInfoBlock=cInvldFBlk;
    gsGcInfo.u16MtCacheBlockCnt=0;
    mSetGcFlag(cGcDesFull);
    // mSetGcFlag(cGcInfobFull);
    gsGcInfo.u16GcDesSLCBlock=c16FBlockInitValue;
    gsGcInfo.u16GcDesTLCBlock=c16FBlockInitValue;
    gsGcInfo.uGcDesBlkCnt=0;
    gsGcInfo.uGcSrcBlkCnt=0;
    gsGcInfo.uGcWr4kPtr=gsGcInfo.uGcRd4kPtr=0;
    gsGcInfo.u32GcDesbFreePagePtr=0;
    gsGcInfo.uHmbGcCachePtr=0;
    gsGcInfo.uHmbGcCacheCnt=0;
    gsGcInfo.uGcTypBit=0;
    gsGcInfo.uGcQueueCnt=0;
    gsGcInfo.ubBgdProcF=0;
    gsGcInfo.uOneShotChPtr=0;
    gsGcInfo.uGcPrioTlcBlkNumPtr=0;
    gsGcInfo.uGCSLCReclaimPtr=0;
    gsGcInfo.u32GcMaxS2TProcTime=0;
    gsGcInfo.u32GcMaxT2TProcTime=0;

    while(gsGcInfo.uGcSkipPopSrcBlockCnt)
    {
        gsGcInfo.uGcSkipPopSrcBlockCnt--;
        gsGcInfo.u16arGcSkipPopSrcBlock[gsGcInfo.uGcSkipPopSrcBlockCnt]=cInvldFBlk;
    }

    u16Idx=cWproGcDesF2hTab00;

    do
    {
        if(gsWproInfo.u16arWproIdxPagePtr[u16Idx]!=0xFFFF)
        {
            while(!gsWproInfo.u16arVpCnt[mGetWproBlkIdx(u16Idx)])
                ;

            gsWproInfo.u16arVpCnt[mGetWproBlkIdx(u16Idx)]--;

            if((!gsWproInfo.u16arVpCnt[mGetWproBlkIdx(u16Idx)])&&(mGetWproBlkIdx(u16Idx)!=gsWproInfo.uActIdx))
            {
                gsWproInfo.u16arWproBlk[mGetWproBlkIdx(u16Idx)]=0xFFFF;
                gsWproInfo.uCnt--;

                while(!gsWproInfo.uCnt)
                    ;
            }

            gsWproInfo.u16arWproIdxPagePtr[u16Idx]=0XFFFF;
            gsWproInfo.uarWproIdxPtr[u16Idx]=0xFF;
        }

        u16Idx++;
    }
    while(u16Idx<=cWproGcInfoPage);

    mSetGcFlow(cGcFlowIdl);
    gsGcInfo.uGcState=cGcStateIdle;

#if _EN_SLCOpenBlkReadScrub
    gsGcInfo.u16FlushBlk=c16FBlockInitValue;
    gsGcInfo.uFlushState=cFlushIdle;
    gsCacheInfo.u16BakF2HTabFlushStart=0;
    gsCacheInfo.u16BakF2HTabFlushEnd=0;
#endif
    gsGcInfo.uOccTsbFlag=0;

    // fillCcmVal((BYTE *)&gsFwDlInfo, sizeof(gsFwDlInfo), 0x00);
    // gsFwDlInfo.uSysRsvFwDlImageBlk=0xFF;
    // gRdLkMigrateTyp=cNormalCacheInfoTyp;
    gBkFidBlock=0xFF;
    mRstCacheInfoSpf;
    mSetCacheInfoSpf(uMode);
}    /* rstCacheInfoTab */

void eraseTotalFBlock(BYTE uOption)
{
    ADDRINFO usTmpAddrInfo;
    WORD u16Fblock, u16ReliableErase=0;

    if(!(uOption&cBit2))
    {
#if (_GREYBOX)
        if((gsGbInfo.uGreyBoxItem==cUGSDSecureEraseID)&&(gsGbInfo.uGreyBoxOpt==cVOpProgCacheInfoBefEraseAll))
        {
            triggerUGSD(cTrue);
        }
#endif
        waitAllChCeBz();

        for(u16Fblock=g16FirstFBlock; u16Fblock<g16TotalFBlock; u16Fblock++)
        {
            if((mGetGlobEraseCnt(u16Fblock)!=c16BitFF)&&chkWproBlk(u16Fblock)&&(chkDiffType2Ptr(u16Fblock)==0xFF))
            {
                // &&(u16Fblock!=g16arSysBlock[cLogInfo]))
#if (_GREYBOX)
                if((gsGbInfo.uGreyBoxItem==cUGSDSecureEraseID)&&(gsGbInfo.uGreyBoxOpt==cVOpErasing))
                {
                    // if(u16Fblock==g16arH2fTabBlk[gsCacheInfo.uActH2fTabBlkIdx])
                    {
                        gsGbInfo.uStag=cVsTriggered;
                    }
                }
#endif
                usTmpAddrInfo.u16FBlock=u16Fblock;
                // usTmpAddrInfo.ubLsbOnly=0;
                // tranCeNum(&usTmpAddrInfo);
#if _EN_Dynamic_Fix_Boundary
                if(u16Fblock<g16StaticBound)
#else
                if(!mChkMlcMoBit(u16Fblock)&&(gsFtlDbg.uStaticMode==cEndStaticMode))
#endif
                {
                    u16ReliableErase=c16Bit3;
                }

                for(gActiveCh=0; gActiveCh<gTotalChNum; gActiveCh++)
                {
                    setFLAddrActCh(gActiveCh, &usTmpAddrInfo);

                    flashErase(c16Bit15|u16ReliableErase);
                }

                for(gActiveCh=0; gActiveCh<gTotalChNum; gActiveCh++)
                {
                    setFLAddrActCh(gActiveCh, &usTmpAddrInfo);
                    chkEraseStatus();
                }

                u16ReliableErase=0;

#if _EN_FLASH_WR_CMD
                flashWriteCmd(u16Fblock);
#endif
            }
        }
    }
}    /* eraseTotalFBlock */

void handleEraseCnt(WORD u16CacheInfoType, WORD u16TotalEraseCount, BYTE uTskTail, BYTE uMode)
{
    WORD u16Fblock;

    prog1stInvQBootInWpro();

#if _ENABLE_RAID
    initRaidEngine();
#endif

    if(g16PushSpareCnt)    // 20190313_Louis
    {
        chkPushSpareQ(0);
    }

    if(!mChkCacheInfoSpf(uMode))
    {
#if _EN_VPC_SWAP
        g32arCacheBlkVpCnt=(volatile LWORD *)(cCacheBlkVpCntHdlEraseStrAddr);
#endif
        rstCacheInfoTab(uMode);

#if !_EN_Always_DynamicMode
        gsCacheInfo.u16SpareBlockCnt=0;
        gsCacheInfo.u16TLCSprBlockCnt=0;
#endif
#if _EN_Dynamic_Fix_Boundary
        gsCacheInfo.u16SLCSpareCnt=0;
        gsCacheInfo.u16DynamicSpareCnt=0;
#if _EN_Always_DynamicMode
        gsCacheInfo.u16SpareBlockCnt=0;
#endif
#endif

#if _ENABLE_ATA_PASSTHROUGH
        if((gbEnATAPassThrough)&&(uMode==cSecurErase)&&(!(gsTskFifoCtrl.uarTskFifo[uTskTail].uTskOpt)))    // uDoNotChangeSecurityState==0
        {
            mSetCacheInfoSpf(cChangeSecurityState);
        }
#endif

        for(u16Fblock=g16FirstFBlock; u16Fblock<g16TotalFBlock; u16Fblock++)
        {
            if((mGetGlobEraseCnt(u16Fblock)!=c16BitFF)&&chkWproBlk(u16Fblock)&&(chkDiffType2Ptr(u16Fblock)==0xFF))
            {
#if (!_BypassEraseFlag)
                mSetEraseFlag(u16Fblock);
#endif

#if !_EN_Always_DynamicMode
                if(!mChkMlcMoBit(u16Fblock))
                {
                    gsCacheInfo.u16SpareBlockCnt++;
                }
                else
                {
                    gsCacheInfo.u16TLCSprBlockCnt++;
                }
#endif
#if _EN_Dynamic_Fix_Boundary
                if(u16Fblock<g16StaticBound)
                {
                    gsCacheInfo.u16SLCSpareCnt++;
                }
                else
                {
                    gsCacheInfo.u16DynamicSpareCnt++;
                }

#if _EN_Always_DynamicMode
                gsCacheInfo.u16SpareBlockCnt++;
#endif
#endif

                mClrPoppedBit(u16Fblock);

                if(mGetGlobEraseCnt(u16Fblock)<(c16BitFF-u16TotalEraseCount))
                {
                    if((uMode!=cSecurErase)&&(uMode!=cSanitize))    // 20181219_SamHu_01
                    {
                        mSetGlobEraseCnt(u16Fblock, (mGetGlobEraseCnt(u16Fblock)+u16TotalEraseCount));
                    }

#if (_EN_SLC_END_PARA)
                    if((u16Fblock<g16StaticBound)&&(mGetGlobEraseCnt(u16Fblock)>g32SlcMaxEraseCnt))
                    {
                        g32SlcMaxEraseCnt=mGetGlobEraseCnt(u16Fblock);

                        while(gsCacheInfo.u32SlcNextEraseCntThr==0)
                            ;

                        if(g32SlcMaxEraseCnt>gsCacheInfo.u32SlcNextEraseCntThr)
                        {
                            setSlcEndurPara();
                        }
                    }
                    else if((u16Fblock>=g16StaticBound)&&(mGetGlobEraseCnt(u16Fblock)>g32TlcMaxEraseCnt))
                    {
                        g32TlcMaxEraseCnt=mGetGlobEraseCnt(u16Fblock);
                    }
#endif/* if _EN_SLC_END_PARA */
                }
                else
                {
                    mSetGlobEraseCnt(u16Fblock, c16BitFF);
                }
            }
        }

#if _EN_VPC_SWAP
        // Prog Changed VPCnt
        progWproPage(cWproCacheBlkVpCnt, cCacheBlkVpCntHdlEraseStrIdx);
#endif

        progCacheInfoTab();
    }
}    /* handleEraseCnt */

void eraseUnitProgram()
{
    ADDRINFO usTmpAddrInfo;
    BLKSPRINFO usBlkSprInfo;
    WORD u16PagePerBlock1;
    BYTE uParamIndex, uPlaneAddr;    // uSkipInitBuffer=0;

    bopClrRam((LWORD)(BYTE *)&usTmpAddrInfo, sizeof(ADDRINFO), 0x00000000, cClrCore1Dccm|cBopWait);
    bopClrRam((LWORD)(BYTE *)&usBlkSprInfo, sizeof(BLKSPRINFO), 0x00000000, cClrCore1Dccm|cBopWait);

    uParamIndex=gsEraseUnitInfo.usCurrentOperation.uParamIndex;
    bopClrRam((LWORD)&garTsb0[0], gSectorPerPageH*512,
              gsEraseUnitInfo.usEraseParam.u32arPattern[uParamIndex], cClrTsb|cBopWait);

    waitAllChCeBz();

    gpFlashAddrInfo=&usTmpAddrInfo;
    g16FBlock=gsEraseUnitInfo.usCurrentOperation.u16NextFBlock;
    // gbLsbOnly=0;
    // setDiffAddr(gpFlashAddrInfo);
    // tranCeNum(gpFlashAddrInfo);
    gSectorH=0;

    mSetFRwParam(c16Tsb0SIdx, gSectorPerPageH, c16Bit0|c16Bit2|c16Bit15, cProgData);

    if(mChkMlcMoBit(g16FBlock))
    {
        u16PagePerBlock1=g16PagePerBlock1;
    }
    else
    {
        u16PagePerBlock1=g16PagePerBlock1_SLC;
    }

    for(g16FPage=0; g16FPage<u16PagePerBlock1; g16FPage++)
    {
        for(gIntlvAddr=0; gIntlvAddr<gIntlvWay; gIntlvAddr++)
        {
            for(gCh=0; gCh<gTotalChNum; gCh++)
            {
                setFLActCh(gCh);
                gSpareCnt[gCh]=cSpareUseOfSLC;
                usBlkSprInfo.u16Spr8.us2BYTE.HighByte=gOpTyp;
                usBlkSprInfo.u16Spr8.us2BYTE.LowByte=cSanitizeOwID;

                for(uPlaneAddr=0; uPlaneAddr<gPlaneNum; uPlaneAddr++)
                {
                    setSprByte(&usBlkSprInfo, uPlaneAddr);
                }

                waitCmdFifoDpt(gCh, gpFlashAddrInfo);
                waitChCeBz(gCh, gIntlvAddr, 0);
                flashProgPage(mGetWriteBuf, mGetProgSctrCnt, mGetWriteOpt);
                setBzInfo(gOpTyp, gCh, gIntlvAddr);
                gPlaneAddr=0;
                gSpareCnt[gCh]=cZero;
            }
        }
    }
}    /* eraseUnitProgram */

void eraseUnitVerifyData()
{
    ADDRINFO usTmpAddrInfo;
    LWORD u32Value;
    WORD u16UnitLen;
    BYTE uParamIndex;

    bopClrRam((LWORD)(BYTE *)&usTmpAddrInfo, sizeof(ADDRINFO), 0x00000000, cClrCore1Dccm|cBopWait);
    gpFlashAddrInfo=&usTmpAddrInfo;

    if(gsEraseUnitInfo.usEraseParam.uNeedVerify)
    {
        uParamIndex=gsEraseUnitInfo.usCurrentOperation.uParamIndex;

        g16FBlock=gsEraseUnitInfo.usCurrentOperation.u16NextFBlock;
        // gbLsbOnly=0;
        // setDiffAddr(gpFlashAddrInfo);
        // tranCeNum(gpFlashAddrInfo);

        u16UnitLen=gSectorPerPageH*(512/4);
        u32Value=(LWORD)gsEraseUnitInfo.usEraseParam.u32arPattern[uParamIndex];

        mSetFRwParam(c16Tsb0SIdx, gSectorPerPageH, c16Bit0|c16Bit4|c16Bit15, cReadData);

        for(g16FPage=0; g16FPage<g16PagePerBlock1; g16FPage++)
        {
            for(gIntlvAddr=0; gIntlvAddr<gIntlvWay; gIntlvAddr++)
            {
                bopClrRam((LWORD)&garTsb0[0], gSectorPerPageH*512, 0x00000000, cClrTsb|cBopWait);

                for(gCh=0; gCh<gTotalChNum; gCh++)
                {
                    setFLActCh(gCh);
                    waitCmdFifoDpt(gCh, gpFlashAddrInfo);
                    waitChCeBz(gCh, gIntlvAddr, 0);
                    flashReadPage();
                    gPlaneAddr=0;
                }

                bopSrchRam(c32Tsb0SAddr, u32Value, c32BitFF, 0, u16UnitLen, cBopSrchStat|cBopLwordMo|cBopWait);

                if((mGetGlobEraseCnt(g16FBlock)!=c16BitFF)&&(gbEccFail||(rmGetSrhResEquCnt!=u16UnitLen)))
                {
                    gsEraseUnitInfo.u32TotalFail++;
                }
            }
        }
    }
    else
    {
        gsEraseUnitInfo.usCurrentOperation.u16NextFBlock=(g16TotalFBlock-1);
    }
}    /* eraseUnitVerifyData */

// Bit0 clear erase count (for every physical block) .
// Bit2 do NOT erase all NAND Blocks
void funcTskEraseUnitProc(BYTE uTskTail)
{
    BYTE uOption=gsTskFifoCtrl.uarTskFifo[uTskTail].uTskOpt;

    handleEraseCnt(cInfuncTskEraseUnitProc_00, 1, uTskTail, cSecurErase);
    eraseTotalFBlock(uOption);
    waitAllChCeBz();
#if (_GREYBOX)
    if((gsGbInfo.uGreyBoxItem==cUGSDSecureEraseID)&&(gsGbInfo.uGreyBoxOpt==cVOpProgCacheInfoAfEraseAll))
    {
        gsGbInfo.uStag=cVsTriggered;
    }
#endif

    if(mChkCacheInfoSpf(cSecurErase))
    {
        mClrCacheInfoSpf(cSecurErase);
        progCacheInfoTab();

#if _ENABLE_ATA_PASSTHROUGH
        if(mChkCacheInfoSpf(cChangeSecurityState))
        {
            // Reset Security State after Erase
            rmRetainSecurityMasterPassword;    // keep master password
            gbSecAPIPendingInitATA=1;
        }
#endif
    }

    waitAllChCeBz();
#if (_GREYBOX)
    if((gsGbInfo.uGreyBoxItem==cUGSDSecureEraseID)&&(gsGbInfo.uGreyBoxOpt==cVOpProgCacheInfoDoneAfEraseAll))
    {
        triggerUGSD(cTrue);
    }
#endif
}    /* eraseUnitProc */

void funcTskLoadTelemetryCtlrLog(BYTE uTskTail)
{
    LWORD u32PageOffset=0;
    WORD u16BufPtr=gsTskFifoCtrl.uarTskFifo[uTskTail].u16TskSBufPtr, u16PageSPtr;

    if(g16LogBlkFreePagePtr<cTelemetryCtlrDataPageCnt)
    {
        u16PageSPtr=0;
    }
    else
    {
        u16PageSPtr=g16LogBlkFreePagePtr-cTelemetryCtlrDataPageCnt;
    }

    for(u32PageOffset=0; u32PageOffset<cTelemetryCtlrDataPageCnt; u32PageOffset++)
    {
        loadInfoPage(u16PageSPtr+u32PageOffset, gSectorPerPlaneH, u16BufPtr+(u32PageOffset*gSectorPerPlaneH), 0, cSysBlockLog, cBit1);
    }
}    /* funcTskLoadTelemetryCtlrLog */

void funcTskEraseUnitStart(BYTE uTskTail)
{
    WORD u16TotalEraseCount, u16TotalProgramCount, u16TotalVerifyCount;
    BYTE uEraseMode=gsTskFifoCtrl.uarTskFifo[uTskTail].uTskOpt, uEraseMethod=gsTskFifoCtrl.uarTskFifo[uTskTail].uTskPgOfst;

    /*
       *  1. Initialize the Erase Operation
       */
#if 0    // Copy in Core 0
    bopClrRam((LWORD)&gsEraseUnitInfo, sizeof(gsEraseUnitInfo), 0x00000000, cClrStcm|cBopWait);
    copyCcmVal((BYTE *)&gsEraseUnitInfo, (BYTE *)&gsSanitizeInfo, sizeof(ERASEUNITPARAM));
#endif

    /* Save the erase unit mode */
    gsEraseUnitInfo.uEraseMode=uEraseMode;
    gsEraseUnitInfo.uEraseMethod=uEraseMethod;

    /* Initialize the next FBlock to be erased to the first data block */
    gsEraseUnitInfo.usCurrentOperation.u16NextFBlock=g16FirstFBlock;

    /* Calculate total operation count per block. */
    u16TotalVerifyCount=0;

    if(gsEraseUnitInfo.uEraseMethod==cSanitizeBlockErase)
    {
        u16TotalEraseCount=1;
        u16TotalProgramCount=0;
    }
    else
    {
        u16TotalProgramCount=u16TotalEraseCount=1;    // gsEraseUnitInfo.usEraseParam.uTotalParam;

        if(gsEraseUnitInfo.usEraseParam.uNeedVerify)
        {
            u16TotalVerifyCount=1;    // gsEraseUnitInfo.usEraseParam.uTotalParam;
        }
    }

    /* Calculate total operations per block for one time pass */
    u16TotalVerifyCount=u16TotalEraseCount+u16TotalProgramCount+u16TotalVerifyCount;
    gsEraseUnitInfo.u32TotalOperationsPerBlock=(LWORD)u16TotalVerifyCount;

    /* Calculate total operations per block to complete all passes. */
    u16TotalVerifyCount*=gsEraseUnitInfo.usEraseParam.uTotalPass;

    /*
       *  Separately only calculate total erase count for the whole pass (since the value will
       *  be used to track the block erase count.
       */
    u16TotalEraseCount*=gsEraseUnitInfo.usEraseParam.uTotalPass;

    /* Initialize the total operation required for the whole drive. This is used to track the progress */
    gsEraseUnitInfo.u32TotalBlockOperations=((LWORD)u16TotalVerifyCount)*(LWORD)(g16TotalFBlock-g16FirstFBlock);

    /*
       *  2. Start the erase operation
       */

    /* Save the cache info block first based on the erase unit mode */
    handleEraseCnt(cInfuncTskEraseUnitStart_00, u16TotalEraseCount, uTskTail, gsEraseUnitInfo.uEraseMode);
}    /* eraseUnitStart */

void funcTskEraseUnitContinue(BYTE uTskTail)
{
    ADDRINFO usTmpAddrInfo;
    WORD u16FBlock, u16EraseFail;

    bopClrRam((LWORD)(BYTE *)&usTmpAddrInfo, sizeof(ADDRINFO), 0x00000000, cClrCore1Dccm|cBopWait);

    if(gsEraseUnitInfo.usCurrentOperation.u16NextFBlock>=g16TotalFBlock)
    {
        if((gsEraseUnitInfo.uEraseMethod!=cSanitizeBlockErase)
           &&(gsEraseUnitInfo.usCurrentOperation.uPassCount<gsEraseUnitInfo.usEraseParam.uTotalPass))
        {
            if(gsEraseUnitInfo.usCurrentOperation.uStage<cEraseVerifyData)
            {
                gsEraseUnitInfo.usCurrentOperation.uStage++;
            }
            else    // cEraseVerifyData
            {
                gsEraseUnitInfo.usCurrentOperation.uPassCount++;

                if(gsEraseUnitInfo.usCurrentOperation.uPassCount<gsEraseUnitInfo.usEraseParam.uTotalPass)
                {
                    gsEraseUnitInfo.usCurrentOperation.uStage=cEraseBlock;
                    gsEraseUnitInfo.usCurrentOperation.uParamIndex=
                        mod((gsEraseUnitInfo.usCurrentOperation.uParamIndex+1), gsEraseUnitInfo.usEraseParam.uTotalParam);
                }
                else
                {
                    return;
                }
            }
        }
        else
        {
            waitAllChCeBz();

            if((gsEraseUnitInfo.uEraseMethod==cSanitizeOverwrite)&&(!gsEraseUnitInfo.u32TotalFail))
            {
                eraseTotalFBlock(0);    // Prevent over program
                gsNamespace.u32DummyPatt=gsEraseUnitInfo.usEraseParam.u32arPattern[gsEraseUnitInfo.usCurrentOperation.uParamIndex];
            }

            if(mChkCacheInfoSpf(gsEraseUnitInfo.uEraseMode))
            {
                mClrCacheInfoSpf(gsEraseUnitInfo.uEraseMode);
                progCacheInfoTab(cIneraseUnitContinue_00);
            }

            waitAllChCeBz();

            gsEraseUnitInfo.usCurrentOperation.uContinue=cFalse;
            return;
        }

        if((gsEraseUnitInfo.usCurrentOperation.uStage!=cEraseVerifyData)
           ||((gsEraseUnitInfo.usCurrentOperation.uStage==cEraseVerifyData)
              &&(gsEraseUnitInfo.usEraseParam.uNeedVerify)))
        {
            gsEraseUnitInfo.usCurrentOperation.u16NextFBlock=g16FirstFBlock;
            gsEraseUnitInfo.usCurrentOperation.u16CurrBlkOpCnt++;
        }
    }

    u16FBlock=gsEraseUnitInfo.usCurrentOperation.u16NextFBlock;

    if((mGetGlobEraseCnt(u16FBlock)!=c16BitFF)&&chkWproBlk(u16FBlock))
    {
        switch(gsEraseUnitInfo.usCurrentOperation.uStage)
        {
            case cEraseBlock:
                waitAllChCeBz();

                usTmpAddrInfo.u16FBlock=u16FBlock;

                for(gActiveCh=0; gActiveCh<gTotalChNum; gActiveCh++)
                {
                    setFLAddrActCh(gActiveCh, &usTmpAddrInfo);
                    flashErase(c16Bit13|c16Bit15);
                }

                if(gsEraseUnitInfo.usEraseParam.uNeedVerify)
                {
                    u16EraseFail=0;

                    for(gActiveCh=0; gActiveCh<gTotalChNum; gActiveCh++)
                    {
                        setFLAddrActCh(gActiveCh, &usTmpAddrInfo);
                        u16EraseFail|=chkEraseStatus();    // just detect Erase fail or not
                    }

                    if(u16EraseFail&&(mGetGlobEraseCnt(u16FBlock)!=c16BitFF))
                    {
                        gsEraseUnitInfo.u32TotalFail++;
                    }
                }

#if _EN_DUMMYPROG
                if(!u16EraseFail)
                {
                    for(gActiveCh=0; gActiveCh<gTotalChNum; gActiveCh++)
                    {
                        setFLAddrActCh(gActiveCh, &usTmpAddrInfo);
                        flashErase(c16Bit10);
                    }
                }
#endif
                break;

            case cEraseProgram:
                eraseUnitProgram();
                break;

            case cEraseVerifyData:
                eraseUnitVerifyData();
                break;

            default:
                break;
        }    /* switch */
    }

    gsEraseUnitInfo.usCurrentOperation.u16NextFBlock++;

    gsEraseUnitInfo.usCurrentOperation.uContinue=cTrue;
}    /* eraseUnitContinue */

#pragma default_function_attributes =







