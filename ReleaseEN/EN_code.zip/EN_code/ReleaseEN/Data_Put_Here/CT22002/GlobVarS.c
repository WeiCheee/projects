







#include "inc/TypeDef.h"
#include "inc/Const.h"
#include "inc/table.h"
// #include "inc/nvmectrl.h"

// #pragma default_variable_attributes = @ ".ROM_VAR"
// 0x000
__root __no_init BYTE garParaPageId[10]            @ cParaAddr+0x00;
__root __no_init BYTE gFlashVendor                 @ cParaAddr+0x0A;
__root __no_init BYTE gCardMode                    @ cParaAddr+0x0B;
__root __no_init BYTE gFLParam                     @ cParaAddr+0x0C;
__root __no_init BYTE gFLOption                    @ cParaAddr+0x0D;
__root __no_init WORD g16PadCnt                    @ cParaAddr+0x0E;
// 0x010
__root __no_init BYTE gChMap                       @ cParaAddr+0x10;
__root __no_init BYTE gCeMap                       @ cParaAddr+0x11;
__root __no_init BYTE gIntlvWay                    @ cParaAddr+0x12;
__root __no_init BYTE gPlaneNum                    @ cParaAddr+0x13;
__root __no_init BYTE gTotalChNum                  @ cParaAddr+0x14;
__root __no_init BYTE gTotalCeNum                  @ cParaAddr+0x15;
__root __no_init BYTE gTotalIntlvChNum             @ cParaAddr+0x16;
__root __no_init BYTE gTotalDiePerCe               @ cParaAddr+0x17;
__root __no_init BYTE gDataECCLevel                @ cParaAddr+0x18;
__root __no_init BYTE gSprECCLevel                 @ cParaAddr+0x19;
__root __no_init BYTE gPageNumReg                  @ cParaAddr+0x1A;
__root __no_init BYTE gBlockNumReg                 @ cParaAddr+0x1B;
__root __no_init BYTE gPlaneNumReg                 @ cParaAddr+0x1C;
__root __no_init BYTE gRsv1_D                      @ cParaAddr+0x1D;
__root __no_init BYTE gTotalIntlvChPlaneNum        @ cParaAddr+0x1E;
__root __no_init BYTE gTotalChPlaneNum             @ cParaAddr+0x1F;
// 0x020:
__root __no_init BYTE garSysBlock[cRsvSysBlkNum]   @ cParaAddr+0x20;

__root __no_init WORD g16MinStaticTlcCnt    @ cParaAddr+0x2C;

// BYTE garParaTabRsv2[0];
// 0x030
__root __no_init WORD g16FirstFBlock               @ cParaAddr+0x30;
__root __no_init WORD g16TotalFBlock               @ cParaAddr+0x32;
__root __no_init WORD g16TotalHBlock               @ cParaAddr+0x34;
__root __no_init WORD g16FBlockPerCe               @ cParaAddr+0x36;
__root __no_init WORD g16FBlockPerDie              @ cParaAddr+0x38;
__root __no_init WORD g16OrgSpareBlockCnt          @ cParaAddr+0x3A;    // for smart
__root __no_init WORD g16OrgBadBlockCnt            @ cParaAddr+0x3C;    // for smart
__root __no_init WORD g16LaterBadBlockCnt          @ cParaAddr+0x3E;    // for smart
// BYTE garParaTabRsv3[0];
// 0x040
__root __no_init BYTE gSectorPerPageF              @ cParaAddr+0x40;
__root __no_init BYTE gSectorPerPageH              @ cParaAddr+0x41;
__root __no_init BYTE gSectorPerPlaneF             @ cParaAddr+0x42;
__root __no_init BYTE gSectorPerPlaneH             @ cParaAddr+0x43;
__root __no_init BYTE gDiffType3Num                @ cParaAddr+0x44;
__root __no_init BYTE gISPCore1StartPage           @ cParaAddr+0x45;
__root __no_init WORD g16PagePerBlock1             @ cParaAddr+0x46;
__root __no_init WORD g16PagePerBlock1_SLC         @ cParaAddr+0x48;    // the number of page in one SLC super block
__root __no_init WORD g16PagePerBlock3_SLC         @ cParaAddr+0x4A;
__root __no_init LWORD g32SectorPerBlockH          @ cParaAddr+0x4C;
// 0x050
__root __no_init BYTE garFLCmdSetTab[16]           @ cParaAddr+0x50;
// BYTE garParaTabRsv5[0];
// 0x060
__root __no_init LWORD g32TotalDatSector           @ cParaAddr+0x60;
__root __no_init BYTE garDllAdj[5]                 @ cParaAddr+0x64;
__root __no_init BYTE gRtcSel                      @ cParaAddr+0x69;
__root __no_init BYTE gIntlvPlaneNum               @ cParaAddr+0x6A;
__root __no_init BYTE gDiffBitMapOfst              @ cParaAddr+0x6B;
__root __no_init WORD g16RTCTrim                   @ cParaAddr+0x6C;
__root __no_init WORD g16Rsv6_E                    @ cParaAddr+0x6E;
// 0x70
__root __no_init BYTE gBlockStatusStartPage        @ cParaAddr+0x70;
__root __no_init BYTE gEraseBlockStatusStartPage   @ cParaAddr+0x71;
__root __no_init BYTE gBadCntTableStartPage        @ cParaAddr+0x72;
__root __no_init BYTE gTotalBlockStatusStartPage   @ cParaAddr+0x73;
__root __no_init BYTE gBadBlockBitMapStartPage     @ cParaAddr+0x74;
__root __no_init BYTE gTotalDiffAddrTableStartPage @ cParaAddr+0x75;
__root __no_init BYTE gISPBlockStartPage           @ cParaAddr+0x76;
__root __no_init BYTE gMinStaticSlcCnt             @ cParaAddr+0x77;    // 0x77   // PDTool set this number as 40
__root __no_init BYTE gRetryTableStartPage         @ cParaAddr+0x78;
__root __no_init BYTE gDiffType2Num                @ cParaAddr+0x79;
__root __no_init BYTE gFormFactor                  @ cParaAddr+0x7A;
__root __no_init BYTE gSeedTableStartPage          @ cParaAddr+0x7B;
__root __no_init WORD g16TlcValidPgPerF2hTab       @ cParaAddr+0x7C;
__root __no_init WORD g16FlashClock                @ cParaAddr+0x7E;

// 0x080
__root __no_init WORD g16ValidPgPerF2hTab          @ cParaAddr+0x80;
__root __no_init WORD g16PagePerH2fTab             @ cParaAddr+0x82;
__root __no_init WORD g16TotalPgPerF2hTab          @ cParaAddr+0x84;
__root __no_init WORD g16MaxCachePageNum           @ cParaAddr+0x86;
__root __no_init WORD g16TotalTlcPgPerF2hTab       @ cParaAddr+0x88;    // g16MaxCacheBlkNum;//obs
__root __no_init BYTE gTotalPlaneOfH2fTab          @ cParaAddr+0x8A;
__root __no_init BYTE gTotal4kNumOfF2hTab          @ cParaAddr+0x8B;
__root __no_init BYTE gTotalPlaneOfCacheInfoTab    @ cParaAddr+0x8C;
__root __no_init BYTE gTotalBankOfF2hTab           @ cParaAddr+0x8D;
__root __no_init BYTE g4kNumPerPlane               @ cParaAddr+0x8E;
__root __no_init BYTE g4kNumPerPage                @ cParaAddr+0x8F;
// 0x090~0x0AF
__root __no_init BYTE gPlaneSizeBitCnt              @ cParaAddr+0x90;    // g4kNumPerPlane shift bit count
__root __no_init BYTE gPlaneBitCnt                  @ cParaAddr+0x91;
__root __no_init BYTE gChBitCnt                     @ cParaAddr+0x92;
__root __no_init BYTE gCeBitCnt                     @ cParaAddr+0x93;
__root __no_init BYTE gDieBitCnt                    @ cParaAddr+0x94;
__root __no_init BYTE gPlaneAddrBitShiftCnt         @ cParaAddr+0x95;
__root __no_init BYTE gChAddrBitShiftCnt            @ cParaAddr+0x96;
__root __no_init BYTE gCeAddrBitShiftCnt            @ cParaAddr+0x97;
__root __no_init BYTE gDieAddrBitShiftCnt2          @ cParaAddr+0x98;    // already define above
__root __no_init BYTE gPhyPageAddrBitShiftCnt       @ cParaAddr+0x99;

__root __no_init WORD g16BlockBitMask               @ cParaAddr+0x9A;
__root __no_init WORD g16DiffOffsetNum              @ cParaAddr+0x9C;
__root __no_init BYTE gBlockBitCnt                  @ cParaAddr+0x9E;
__root __no_init BYTE gTlcTotal4kNumOfF2hTab        @ cParaAddr+0x9F;
__root __no_init BYTE gTlcLgPgDieAddrBitShiftCnt2   @ cParaAddr+0xA0;
__root __no_init BYTE gTlcLgPgCeAddrBitShiftCnt     @ cParaAddr+0xA1;
__root __no_init BYTE gTlcLgPgPhyPageAddrBitShiftCnt@ cParaAddr+0xA2;
__root __no_init BYTE gTlcLgPgShiftCnt              @ cParaAddr+0xA3;
__root __no_init BYTE gRsvA[12]                     @ cParaAddr+0xA4;
// 0x0B0
__root __no_init LWORD g32VpcPerTlcBlk             @ cParaAddr+0xB0;
__root __no_init WORD g16MaxDualMoPeThr            @ cParaAddr+0xB4;    // g16PagePerBlock2_SLC;
__root __no_init WORD g16TlcFullCachebGcThr        @ cParaAddr+0xB6;    // g16LastSLCBlock;
__root __no_init LWORD g32VpcPerSlcBlk             @ cParaAddr+0xB8;
__root __no_init BYTE gTotalTlcBankOfF2hTab        @ cParaAddr+0xBC;    // gLogiPlaneNum;
__root __no_init BYTE gPhyDiePerPackage            @ cParaAddr+0xBD;
__root __no_init BYTE gOPRomStrPage                @ cParaAddr+0xBE;
__root __no_init BYTE gRDTStrPage                  @ cParaAddr+0xBF;
// 0x0C0
__root __no_init LWORD g32PagePerBlock2            @ cParaAddr+0xC0;
__root __no_init LWORD g32PagePerBlock2By4k        @ cParaAddr+0xC4;    // g32FlushF2hTabStAddr;
__root __no_init LWORD g32PagePerBlock2_SLCBy4k    @ cParaAddr+0xC8;    // g32FlushF2hTabStAddr;
__root __no_init BYTE garParaTabRsvC[4]            @ cParaAddr+0xCC;
// 0x0D0
__root __no_init BYTE gSecurityOption              @ cParaAddr+0xD0;
__root __no_init BYTE gChgNANDClock                @ cParaAddr+0xD1;
__root __no_init BYTE gRsvD[13]                    @ cParaAddr+0xD2;
__root __no_init BYTE gTcgReservedSecShiftCnt      @ cParaAddr+0xDF;

// 0x0E0
// __root __no_init BYTE gRsvE[16]                    @ cParaAddr+0xE0;
__root __no_init BYTE gCh0FshODTAndDrv             @ cParaAddr+0xE0;
__root __no_init BYTE gCh0CtrlIODrv                @ cParaAddr+0xE1;
__root __no_init BYTE gCh0DataDQSDrv               @ cParaAddr+0xE2;
__root __no_init BYTE gCh0SchmtWindAndODT          @ cParaAddr+0xE3;
__root __no_init BYTE gCh1FshODTAndDrv             @ cParaAddr+0xE4;
__root __no_init BYTE gCh1CtrlIODrv                @ cParaAddr+0xE5;
__root __no_init BYTE gCh1DataDQSDrv               @ cParaAddr+0xE6;
__root __no_init BYTE gCh1SchmtWindAndODT          @ cParaAddr+0xE7;
__root __no_init BYTE gCh2FshODTAndDrv             @ cParaAddr+0xE8;
__root __no_init BYTE gCh2CtrlIODrv                @ cParaAddr+0xE9;
__root __no_init BYTE gCh2DataDQSDrv               @ cParaAddr+0xEA;
__root __no_init BYTE gCh2SchmtWindAndODT          @ cParaAddr+0xEB;
__root __no_init BYTE gCh3FshODTAndDrv             @ cParaAddr+0xEC;
__root __no_init BYTE gCh3CtrlIODrv                @ cParaAddr+0xED;
__root __no_init BYTE gCh3DataDQSDrv               @ cParaAddr+0xEE;
__root __no_init BYTE gCh3SchmtWindAndODT          @ cParaAddr+0xEF;
// 0x0F0
__root __no_init BYTE gFlashId[8]                  @ cParaAddr+0xF0;
__root __no_init BYTE gCeDieMap[8]                 @ cParaAddr+0xF8;
// will put in core1

// *********** For PS4 backup used ****************
WPROINFO gsWproInfo                                @ cGsWproInfoAddr;    // size: 0x15C
WORD g16arCurrSysBlkEsCnt[cRsvSysBlkNum]           @ cG16arCurrSysBlkEsCntAddr;    // size: 0x10
LWORD g32IndexBlkSerial                            @ cGps4StcmValAddr+0x00;
WORD g16IdxBlkFreePagePtr                          @ cGps4StcmValAddr+0x04;
BYTE gSysOption                                    @ cGps4StcmValAddr+0x08;
BYTE gHandlePlpScpFlow                             @ cGps4StcmValAddr+0x09;
BYTE gSysOption1                                   @ cGps4StcmValAddr+0x0A;    // Chief20190131 LWROD Need Align 4 BYTE, WORD Need Align 2 BYTE
LWORD g32Ps3EnPwrDomain1                           @ cGps4StcmValAddr+0x0C;
LWORD g32CurMaxNandTemp                            @ cGps4StcmValAddr+0x10;
LWORD g32PwrOnMaxNandTemp                          @ cGps4StcmValAddr+0x14;
LWORD g32AvgNandTemp                               @ cGps4StcmValAddr+0x18;
LWORD g32arPlpScpTimeStamp                         @ cGps4StcmValAddr+0x1C;
WORD g16LogBlkFreePagePtr                          @ cGps4StcmValAddr+0x20;
BYTE gSecurityStatus                               @ cGps4StcmValAddr+0x22;

#if _EN_CDMTRIG
BYTE gCDMStatus                                    @ cGps4StcmValAddr+0x23;
LWORD g32CDMTimer                                  @ cGps4StcmValAddr+0x24;
#endif

#if _EN_Lenovo_RecoveryChk
IomInfo gsIomInfo_RecoveryCheck                    @ cGps4StcmValAddr+0x28;
#endif

#if _EN_EarlyBdGC
LWORD g32EarGCTimer                                @ cGps4StcmValAddr+0x40;
LWORD g32EarIOcnt                                  @ cGps4StcmValAddr+0x44;
BYTE gEarGCflag                                    @ cGps4StcmValAddr+0x48;

#endif
#if _EN_DisHMBInReset    // 20190805_Chief_DisHMB
BYTE gDisHMBCnt_NormalBehavior                     @ cGps4StcmValAddr+0x49;
BYTE gDisHMBCnt_AbnormalBehavior                   @ cGps4StcmValAddr+0x4A;
BYTE gChkFlag                                      @ cGps4StcmValAddr+0x4B;
LWORD g32DisHMBTimer                               @ cGps4StcmValAddr+0x4C;
#endif

#if _EN_SKIPGC10MIN    // 20190806_ChrisSu
LWORD g32BgdGCSkip10min                            @ cGps4StcmValAddr+0x50;
#endif
#pragma default_variable_attributes = @ ".GLOB_VAR"

/********Managers*********/
#if 1

volatile BYTE(*regLdpcDsp)[0x20000];
volatile WORD(*reg16LdpcDsp)[0x10000];
volatile LWORD(*reg32LdpcDsp)[0x8000];

volatile BYTE(*regFSHA)[0x10000];
volatile WORD(*reg16FSHA)[0x8000];
volatile LWORD(*reg32FSHA)[0x4000];

volatile LWORD g32NvmeCondition;    // @ ".STCM_Var_ROM";
volatile LWORD g32PcieRstOrErrEvent;

// ----------------------------------------parameter pag
volatile BYTE gSysOpFlag;
BITS gbsTmpFlag;
BITS gbsFLSts;
// BYTE gReadFlag;
BYTE gWriteFlag;
BYTE gFtlChgFlag;
LWORD g32ECCCorrCnt;
LWORD g32ECCErrCnt;
WORD g16TempPage;
BYTE gIntlvShiftCnt;

BYTE gTempRest;
BYTE garChMapTable[cMaxPhyChNum];
BYTE garCeMapTable[cCePin];

// -------------------------------- flash character
WORD g16PagePerChannel;
BYTE gSectorPerPageH2n;
BYTE gIntlvOddA;
BYTE gActiveCh;
BYTE gWithInfoBlk;
// --- (ab) add for extened block ---//
BYTE gNewTech;    // =NewSamsung or NewHynix
BYTE gChipAddrShitCnt;
WORD g16FBlockCombinUnit;

// -------------------------------- initial device
LWORD g32HostXfrCnt;
BYTE garTestArg[32];
BYTE gFlashErrorCode;
BYTE gPretestErrorCode;
BYTE gSecurityErrorCode;
BYTE gVendorCmdErrCode;

// ---------------------------------- flash parameter
BYTE gNowFCENum;
BYTE gSectorF;
BYTE garCeFlashMap[cCePin];
BYTE gUseOrphan;
BYTE gUseSysOrphan;

LWORD g32arFlashStatus[cMaxIntlvWayROM];

BYTE gXfrDir;
WORD g16arTotalFBlockBeforeCE[cCePin];
WORD *gp16FBlockPtr;
WORD g16FBlockOffSet;
BYTE garFLCmdSetTab2[16];
LWORD g32arGcSrcBlkBitMap[c16MaxBlockNum/32];    // 128b
ADDRINFO gsFlashAddrInfoTemp;
ADDRINFO garSrcAddrInfo[cReadFifoDpt];
ADDRINFO garDesAddrInfo[cWriteFifoDpt];
ADDRINFO gpVendorAddrInfo;
F2HINFO garDesF2hInfo[cWriteFifoDpt];
BLKSPRINFO gsBlkSprInfo;
LWORD g32QueAddrNow;
LWORD g32QueAddrLast;
LWORD g32AuxQueAddr;
WORD g16MaxEccBit;
WORD g16MaxEccPage;
LWORD g32PageNumForEccOverTh;
BYTE gVenderOfNand;
BYTE gUncFifoPtr;

// ----------------------------------------- system parameter
LWORD g32SectorsPerBlock;
WORD g16FBlockPerChip;
WORD g16arROMInfoBlockAddr[2];
volatile LWORD g32arFwPreOccuFlag[(c16WriteBufSize/cSctrPer4k)/32];

// Retry variable
BYTE gWithRetryTable;
BYTE gRetryType;
BYTE gRegisterCnt;
BYTE gSLC_RegisterCnt;
BYTE gRetryTimes;
BYTE gSLC_RetryTimes;
BYTE gLowerRetryTimes;
BYTE gUpperRetryTimes;
BYTE gRetryEraseTimes;
BYTE gRetryIteration;

// ROM code add
WORD g16BootISPStartBlock;
WORD g16BootISPEndBlock;
BYTE gFlashEccFailStatus;
LWORD g32ROMCodeFlowBit;

// for security use
BYTE gSecuDerivedKey[32];
BYTE gSuperLightSwitch;
BYTE gDebugLocked;

BYTE gMaxErrCnt;
// BYTE gPlaneAddr;
BYTE gTotalBank;
BYTE gIntIntlvMask;
BYTE gIntIntlv2n;

BYTE garLinkId[20];
BYTE gMLC2SLCCmdROM;    // for shuttle ROM code compatible
BITS gbsFlashStatus;
BITS gbsFlashOperation;
BITS gbsVendorRWOption;

BYTE gDegArray[32];    // debug array ue to return information in read_flash_id
BYTE gFeatureCmd;
LWORD isrServiceCnt;
// for Pcie,Nvme use
WORD gPrdIdx;

// for SLC SortQ
WORD g16SlcSortQCnt;    // 20181223_Bruce

// for timer
LWORD g32Timer0Limit;
LWORD g32PowerOnHour;
LWORD g32Timer0TickCnt;
LWORD g32Rtc32kStartVal;
// LWORD g32Rtc32kEndVal;
LWORD g32Cpu1TOFlag;
LWORD g32SysTmrOn;    // CPU0 & CPU1

// for thermal sensor temperature
BYTE gThsor0TemperatureBk;
LWORD g32RWTickCnt;

LWORD gNvmeNumberOfQueuesReqROM;
LWORD gNvmeArbitrationROM;
LWORD gNvmeIntCoalescingROM;
#endif/* if 1 */

// HWPRDCTRL gsHwPrd;

volatile RWCTRL gsRwCtrl;
CACHEINFO gsCacheInfo;
PRDINFO gsPrdInfo;
// READHADDRQ gsRdHaddrMgr;
RDLINKINFO gsRdlinkInfo;
QBOOTINFO gsQBootInfo;
BADINFO gsBadInfo;
GCINFO gsGcInfo;
FWDLINFO gsFwDlInfo;
volatile TASKFIFOCTRL gsTskFifoCtrl;
// volatile ISRCTRL gsIsrCtrl;
volatile MUTEXINFO gsMutexInfo;
volatile MUTEXINFO gsOccuMutexInfo;
// volatile BOOTMUTEXINFO gsBtMutexInfo;
UCBYTE *FlashDataBasePtr;
WORD g16PHYErrAddr;
BYTE gPHYErrExpVal;
BYTE gPHYErrData;
WORD g16ReadBufPtr;
// TODO: remove those varables after parameter table ready

// >>> merge 58xt IM3D
BYTE garCmdFifoDpt[3];
BYTE gReadLinkRetrySlcVth[cMaxChNum][cMaxPlaneNum];
// <<<

// ERRORINFO garErrorLog[cMaxErrLogEntryCnt];

// VENDORCMDDEBUGINFO gsVendorCmdDebugInfo;

// volatile BYTE garH2fSgmtRdyQ[cH2fSgmtRdyDept];
// volatile BYTE gH2fSgmtRdyHead;
// volatile BYTE gH2fSgmtRdyTail;
// volatile BYTE gH2fSgmtRdyCnt;
// volatile BYTE gH2f1KPrepCnt;
// volatile QWORD g64H2f1kTabSgmtPrep;
LWORD g32H2fTabFullSize;
LWORD g32H2fTabValidSize;
WORD g16H2fTabSize;
WORD g16H2fTabSctrSize;
WORD g16H2fTabValidSctrSize;
WORD g16WproSwapSBuf;
WORD g16HmbMaxTableNum;
BYTE gGCH2fTabShiftSize;
BYTE gPage4kPerH2fTab;
BYTE gHmbH2FTableShift;

WORD g16SlcF2hPadStartAddr_1;
WORD g16SlcF2hPadStartAddr_2;
WORD g16TlcF2hPadStartAddr_1;
WORD g16TlcF2hPadStartAddr_2;
BYTE gSlcSecNumPadF2h_1;
BYTE gSlcSecNumPadF2h_2;
BYTE gTlcSecNumPadF2h_1;
BYTE gTlcSecNumPadF2h_2;
BYTE gSpareCnt[cMaxChNum];
BYTE gWaitSpareTyp[cMaxChNum];
BYTE gSparePtrHead[cMaxChNum];
BYTE gSparePtrTail[cMaxChNum];
BYTE gSpareDesIdx[cMaxChNum][cSpareRegisterCnt];

// RAID related
WORD g16RaidStrAddr[cRaidParityNum];
WORD g16SlcRaidStrAddr[cRaidParityNum];
WORD g16TlcPartialParityNum;
WORD g16SlcPartialParityNum;
BYTE gSlcPadF2h4KNum;
BYTE gTlcPadF2h4KNum;
BYTE gSlcSecNumDummyF2h;
BYTE gTlcSecNumDummyF2h;
BYTE gMaxH2fTabBlkNum;
volatile LWORD g32DecodeWait;
volatile LWORD g32ParityOut;

volatile LWORD g32Core1State;
volatile LWORD g32NandTempSensor;

WORD g16SaveEventLog;
WORD g16Core1SaveEventLog;
WORD g16SaveEventLog2;
WORD g16Core1SaveEventLog2;
WORD g16EventLogPtr;
WORD g16Core1EventLogPtr;
WORD g16EventLogPtrBK;
WORD g16Core1EventLogPtrBK;
WORD g16LinkLogPtr;
WORD g16LinkLogPtrBK;
volatile WORD g16arLinkLog[cLinkLogSize];
CMDSTRUCT garCmdHistory[cCmdHistorySize];
NVMEPRDSTRUCT garCmdValidHistory[cCmdHistorySize];
LWORD g32CmdHistoryPtr;
LWORD g32EndCmdHistoryPtr;
// BYTE gEventLogPageWproPtr;
LWORD g32RxTrigStartmsTime;
LWORD g32OutputUART;    // g32OutputUart for security crypto library.

// Vu command
BYTE gVuMode;
BYTE gTlcMode;

#if ((_INITDRAM)||(_GREYBOX))
BYTE gGreyBoxBootSta;
#endif

// Flash/Ftl
LWORD g32DieAddrBitMask;
LWORD g32CeAddrBitMask;
LWORD g32ChAddrBitMask;
LWORD g32PlaneAddrBitMask;
LWORD g32PhyPageAddrMask;
BYTE gPlaneUNCSts[cMaxChNum];
BYTE gPlaneCorrSts[cMaxChNum];
BYTE gPlaneOnesCntSts[cMaxChNum];
LWORD gTotalRetryTimes;

LWORD g32arRH2fTabDirty[cMaxRH2fTabNum/32];    // if set 1, mean the segment of 64kb RH2f is modified and not sync to HMB and NAND flash
LWORD g32arH2f1kTabSgmt[cMaxRH2fTabNum];    // 128b

// E2E for BOP/HDMA
LWORD g32E2eLba;

WORD g16FlashClkForThermal;

WORD g16OneFblockGlobEraseCnt;
LWORD g32HmbTotalH2FTableSize;
// LWORD g32HmbGcInfoStrAddr;

#if _EN_Dynamic_Fix_Boundary
WORD g16TLCGCSpareCnt_Ori;
WORD g16TLCGCSpareCnt_Run;
#endif

E2EINFO gsE2eInfo;
volatile BYTE(*garTsb0)[512];
volatile WORD(*g16arTsb0)[512/2];
volatile LWORD(*g32arTsb0)[512/4];
volatile QWORD(*g64arTsb0)[512/8];

volatile BYTE *garBadInfoBuf;
volatile WORD *g16arBadInfoBuf;
volatile LWORD *g32arBadInfoBuf;

volatile NVMEFEATVAR *gpNvmeFeatVar;
volatile GETLOGINFO *gpGetLog;
ERASEUNITINFO gsEraseUnitInfo;

volatile BYTE *garIfSendBufPtr;
volatile BYTE *garIfRecvBufPtr;
volatile BYTE *garRecvTCGBuf;

#if 1    // _ENABLE_SECAPI
/* Used in SecIntf_TCG_Write()*/
BYTE gSecurityWProMode;
#endif
WBITS gbsSecurity;
BITS gbsSecAPI;
volatile BYTE gInSecApi;
volatile BYTE gByPassSecApiLog;

BYTE gSecurityLockRWErr;

volatile BYTE gWdtStatus;
BYTE gTelemetryCtlrInfo;
BYTE gTelemetryCtlrGenNum;

volatile BYTE gUartCMDStatus;
#if (_EN_CHRONUS_UART_DEBUG)
LWORD g32UartCMDSOFofst;
LWORD g32UartCMDEOFofst;
sChronusUartCMD *gpUartCMD;
LWORD *gp32UartCMDStartAddress;

volatile LWORD g32UartRSPofst;
volatile LWORD g32UartCMDofst;
volatile LWORD g32UartCMDDW;
volatile LWORD g32UartCMDWaitTime;
volatile LWORD g32arUartHndShkCMD[4];
volatile LWORD g32arUartCQEntryDW[4];
#endif

#if (_EN_WDT)
volatile BYTE gWdtTOExtensionCnt;
#endif

LWORD g32CmdPara0;
LWORD g32CmdPara1;
LWORD g32CmdPara2;
LWORD g32CmdPara3;

volatile BYTE gProgFifoPtr;
volatile HMBPTYINFO gsHmbPtyInfo;

BYTE gVuCmdSpFlag;    // bit0->VthCenter
// BYTE gVuCmdSts;
BYTE garVuCmdVthCenter[cMaxRetryRegisterCnt];    // ACEGBDFS
LWORD g32RamAddrRetryTablePassIndex;
LWORD g32RamAddrLastPassVthCenter;

#if _EN_VPC_SWAP
volatile LWORD *g32arCacheBlkVpCnt;
WORD g16arGlobEraseCnt[c16MaxBlockNum];    // 2kb
LWORD g32VPCSwapFlag;
BYTE gFor512GbDebug;
#else
#if (_TSB_BiCS4)
LWORD g32arGlobReadCnt[c16MaxBlockNum];    // 5kB
#endif
#endif
LWORD g32PS4BootTimeStamp;
#if _EN_CDMTRIG
BYTE gCCTFlag;
LWORD g32CDM_WSctrCnt;
LWORD g32CDM_RSctrCnt;
LWORD g32CDM_SWCnt;
LWORD g32CDM_SRCnt;
LWORD g32CDM_WBrkCnt;
LWORD g32CDM_RBrkCnt;

#endif
#if _EN_PopBlk0
volatile BYTE gBlkEmergencyflag;
#endif

#if _EN_Liteon_ErrHandle
BYTE gJdgBootGCFlag;
#endif

#if _EN_VPC_SWAP
LWORD g32SLCAvgVpc;
WORD g16MaxSlcBlkQ;
#endif

#if _EN_IOMTRIG
IomInfo gsIomInfo;
IomInfo gsIomInfo1Thr;
#endif

BYTE gGCOpt;
#pragma default_variable_attributes =
// ******** Region: STCM_FIFO_region End:0x0004_7FFF Size:26.25K ********//







