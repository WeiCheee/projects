







void setZeroVpcBlock(WORD u16FBlock)
{
    BYTE uOpt;

#if _EN_VPC_SWAP
    mClrVPCntValid(u16FBlock);
#endif

    if(g32Core1State>=cCore1BootState_Finished)
    {
        if((u16FBlock!=gsCacheInfo.u16ActiveCacheBlock)&&(u16FBlock!=gsCacheInfo.u16FluCacheBlock)&&
           (u16FBlock!=gsGcInfo.u16GcDesBlock))
        {
            if(mChkGcSrcBlkBmap(u16FBlock))
            {
                mClrGcSrcBlkBmap(u16FBlock);
            }

            // while(rmChkBopBz)
            //    ;
            if(!mChkSkipGcSrch(u16FBlock))
            {
                mSetSkipGcSrch(u16FBlock);
            }

            uOpt=0;

            if(mChkGcFlag(cUnderBgdGc|cUnderFgdGc))    // mChkInGcFlow)
            {
                uOpt=cPushJudgeMaxSlc;

                if(mChkGcFlag(cUnderFgdGc))
                {
                    uOpt|=cPushDecMaxSlc;
                }
            }

#if (!_CPUID)
            pushSpareBlockCore0(u16FBlock, cPushNotErase|uOpt);
#else
            pushSpareBlock(u16FBlock, cPushNotErase|uOpt);
#endif

            // else
            // {
            //    debugDeadLock(0x0008);
            // }
        }
    }
    else
    {
        if((u16FBlock!=gsRdlinkInfo.u16BkActiveCacheBlock)&&(u16FBlock!=gsRdlinkInfo.u16BkFluCacheBlock)&&
           (u16FBlock!=gsRdlinkInfo.u16BkActiveGcDesBlock)&&(u16FBlock!=gsCacheInfo.u16ActiveCacheBlock))    // 20190218_Bill
        {
#if (!_CPUID)
            pushSpareBlockCore0(u16FBlock, cPushNotErase);
#else
            pushSpareBlock(u16FBlock, cPushNotErase);
#endif
            // if(!mChkSkipGcSrch(u16FBlock))
            {
                mSetSkipGcBit(u16FBlock);
            }
        }

        // else
        // {
        //    debugDeadLock(0x0008);
        // }
        if(mChkGcSrcBlkBmap(u16FBlock))
        {
            mClrGcSrcBlkBmap(u16FBlock);
        }
    }
}    /* setZeroVpcBlock */







