







// #include "inc/GlobVarT.h"
// #include "inc/FtlCtrl.h"

#if (!_ICE_LOAD_ALL)
#pragma default_function_attributes = @ ".CORE0_MAIN"
#endif

#if 1
void setWriteDes(WORD u16ProgPageOfst, ADDRINFO *upTmpAddrInfo, BYTE uDesTyp)
{
    LWORD u324KNumOfDesFblk;

    // WORD u16PadF2hTabPgStr, u16PadF2hTabPgEnd, u16ProgF2hTabStr, u16ProgF2hTabEnd;

    if(uDesTyp==cWriteCache)
    {
#if _GREYBOX
        if((gsGbInfo.uGreyBoxItem==cUGSDProgCacheSlcID)&&
           ((gsGbInfo.uGreyBoxOpt==cVOpProgCacheLast6Page)||(gsGbInfo.uGreyBoxOpt==cVOpProgCacheLast3Page)||
            (gsGbInfo.uGreyBoxOpt==cVOpAllConfig))&&(gsGbInfo.uStag==cVsIdl))
        {
            trigGreyBox(cTrue);
        }
#endif

        u324KNumOfDesFblk=gsCacheInfo.u32CacheFreePagePtr+u16ProgPageOfst;
        upTmpAddrInfo->u32FPageNoTran=u324KNumOfDesFblk;
        upTmpAddrInfo->u16FBlock=gsCacheInfo.u16ActiveCacheBlock;
        upTmpAddrInfo->uAddrOpt=cCacheBlockID;
        upTmpAddrInfo->uPlaneCnt=0;
        tranAddrInfo(upTmpAddrInfo);

        mClrTabSpr(upTmpAddrInfo);    // upTmpAddrInfo->uTabSpar=0;
        mSetSprUseCnt(upTmpAddrInfo, cSpareUseOfSLC);    // upTmpAddrInfo->uSparUseCnt=cSpareUseOfSLC;

        while(u324KNumOfDesFblk>=gsCacheInfo.u16TotalPgPerF2hTab)
        {
            u324KNumOfDesFblk-=gsCacheInfo.u16TotalPgPerF2hTab;
        }

        gsCacheInfo.uCacheEobFlag=0;

        if((u324KNumOfDesFblk>=g16SlcPadF2hTabPgStr)&&(u324KNumOfDesFblk<g16SlcPadF2hTabPgEnd))
        {
            upTmpAddrInfo->u16RwOpt=cProg16kF2H;
            mSetCacheEobFlag(cEob1stF2h);
#if (_GREYBOX)
            if((gsGbInfo.uGreyBoxItem==cRAIDEncOnData)||(gsGbInfo.uGreyBoxItem==cRAIDDecOnNormData)||
               ((gsGbInfo.uGreyBoxItem==cSecurityRW)&&(gsGbInfo.uGreyBoxOpt==cVOpSecurityW)))
            {
                g16GbFBlock=upTmpAddrInfo->u16FBlock;
                g16GbFPage=upTmpAddrInfo->u16FPage;
                gGbCh=upTmpAddrInfo->uCh;
                gGbCe=upTmpAddrInfo->uCe;
                gGbDieAddr=upTmpAddrInfo->uDieAddr;
                gGbIntlvAddr=upTmpAddrInfo->uIntlvAddr;
                gGbPlaneAddr=upTmpAddrInfo->uPlaneAddr;
            }
            else if((gsGbInfo.uGreyBoxItem==cRAIDDecOnPreReadData))
            {
                g16GbFBlock=upTmpAddrInfo->u16FBlock;
                g16GbFPage=upTmpAddrInfo->u16FPage;
                gGbCh=upTmpAddrInfo->uCh;
                gGbCe=upTmpAddrInfo->uCe;
                gGbDieAddr=upTmpAddrInfo->uDieAddr;
                gGbIntlvAddr=upTmpAddrInfo->uIntlvAddr;
                gGbPlaneAddr=upTmpAddrInfo->uPlaneAddr;
            }
#endif/* if (_GREYBOX) */
        }
        else if(((u324KNumOfDesFblk>=g16SlcProgF2hTabStr)&&(u324KNumOfDesFblk<g16SlcProgF2hTabEnd)))
        {
            upTmpAddrInfo->u16RwOpt=cProg32kF2H;
        }
        else
        {
            upTmpAddrInfo->u16RwOpt=0;
        }

#if _ENABLE_RAID
        if((u324KNumOfDesFblk>=g16SlcProgRaidChStr4K)&&(upTmpAddrInfo->uCh==(gTotalChNum-1))&&(upTmpAddrInfo->uIntlvAddr==(gIntlvWay-1)))
        {
            upTmpAddrInfo->u16RwOpt|=cProgPlaneRaid;    // Raid pty
            mSetCacheEobFlag(cEobRaid);
        }
#endif
    }
    else if(uDesTyp==cWriteGcDes)
    {
        u324KNumOfDesFblk=gsGcInfo.u32GcDesbFreePagePtr+u16ProgPageOfst;
        upTmpAddrInfo->u32FPageNoTran=u324KNumOfDesFblk;
        upTmpAddrInfo->u16FBlock=gsGcInfo.u16GcDesBlock;
        upTmpAddrInfo->u16AbstractFBlock=gsGcInfo.u16GcDesBlock;    // 20190124_Bruce_for SPOR EC error
        upTmpAddrInfo->uAddrOpt=cGcDesBlockID;
        upTmpAddrInfo->uPlaneCnt=0;

        // tranAddrInfo(upTmpAddrInfo);
        upTmpAddrInfo->u16FPage=gsGcInfo.u16GcOneShotPtr;    ///gIntlvWay;
        // upTmpAddrInfo->ubLargePg=1;
        upTmpAddrInfo->uIntlvAddr=gsGcInfo.uGcIntlvPtr;
        upTmpAddrInfo->uCe=mGetCEAddr(upTmpAddrInfo->uIntlvAddr);
        upTmpAddrInfo->uDieAddr=mGetDieAddr(upTmpAddrInfo->uIntlvAddr);
        upTmpAddrInfo->uCh=gsGcInfo.uOneShotChPtr;
        upTmpAddrInfo->uPlaneAddr=0;

        if(mChkMlcMoBit(upTmpAddrInfo->u16FBlock))
        {
            // upTmpAddrInfo->uPageSelCmd=gsGcInfo.uSrcHandlePageType+1;
            setPageSelCmd(upTmpAddrInfo, gsGcInfo.uSrcHandlePageType+1);
        }
        else
        {
            // upTmpAddrInfo->uPageSelCmd=cSlcCmd;
            setPageSelCmd(upTmpAddrInfo, cSlcCmd);
        }

        mClrTabSpr(upTmpAddrInfo);    // upTmpAddrInfo->uTabSpar=0;
        mSetSprUseCnt(upTmpAddrInfo, cSpareUseOfSLC);    // upTmpAddrInfo->uSparUseCnt=cSpareUseOfSLC;

        while(u324KNumOfDesFblk>=gsGcInfo.u16GCDesTotalPgPerF2hTab)
        {
            u324KNumOfDesFblk-=gsGcInfo.u16GCDesTotalPgPerF2hTab;
        }

        gsCacheInfo.uCacheEobFlag=0;

        if((u324KNumOfDesFblk>=gsGcInfo.u16PadF2hTabPgStr)&&(u324KNumOfDesFblk<gsGcInfo.u16PadF2hTabPgEnd))
        {
            upTmpAddrInfo->u16RwOpt=cProg16kF2H;
            mSetCacheEobFlag(cEob1stF2h);
        }
        else if(((u324KNumOfDesFblk>=gsGcInfo.u16ProgF2hTabStr)&&(u324KNumOfDesFblk<gsGcInfo.u16ProgF2hTabEnd)))
        {
            upTmpAddrInfo->u16RwOpt=cProg32kF2H;    // f2h bank second page
        }
        else
        {
            upTmpAddrInfo->u16RwOpt=0;
        }

#if _EN_RAID_GC
        if((u324KNumOfDesFblk>=gsGcInfo.u16ProgRaidChStr4K)&&(upTmpAddrInfo->uCh==(gTotalChNum-1))&&(upTmpAddrInfo->uIntlvAddr==(gIntlvWay-1)))
        {
            upTmpAddrInfo->u16RwOpt|=cProgPlaneRaid;    // Raid pty
            mSetCacheEobFlag(cEobRaid);
        }
#endif
    }
    else if(uDesTyp==cWriteH2fTab)
    {
        upTmpAddrInfo->u16FBlock=g16arH2fTabBlk[gsCacheInfo.uActH2fTabBlkIdx];
        upTmpAddrInfo->u32FPageNoTran=mTranH2fTabAddr(gsCacheInfo.u16H2fTabFreePagePtr)+u16ProgPageOfst;
        upTmpAddrInfo->uAddrOpt=cH2fTableID;
        tranAddrInfo(upTmpAddrInfo);
        mSetTabSpr(upTmpAddrInfo, cBit6);    // upTmpAddrInfo->uTabSpar=2;
        mSetSprUseCnt(upTmpAddrInfo, cSpareUseOfH2F);    // upTmpAddrInfo->uSparUseCnt=cSpareUseOfH2F;
    }
    else
    {
        gsFtlDbg.u16DummyFailType=cSetWriteDes1;
        debugWhile();
    }

    mClrSprSetDone(upTmpAddrInfo);    // upTmpAddrInfo->uSprSetDone=0;
}    /* setWriteDes */

#endif/* if 1 */

#if (!_ICE_LOAD_ALL)
#pragma default_function_attributes =
#endif







