







#include "inc/Option.h"
#include "inc/DebugLog.h"
#include "inc/EventLogIDX.h"
#include "inc/EventLogFunctionIDX.h"
#include "inc/ArmCp15.h"
#include "inc/Asm.h"
#include "inc/BitDef.h"
#include "inc/Const.h"
#include "inc/GlobVar0.h"
#include "inc/GlobVarS.h"
#include "inc/GlobVarT.h"
#include "inc/Mac.h"
#include "inc/NvmeCtrl.h"
#include "inc/ProType.h"
#include "inc/Reg.h"
#include "inc/Table.h"
#include "inc/TypeDef.h"
#include "inc/GreyBox.h"
// #include "inc/Rdlink.h"
#include "inc/Security.h"
#include "inc/Crypto_Library.h"

#if _ENABLE_SECAPI

#include "SecAPI_BaseFW_Var.c"
#include "Security.c"

#if (!_ICE_DEBUG)
#pragma default_function_attributes = @ ".SecurityAPI_Code_BaseFW"
#endif

#if _ENABLE_ATA_PASSTHROUGH

void SecAPI_InitATASecurityFuncPtr_BaseFW()
{
// assign some functions of TCG OPAL if OPAL is disable
/*=====================================================================*/
// ------ implement by BaseFW
/*=====================================================================*/
    SFP.gfpSecIntf_EraseUserArea=SecIntf_EraseUserArea;
    SFP.gfpSecIntf_UpdateATASecurityStatus=SecIntf_UpdateATASecurityStatus;
    SFP.gfpSecIntf_SYS_DCache_Invalidte=SecIntf_SYS_DCache_Invalidte;
}

void SecAPI_InitATASecurity(BYTE uMode)
{
    SFP.gfpSecIntf_InitATASecurity(uMode);
}

void SecAPI_NoticeModifyMEKs_Request(BYTE *upMEK)
{
    SFP.gfpSecIntf_NoticeModifyMEKs(upMEK);
}

void SecIntf_EraseUserArea(BYTE uDoNotChangeSecurityState)
{
    handleCore0VarErase();
    eraseUnitProcCore0(uDoNotChangeSecurityState);

#if _ENABLE_ATA_PASSTHROUGH

    if(!uDoNotChangeSecurityState)
    {
        handleSecFlagSub();
    }
#endif
}

void SecIntf_UpdateATASecurityStatus(BYTE uMode, BYTE *uSecurityStatus)
{
    if(uMode&cUpdateBaseFW)
    {
        if(gbSecAPIClearATASecurityPrepare)
        {
            gSecurityStatus=(*uSecurityStatus&~cBit0);
            *uSecurityStatus=gSecurityStatus;    // immediate update to API.
            gbSecAPIClearATASecurityPrepare=0;
        }
        else
        {
            gSecurityStatus=*uSecurityStatus;
        }
    }
    else    // if(uMode&cUpdateSecurityFW)
    {
        *uSecurityStatus=gSecurityStatus;
    }
}    /* SecIntf_UpdateATASecurityStatus */

void SecIntf_SYS_DCache_Invalidte()
{
    invalidateDCache();
}

#endif/* if _ENABLE_ATA_PASSTHROUGH */

void SecAPI_NoticeBackupResume_Request(BYTE uAction)
{
    SFP.gfpSecIntf_NoticeBackupResume(uAction);
}

void SecAPI_NoticeReset_Request(BYTE uType)    // for BlockSID Hardware Reset entry(not used in NVMe now)
{
    SFP.gfpSecIntf_NoticeReset(uType);
}

LWORD SecAPI_GetReadGHP_Request(BYTE uMode, LWORD u32GHP)
{
    return SFP.gfpSecIntf_GetReadGHP(uMode, u32GHP);
}

BYTE SecAPI_Crypto_UpdateGlobalRangeKey_Request(BYTE *upMEK)
{
    BYTE uStatus=0;

    uStatus=SFP.gfpSecIntf_Crypto_UpdateGlobalRangeKey(upMEK);
    return uStatus;
}

void SecAPI_Crypto_RestoreAESHWInfo_Request()
{
    SFP.gfpSecIntf_Crypto_RestoreAESHWInfo();
}

BYTE SecIntf_JudgeWrittenGHP(LWORD u32GHP)
{
    HADDRINFO usTmpHAddrInfo;

    tranLba2HAddr(u32GHP<<cSctrTo4kShift, &usTmpHAddrInfo);
    gsCacheInfo.u16SrchRslFBlock=c16FBlockInitValue;
    findReadSrc(g16HBlock, g16HPage, 0);

    if(gsCacheInfo.u16SrchRslFBlock==c16FBlockInitValue)
    {
        return 0;
    }
    else
    {
        return 1;
    }
}    /* SecIntf_JudgeWrittenGHP */

void SecIntf_SetSecurityWProMode()
{
    gSecurityWProMode=1;
}

LWORD SecIntf_GetCurrentMs(void)
{
    return getRtcCurrentMsForTsbCode();
}

#if 1
// =================== Arm Timer ===================
// example:
// count=enableArmTimer()
// .
// .
// .
// while(chkArmTimerTimeOut(count));
// disableArmTimer();

LWORD getFreq(WORD u16PLLSel)
{
    BYTE uVco, uPreScale;
    LWORD u32Freq;

    uVco=((u16PLLSel>>7)&0x0003)+1;
    uPreScale=(u16PLLSel>>9)&0x0003;
    u32Freq=((u16PLLSel&0x7f)*2500)>>(uVco+uPreScale);    // Unit: 10KHz

    return u32Freq;
}

BYTE enableCCNTCounter(LWORD u32Cnt)
{
    rmCp15DisCCNT;
    __ISB();
    rmCp15RstCNT;
    __ISB();
    rmCp15EnCCNT;
    __ISB();

    return 0;
}

LWORD enableArmTimer(LWORD u32IdleTimeMs)
{
    LWORD u32StopCnt, u32Freq;

    u32Freq=getFreq(rmGetSysClkPll);    // return unit 10KHz
    u32StopCnt=u32Freq*10*u32IdleTimeMs;

    enableCCNTCounter(u32StopCnt);

    return u32StopCnt;
}

void disableArmTimer()
{
    rmCp15DisCCNT;
}

BYTE chkArmTimerTimeOut(LWORD u32TimeOutCnt)
{
    return rmCp15ChkCCNT>=u32TimeOutCnt;
}

#endif/* if 0 */

/*Wait for a specified time in ms from the current time-stamp of the internal timer */
void SecIntf_TimerWaitMs(LWORD uTime)
{
    LWORD u32StopCnt;

    u32StopCnt=enableArmTimer((LWORD)uTime);

    while(!chkArmTimerTimeOut(u32StopCnt))
        ;

    disableArmTimer();
}

void SecIntf_SetSessionTimeout(BYTE uAction, LWORD u32SessionTimerStart, LWORD u32MaxSessionTimeout)
{
    if(gbEnSessionTimer)
    {
        if(uAction==cSessionTimeoutStart)
        {
            g32SessionTimerStart=u32SessionTimerStart;
            g32MaxSessionTimeout=u32MaxSessionTimeout;
            // NLOG(cLogSecApiBaseFw, SECAPI_BASEFW_C, 4, "  cSessionTimeoutStart(), g32SessionTimerStart = 0x%08X, g32MaxSessionTimeout =
            // 0x%08X.", g32SessionTimerStart>>16, (WORD)g32SessionTimerStart, g32MaxSessionTimeout>>16, (WORD)g32MaxSessionTimeout);
        }

        if(uAction==cSessionTimeoutStop)
        {
            g32SessionTimerStart=0;
            g32MaxSessionTimeout=0;
            // NLOG(cLogSecApiBaseFw, SECAPI_BASEFW_C, 0, "  cSessionTimeoutStop");
        }
    }
}    /* SecIntf_SetSessionTimeout */

void SecIntf_Crypto_LoadKey(BYTE *upRangeKey, BYTE uRangeID)
{
    NLOG(cLogSecApiBaseFw, SECAPI_BASEFW_C, 1, "  SecIntf_Crypto_LoadKey(), uRangeID = 0x%04X.", uRangeID);

    if(gbEnAes)
    {
        BYTE uLoop;
        LWORD u32RangeKeyOffset=rcAesDefaultKey00;

        switch(uRangeID)
        {
            case cRangeIdRange1:
                u32RangeKeyOffset=rcAesP0Key00;
                break;

            case cRangeIdRange2:
                u32RangeKeyOffset=rcAesP1Key00;
                break;

            case cRangeIdRange3:
                u32RangeKeyOffset=rcAesP2Key00;
                break;

            case cRangeIdRange4:
                u32RangeKeyOffset=rcAesP3Key00;
                break;

            case cRangeIdRange5:
                u32RangeKeyOffset=rcAesP4Key00;
                break;

            case cRangeIdRange6:
                u32RangeKeyOffset=rcAesP5Key00;
                break;

            case cRangeIdRange7:
                u32RangeKeyOffset=rcAesP6Key00;
                break;

            case cRangeIdRange8:
                u32RangeKeyOffset=rcAesP7Key00;
                break;

            case cRangeIdGlobalRange:
                u32RangeKeyOffset=rcAesDefaultKey00;
                break;

            default:
                break;
        }    /* switch */

        rmAesNormalMode;    // Switch to normal mode before changing keys
        rmFwAesNormalMode;

        for(uLoop=0; uLoop<cMekSize; uLoop++)
        {
            rAesCtrl[u32RangeKeyOffset+uLoop]=upRangeKey[uLoop];
            rFwAes[u32RangeKeyOffset+uLoop]=upRangeKey[uLoop];
        }

        rmAesMode;
        rmFwAesMode;

#if _ENABLE_SECAPI_DEBUG
        NLOG(cLogSecApiBaseFw, SECAPI_BASEFW_C, 4, " SecIntf_Crypto_LoadKey(): O32_AES_Key0_0=0x%08X, O32_AES_Key0_1=0x%08X ",
             (r32AesCtrl[u32RangeKeyOffset/4])>>16, (r32AesCtrl[u32RangeKeyOffset/4]), (r32AesCtrl[(u32RangeKeyOffset/4)+1])>>16,
             (r32AesCtrl[(u32RangeKeyOffset/4)+1]));
#endif
    }
}    /* SecIntf_Crypto_LoadKey */

void SecIntf_Crypto_SetRangePartitionRegister(BYTE uAction, LWORD u32LBAStart, LWORD u32LBAEnd, BYTE uRangeID)
{
    NLOG(cLogSecApiBaseFw,
         SECAPI_BASEFW_C,
         4,
         "  SecIntf_Crypto_SetRangePartitionRegister()-1 , u8Action = 0x%04X , uRangeID = 0x%04X , u32LBAStart = 0x%08X.",
         (WORD)uAction,
         (WORD)uRangeID,
         (WORD)(u32LBAStart>>16),
         (WORD)u32LBAStart);
    NLOG(cLogSecApiBaseFw,
         SECAPI_BASEFW_C,
         2,
         "  SecIntf_Crypto_SetRangePartitionRegister()-2 , u32LBAEnd = 0x%08X.",
         (WORD)(u32LBAEnd>>16),
         (WORD)u32LBAEnd);

    if(gbEnAes)
    {
        if(uAction&cEnableRange)
        {
            // HW AES Registers
            r32AesCtrl[rcAesFwP0LbaStart/4+((uRangeID-1)*4)]=u32LBAStart;
            r32AesCtrl[rcAesFwP0LbaEnd/4+((uRangeID-1)*4)]=(u32LBAEnd-1);    // u32LBAEnd is just the boundary not the actual LBA
            r16AesCtrl[rcAesPEn/2]|=cbBitTab[(uRangeID-1)];
            // FW AES Registers
            r32FwAes[rcAesFwP0LbaStart/4+((uRangeID-1)*4)]=u32LBAStart;
            r32FwAes[rcAesFwP0LbaEnd/4+((uRangeID-1)*4)]=(u32LBAEnd-1);    // u32LBAEnd is just the boundary not the actual LBA
            r16FwAes[rcAesPEn/2]|=cbBitTab[(uRangeID-1)];
        }

        if(uAction&cDisableRange)
        {
            // HW AES Registers
            r32AesCtrl[rcAesFwP0LbaStart/4+((uRangeID-1)*4)]=0;
            r32AesCtrl[rcAesFwP0LbaEnd/4+((uRangeID-1)*4)]=0;    // u32LBAEnd is just the boundary not the actual LBA
            r16AesCtrl[rcAesPEn/2]&=0xff^((0x01)<<(uRangeID-1));
            // FW AES Registers
            r32FwAes[rcAesFwP0LbaStart/4+((uRangeID-1)*4)]=0;
            r32FwAes[rcAesFwP0LbaEnd/4+((uRangeID-1)*4)]=0;    // u32LBAEnd is just the boundary not the actual LBA
            r16FwAes[rcAesPEn]&=0xff^((0x01)<<(uRangeID-1));
        }
    }
}    /* SecIntf_Crypto_SetRangePartitionRegister */

void SecIntf_Crypto_KeyWrapping(BYTE uAction,
                                BYTE *upInputKey,
                                BYTE uInputKeylength,
                                BYTE *upInputString,
                                BYTE uInputStringLength,
                                BYTE *upOutputString,
                                LWORD MemoryAddr,
                                BYTE *upStatus)
{
    BYTE uarInputKey[cKekSize];

    // have a copy because crypto function will modify the value of input key
    moveMem2Mem((LWORD)&upInputKey[0], (LWORD)&uarInputKey[0], uInputKeylength);

    if(uAction&cEncrypt)    // Don't need to maintain the value of u8Status
    {
        KeyWraping_AE(uarInputKey, uInputKeylength, upInputString, uInputStringLength, upOutputString, MemoryAddr);
    }

    if(uAction&cDecrypt)
    {
        *upStatus=KeyWraping_AD(uarInputKey, uInputKeylength, upInputString, uInputStringLength, upOutputString, MemoryAddr);

        if(*upStatus)
        {
            NLOG(cLogSecApiBaseFw, SECAPI_BASEFW_C, 0, "  SecIntf_Crypto_KeyWrapping() - Decrypt fails.");
        }
    }
}    /* SecIntf_Crypto_KeyWrapping */

void SecIntf_Crypto_SP800_108(BYTE *upInputKey,
                              BYTE uInputKeylength,
                              BYTE *upLabel,
                              LWORD u32LabelLength,
                              BYTE *upContext,
                              LWORD u32ContextLength,
                              BYTE *upOutputString,
                              LWORD u32OutputLength,
                              LWORD MemoryAddr)
{
    KDF_Counter_Mode(upInputKey,
                     uInputKeylength,
                     upLabel,
                     u32LabelLength,
                     upContext,
                     u32ContextLength,
                     upOutputString,
                     u32OutputLength,
                     MemoryAddr,
                     0);
}

void SecIntf_Crypto_SP800_132(BYTE *upInputPassword,
                              BYTE uInputPasswordLength,
                              BYTE *upSalt,
                              BYTE uSaltLength,
                              LWORD u32IterationCount,
                              BYTE *upOutputString,
                              LWORD u32OutputLength,
                              LWORD MemoryAddr)
{
    PBKDF(upInputPassword, uInputPasswordLength, upSalt, uSaltLength, u32IterationCount, upOutputString, u32OutputLength, MemoryAddr, 0);
}

void SecIntf_Crypto_GetRootKey(LWORD MemoryAddr, BYTE *upRootKey)
{
    // MemoryAddr isn't needed to be taken care of in SM2260
    moveMem2Mem((LWORD)&gSecuEfuse[0], (LWORD)&upRootKey[0], cRootKeySize);
}

void SecIntf_Crypto_GenerateRandomNum(BYTE u8ByteLen, BYTE *uRandomNum)
{
    Crypto_GenerateNDRBG(uRandomNum, (LWORD)u8ByteLen);

    if(u8ByteLen==cMekSize)    // Gen AES Key
    {
        // Check AES Key1 != Key2
        if(SecIntf_MemoryCompare((LWORD)((BYTE *)&uRandomNum[0]), (LWORD)((BYTE *)&uRandomNum[32]), 32))
        {
            Crypto_GenerateNDRBG(uRandomNum, (LWORD)u8ByteLen);

            if(SecIntf_MemoryCompare((LWORD)((BYTE *)&uRandomNum[0]), (LWORD)((BYTE *)&uRandomNum[32]), 32))
            {
                NLOG(cLogSecApiBaseFw, SECAPI_BASEFW_C, 0, "  SecIntf_Crypto_GenerateRandomNum() failed, AES Key1 = Key2");
            }
        }
    }
}    /* SecIntf_Crypto_GenerateRandomNum */

void SecIntf_MOVE_MEM2MEM(LWORD u32SrcAddr, LWORD u32DesAddr, LWORD u32Len)
{
    if(u32Len>128)    // Use Hardware BOP resource
    {
        BYTE uDir=cDmaTsb2Tsb;

        /* TSB */
        if((u32SrcAddr>>24)==0x40)
        {
            if((u32DesAddr>>24)==0x40)
            {
                uDir=cDmaTsb2Tsb;
            }
            else if((u32DesAddr>>16)==0x02)
            {
                uDir=cDmaTsb2Dccm;
            }
            // #if S_SecAPI_NVMe
            else if((u32DesAddr>>16)==0x03)
            {
                uDir=cDmaTsb2Stcm;
            }
            // #endif
            else if((u32DesAddr>>17)==0x00)
            {
                uDir=cDmaTsb2Iccm;
            }
        }
        /* DCCM */
        else if((u32SrcAddr>>16)==0x02)
        {
            if((u32DesAddr>>24)==0x40)
            {
                uDir=cDmaDccm2Tsb;
            }
        }
        /* STCM */
        else if(((u32SrcAddr>>16)==0x03)&&((u32DesAddr>>24)==0x40))
        {
            uDir=cDmaStcm2Tsb;
        }
        /* ICCM */
        else if(((u32SrcAddr>>17)==0x00)&&((u32DesAddr>>24)==0x40))
        {
            uDir=cCopyIccm2Tsb;
        }

        if((uDir<cCopyTsb2Cpu1Dccm))
        {
            bopCopyRam(u32DesAddr, u32SrcAddr, u32Len, uDir|cBopWait);
        }
        else
        {
            moveMem2Mem(u32SrcAddr, u32DesAddr, u32Len);
        }
    }
    else    // Use CPU resource
    {
        moveMem2Mem(u32SrcAddr, u32DesAddr, u32Len);
    }
}    /* SecIntf_MOVE_MEM2MEM */

BYTE SecIntf_MemoryCompare(LWORD u32SrcAddr, LWORD u32DesAddr, LWORD u32Len)
{
    BYTE uStatus;

    uStatus=memoryCompareAddress(u32SrcAddr, u32DesAddr, u32Len);
    return uStatus;
}

void SecIntf_DebugLog(BYTE uPriority, BYTE uIdx, BYTE uParaCnt, WORD u16para0, WORD u16para1, WORD u16para2, WORD u16para3, WORD u16SaveLogID)
{
#if _DEBUG_LOG
    // if (u16SaveLogID)
    // {
    //    debugLogSave(uPriority, uIdx, uParaCnt, u16SaveLogID, u16para0, u16para1, u16para2, u16para3);
    // }
    // else
    {
        debugLog(uPriority, uIdx, uParaCnt, u16para0, u16para1, u16para2, u16para3);
    }
#endif
}

void getSecRWInfo(BYTE uMode)
{
#if !_GREYBOX
    SFP.gfpSecIntf_GetLBAInfo(uMode, &g32SecLba, &g32HostXfrCnt);
#else
    g32SecLba=gsGbInfo.u32BurnInStart;
    g32HostXfrCnt=gsGbInfo.u32BurnInCnt;
#endif

#if _ENABLE_SECAPI_W_DEBUG
    NLOG(cLogSecApiDebug, SECAPI_BASEFW_C, 4, "  GetSecRWInfo() , g32SecLba = 0x%08X , g32HostXfrCnt = 0x%08X.",
         (WORD)(g32SecLba>>16), (WORD)g32SecLba, (WORD)(g32HostXfrCnt>>16), (WORD)g32HostXfrCnt);
#endif

    gSecStartSectorH=g32SecLba&(cSctrPer4k-1);
    g32SecGlobalHPage=g32SecLba>>cSctrTo4kShift;
    g16ReadUnitCnt=(g32HostXfrCnt+gSecStartSectorH+(cSctrPer4k-1))>>cSctrTo4kShift;
}    /* getSecRWInfo */

void handleTcgNop1(BYTE uMode, LWORD u32SecGlobalHPage, LWORD *u32SecHpage)
{
    LWORD u32OrigSecGlobalHPage;
    LWORD u32PartReadGHP;
    HADDRINFO usTmpHAddrInfo;
    WORD u16NowNodeIdx;

    // volatile BYTE uSTOP=1;
    // while(uSTOP);
    // Read NOP1 Head
    if(1)    // (gSecStartSectorH)
    {
        u32OrigSecGlobalHPage=u32SecGlobalHPage;

#if !_GREYBOX
        u32PartReadGHP=SFP.gfpSecIntf_TCG_JudgeRWGHP(&u32SecGlobalHPage);
#else
        u32PartReadGHP=u32SecGlobalHPage;
#endif
        u32SecHpage[0]=u32SecGlobalHPage;
        tranLba2HAddr(u32PartReadGHP<<cSctrTo4kShift, &usTmpHAddrInfo);

        gsCacheInfo.u16SrchRslFBlock=c16FBlockInitValue;
        gsCacheInfo.u32SrchRslFPage=c32BitFF;
        findReadSrc(g16HBlock, g16HPage, 0);
        u16NowNodeIdx=gsRwCtrl.uarFreeSrcQue[gsRwCtrl.u32FreeSrcFifoHead];
        gpFlashAddrInfo=&garSrcAddrInfo[u16NowNodeIdx];

        g32FPageNoTran=gsCacheInfo.u32SrchRslFPage;
        gpFlashAddrInfo->uPrdPtr=0xF1;
        gpFlashAddrInfo->uTsb4kIdx=0xFF;
        gpFlashAddrInfo->uSrcIdx=u16NowNodeIdx;

#if _ENABLE_SECAPI_W_DEBUG
        {
            NLOG(cLogSecApiDebug,
                 SECAPI_BASEFW_C,
                 5,
                 "handleTcgNop1() - head , HBlock = 0x%04X , HPage = 0x%08X, GHP = 0x%08X.",
                 (WORD)gpHostAddrInfo->u16HBlock,
                 (WORD)gpHostAddrInfo->u16HPage>>16,
                 (WORD)gpHostAddrInfo->u16HPage,
                 (WORD)(u32PartReadGHP>>16),
                 (WORD)u32PartReadGHP
                 );
        }
#endif

        if(gsCacheInfo.u16SrchRslFBlock==c16FBlockInitValue)
        {
            g16FBlock=g16AbstrFBlock=0;
            mSetFRwParam(0, cSctrPer4k    /*gSecStartSectorH*/, 0, cSecReadDummy);
        }
        else
        {
            g16FBlock=gsCacheInfo.u16SrchRslFBlock;
            // gSectorH=mTranSctr4kAddr(g32FPageNoTran)+gStartSector;
            gSectorH=mTranSctr4kAddr(g32FPageNoTran);
            tranAddrInfo(gpFlashAddrInfo);
            // mSetFRwParam(0, gSecStartSectorH, c16Bit1|c16Bit4|c16Bit11, cSecReadData);
            mSetFRwParam(0, cSctrPer4k, c16Bit4, cSecReadData);    // gSecStartSectorH will lose data(byte base).
        }

        gsRwCtrl.u32FreeSrcFifoHead=(gsRwCtrl.u32FreeSrcFifoHead+1)&(cReadFifoDpt-1);
        // invPlaneBufFlagCore0(0, gSecStartSectorH, cInvBufFlag);
    }
    else
    {
        u32OrigSecGlobalHPage=c32BitFF;
        u32SecHpage[0]=c32BitFF;
    }

    // Read NOP1 Tail
    if((g32SecLba+g32HostXfrCnt)%cSctrPer4k)
    {
        // uNopTailSctCnt=cSctrPer4k-((g32SecLba+g32HostXfrCnt)%cSctrPer4k);

        u32SecGlobalHPage=(g32SecLba+g32HostXfrCnt)>>cSctrTo4kShift;

        if(u32OrigSecGlobalHPage!=u32SecGlobalHPage)
        {
            {
#if !_GREYBOX
                u32PartReadGHP=SFP.gfpSecIntf_TCG_JudgeRWGHP(&u32SecGlobalHPage);
#else
                u32PartReadGHP=u32SecGlobalHPage;
#endif
                u32SecHpage[1]=u32SecGlobalHPage;
                tranLba2HAddr(u32PartReadGHP<<cSctrTo4kShift, &usTmpHAddrInfo);
            }

            gsCacheInfo.u16SrchRslFBlock=c16FBlockInitValue;
            gsCacheInfo.u32SrchRslFPage=c32BitFF;
            findReadSrc(g16HBlock, g16HPage, 0);

            u16NowNodeIdx=gsRwCtrl.uarFreeSrcQue[gsRwCtrl.u32FreeSrcFifoHead];
            gpFlashAddrInfo=&garSrcAddrInfo[u16NowNodeIdx];

            g32FPageNoTran=gsCacheInfo.u32SrchRslFPage;
            gpFlashAddrInfo->uPrdPtr=0xF2;
            gpFlashAddrInfo->uTsb4kIdx=0xFF;
            gpFlashAddrInfo->uSrcIdx=u16NowNodeIdx;

#if _ENABLE_SECAPI_W_DEBUG
            NLOG(cLogSecApiDebug,
                 SECAPI_BASEFW_C,
                 5,
                 "handleTcgNop1() - tail , HBlock = 0x%04X , HPage = 0x%08X, GHP = 0x%08X.",
                 (WORD)gpHostAddrInfo->u16HBlock,
                 (WORD)gpHostAddrInfo->u16HPage>>16,
                 (WORD)gpHostAddrInfo->u16HPage,
                 (WORD)(u32PartReadGHP>>16),
                 (WORD)u32PartReadGHP
                 );
#endif

            if(gsCacheInfo.u16SrchRslFBlock==c16FBlockInitValue)
            {
                g16FBlock=g16AbstrFBlock=0;
                // mSetFRwParam(gSecStartSectorH+g32HostXfrCnt, uNopTailSctCnt, 0, cSecReadDummy);
                mSetFRwParam(((gSecStartSectorH+g32HostXfrCnt)&c16BufPtrAlign4k), cSctrPer4k, 0, cSecReadDummy);
            }
            else
            {
                g16FBlock=gsCacheInfo.u16SrchRslFBlock;
                gSectorH=mTranSctr4kAddr(g32FPageNoTran);
                // gSectorH=mTranSctr4kAddr(g32FPageNoTran)+gStartSector;
                tranAddrInfo(gpFlashAddrInfo);

                // mSetFRwParam(gSecStartSectorH+g32HostXfrCnt, uNopTailSctCnt, c16Bit1|c16Bit4|c16Bit11, cSecReadData);
                mSetFRwParam(((gSecStartSectorH+g32HostXfrCnt)&c16BufPtrAlign4k), cSctrPer4k, c16Bit4, cSecReadData);
            }

            gsRwCtrl.u32FreeSrcFifoHead=(gsRwCtrl.u32FreeSrcFifoHead+1)&(cReadFifoDpt-1);
            // invPlaneBufFlagCore0(gSecStartSectorH+g32HostXfrCnt, uNopTailSctCnt, cInvBufFlag);
        }
        else
        {
            u32SecHpage[1]=c32BitFF;
        }
    }
    else
    {
        u32SecHpage[1]=c32BitFF;
    }

    while(gsRwCtrl.u32FreeSrcFifoTail!=gsRwCtrl.u32FreeSrcFifoHead)
        ;

#if _ENABLE_RAID
    // rmResetBufFlg;
#endif
}    /* handleTcgNop1 */

// uMode : 0xFF is for RPMB.
BYTE SecIntf_TCG_Write(BYTE uMode)
{
    HADDRINFO usTmpHAddrInfo;
    LWORD u32DesAddr;
    LWORD u32GHP;
    LWORD u32TotalSctrCnt;
    LWORD u32SecHpage[2];

    // WORD u16PrdSctrCnt;
    // BYTE uStartSct;
    BYTE uRWStatus=cRwSuccess;
    BYTE uWriteSctrCnt;
    BYTE uInvSctCnt;

    while(!gInSecApi)
        ;

    if(g16SecTrimPtr)
    {
        handleSecTrim();
    }

    // step 1 : get LBA and XfrCnt and other parameter, trigger to Read old data into garTcgDataBuf
    getSecRWInfo(uMode);

    if(gSecurityWProMode)    // handle read only mode
    {
        NLOG(cLogSecApiBaseFw, SECAPI_BASEFW_C, 0, "SecIntf_TCG_Write() Read Only Mode.");
        uRWStatus=cRwReadOnly;
        return uRWStatus;
    }

    if(!g16ReadUnitCnt)
    {
        NLOG(cLogSecApiBaseFw, SECAPI_BASEFW_C, 0, "SecIntf_TCG_Write() g16ReadUnitCnt=0.");
        uRWStatus=cRwNoXfrCnt;
        return uRWStatus;
    }

    // Can't over 64KB
    while(g16ReadUnitCnt>16)
        ;

    initNewFblkProc(0xFE);

    // step 2 : Read NOP1
    handleTcgNop1(uMode, g32SecGlobalHPage, u32SecHpage);

    u32GHP=g32SecGlobalHPage;
    // gsRwCtrl.uCachePtr=0;
    u32DesAddr=cTrustedRwBufferAddr+(gSecStartSectorH<<cSingleSectorShift);

#if _ENABLE_SECAPI_W_DEBUG
    NLOG(cLogSecApiBaseFw,
         SECAPI_BASEFW_C,
         3,
         "SecIntf_TCG_Write() g16WriteBufPtr=0x%04X, g16FlashWBufPtr=0x%04X, gsGcInfo.ubBgdProcF=0x%04X",
         g16WriteBufPtr,
         g16FlashWBufPtr,
         (WORD)gsGcInfo.ubBgdProcF
         );
#endif

    g16BackupWriteBufPtr=g16FlashWBufPtr;
    g16WriteBufPtr=cTrustedRwBufferStartBufIdx;
    g16FlashWBufPtr=cTrustedRwBufferStartBufIdx;

    // step 2 : move the new data to Rw buffer (cover part of the old data on Rw buffer)
#if !_GREYBOX
    SFP.gfpSecIntf_TCG_WriteProcess(uMode, u32DesAddr, cTrustedRwBufferAddr+cTrustedRwBufferBufSize, cTrustedRwBufferAddr);
#else
    bopCopyRam(u32DesAddr, 0x40050000, (gsGbInfo.u32BurnInCnt<<cSingleSectorShift), cCopyTsb2Tsb|cBopWait);
#endif

#if 0    // _ENABLE_E2E_PROTECTION
    // shadow MBR doesn't need E2E protection.
    gsE2eInfo.u32GenerateLba=g32SecLba-gTcgReservedSecShiftCnt-g32HostTotalDataSectorCnt;
    bopCopyRam(u32DesAddr, u32DesAddr, g32HostXfrCnt*0x0200, cCopyTsb2Tsb|cBopWait|cBopEnCrc|cBopGenCrc);
#endif

    // step 3 : invert buffer flag.
#if 1
    u32DesAddr=0;
    u32TotalSctrCnt=((gSecStartSectorH+g32HostXfrCnt+(cSctrPer4k-1))>>cSctrTo4kShift)<<cSctrTo4kShift;

    do
    {
        uInvSctCnt=gSectorPerPlaneH;

        if(uInvSctCnt>u32TotalSctrCnt)
        {
            uInvSctCnt=u32TotalSctrCnt;
        }

        invPlaneBufFlagCore0(u32DesAddr, uInvSctCnt, cInvBufFlag);

        u32DesAddr+=uInvSctCnt;
        u32TotalSctrCnt-=uInvSctCnt;
    }
    while(u32TotalSctrCnt);

#else/* if 1 */
    uStartSct=gSecStartSectorH;
    u32DesAddr=gSecStartSectorH;

    u32TotalSctrCnt=g32HostXfrCnt;

    do
    {
        uInvSctCnt=gSectorPerPlaneH-uStartSct;

        if(uInvSctCnt>u32TotalSctrCnt)
        {
            uInvSctCnt=u32TotalSctrCnt;
        }

        invPlaneBufFlagCore0(u32DesAddr, uInvSctCnt, cInvBufFlag);
        uStartSct=0;
        u32DesAddr+=uInvSctCnt;
        u32TotalSctrCnt-=uInvSctCnt;
    }
    while(u32TotalSctrCnt);
#endif/* if 1 */

    u32TotalSctrCnt=g32HostXfrCnt;

    do
    {
        // step 4 : judge where to read the old data and where to write the new data [D.H]
        g32SecGlobalHPage=u32GHP;
#if _ENABLE_SECAPI_W_DEBUG
        LWORD u32DebugSecGlobalHPage=(g32SecGlobalHPage-((g32TotalDatSector-cTcgReserveSecCnt)>>3))>>3;
#endif

        // read old data from u32PartReadGHP; write new data in g32GlobalHPage
        if((u32TotalSctrCnt==g32HostXfrCnt)&&(u32SecHpage[0]!=c32BitFF))
        {
            g32SecGlobalHPage=u32SecHpage[0];
        }
        else if((u32TotalSctrCnt<cSctrPer4k)&&(u32SecHpage[1]!=c32BitFF))
        {
            g32SecGlobalHPage=u32SecHpage[1];
        }
        else
        {
#if !_GREYBOX
            SFP.gfpSecIntf_TCG_JudgeRWGHP(&g32SecGlobalHPage);
#endif
        }

        tranLba2HAddr(g32SecGlobalHPage<<cSctrTo4kShift, &usTmpHAddrInfo);

#if _ENABLE_SECAPI_W_DEBUG
        NLOG(cLogSecApiDebug, SECAPI_BASEFW_C, 2, "SecIntf_TCG_Write() u32GHP = 0x%08X .",
             (WORD)(g32SecGlobalHPage>>16), (WORD)g32SecGlobalHPage);
        NLOG(cLogSecApiDebug,
             SECAPI_BASEFW_C,
             4,
             "SecIntf_TCG_Write() u32DebugSecGlobalHPage = 0x%08X,  MBRValidBitMap, uBitMap = 0x%04X, uBitMapUpdate = 0x%04X .",
             (WORD)(u32DebugSecGlobalHPage>>16),
             (WORD)u32DebugSecGlobalHPage,
             (WORD)garMBRValidBitMap[u32DebugSecGlobalHPage],
             (WORD)garMBRValidBitMap[u32DebugSecGlobalHPage+4416]);
#endif

        if(gSecStartSectorH)
        {
            gStartSector=gSecStartSectorH;
        }

        if(mChkChgBlock)
        {
            initNewFblkProc(0xFE);
            mClrChgBlock;

            if(gsRwCtrl.u16OccFSkipSize>=c16WriteBufSize)
            {
                chkBufOccupy(c16Null);
            }
        }

        uWriteSctrCnt=cSctrPer4k-gSecStartSectorH;

        if(uWriteSctrCnt>u32TotalSctrCnt)
        {
            uWriteSctrCnt=u32TotalSctrCnt;
            mSetCacheInBufW;
        }
        else
        {
            mClrCacheInBufW;
        }

#if _ENABLE_SECAPI_W_DEBUG
        NLOG(cLogSecApiDebug,
             SECAPI_BASEFW_C,
             6,
             "SecIntf_TCG_Write() HBlock = 0x%04X , HPage = 0x%08X, GHP = 0x%08X, WriteSctrCnt = 0x%04X.",
             (WORD)gpHostAddrInfo->u16HBlock,
             (WORD)gpHostAddrInfo->u16HPage>>16,
             (WORD)gpHostAddrInfo->u16HPage,
             (WORD)(g32SecGlobalHPage>>16),
             (WORD)g32SecGlobalHPage,
             (WORD)uWriteSctrCnt);
#endif

        // step 3 : update write information and assign part read Fifo
        if(!mChkCacheInBuf(gsRwCtrl.uCachePtr))
        {
            gsRwCtrl.u16arCacheHPage[gsRwCtrl.uCachePtr]=g16HPage;
            gsRwCtrl.u16arCacheHBlock[gsRwCtrl.uCachePtr]=g16HBlock;
            gsRwCtrl.uCacheStartSctr=gSecStartSectorH;
        }

        gsRwCtrl.uPrdPtr[gsRwCtrl.uCachePtr]=0xF5;
        gsRwCtrl.uCacheEndSctr=gSecStartSectorH+uWriteSctrCnt;

        if(mChkCacheInBufW)
        {
            mSetCacheInBuf(gsRwCtrl.uCachePtr);
        }
        else
        {
            if((mGetStartSctr!=0)||(mGetEndSctr!=cSctrPer4k))
            {
#if _ENABLE_SECAPI_W_DEBUG
                NLOG(cLogSecApiDebug,
                     SECAPI_BASEFW_C,
                     2,
                     "SecIntf_TCG_Write() - readNop1Proc , mGetStartSctr = 0x%04X , mGetEndSctr = 0x%04X .",
                     (WORD)mGetStartSctr,
                     (WORD)mGetEndSctr);
#endif
                // readNop1Proc(0);
                gsCacheInfo.u32WriteSctr2ChgBlk-=(mGetStartSctr+(cSctrPer4k-mGetEndSctr));

                if(!gsCacheInfo.u32WriteSctr2ChgBlk)
                {
                    mSetChgBlock;
                    mSetCalWriteSctr2ChgBlk;
                }

                gsRwCtrl.uCacheStartSctr=0;
                gsRwCtrl.uCacheEndSctr=cSctrPer4k;
            }

            gpFlashAddrInfo=&garDesAddrInfo[gsRwCtrl.u32ProgFifoHead];

            if(mChkNewDesF)
            {
                setWriteDes(gsRwCtrl.u16ProgPageOfst, gpFlashAddrInfo, cWriteCache);
                mClrNewDesF;    // gbNewDesF=0;
            }

            garDesF2hInfo[gsRwCtrl.u32ProgFifoHead].u16arHPage[gsRwCtrl.uCachePtr]=g16HPage;    // gsRwCtrl.u16arCacheHPage[gsRwCtrl.uCachePtr];
            garDesF2hInfo[gsRwCtrl.u32ProgFifoHead].u16arHBlock[gsRwCtrl.uCachePtr]=g16HBlock;    // gsRwCtrl.u16arCacheHBlock[gsRwCtrl.uCachePtr];
            rmSetSrchTgt(gsRwCtrl.uMaskTgtPtr, (g16HBlock<<16)|g16HPage);
            gsRwCtrl.uMaskTgtPtr++;
            setProgFifoOpt(0xFE);    // Temp [D.H]
        }

        addLbaAddr(uWriteSctrCnt);
        gsCacheInfo.u32WriteSctr2ChgBlk-=uWriteSctrCnt;

        if(!gsCacheInfo.u32WriteSctr2ChgBlk)
        {
            mSetChgBlock;
            mSetCalWriteSctr2ChgBlk;
        }

#if _ENABLE_SECAPI_W_DEBUG
        NLOG(cLogSecApiDebug,
             SECAPI_BASEFW_C,
             3,
             "SecIntf_TCG_Write() gsRwCtrl.u16OccFSkipSize = 0x%04X, gWriteFlag = 0x%04X,u32TotalSctrCnt  = 0x%04X",
             (WORD)gsRwCtrl.u16OccFSkipSize, (WORD)gWriteFlag, (WORD)u32TotalSctrCnt
             );
#endif

        u32TotalSctrCnt-=uWriteSctrCnt;

        if(gsRwCtrl.u16OccFSkipSize>=c16WriteBufSize)
        {
            chkBufOccupy(c16Null);
        }

        // if(u32TotalSctrCnt)
        // {
        //    gSecStartSectorH=gStartSector;
        // }
        gSecStartSectorH=0;
        u32GHP++;
    }
    while(u32TotalSctrCnt&&!mChkHandlePcieErrF);

    // here need to add errorhandle.[D.H]

    if((mGetStartSctr!=0)||(mGetEndSctr!=cSctrPer4k))
    {
#if _ENABLE_SECAPI_W_DEBUG
        NLOG(cLogSecApiDebug, SECAPI_BASEFW_C, 2, "SecIntf_TCG_Write() - readNop1Proc , mGetStartSctr = 0x%04X , mGetEndSctr = 0x%04X .",
             (WORD)mGetStartSctr, (WORD)mGetEndSctr);
#endif
        gsCacheInfo.u32WriteSctr2ChgBlk-=(mGetStartSctr+(cSctrPer4k-mGetEndSctr));

        if(!gsCacheInfo.u32WriteSctr2ChgBlk)
        {
            mSetChgBlock;
            mSetCalWriteSctr2ChgBlk;
        }

        gsRwCtrl.uCacheStartSctr=0;
        gsRwCtrl.uCacheEndSctr=cSctrPer4k;
    }

    termFlashOperW(0);

    // if (g16BackupWriteBufPtr==0xFFFF)
    // {
    //    g16FlashWBufPtr=0;
    // }
    // else
    // {
    g16FlashWBufPtr=addWriteBufPtr(g16FlashWBufPtr, g16BackupWriteBufPtr);
    // }
    g16WriteBufPtr=g16FlashWBufPtr;
#if _ENABLE_SECAPI_W_DEBUG
    NLOG(cLogSecApiDebug,
         SECAPI_BASEFW_C,
         2,
         "SecIntf_TCG_Write() WriteBufPtr=0x%04X, gsGcInfo.ubBgdProcF=0x%04X",
         g16WriteBufPtr,
         (WORD)gsGcInfo.ubBgdProcF);
#endif

    NLOG(cLogSecApiBaseFw, SECAPI_BASEFW_C, 0, "SecIntf_TCG_Write() end.");
    return uRWStatus;
}    /* SecIntf_TCG_Write */

BYTE SecIntf_TCG_Read(BYTE uMode)
{
    HADDRINFO usTmpHAddrInfo;
    LWORD u32PhysicalGHP;
    LWORD u32TotalSctrCnt;
    WORD u16NowNodeIdx;
    WORD u16BufPtr;
    BYTE uRWStatus=cRwSuccess;
    BYTE uReadSctrCnt;

    // volatile BYTE uSTOP=1;

    NLOG(cLogSecApiBaseFw, SECAPI_BASEFW_C, 0, "SecIntf_TCG_Read() start.");

    // while(uSTOP);
    // step 1 : get LBA and XfrCnt and other parameter
    getSecRWInfo(uMode);

    u32TotalSctrCnt=g32HostXfrCnt;

    u16BufPtr=cTrustedRwBufferStartBufIdx;

    do
    {
        // step 2 : assign read fifo
#if !_GREYBOX
        u32PhysicalGHP=SecAPI_GetReadGHP_Request(cTcgReadUpdated, g32SecGlobalHPage);
#else
        u32PhysicalGHP=g32SecGlobalHPage;
#endif
        tranLba2HAddr(u32PhysicalGHP<<cSctrTo4kShift, &usTmpHAddrInfo);

        if(gSecStartSectorH)
        {
            gStartSector=gSecStartSectorH;
        }

        gsCacheInfo.u16SrchRslFBlock=c16FBlockInitValue;
        gsCacheInfo.u32SrchRslFPage=c32BitFF;
        findReadSrc(g16HBlock, g16HPage, 0);
        u16NowNodeIdx=gsRwCtrl.uarFreeSrcQue[gsRwCtrl.u32FreeSrcFifoHead];
        gpFlashAddrInfo=&garSrcAddrInfo[u16NowNodeIdx];
        g32FPageNoTran=gsCacheInfo.u32SrchRslFPage;
        gpFlashAddrInfo->uPrdPtr=0xF0;
        gpFlashAddrInfo->uTsb4kIdx=0xFF;
        gpFlashAddrInfo->uSrcIdx=u16NowNodeIdx;
        uReadSctrCnt=getReadSctrCnt(u32TotalSctrCnt);

#if _ENABLE_SECAPI_W_DEBUG
        NLOG(cLogSecApiDebug,
             SECAPI_BASEFW_C,
             6,
             "SecIntf_TCG_Read() , HBlock = 0x%04X , HPage = 0x%08X, GHP = 0x%08X, ReadSctrCnt = 0x%04X.",
             (WORD)gpHostAddrInfo->u16HBlock,
             (WORD)gpHostAddrInfo->u16HPage>>16,
             (WORD)gpHostAddrInfo->u16HPage,
             (WORD)(u32PhysicalGHP>>16),
             (WORD)u32PhysicalGHP,
             (WORD)uReadSctrCnt);
#endif

        if(gsCacheInfo.u16SrchRslFBlock==c16FBlockInitValue)
        {
            g16FBlock=g16AbstrFBlock=0;
            mSetFRwParam(u16BufPtr, uReadSctrCnt, 0, cSecReadDummy);
        }
        else
        {
            g16FBlock=gsCacheInfo.u16SrchRslFBlock;
            gSectorH=mTranSctr4kAddr(g32FPageNoTran)+gStartSector;
            tranAddrInfo(gpFlashAddrInfo);
            mSetFRwParam(u16BufPtr, uReadSctrCnt, c16Bit4, cSecReadData);
        }

        gsRwCtrl.u32FreeSrcFifoHead=(gsRwCtrl.u32FreeSrcFifoHead+1)&(cReadFifoDpt-1);

        u16BufPtr+=uReadSctrCnt;

#if 0

        if(uMode!=0xFF)
        {
            // if(uUnitCnt!=1)
            // {
            // u32PhysicalGHP=SecAPI_GetReadGHP_Request(cTcgReadUpdated, g32SecGlobalHPage);
            // tranLba2HAddr(u32PhysicalGHP<<cSctrTo4kShift, &usTmpHAddrInfo);

            g32SecGlobalHPage++;
            // g16ReadUnitCnt--;
            // }
            // else
            // {
            //    break;
            // }
        }
        else
        {
            // if(uUnitCnt!=1)
            // {
            //    gStartSector=(gStartSector+uReadSctrCnt)&(cSctrPer4k-1);    // mod(gStartSector+uReadSctrCnt, cSctrPer4k);
            // u32TotalSctrCnt-=uReadSctrCnt;
            //    gpHostAddrInfo->uSrchSrcTabStIdx=(gpHostAddrInfo->uSrchSrcTabStIdx+1)&(cSrchSrcNum-1);
            // g16ReadUnitCnt--;
            //    g16HPage++;
            // }
            // else
            // {
            //    break;
            // }
        }
#endif/* if 0 */
        g32SecGlobalHPage++;
        u32TotalSctrCnt-=uReadSctrCnt;
        gSecStartSectorH=0;
        // if(u32TotalSctrCnt)
        // {
        //    gSecStartSectorH=gStartSector;
        // }
    }
    while(u32TotalSctrCnt&&!mChkHandlePcieErrF);

    // step 3 : finish read fifo
    while(gsRwCtrl.u32FreeSrcFifoTail!=gsRwCtrl.u32FreeSrcFifoHead)
        ;

    // step 4: check if the assigned read data have UNC
    // if(gReadUNC)  // hanlde unc
    // {
    //    NLOG(cLogSecApiBaseFw, SECAPI_BASEFW_C, 0, "SecIntf_TCG_Read() UNC fail.");
    //	uRWStatus=cRwUnc;
    //	gReadUNC=0;
    // }

    // step 5 : move data (TSB0 Buffer Wrap issue will not happen because g16UnitBufIdx=0 and that host requests at most 32K data)
#if !_GREYBOX
    SFP.gfpSecIntf_TCG_ReadDone(uMode, cTrustedRwBufferAddr);
#endif

    // Reset all the flags set on TSB in the security flow because these flags will not be cleared
    rmResetBufFlg;
    rmResetOccupyFlg;

    return uRWStatus;
}    /* SecIntf_TCG_Read */

BYTE handleTrustedSend()
{
    BYTE uStatus;

    g32ReceivedXfrCnt=(rmNvmeSecTl+(512-1))>>9;
    g32ReceivedXfrByte=rmNvmeSecTl;
    gReceivedProtocolId=rmNvmeSecSecp;
    g16ReceivedComId=rmNvmeSecSpsp;
    gReceivedRpmbTarget=rmNvmeSecNssf;    // Used for RPMB

#if _ENABLE_ATA_PASSTHROUGH

    if(rmChkSecurityErasePrepare)
    {
        if(!((gReceivedProtocolId==0xEF)&&(g16ReceivedComId==cAtaSecurityErasePrepare)))
        {
            rmClrSecurityErasePrepare;
        }
    }
    else
    {
        if(gReceivedProtocolId==0xEF)
        {
            if(g16ReceivedComId==cAtaSecurityErase)
            {
                NLOG_SAVE(cLogSecApiBaseFw,
                          SECAPI_BASEFW_C,
                          1,
                          cSaveIdSecurity,
                          "HandleTrustedSend(), ATA ErasePrepare not ready, status = 0x%04X.",
                          (WORD)gSecurityStatus);
                return cATASecurityCmdError;
            }
            else if(g16ReceivedComId==cAtaSecurityErasePrepare)
            {
                if(rmChkSecurityFrozen)
                {
                    NLOG_SAVE(cLogSecApiBaseFw,
                              SECAPI_BASEFW_C,
                              1,
                              cSaveIdSecurity,
                              "HandleTrustedSend(), ATA Security Frozen, status = 0x%04X.",
                              (WORD)gSecurityStatus);
                    return cATASecurityCmdError;
                }
                else
                {
                    rmSetSecurityErasePrepare;
                    NLOG_SAVE(cLogSecApiBaseFw,
                              SECAPI_BASEFW_C,
                              1,
                              cSaveIdSecurity,
                              "HandleTrustedSend(), ATA Set ErasePrepare, status = 0x%04X.",
                              (WORD)gSecurityStatus);
                    return cGood;
                }
            }
        }
    }
#endif/* if _ENABLE_ATA_PASSTHROUGH */

    uStatus=SFP.gfpSecIntf_IfSendCmd(gReceivedProtocolId, g16ReceivedComId, g32ReceivedXfrByte);
    // May return C_Good,
    // C_Invalid_Transfer_Length,
    // C_Invalid_Transfer_Length_IEEE1667,
    // or C_No_Allocation_Length

    if(uStatus==cGood)
    {
        if(g32ReceivedXfrByte)
        {
            trigNonRWCmd(cTrustedRwBufferStartBufIdx, g32ReceivedXfrCnt, cTsb0, cNvmeWrite, cManualCq);
        }

        SecIntf_MOVE_MEM2MEM(cTrustedRwBufferAddr, cTrustedIfSendAddr, g32ReceivedXfrByte);    // Move Opal data to the
        // Temp Buffer

        uStatus=SFP.gfpSecIntf_IfSendData(cTrustedIfSendAddr);
        return uStatus;
    }
    else
    {
        return uStatus;
    }
}    /* handleTrustedSend */

void SecAPI_Trusted_Send(void)
{
    BYTE uStatus=cGood;

    if((!gbEnTCG)&&(!gbEnATAPassThrough)&&(!gbEnRpmb))
    {
        manualCompletion(cStatusInvalidOpCode, 0x0, cNoRwCmd, 0x0);

        // Save Security parameters before unloading code
        // SecAPI_NoticeSecCodeSwap(1);
        return;
    }

    // Initial Security functions and parameters after loading code
    SecAPI_NoticeSecCodeSwap(0);

#if _ENABLE_ATA_PASSTHROUGH
    handleSecFlagSub();
#endif

    uStatus=handleTrustedSend();

    if((uStatus==cInvalidProtocolId)||(uStatus==cInvalidTransferLength)||(uStatus==cOtherInvalidCommand)||(uStatus==cNoAllocationLength)||
       (uStatus==cCommandAborted))
    {
        NLOG_SAVE(cLogSecApiBaseFw, SECAPI_BASEFW_C, 1, cSaveIdSecurity, "SecAPI_Trusted_Send() fail uStatus = 0x%04X.", (WORD)uStatus);
        manualCompletion(cStatusDoNotRetry|cStatusInvalidField, 0x0, cNoRwCmd, 0x0);
    }
    else if(uStatus==cSynchronousProtocolViolation)
    {
        NLOG_SAVE(cLogSecApiBaseFw, SECAPI_BASEFW_C, 1, cSaveIdSecurity, "SecAPI_Trusted_Send() fail uStatus = 0x%04X.", (WORD)uStatus);
        manualCompletion(cStatusDoNotRetry|cStatusCmdSequenceErr, 0x0, cNoRwCmd, 0x0);
    }
    else if((uStatus==cGood)||(uStatus==cFaultyGood)||(uStatus==cNoDataGood)||(uStatus==cInvalidTransferLengthIEEE1667))
    {
        NLOG(cLogSecApiBaseFw,
             SECAPI_BASEFW_C,
             1,
             "SecAPI_Trusted_Send()/SecAPI_Trusted_Receive() Good uStatus = 0x%04X.",
             (WORD)uStatus);
        manualCompletion(cStatusSuccess, 0x0, cNoRwCmd, 0x0);
    }

#if _ENABLE_ATA_PASSTHROUGH
    else if((uStatus==cATASecurityCmdError)||(uStatus==cATASecurityLocked))
    {
        NLOG_SAVE(cLogSecApiBaseFw,
                  SECAPI_BASEFW_C,
                  1,
                  cSaveIdSecurity,
                  "SecAPI_Trusted_Send()/SecAPI_Trusted_Receive() fail uStatus = 0x%04X.",
                  (WORD)uStatus);
        manualCompletion(cStatusDoNotRetry|cStatusCmdSequenceErr, 0x0, cNoRwCmd, 0x0);
    }
#endif

// === TODO: handle BackgroundTrim === //
/*
   #if _ENABLE_BGTRIM // if gTrigSaveMap = 1, it means that BG Trim table has been updated in Security flow
   *      if(gTrigSaveMap && gBGTrimFlowManager.u32RemainTrimEntryCnt)	ChkSaveMapGroup(C_Map_Trim1, 0, 0);
   #endif
   */
    // Save Security parameters before unloading code
    SecAPI_NoticeSecCodeSwap(1);
}    /* trustedSend */

BYTE handleTrustedReceive(void)
{
    BYTE uStatus;
    LWORD u32ReceivedXfrDW=0, u32ReceivedXfrCnt=0;

    gReceivedProtocolId=rmNvmeSecSecp;
    g16ReceivedComId=rmNvmeSecSpsp;
    g32ReceivedXfrByte=rmNvmeSecAl;
    g32ReceivedXfrCnt=(rmNvmeSecAl+(512-1))>>9;
    gReceivedRpmbTarget=rmNvmeSecNssf;    // Used for RPMB

    uStatus=SFP.gfpSecIntf_IfRecvCmd(gReceivedProtocolId, g16ReceivedComId, g32ReceivedXfrByte);

    if((uStatus==cGood)||(uStatus==cFaultyGood)||(uStatus==cInvalidTransferLengthIEEE1667))
    {
        // Get data from PRP Entry 1 first in case that host memory might be overlapped under the condition that g32ReceivedXfrByte isn't 4-byte
        // aligned or that the value of u32ReceivedXfrDW isn't even
        u32ReceivedXfrDW=(g32ReceivedXfrByte+(4-1))>>2;

        if(g32ReceivedXfrByte&0x3)    // not align a dword
        {
            NLOG(cLogSecApiBaseFw, SECAPI_BASEFW_C, 2, "HandleTrustedReceive() xfr byte not align, 0x%08X.",
                 (WORD)(g32ReceivedXfrByte>>16), (WORD)(g32ReceivedXfrByte));

            u32ReceivedXfrCnt=((u32ReceivedXfrDW<<2)+(512-1))>>9;
            trigNonRWCmd(cTrustedRwBufferStartBufIdx, u32ReceivedXfrCnt, cTsb0, cNvmeWrite, cManualCq);
        }

        // Reset
        bopClrRamForTsbCode(cTrustedRwBufferAddr, g32ReceivedXfrByte, 0, cBopWait|cClrTsb);

        // SecurityFW prepares the data buffer
        SFP.gfpSecIntf_IfRecvComplete();

        // return data to host
        if(g32ReceivedXfrByte)
        {
            // WA: force copy get security caps result for now
            if(((gReceivedProtocolId==0x0)||(gReceivedProtocolId==0xEF))&&(g16ReceivedComId==0x0))
            {
                bopCopyRam(0x40000000, 0x40058000, g32ReceivedXfrByte, cCopyTsb2Tsb|cBopWait);
            }

            trigNonRWCmd(cTrustedRwBufferStartBufIdx, 0, cTsb0, cNvmeRead, cManualCq);
        }

        return uStatus;
    }
    else
    {
        return uStatus;
    }
}    /* handleTrustedReceive */

void SecAPI_Trusted_Receive(void)
{
    BYTE uStatus;

    // Initial Security functions and parameters after loading code
    SecAPI_NoticeSecCodeSwap(0);

    if((!gbEnTCG)&&(!gbEnATAPassThrough)&&(!gbEnRpmb))
    {
        manualCompletion(cStatusInvalidOpCode, 0x0, cNoRwCmd, 0x0);

        // Save Security parameters before unloading code
        SecAPI_NoticeSecCodeSwap(1);
        return;
    }

#if _ENABLE_ATA_PASSTHROUGH
    handleSecFlagSub();
#endif

    uStatus=handleTrustedReceive();

    if((uStatus==cInvalidProtocolId)||(uStatus==cInvalidTransferLength)||(uStatus==cOtherInvalidCommand)||(uStatus==cNoAllocationLength)||
       (uStatus==cCommandAborted))
    {
        NLOG_SAVE(cLogSecApiBaseFw, SECAPI_BASEFW_C, 1, cSaveIdSecurity, "SecAPI_Trusted_Receive() fail uStatus = 0x%04X.", (WORD)uStatus);
        manualCompletion(cStatusDoNotRetry|cStatusInvalidField, 0, cNoRwCmd, 0);
    }
    else if(uStatus==cSynchronousProtocolViolation)
    {
        NLOG_SAVE(cLogSecApiBaseFw, SECAPI_BASEFW_C, 1, cSaveIdSecurity, "SecAPI_Trusted_Receive() fail uStatus = 0x%04X.", (WORD)uStatus);
        manualCompletion(cStatusDoNotRetry|cStatusCmdSequenceErr, 0, cNoRwCmd, 0);
    }
    else if((uStatus==cGood)||(uStatus==cFaultyGood)||(uStatus==cNoDataGood)||(uStatus==cInvalidTransferLengthIEEE1667))
    {
        NLOG(cLogSecApiBaseFw,
             SECAPI_BASEFW_C,
             1,
             "SecAPI_Trusted_Send()/SecAPI_Trusted_Receive() Good uStatus = 0x%04X.",
             (WORD)uStatus);
        manualCompletion(cStatusSuccess, 0, cNoRwCmd, 0);
    }

#if _ENABLE_ATA_PASSTHROUGH
    else if((uStatus==cATASecurityLocked)||(uStatus==cATASecurityCmdError))
    {
        NLOG_SAVE(cLogSecApiBaseFw, SECAPI_BASEFW_C, 1, cSaveIdSecurity, "SecAPI_Trusted_Receive() fail uStatus = 0x%04X.", (WORD)uStatus);
        manualCompletion(cStatusDoNotRetry|cStatusCmdSequenceErr, 0, cNoRwCmd, 0);
    }
#endif

// === TODO: handle BackgroundTrim === //
/*
   #if _ENABLE_BGTRIM // if gTrigSaveMap = 1, it means that BG Trim table has been updated in Security flow
   *      if(gTrigSaveMap && gBGTrimFlowManager.u32RemainTrimEntryCnt)	ChkSaveMapGroup(C_Map_Trim1, 0, 0);
   #endif
   */

    // Save Security parameters before unloading code
    SecAPI_NoticeSecCodeSwap(1);
}    /* SecAPI_Trusted_Receive */

void SecIntf_ResetMemory(BYTE *uPtr, LWORD u32Size, LWORD u32Val)
{
    if(u32Size>128)    // Use Hardware BOP resource
    {
        bopClrRamForTsbCode((LWORD)uPtr, u32Size, u32Val, cBopWait|cClrTsb);
    }
    else    // Use CPU resource
    {
        resetRam(uPtr, u32Size, (BYTE)u32Val);
    }
}

void SecIntf_ResetTSB(UCBYTE *uPtr, LWORD size, LWORD u32Val)
{
    bopClrRamForTsbCode((LWORD)uPtr, size, u32Val, cBopWait|cClrTsb);
}

LWORD SecIntf_MemoryUsage(BYTE uUsage, BYTE uMode, WORD u16Length, LWORD u32BaseAddr)
{
    if(uUsage&Memory_Allocate)    // only Memory_Allocate, need to handle return value
    {
        return memoryAllocate(uMode, u16Length, u32BaseAddr);
    }

    if(uUsage&Memory_Release)
    {
        memoryRelease(u32BaseAddr);
    }

    return 0;
}

void SecIntf_SaveWProPage(BYTE uPageIdx)
{
#if _ENABLE_SECAPI_W_DEBUG
    NLOG(cLogSecApiDebug,
         SECAPI_BASEFW_C,
         4,
         "  SecIntf_SaveWProPage() uPageIdx = 0x%04X, gsWproInfo.uarWproIdxPtr= 0x%04X, gsWproInfo.uarWproIdxPtr= 0x%04X, gsWproInfo.u16WproFreePagePtr= 0x%04X",
         (WORD)uPageIdx,
         (WORD)gsWproInfo.uarWproIdxPtr[uPageIdx],
         gsWproInfo.u16arWproIdxPagePtr[uPageIdx],
         gsWproInfo.u16WproFreePagePtr);
#endif
    prog1stInvQBootInWpro();
    progWproPageCore0(uPageIdx, c16Tsb0SIdx|c16Bit15);
}    /* SecIntf_SaveWProPage */

BYTE SecIntf_LoadWProPage(BYTE uPageIdx)
{
    if(gsWproInfo.u16arWproIdxPagePtr[uPageIdx]!=c16BitFF)
    {
#if _ENABLE_SECAPI_W_DEBUG
        NLOG(cLogSecApiDebug,
             SECAPI_BASEFW_C,
             3,
             "  SecIntf_LoadWProPage() uPageIdx = 0x%04X, gsWproInfo.uarWproIdxPtr= 0x%04X, gsWproInfo.uarWproIdxPtr= 0x%04X",
             (WORD)uPageIdx,
             (WORD)gsWproInfo.uarWproIdxPtr[uPageIdx],
             (WORD)gsWproInfo.u16arWproIdxPagePtr[uPageIdx]);
#endif

        readWproPageCore0(uPageIdx, c16Tsb0SIdx, 0);
        return 1;
    }
    else
    {
        return 0;
    }
}    /* SecIntf_LoadWProPage */

BYTE SecIntf_CheckWProPageExist(BYTE uPageIdx)
{
    return gsWproInfo.u16arWproIdxPagePtr[uPageIdx]!=0xFFFF;
}

void SecIntf_SaveLinkMap(BYTE uSaveMapID, BYTE uPartialMap)
{
    // progCacheInfoTab((cInSecApiTcg_00&0xFF00)|uSaveMapID);
    progCacheInfoTab();
}

void handleSecTrim()
{
    // volatile BYTE uSTOP=1;
    // while(uSTOP);
    save1stCacheInfoBefW();
    enableLdpcPipe();
    processTrim(cNvmeCmdSecuritySend);
    disableLdpcPipe();
}

void SecIntf_AddTrimEntry(LWORD u32TrimStartLBA, LWORD u32XfrCnt)
{
    // volatile BYTE uSTOP=1;
    // TRIMTOUTINFO usTrimTOutInfo;
    TRIMINFO *upTrimInfo=(TRIMINFO *)(&gCrcDataBuffer[0]+g16SecTrimPtr*16);

    LWORD u32HostTcgTotalDataSectorCnt=g32HostTotalDataSectorCnt+gTcgReservedSecShiftCnt+cTcgReserveSecCnt;

    if((!u32XfrCnt)||(u32TrimStartLBA>=u32HostTcgTotalDataSectorCnt)||((u32TrimStartLBA+u32XfrCnt)>u32HostTcgTotalDataSectorCnt))
    {
        return;
    }

    // usTrimTOutInfo.u16ActiveH2F=c16H2FTabInitValue;
    // usTrimTOutInfo.u16TotalValidEntryCnt=1;

    // g32arTsb0[cTrimLBAInfoStBuf][0]=u32TrimStartLBA;
    // g32arTsb0[cTrimLenInfoStBuf][0]=u32XfrCnt;
    // g32SecTrimLba[g16SecTrimPtr]=u32TrimStartLBA;
    // g32SecTrimXfrCnt[g16SecTrimPtr]=u32XfrCnt;

    upTrimInfo->u64StartLba=u32TrimStartLBA;
    upTrimInfo->u32Length=u32XfrCnt;
    g16SecTrimPtr++;

    if(g16SecTrimPtr>=256)
    {
        // while(uSTOP);
        handleSecTrim();
    }
}    /* SecIntf_AddTrimEntry */

void SecIntf_RangePolicyUpdate(BYTE uAction, lba_policy_st *upRangePolicy)
{
    if(uAction&cMbrUpdate)
    {
        gMBRShadow=upRangePolicy->MBRShadow;
    }

    if(uAction&cLockingStatusUpdate)
    {
        gLockingStatus=upRangePolicy->LockingStatus;
    }

    if(uAction&cTcgNviSpLockingLifeCycleStateUpdate)
    {
        gTcgNviSpLockingLifeCycleState=upRangePolicy->TcgNviSpLockingLifeCycleState;
    }

    NLOG(cLogSecApiBaseFw,
         SECAPI_BASEFW_C,
         4,
         "  SecIntf_RangePolicyUpdate() uAction = 0x%04X , gMBRShadow = 0x%04X , gLockingStatus = 0x%04X , gTcgNviSpLockingLifeCycleState = 0x%04X",
         (WORD)uAction,
         (WORD)gMBRShadow,
         (WORD)gLockingStatus,
         (WORD)gTcgNviSpLockingLifeCycleState);
}    /* SecIntf_RangePolicyUpdate */

BYTE SecAPI_HandleFWupdate(LWORD u32SecurityState)
{
    BYTE result=cTrue;    // TRUE: allow FW update;  FALSE: abort FW update

    // Check if Security Setting remains the same
    if(u32SecurityState!=gsLightSwitch.usSecLs.u32SecFeature)
    {
        result=cFalse;
    }

    return result;
}    /* SecAPI_HandleFWupdate */

BYTE SecAPI_SetCPin_Request()
{
    BYTE uIdx;
    BYTE uarCPinPsid[C_PSID_SIZE];
    BYTE uarCPinMsid[C_MSID_SIZE];
    BYTE *upPtr=(BYTE *)cTrustedIfSendAddr;

    // Get PSID (Byte0-Byte32)
    for(uIdx=0; uIdx<C_PSID_SIZE; uIdx++)
    {
        uarCPinPsid[uIdx]=upPtr[uIdx];
    }

    // Get MSID (Byte32-Byte48)
    for(uIdx=0; uIdx<C_MSID_SIZE; uIdx++)
    {
        uarCPinMsid[uIdx]=upPtr[uIdx+C_PSID_SIZE];
    }

    if(SFP.gfpSecIntf_SetCPin(uarCPinMsid, uarCPinPsid))
    {
        return cSecuErrSetCpinFail;
    }

    return 0;    // Set PSID and MSID success
}    /* SecAPI_SetCPin_Request */

void SecAPI_InitSecAPIFuncPtr_BaseFW()
{
#if _ENABLE_ATA_PASSTHROUGH
    SecAPI_InitATASecurityFuncPtr_BaseFW();
#endif
/*=====================================================================*/
// ------ implement by BaseFW
/*=====================================================================*/
    SFP.gfpSecIntf_JudgeWrittenGHP=SecIntf_JudgeWrittenGHP;
    SFP.gfpSecIntf_SetSecurityWProMode=SecIntf_SetSecurityWProMode;
    SFP.gfpSecIntf_GetCurrentMs=SecIntf_GetCurrentMs;
    SFP.gfpSecIntf_TimerWaitMs=SecIntf_TimerWaitMs;
    SFP.gfpSecIntf_SetSessionTimeout=SecIntf_SetSessionTimeout;
    SFP.gfpSecIntf_MOVE_MEM2MEM=SecIntf_MOVE_MEM2MEM;
    SFP.gfpSecIntf_MemoryCompare=SecIntf_MemoryCompare;
    SFP.gfpSecIntf_ResetMemory=SecIntf_ResetMemory;
    SFP.gfpSecIntf_ResetTSB=SecIntf_ResetTSB;
    SFP.gfpSecIntf_MemoryUsage=SecIntf_MemoryUsage;
    SFP.gfpSecIntf_DebugLog=SecIntf_DebugLog;
    SFP.gfpSecIntf_SaveWProPage=SecIntf_SaveWProPage;
    SFP.gfpSecIntf_LoadWProPage=SecIntf_LoadWProPage;
    SFP.gfpSecIntf_CheckWProPageExist=SecIntf_CheckWProPageExist;
    SFP.gfpSecIntf_SaveLinkMap=SecIntf_SaveLinkMap;
    SFP.gfpSecIntf_AddTrimEntry=SecIntf_AddTrimEntry;
    SFP.gfpSecIntf_RangePolicyUpdate=SecIntf_RangePolicyUpdate;
    SFP.gfpSecIntf_TCG_Write=SecIntf_TCG_Write;
    SFP.gfpSecIntf_TCG_Read=SecIntf_TCG_Read;
    SFP.gfpSecIntf_UpdateBaseFWParameter=SecIntf_UpdateBaseFWParameter;

/*=====================================================================*/
// ------ implement by BaseFW - Crypto
/*=====================================================================*/
    SFP.gfpSecIntf_Crypto_LoadKey=SecIntf_Crypto_LoadKey;
    SFP.gfpSecIntf_Crypto_SetRangePartitionRegister=SecIntf_Crypto_SetRangePartitionRegister;
    SFP.gfpSecIntf_Crypto_GenerateRandomNum=SecIntf_Crypto_GenerateRandomNum;
}    /* SecAPI_InitSecAPIFuncPtr_BaseFW */

void SecAPI_UpdateSecurityFWParameter_Request()
{
    cid_st CID;

    CID.EnAES=gbEnAes;
    CID.EnTCG=gbEnTCG;
    CID.EnIEEE1667=gbEnIEEE1667;
    CID.EnSessionTimer=gbEnSessionTimer;
    CID.EnPyrite=gbEnPyrite;
    CID.EnATAPassThrough=gbEnATAPassThrough;
#if _ENABLE_E2E_PROTECTION
    CID.EnE2EWorkAround=gbEnAes;
#else
    CID.EnE2EWorkAround=0;
#endif
#if _ENABLE_ATA_PASSTHROUGH
    CID.EnAtaPassword=gsLightSwitch.usSecLs.uEnAtaPassword;
#else
    CID.EnAtaPassword=0;
#endif

    const_st CONST;
    CONST.Map_TCG_1=(BYTE)cInSecApiTcg_00;
    CONST.Map_TCG_2=(BYTE)cInSecApiTcg_01;
    CONST.TCGReadOrigin=cTcgReadOrigin;
    CONST.TCGReadUpdated=cTcgReadUpdated;
    CONST.WPRO_TCGIEEE1667Info_ID=cWproTcgIeee1667InfoId;
    CONST.WPRO_SECURITY_ID=cWproSecurityId;
    CONST.Security_Log_ID=cSaveIdSecurity;

    parameter_st PARAMETER;
    PARAMETER.uSectorPerUnitH2n=cSctrTo4kShift;
    PARAMETER.uSectorPerUnitH=cSctrPer4k;
    PARAMETER.uSectorPerPageH=gSectorPerPlaneH;
    PARAMETER.uSectorPerWPROPageH=gSectorPerPlaneH-1;    // according to the reserved sector count of WPRO page for g16arWproPage
    PARAMETER.uTCGReservedSecShiftCnt=gTcgReservedSecShiftCnt;
    PARAMETER.u32ReservedAreaStartSector=g32HostTotalDataSectorCnt+gTcgReservedSecShiftCnt;
    PARAMETER.u32MemoryUsageAddr=cSecurityApiBufferAddr;    // must be on TSB (Share 64K space with garAPIBuffer_Lib[] in CryptoLibrary)
    PARAMETER.u32MaxSessionTimeout=cDefaultSessionTimeout;

    pointer_st POINTER;

    POINTER.uarH2FMap=0;    // 2263XT doesn't use.
    POINTER.uarRwBuf=&garTsb0[cTrustedRwBufferStartBufIdx];
    POINTER.uarWWN=gsLightSwitch.usVuIdLs.uarWWN;
#if _ENABLE_ATA_PASSTHROUGH
    POINTER.uarAtaPassword=gsLightSwitch.usSecLs.uAtaPassword;
#endif
    SFP.gfpSecIntf_UpdateSecurityFWParameter(&CID, &CONST, &PARAMETER, &POINTER);
}    /* SecAPI_UpdateSecurityFWParameter_Request */

void SecAPI_InitParameter_BaseFW()
{
    LWORD u32Start, u32Length;

#pragma section=".SecurityAPI_Var_BaseFW"
    u32Start=(LWORD)(__section_begin(".SecurityAPI_Var_BaseFW"));
    u32Length=(LWORD)(__section_size(".SecurityAPI_Var_BaseFW"));
    bopClrRamForTsbCode(u32Start, u32Length, 0x00000000, cBopWait|cClrTsb);
}

void SecIntf_UpdateBaseFWParameter(pointer_sec_st *POINTER_SEC)
{
    gp32WriteRangeStart=POINTER_SEC->u32arWriteRangeStart;
    gp32WriteRangeEnd=POINTER_SEC->u32arWriteRangeEnd;
    gp32ReadRangeStart=POINTER_SEC->u32arReadRangeStart;
    gp32ReadRangeEnd=POINTER_SEC->u32arReadRangeEnd;
    gpMBRValidBitMap=POINTER_SEC->uarTCGMBRValidBitMap;
}

/*void testfp(BYTE idx)
   * {
   *      DebugLog(0x81,idx,2,(LWORD)SFP.gfpSecIntf_ChkSecurityStatus>>16,(LWORD)SFP.gfpSecIntf_ChkSecurityStatus,0,0,0);
   *      DebugLog(0x81,idx,2,(LWORD)SFP.gfpSecIntf_MOVE_MEM2MEM>>16,(LWORD)SFP.gfpSecIntf_MOVE_MEM2MEM,0,0,0);
   *      DebugLog(0x81,idx,2,(LWORD)SFP.gfpSecIntf_ResetMemory>>16 ,(LWORD)SFP.gfpSecIntf_ResetMemory ,0,0,0);
   *      DebugLog(0x81,idx,2,(LWORD)SFP.gfpSecIntf_ResetTSB>>16,(LWORD)SFP.gfpSecIntf_ResetTSB ,0,0,0);
   *      DebugLog(0x81,idx,2,(LWORD)SFP.gfpSecIntf_MemoryUsage >>16,(LWORD)SFP.gfpSecIntf_MemoryUsage ,0,0,0);
   *      DebugLog(0x81,idx,2,(LWORD)SFP.gfpSecIntf_DebugLog >>16,(LWORD)SFP.gfpSecIntf_DebugLog ,0,0,0);
   *      DebugLog(0x81,idx,2,(LWORD)SFP.gfpSecIntf_SaveWProPage >>16,(LWORD)SFP.gfpSecIntf_SaveWProPage ,0,0,0);
   *      DebugLog(0x81,idx,2,(LWORD)SFP.gfpSecIntf_LoadWProPage>>16,(LWORD)SFP.gfpSecIntf_LoadWProPage ,0,0,0);
   *      DebugLog(0x81,idx,2,(LWORD)SFP.gfpSecIntf_SaveLinkMap>>16,(LWORD)SFP.gfpSecIntf_SaveLinkMap ,0,0,0);
   *      DebugLog(0x81,idx,2,(LWORD)SFP.gfpSecIntf_AddTrimEntry >>16,(LWORD)SFP.gfpSecIntf_AddTrimEntry ,0,0,0);
   *      DebugLog(0x81,idx,2,(LWORD)SFP.gfpSecIntf_RangePolicyUpdate >>16,(LWORD)SFP.gfpSecIntf_RangePolicyUpdate ,0,0,0);
   *      DebugLog(0x81,idx,2,(LWORD)SFP.gfpSecIntf_TCG_Write>>16,(LWORD)SFP.gfpSecIntf_TCG_Write ,0,0,0);
   *      DebugLog(0x81,idx,2,(LWORD)SFP.gfpSecIntf_TCG_Read >>16,(LWORD)SFP.gfpSecIntf_TCG_Read ,0,0,0);
   * }*/

void SecAPI_Resume(BYTE uAction)
{
    SecAPI_InitSecAPIFuncPtr_BaseFW();
    SecAPI_UpdateSecurityFWParameter_Request();
    SecAPI_NoticeBackupResume_Request(uAction);
#if 0    // Comment out in order to shorten the period of devslp-resume process
    ChkRebuildMap(g32HostTotalDataSectorCnt, C_TCGReserveSecCnt, 0);    // Make sure to set the corresponding garZoneBitmap
#endif

    gbSecAPIInitial=1;    // As the flag to indicate that the initialization is finished

    // ===Handle the Pending tasks prior to initialization===
    if(gbSecAPIPendingPCIeReset)
    {
        SecAPI_NoticeReset_Request(cPCIeRst);
        gbSecAPIPendingPCIeReset=0;
        gbSecAPIProgWproAfterResume=1;
    }

    if(gbSecAPIPendingNSSR)
    {
        SecAPI_NoticeReset_Request(cNSSR);
        gbSecAPIPendingNSSR=0;
    }
}    /* SecAPI_DevSlp_Resume */

void initSecurityParameter()
{
    LWORD u32Start, u32Length;

    // Reset "SecurityAPI_SecurityVar" section
#pragma section=".SecurityAPI_SecurityVar"
    u32Start=(LWORD)(__section_begin(".SecurityAPI_SecurityVar"));
    u32Length=(LWORD)(__section_size(".SecurityAPI_SecurityVar"));
    bopClrRamForTsbCode(u32Start, u32Length, 0, cClrTsb|cBopWait);
}

void updateLbaRangeMbrBitmap()
{
    bopCopyRam((LWORD)g32arWriteRangeStart, (LWORD)gp32WriteRangeStart, sizeof(g32arWriteRangeStart), cCopyTsb2Dccm|cBopWait);
    bopCopyRam((LWORD)g32arWriteRangeEnd, (LWORD)gp32WriteRangeEnd, sizeof(g32arWriteRangeEnd), cCopyTsb2Dccm|cBopWait);
    bopCopyRam((LWORD)g32arReadRangeStart, (LWORD)gp32ReadRangeStart, sizeof(g32arReadRangeStart), cCopyTsb2Dccm|cBopWait);
    bopCopyRam((LWORD)g32arReadRangeEnd, (LWORD)gp32ReadRangeEnd, sizeof(g32arReadRangeEnd), cCopyTsb2Dccm|cBopWait);
    bopCopyRam((LWORD)garMBRValidBitMap, (LWORD)gpMBRValidBitMap, sizeof(garMBRValidBitMap), cCopyTsb2Dccm|cBopWait);
}

void SecAPI_NoticeSecCodeSwap(BYTE uAction)
{
#if _ENABLE_SECAPI_DEBUG
    NLOG(cLogSecApiDebug, SECAPI_BASEFW_C, 1, "SecAPI_NoticeSecCodeSwap() , uAction = 0x%04X", (WORD)uAction);
#endif

    gByPassSecApiLog=1;

    if(uAction==0)    // Load Security Code to TSB
    {
        // Update Security Key Info
        if(gbEnAes)
        {
            if(gsWproInfo.u16arWproIdxPagePtr[cWproSecurityId]!=c16BitFF)
            {
                readWproPageCore0(cWproSecurityId, c16Tsb0SIdx, 0);
            }
            else
            {
                bopClrRamForTsbCode(cTsb0Addr, gSectorPerPlaneH*512, 0, cClrTsb|cBopWait);
            }

            updataSecurityKeyInfo();
        }

        /*(1) Update FuncPtr and BaseFW Parameters
           *  (2) Load TCG and IEEE1667 Parameters from WPRO */
        SecAPI_Resume(cSwapResume);

        // rstH2F1KInfo2(1);
    }
    else if(uAction==1)    // Unload Security Code from TSB
    {
        if(g16SecTrimPtr)
        {
            handleSecTrim();
        }

        // Save TCG and IEEE1667 Parameters to WPRO
        SecAPI_NoticeBackupResume_Request(cSwapBackup);
        updateLbaRangeMbrBitmap();
    }

    gByPassSecApiLog=0;
}    /* SecAPI_NoticeSecCodeSwap */

void SecAPI_InitSecAPI(BYTE uMode)
{
// testfp(0x10);
    SecAPI_InitSecAPIFuncPtr_BaseFW();
// testfp(0x11);
    SecAPI_UpdateSecurityFWParameter_Request();
    // SFP.gfpSecIntf_InitParameter();
    // SFP.gfpSecIntf_InitSecurityFWParameter();
#if 0    // Comment out in order to shorten the period of power-on process
    // Handle Reserved LBA
    ChkRebuildMap(g32HostTotalDataSectorCnt, C_TCGReserveSecCnt, 0);    // Reserved LBA which is in the last zone must be build before
                                                                        // trimming invalid page
#endif
    SFP.gfpSecIntf_InitStart(uMode);

    gbSecAPIInitial=1;    // As the flag to indicate that the initialization is finished

    // ===Handle the Pending tasks prior to initialization===
    if(gbSecAPIPendingPCIeReset)
    {
        SecAPI_NoticeReset_Request(cPCIeRst);
        gbSecAPIPendingPCIeReset=0;
    }

    if(gbSecAPIPendingNSSR)
    {
        SecAPI_NoticeReset_Request(cNSSR);
        gbSecAPIPendingNSSR=0;
    }
}    /* SecAPI_InitSecAPI */

void bootInitSecurity()
{
    if(gbEnTCG||gbEnATAPassThrough||gbEnRpmb)
    {
        initSecurityParameter();
        SecAPI_InitParameter_BaseFW();

        if(rmChkInDevSlp)    // Resume from PS4
        {
            NLOG(cLogSecApiDebug, SECAPI_BASEFW_C, 0, "bootInitSecurity() , Resume from PS4");
            SecAPI_Resume(cDevSlpResume);
        }
        else if(gFwResetCpuForSec)    // Resume from FW Commit Auto Reset
        {
            NLOG(cLogSecApiDebug, SECAPI_BASEFW_C, 0, "bootInitSecurity() , Resume from CPU reset");
            SecAPI_Resume(cSwapResume);
        }
        else    // Normal power-on
        {
            NLOG(cLogSecApiDebug, SECAPI_BASEFW_C, 0, "bootInitSecurity() , Normal power-on");
            SecAPI_InitSecAPI(cInitNormal);
        }

        updateLbaRangeMbrBitmap();
    }

    if(gbEnAes)
    {
        initAesDefaultKey(rmChkDebugLocked);
    }

    if(gbEnTCG||gbEnATAPassThrough||gbEnRpmb)
    {
        if(!rmChkInDevSlp||gbSecAPIProgWproAfterResume)
        {
            SecAPI_NoticeSecCodeSwap(1);
        }
    }
}    /* bootInitSecurity */

#endif/* if _ENABLE_SECAPI */

#if (!_ICE_DEBUG)
#pragma default_function_attributes =
#endif







