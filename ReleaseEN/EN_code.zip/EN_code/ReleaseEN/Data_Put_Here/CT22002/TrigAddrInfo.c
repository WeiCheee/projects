







#include "inc/ProType.h"
// #include "inc/FlashCtrl.h"
#include "inc/GlobVar1.h"
#include "inc/GlobVarS.h"
#include "inc/GlobVarT.h"
#include "inc/Reg.h"
#include "inc/FtlCtrl.h"
#include "inc/Mac.h"
#include "inc/BitDef.h"

// Currently, GC related return 0.
LWORD calReadFifoLbaAddr(WORD u16Trig)
{
    return garSrcAddrInfo[u16Trig].uDieAddr+(garSrcAddrInfo[u16Trig].uCe<<8)+(garSrcAddrInfo[u16Trig].uIntlvAddr<<16)+
           (garSrcAddrInfo[u16Trig].uCh<<24);
}

void chkPreCmdAle(BYTE uCh)    // , BYTE uPreCnt, BYTE uCmdThr)
{
    BYTE uIntlvAddr, uReadFifoIdx;

#if _EN_CacheR
    BYTE uWaitFlag, uWaitTyp;
#if  _EN_MutiWayCacheRImprove
    BYTE uReadLoop, uReadCmdAlign=0, uWay;
#endif
    LWORD u32ReadCnt=0;

    if(gsRwCtrl.uEnCacheR==0)
    {
        uWaitTyp=cReadCmdAle;
    }
    else
    {
        uWaitTyp=cCacheRCmd;
    }
#endif
#if  _EN_MutiWayCacheRImprove
    if(gsRwCtrl.uChForceDataOut[uCh])
    {
        return;
    }

    for(uReadLoop=0; uReadLoop<2; uReadLoop++)
    {
        if(gsRwCtrl.uChForceDataOut[uCh])
        {
            return;
        }
#endif

    for(uIntlvAddr=0; uIntlvAddr<gIntlvWay; uIntlvAddr++)
    {
#if _EN_CacheR
        uWaitFlag=gsRwCtrl.usWaitInfo[uCh][uIntlvAddr].uWaitFlag;
#if  _EN_MutiWayCacheRImprove
        if((uWaitFlag==cReadCmdAle)&&(!uReadLoop))
        {
            continue;
        }

        while((gsRwCtrl.uChPreFifoTail[uCh][uIntlvAddr]!=gsRwCtrl.uChPreFifoHead[uCh][uIntlvAddr])&&(uWaitFlag!=uWaitTyp)&&
              (uWaitFlag!=cCache3FCmd))
#else
        while((gsRwCtrl.uChPreFifoTail[uCh][uIntlvAddr]!=gsRwCtrl.uChPreFifoHead[uCh][uIntlvAddr])&&(uWaitFlag!=uWaitTyp))
#endif
#else
        if((gsRwCtrl.uChPreFifoTail[uCh][uIntlvAddr]!=gsRwCtrl.uChPreFifoHead[uCh][uIntlvAddr])&&
           (gsRwCtrl.usWaitInfo[uCh][uIntlvAddr].uWaitFlag!=cReadCmdAle))
#endif/* if _EN_CacheR */
        {
            if(gsRwCtrl.uChReadFifoTail[uCh]==((gsRwCtrl.uChReadFifoHead[uCh]+1)&(cMaxChFifoRDepth-1)))
            {
                return;
            }

            uReadFifoIdx=gsRwCtrl.uChPreFifoIdx[uCh][uIntlvAddr][gsRwCtrl.uChPreFifoTail[uCh][uIntlvAddr]];
            gpFlashAddrInfo=&garSrcAddrInfo[uReadFifoIdx];

#if _EN_Precmd
            if((!(g16RwOpt&c16Bit0))||(g16FPage!=gsRwCtrl.u16LastFPageR[uCh][uIntlvAddr])||
               (g16FBlock!=gsRwCtrl.u16LastFBlockR[uCh][uIntlvAddr])||
               (mGetPageSelCmd(gpFlashAddrInfo)!=gsRwCtrl.uPreFixCmd[uCh][uIntlvAddr]))
#else
            if(1)    // need check????
#endif
            {
#if _EN_CacheR
                if(gsRwCtrl.uContiAddrCnt[uCh][uIntlvAddr]!=0)
                {
                    break;
                }

                if(gsRwCtrl.uEnCacheR&&((uWaitFlag==cCacheRCmd1)||(uWaitFlag==cReadCmdAle)))
                {
                    // if((mChkMlcMoBit(g16FBlock)!=mChkMlcMoBit(gsRwCtrl.u16LastFBlockR[uCh][uIntlvAddr]))||(mChkMlcMoBit(g16FBlock)))
                    if(mChkMlcMoBit(g16FBlock)!=mChkMlcMoBit(gsRwCtrl.u16LastFBlockR[uCh][uIntlvAddr]))
                    {
#if  _EN_MutiWayCacheRImprove
                        if(uWaitFlag==cCacheRCmd1)
                        {
                            rmCeOn(gCe);
                            rmCle(0xF1+mGetDieAddr(uIntlvAddr));
                            rmCle(gLastPageCacheReadCmd);
                            rmAllCeOff;
                            gsRwCtrl.usWaitInfo[uCh][uIntlvAddr].uWaitFlag=cCache3FCmd;
                        }
#endif

                        break;    // TLC, SLC can't issue cache R together
                    }
                    else
                    {
#if  _EN_MutiWayCacheRImprove
                        if((gsRwCtrl.uChLastReadCmdWay[uCh]==uIntlvAddr)&&(uWaitFlag==cReadCmdAle)&&(gsRwCtrl.uChReadFifoCnt[uCh]>1))
                        {
                            gsRwCtrl.uChForceDataOut[uCh]=1;
                            return;
                        }
#endif
                        g16RwOpt|=c16Bit3;
                    }
                }
#else/* if _EN_CacheR */
                if(gsRwCtrl.uContiAddrCnt[uCh][uIntlvAddr]!=0)
                {
                    continue;
                }
#endif/* if _EN_CacheR */

                // if(g16LastRdCntFBlock[uCh][uIntlvAddr]!=g16FBlock)
                // {
                // only for uneven reading block
                if((gOpTyp==cHostReadData)||(gOpTyp==cH2fReadTab)||(gOpTyp==cH2fRead1kTab))
                {
                    // g16LastRdCntFBlock[uCh][uIntlvAddr]=g16FBlock;
                    u32ReadCnt=mGetGlobReadCnt(g16FBlock);

                    if(gsRwCtrl.u32SeqRdFlag&&(g16LastRdCntFBlock==g16FBlock)&&(g16LastRdCntFPage==g16FPage))
                    {}
                    else
                    {
                        mSetGlobReadCnt(g16FBlock, u32ReadCnt+1);
                    }

#if _GREYBOX
                    if((gsGbInfo.uGreyBoxItem==cFtlRuleReadReclaimID)&&(g16FBlock==g16GbSetReclaimBlk))
                    {
                        u32ReadCnt=mGetGlobReadCnt(g16FBlock)+c32SlcClosedBlkVpcThr;
                        mSetGlobReadCnt(g16FBlock, u32ReadCnt);

                        if(mChkSkipGcSrch(g16FBlock)||mChkPushReClaimQBit(g16FBlock))
                        {
                            g16GbGetReclaimBlk=g16FBlock;
                        }
                    }

                    if((u32ReadCnt>c32SlcClosedBlkVpcThr)||
                       ((gsGbInfo.uGreyBoxItem==cUGSDReclaimID)&&(mChkMlcMoBit(g16FBlock))&&
                        ((*(WORD *)(c32GreyBoxBuf+cGbInfoReclimFBlk3))==0)))
#else
#if _EN_SLCOpenBlkReadScrub
                    if(chkReadCnt(g16FBlock))
#else
                    if((u32ReadCnt>c32SlcClosedBlkVpcThr)&&(!mChkSkipGcSrch(g16FBlock)))
#endif
#endif/* if _GREYBOX */
                    {
                        pushWLReadReclaimQ(g16FBlock, cTouchRdCntThr);

                        /*
                           * if(!mChkPushReClaimQBit(g16FBlock)&&!mChkGcFlag(cUnderReclaim)&&!mChkSkipGcSrch(g16FBlock))
                           * {
                           *  pushReadScrubQ(g16FBlock);
                           * }*/
                    }
                }

                // }

                gsRwCtrl.u16LastFBlockR[uCh][uIntlvAddr]=g16FBlock;
                gsRwCtrl.uPreFixCmd[uCh][uIntlvAddr]=mGetPageSelCmd(gpFlashAddrInfo);
                g16LastRdCntFBlock=g16FBlock;
                g16LastRdCntFPage=g16FPage;

                if(g16RwOpt&c16Bit0)
                {
                    gsRwCtrl.u16LastFPageR[uCh][uIntlvAddr]=g16FPage;
                }
                else
                {
                    gsRwCtrl.u16LastFPageR[uCh][uIntlvAddr]=cInvalid16Bit;
                }

#if _EN_CacheR
                if(uWaitFlag!=cCacheRCmd1)
                {
                    waitChCeBz(uCh, uIntlvAddr, 0);
                }
#else
                waitChCeBz(uCh, uIntlvAddr, 0);
#endif
                // trigFlPreCmdAle();
                rmCeOn(gCe);
                setAutoFBlock(gIntlvAddr, gPlaneAddr);
                flashChangeDieCmd(gDieAddr);
                chkRlibMoCmd();

#if _ENABLE_NAND_TestReadVth
                if(g16RCCnt==0)
                {
                    if((!gbLsbOnly)&&(gOpTyp!=cPwrOnGc))
                    {
                        setTestRetryCmd();
                        g16RCCnt=200;
                    }
                }
                else
                {
                    g16RCCnt--;
                }
#endif

                if(gbLsbOnly)
                {
                    if(mChkFLParam(cWithRlibMo))
                    {
                        rmSetPageAddr(g16FPage);
                    }
                    else if(mChkCardMode(cWithSlcMo))
                    {
                        rmSetPageAddr(g16FPage<<1);
                    }
                }
                else
                {
                    rmSetPageAddr(g16FPage);
                }

                rmSetSctrAddr(gSectorH);
                rmSelData;

                if(g16RwOpt&c16Bit0)
                {
                    setMultiPlaneRead();
                }
                else
                {
                    setAutoFBlock(gIntlvAddr, gPlaneAddr);
#if _EN_HalfR
                    if(!gsRwCtrl.uEnCacheR&&((gSectorH>>3)==((gSectorH+mGetReadSctrCnt-1)>>3)))
                    {
                        setSinglePlaneRead(1);
                    }
                    else
                    {
                        setSinglePlaneRead(0);
                    }
#else
                    setSinglePlaneRead(0);
#endif
                }

                rmAllCeOff;
            }
            else
            {
                g16RwOpt|=c16Bit9;
                gsRwCtrl.uContiAddrCnt[uCh][uIntlvAddr]++;
            }

            g16RwOpt|=c16Bit2;

            if(!(g16RwOpt&c16Bit9))
            {
#if _EN_CacheR
                if((uWaitFlag==cReadCmdAle)||(uWaitFlag==cCacheRCmd1))
                {
                    uWaitFlag=cCacheRCmd;
                }
                else
                {
                    uWaitFlag=cReadCmdAle;
                }

#if  _EN_MutiWayCacheRImprove
                gsRwCtrl.uChLastReadCmdWay[uCh]=uIntlvAddr;
#endif
                gsRwCtrl.usWaitInfo[uCh][uIntlvAddr].uWaitFlag=uWaitFlag;
#else
                gsRwCtrl.usWaitInfo[uCh][uIntlvAddr].uWaitFlag=cReadCmdAle;    // setBzInfo(cReadCmdAle, uCh, uIntlvAddr);
#endif
                gsRwCtrl.usWaitInfo[uCh][uIntlvAddr].uStatusErrStop=0;
            }

            gsRwCtrl.uChReadFifoIdx[uCh][gsRwCtrl.uChReadFifoHead[uCh]]=uReadFifoIdx;
            gsRwCtrl.uChReadFifoHead[uCh]=(gsRwCtrl.uChReadFifoHead[uCh]+1)&(cMaxChFifoRDepth-1);
            gsRwCtrl.uChReadFifoCnt[uCh]++;

            gsRwCtrl.uChPreFifoTail[uCh][uIntlvAddr]=(gsRwCtrl.uChPreFifoTail[uCh][uIntlvAddr]+1)&(cMaxChFifoRDepth-1);
            gsRwCtrl.uChPreFifoCnt[uCh]--;
#if  _EN_MutiWayCacheRImprove
            if(uWaitFlag==cReadCmdAle)
            {
                uReadCmdAlign|=(1<<uIntlvAddr);
            }
#endif
#if _EN_CacheR
            if((gsRwCtrl.uEnCacheR==0)||(g16RwOpt&c16Bit9))
            {
                break;
            }
#endif
#if  _EN_MutiWayCacheRImprove
            if(!uReadLoop)
            {
                break;
            }
#endif
        }
    }

#if  _EN_MutiWayCacheRImprove
    if((!uReadLoop)&&(uReadCmdAlign!=((1<<gIntlvWay)-1))&&uReadCmdAlign)
    {
        for(uWay=0; uWay<gIntlvWay; uWay++)
        {
            if(uReadCmdAlign&(1<<uWay))
            {
                continue;
            }

            if((gsRwCtrl.usWaitInfo[uCh][uWay].uWaitFlag==cCache3FCmd)||(gsRwCtrl.usWaitInfo[uCh][uWay].uWaitFlag==cCacheRCmd)||
               (gsRwCtrl.usWaitInfo[uCh][uWay].uWaitFlag==cCacheRCmd1))
            {
                gsRwCtrl.uChForceDataOut[uCh]++;
            }
        }
    }
}    /* chkPreCmdAle */
#endif/* if  _EN_MutiWayCacheRImprove */
}    /* chkPreCmdAle */

/*
   * void trigFlPreCmdAle()
   * {
   *  rmCeOn(gCe);
   *  chkRlibMoCmd();
   *
   #if _ENABLE_NAND_TestReadVth
   *  if(g16RCCnt==0)
   *  {
   *      if((!gbLsbOnly)&&(gOpTyp!=cPwrOnGc))
   *      {
   *          setTestRetryCmd();
   *          g16RCCnt=200;
   *      }
   *  }
   *  else
   *  {
   *      g16RCCnt--;
   *  }
   #endif
   *
   *  // setAutoAleReg(gpFlashAddrInfo->uPageSelCmd);
   *  if(gbLsbOnly)
   *  {
   *      if(mChkFLParam(cWithRlibMo))
   *      {
   *          rmSetPageAddr(g16FPage);
   *      }
   *      else if(mChkCardMode(cWithSlcMo))
   *      {
   *          rmSetPageAddr(g16FPage<<1);
   *      }
   *  }
   *  else
   *  {
   #if (_TSB_BiCS3||_SANDISK_3D_GEN2||_SANDISK_3D_GEN3)
   *      rmSetPageAddr(g16FPage);
   #endif
   *  }
   *
   *  rmSetSctrAddr(gSectorH);
   *  rmSelData;
   *
   *  // if((gOpTyp==cH2fRead1kTab)||(gpFlashAddrInfo->u16RwOpt&c16Bit0))
   *  if(g16RwOpt&c16Bit0)
   *  {
   *      setMultiPlaneRead();
   *  }
   *  else
   *  {
   *      setAutoFBlock(gIntlvAddr, gPlaneAddr);
   #if _EN_HalfR
   *      if((gsRwCtrl.uEnCacheR==0)&&((gSectorH>>3)==((gSectorH+mGetReadSctrCnt-1)>>3)))
   *      {
   *          setSinglePlaneRead(1);
   *      }
   *      else
   *      {
   *          setSinglePlaneRead(0);
   *      }
   #else
   *      setSinglePlaneRead(0);
   #endif
   *  }
   *
   *  rmAllCeOff;
   * }
   */

void trigFlCmdFfStep3()    // BYTE uWaitOpIdx)
{
    BYTE uCh, uIntlvAddr, uWaitFlag=0, uChTrig, uMinBufSerl, uBufSerl, uMinTsb4kIdx, uTsb4kIdx, uMinChTrig, uIntlvAddrMap;

#if _EN_CacheR&&_EN_MutiWayCacheRImprove
    BYTE uWay;
#endif

    if(gsRwCtrl.u32AllReadFifoCnt)
    {
        for(uCh=0; uCh<gTotalChNum; uCh++)
        {
            setFLActCh(uCh);

            if(gsRwCtrl.uChPreFifoCnt[uCh])
            {
                chkPreCmdAle(uCh);
            }

            if(!rmGetOpIdxCntInFifo)
            {
                if(gsRwCtrl.uChReadFifoCnt[uCh])
                {
                    uChTrig=gsRwCtrl.uChReadFifoTrig[uCh];
                    gpFlashAddrInfo=&garSrcAddrInfo[gsRwCtrl.uChReadFifoIdx[uCh][uChTrig]];

                    if(!chkReadBufFree(gpFlashAddrInfo->uTsb4kIdx, gpFlashAddrInfo->uPlaneCnt, gpFlashAddrInfo->uReadBufSerl))
                    {
                        if(gsRwCtrl.uChReadFifoCnt[uCh]>1)
                        {
                            uMinChTrig=uChTrig;
                            uMinBufSerl=gpFlashAddrInfo->uReadBufSerl;
                            uMinTsb4kIdx=gpFlashAddrInfo->uTsb4kIdx;
                            uIntlvAddrMap=cbBitTab[gpFlashAddrInfo->uIntlvAddr];

                            for(BYTE uLoop=1; uLoop<gsRwCtrl.uChReadFifoCnt[uCh]; uLoop++)
                            {
                                uWaitFlag=(uChTrig+uLoop)&(cMaxChFifoRDepth-1);
                                gpFlashAddrInfo=&garSrcAddrInfo[gsRwCtrl.uChReadFifoIdx[uCh][uWaitFlag]];
                                uBufSerl=gpFlashAddrInfo->uReadBufSerl;
                                uTsb4kIdx=gpFlashAddrInfo->uTsb4kIdx;

                                if(mChkBitMask(uIntlvAddrMap, gpFlashAddrInfo->uIntlvAddr))
                                {
                                    if(uIntlvAddrMap==(cb16BitTab[gIntlvWay]-1))
                                    {
                                        break;
                                    }
                                    else
                                    {
                                        continue;
                                    }
                                }
                                else if(uTsb4kIdx==cBitFF)
                                {
                                    uMinBufSerl=uBufSerl;
                                    uMinTsb4kIdx=uTsb4kIdx;
                                    uMinChTrig=uWaitFlag;
                                    break;    // this read can trigger
                                }
                                else if(compareBufSerl(uMinBufSerl, uBufSerl, uMinTsb4kIdx, uTsb4kIdx))
                                {
                                    uMinBufSerl=uBufSerl;
                                    uMinTsb4kIdx=uTsb4kIdx;
                                    uMinChTrig=uWaitFlag;
                                }

                                mSetBitMask(uIntlvAddrMap, gpFlashAddrInfo->uIntlvAddr);
                            }

                            if(uChTrig!=uMinChTrig)
                            {
                                uBufSerl=gsRwCtrl.uChReadFifoIdx[uCh][uMinChTrig];

                                while(uChTrig!=uMinChTrig)
                                {
                                    gsRwCtrl.uChReadFifoIdx[uCh][uMinChTrig]=
                                        gsRwCtrl.uChReadFifoIdx[uCh][((uMinChTrig-1)&(cMaxChFifoRDepth-1))];
                                    uMinChTrig=(uMinChTrig-1)&(cMaxChFifoRDepth-1);
                                }

                                gsRwCtrl.uChReadFifoIdx[uCh][uChTrig]=uBufSerl;
                                gpFlashAddrInfo=&garSrcAddrInfo[uBufSerl];

                                if(!chkReadBufFree(gpFlashAddrInfo->uTsb4kIdx, gpFlashAddrInfo->uPlaneCnt, gpFlashAddrInfo->uReadBufSerl))
                                {
                                    continue;
                                }
                            }
                            else
                            {
                                continue;
                            }
                        }
                        else
                        {
                            continue;
                        }
                    }

                    // if((gsPrdInfo.uQCmdCnt==1)&&(gOpTyp==cHostReadData)&&(gsPrdInfo.uarPrdQue[gpFlashAddrInfo->uPrdPtr].u16PrdRd4kCnt==1))
                    // {
                    //    gsPrdInfo.uarPrdQue[gpFlashAddrInfo->uPrdPtr].u16RestQRd4kCnt=0xFFFF;
                    //    gsRwCtrl.uarTrigHostPrd[gsRwCtrl.u32TrigHostHead]=gpFlashAddrInfo->uPrdPtr;
                    //    gsRwCtrl.u32TrigHostHead=(gsRwCtrl.u32TrigHostHead+1)&(cPrdDepth-1);
                    // }

                    uIntlvAddr=gIntlvAddr;

                    if(!(g16RwOpt&c16Bit9))
                    {
#if _EN_CacheR
                        uWaitFlag=gsRwCtrl.usWaitInfo[uCh][uIntlvAddr].uWaitFlag;
#if _EN_MutiWayCacheRImprove
                        if(uWaitFlag==cCacheRCmd1)
                        {
                            for(uWay=0; uWay<gIntlvWay; uWay++)
                            {
                                if(gsRwCtrl.usWaitInfo[uCh][uWay].uWaitFlag==cCacheRCmd1)
                                {
                                    rmCeOn(gCe);
                                    rmCle(0xF1+mGetDieAddr(uWay));
                                    rmCle(gLastPageCacheReadCmd);
                                    rmAllCeOff;
                                    gsRwCtrl.usWaitInfo[uCh][uWay].uWaitFlag=cCache3FCmd;
                                }
                            }
                        }
#endif

                        if(uWaitFlag==cCacheRCmd)
                        {
                            waitChCeBz(uCh, uIntlvAddr, 1);
                        }
                        else    // if((uWaitFlag==cCacheRCmd1))
                        {
                            waitChCeBz(uCh, uIntlvAddr, 0);
                        }
#else/* if _EN_CacheR */
                        waitChCeBz(uCh, uIntlvAddr, 0);
#endif/* if _EN_CacheR */
                    }

                    flashReadPage();
                    // addReadOpIdex(uCh);
                    rmAddOPIndex;
                    gsRwCtrl.uOpIdxSerial[uCh]++;

                    if(!gEnableLdpcPipe)
                    {
                        gpFlashAddrInfo->uOpIdxSerial=gsRwCtrl.uOpIdxSerial[uCh];
                        gsRwCtrl.uOpIdxAccCntR[uCh]++;
                        gsRwCtrl.uAllOpIdxCntR++;
                    }

                    if(!(g16RwOpt&c16Bit9))
                    {
#if _EN_CacheR
                        if(uWaitFlag==cCacheRCmd)
                        {
                            gsRwCtrl.usWaitInfo[uCh][uIntlvAddr].uWaitFlag=cCacheRCmd1;
                        }
                        else
                        {
                            gsRwCtrl.usWaitInfo[uCh][uIntlvAddr].uWaitFlag=gOpTyp;
                        }
#else/* if _EN_CacheR */
                        gsRwCtrl.usWaitInfo[uCh][uIntlvAddr].uWaitFlag=gOpTyp;
#endif/* if _EN_CacheR */
                        gsRwCtrl.usWaitInfo[uCh][uIntlvAddr].uStatusErrStop=0;
                    }
                    else
                    {
                        gsRwCtrl.uContiAddrCnt[uCh][uIntlvAddr]--;
                    }

                    gsRwCtrl.uChReadFifoCnt[uCh]--;
                    gsRwCtrl.u32AllReadFifoCnt--;
                    gsRwCtrl.uChReadFifoTrig[uCh]=(gsRwCtrl.uChReadFifoTrig[uCh]+1)&(cMaxChFifoRDepth-1);
#if _EN_MutiWayCacheRImprove
                    if(gsRwCtrl.uChForceDataOut[uCh])
                    {
                        gsRwCtrl.uChForceDataOut[uCh]--;
                    }
#endif
                }
            }
        }
    }
}    /* trigFlCmdFfStep3 */

void trigFlCmdFfStep2()
{
    BYTE uCh, uHdmaDoneCnt, uSrcIdx;
    volatile LINKINFO *upDelLlInfo;
    WORD u16PrevNodeIdx, u16NextNodeIdx;

#if 0    // _ENABLE_E2E_PROTECTION
    LWORD u32FreeSrcFifoTail;
#endif

    if(gsRwCtrl.uHdmaAccCnt)
    {
        uHdmaDoneCnt=gsRwCtrl.uHdmaAccCnt-rmGetHdmaCmdFifoCnt;
        gsRwCtrl.uHdmaAccCnt-=uHdmaDoneCnt;

        while(uHdmaDoneCnt)
        {
            uHdmaDoneCnt--;
            upDelLlInfo=&gsRwCtrl.usSrcCmdList;
            uSrcIdx=gsRwCtrl.uarHdmaFifoIdx[gsRwCtrl.uHdmaFifoTail];
            chkReadState(&garSrcAddrInfo[uSrcIdx]);
            gsRwCtrl.uHdmaFifoTail=(gsRwCtrl.uHdmaFifoTail+1)&(cMaxHdmaQNum-1);
            mDelNode(u16PrevNodeIdx, gsRwCtrl.uarSrcCmdLink, uSrcIdx, u16NextNodeIdx, upDelLlInfo);
            gsRwCtrl.uarFreeSrcQue[gsRwCtrl.u32FreeSrcFifoTail]=uSrcIdx;

#if 0    // _ENABLE_E2E_PROTECTION
            u32FreeSrcFifoTail=(gsRwCtrl.u32FreeSrcFifoTail+1)&(cReadFifoDpt-1);

            if((gsE2eInfo.uHmbEnable)&&(garSrcAddrInfo[uSrcIdx].uOpTyp==cGcHdmaDummy)&&(u32FreeSrcFifoTail==gsRwCtrl.u32FreeSrcFifoHead))
            {
                hdmaCopyRam((LWORD)c32TsbTempCrcAddr,
                            (LWORD)c32TsbCrcAddr+(c16CopySIdx<<3),
                            c16WriteBufSize<<3,
                            cCopyTsb2Tsb|cHdmaWait|cHdmaTsbWriteFlag);
                // bopCopyRam((LWORD)c32TsbTempCrcAddr, (LWORD)c32TsbCrcAddr+(upAddrInfo->u16BufPtr<<3), upAddrInfo->uRwHalfKb<<3,
                // cCopyTsb2Tsb|cBopWait|cBopDesAutoBuf);
                gsRwCtrl.u32FreeSrcFifoTail=u32FreeSrcFifoTail;
            }
            else
#endif/* if _ENABLE_E2E_PROTECTION */
            {
                gsRwCtrl.u32FreeSrcFifoTail=(gsRwCtrl.u32FreeSrcFifoTail+1)&(cReadFifoDpt-1);
            }
        }
    }

    /*
       * while(gsRwCtrl.u32CompleHmbTail!=gsRwCtrl.u32CompleHmbHead)
       * {
       *  upDelLlInfo=&gsRwCtrl.usSrcCmdList;
       *  uSrcIdx=gsRwCtrl.uarCompleHmbPrd[gsRwCtrl.u32CompleHmbTail];
       *  chkReadState(&garSrcAddrInfo[uSrcIdx]);
       *  gsRwCtrl.u32CompleHmbTail=(gsRwCtrl.u32CompleHmbTail+1)&(cPrdDepth-1);
       *  mDelNode(u16PrevNodeIdx, gsRwCtrl.uarSrcCmdLink, uSrcIdx, u16NextNodeIdx, upDelLlInfo);
       *  gsRwCtrl.uarFreeSrcQue[gsRwCtrl.u32FreeSrcFifoTail]=uSrcIdx;
       *  gsRwCtrl.u32FreeSrcFifoTail=(gsRwCtrl.u32FreeSrcFifoTail+1)&(cReadFifoDpt-1);
       * }
       */

    trigFlCmdFfStep3();

    if(gEnableLdpcPipe)
    {
        if(g16LdpcDmaIdCnt&&rmChkLdpcInfoFifoReady)
        {
            chkLdpcResult(cLdpcNormalErr);
        }

#if _EN_PROGFAILLOG
        if(rmChkSysStsErr)
        {
            for(uCh=0; uCh<gTotalChNum; uCh++)
            {
                setFLActCh(uCh);
                chkStatusFail(uCh);
            }
        }
#endif
    }
    else if(gsRwCtrl.uAllOpIdxCntR)
    {
        for(uCh=0; uCh<gTotalChNum; uCh++)
        {
            chkRwOpIdxTail(uCh);
        }
    }

#if _EN_RAID_DECODE
    if(gsRaidInfo.uRaidDecQueCnt)
    {
        doRaidDecodeSwap();    // doRaidDecode();
    }
#endif
}    /* trigFlCmdFfStep2 */

/*
   * void trigChFlashCmdFifoR(BYTE uCh)
   * {
   *  setFLAddrActCh(uCh, &garSrcAddrInfo[gsRwCtrl.uChReadFifoIdx[uCh][gsRwCtrl.uChReadFifoTrig[uCh]]]);
   *
   *  if(!rmChkEccFail)    // if(rmChkCmdFifoDpt(gHalfCmdThr)&&!rmChkUNC)
   *  {
   *      waitChCeBz(uCh, gIntlvAddr, cNoOp);
   *      flashReadPage();
   *      setBzInfo(gOpTyp, uCh, gIntlvAddr);
   *      addReadOpIdex(uCh);
   *      gsRwCtrl.uChReadFifoCnt[uCh]--;
   *      gsRwCtrl.u32AllReadFifoCnt--;
   *      gsRwCtrl.uChReadFifoTrig[uCh]=(gsRwCtrl.uChReadFifoTrig[uCh]+1)&(cMaxChFifoRDepth-1);
   *  }
   * }
   */

void chkPostReadFifo3()    // rand
{
    WORD u16Trig;
    LWORD u32DummyPat=gsNamespace.u32DummyPatt;
    ADDRINFO *upAddrInfo;

    u16Trig=gsRwCtrl.usSrcCmdList.u16Trig;

    while((u16Trig!=cNull)&&(gsRwCtrl.uHdmaAccCnt<32))
    {
        upAddrInfo=&garSrcAddrInfo[u16Trig];

        if(upAddrInfo->uOpTyp<cHdmaDummy)    // &&(upAddrInfo->uOpTyp!=cGcHdmaDummy))
        {
            chkPostPreReadFifo(u16Trig, upAddrInfo->uCh, upAddrInfo->uIntlvAddr);
            u16Trig=gsRwCtrl.uarSrcCmdLink[u16Trig].uNext;

            while(gsRwCtrl.uChPreFifoCnt[upAddrInfo->uCh]>(cMaxCeFifoRDepth-2))    // while(gsRwCtrl.uChPreFifoCnt[uCh]>(cMaxCeFifoRDepth-2))
            {
                trigFlCmdFfStep2();
            }
        }
        /*
           * else if(upAddrInfo->uOpTyp==cHmbWrCacheData)
           * {
           *  upAddrInfo->u32FPageNoTran=((upAddrInfo->u32FPageNoTran&(g16H2fTabSize-1))<<12)+((upAddrInfo->u16BufPtr<<9)&0x0FFF);
           *  gsRwCtrl.uarTrigHmbPrd[gsRwCtrl.u32TrigHmbHead]=u16Trig;
           *  gsRwCtrl.u32TrigHmbHead=(gsRwCtrl.u32TrigHmbHead+1)&(cPrdDepth-1);
           *  u16Trig=gsRwCtrl.uarSrcCmdLink[u16Trig].uNext;
           *
           *  while(gsRwCtrl.u32TrigHmbHead==gsRwCtrl.u32TrigHmbTail)
           *      ;
           * }
           */
        else
        {
            gsE2eInfo.u32GenerateLba=calReadFifoLbaAddr(u16Trig);
#if _EN_RAID_GC
            WORD u16Opt=cClrTsb|cHdmaTsbFlag|cHdmaNotWait;

            if(!gsGcInfo.uHmbEnGcCache&&(upAddrInfo->uPrdPtr==0xFF))
            {
                u16Opt|=cHdmaRaidFlag;
            }

            if(gSecurityOption&cEnE2e)
            {
                u16Opt|=(cHdmaEnCrc|cHdmaGenCrc);
            }
            else
            {
                if(gbEnAes&&((upAddrInfo->uOpTyp!=cMbrReadDummy)&&(upAddrInfo->uOpTyp!=cSecReadDummy)&&(upAddrInfo->uOpTyp!=cGcHdmaDummy)))
                {
                    u16Opt|=cHdmaEnFwAes;
                }
            }

            if(upAddrInfo->uOpTyp==cSecReadDummy)
            {
                u16Opt&=~cHdmaTsbFlag;
            }

            hdmaClrRam((LWORD)(cTsb0Addr+(upAddrInfo->u16BufPtr<<9)),
                       upAddrInfo->uRwHalfKb<<9, u32DummyPat, u16Opt);
#else/* if _EN_RAID_GC */
            hdmaClrRam((LWORD)(cTsb0Addr+(upAddrInfo->u16BufPtr<<9)),
                       upAddrInfo->uRwHalfKb<<9, u32DummyPat,
                       cClrTsb|cHdmaTsbFlag|cHdmaNotWait|cHdmaEnCrc|cHdmaGenCrc);
#endif/* if _EN_RAID_GC */
            gsRwCtrl.uHdmaAccCnt++;
            gsRwCtrl.uarHdmaFifoIdx[gsRwCtrl.uHdmaFifoHead]=u16Trig;
            gsRwCtrl.uHdmaFifoHead=(gsRwCtrl.uHdmaFifoHead+1)&(cMaxHdmaQNum-1);
            u16Trig=gsRwCtrl.uarSrcCmdLink[u16Trig].uNext;
        }
    }

    gsRwCtrl.usSrcCmdList.u16Trig=u16Trig;
}    /* chkPostReadFifo3 */

// void trigFlashCmdFifoR()
// {
//    chkPostReadFifo3();
//    trigFlCmdFfStep2();
// }

void chkPostPreReadFifo(WORD u16Trig, BYTE uCh, BYTE uIntlvAddr)
{
    gsRwCtrl.uChPreFifoIdx[uCh][uIntlvAddr][gsRwCtrl.uChPreFifoHead[uCh][uIntlvAddr]]=u16Trig;
    gsRwCtrl.uChPreFifoHead[uCh][uIntlvAddr]=(gsRwCtrl.uChPreFifoHead[uCh][uIntlvAddr]+1)&(cMaxChFifoRDepth-1);
    gsRwCtrl.uChPreFifoCnt[uCh]++;
    gsRwCtrl.u32AllReadFifoCnt++;

    // while(gsRwCtrl.uChPreFifoHead[uCh]==gsRwCtrl.uChPreFifoTail[uCh])
    //    ;
}

void chkPostReadFifo2()
{
    BYTE uTsbCnt, uTsbIdx;
    WORD u16Trig, u16Opt;
    LWORD u32DummyPat=gsNamespace.u32DummyPatt;

    u16Trig=gsRwCtrl.usSrcCmdList.u16Trig;

    while((u16Trig!=cNull)&&(gsRwCtrl.uHdmaAccCnt<32))
    {
        ADDRINFO *upAddrInfo=&garSrcAddrInfo[u16Trig];

        uTsbCnt=upAddrInfo->uPlaneCnt;
        uTsbIdx=upAddrInfo->uTsb4kIdx;

        if(upAddrInfo->uOpTyp<cHdmaDummy)
        {
            upAddrInfo->uReadBufSerl=garReadBufOrderHead[uTsbIdx];

            if(uTsbIdx!=0xFF)
            {
                while(1)
                {
                    garReadBufOrderHead[uTsbIdx]++;
                    uTsbCnt--;

                    if(!uTsbCnt)
                    {
                        break;
                    }

                    uTsbIdx=(uTsbIdx==(c16ReadBufSize4K-1))?0:(uTsbIdx+1);
                }
            }

            chkPostPreReadFifo(u16Trig, upAddrInfo->uCh, upAddrInfo->uIntlvAddr);
            u16Trig=gsRwCtrl.uarSrcCmdLink[u16Trig].uNext;

            while(gsRwCtrl.uChPreFifoCnt[upAddrInfo->uCh]>(cMaxCeFifoRDepth-2))
            {
                trigFlCmdFfStep2();
            }
        }
        /*
           * else if(upAddrInfo->uOpTyp==cHmbWrCacheData)
           * {
           *  upAddrInfo->u32FPageNoTran=((upAddrInfo->u32FPageNoTran&(g16H2fTabSize-1))<<12)+((upAddrInfo->u16BufPtr<<9)&0x0FFF);
           *  gsRwCtrl.uarTrigHmbPrd[gsRwCtrl.u32TrigHmbHead]=u16Trig;
           *  gsRwCtrl.u32TrigHmbHead=(gsRwCtrl.u32TrigHmbHead+1)&(cPrdDepth-1);
           *  u16Trig=gsRwCtrl.uarSrcCmdLink[u16Trig].uNext;
           *
           *  while(gsRwCtrl.u32TrigHmbHead==gsRwCtrl.u32TrigHmbTail)
           *      ;
           * }
           */
        else if(chkReadBufFree(uTsbIdx, uTsbCnt, garReadBufOrderHead[uTsbIdx]))
        {
            upAddrInfo->uReadBufSerl=garReadBufOrderHead[uTsbIdx];

            if(uTsbIdx!=0xFF)
            {
                while(1)
                {
                    garReadBufOrderHead[uTsbIdx]++;
                    uTsbCnt--;

                    if(!uTsbCnt)
                    {
                        break;
                    }

                    uTsbIdx=(uTsbIdx==(c16ReadBufSize4K-1))?0:(uTsbIdx+1);
                }
            }

            u16Opt=(cClrTsb|cHdmaNotWait|cHdmaTsbFlag);
            gsE2eInfo.u32GenerateLba=calReadFifoLbaAddr(u16Trig);

            if(gSecurityOption&cEnE2e)
            {
                u16Opt|=(cHdmaEnCrc|cHdmaGenCrc);
            }
            else
            {
                if(gbEnAes&&((upAddrInfo->uOpTyp!=cMbrReadDummy)&&(upAddrInfo->uOpTyp!=cSecReadDummy)&&(upAddrInfo->uOpTyp!=cGcHdmaDummy)))
                {
                    u16Opt|=cHdmaEnFwAes;
                }
            }

            if(upAddrInfo->uOpTyp==cSecReadDummy)
            {
                u16Opt&=~cHdmaTsbFlag;
            }

#if _EN_RAID_GC
            else if(!gsGcInfo.uHmbEnGcCache&&(upAddrInfo->uOpTyp==cGcHdmaDummy))
            {
                u16Opt|=cHdmaRaidFlag;
            }
#endif
            hdmaClrRam((LWORD)(cTsb0Addr+(upAddrInfo->u16BufPtr<<9)),
                       upAddrInfo->uRwHalfKb<<9,
                       u32DummyPat,
                       u16Opt);
            gsRwCtrl.uHdmaAccCnt++;
            gsRwCtrl.uarHdmaFifoIdx[gsRwCtrl.uHdmaFifoHead]=u16Trig;
            gsRwCtrl.uHdmaFifoHead=(gsRwCtrl.uHdmaFifoHead+1)&(cMaxHdmaQNum-1);
            u16Trig=gsRwCtrl.uarSrcCmdLink[u16Trig].uNext;
        }
        else
        {
            break;
        }
    }

    gsRwCtrl.usSrcCmdList.u16Trig=u16Trig;
}    /* chkPostReadFifo2 */

// void trigFlashCmdFifoR3()
// {
//    chkPostReadFifo2();
//    trigFlCmdFfStep2();
// }

void sortProgFifoIdx(BYTE uCh, BYTE uIdx)
{
    gsRwCtrl.uChProgFifoPlaneCnt[uCh]-=garDesAddrInfo[gsRwCtrl.uChProgFifoIdx[uCh][uIdx]].uPlaneCnt;
    gsRwCtrl.uChProgFifoCnt[uCh]--;
}

#if 0
void setFifoClrOccF(WORD u16BufPtr, BYTE uSctrCnt)    // , BYTE uNormal)
{
#if _ENABLE_OCC_FLAG
    WORD u16BufPtrEnd;
    BYTE uSctrCntClr;

    u16BufPtrEnd=addWriteBufPtr(u16BufPtr, uSctrCnt);
    rmClrTSBOcc;

    if((u16BufPtrEnd==c16WriteSIdx)||(u16BufPtrEnd>u16BufPtr))
    {
        rmSetOccFlagClrLen(uSctrCnt);
        rmOccStartAddr(u16BufPtr);
    }
    else
    {
        uSctrCntClr=(c16WriteSIdx+c16WriteBufSize)-(u16BufPtr);
        rmSetOccFlagClrLen(uSctrCntClr);
        rmOccStartAddr(u16BufPtr);
        rmClrOccFlag;
        rmNop(16);
        rmSetOccFlagClrLen(uSctrCnt-uSctrCntClr);
        rmOccStartAddr(c16WriteSIdx);
    }
    rmClrOccFlag;
#endif/* if _ENABLE_OCC_FLAG */
}    /* setFifoClrOccF */

#endif/* if 0 */
#if _EnSpareFunc
BYTE waitSpareReady(BYTE uCh)
{
    if(gWaitSpareTyp[uCh]==cTLCData)
    {
        if((gSpareCnt[uCh]+cSpareUseOfTLC)<cSpareRegisterCnt)
        {
            return 1;
        }
        else
        {
            return 0;
        }
    }
    else if(gWaitSpareTyp[uCh]==cSLCData)
    {
        if((gSpareCnt[uCh]+cSpareUseOfSLC)<cSpareRegisterCnt)
        {
            return 1;
        }
        else
        {
            return 0;
        }
    }

    return 1;
}    /* waitSpareReady */

#endif/* if _EnSpareFunc */
#if 0
void clrDataOccFlag(BYTE uBufNum)
{
    BYTE uBufIdx, uHalfKB, uClrOccSize;

    uHalfKB=gpFlashAddrInfo->uRwHalfKb;

    for(uBufIdx=0; uBufIdx<uBufNum; uBufIdx++)
    {
        if(uHalfKB<gSectorPerPageH)
        {
            uClrOccSize=uHalfKB;
            uHalfKB=0;
        }
        else
        {
            uClrOccSize=gSectorPerPageH;
            uHalfKB-=gSectorPerPageH;
        }

        setFifoClrOccF(gpFlashAddrInfo->u16BufPtr, uClrOccSize);    // , 1);

        if(!uHalfKB)
        {
            break;
        }
    }
}    /* ClrDataOccFlag */

#endif/* if 0 */
/*
   * void trigChFlashCmdFifoW(BYTE uCh)
   * {
   *  BYTE uBufNum=1;
   *
   *  setFLAddrActCh(uCh, &garDesAddrInfo[gsRwCtrl.uChProgFifoIdx[uCh][gsRwCtrl.uChProgFifoTrig[uCh]]]);
   *
   *  if(mChkMlcMoBit(g16FBlock))
   *  {
   *      uBufNum=cProgCntPerWL;
   *  }
   *
   *  if(!rmChkEccFail)    // if((chkCmdFifoDptCh(uCh)==cTrue)&&!rmChkUNC)
   *  {
   *      gActiveCe=gpFlashAddrInfo->uCe;
   *      waitChCeBz(uCh, gIntlvAddr, gsRwCtrl.uRdyTyp[uCh][gIntlvAddr]);
   *
   *      if(gOpTyp==cCacheProgData)
   *      {
   *          gsRwCtrl.uRdyTyp[uCh][gIntlvAddr]=1;
   *      }
   *
   #if _EnSpareFunc
   *      if(gpFlashAddrInfo->uSprSetDone&&(g32Core1State>=cCore1BootState_Finished))
   *      {
   *          while(1)
   *              ;
   *      }
   *
   *      if(!gpFlashAddrInfo->uSprSetDone)    // add for rdlink flow core 0 has set spare byte
   *      {
   *          setSprByteOfDataBlk(gsRwCtrl.uChProgFifoIdx[uCh][gsRwCtrl.uChProgFifoTrig[uCh]]);
   *      }
   #endif
   *
   *      if(gpFlashAddrInfo->uAddrOpt&cForeClrOccF)
   *      {
   *          // if(gsGcInfo.uClrOccFCnt)
   *          // {
   *          //    setFifoClrOccF(gpFlashAddrInfo->u16OneShotBufPtr[cLSB], gSectorPerPageH, 0);
   *          // }
   *          // else
   *          // {
   *          clrDataOccFlag(uBufNum);
   *          // }
   *      }
   *
   *      flashProgPage(mGetWriteBuf, mGetProgSctrCnt, mGetWriteOpt);
   *
   *      if(gpFlashAddrInfo->uAddrOpt&cBackClrOccF)
   *      {
   *          clrDataOccFlag(uBufNum);
   *      }
   *
   *      setBzInfo(gOpTyp, uCh, gIntlvAddr);
   *      // gsRwCtrl.usWaitInfo[uCh][gIntlvAddr].uStatusErrStop=1;
   *      addProgOpIdex(uCh);
   *      sortProgFifoIdx(uCh, gsRwCtrl.uChProgFifoTrig[uCh]);
   *      gsRwCtrl.uChProgFifoTrig[uCh]=addChPgFfPtrBy1(gsRwCtrl.uChProgFifoTrig[uCh]);
   *  }
   * }
   */

void chkPostProgFifo()
{
    BYTE uCh;
    ADDRINFO *upTmpAddrInfo;

    while(gsRwCtrl.u32ProgFifoTrig!=gsRwCtrl.u32ProgFifoHead)
    {
        upTmpAddrInfo=&garDesAddrInfo[gsRwCtrl.u32ProgFifoTrig];
        uCh=upTmpAddrInfo->uCh;

        // if((gsRwCtrl.uChProgFifoPlaneCnt[uCh]+garDesAddrInfo[gsRwCtrl.u32ProgFifoTrig].uPlaneCnt)>gsRwCtrl.uMaxFLChFifoDpt)
        // {
        //    break;
        // }
        // else
        // {
        if(gsRwCtrl.uChProgFifoCnt[uCh]+gsRwCtrl.uOpIdxAccCntW[uCh]<cMaxChFifoDepth)
        {
#if _ENABLE_RAID
            if(!chkTailFifoOffset())
            {
                break;
            }
            trigHdmaEncData(upTmpAddrInfo);
#endif
            gsRwCtrl.uChProgFifoIdx[uCh][gsRwCtrl.uChProgFifoHead[uCh]]=gsRwCtrl.u32ProgFifoTrig;
            gsRwCtrl.uChProgFifoPlaneCnt[uCh]+=upTmpAddrInfo->uPlaneCnt;
            gsRwCtrl.uChProgFifoHead[uCh]=addChPgFfPtrBy1(gsRwCtrl.uChProgFifoHead[uCh]);
            gsRwCtrl.uChProgFifoCnt[uCh]++;
            gsRwCtrl.u32ProgFifoTrig=addWrFfPtrBy1(gsRwCtrl.u32ProgFifoTrig);
        }
        else
        {
            break;
        }
    }
}    /* chkPostProgFifo */

void trigFlashCmdFifoW()
{
    BYTE uCh;    // , uBufNum;

    if(gsRwCtrl.u32FreeSrcFifoTrig!=gsRwCtrl.u32FreeSrcFifoHead)
    {
        insSrcCmdList();
    }
    else
    {
        // chkPostReadFifo();
        chkPostProgFifo();

        for(uCh=0; uCh<gTotalChNum; uCh++)
        {
            // if(gsRwCtrl.uChReadFifoCnt[uCh]!=0)
            // {
            //    trigChFlashCmdFifoR(uCh);
            // }
            // else
#if !_EnSpareFunc
            if(gsRwCtrl.uChProgFifoCnt[uCh]!=0)
            {
#else
            if((gsRwCtrl.uChProgFifoCnt[uCh]!=0)&&waitSpareReady(uCh))
            {
#endif
                // trigChFlashCmdFifoW(uCh);
                setFLAddrActCh(uCh, &garDesAddrInfo[gsRwCtrl.uChProgFifoIdx[uCh][gsRwCtrl.uChProgFifoTrig[uCh]]]);

#if (_GREYBOX)
                if(gsGbInfo.uGreyBoxItem==cUGSDProgCacheSlcID)
                {
                    if((gsGbInfo.uGreyBoxOpt==cVOpProgPause)&&(gsGbInfo.uStag==cVsIdl))
                    {
                        if((uCh==1)&&(g16FPage==(g16PagePerBlock1_SLC-1))&&(gIntlvAddr==(gIntlvWay-1)))
                        {
                            outSta(cVTrig);
                            gsGbInfo.uStag=cVsTriggered;
                            rmCmdPause;
                        }
                    }
                }
#endif

                // if(mChkMlcMoBit(g16FBlock))
                // {
                //    uBufNum=cProgCntPerWL;
                // }
                // else
                // {
                //    uBufNum=1;
                // }

#if 0    // _ENABLE_RAID
                trigHdmaEncData();
#endif

                // if(!rmChkEccFail)
                // {
                gActiveCe=gpFlashAddrInfo->uCe;
                waitChCeBz(uCh, gIntlvAddr, gsRwCtrl.uRdyTyp[uCh][gIntlvAddr]);

                if(gOpTyp==cCacheProgData)
                {
                    gsRwCtrl.uRdyTyp[uCh][gIntlvAddr]=(mGetPageSelCmd(gpFlashAddrInfo)!=cMsbPreFixCmd)?cRdyTypSlcCacheW:cRdyTypTlcCacheW;
                }

#if _EnSpareFunc
                if(!mChkSprSetDone(gpFlashAddrInfo))    // add for rdlink flow core 0 has set spare byte
                {
                    setSprByteOfDataBlk(gsRwCtrl.uChProgFifoIdx[uCh][gsRwCtrl.uChProgFifoTrig[uCh]]);
                }
                else
                {
                    while(g32Core1State>=cCore1BootState_Finished)
                        ;
                }
#endif

                // if(gpFlashAddrInfo->uAddrOpt&cForeClrOccF)
                // {
                //    clrDataOccFlag(uBufNum);
                // }

                flashProgPage(mGetWriteBuf, mGetProgSctrCnt, mGetWriteOpt);

                // if(gpFlashAddrInfo->uAddrOpt&cBackClrOccF)
                // {
                //    clrDataOccFlag(uBufNum);
                // }

                setBzInfo(gOpTyp, uCh, gIntlvAddr);
                gsRwCtrl.usWaitInfo[uCh][gIntlvAddr].uStatusErrStop=1;
                addProgOpIdex(uCh);
                sortProgFifoIdx(uCh, gsRwCtrl.uChProgFifoTrig[uCh]);
                gsRwCtrl.uChProgFifoTrig[uCh]=addChPgFfPtrBy1(gsRwCtrl.uChProgFifoTrig[uCh]);
                // }
            }
        }

        while(gsRwCtrl.usSrcCmdList.u16Tail!=gsRwCtrl.usSrcCmdList.u16Trig)
            ;

        if(gsRwCtrl.u32ProgFifoTail!=gsRwCtrl.u32ProgFifoTrig)
        {
            for(uCh=0; uCh<gTotalChNum; uCh++)
            {
                // chkRwOpIdxTail(uCh);
                if(gsRwCtrl.uOpIdxAccCntW[uCh])
                {
                    chkOpIdxAccCntW(uCh);
#if _EN_PROGFAILLOG
                    chkStatusFail(uCh);
#endif
                }
            }
        }
    }
}    /* trigFlashCmdFifoW */

void trigFLCmdFifoWtab()
{
    BYTE uCh;

    while(gsRwCtrl.u32ProgFifoTail!=gsRwCtrl.u32ProgFifoHead)
    {
        chkPostProgFifo();

        for(uCh=0; uCh<gTotalChNum; uCh++)
        {
            if((gsRwCtrl.uChProgFifoCnt[uCh]!=0)&&((gSpareCnt[uCh]+cSpareUseOfH2F)<cSpareRegisterCnt))
            {
                setFLAddrActCh(uCh, &garDesAddrInfo[gsRwCtrl.uChProgFifoIdx[uCh][gsRwCtrl.uChProgFifoTrig[uCh]]]);

                if(!rmChkEccFail)
                {
                    gActiveCe=gpFlashAddrInfo->uCe;

                    waitChCeBz(uCh, gIntlvAddr, gsRwCtrl.uRdyTyp[uCh][gIntlvAddr]);

                    if(!mChkTabSpr(gpFlashAddrInfo, cBit6))
                    {
                        gsFtlDbg.u16DummyFailType=cTrigFLCmdFifoWtab;
                        debugWhile();
                    }

                    if((gSparePtrHead[gActiveCh]&(cSpareRegisterCnt-1))<4)
                    {
                        rmSelSprGroup(0);
                    }
                    else
                    {
                        rmSelSprGroup(1);
                    }

                    setSprByteOfTabBlk(cH2fTableID,
                                       garDesF2hInfo[gsRwCtrl.uChProgFifoIdx[uCh][gsRwCtrl.uChProgFifoTrig[uCh]]].u16arHBlock[gPlaneAddr],
                                       mGetH2fSpr1,
                                       mGetH2fSpr2,
                                       mGetH2fSprSerial,
                                       gSparePtrHead[gActiveCh]&3,
                                       cInbgdClnH2fTabblkProc_00);

                    gSpareCnt[gActiveCh]++;
#if _ENABLE_E2E_TAB
                    genInternalDataCrc(gpFlashAddrInfo->u16BufPtr,
                                       gpFlashAddrInfo->uRwHalfKb,
                                       gpFlashAddrInfo->u32FPageNoTran<<cSctrTo4kShift,
                                       cE2eH2fBlk);
#endif

                    flashProgPage(mGetWriteBuf, mGetProgSctrCnt, mGetWriteOpt);

                    gSparePtrHead[gActiveCh]=addPtrBy1(gSparePtrHead[gActiveCh], cSpareRegisterCnt);
                    gSparePtrTail[gActiveCh]=addPtrBy1(gSparePtrTail[gActiveCh], cSpareRegisterCnt);
#if 1    // _EN_PROGFAILLOG
                    addProgOpIdex(uCh);
#endif
                    setBzInfo(gOpTyp, uCh, gIntlvAddr);
                    gsRwCtrl.usWaitInfo[uCh][gIntlvAddr].uStatusErrStop=1;
                    sortProgFifoIdx(uCh, gsRwCtrl.uChProgFifoTrig[uCh]);
                    gsRwCtrl.uChProgFifoTrig[uCh]=addChPgFfPtrBy1(gsRwCtrl.uChProgFifoTrig[uCh]);
                }
            }
        }

        // rstFifoTailPtr();
        for(uCh=0; uCh<gTotalChNum; uCh++)
        {
            chkRwOpIdxTail(uCh);
        }
    }
}    /* trigFLCmdFifoWtab */

void insSrcCmdList()
{
    WORD u16PrevNodeIdx, u16NextNodeIdx, u16NowNodeIdx;
    LWORD u32FreeSrcFifoTrig=gsRwCtrl.u32FreeSrcFifoTrig;
    volatile LINKINFO *upInsLlInfo=&gsRwCtrl.usSrcCmdList;

    do
    {
        u16NowNodeIdx=gsRwCtrl.uarFreeSrcQue[u32FreeSrcFifoTrig];
        u32FreeSrcFifoTrig=(u32FreeSrcFifoTrig+1)&(cReadFifoDpt-1);
        mInsNode(u16PrevNodeIdx, upInsLlInfo, u16NextNodeIdx, gsRwCtrl.uarSrcCmdLink, u16NowNodeIdx);
    }
    while(u32FreeSrcFifoTrig!=gsRwCtrl.u32FreeSrcFifoHead);

    gsRwCtrl.u32FreeSrcFifoTrig=u32FreeSrcFifoTrig;

    if(gsRwCtrl.usSrcCmdList.u16Cnt>cReadFifoDpt)
    {
        gsFtlDbg.u16DummyFailType=cInsSrcCmdList;
        debugWhile();
    }

    /*
       * else
       * {
       *  if(gsRwCtrl.usSrcCmdList.u16Cnt>gsRwCtrl.u32Debug1)
       *  {
       *      gsRwCtrl.u32Debug1=gsRwCtrl.usSrcCmdList.u16Cnt;
       *  }
       * }
       */
}    /* insSrcCmdList */

void termContiRCore1()
{
    volatile LINKINFO *upDelLlInfo;
    WORD u16PrevNodeIdx, u16NextNodeIdx;
    BYTE uCh, uIntlvAddr;

    if(gsRwCtrl.u32AllReadFifoCnt)
    {
        gsRwCtrl.u32AllReadFifoCnt=0;

        for(uCh=0; uCh<gTotalChNum; uCh++)
        {
            gsRwCtrl.uChReadFifoCnt[uCh]=0;
            gsRwCtrl.uChReadFifoTrig[uCh]=gsRwCtrl.uChReadFifoHead[uCh];
#if _EN_MutiWayCacheRImprove
            gsRwCtrl.uChLastReadCmdWay[uCh]=cInvalid8Bit;
            gsRwCtrl.uChForceDataOut[uCh]=0;
#endif

            for(uIntlvAddr=0; uIntlvAddr<gIntlvWay; uIntlvAddr++)
            {
                gsRwCtrl.uChPreFifoTail[uCh][uIntlvAddr]=gsRwCtrl.uChPreFifoHead[uCh][uIntlvAddr];
                gsRwCtrl.uChPreFifoCnt[uCh]=0;
            }
        }
    }

    while(gsRwCtrl.uHdmaAccCnt||    /*(gsRwCtrl.u32CompleHmbTail!=gsRwCtrl.u32CompleHmbHead)||*/ (gsRwCtrl.uAllOpIdxCntR||g16LdpcDmaIdCnt))
    {
        rmResetBufFlg;
        trigFlCmdFfStep2();
    }

    while(gsRwCtrl.usSrcCmdList.u16Cnt)
    {
        upDelLlInfo=&gsRwCtrl.usSrcCmdList;
        gsRwCtrl.uarFreeSrcQue[gsRwCtrl.u32FreeSrcFifoTail]=gsRwCtrl.usSrcCmdList.u16Tail;
        mDelNode(u16PrevNodeIdx, gsRwCtrl.uarSrcCmdLink, gsRwCtrl.usSrcCmdList.u16Tail, u16NextNodeIdx, upDelLlInfo);
        gsRwCtrl.u32FreeSrcFifoTail=(gsRwCtrl.u32FreeSrcFifoTail+1)&(cReadFifoDpt-1);
    }

    gsRwCtrl.usSrcCmdList.u16Trig=cNull;
    gsRwCtrl.u32FreeSrcFifoTail=gsRwCtrl.u32FreeSrcFifoTrig=gsRwCtrl.u32FreeSrcFifoHead;

    for(uCh=0; uCh<gTotalChNum; uCh++)
    {
        gsRwCtrl.uChReadFifoTail[uCh]=gsRwCtrl.uChReadFifoHead[uCh];

        for(uIntlvAddr=0; uIntlvAddr<gIntlvWay; uIntlvAddr++)
        {
            gsRwCtrl.u16LastFBlockR[uCh][uIntlvAddr]=cInvalid16Bit;
            setFLActCh(uCh);
            waitChCeBz(uCh, uIntlvAddr, 0);
#if _EN_CacheR
            if(gsRwCtrl.uEnCacheR)
            {
                rmCeOn(mGetCEAddr(uIntlvAddr));
                rmSetDieBit(mGetDieAddr(uIntlvAddr));
                pollStatus(cPollMaskNor);
                rmCle(gLastPageCacheReadCmd);
                pollStatus(cPollMaskNor);
                rmAllCeOff;
            }
#endif
        }
    }

    g16LastRdCntFBlock=cInvalid16Bit;
    g16LastRdCntFPage=cInvalid16Bit;

    rmResetBufFlg;
}    /* termContiRCore1 */

#if _EN_SLCOpenBlkReadScrub
BYTE chkReadCnt(WORD uFblk)
{
    LWORD u32ReadCnt;
    BYTE uLoop;

    if(!mChkFLOption(cEnReadScrub))
    {
        return cFalse;
    }

    u32ReadCnt=mGetGlobReadCnt(uFblk);

    if(!mChkMlcMoBit(uFblk))
    {
        if((gsCacheInfo.u16ActiveCacheBlock==uFblk)&&(mGetGcFlushState==cFlushIdle))
        {
            if((u32ReadCnt>c32SLCOpenBlkRCThr)&&(gsGcInfo.u16FlushBlk==c16FBlockInitValue))
            {
                return cTrue;
            }
            else
            {
                return cFalse;
            }
        }
        else
        {
            if((u32ReadCnt>c32SLCOpenBlkRCThr)&&(g16arH2fTabBlk[gsCacheInfo.uActH2fTabBlkIdx]==uFblk)&&
               (!mChkGcFlag(cReadScrubH2F)))
            {
                return cTrue;
            }
        }
    }

    if(mChkMlcMoBit(uFblk))
    {
        if((mGetGlobEraseCnt(uFblk)>=c16TLCBoltoEolECThr)&&(u32ReadCnt>c32TLCBlkRCEolThr))
        {
            return cTrue;
        }
        else if((mGetGlobEraseCnt(uFblk)<c16TLCBoltoEolECThr)&&(u32ReadCnt>c32TLCBlkRCBolThr))
        {
            return cTrue;
        }
        else
        {
            return cFalse;
        }
    }
    else if(((mGetGlobEraseCnt(uFblk)>=c16SLCBoltoEolECThr)&&(u32ReadCnt>c32SLCCloseBlkRCEolThr))||
            ((mGetGlobEraseCnt(uFblk)<c16SLCBoltoEolECThr)&&(u32ReadCnt>c32SLCCloseBlkRCBolThr)))
    {
        if(!mChkSkipGcSrch(uFblk)||mChkGcSrcBlkBmap(uFblk))
        {
            return cTrue;
        }
        else if(!mChkGcFlag(cReadScrubH2F))
        {
            for(uLoop=0; uLoop<gMaxH2fTabBlkNum; uLoop++)
            {
                if((g16arH2fTabBlk[uLoop]==uFblk))
                {
                    return cTrue;
                }
            }
        }
        else
        {
            return cFalse;
        }
    }

    return cFalse;
}    /* chkReadCnt */

#endif/* if _EN_SLCOpenBlkReadScrub */

BYTE chkReadBufFree(BYTE uTsbIdx, BYTE uTsbCnt, BYTE uBufSerial)
{
    if(uTsbIdx!=cBitFF)
    {
        while(1)
        {
            if((garReadBufOrderTail[uTsbIdx]!=uBufSerial)||rmBufStatus(uTsbIdx))
            {
                return cFalse;
            }

            uTsbCnt--;

            if(!uTsbCnt)
            {
                break;
            }

            if(uTsbIdx==(c16ReadBufSize4K-1))
            {
                uTsbIdx=0;
                uBufSerial++;
            }
            else
            {
                uTsbIdx++;
            }
        }
    }

    return cTrue;
}    /* chkReadBufFree */

BYTE compareBufSerl(BYTE uOrgMinSerial, BYTE uNowSerial, BYTE uOrgMin4kIdx, BYTE uNow4kIdx)
{
    if(uOrgMinSerial==uNowSerial)
    {
        // equal
        if(uNow4kIdx<uOrgMin4kIdx)
        {
            return cTrue;
        }
    }
    else if(uOrgMinSerial>uNowSerial)
    {
        // greater
        if((uOrgMinSerial-uNowSerial)<32)
        {
            return cTrue;
        }
    }
    else if((uNowSerial-uOrgMinSerial)>32)
    {
        // smaller
        return cTrue;
    }

    return cFalse;
}    /* compareBufSerl */







