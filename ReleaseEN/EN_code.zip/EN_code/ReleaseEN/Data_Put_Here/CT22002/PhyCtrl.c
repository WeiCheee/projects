







#include "inc/DebugLog.h"
#include "inc/EventLogIDX.h"
#include "inc/EventLogFunctionIDX.h"
#include "inc/ProType.h"
#include "inc/GlobVarS.h"
#include "inc/GlobVar0.h"
#include "inc/table.h"
#include "inc/Reg.h"

#if (!_ICE_LOAD_ALL)
#pragma default_function_attributes = @ ".PHY_CTRL"
#endif

#if (_PHYCHG5_CR)
void clrCtrl()
{
    BYTE uLoop;

    while(!rmCrAck)
        ;// polling 0

    for(uLoop=0; uLoop<50; uLoop++)
    {
        _nop();
    }

    rmSetLfckGating;

    for(uLoop=0; uLoop<50; uLoop++)
    {
        _nop();
    }

    rmClrCtrl;

    for(uLoop=0; uLoop<50; uLoop++)
    {
        _nop();
    }

    rmClrLfckGating;

    while(rmCrAck)
        ;// polling 1
}    /* clrCtrl */

WORD crRead(WORD u16Addr)
{
    WORD u16data;

#if (!_FW_CTRL_LFCK)
    rmClrtLfckAutoGate;
#endif

    while(rmCrAck)
        ;// polling 0

    rmCrDataInOut=u16Addr;
    rmCrCapAddr;
    clrCtrl();
    rmCrReadData;
    clrCtrl();
    u16data=rmCrDataInOut;

#if (!_FW_CTRL_LFCK)
    rmSetLfckAutoGate;
#endif

    return u16data;
}    /* crRead */

void crWrite(WORD u16Addr, WORD u16Data)
{
#if (!_FW_CTRL_LFCK)
    rmClrtLfckAutoGate;
#endif

    while(rmCrAck)
        ;// polling 0

    rmCrDataInOut=u16Addr;
    rmCrCapAddr;
    clrCtrl();

    rmCrDataInOut=u16Data;
    rmCrCapData;
    clrCtrl();

    rmCrWriteData;
    clrCtrl();

#if (!_FW_CTRL_LFCK)
    rmSetLfckAutoGate;
#endif
}    /* crWrite */

#else/* if _PHYCHG5_CR */
#if _CR_POLLING
void crPolling()
{
    while(!rmCrAck)
        ;// polling 0

    sysDelay(100);
    rmClrCtrl;

    while(rmCrAck)
        ;// polling 1
}

#endif
WORD crRead(WORD u16Addr)
{
    WORD u16Data;

    while(rmCrAck)
        ;// polling 0

    rmCrDataInOut=u16Addr;
    rmCrCapAddr;
#if _CR_POLLING
    crPolling();
#else
    while(rmPolCrCapAddr)
        ;// polling 0
#endif

    rmCrReadData;
#if _CR_POLLING
    crPolling();
#else
    while(!rmPolCrReadData)
        ;// polling 0
#endif
    u16Data=rmCrDataInOut;

    return u16Data;
}    /* crRead */

void crWrite(WORD u16Addr, WORD u16Data)
{
    while(rmCrAck)
        ;// polling 0

    rmCrDataInOut=u16Addr;
    rmCrCapAddr;
#if _CR_POLLING
    crPolling();
#else
    while(rmPolCrCapAddr)
        ;// polling 0
#endif

    rmCrDataInOut=u16Data;
    rmCrCapData;
#if _CR_POLLING
    crPolling();
#else
    while(rmPolCrCapData)
        ;// polling 0
#endif

    rmCrWriteData;
#if _CR_POLLING
    crPolling();
#else
    while(rmPolCrWriteData)
        ;// polling 0
#endif
}    /* crWrite */

#endif/* if _PHYCHG5_CR */

void wakeUpPhy(BYTE uForceWake)
{
    crWrite((0x3C00|cAddrDphyParityBit), cDatSetDphyParityBit);    // enable write priority
    crWrite((0x3C00|0x002A), (uForceWake<<3));
    crWrite((0x3C00|cAddrDphyParityBit), cDatClrDphyParityBit);    // disable write priority
}

// APhy
void chkPhyValue(BYTE uData, BYTE uExpVal, LWORD u32Addr)
{
    if(uExpVal!=uData)
    {
        if(!g16PHYErrAddr)
        {
            gPHYErrData=uData;    // log error info
            gPHYErrExpVal=uExpVal;
            g16PHYErrAddr=u32Addr;
        }

        NLOG_SAVE(cLogHost, PHYCTRL_C, 2, cSaveIdPhyErr, " PHY Setting readback error, Addr=0x%04X, ExpVal=0x%02X, ActVal=0x%02X ", u32Addr,
                  ((WORD)uExpVal<<8)|uData);
    }
}

void writeWiMask(WORD u16Addr, BYTE uMask, BYTE uVal)
{
    WORD u16CrData;
    BYTE uLsb;

    u16CrData=crRead(u16Addr);
    u16CrData&=(~uMask);

    for(uLsb=0; uLsb<8; uLsb++)
    {
        if(uMask&cbBitTab[uLsb])
        {
            crWrite(u16Addr, (u16CrData|(uVal<<uLsb)));
            break;
        }
    }
}

void chkWriteWiMask(WORD u16Addr, BYTE uMask, BYTE uVal)
{
    WORD u16CrData;
    BYTE uLsb;

    u16CrData=crRead(u16Addr);
    u16CrData&=(uMask);

    for(uLsb=0; uLsb<8; uLsb++)
    {
        if(uMask&cbBitTab[uLsb])
        {
            chkPhyValue((u16CrData>>uLsb), uVal, u16Addr);
            break;
        }
    }
}

#if 0    // for code size
void aPhyChkWrite(WORD u16Addr, BYTE uMask, BYTE uVal)
{
    WORD u16CrData;

    u16CrData=(crRead((u16Addr|cAddrSmb)))&(~uMask);
    crWrite((u16Addr|cAddrSmb), (uMask|u16CrData));

    u16CrData=(crRead(u16Addr))&(~uMask);
    crWrite(u16Addr, (uVal|u16CrData));
}

#endif

void setPhyLatency(BYTE uWakeupFlow)    // for resume from PS4
{
#if 1    // _2260PCIe_workaround
    // CSSD - 2576
    WORD u16DphyAddr=cAddrDphyLane0;
    WORD u16CrData;
    WORD u16LaneNum;
    WORD u16DatSetRefRdyH;    // [7:2]
    WORD u16DatSetRefRdyM;    // [7:0]
    WORD u16DatSetRefRdyL;    // [3:0]

    if(uWakeupFlow)    // resume from PS4, set default value: 15us
    {
        u16DatSetRefRdyH=cDatSet15usecRefRdyH;
        u16DatSetRefRdyM=cDatSet15usecRefRdyM;
        u16DatSetRefRdyL=cDatSet15usecRefRdyL;
    }
    else    // extend APhy Pll latency to 30us
    {
#if 1    // for novatek pmic test
        u16DatSetRefRdyH=cDatSet30usecRefRdyH;
        u16DatSetRefRdyM=cDatSet30usecRefRdyM;
        u16DatSetRefRdyL=cDatSet30usecRefRdyL;
#else
        u16DatSetRefRdyH=cDatSet1msecRefRdyH;
        u16DatSetRefRdyM=cDatSet1msecRefRdyM;
        u16DatSetRefRdyL=cDatSet1msecRefRdyL;
#endif
    }

    for(u16LaneNum=0; u16LaneNum<4; u16LaneNum++)
    {
        crWrite(((u16DphyAddr|(u16LaneNum<<8))|cAddrDphyParityBit), cDatSetDphyParityBit);    // enable write priority
#if 0    // ===== w/o CSSD-3222 fix
        u16CrData=crRead((u16DphyAddr|(u16LaneNum<<8))|cAddrCntRefRdyH)&0x03;
        crWrite(((u16DphyAddr|(u16LaneNum<<8))|cAddrCntRefRdyH), (u16DatSetRefRdyH|u16CrData));    // [7:2]
        crWrite(((u16DphyAddr|(u16LaneNum<<8))|cAddrCntRefRdyM), u16DatSetRefRdyM);    // [7:0]
        u16CrData=crRead((u16DphyAddr|(u16LaneNum<<8))|cAddrCntRefRdyL)&0xF0;
#else    // ===== w/i CSSD-3222 fix
        u16CrData=crRead((u16DphyAddr|(u16LaneNum<<8))|cAddrCntRefRdyH)&0xF0;    // CSSD-3222
        crWrite(((u16DphyAddr|(u16LaneNum<<8))|cAddrCntRefRdyH), (u16DatSetRefRdyH|u16CrData));    // [7:2]
        crWrite(((u16DphyAddr|(u16LaneNum<<8))|cAddrCntRefRdyM), u16DatSetRefRdyM);    // [7:0]
        u16CrData=crRead((u16DphyAddr|(u16LaneNum<<8))|cAddrCntRefRdyL)&0x03;    // CSSD-3222
#endif
        crWrite(((u16DphyAddr|(u16LaneNum<<8))|cAddrCntRefRdyL), (u16DatSetRefRdyL|u16CrData));    // [3:0]

        crWrite(((u16DphyAddr|(u16LaneNum<<8))|cAddrDphyParityBit), cDatClrDphyParityBit);    // disable write priority
    }
#endif/* if _2260PCIE_WORKAROUND */
}    /* setPhyLatency */

BYTE chkEqPhase2PresetValueCnt()
{
    BYTE uPresetValueCnt;    // Max Preset Value
    WORD u16Tmp=gsLightSwitch.usPhyLs.u16CustomizeF&0x07FF;

    for(BYTE i=0; i<11; i++)
    {
        if((u16Tmp>>i)&c16Bit0)
        {
            uPresetValueCnt++;
        }
    }

    return uPresetValueCnt;
}

// #endif/* if _Enable_Customize_Patch */

void setPhyAlwaysWake(BYTE uForceWake)
{
    WORD u16LaneAddr;
    WORD u16Data;
    WORD u16LaneNum;

    if(uForceWake)
    {
#if 0
        u16LaneNum=4;
        u16LaneAddr=0x2100|cAddrPllPd;
        u16Data=(crRead(u16LaneAddr)&(~cSmbPllPd));
        aPhyWrite(u16LaneAddr, cSmbPllPd, u16Data);

        do
        {
            u16LaneNum--;
            u16LaneAddr=0x2000|(u16LaneNum<<8);
            u16Data=crRead(u16LaneAddr|cAddrPdWPll)&(~cSmbPdWPll);
            aPhyWrite((u16LaneAddr|cAddrPdWPll), cSmbPdWPll, u16Data);
            u16Data=crRead(u16LaneAddr|cAddrSqPd)&(~cSmbSqPd);
            aPhyWrite((u16LaneAddr|cAddrSqPd), cSmbSqPd, u16Data);
        }
        while(u16LaneNum!=0);
#else
        u16LaneNum=4;

        do
        {
            u16LaneNum--;
            u16LaneAddr=0x3C00|(u16LaneNum<<8);
            crWrite((u16LaneAddr|cAddrDphyParityBit), cDatSetDphyParityBit);    // enable write priority
            u16Data=(crRead(u16LaneAddr|0x88)&(0x3F))|0x40;    // Keep SQON when PHY enter L1.2 state
            crWrite((u16LaneAddr|0x88), u16Data);
            u16Data=(crRead(u16LaneAddr|0x97)&(0xDF))|0x20;    // Keep WPULLON when PHY enter L1.2 state
            crWrite((u16LaneAddr|0x97), u16Data);
            // u16Data=(crRead(u16LaneAddr|0x99)&(0xDF))|0x20;    // Keep RXRON when PHY enter L1.2 state, CSSD-5709
            // crWrite((u16LaneAddr|0x99), u16Data);
            crWrite((u16LaneAddr|cAddrDphyParityBit), cDatClrDphyParityBit);    // disable write priority
        }
        while(u16LaneNum!=0);
#endif/* if 0 */
    }
    else
    {
#if 0
        u16LaneNum=4;
        u16LaneAddr=0x2100|cAddrPllPd|cAddrSmb;
        crWrite((u16LaneAddr), 0x00);

        do
        {
            u16LaneNum--;
            u16LaneAddr=(0x2000|(u16LaneNum<<8))|cAddrSmb;
            crWrite((u16LaneAddr|cAddrPdWPll), 0x00);
            crWrite((u16LaneAddr|cAddrSqPd), 0x00);
        }
        while(u16LaneNum!=0);
#else
        u16LaneNum=4;

        do
        {
            u16LaneNum--;
            u16LaneAddr=0x3C00|(u16LaneNum<<8);
            crWrite((u16LaneAddr|cAddrDphyParityBit), cDatSetDphyParityBit);    // enable write priority
            u16Data=crRead(u16LaneAddr|0x88)&(0x3F);
            crWrite((u16LaneAddr|0x88), u16Data);
            u16Data=crRead(u16LaneAddr|0x97)&(0xDF);
            crWrite((u16LaneAddr|0x97), u16Data);
            // u16Data=crRead(u16LaneAddr|0x99)&(0xDF);    // release RXRON when PHY enter L1.2 state, CSSD-5709
            // crWrite((u16LaneAddr|0x99), u16Data);
            crWrite((u16LaneAddr|cAddrDphyParityBit), cDatClrDphyParityBit);    // disable write priority
        }
        while(u16LaneNum!=0);
#endif/* if 0 */
    }
}    /* disableUnusedLanes */

// void chkDm(WORD u16MRAddr, BYTE uMask)
// {
//    BYTE cbDmTab[2][10]=
//    {
//        {0x00, 0x00, 0x00, 0x00, 0x00, 0x08, 0x0A, 0x08, 0x0A, 0x0D}, {0x14, 0x0D, 0x10, 0x0A, 0x00, 0x00, 0x00, 0x10, 0x0A, 0x00}
//    };
//
//    WORD u16APhyAddr;
//    WORD u16CrData;
//    BYTE uLane;
//
//    for(uLane=0; uLane<4; uLane++)
//    {
//        u16APhyAddr=(cAddrAphyLane0|(uLane<<8)|u16MRAddr);
//        u16CrData=crRead(u16APhyAddr);
//
//        if(u16MRAddr==cAddrDm0)
//        {
//            if(u16CrData!=cbDmTab[0][rmCheckPreset(uLane)])
//            {
//                aPhyWrite((u16APhyAddr), uMask, cbDmTab[0][rmCheckPreset(uLane)]);
//            }
//        }
//        else if(u16MRAddr==cAddrDm2)
//        {
//            if(u16CrData!=cbDmTab[1][rmCheckPreset(uLane)])
//            {
//                aPhyWrite((u16APhyAddr), uMask, cbDmTab[1][rmCheckPreset(uLane)]);
//            }
//        }
//    }
// }    /* chkDm */

// void checkPhyEQ()
// {
// //(A) if APhy value different from the value from Host(in MAC) then use FW to force set APhy as value in MAC
// if((!rmDetectLtssmIntr1)&&(!gLtssmIntr1)) // It had not enter EQ3
// {
// //future to implement
// //if(!gsLightSwitch.usPhyLs.Dm0_Manual)
// //{
// //    chkDm(cAddrDm0, cSmbDm0);
// //}
// //if(!gsLightSwitch.usPhyLs.Dm2_Manual)
// //{
// //    chkDm(cAddrDm2, cSmbDm2);
// //}
// crRead(cAddrDphyLane0|0xFF);
// }
// else
// {
// rmClrLtssmIntr1;
// gLtssmIntr1=0;
// }
// }

// void initDphyPatch()
// {
//    // g32PowerOnDphy7Cnt=0;
//    gLpbkSt=0;
//    // gDPHY_Init_flag=0;
//    // gGetEMU_flag=0;
//
//    // gLTSM_PREDET_flag=0;
//    gLtssmIntr0=gLtssmIntr1=gLtssmIntr2=0;
// }

#if (_DPHY_18)
void setDphyKi()
{
    WORD u16DphyAddr;
    BYTE uLane;

    for(uLane=0; uLane<4; uLane++)
    {
        u16DphyAddr=cAddrDphyLane0|(uLane<<8);
        crWrite((u16DphyAddr|cAddrDphyParityBit), cDatSetDphyParityBit);    // enable write priority
        crWrite((u16DphyAddr|cAddrGen3KiIni), 0x0008);
        crWrite((u16DphyAddr|cAddrGen2KiIni), 0x000A);
        crWrite((u16DphyAddr|cAddrGen1KiIni), 0x0014);
        crWrite((u16DphyAddr|cAddrDphyParityBit), cDatClrDphyParityBit);    // enable write priority
    }
}

#if 0    // for Code size
void setAPhyKp(BYTE uMode)
{
    WORD u16APhyAddr;
    BYTE uLane;
    BYTE uKpValue;

    if(uMode==cKpLoopback)
    {
        uKpValue=gsLightSwitch.usPhyLs.uKpG3LoopBack;
    }
    else
    {
        uKpValue=gsLightSwitch.usPhyLs.uKp;
    }

    rmClrCtrl;

    if(gsLightSwitch.usPhyLs.uAPhyManual&cKPmanual)
    {
        for(uLane=0; uLane<4; uLane++)
        {
            u16APhyAddr=cAddrAphyLane0|(uLane<<8);
            aPhyWrite((u16APhyAddr|cAddrKp), cSmbKp, uKpValue);
        }

        for(uLane=0; uLane<4; uLane++)
        {
            u16APhyAddr=cAddrAphyLane0|(uLane<<8);
            aPhyReadBack((u16APhyAddr|cAddrKp), cSmbKp, uKpValue);
        }

        crRead(cAddrDphyLane0|0xFF);    // freeze all setting
    }
}    /* setAPhyKp */

#endif/* if 0 */

#if (_DPHY_18_1)

void initAPhyLP()
{
    rmClrCtrl;

    // auto EQ inprogress Process
    crWrite(0x3CFF, 0x0001);    // enable write priority
    crWrite(0x3DFF, 0x0001);    // enable write priority
    crWrite(0x3EFF, 0x0001);    // enable write priority
    crWrite(0x3FFF, 0x0001);    // enable write priority

    sysDelay(26000000);

    crWrite(0x3CF5, 0x0001);    // i2c_eqinprogress
    crWrite(0x3DF5, 0x0001);    // i2c_eqinprogress
    crWrite(0x3EF5, 0x0001);    // i2c_eqinprogress
    crWrite(0x3FF5, 0x0001);    // i2c_eqinprogress

    sysDelay(2600000);

    crWrite(0x3CF5, 0x0000);
    crWrite(0x3DF5, 0x0000);
    crWrite(0x3EF5, 0x0000);
    crWrite(0x3FF5, 0x0000);

    crWrite(0x3CFF, 0x0000);    // disable write priority
    crWrite(0x3DFF, 0x0000);    // disable write priority
    crWrite(0x3EFF, 0x0000);    // disable write priority
    crWrite(0x3FFF, 0x0000);    // disable write priority
}    /* initAPhyLP */

#endif/* if (_DPHY_18_1) */

#endif/* if (_DPHY_18) */

#if 0    // for Code size
void forceDm2(WORD u16LaneNum)
{
    WORD u16APhyAddr=(cAddrAphyLane0|(u16LaneNum<<8));    // CSSD-2606 (2)

    aPhyWrite((u16APhyAddr|cAddrDm2), cSmbDm2, 0x0014);
}

#endif

#if 0    // for Code size
void disableLane(WORD u16LaneNum)
{
    WORD u16APhyAddr=(cAddrAphyLane0|(u16LaneNum<<8));
    WORD u16CrData;
    BYTE uChkCount;
    BYTE uKeepLane=0;

    for(uChkCount=0; uChkCount<10; uChkCount++)    // CSSD -2606
    {
        u16CrData=((crRead((u16APhyAddr|cAddrIsa)))&0x04);

        if(u16CrData==0)
        {
            uKeepLane=1;
        }
    }

    if(uKeepLane==0)
    {
        aPhyChkWrite((u16APhyAddr|cAddrTxpd), cSmbTxpd, cDatSetTxpd);
        aPhyChkWrite((u16APhyAddr|cAddrRxpd), cSmbRxpd, cDatSetRxpd);

        if(u16LaneNum!=0)
        {
            aPhyChkWrite((u16APhyAddr|cAddrTbcOff), cSmbTbcOff, cDatSetTbcOff);
        }
    }
}    /* disableLane */

#endif/* if 0 */

// void disableUnuseLane()
// {
//    WORD u16LaneSel;
//
//    // Step 1 : force all DM2 of all lane to 0x14
//    for(u16LaneSel=0; u16LaneSel<4; u16LaneSel++)    // (Sam) remove to pass Pcie plugfest
//    {
//        forceDm2(u16LaneSel);
//    }
//
//    // Step 2 :
//    for(u16LaneSel=0; u16LaneSel<4; u16LaneSel++)
//    {
//        disableLane(u16LaneSel);
//    }
// }

LWORD chkLtrValue(LWORD u32TargetLtr, LWORD u32MaxLtr)
{
    QWORD cb64ScaleTab[]=
    {
        1, 32, 1024, 32768, 1048576, 33554432
        // 000 ??Value times 1 ns
        // 001 ??Value times 32 ns
        // 010 ??Value times 1,024 ns
        // 011 ??Value times 32,768 ns
        // 100 ??Value times 1,048,576 ns
        // 101 ??Value times 33,554,432 ns
    };

    // b9:0   = value
    // b12:10 = scale
    // b15:   = enable
    LWORD u32Rlt=u32TargetLtr;

    LWORD u32Value=u32TargetLtr&0x3FF;
    BYTE uScale=(u32TargetLtr>>10)&0x7;

    LWORD u32MaxValue=u32MaxLtr&0x3FF;
    BYTE uMaxScale=(u32MaxLtr>>10)&0x07;

    if(uMaxScale<6)
    {
        if((QWORD)u32Value*cb64ScaleTab[uScale]>(QWORD)u32MaxValue*cb64ScaleTab[uMaxScale])
        {
            u32Rlt=u32MaxLtr;
        }
    }

    return u32Rlt;    // SPF031K
}    /* chkLtrValue */

void srvLtrSend(BYTE uSendLtrState)
{
#if (_PCIE_D3HOT_D0_LTR_WORKAROUND)
    LWORD u32LtrVaule;

    if((!(rmGetLtrMaxSnoopLatency&0x7FF))||(!(rmGetLtrMaxNoSnoopLatency&0x7FF)))    // (A) if latency is zero, don't send LTR (Swapna)
    {
        return;
    }

    if(!uSendLtrState)    // (A) check max latency everytime (Swapna)
    {
        // (A)        if(!g32LTRValue0)
        {
            // lower 16 bit is Snoop
            g32LtrValue0=chkLtrValue((rmPcieLtr0Value&0x1FFF), rmGetLtrMaxSnoopLatency);
            // high 16 bit is NoSnoop
            g32LtrValue0|=chkLtrValue(((rmPcieLtr0Value>>16)&0x1FFF), rmGetLtrMaxNoSnoopLatency)<<16;
            g32LtrValue0|=0x80008000;    // enable
        }
        u32LtrVaule=g32LtrValue0;
    }
    else
    {
// (A)        if(!g32LTRValue2)
        {
            // lower 16 bit is Snoop
            g32LtrValue2=chkLtrValue((rmPcieLtr2Value&0x1FFF), rmGetLtrMaxSnoopLatency);
            // high 16 bit is NoSnoop
            g32LtrValue2|=chkLtrValue(((rmPcieLtr2Value>>16)&0x1FFF), rmGetLtrMaxNoSnoopLatency)<<16;
            g32LtrValue2|=0x80008000;    // enable
        }
        u32LtrVaule=g32LtrValue2;
    }

    rmSetPcieVenMsgCtrl1(0x00000010);    // Sync HHF023K
    rmSetPcieVenMsgCtrl2(u32LtrVaule);
    rmReqPcieVenMsg;
#endif/* if 0 */
}    /* srvLtrSend */

BYTE chkDphyPatch()
{
    BYTE uPatchActive=0;

#if (_DPHY_18)
    if(rmDetectLtssmLPbkAct)
    {
        waitPclkRdy();

        if(rmDetectLtssmLPbkAct&&(gLpbkSt==0)&&(rmCheckCurrentSpeed==0x0003))
        {
            // setAPhyKp(cKpLoopback);  //remove, 2263  // force_aphy_kp_LPBK();
            setDphyKi();
            gLpbkSt=1;
            // Only for JBERTB, manually cal Eqc Eqr Tap123 Offd
#if (_DPHY_18_1)
            initAPhyLP();
#endif
        }

        uPatchActive=1;
    }
    else if((!rmDetectLtssmLPbkAct)&&(gLpbkSt==1))
    {
        // setAPhyKp(cKpNormal);  //remove , 2263  // release_aphy_kp();
        gLpbkSt=0;
        uPatchActive=1;
    }
#endif/* if (_DPHY_18) */

    return uPatchActive;
}    /* chkDphyPatch */

#if _2260PCIE_WORKAROUND
void gen3ConfigPatch()
{
    if(rmChkLtssmTraceIntr0)
    {
        WORD u16WaitCnt;
        BYTE uBreakWaitCnt=0;

        // rmSetAuxToPcieDebug;

        for(u16WaitCnt=0; u16WaitCnt<1024; u16WaitCnt++)
        {
            if(rmChkLinkCurState!=0x07)
            {
                if(uBreakWaitCnt==64)
                {
                    break;
                }
                else
                {
                    uBreakWaitCnt++;
                }
            }

            rmSetFwDebugSelect;    // for SM2263 only

            if(((rmChkRcvdTs2!=0x02)||(rmChkLinkCurState==0x07))&&(u16WaitCnt==1023))
            {
                rmSetPortFroceLinkLtssm(0x09);
                rmSetForceEn;
                rmSetPortFroceLinkLtssm(0x11);
                rmSetForceEn;
            }

            rmClrFwDebugSelect;    // for SM2263 only
        }

        rmClrLtssmTraceIntr0;
    }
}    /* gen3ConfigPatch */

#endif/* if _2260PCIE_WORKAROUND */

#if (_2260PCIE_WORKAROUND)
BYTE setExtSync(BYTE uEnable)
{
    BYTE uEnableL12=disableL12();    // Disable L1.2 first to avoid no PClk cause time out
    BYTE uHostSetExtSync=0;

    if(rmChkPclkReady)
    {
        if(uEnable)
        {
            if(!rmChkExtSync)
            {
                rmSetExtSync;
            }
            else
            {
                uHostSetExtSync=1;
            }
        }
        else
        {
            rmClrExtSync;
        }
    }

    if(uEnableL12)
    {
        enableL12();
    }

    return uHostSetExtSync;
}    /* setExtSync */

#endif/* if (_2260PCIE_WORKAROUND) */

#if (_EN_PCIE_DEBUG)
WORD chkDphyError(BYTE uLaneNum)
{
    WORD u16DphyAddr=0x3C00;
    WORD u16CrData;

    u16DphyAddr=0x3C00|(uLaneNum<<8);
    crWrite((u16DphyAddr|cAddrDphyParityBit), cDatSetDphyParityBit);
    u16CrData=((crRead(u16DphyAddr|0x0B)&(0xFE))|0x00);
    crWrite((u16DphyAddr|0x0B), u16CrData);
    u16CrData=((crRead(u16DphyAddr|0x0B)&(0xFE))|0x01);
    crWrite((u16DphyAddr|0x0B), u16CrData);
    // Read Error
    u16CrData=crRead(u16DphyAddr|0x08);
    crWrite((u16DphyAddr|cAddrDphyParityBit), cDatClrDphyParityBit);

    return u16CrData;
}

WORD chkPhyError(BYTE uLaneNum)
{
    WORD u16DphyAddr=0x3C00;
    WORD u16CrData;

    u16DphyAddr=0x3C00|(uLaneNum<<8);
    crWrite((u16DphyAddr|cAddrDphyParityBit), cDatSetDphyParityBit);
    u16CrData=crRead(u16DphyAddr|0x36);
    crWrite((u16DphyAddr|cAddrDphyParityBit), cDatClrDphyParityBit);

    return u16CrData;
}

void setPhyError(BYTE uLaneNum)
{
    WORD u16DphyAddr=0x3C00;

    u16DphyAddr=0x3C00|(uLaneNum<<8);
    crWrite((u16DphyAddr|cAddrDphyParityBit), cDatSetDphyParityBit);
    crWrite((u16DphyAddr|0x22), 0x20);
    crWrite((u16DphyAddr|0x23), 0x1B);
    crWrite((u16DphyAddr|0x26), 0x04);
    crWrite((u16DphyAddr|0xA6), 0xFF);
    crWrite((u16DphyAddr|cAddrDphyParityBit), cDatClrDphyParityBit);
}

#endif/* if (_EN_PCIE_DEBUG) */

#if (!_ICE_LOAD_ALL)
#pragma default_function_attributes =
#endif







