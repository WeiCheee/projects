







/*
   ****************************************************
   *      Interrupt Service Routine
   ****************************************************
   */

#include "inc/Option.h"
#include "inc/NvmeCtrl.h"
#include "inc/ProType.h"
#include "inc/GlobVarS.h"
#include "inc/Reg.h"

#if (!_ICE_LOAD_ALL)
#pragma default_function_attributes = @ ".ISR"
#endif

// SVC exception handler is implemented here
__irq __arm void SVCHandler()
{
    while(1)
        ;// not implemented
}

// IRQ handler is implemented here, this handler will be instead by asm handler in the future
__irq __arm void IRQHandler()
{
    while(1)
        ;// not implemented
}

// FIQ exception handler is implemented here, this handler will be instead by asm handler in the future
__irq __arm void FIQHandler()
{
    while(1)
        ;// not implemented
}

// Undefined instruction exception handler is implemented here
__irq __arm void UndefinedHandler()
{
    while(1)
        ;// not implemented
}

// Abort exception handler is implemented here
__irq __arm void AbortHandler()
{
    if(__MRC(15, 0, 6, 0, 0)!=(LWORD)(&gsOccuMutexInfo.u32Lock))
    {
        while(1)
            ;
    }
    else
    {
        gsOccuMutexInfo.u32Lock=0;
        g16DebugDoubleLockCnt++;
    }

// not implemented
}

// Prefetch exception handler is implemented here
__irq __arm void PrefetchHandler()
{
    asm ("MRC p15, 0, r1, c5, c0, 1 ");    // Read IFSR
    asm ("MOV r1, #0");
    asm ("MCR p15, 0, r1, c5, c0, 1 ");    // Read IFSR
    asm ("MRC p15, 0, r1, c5, c0, 1 ");    // Read IFSR
    asm ("SUB PC, LR, #0");
}

void resumePS3()
{}

__irq __arm void isrClkReqLatQ(void)
{
    rmVic1IrqClr;
}

__irq __arm void isrPwFail18(void)
{
    rmVic1IrqClr;
}

__irq __arm void isrPwFail23(void)
{
    while(!rmChkVdt23Fsh1Good)
        ;

    rmVic1IrqClr;
}

__irq __arm void isrWdtIntPwFail27(void)
{
    rmVic1IrqClr;
}

__irq __arm void isrPwFail40IntPwFail10(void)
{
    rmVic1IrqClr;
}

__irq __arm void isrPwFailEx(void)
{
    rmVic1IrqClr;
}

__irq __arm void isrPwFailPor1(void)
{
    rmVic1IrqClr;
}

__irq __arm void isrThsorValue(void)
{
    rmVic1IrqClr;
}

__irq __arm void isrJtag(void)
{
    rmVic1IrqClr;
}

__irq __arm void isrGpioAll(void)    // P1.0
{
    rmVic1IrqClr;
}

__irq __arm void isrFshIoPwFail(void)    // /P1.1
{
    while(!rmChkVdt12FioGood)
        ;

    rmVic1IrqClr;
}

__irq __arm void isrAllTimer(void)
{
    rmVic1IrqClr;
}

__irq __arm void isrI2cSlave(void)
{
    rmVic1IrqClr;
}

__irq __arm void isrI2cMaster(void)
{
    rmVic1IrqClr;
}

__irq __arm void isrUart(void)
{
    rmVic1IrqClr;
}

__irq __arm void isrRng(void)
{
    rmVic1IrqClr;
}

__irq __arm void isrPcieAppIrq0(void)
{
    rmVic1IrqClr;
}

__irq __arm void isrPcieAppIrq1(void)    // NVMP DPS related ISR
{
    rmVic1IrqClr;
}

__irq __arm void isrPcieAppIrq2(void)    // Nvme related ISR, 18
{
    rmVic1IrqClr;
}

__irq __arm void isrPcieAppIrq3(void)
{
    rmVic1IrqClr;
}

__irq __arm void isrPcieIrq0(void)    // PCIE related ISR, 20
{
    rmVic1IrqClr;
}

__irq __arm void isrPcieIrq1(void)
{
    rmVic1IrqClr;
}

__irq __arm void isrPcieIrq2(void)
{
    rmVic1IrqClr;
}

__irq __arm void isrPcieIrq3(void)
{
    rmVic1IrqClr;
}

__irq __arm void isrSetBvb2CfgTmoFlag(void)
{
    rmVic1IrqClr;
}

__irq __arm void isrRsa(void)
{
    rmVic1IrqClr;
}

__irq __arm void isrFakeFailStop(void)    // Dram Ecc fail, fake engine fail
{
    rmVic1IrqClr;
}

__irq __arm void isrCmdFifoFull(void)
{
    rmVic1IrqClr;
}

__irq __arm void isrFlash(void)
{
    rmVic1IrqClr;
}

__irq __arm void isrHdaDone(void)
{
    rmVic1IrqClr;
}

__irq __arm void isrBopDone(void)
{
    rmVic1IrqClr;
}

__irq __arm void isrVIC31(void)
{
#if (_EN_WDT)
    if(mChkWdtRstFlash)
    {
        tempSetFlashCmd();
        initNandCtrlReg();

        setFlashClock(100);
        setSelMulFL(1);
        rmEnAleCleDoubleCycle;
        rmEnACle2Cycle;
        setSelMulFL(0);
        initNandBusAndAleReg();
        initNandFlash();
        initBufWrap();
        rmResetBufFlg;
        rmResetOccupyFlg;
        rmResetRaidFlg;
        mClrWdtRstFlash;

        while(!mChkWdtSaveLog)
            ;

        gEnableLdpcPipe=0;

        if(gsFtlDbg.u16DummyFailType)
        {
            gsCacheInfo.ubEnDualCoreFlush=cFalse;
            gPowerDownMode=cGSD;
            progWproPage(cWproQBWithDumyW, c16Tsb0SIdx);
        }
        else
        {
            progWproPage(cWproEventLog, c16Tsb0SIdx);
        }

        saveWdtDebugInfo(gSectorPerPlaneH);
        mClrWdtSaveLog;

        while(1)
            ;
    }
#endif/* if (_EN_WDT) */

#if _EN_PCIE_ERR_HANG
    while(mChkHandlePcieErrF)
        ;
#endif

    rmVic1IrqClr;
}    /* isrVIC31 */

#if (!_ICE_LOAD_ALL)
#pragma default_function_attributes =
#endif







