







void nvmeWriteUncorrectable()
{
#if _EN_WUNCTable    // WUNCTable Chief_21081121
    BYTE uStartSct, uIdx, uMatch, uWuncCnt=0;
    LWORD u32WUNCSlba[2], u32WUNCNlb[2], u32WuncElba, u32WuncSLaa, u32WuncELaa, u16HBlock, u16HPage;
#endif
    LWORD u32Slba, u32Nlb, u32SctrCnt, u32HSector, u32NsId=rmNvmeNsId;
    LWORD *u32pH2FTab=(LWORD *)garTsb0[0];
    WORD u16SrhHBlock, u16SrhHPage, u16H4k, u16F2hTabHitPtr, u16CommandStatus=cStatusSuccess;

#if _ENABLE_HMB_FLUSH
    BYTE uSgmtIdx;
#endif

#if _EN_VPC_SWAP    // 20190620_Louis
    LWORD u32CacheBlkVpCntStrAddr=cCacheBlkVpCntSecuritySendStrAddr;
    WORD u16VPCStartIdx=cCacheBlkVpCntSecuritySendStrIdx;

    g32arCacheBlkVpCnt=(volatile LWORD *)(u32CacheBlkVpCntStrAddr);
    readWproPageCore0(cWproCacheBlkVpCnt, u16VPCStartIdx, 0);
#endif

    if(gsLightSwitch.usNvmeLs.uOncs&cWriteUncCommand)
    {
        u32Nlb=rmNvmeWriteUncNlb;
        u32Slba=rmNvmeWriteUncSlbaLow;
        NLOG(cLogHost, NVMEIOCMDEXT_C, 3, " NVMe WUNC Cmd u32Slba=0x%08X, u32Nlb=0x%04X", u32Slba>>16, u32Slba, u32Nlb);

        // Don't need check Nlb>Mdts case because there isn't data xfer
        if((u32NsId==cNamespaceNotSpecific)||(u32NsId>gsLightSwitch.usNvme2Ls.u32NamespaceNum)||
           (!(gsNamespace.uActiveBitMap&cbBitTab[u32NsId-1])))
        {
            u16CommandStatus=(cStatusMore|cStatusInvalidNsFormat);    // WD Jira-87
        }
        else
        {
            u16CommandStatus=chkLbaRange(rmNvmeWriteUncSlbaHigh, u32Slba, u32Nlb, u32NsId, cNvmeCmdWriteUnc);
        }

        if(u16CommandStatus)
        {
            manualCompletion(u16CommandStatus, 0, cNoRwCmd, 0);
            return;
        }

#if _EN_WUNCTable    // WUNCTable Chief_21081121
        NLOG(cLogHost, NVMEIOCMDEXT_C, 0, "initWuncTableVar");

        for(uIdx=0; uIdx<C_MaxWUNCLAACnt; uIdx++)
        {
            gsWUNCInfo.uWuncCnt=0;
            gsWUNCInfo.u16HBlock[uIdx]=c16BitFF;
            gsWUNCInfo.u16HPage[uIdx]=c16BitFF;
            gsWUNCInfo.uBitMap[uIdx]=0;
        }

        u32WuncElba=u32Slba+u32Nlb-1;
        u32WuncSLaa=u32Slba>>3;
        u32WuncELaa=u32WuncElba>>3;

        u32WUNCSlba[0]=u32Slba;
        // u32Slba=(u32Slba+cSctrPer4k-1)&cSctrPer4k;
        NLOG(cLogHost,
             NVMEIOCMDEXT_C,
             2,
             " WUNC Check Start u32WUNCSlba=0x%08X", u32WUNCSlba[0]>>16, u32WUNCSlba[0]);

        if(u32WUNCSlba[0]&(cSctrPer4k-1)||(!(u32WUNCSlba[0]&cSctrPer4k-1))&&(u32Nlb<cSctrPer4k))
        {
            if(u32Nlb<=(cSctrPer4k-(u32WUNCSlba[0]&(cSctrPer4k-1))))    // ONE LAA
            {
                u32WUNCNlb[0]=u32Nlb;
            }
            else
            {
                u32WUNCNlb[0]=cSctrPer4k-u32WUNCSlba[0]&(cSctrPer4k-1);    // Over One LAA
            }

            u32Nlb-=u32WUNCNlb[0];
            uWuncCnt++;
            NLOG(cLogHost,
                 NVMEIOCMDEXT_C,
                 4,
                 " WUNC First u32WUNCSlba=0x%08X, u32WUNCNlb=0x%04X, uWuncCnt=0x%04X",
                 u32WUNCSlba[0]>>16,
                 u32WUNCSlba[0],
                 u32WUNCNlb[0],
                 uWuncCnt);
        }

        if((u32WuncElba+1)&(cSctrPer4k-1)&&(u32WuncSLaa!=u32WuncELaa))
        {
            u32WUNCSlba[1]=u32WuncELaa<<3;
            u32WUNCNlb[1]=(u32WuncElba&(cSctrPer4k-1))+1;
            u32Nlb-=u32WUNCNlb[1];
            uWuncCnt++;
            NLOG(cLogHost,
                 NVMEIOCMDEXT_C,
                 4,
                 " WUNC Second u32WUNCSlba=0x%08X, u32WUNCNlb=0x%04X, uWuncCnt=0x%04X",
                 u32WUNCSlba[1]>>16,
                 u32WUNCSlba[1],
                 u32WUNCNlb[1],
                 uWuncCnt);
        }

        while(uWuncCnt)
        {
            uWuncCnt--;
            u16HBlock=u32WUNCSlba[uWuncCnt]/g32SectorPerBlockH;
            u32HSector=u32WUNCSlba[uWuncCnt]%g32SectorPerBlockH;
            u16HPage=u32HSector>>cSctrTo4kShift;
            uMatch=cBitFF;

            for(uIdx=0; uIdx<C_MaxWUNCLAACnt; uIdx++)
            {
                if((gsWUNCInfo.u16HBlock[uIdx]==u16HBlock)&&(gsWUNCInfo.u16HPage[uIdx]==u16HPage))
                {
                    uMatch=cBit7F;
                    break;
                }
            }

            if(uMatch==cBitFF)
            {
                for(uIdx=0; uIdx<C_MaxWUNCLAACnt; uIdx++)
                {
                    if(gsWUNCInfo.u16HBlock[uIdx]==c16BitFF)
                    {
                        uMatch=uIdx;
                        break;
                    }
                }
            }

            if(uMatch==cBitFF)
            {
                break;
            }

            gsWUNCInfo.u16HBlock[uIdx]=u16HBlock;
            gsWUNCInfo.u16HPage[uIdx]=u16HPage;
            uStartSct=u32WUNCSlba[uWuncCnt]&(cSctrPer4k-1);

            for(; uStartSct<cSctrPer4k; uStartSct++)
            {
                gsWUNCInfo.uBitMap[uIdx]|=cbBitTab[uStartSct];
                u32WUNCNlb[uWuncCnt]--;

                if(!u32WUNCNlb[uWuncCnt])
                {
                    break;
                }
            }

            if(uMatch!=cBit7F)
            {
                gsWUNCInfo.uWuncCnt++;
            }

            NLOG(cLogHost, NVMEIOCMDEXT_C, 4,
                 "WUNC u16HBlock=0x%04X,u16HPage=0x%04X,uBitMap=0x%04X,uWuncCnt=0x%04X",
                 u16HBlock, u16HPage, gsWUNCInfo.uBitMap[uIdx], gsWUNCInfo.uWuncCnt);
#if _EN_WuncInNand
            if(!uWuncCnt)
            {
                bopCopyRam(((LWORD)garTsb0[0]), (LWORD)&gsWUNCInfo, sizeof(gsWUNCInfo),
                           cCopyStcm2Tsb|cBopWait);
                progWproPageCore0(cWproWriteUNC, c16Tsb0SIdx);
                mSetCacheInfoChangeFlag(cH2fChg);
            }
#endif
        }

#if _EN_WuncInNand
        if(uWuncCnt)
        {
            if(gsWproInfo.u16arWproIdxPagePtr[cWproWriteUNC]!=c16BitFF)
            {
                readWproPageCore0(cWproWriteUNC, c16Tsb0SIdx, 0);
                bopCopyRam((LWORD)&gsWUNCInfo, ((LWORD)garTsb0[0]), sizeof(gsWUNCInfo), cCopyTsb2Stcm|cBopWait);
            }

            if((gsWUNCInfo.uWuncCnt>C_MaxWUNCLAACnt)||(gsWproInfo.u16arWproIdxPagePtr[cWproWriteUNC]==c16BitFF))
            {
                for(uStartSct=0; uStartSct<C_MaxWUNCLAACnt; uStartSct++)
                {
                    NLOG(cLogHost,
                         NVMEIOCMDEXT_C,
                         4,
                         "over MaxUNCLAACnt uWuncCnt=0x%04X, HBlock=0x%04X, u16HPage=0x%04X, uBitMap=0x%04X",
                         gsWUNCInfo.uWuncCnt,
                         gsWUNCInfo.u16HBlock[uStartSct],
                         gsWUNCInfo.u16HPage[uStartSct],
                         gsWUNCInfo.uBitMap[uStartSct]);
                    gsWUNCInfo.uWuncCnt=0;
                    gsWUNCInfo.u16HBlock[uStartSct]=c16BitFF;
                    gsWUNCInfo.u16HPage[uStartSct]=c16BitFF;
                    gsWUNCInfo.uBitMap[uStartSct]=0;
                }
            }
        }
#endif/* if _EN_WuncInNand */
#endif/* if _EN_WUNCTable */
        u32Slba+=gsNamespace.usInfo[u32NsId-1].u32StartLba;

        u16SrhHBlock=div(u32Slba, g32SectorPerBlockH);
        u32HSector=u32Slba-(u16SrhHBlock*g32SectorPerBlockH);    // mod(u32LbaAddr, g32SectorPerBlockH);
        u16SrhHPage=div(u32HSector, cSctrPer4k);
        u32SctrCnt=div(u32Nlb+cSctrPer4k-1, cSctrPer4k);

#if _ENABLE_HMB_FLUSH
        for(uSgmtIdx=0; uSgmtIdx<cMaxRH2fTabNum; uSgmtIdx++)
        {
            if((u16SrhHBlock==(g32arH2f1kTabSgmt[uSgmtIdx]>>16))&&(mChkRH2fTabDirty(uSgmtIdx)))
            {
                modifyHmbByH2f1kTab(uSgmtIdx);
            }
        }
#endif

        // if(gsCacheInfo.u16ActiveH2fTab!=u16SrhHBlock)
        {
            swapH2fTable(u16SrhHBlock, c16Tsb0SIdx, cWaitReadDone);
        }

        while(u32SctrCnt)
        {
            if(u16SrhHPage>=g16PagePerH2fTab)
            {
                if(mChkCacheInfoChangeFlag(cH2fChg))
                {
                    if(mChkHmbLink(u16SrhHBlock))
                    {
                        remHmbLink(u16SrhHBlock);
                    }

                    progH2fTableCore0(c16Tsb0SIdx, u16SrhHBlock, c16Bit0|c16Bit2|c16Bit15, cInnvmeWriteUnc_00, 0);
#if (_EN_HMB)
                    if(gsHmbInfo.uHmbEnable&&(gsHmbInfo.usHmbList.u16Cnt<g16HmbMaxTableNum))
                    {
                        writeHmbH2fTab(c16Tsb0SIdx, u16SrhHBlock, 0);
                    }
#endif
                }

                u16SrhHBlock++;
                swapH2fTable(u16SrhHBlock, c16Tsb0SIdx, cWaitReadDone);
                u16SrhHPage=0;
            }

            if(mChkSrcInCache(u16SrhHBlock))
            {
                u16F2hTabHitPtr=srchSrcInF2hTab(u16SrhHBlock, u16SrhHPage);
            }
            else
            {
                u16F2hTabHitPtr=c16BitFF;
            }

            if(u16F2hTabHitPtr!=c16BitFF)
            {
                u16H4k=garCacheF2hTab[u16F2hTabHitPtr].u16HPage;

                setH2fSrcBlock((UCLWORD *)(u32pH2FTab+u16H4k), gsCacheInfo.u16SrchRslFBlock, gsCacheInfo.u32SrchRslFPage,
                               (!mChkMlcMoBit(gsCacheInfo.u16SrchRslFBlock)), cFalse);

                if(!(u32pH2FTab[u16H4k]&c32FBlockUncBit))
                {
                    u32pH2FTab[u16H4k]|=c32FBlockUncBit;
                }

                garCacheF2hTab[u16F2hTabHitPtr].u16HBlock|=c16Bit15;
                mSetCacheInfoChangeFlag(cH2fChg);
                // gsIsrCtrl.ubSrchValid=0;

                while(srchSrcInF2hTab(u16SrhHBlock, u16SrhHPage)!=c16BitFF)
                {
                    // garCacheF2hTab[g16F2hTabHitPtr].u16HBlock=c16Null;
                    // garCacheF2hTab[g16F2hTabHitPtr].u16HPage=c16Null;
                }

                if(mChkSrcInCache(u16SrhHBlock))
                {
                    // chkSrcInF2h(u16SrhHBlock);  ??
                }
            }
            else
            {
                // if((u32pH2FTab[u16SrhHPage]&c32FBlockInitValue)!=c32FBlockInitValue)
                {
                    if(!(u32pH2FTab[u16SrhHPage]&c32FBlockUncBit))
                    {
                        u32pH2FTab[u16SrhHPage]|=c32FBlockUncBit;
                    }

                    mSetCacheInfoChangeFlag(cH2fChg);
                    // progH2fTable(c16H2fTabSIdx, gsCacheInfo.u16ActiveH2fTab, c16Bit2|c16Bit15, cInnvmeWriteUnc_01);
                }
            }

            u16SrhHPage++;
            u32SctrCnt--;
        }

        if(mChkCacheInfoChangeFlag(cH2fChg))
        {
            if(mChkHmbLink(u16SrhHBlock))
            {
                remHmbLink(u16SrhHBlock);
            }

            progH2fTableCore0(c16Tsb0SIdx, u16SrhHBlock, c16Bit0|c16Bit2|c16Bit15, cInnvmeWriteUnc_01, 0);
#if (_EN_HMB)
            if(gsHmbInfo.uHmbEnable&&(gsHmbInfo.usHmbList.u16Cnt<g16HmbMaxTableNum))
            {
                writeHmbH2fTab(c16Tsb0SIdx, u16SrhHBlock, 0);
            }
#endif
        }

        if(g16arH2fTabPtr[u16SrhHBlock]!=c16H2FTabInitValue)
        {
            remRptH2f1kTabSgmt(u16SrhHBlock);
        }

        // hdmaClrRam((LWORD)g32arSkipF2hSrch, 0x0000_0800, (LWORD)0x0000_0000, cClrTsb|cHdmaNotWait);

#if _EN_VPC_SWAP    // 20190703_Louis
        progWproPageCore0(cWproCacheBlkVpCnt, u16VPCStartIdx);
#endif/* if _EN_VPC_SWAP */

        if((mChkGcQue(cGcTypH2fTab))||mChkGcFlag(cReadScrubH2F))
        {
            g32Rtc32kStartVal=getRtcCurrent32k();
            gsGcInfo.u32BgdGcEndTime=c32PartialCleanRtc20ms;
            bgdClnH2fTabblkProc();
        }

        if(g16PushSpareCnt>gsGcInfo.uPushSprbHiThr)
        {
            chkPushSpareQCore0(0);
        }

        save1stCacheInfoBefW();
        gsSmart.usStatus.uWuncEver=1;
        manualCompletion(cStatusSuccess, 0, cNoRwCmd, 0);
    }
    else
    {
        manualCompletion(cStatusInvalidOpCode, 0, cNoRwCmd, 0);
    }

    waitHmbPrdDone();
}    /* nvmeWriteUncorrectable */

void nvmeCompare()
{
    HADDRINFO usTmpHAddrInfo;
    LWORD u32TotalNlb=rmNvmeNlb, u32LbaAddr=rmNvmeLbaLow, u32NsId=rmNvmeNsId, u32Offset=0, u32PartialNlb, u32TotalSctrCnt;
    WORD u16BufPtr, u16CommandStatus=cStatusSuccess;
    BYTE uReadSctrCnt, uHwPrdIdx=cBitFF, uCmpErr=0, uOriginStartSct=0;

    NLOG(cLogHost, NVMEIOCMDEXT_C, 0, " NVMe Compare Cmd ");

    if(gsLightSwitch.usNvmeLs.uOncs&cCompareCommand)
    {
        if(chkCmdInfoError(u32TotalNlb, u32LbaAddr, u32NsId))
        {
            return;
        }

        bopClrRam((c32Tsb0SAddr), 0x40000, 0x00000000, cBopWait|cClrTsb);
        g64TotalHostRdSecCnt+=u32TotalNlb;
        u32LbaAddr+=gsNamespace.usInfo[u32NsId-1].u32StartLba;
        gsE2eInfo.u32GenerateLba=u32LbaAddr;

        while(u32TotalNlb)
        {
            tranLba2HAddr(u32LbaAddr, &usTmpHAddrInfo);
            uOriginStartSct=gStartSector;

            // Compare 128k once a time
            if((u32TotalNlb+gStartSector)<=0x100)
            {
                u32PartialNlb=u32TotalNlb;
                u32TotalNlb=0;
            }
            else
            {
                u32PartialNlb=0x100-gStartSector;
                u32TotalNlb=u32TotalNlb-(0x100-gStartSector);
            }

            u32TotalSctrCnt=u32PartialNlb;

            if(uHwPrdIdx==cBitFF)    // first times
            {
                if(u32TotalNlb)    // NLB larger than 128K (including start sector)
                {
                    uHwPrdIdx=trigNonRWCmd(cTsb0StartBufIdx+gStartSector, u32PartialNlb, cTsb0, cNvmeWrite, cManualCq|cMultiPrd);
                }
                else
                {
                    uHwPrdIdx=trigNonRWCmd(cTsb0StartBufIdx+gStartSector, rmNvmeNlb, cTsb0, cNvmeWrite, cManualCq);
                }
            }
            else    // after first times
            {
                if(!u32TotalNlb)
                {
                    r32NvmePrd[uHwPrdIdx][0]|=cLastPrd;
                }

                r32NvmePrd[uHwPrdIdx][1]=cTsb0StartBufIdx;    // TSB Address
                r32NvmePrd[uHwPrdIdx][5]=u32PartialNlb;
                rmClrDpp(rmCurrentEngine);    // Once clear Dpp will trig next data xfer
                rmPopNextValue;
                waitHostDone();
                setBufStatus(cTsb0StartBufIdx, u32PartialNlb, cTsb0);    // Clr TSB buf flag
            }

            if(gSecurityOption&cEnE2e)
            {
                genInternalDataCrc(uOriginStartSct, u32PartialNlb, u32LbaAddr, cE2eUserData);
            }

            if(gbEnAes)
            {
                // Can't move onto bopCopyRam, setting of crypto lib will be clean.
                rmFwAesMode;
                rmBopAutoAesXts;
                rmBopAutoAesLba(gsE2eInfo.u32GenerateLba);
                rmBopAutoAesExtLba(0);
                rmBopAutoAesEnc;

                bopCopyRam(cTsb0Addr+gStartSector*cSectorSize,
                           cTsb0Addr+gStartSector*cSectorSize,
                           u32PartialNlb*0x200,
                           cCopyTsb2Tsb|cBopWait);
                rmBopDisAutoAes;
            }

            while(u32TotalSctrCnt)
            {
                if(g16HPage>=g16PagePerH2fTab)
                {
                    g16HBlock++;
                    g16HPage=0;
                }

                // usTmpAddrInfo.u16BufPtr=(0x100+div(u32Offset, cSectorSize));
                u16BufPtr=(0x100+div(u32Offset, cSectorSize))+gStartSector;
                uReadSctrCnt=getReadSctrCnt(u32TotalSctrCnt);

                gsCacheInfo.u16SrchRslFBlock=c16FBlockInitValue;
                gsCacheInfo.u32SrchRslFPage=c32BitFF;
                findReadSrc(g16HBlock, g16HPage, 0);

                if(gsCacheInfo.u16SrchRslFBlock==c16FBlockInitValue)
                {
                    hdmaClrRam((LWORD)(cTsb0Addr+0x20000+u32Offset+gStartSector*cSectorSize), ((cSctrPer4k-gStartSector)*cSectorSize),
                               gsNamespace.u32DummyPatt, cClrTsb|cHdmaWait|cHdmaEnCrc|cHdmaGenCrc);
                }
                else
                {
                    readRequrementData(u16BufPtr, uReadSctrCnt);
                }

                g16HPage++;
                u32TotalSctrCnt-=uReadSctrCnt;
                gsE2eInfo.u32GenerateLba+=uReadSctrCnt;
                gStartSector=0;
                u32Offset+=(cSctrPer4k*cSectorSize);
            }

            if(gSecurityOption&cEnE2e)
            {
                // bopCopyRam((LWORD)&gCrcDataBuffer[0], (LWORD)c32TsbCrcAddr+0x800+(uOriginStartSct<<3), u32PartialNlb<<3,
                // cCopyTsb2Tsb|cBopWait);
                // genInternalDataCrc(0x100+uOriginStartSct, u32PartialNlb, u32LbaAddr, cE2eUserData);
            }

            if(!bopDmaComp(c32Tsb0SAddr+uOriginStartSct*cSectorSize, (c32Tsb0SAddr+0x20000+uOriginStartSct*cSectorSize),
                           (u32PartialNlb*cSectorSize), cCopyTsb2Tsb|cBopWait))
            {
                uCmpErr=1;
                // 20190211_SamKe
                NLOG(cLogHost,
                     NVMEIOCMDEXT_C,
                     3,
                     " NVMe compare Cmd, error uOriginStartSct=0x%02X, u32PartialNlb=0x%08X",
                     uOriginStartSct,
                     u32PartialNlb>>16,
                     u32PartialNlb);
                LWORD u32compareloop, u32comparefialcnt;

                for(u32compareloop=0; u32compareloop<(u32PartialNlb*cSectorSize); u32compareloop++)
                {
                    if(*(LWORD *)(c32Tsb0SAddr+uOriginStartSct*cSectorSize+u32compareloop)!=
                       *(LWORD *)(c32Tsb0SAddr+0x20000+uOriginStartSct*cSectorSize+u32compareloop))
                    {
                        u32comparefialcnt++;
                    }
                }

                NLOG(cLogHost, NVMEIOCMDEXT_C, 2, " NVMe compare Cmd,  u32comparefialcnt=0x%08X", u32comparefialcnt>>16, u32comparefialcnt);
                // 20190211_SamKe

                // while(uSTOP);
                // break;
            }

#if (_GREYBOX)
            if((gsGbInfo.uGreyBoxItem==cErrHdlE2EHostData)&&(gsGbInfo.uGreyBoxOpt==cVOpE2EBopReadChkErr))
            {
                (*(WORD *)(c32TsbCrcAddr+0x800+(uOriginStartSct*8)))+=1;
            }
#endif

            if((gSecurityOption&cEnE2e)&&!uCmpErr)
            {
                LWORD u32offset;

                // CRC unit is 8 byte for one sector. Bit15 in CRC is for bypass AES, here need to pass it.
                for(u32offset=uOriginStartSct*8; u32offset<((uOriginStartSct+u32PartialNlb)*8); u32offset+=8)
                // for(u32offset=gStartSector*8; u32offset<((gStartSector+u32PartialNlb)*8); u32offset+=8)
                {
                    // if(((*(WORD *)((LWORD)&gCrcDataBuffer[0]+u32offset))&0x7FFF)!=((*(WORD *)(c32TsbCrcAddr+0x800+u32offset))&0x7FFF))
                    if(((*(WORD *)(c32TsbCrcAddr+u32offset))&0x7FFF)!=((*(WORD *)(c32TsbCrcAddr+0x800+u32offset))&0x7FFF))
                    {
                        uCmpErr=1;
                    }
                }
            }

            u32LbaAddr+=u32PartialNlb;
            u32Offset=0;
        }

        if(uCmpErr)
        {
            u16CommandStatus=cStatusCompareFailure;
        }

        chkReleaseFreeHwPrd();

        g64HostRdCmdCnt++;

        manualCompletion(u16CommandStatus, 0, cNoRwCmd, 0);
    }
    else
    {
        manualCompletion(cStatusInvalidOpCode, 0, cNoRwCmd, 0);
    }
}    /* nvmeCompare */

void readRequrementData(WORD u16BufPtr, BYTE uReadSctrCnt)
{
    WORD u16NowNodeIdx;

    u16NowNodeIdx=gsRwCtrl.uarFreeSrcQue[gsRwCtrl.u32FreeSrcFifoHead];
    gpFlashAddrInfo=&garSrcAddrInfo[u16NowNodeIdx];

    g16FBlock=gsCacheInfo.u16SrchRslFBlock;
    g32FPageNoTran=gsCacheInfo.u32SrchRslFPage;
    tranAddrInfo(gpFlashAddrInfo);

    gSectorH=mTranSctr4kAddr(g32FPageNoTran)+gStartSector;
    mSetFRwParam(u16BufPtr, uReadSctrCnt, c16Bit4|c16Bit5|c16Bit10|c16Bit11, cReadData);

    gpFlashAddrInfo->uPrdPtr=0xE0;
    gpFlashAddrInfo->uTsb4kIdx=0xFF;
    gpFlashAddrInfo->uSrcIdx=u16NowNodeIdx;

    gsRwCtrl.u32FreeSrcFifoHead=(gsRwCtrl.u32FreeSrcFifoHead+1)&(cReadFifoDpt-1);

    while(gsRwCtrl.u32FreeSrcFifoTail!=gsRwCtrl.u32FreeSrcFifoHead)
        ;
}    /* readCompareData */

void remRptH2f1kTabSgmt(WORD u16Hblock)
{
    BYTE uIdx;

    // for(uIdx=0; uIdx<gsCacheInfo.uH2f1kTabCnt; uIdx++)
    for(uIdx=0; uIdx<cMaxRH2fTabNum; uIdx++)
    {
        // if(garH2f1kTabSgmt[garH2f1kTabSgmtIdx[uIdx]].u16HBlock==u16Hblock)
        if((g32arH2f1kTabSgmt[uIdx]>>16)==u16Hblock)
        {
            // remH2f1kTabSgmt(uIdx);
            g32arH2f1kTabSgmt[uIdx]=0xFFFFFFFF;
            rmSetSrchTgt(uIdx, 0xFFFFFFFF);
            // uIdx--;
            gsCacheInfo.uH2f1kSgmtFreePtr=uIdx;
            gsCacheInfo.uH2f1kTabCnt--;
        }
    }
}    /* remRptH2f1kTabSgmt */







