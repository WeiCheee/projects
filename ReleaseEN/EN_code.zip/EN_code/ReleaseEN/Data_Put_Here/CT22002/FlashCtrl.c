







#include "inc/TypeDef.h"
#include "inc/Const.h"
#include "inc/table.h"
#include "inc/GlobVarS.h"
#include "inc/ProType.h"
#include "inc/GlobVar1.h"
#include "inc/Reg.h"
#include "inc/BitDef.h"
#include "inc/GlobVarT.h"
#include "inc/Mac.h"

#if (!_ICE_LOAD_ALL)
#pragma default_function_attributes = @ ".FTL_CTRL"
#endif

#if 0
// >>> merge 58xt IM3D
void tranAddrInfoToAllCh(ADDRINFO *upAddrInfo)
{
    WORD u16Rem;

    u16Rem=upAddrInfo->u16FPage%(gIntlvWay*gPlaneNum);
    upAddrInfo->u16FPage=upAddrInfo->u16FPage/(gIntlvWay*gPlaneNum);
    upAddrInfo->uIntlvAddr=u16Rem/gPlaneNum;
    upAddrInfo->uPlaneAddr=u16Rem%gPlaneNum;
    upAddrInfo->uDieAddr=mGetDieAddr(upAddrInfo->uIntlvAddr);
    // upAddrInfo->ubRsvBlkSeed=0;
}

#endif

#if 0    // move to FlashPub.c
WORD tranRsvBlkAddr(BYTE uSysBlkAddr, ADDRINFO *usTmpAddrInfo)
{
#if 0
    WORD u16Rem;

    usTmpAddrInfo->u16FBlock=div(uSysBlkAddr, gTotalIntlvChNum*gPlaneNum);
    u16Rem=uSysBlkAddr%(gTotalIntlvChNum*gPlaneNum);
    usTmpAddrInfo->uPlaneAddr=div(u16Rem, gTotalIntlvChNum)    /* *gLogiPlaneNum*/;
    u16Rem=u16Rem%gTotalIntlvChNum;
    usTmpAddrInfo->uIntlvAddr=div(u16Rem, gTotalChNum);
    usTmpAddrInfo->uCh=u16Rem%gTotalChNum;
    usTmpAddrInfo->uDieAddr=mGetDieAddr(usTmpAddrInfo->uIntlvAddr);

    mClrMlcMoBit(usTmpAddrInfo->u16FBlock);
    // usTmpAddrInfo->ubLsbOnly=1;
    return usTmpAddrInfo->u16FBlock;
#else
    WORD u16Rem;

    usTmpAddrInfo->u16FBlock=uSysBlkAddr/(gTotalIntlvChNum*gPlaneNum);
    u16Rem=uSysBlkAddr%(gTotalIntlvChNum*gPlaneNum);
    usTmpAddrInfo->uPlaneAddr=u16Rem/gTotalIntlvChNum;
    u16Rem=u16Rem%gTotalIntlvChNum;
    usTmpAddrInfo->uIntlvAddr=u16Rem/gTotalChNum;
    usTmpAddrInfo->uCh=u16Rem%gTotalChNum;
    usTmpAddrInfo->uDieAddr=mGetDieAddr(usTmpAddrInfo->uIntlvAddr);
    usTmpAddrInfo->uCe=(BYTE)(usTmpAddrInfo->uIntlvAddr&g32CeAddrBitMask);
    mClrMlcMoBit(usTmpAddrInfo->u16FBlock);
    // usTmpAddrInfo->ubLsbOnly=1;
    return usTmpAddrInfo->u16FBlock;
#endif/* if 0 */
}    /* tranRsvBlkAddr */

#endif/* if 0 */

#if 0    // move to flashPub.c
void getSprByte(BLKSPRINFO *upBlkSprInfo, BYTE uPlane)
{
    BYTE uSprOfst;
    WORD *u16pSprPtr;
    BYTE uLoop;

    uSprOfst=div(rcP0SprSeed+(uPlane*cSprGrpOffset), 2);

    u16pSprPtr=&(upBlkSprInfo->u16Seed);

    for(uLoop=0; uLoop<(cExtSprByteNum/2); uLoop++)
    {
        *u16pSprPtr=r16FLCtrl[uSprOfst+uLoop];
        u16pSprPtr++;
    }
}

// <<< merge 58xt IM3D

void setFLActCh(BYTE uChNum)
{
    gActiveCh=uChNum;

    uChNum=garChMapTable[uChNum];
    rFLCtrl=(void *)regFSHA[uChNum];
    r16FLCtrl=(void *)reg16FSHA[uChNum];
    r32FLCtrl=(void *)reg32FSHA[uChNum];
}

#endif/* if 0 */

#if 0    // move to flashPub.c
void setFLAddrActCh(BYTE uChNum, ADDRINFO *upAddrInfo)
{
    setFLActCh(uChNum);
    gpFlashAddrInfo=upAddrInfo;
}

#endif

void enEccInMax()
{
    BYTE uarLdpcEccLevel[4]=
    {
        0, 13, 3, 0
    };
    BYTE uarDataEccParityByte[8]=
    {
        248, 152, 228, 248, 0, 0, 0, 0
    };

    while(rmChkSysCmdFifoBz)
        ;

    while(rmChkLdpcReady)
        ;

    if(gSecurityOption&cEnE2e)
    {
        rmDisGlobalCrc;
        rmDisE2eCrc15;
    }

    rmSetLdpcMode(uarLdpcEccLevel[cMaxLdpcLevel]);    // Max 240+4 CRC

    while(rmChkLdpcReady)
        ;

    setSelMulFL(1);

    rmSetEccParity(uarDataEccParityByte[cMaxLdpcLevel]);

    setSelMulFL(0);
}    /* enEccInMax */

void enEccInNormal()
{
    BYTE uarLdpcEccLevel[4]=
    {
        0, 13, 3, 0
    };
    BYTE uarDataEccParityByte[8]=
    {
        248, 152, 228, 248, 0, 0, 0, 0
    };

    while(rmChkSysCmdFifoBz)
        ;

    while(rmChkLdpcReady)
        ;

    if(gSecurityOption&cEnE2e)
    {
        rmEnGlobalCrc;
        rmEnE2eCrc15;
    }

    rmSetLdpcMode(uarLdpcEccLevel[gDataECCLevel]);    // Max 240+4 CRC

    while(rmChkLdpcReady)
        ;

    // need to manual set Ecc data parity
    setSelMulFL(1);

    rmSetEccParity(uarDataEccParityByte[gDataECCLevel]);

    setSelMulFL(0);
}    /* enEccInNormal */

void resetEcc()
{
    rmResetOnesCnt;
    rFLCtrl[rcDatMaxErrCnt]=rFLCtrl[rcSpareMaxErrCnt]=0;
    rmGetLdpcEccBit=0x0000;
    rmResetEccSts;
}

void setChunkAddr(BYTE uAfterSoftRst)
{
    BYTE uarDataEccParityByte[8]=
    {
        248, 152, 228, 248, 0, 0, 0, 0
    };
    BYTE uTotalChunk, uChunkIdx;
    WORD u16Chunklen, u16ChunkAddr, u16SprAddr;

    if(!uAfterSoftRst)
    {
        setSelMulFL(1);
    }

    u16Chunklen=r16FLCtrl[rcDmaLen/2];
    uTotalChunk=gSectorPerPlaneH/(u16Chunklen>>9);

    u16Chunklen+=uarDataEccParityByte[gDataECCLevel];    // chunk lenth+parity lenth

    u16ChunkAddr=0;

    for(uChunkIdx=0; uChunkIdx<uTotalChunk; uChunkIdx++)
    {
        rmSetChunkStartAddr(uChunkIdx, u16ChunkAddr);

        if(mChkFLOption(cEnSnapRead)&&(uChunkIdx==(uTotalChunk/2-1)))
        {
            rmSetChunkPtyExtLen(uChunkIdx, g16PadCnt);
            u16ChunkAddr+=g16PadCnt;
        }
        else
        {
            rmSetChunkPtyExtLen(uChunkIdx, 0);
        }

        u16ChunkAddr+=u16Chunklen;
    }

    // Set Spare address
    u16SprAddr=u16ChunkAddr;
    rmSetSprStartAddr(u16SprAddr);

    if(!uAfterSoftRst)
    {
        setSelMulFL(0);
    }
}    /* setChunkAddr */

void setSprByte(BLKSPRINFO *upBlkSprInfo, BYTE uPlaneIndex)
{
    BYTE uSprOfst;
    WORD *u16pSprPtr;
    BYTE uLoop;

    uSprOfst=((rcP0SprSeed+(uPlaneIndex*cSprPlaneOffset))/2);
    u16pSprPtr=&(upBlkSprInfo->u16Seed);
    setFLActCh(gCh);

    for(uLoop=0; uLoop<((cSprByteNum+2)/2); uLoop++)
    {
        r16FLCtrl[uSprOfst+uLoop]=*u16pSprPtr;
        u16pSprPtr++;
    }
}

void enDataOnesCnt()
{
    WORD u16ChunkBitNum;

    u16ChunkBitNum=((rFLCtrl[rcEccPtyLen]+2048)*8);

    while(rmChkSysCmdFifoBz)
        ;

    rmEnDataOnesCnt;

    rmSetDataOnesCntTh(3*(u16ChunkBitNum/4));    // rmSetDataOnesCntTh(u16ChunkBitNum-100)
}

void disDataOnesCnt()    // SM2256 only
{
    while(rmChkSysCmdFifoBz)
        ;

    rmDisDataOnesCnt;
}

// ////////////////////////////
// uMode :
// Bit 0:Spr OnesCnt enable
// Bit 1:Data OnesCnt enable
// ////////////////////////////
void ctrlOnesCntStop(BYTE uMode)
{
    setSelMulFL(1);

    if((uMode&cBit0)&&rmChkSpare26B)
    {
        rmSetSprOnesCntTh(26);    // R0124A jiannan Suggest, fix spare byte read 0xFF issue.
    }
    else
    {
        rmDisSprOnesCnt;
    }

    if(uMode&cBit1)
    {
        enDataOnesCnt();
        rmEnOnesCntStop;
    }
    else
    {
        disDataOnesCnt();
        rmDisOnesCntStop;
    }

    setSelMulFL(0);
}    /* ctrlOnesCntStop */

void enAllChStop(BYTE uStop)
{
    if(uStop&cBit0)
    {
        enErrStop();
    }

    if(uStop&cBit1)
    {
        enEccStop();
    }

    if(uStop&cBit2)
    {
        // setSelMulFL(1);
        ctrlOnesCntStop(cBit0|cBit1);
        // setSelMulFL(0);
    }
}    /* enAllChStop */

void disAllChStop(BYTE *upStopBK)
{
    *upStopBK=0;

    if(rmChkStsFailStop)
    {
        *upStopBK|=cBit0;
    }

    if(rmChkErrStop)
    {
        *upStopBK|=cBit1;
    }

    if(rmChkDataOnesCnt)
    {
        *upStopBK|=cBit2;
    }

    disErrStop();
    disEccStop();
    // setSelMulFL(1);
    ctrlOnesCntStop(0x00);
    // setSelMulFL(0);
}    /* disAllChStop */

void enErrStop()
{
#if _EN_PROGFAILLOG
    while(rmChkSysCmdFifoBz)
        ;

    setSelMulFL(1);
    rmEnStsFailStop;
    setSelMulFL(0);
#endif
}

void disErrStop()
{
    while(rmChkSysCmdFifoBz)
        ;

    setSelMulFL(1);
    rmDisStsFailStop;
    setSelMulFL(0);
}

void enEccStop()
{
    while(rmChkSysCmdFifoBz)
        ;

    setSelMulFL(1);
    enEccStopCh();
    setSelMulFL(0);
}

void disEccStop()
{
    while(rmChkSysCmdFifoBz)
        ;

    setSelMulFL(1);
    disEccStopCh();
    setSelMulFL(0);
}

void enEccStopCh()
{
    rmEnUnCorrErrStop;    // stop at the current ecc fail  DMA
    rmEnPlaneRetry;    // not turn over buffer flag  if this chunk ecc fail
}

void disEccStopCh()
{
    rmDisErrStop;
    rmDisPlaneRetry;
}

void setSelMulFL(BYTE uMul)
{
    rmSelMulRdCh(cbBitTab[(garChMapTable[0])]);

    if(uMul!=0)
    {
        rmSelMulFlash(gChMap);
        rFLCtrl=(void *)regFSHA[8];
        r16FLCtrl=(void *)reg16FSHA[8];
        r32FLCtrl=(void *)reg32FSHA[8];
    }
    else
    {
        rmSelMulFlash(gChMap);    // (J)select channels to be operated synchronously
        setFLActCh(0);
    }
}

/*
   * void setBusSyncMode()
   * {
   *  rmSetFshReLPF(0);
   *  setSelMulFL(1);
   *  rmEnONFI2Mo;
   *  setSelMulFL(0);
   * }
   */

#if (_CPUID==1)
void setCeQueAddr()
{
    rmSetCe0SAddr(cNorQStrAddr);    // word based
    rmSetCe0EAddr(cNorQEndAddr);
    rmSetAuxSAddr(cAuxQStrAddr);
    rmSetAuxEAddr(cAuxQEndAddr);
}

void enSprEcc()
{
    switch(gSprECCLevel)
    {
        case 0:
            rmSpareLen16B;
            break;

        case 1:
            rmSpareLen26B;
            break;

        case 2:
            rmSpareLen26BS;
            break;
    }
}

void setBusEdoMode()
{
    rmSetFshReLPF(0x01);
    setSelMulFL(1);
    rmEnBusEDOMo;
    setSelMulFL(0);
    rmDdrDis;
    rmDfDdrSet(0x00);
}

void setBusDiff()
{
    rmSetFshReLPF(3);    // rmSetFshReLPF(0);
    setSelMulFL(1);
    rmEnToggleMo;
    setSelMulFL(0);
    rmDdrEn;
    rmDfDdrSet(0x02);
}

void setBusToggleMode()
{
    rmSetFshReLPF(0);
    setSelMulFL(1);
    rmEnToggleMo;
    setSelMulFL(0);
}

void setFlashDrv()
{
    BYTE uCh, uChLoop, uCtrlDrv, uDataDrv;
    LWORD u32FshCtrlDrv, u32FshDataDrv, u32CtrlOdt;
    BYTE uCtrlOdt=0x01;
    BYTE uSchmitWind=0x10;

    BYTE *upIntrfaceSetPtr=&gCh0FshODTAndDrv;

    for(uChLoop=0; uChLoop<gTotalChNum; uChLoop++)
    {
        uCtrlDrv=upIntrfaceSetPtr[uChLoop*4+0x01];
        uDataDrv=upIntrfaceSetPtr[uChLoop*4+0x02];
        uCtrlOdt=(upIntrfaceSetPtr[uChLoop*4+0x03]&0x0F);
        uSchmitWind=(upIntrfaceSetPtr[uChLoop*4+0x03]&0x30);
        u32FshCtrlDrv=(LWORD)(uCtrlDrv|uSchmitWind<<8|uCtrlDrv<<16);
        u32FshDataDrv=(LWORD)(uDataDrv|uSchmitWind<<8|uDataDrv<<16|uSchmitWind<<24);
        u32CtrlOdt=uCtrlOdt<<8|uCtrlOdt;

        uCh=garChMapTable[uChLoop];
        r32SysCtrl0[(rcCtrlIoCh0/4)+uCh*2]=u32FshCtrlDrv;
        r32SysCtrl0[(rcDataIoCh0/4)+uCh*2]=u32FshDataDrv;
        r32SysCtrl1[rcCtrlOdt/4+uCh]=u32CtrlOdt;
    }

    rmEnOdtTrAuto;
}    /* setFlashDrv */

void waitCmdFifoDpt(BYTE uCh, ADDRINFO *upTmpAddrInfo)
{
    BYTE uTempFlag=0x00;

    while(rmChkCmdFifoBz||rmChkCmdFifoStsBusy)
    {
        if(rmChkCmdFifoStsFull)
        {
            while(rmChkCmdFifoStsFull)
                ;
        }

        while(rmChkCmdFifoBz)
        {
            if(rmChkSysUNC)
            {
                chkAllChEccFail(uCh);
                setFLAddrActCh(uCh, upTmpAddrInfo);
                gActiveCe=gpFlashAddrInfo->uCe;
            }
            else if(rmChkSysStsErr)
            {
#if _EN_PROGFAILLOG
                chkAllChStatusFail(uCh);
#endif
                setFLActCh(uCh);
            }
        }

        if((rmGetOpIdxCntInFifo!=0)&&rmChkUNC)
        {
            chkEccFail(uCh);
        }
        else if(rmChkUNC)
        {
            uTempFlag|=cBit0;
            // return;
        }

#if _EN_PROGFAILLOG
        if(rmChkStatusFail)
        {
            chkStatusFail(uCh);
        }
#endif

        if(rmChkSysStsErr)
        {
            // Now bypass Erase and Program fail!!
            uTempFlag|=cBit1;
            // return;
        }

        if(mChkHandlePcieErrF)
        {
            // Now bypass PCIE interface error !!
            uTempFlag|=cBit2;
            // return;
        }

        if(uTempFlag!=0x00)
        {
            uTempFlag=0x00;
            break;
        }
    }

    while(rmChkLdpcDmaSt)
    {
        uTempFlag=rmChkLdpcDmaSt;
    }
}    /* waitCmdFifoDpt */

void setAleRegister()
{
    setSelMulFL(1);

    // set page number per die
    rmSetPageNum(gPageNumReg);
    rmSetBlockNum(gBlockNumReg);

    if(mChkFLParam(cMPlaneMo))
    {
        rmSetPlaneNum(gPlaneNumReg);

        if(mChkFLParam(cLsbPlanebit))
        {
            rmLsbPlaneBit;
        }
        else
        {
            rmMsbPlaneBit;
        }
    }

    enSprEcc();
    ctrlOnesCntStop(cBit0|cBit1);
    setSelMulFL(0);
    enEccInNormal();
    setChunkAddr(0);
}    /* setAleRegister */

void ctrlScrbBothAndEcc(BYTE uScrbMode, BYTE uEccMode)
{
    setSelMulFL(1);

    if(uEccMode==0)
    {
        rmDisEccEngine;    // rmDisEcc;//rmDisEccEngine;
        rmSetEccFailForceXfr;
    }
    else
    {
        rmEnEcc;    // rmEN_ECC;

        if(uEccMode==2)
        {
            enEccInMax();
        }
        else
        {
            enEccInNormal();
        }
    }

    setSelMulFL(0);
    setSelMulFL(1);

    if(uScrbMode==0)
    {
        rmDisScrbBoth;
        rmDisSprOnesCnt;
        rmDisDataOnesCnt;
        rmDisErrStop;
        rmSetEccFailForceXfr;
        rmSetDecModeBypass;
    }
    else
    {
        rmEnScrbBoth;

        // rmDisSpronesCnt;
        // rmDisDataOnesCnt;
        if(uScrbMode==2)
        {
            // rmDisUnCorrErrStop;
            // rmDisCorrOverStop;
            // rmDisStsFailStop;
            // rmSetEccFailForceXfr;    // rmClrEccFailForceXfr;
            rmClrEccFailForceXfr;
            // rmClrDecModeBypass;
            ctrlOnesCntStop(0x00);
        }
        else
        {
            rmEnUnCorrErrStop;    // rmDisUnCorrErrStop;
            // rmDisCorrOverStop;
            // rmDisStsFailStop;
            rmClrEccFailForceXfr;    // rmSetEccFailForceXfr;//rmClrEccFailForceXfr;
            // rmClrDecModeBypass;
            ctrlOnesCntStop(0x03);
        }
    }

    setSelMulFL(0);
}    /* ctrlScrbBothAndEcc */

#if _GREYBOX
void ctrlErrInject(BYTE uLength, BYTE uRw, BYTE uChunkBitMap, WORD u16Location, WORD u16Pattern)
{
    if(uLength!=0x00)
    {
        rmSetErrInjectPattern(u16Pattern);
        rmErrInjectRWSel(uRw);    // 0: read 1: write
        rmErrInjectChunk(uChunkBitMap);    // bit map
        rmSetMiscReg(u16Location);    // byte addr
        rmErrInjectLength(uLength);    // byte addr
        rmCmdFlashErrInjectEn;
    }
    else
    {
        rmCmdFlashErrInjectDis;
        rmCmdRwSelNormalSource;
    }

    while(rmChkCmdFifoBz)
        ;// while(mWaitSysCmdFifoBz);
}    /* ctrlErrInject */

#endif/* if _GREYBOX */

void ctrlAuxQue(BYTE uMode)    // 0:OUT 1:IN
{
    if(uMode==0x01)
    {
        while(rmChkCmdFifoBz)
            ;

        while(rmChkLdpcDmaSt)
            ;

        // Enter Read Retry
        rmDisFlashClkAutoGate;    // rmDisFLClkGate(garChMapTable[gActiveCh]);
        sysDelay(cRetryRegDelayCnt);
        rmEnReadRetry;
        rmDisCmdFifoFullInt;
        sysDelay(cRetryRegDelayCnt);
        rmEnAuxCmdQue;
        sysDelay(cRetryRegDelayCnt);
        rmClrCmdQueFull;

        while(rmChkCmdFifoBz)
            ;

        rmDisUnCorrErrStop;
        rmDisOnesCntStop;
        rmCmdQueResume;    // rmSetEccFailForceXfr;
    }
    else
    {
        // End Read Retry
        rmResetEccSts;    // rmClrEccFailForceXfr;
        rmResetOnesCnt;
        rmSetLdpcSoftMode(0);
        rmSetLdpcSoftIdx(0);
        rmSetSctrAddr(0x00);
        rmEnUnCorrErrStop;
        rmEnOnesCntStop;
        rmCmdPause;

        while(!rmChkCmdFifoPause)
            ;

        rmDisReadRetry;
        rmClrEccFailForceXfr;
        rmDisFlashClkAutoGate;    // rmEnFLClkGate(garChMapTable[gActiveCh]);
        rmDisAuxCmdQue;
        sysDelay(cRetryRegDelayCnt);
        rmClrCmdQueFull;
        rmClrCmdFifoStsFull;
        sysDelay(cRetryRegDelayCnt);
        rmClrPause;
        rmCmdQueResume;
        rmEnCmdFifoFullInt;
        sysDelay(cRetryRegDelayCnt);
    }
}    /* ctrlAuxQue */

/*
   * BYTE getChFiFoBusy(BYTE uCh)
   * {
   *  BYTE uBackUpCh=gActiveCh;
   *  BYTE uStatus;
   *
   *  setFLActCh(uCh);
   *  uStatus=rmChkCmdFifoBz;
   *  setFLActCh(uBackUpCh);
   *
   *  return uStatus;
   * }
   *
   * void setChOpIndex(BYTE uCh, BYTE value)
   * {
   *  BYTE uBackUpCh=gActiveCh;
   *
   *  setFLActCh(uCh);
   *  rmSetOpIndex(value);
   *  setFLActCh(uBackUpCh);
   * }
   *
   * BYTE getChOpIdxCntInFifo(BYTE uCh)
   * {
   *  BYTE uBackUpCh=gActiveCh;
   *  BYTE uOpIdxCntInFifo;
   *
   *  setFLActCh(uCh);
   *  uOpIdxCntInFifo=rmGetOpIdxCntInFifo;
   *  setFLActCh(uBackUpCh);
   *
   *  return uOpIdxCntInFifo;
   * }
   *
   *
   * void addChOpIndex(BYTE uCh)
   * {
   *  BYTE uBackUpCh=gActiveCh;
   *
   *  setFLActCh(uCh);
   *  rmAddOPIndex;
   *  setFLActCh(uBackUpCh);
   * }
   *
   * BYTE getChOpIndex(BYTE uCh)
   * {
   *  BYTE uBackUpCh=gActiveCh;
   *  BYTE value;
   *
   *  setFLActCh(uCh);
   *  value=rmGetOpIndex;
   *  setFLActCh(uBackUpCh);
   *
   *  return value;
   * }
   *
   * BYTE getChEccResultSts(BYTE uCh)
   * {
   *  BYTE uBackUpCh=gActiveCh;
   *  BYTE value;
   *
   *  setFLActCh(uCh);
   *  value=rmGetEccResultSts;
   *  setFLActCh(uBackUpCh);
   *
   *  return value;
   * }
   *
   * BYTE getChOpResultFlag(BYTE uCh)
   * {
   *  BYTE uBackUpCh=gActiveCh;
   *  BYTE value;
   *
   *  setFLActCh(uCh);
   *  value=rmChkStatusFail;
   *  setFLActCh(uBackUpCh);
   *
   *  return value;
   * }
   */

void chkAllChEccFail(BYTE uOriCh)
{
    BYTE uCh;

    for(uCh=0; uCh<gTotalChNum; uCh++)
    {
        if(uCh!=uOriCh)
        {
            setFLActCh(uCh);
            chkEccFail(uCh);
        }
    }
}

#if _EN_PROGFAILLOG
void chkStatusFail(BYTE uCh)
{
    if(rmChkStatusFail&&!rmChkCmdFifoBz)
    {
        chkPfFblockProc(uCh);
    }
}

void chkAllChStatusFail(BYTE uOriCh)
{
    BYTE uCh;

    for(uCh=0; uCh<gTotalChNum; uCh++)
    {
        if(uCh!=uOriCh)
        {
            setFLActCh(uCh);
            chkStatusFail(uCh);
        }
    }
}

#else/* if _EN_PROGFAILLOG */
void chkStatusFail(BYTE uCh)
{
    _nop();
}

#endif/* if _EN_PROGFAILLOG */

void enLDPCAutoGate(BYTE uAutoClkGateSet)
{
    if(uAutoClkGateSet&cBit0)
    {
        rmSysEnLdpcClkAutoGate2;
    }

    if(uAutoClkGateSet&cBit1)
    {
        // rmEnLDPCWrpClkAGate;   //2258 ck1_fsh0_ldp_g_en
        rmEnClk8Dsp;
        // rmSysDisLdpcClkAutoGate; //need check 2260&2263 ,where is ck1_fsh0_ldp_g_en ??
    }
}

void disLDPCAutoGate(BYTE *upAutoClkGateSet)
{
    if(rmSysChkLdpcClkAutoGate2)
    {
        rmSysDisLdpcClkAutoGate2;
        (*upAutoClkGateSet)|=cBit0;
    }

    if(rmChkClk8Dsp)
    {
        rmDisClk8Dsp;
        (*upAutoClkGateSet)|=cBit1;
    }
}

void enFlashAutoGate(BYTE uAutoClkGateSet)
{
    if(uAutoClkGateSet&cBit3)
    {
        rmEnFlashClkAutoGate;
    }
}

void disFlashAutoGate(BYTE *up_AutoClkGateSet)
{
    if(rmChkFlashClkAutoGate)
    {
        rmDisFlashClkAutoGate;
        (*up_AutoClkGateSet)|=cBit3;
    }
}

LWORD readDataInLdpc(BYTE ubank, LWORD u32addr, BYTE uSelectCh)
{
    LWORD u32RdData;
    BYTE uAutoClkGateSet=0;

    disLDPCAutoGate(&uAutoClkGateSet);
    disFlashAutoGate(&uAutoClkGateSet);
#if 1
    rmSetLdpcChannel(garChMapTable[gActiveCh]);
    u32RdData=r32LdpcDsp[u32addr/4];
#else
    if(!uSelectCh)
    {
        r32EccDec[rcLdpcXbusAddr/4]=u32addr;
    }
    else
    {
        r32EccDec[rcLdpcXbusAddr/4]=(u32addr|(cb32BitTab[garChMapTable[gActiveCh]]<<16));
    }

    rEccDec[rcLdpcXbusCmdBank]=ubank<<5;    // bank_addr

    while(!rmChkXbusCmdReady)
        ;

    rEccDec[rcLdpcXbusEnale]=0xf2;    // cmd {addr_b3_en, addr_b3_en, addr_b3_en, addr_b3_en, 0, 0, rd_op, wr_op}

    while(!rmChkXbusCmdReady)
        ;
    u32RdData=r32EccDec[rcLdpcXbusReadData/4];
#endif/* if 1 */
    enLDPCAutoGate(uAutoClkGateSet);
    enFlashAutoGate(uAutoClkGateSet);
    return u32RdData;
}    /* readDataInLdpc */

void setSprOnesCnt(BYTE uDisOpt)
{
    if(uDisOpt)
    {
        rmDisSprOnesCnt;
    }
    else if(rmChkSpare26B)
    {
        rmSetSprOnesCntTh(26);
    }
    else
    {
        rmSetSprOnesCntTh(16);
    }
}

void enRetryDataOnesCnt(BYTE uOptyp)
{
    if(gbManulDisSprOnes)
    {
        setSprOnesCnt(0);
    }
}

void disRetryDataOnesCnt(BYTE uOptyp)
{
    if(gbManulDisSprOnes)
    {
        setSprOnesCnt(1);
    }
}

void setFlashDllAdj()
{
    BYTE uBackUpCh=gActiveCh;
    BYTE uCh;

    for(uCh=0; uCh<gTotalChNum; uCh++)
    {
        setFLActCh(uCh);
        rmSetDllAdjVal(garDllAdj[garChMapTable[uCh]]);
    }

    setFLActCh(uBackUpCh);
}

void SetMskCeCnt(WORD u16FlashClk)
{
    BYTE ufillvalue=0;    // for example, 325MHz
    BYTE utRPSTH=25;    // (ns) spec requirement
    BYTE uTick=0;

    uTick=(1000/(u16FlashClk));    // (ns) 1/(Flash clock)                          //=3
    uTick*=2;    // HW design interval is 2 ticks                //=6
    ufillvalue=(utRPSTH+(uTick-1))/(uTick);    // how many interval we need to meet spec       //=3
    ufillvalue++;    // =4

    if(ufillvalue<=2)
    {
        ufillvalue=3;    // shold set at least 3
    }

    rmSetMskCeCnt(ufillvalue);    // set 1/2/3/4 = 0/6/12/18 (ns)
}    /* SetMskCeCnt */

void setFlashRWDelayTime(WORD u16FlashClk)
{
    WORD u16FlashClk10times;

    u16FlashClk10times=u16FlashClk*10;
    // for flash RW ALE preamble
    rmSetTwhr2((u16FlashClk10times+32)/33);    // For (tWHR) >300ns�Aso(200MHz�ADDR400)= 300/5 = 0x3C

    if(((u16FlashClk10times+32)/33)>8)
    {
        rmSetTpre(((u16FlashClk10times+32)/33)-8);    // tWHR -  8
    }

    SetMskCeCnt(u16FlashClk);    // CSSD-4739
    // g32SetFeatureDelay=Div((u16FlashClk<<1),10);    //delay 2us
}

void setAuxQue(BYTE uMode)
{
    if(uMode==0x01)
    {
        rmDisFlashClkAutoGate;
        rmDisCmdFifoFullInt;
        rmEnAuxCmdQue;
        sysDelay(16);
        rmClrCmdQueFull;
        mWaitCmdFifoBz;
        rmCmdQueResume;
    }
    else
    {
        rmCmdPause;

        while(!rmChkCmdFifoPause)
            ;

        rmDisAuxCmdQue;
        sysDelay(16);
        rmClrCmdQueFull;
        rmClrCmdFifoStsFull;
        sysDelay(16);
        rmClrPause;
        rmCmdQueResume;
        rmEnCmdFifoFullInt;
        sysDelay(16);
    }
}    /* setAuxQue */

#if _GREYBOX
void setPfWrPara(BYTE uAddr, BYTE uData)
{}

void chkPfWrPara(BYTE uAddr, BYTE uPara)
{}

void setProgFailPara(WORD u16Opt)
{}

void restoProgFailPara()
{}

#endif/* if (_GREYBOX) */
#else/* if (_CPUID==1) */
void waitCmdFifoDpt(BYTE uCh, ADDRINFO *upTmpAddrInfo)
{
    gsFtlDbg.u16DummyFailType=cWaitCmdFifoDpt;
    debugWhile();
}

#endif/* if (_CPUID==1) */

#if (!_ICE_LOAD_ALL)
#pragma default_function_attributes =
#endif







