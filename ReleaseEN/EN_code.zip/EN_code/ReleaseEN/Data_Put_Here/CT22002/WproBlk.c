







#include "inc/Const.h"
#include "inc/TypeDef.h"
#include "inc/Option.h"
#include "inc/ProType.h"
#include "inc/Asm.h"
#include "inc/GlobVarS.h"
#include "inc/GlobVar1.h"
#include "inc/GlobVarT.h"
#include "inc/NvmeCtrl.h"
#include "inc/BitDef.h"
#include "inc/Reg.h"
#include "inc/Rdlink.h"
#include "inc/Mac.h"
#if _EN_CHRONUS_UART_DEBUG
#include "inc/DebugLog.h"
#include "inc/EventLogIDX.h"
#include "inc/EventLogFunctionIDX.h"
#endif

BYTE chkDiffType2Ptr(WORD u16FBlock)
{
    BYTE uDiffType2Ptr;

    for(uDiffType2Ptr=0; uDiffType2Ptr<gDiffType2Num; uDiffType2Ptr++)
    {
        if(u16FBlock==g16arDiffType2Offset[uDiffType2Ptr])
        {
            return uDiffType2Ptr;
        }
    }

    return 0xFF;
}

WORD popDiffType2SpareBlock()
{
    BYTE uDiffType2Ptr;
    BYTE uChose=0xFF;
    WORD u16MinEraseCnt=c15BitFF;
    WORD u16EraseCnt;

    while(cTrue)
    {
        for(uDiffType2Ptr=0; uDiffType2Ptr<gDiffType2Num; uDiffType2Ptr++)
        {
            if(!mChkBitMask(gsCacheInfo.u32arDiffType2PopBit[uDiffType2Ptr>>5], uDiffType2Ptr&0x1F))
            {
                u16EraseCnt=mGetGlobEraseCnt(g16arDiffType2Offset[uDiffType2Ptr]);

                if(u16MinEraseCnt>u16EraseCnt)
                {
                    u16MinEraseCnt=u16EraseCnt;
                    uChose=uDiffType2Ptr;
                }
            }
        }

        while(uChose==0xFF)
            ;

        mSetBitMask(gsCacheInfo.u32arDiffType2PopBit[uChose>>5], uChose&0x1F);
        gsCacheInfo.uDiffType2SprBlkCnt--;

        if(erasedDiffType2Blk(g16arDiffType2Offset[uChose]))
        {
            mSetPoppedBit(g16arDiffType2Offset[uChose]);
            mSetGlobEraseCnt(g16arDiffType2Offset[uChose], c16BitFF);

            if(gsCacheInfo.uDiffType2SprBlkCnt==0)
            {
                gsFtlDbg.u16DummyFailType=cPopDiffType2SpareBlock;
                debugWhile();
            }
        }
        else
        {
            break;
        }
    }

    return g16arDiffType2Offset[uChose];
}    /* popDiffType2SpareBlock */

void setWproPagePtr(BYTE uWproIdx, WORD u16PagePtr)
{
    BYTE uOrgBlkIdx, uDiffTypePtr;
    WORD u16FBlock;

    if((gsWproInfo.uarWproIdxPtr[uWproIdx]!=0xFF)&&(uWproIdx!=cWproQBootPg)&&(uWproIdx!=cWproQBWithDumyW)&&(uWproIdx!=cWproInvQBootPg))
    {
        if(gsWproInfo.uarWproIdxPtr[uWproIdx]!=0xFF)
        {
            uOrgBlkIdx=gsWproInfo.uarWproIdxPtr[uWproIdx];    // max wpro block count = 8

            if((uWproIdx!=cMaxWproPageType)&&(uWproIdx!=cWproQBootPg)&&(uWproIdx!=cWproQBWithDumyW)&&(uWproIdx!=cWproInvQBootPg))
            {
                while(!gsWproInfo.u16arVpCnt[uOrgBlkIdx])
                    ;

                gsWproInfo.u16arVpCnt[uOrgBlkIdx]--;
            }

            if((!gsWproInfo.u16arVpCnt[uOrgBlkIdx])&&(uOrgBlkIdx!=gsWproInfo.uActIdx))
            {
                u16FBlock=gsWproInfo.u16arWproBlk[uOrgBlkIdx];
                uDiffTypePtr=chkDiffType2Ptr(u16FBlock);

                // Diff Type 2 block
                if(uDiffTypePtr!=0xFF)
                {
                    mClrBitMask(gsCacheInfo.u32arDiffType2PopBit[uDiffTypePtr>>5], uDiffTypePtr&0x1F);
                    gsCacheInfo.uDiffType2SprBlkCnt++;
                }
                else
                {
                    pushSpareBlock(u16FBlock, cPushNotErase);
                }

                gsWproInfo.uCnt--;

                while(!gsWproInfo.uCnt)
                    ;

                gsWproInfo.u16arWproBlk[uOrgBlkIdx]=c16BitFF;
            }
        }
    }

    gsWproInfo.uarWproIdxPtr[uWproIdx]=gsWproInfo.uActIdx;
    gsWproInfo.u16arWproIdxPagePtr[uWproIdx]=u16PagePtr;

    if((uWproIdx!=cMaxWproPageType)&&(uWproIdx!=cWproQBootPg)&&(uWproIdx!=cWproQBWithDumyW)&&(uWproIdx!=cWproInvQBootPg))
    {
        gsWproInfo.u16arVpCnt[gsWproInfo.uActIdx]++;
    }
}    /* setWproPagePtr */

BYTE getFreeWproBlkIdx(BYTE uActIdx)
{
    BYTE uLoop, uIdx;

    if(uActIdx==0xFF)
    {
        return 0;
    }
    else
    {
        uIdx=uActIdx;

        for(uLoop=0; uLoop<cMaxWproBlkCnt; uLoop++)
        {
            if(uIdx==(cMaxWproBlkCnt-1))
            {
                uIdx=0;
            }
            else
            {
                uIdx++;
            }

            if(gsWproInfo.u16arWproBlk[uIdx]==c16BitFF)
            {
                return uIdx;
            }
        }
    }

    gsFtlDbg.u16DummyFailType=cGetFreeWproBlkIdx;
    debugWhile();    // can not find free idx
    return 0;
}    /* getFreeWproBlkIdx */

void swapWproBlk()
{
    BYTE uWproIdx, uInHmb;
    WORD u16BKPowerDownMode=gPowerDownMode;    // 20190131_Louis

    // WORD u16BkWproBlock=gsWproInfo.u16WproBlk;

    // ADDRINFO usTmpAddrInfo;
    // BYTE uCh;
    gsWproInfo.uSwap=1;
    gsWproInfo.uWPROFull=1;
#if _EN_PopBlk0    // Chief_20190104
    if(g16PushSpareCnt&&(gsCacheInfo.u16SpareBlockCnt<C_BlkEmergencyTh))
    {
        NLOG(cLogHost, WPROBLK_C, 1, "Emergency SwapWproBlk g16PushSpareCnt =0x%04X", g16PushSpareCnt);
        chkPushSpareQ(3);
        gBlkEmergencyflag=cBit0;
    }
#endif
    NLOG(cLogHost, WPROBLK_C, 0, "SwapWproBlk Start!");

    for(uWproIdx=(cWproInvQBootPg+1); uWproIdx<cMaxWproPageType; uWproIdx++)
    {
        if((gsWproInfo.uarWproIdxPtr[uWproIdx]!=gsWproInfo.uActIdx)&&(gsWproInfo.u16arWproIdxPagePtr[uWproIdx]!=0xFFFF))
        {
            uInHmb=mChkGcInfoHmbLink(uWproIdx);

            if(uInHmb)
            {
                mClrGcInfoHmbLink(uWproIdx);
            }

            readWproPage(uWproIdx, g16WproSwapSBuf, 0);
#if _GREYBOX
            if(gsGbInfo.uGreyBoxItem==cUGSDSwapWproID)
            {
                gsGbInfo.uStag=cVsTriggered;
            }
#endif
            progWproPage(uWproIdx, g16WproSwapSBuf);

            if(uInHmb)
            {
                mSetGcInfoHmbLink(uWproIdx);
            }
        }
    }

    for(uWproIdx=0; uWproIdx<cMaxWproBlkCnt; uWproIdx++)
    {
        if((uWproIdx!=gsWproInfo.uActIdx)&&(gsWproInfo.u16arWproBlk[uWproIdx]!=0xFFFF)&&(!gsWproInfo.u16arVpCnt[uWproIdx]))
        {
            while(!mChkPoppedBit(gsWproInfo.u16arWproBlk[uWproIdx]))
                ;

            pushSpareBlock(gsWproInfo.u16arWproBlk[uWproIdx], cPushNotErase);
            gsWproInfo.u16arWproBlk[uWproIdx]=0xFFFF;
            gsWproInfo.uCnt--;

            while(!gsWproInfo.uCnt)
                ;
        }
    }

    gsWproInfo.uWPROFull=0;
    gsQBootInfo.ubQBootValid=0;
    gsWproInfo.uSwap=0;
    gPowerDownMode=u16BKPowerDownMode;

    NLOG(cLogHost, WPROBLK_C, 1, "swapWproBlk End! gsWproInfo.uCnt=0x%04x", gsWproInfo.uCnt);
}    /* swapWproBlk */

#if 1
void progWproPage(BYTE uWproIdx, WORD u16SbufPtr)
{
    if(mChkDummyWrite)
    {
        return;
    }

    if(gsQBootInfo.ubQBootValid&&(uWproIdx!=cWproInvQBootPg)&&(uWproIdx!=cWproQBootPg)&&(uWproIdx!=cMaxWproPageType)&&(!(u16SbufPtr&c16Bit15)))
    {
        progWproPage2(cWproInvQBootPg, c16Tsb0SIdx);
    }

#if _EN_VPC_SWAP
    if((!mChkBitMask(g32VPCSwapFlag, cVPCntBufValid))&&(u16SbufPtr!=g16WproSwapSBuf)&&(uWproIdx==cWproCacheInfo))
    {
        waitAllChCeBz();
        readWproPage(cWproCacheBlkVpCnt, (c32ProgCacheInfo_CacheBlkVpCntStAddr+((LWORD)(u16SbufPtr&(0x7FFF))*0x200))>>9, 0);
    }
#endif/* if _EN_VPC_SWAP */

    progWproPage2(uWproIdx, u16SbufPtr);
}    /* progWproPage */

#endif/* if 1 */

void prog1stInvQBootInWpro()
{
    if(gsQBootInfo.ubQBootValid)
    {
        progWproPage(cWproInvQBootPg, c16Tsb0SIdx);
    }
}

void progWproPage2(BYTE uWproIdx, WORD u16SbufPtrOrg)
{
    // void progWproPage(BYTE uWproIdx, WORD u16SbufPtr)
    ADDRINFO usTmpAddrInfo;
    BYTE    /*uBzBitMap=0,*/ uCh, uPlaneAddr1, uIntlvAddr1,    /* uTotalPlaneCnt, uStartBufPtr, */ uOpType, uIdx, uNoSwap=0;
    WORD u16PageOfst, u16TotalPlaneOfWproPage;
    WORD u16RiskFpage, u16HdlOpWproPagePtr;
    BYTE uStartCh, uEndCh;
    WORD u16FBlock;
    WORD u16SbufPtr;
    BYTE uDiffType2=0, uAssignMultiPlane, uLoop;
    WORD u16AddPageCnt;
    WORD u16SctAddr;

    do
    {
        u16SbufPtr=u16SbufPtrOrg;

        if(u16SbufPtr&c16Bit15)
        {
            u16SbufPtr&=~c16Bit15;
            uNoSwap=1;
        }

        if((uWproIdx==cWproQBootPg)||(uWproIdx==cWproQBWithDumyW))
        {
            waitAllChCeBz();
            u16TotalPlaneOfWproPage=gsQBootInfo.uSavePgCnt;
        }
        else if(uWproIdx==cWproCacheInfo)
        {
            if(gsWproInfo.u16CacheInfoPlaneSize==0)
            {
                u16TotalPlaneOfWproPage=((c16CacheInfoTabSize/cSctrPer4k)/g4kNumPerPlane);
#if _EN_VPC_SWAP
                u16AddPageCnt=
                    (c32CacheBlkVpCntVarSize+sizeof(g16arGlobEraseCnt)+
                     sizeof(g32arPushReclaimQ)+c32SlcQRamSize)%
                    (cSctrPer4k*cSectorSize*g4kNumPerPlane);

                u16AddPageCnt=
                    ((c32CacheBlkVpCntVarSize+sizeof(g16arGlobEraseCnt)+
                      sizeof(g32arPushReclaimQ)+c32SlcQRamSize)/(cSctrPer4k*cSectorSize*g4kNumPerPlane))+
                    ((u16AddPageCnt)?1:0);
#else
                u16AddPageCnt=(sizeof(g16arGlobEraseCnt)+sizeof(g32arGlobReadCnt)+sizeof(g32arPushReclaimQ)+c32SlcQRamSize)%
                               (cSctrPer4k*cSectorSize*g4kNumPerPlane);

                u16AddPageCnt=
                    ((sizeof(g16arGlobEraseCnt)+sizeof(g32arGlobReadCnt)+sizeof(g32arPushReclaimQ)+c32SlcQRamSize)/
                     (cSctrPer4k*cSectorSize*g4kNumPerPlane))+((u16AddPageCnt)?1:0);
#endif
                u16TotalPlaneOfWproPage+=u16AddPageCnt;

                gsWproInfo.u16CacheInfoPlaneSize=u16TotalPlaneOfWproPage;
            }
            else
            {
                u16TotalPlaneOfWproPage=gsWproInfo.u16CacheInfoPlaneSize;
            }

            if(u16SbufPtr!=g16WproSwapSBuf)
            {
                for(uLoop=0; uLoop<cMaxWproBlkCnt; uLoop++)
                {
                    if(gsWproInfo.u16arWproBlk[uLoop]!=0xFFFF)
                    {
                        mClrPoppedBit(gsWproInfo.u16arWproBlk[uLoop]);
                    }
                }

                waitAllChCeBz();
                bopCopyRam((cTsb0Addr+((LWORD)u16SbufPtr*0x200)+c32ProgCacheInfo_CacheInfoTabStAddr),
                           (c32Tsb2SAddr),
                           c32ProgCacheInfo_CacheInfoTabSize,
                           cCopyTsb2Tsb|cBopWait);    //
                                                      // cacheInfo
#if _EN_VPC_SWAP
                bopCopyRam(cTsb0Addr+(u16SbufPtr*0x200)+c32ProgCacheInfo_EraseCntStAddr,    // erase count
                           (LWORD)&g16arGlobEraseCnt,
                           c32ProgCacheInfo_EraseCntSize,
                           cCopyStcm2Tsb|cBopWait);
                bopCopyRam(cTsb0Addr+(u16SbufPtr*0x200)+c32ProgCacheInfo_ReadCntStAddr,    // read count
                           (LWORD)&g16arGlobReadCnt,
                           c32ProgCacheInfo_LowReadCntSize,
                           cCopyTsb2Tsb|cBopWait);    // ??? cCopyCpu1Dccm2Tsb
                bopCopyRam(cTsb0Addr+(u16SbufPtr*0x200)+c32ProgCacheInfo_ReadCntStAddr+c32ProgCacheInfo_LowReadCntSize,    // read count
                           (LWORD)&garGlobReadCntHighByte,
                           c32ProgCacheInfo_HighReadCntSize,
                           cCopyTsb2Tsb|cBopWait);    // ??? cCopyCpu1Dccm2Tsb
#else
                bopCopyRam(cTsb0Addr+(u16SbufPtr*0x200)+c32ProgCacheInfo_EraseCntStAddr,    // erase count
                           (LWORD)&g16arGlobEraseCnt,
                           c32ProgCacheInfo_EraseCntSize,
                           cCopyCpu1Dccm2Tsb|cBopWait);
#if (_TSB_BiCS4)
                bopCopyRam(cTsb0Addr+(u16SbufPtr*0x200)+c32ProgCacheInfo_ReadCntStAddr,    // read count
                           (LWORD)&g32arGlobReadCnt,
                           c32ProgCacheInfo_ReadCntSize,
                           cCopyStcm2Tsb|cBopWait);    // ??? cCopyCpu1Dccm2Tsb
#else
                bopCopyRam(cTsb0Addr+(u16SbufPtr*0x200)+c32ProgCacheInfo_ReadCntStAddr,    // read count
                           (LWORD)&g32arGlobReadCnt,
                           c32ProgCacheInfo_ReadCntSize,
                           cCopyTsb2Tsb|cBopWait);    // ??? cCopyCpu1Dccm2Tsb
#endif
#endif/* if _EN_VPC_SWAP */
                bopCopyRam(cTsb0Addr+(u16SbufPtr*0x200)+c32ProgCacheInfo_PushReclaimQStAddr,
                           (LWORD)&g32arPushReclaimQ,
                           c32ProgCacheInfo_PushReclaimQSize,
                           cCopyCpu1Dccm2Tsb|cBopWait);    // ??? cCopyCpu1Dccm2Tsb

                bopCopyRam(cTsb0Addr+(u16SbufPtr*0x200)+c32ProgCacheInfo_SlcQStAddr,
                           (LWORD)c32SlcQRamAddr,
                           c32SlcQRamSize,
                           cCopyCpu1Dccm2Tsb|cBopWait);

                for(uLoop=0; uLoop<cMaxWproBlkCnt; uLoop++)
                {
                    if(gsWproInfo.u16arWproBlk[uLoop]!=0xFFFF)
                    {
                        mSetPoppedBit(gsWproInfo.u16arWproBlk[uLoop]);
                    }
                }
            }

            // bopCopyRam((cTsb0Addr+((LWORD)u16SbufPtr*0x200)), (c32Tsb2SAddr), c16CacheInfoTabSize*512, cCopyTsb2Tsb|cBopWait);
        }
        else if(uWproIdx==cWproBadInfo)
        {
            u16TotalPlaneOfWproPage=1+((cDiffMixTableHalfKb+cTotalRTDiffPoolHalfKb)/gSectorPerPlaneH);
        }
        else if((uWproIdx>=cWproGcDesF2hTab00)&&(uWproIdx<=cWproGcInfoPage))
        {
            u16TotalPlaneOfWproPage=gsGcInfo.uGCDes4KNumOfF2hTab/g4kNumPerPlane;
            u16TotalPlaneOfWproPage<<=1;
        }
        else if(uWproIdx==cMaxWproPageType)
        {
            u16RiskFpage=gsWproInfo.u16WproFreePagePtr/(gIntlvWay*gPlaneNum*cWriteChNum);
            u16HdlOpWproPagePtr=((u16RiskFpage/cSubBlockNum+cHdlOpWLNum)*cSubBlockNum)*(gIntlvWay*gPlaneNum*cWriteChNum);
            u16TotalPlaneOfWproPage=u16HdlOpWproPagePtr-gsWproInfo.u16WproFreePagePtr;

            if((u16TotalPlaneOfWproPage+gsWproInfo.u16WproFreePagePtr)>gsWproInfo.u16PagePerBlock3)
            {
                u16TotalPlaneOfWproPage=gsWproInfo.u16PagePerBlock3-gsWproInfo.u16WproFreePagePtr;
            }
        }
        else if(uWproIdx==cWproFeaturePg)
        {
            u16TotalPlaneOfWproPage=(((sizeof(NVMEFEATVAR)-0x1000)/(gSectorPerPlaneH*0x200))+1);
        }
        else if(uWproIdx==cWproGetLogPg)
        {
            u16TotalPlaneOfWproPage=((sizeof(GETLOGINFO)/(gSectorPerPlaneH*0x200))+1);
        }
        else if(uWproIdx==cWproSecurityBackupAllTsb)
        {
            u16TotalPlaneOfWproPage=c16Tsb0Size/gSectorPerPlaneH;
        }

        // else if(uWproIdx==cWproGcBakF2hTab)
        // {
        //    u16TotalPlaneOfWproPage=((cCacheF2hTabSctrSize/cSctrPer4k)/g4kNumPerPlane);
        // }
#if _EN_VPC_SWAP
        else if(uWproIdx==cWproCacheBlkVpCnt)
        {
            u16TotalPlaneOfWproPage=(c16MaxBlockNum>>7)/gSectorPerPlaneH;

            if((c16MaxBlockNum>>7)%gSectorPerPlaneH)
            {
                u16TotalPlaneOfWproPage++;
            }
        }
#endif
        else
        {
            u16TotalPlaneOfWproPage=1;
        }

        if(uWproIdx!=cMaxWproPageType)
        {
#if _EN_PROGFAILLOG
            if(mChkCacheInfoFlag(cWproProgramFail)||mChkCacheInfoFlag(cMoveProgramFail))
            {
                gsWproInfo.u16WproFreePagePtr=gsWproInfo.u16PagePerBlock3;
                mClrCacheInfoFlag(cWproProgramFail);
                mClrCacheInfoFlag(cMoveProgramFail);
            }
#endif

            if((gsWproInfo.u16WproFreePagePtr>=(gsWproInfo.u16PagePerBlock3-u16TotalPlaneOfWproPage+1)))
            {
                // if(uWproIdx==cMaxWproPageType)
                // {
                //    u16TotalPlaneOfWproPage=0;    // not padding but need to pop new WproBlk
                // }

                while(gsWproInfo.uCnt>=cMaxWproBlkCnt)
                    ;

                uIdx=gsWproInfo.uActIdx;    // for debug
                gsWproInfo.uActIdx=getFreeWproBlkIdx(uIdx);

#if _GREYBOX
                if((gsGbInfo.uGreyBoxItem==cUGSDProgWPROID)&&(gsGbInfo.uGreyBoxOpt==cVOpErasing)&&(gsGbInfo.uStag==cVsIdl))
                {
                    trigGreyBox(cTrue);
                }
                else if((gsGbInfo.uGreyBoxItem==cUGSDonEraseFail)&&(gsGbInfo.uStag==cVsIdl)&&(gsGbInfo.uGreyBoxOpt==cVOpPopWPROIDBfErase))
                {
                    gsGbInfo.uStag=cVsTriggered;
                }
                else if((gsGbInfo.uGreyBoxItem==cUGSDonEraseFail)&&(gsGbInfo.uGreyBoxOpt==cVOpPopWPROIDAfErase)&&
                        (gsGbInfo.u32BkValue==cSuccess))
                {
                    gsGbInfo.u32BkValue|=c32Bit1;
                }
#endif

#if _EN_WPRO_WITH_DIFFTYPE2
                if(gsCacheInfo.uDiffType2SprBlkCnt)
                {
                    gsWproInfo.u16arWproBlk[gsWproInfo.uActIdx]=popDiffType2SpareBlock();
                }
                else
#endif
                {
                    gsWproInfo.u16arWproBlk[gsWproInfo.uActIdx]=popSpareBlock(cPopMinErsCnt|cPopSlcBlock);
                }

                gsWproInfo.uCnt++;
                gsWproInfo.u16WproFreePagePtr=0;
                gsWproInfo.u32Serial++;
                // mSetSeedOfst(gsWproInfo.u16WproBlk, 0);

                if((gsWproInfo.uCnt>=(cWproGcThr))&&(!uNoSwap)&&(!gsWproInfo.uSwap))
                {
                    swapWproBlk();

                    if(mChkGcQue(cGcTypWPROSwap))
                    {
                        mPopGcQue(cGcTypWPROSwap);
                    }
                }

                waitAllChCeBz();

                saveIndexBlock();

                // if(u16OrgWproBlk!=0xFFFF)    // &&(u16OrgWproBlk!=gsWproInfo.u16WproBlk))
            }
            else if((gsWproInfo.uCnt>=(cWproGcThr))&&(!uNoSwap)&&(!gsWproInfo.uSwap))
            {
                swapWproBlk();

                waitAllChCeBz();

                saveIndexBlock();
            }

#if 0    // 20190722_SamHu_01
            else if(gbUpdIdxF)
            {
                // for info is injured
                saveIndexBlock();
            }
#endif
        }

        // For Devslp QBoot, Pre-Prepare variable.
        if((uWproIdx==cWproInvQBootPg)||(uWproIdx==cMaxWproPageType))
        {
            // while(uSTOP);
            gsQBootInfo.ubQBootValid=0;
            gPowerDownMode=cUGSD;
        }
        else if((uWproIdx==cWproQBootPg)||(uWproIdx==cWproQBWithDumyW))
        {
            // while(uSTOP);
            gsQBootInfo.ubQBootValid=1;
        }

        if(uWproIdx!=cMaxWproPageType)
        {
            // gsWproInfo.u16arWproIdxPagePtr[uWproIdx]=gsWproInfo.u16WproFreePagePtr;
            setWproPagePtr(uWproIdx, gsWproInfo.u16WproFreePagePtr);
        }

        if((uWproIdx==cWproQBootPg)||(uWproIdx==cWproQBWithDumyW))
        {
            gsWproInfo.u16WproFreePagePtr+=gsQBootInfo.uSavePgCnt;

            if(uWproIdx==cWproQBootPg)
            {
#if _EN_RAID_GSD
                termRaidAllEngForQB();
#endif
            }

#if 0
            /* test code */
            g32arCacheBlkVpCnt[0]=0xAAAA5555;
            // gsCacheInfo.u32DummyProgFreePagePtr=0x5A5A5A5A;
            // gsRwCtrl.u32LastLbaW=0xAAAA5555;
            gsGcInfo.u32BgdGcEndTime=0x5555AAAA;
            r32SkipRam[0]=0xAAAA5555;
            garCacheF2hTab[0].u16HBlock=0x5555;
            garCacheF2hTab[0].u16HPage=0xAAAA;
            g16arGlobEraseCnt[1023]=0x5A5A;
#endif

#if 1
            // (s)gsQBootInfo.u16arStartBuf[2]
            bopCopyRam(((LWORD)garTsb0[0])+c32CacheInfoVarAddr,
                       (LWORD)&gsCacheInfo,
                       sizeof(gsCacheInfo),
                       cCopyStcm2Tsb|cBopWait);
            bopCopyRam(((LWORD)garTsb0[0])+c32GcInfoVarAddr,
                       (LWORD)&gsGcInfo,
                       sizeof(gsGcInfo),
                       cCopyStcm2Tsb|cBopWait);
            bopCopyRam(((LWORD)garTsb0[0])+c32WproInfoVarAddr,
                       (LWORD)&gsWproInfo,
                       sizeof(gsWproInfo),
                       cCopyStcm2Tsb|cBopWait);
            bopCopyRam(((LWORD)garTsb0[0])+c32RwCtrlVarAddr,
                       (LWORD)&gsRwCtrl,
                       sizeof(gsRwCtrl),
                       cCopyStcm2Tsb|cBopWait);

            copyReg2Tsb32(g32arTsb0[c16SkipRamVarSctrAddr], r32SkipRam, c32SkipRamVarSize/4);

#if _EN_VPC_SWAP
            bopCopyRam(((LWORD)garTsb0[0])+c32EraseCntVarAddr, (LWORD)&g16arGlobEraseCnt,
                       sizeof(g16arGlobEraseCnt), cCopyStcm2Tsb|cBopWait);
            bopCopyRam(((LWORD)garTsb0[0])+c32ReadCntVarAddr,
                       (LWORD)&g16arGlobReadCnt,
                       sizeof(g16arGlobReadCnt),
                       cCopyTsb2Tsb|cBopWait);
            bopCopyRam(((LWORD)garTsb0[0])+c32ReadCntVarAddr+c32LowReadCntVarSize,
                       (LWORD)&garGlobReadCntHighByte,
                       sizeof(garGlobReadCntHighByte),
                       cCopyTsb2Tsb|cBopWait);
            bopCopyRam(((LWORD)garTsb0[0])+c32ReadCntVarAddr+c32LowReadCntVarSize+c32HighReadCntVarSize,
                       (LWORD)&g32arPushReclaimQ,
                       sizeof(g32arPushReclaimQ),
                       cCopyCpu1Dccm2Tsb|cBopWait);
#else
            bopCopyRam(((LWORD)garTsb0[0])+c32EraseCntVarAddr, (LWORD)&g16arGlobEraseCnt,
                       sizeof(g16arGlobEraseCnt), cCopyCpu1Dccm2Tsb|cBopWait);
#if (_TSB_BiCS4)
            bopCopyRam(((LWORD)garTsb0[0])+c32ReadCntVarAddr,
                       (LWORD)&g32arGlobReadCnt,
                       sizeof(g32arGlobReadCnt),
                       cCopyStcm2Tsb|cBopWait);
#else
            bopCopyRam(((LWORD)garTsb0[0])+c32ReadCntVarAddr,
                       (LWORD)&g32arGlobReadCnt,
                       sizeof(g32arGlobReadCnt),
                       cCopyTsb2Tsb|cBopWait);
#endif
            bopCopyRam(((LWORD)garTsb0[0])+c32ReadCntVarAddr+sizeof(g32arGlobReadCnt),
                       (LWORD)&g32arPushReclaimQ,
                       sizeof(g32arPushReclaimQ),
                       cCopyCpu1Dccm2Tsb|cBopWait);
#endif/* if _EN_VPC_SWAP */
            bopCopyRam(((LWORD)garTsb0[0])+c32GcSrcBlkBitMapAddr, (LWORD)&g32arGcSrcBlkBitMap,
                       sizeof(g32arGcSrcBlkBitMap), cCopyStcm2Tsb|cBopWait);
#if (!_EN_VPC_SWAP)
            bopCopyRam(((LWORD)garTsb0[0])+c32GcInvalidPageBitMapAddr,
                       (LWORD)&g32arGcInvaildPageBimap,
                       sizeof(g32arGcInvaildPageBimap),
                       cCopyTsb2Tsb|cBopWait);
#endif

            bopCopyRam(((LWORD)garTsb0[0])+c32SlcQStAddr, (LWORD)c32SlcQRamAddr,
                       c32SlcQRamSize, cCopyCpu1Dccm2Tsb|cBopWait);

            bopCopyRam(((LWORD)garTsb0[0])+c32RaidInfoAddr,
                       (LWORD)&gsRaidInfo,
                       sizeof(gsRaidInfo),
                       cCopyCpu1Dccm2Tsb|cBopWait);
            /*
               * bopCopyRam(((LWORD)garTsb0[0])+c32RdCntCtrlAddr,
               *         (LWORD)&gsRdCntCtrl,
               *         sizeof(gsRdCntCtrl),
               *         cCopyCpu1Dccm2Tsb|cBopWait);
               */

            bopCopyRam(((LWORD)garTsb0[0])+c32HmbH2fCrcAddr,
                       (LWORD)&g32arHmbCrc,
                       sizeof(g32arHmbCrc),
                       cCopyTsb2Tsb|cBopWait);
            bopCopyRam(((LWORD)garTsb0[0])+c32HmbGcDataCrcAddr,
                       (LWORD)&g32arGcDataCrc,
                       sizeof(g32arGcDataCrc),
                       cCopyTsb2Tsb|cBopWait);
            bopCopyRam(((LWORD)garTsb0[0])+c32HmbGcInfoCrcAddr,
                       (LWORD)&g32arGcInfoCrc,
                       sizeof(g32arGcInfoCrc),
                       cCopyTsb2Tsb|cBopWait);
            bopCopyRam(((LWORD)garTsb0[0])+c32HmbGcPtCrcAddr,
                       (LWORD)&g32arGcPtyCrc,
                       sizeof(g32arGcPtyCrc),
                       cCopyTsb2Tsb|cBopWait);
#if (_EN_VPC_SWAP&&_EN_GCPWR&&(!_EN_RAID_GC))
            bopCopyRam(((LWORD)garTsb0[0])+c32GcInvalidPageBitMapAddr,
                       (LWORD)&g32arGcInvaildPageBimap,
                       sizeof(g32arGcInvaildPageBimap),
                       cCopyTsb2Tsb|cBopWait);
#endif

            // (s)gsQBootInfo.u16arStartBuf[1], (CacheF2h)
            bopCopyRam(((LWORD)garTsb0[gsQBootInfo.u16QBVarPgSectorCnt]),
                       ((LWORD)garTsb0[c16CacheF2hTabSIdx]),
                       cCacheF2hSctrSize*0x200,
                       cCopyTsb2Tsb|cBopWait);

            // (s)gsQBootInfo.u16arStartBuf[2], (cache info-TSB2)
            bopCopyRam(((LWORD)garTsb0[gsQBootInfo.u16QBVarPgSectorCnt+cCacheF2hSctrSize]),
                       (c32Tsb2SAddr),
                       c16CacheInfoTabSize*0x200,
                       cCopyTsb2Tsb|cBopWait);

            if(uWproIdx==cWproQBootPg)
            {
#if _GREYBOX
                if((gsGbInfo.uGreyBoxItem==cErrHdlProgWPROID)&&(uWproIdx==cWproQBootPg))
                {
                    copyTsb2Sdram((BYTE *)c32GreyBoxBuf, (UCBYTE *)(cTsb0Addr), (((LWORD)gSectorPerPlaneH*gsQBootInfo.uSavePgCnt)<<9));
                }
#endif
#if _EN_RAID_GSD
                resmRaidAllEngForQB();
#endif
            }

            gsWproInfo.u16WproFreePagePtr-=gsQBootInfo.uSavePgCnt;
#else/* if 1 */
            bopCopyRam(((LWORD)garTsb0[0])+c32CacheInfoVarAddr, (LWORD)&gsCacheInfo, sizeof(gsCacheInfo), cCopyStcm2Tsb|cBopWait);
            bopCopyRam(((LWORD)garTsb0[0])+c32GcInfoVarAddr, (LWORD)&gsGcInfo, sizeof(gsGcInfo), cCopyStcm2Tsb|cBopWait);
            bopCopyRam(((LWORD)garTsb0[0])+c32WproInfoVarAddr, (LWORD)&gsWproInfo, sizeof(gsWproInfo), cCopyStcm2Tsb|cBopWait);
            bopCopyRam(((LWORD)garTsb0[0])+c32RwCtrlVarAddr, (LWORD)&gsRwCtrl, sizeof(gsRwCtrl), cCopyStcm2Tsb|cBopWait);

            copyReg2Tsb32(g32arTsb0[c16SkipRamVarSctrAddr], r32SkipRam, c32SkipRamVarSize/4);
            bopCopyRam(((LWORD)garTsb0[0])+c32EraseCntVarAddr, (LWORD)&g16arGlobEraseCnt, sizeof(g16arGlobEraseCnt),
                       cCopyCpu1Dccm2Tsb|cBopWait);

            gsWproInfo.u16WproFreePagePtr-=gsQBootInfo.uSavePgCnt;

            uStartBufPtr=0;
            u16SbufPtr=gsQBootInfo.u16arStartBuf[0];
            uTotalPlaneCnt=gsQBootInfo.uPgCnt[uStartBufPtr];
#endif/* if 1 */
        }
        else if((uWproIdx>=cWproCacheInfo)&&(uWproIdx<=cWproSecurityBackupAllTsb))
        {
            // copy gsWproInfo
            switch(uWproIdx)
            {
                case cWproCacheInfo:
#if _EN_VPC_SWAP
                    u16SctAddr=c16CacheInfoVPCSize+c16CacheInfoTabSize-1;
#else
                    u16SctAddr=c16CacheInfoTabSize-1;
#endif
                    break;

                case cWproBadInfo:
                    u16SctAddr=u16TotalPlaneOfWproPage*gSectorPerPlaneH-1;    // u16SctAddr=cBadInfoBufSctrCnt-1;
                    break;

                case cWproEventLog:
                case cWproFeaturePg:
                case cWproGetLogPg:
                case cWproSecurityId:
                case cWproTcgIeee1667InfoId:
                case cWproTcgInfoId:
                case cWproTcgInfoDevslpId:
                case cWproTcgIeee1667InfoDevslpId:
                case cWproTcgIeee1667InfoTransDevslpId:
                case cWproTcgRecvbuf1DevslpId:
                case cWproTcgRecvbuf2DevslpId:
                case cWproTcgRecvbuf3DevslpId:
                case cWproTcgRecvbuf4DevslpId:
#if _EN_WUNCTable    // WUNCTable Chief_21081121
                case cWproWriteUNC:
#endif
                case cWproRpmbInfoId:
#if _EN_KEEP_RW_ON_ERROR
                case cWproErrorInfo:
#endif
                case cWproSecurityBackupAllTsb:
                    u16SctAddr=u16TotalPlaneOfWproPage*gSectorPerPlaneH-1;
                    break;

                default:
                    break;
            }    /* switch */

            bopCopyRam(((LWORD)garTsb0[u16SbufPtr+u16SctAddr]), (LWORD)&gsWproInfo, sizeof(gsWproInfo), cCopyStcm2Tsb|cBopWait);
        }

#if _ENABLE_E2E_TAB
        genInternalDataCrc(u16SbufPtr, u16TotalPlaneOfWproPage*gSectorPerPlaneH, gsWproInfo.u16WproFreePagePtr*gSectorPerPlaneH, cE2eWproBlk);
#endif

        u16FBlock=gsWproInfo.u16arWproBlk[gsWproInfo.uActIdx];

        if((g16arDiffOffset[u16FBlock]!=c16BitFF)&&(mChkBitMask(g16arDiffOffset[u16FBlock], 0x0F)))
        {
            uDiffType2=1;
        }

        usTmpAddrInfo.uAddrOpt=cWPROBlockID;

        u16PageOfst=0;

        while(u16PageOfst<u16TotalPlaneOfWproPage)
        {
            // setWriteDes(0, &usTmpAddrInfo, cWriteWpro);
            usTmpAddrInfo.u16AbstractFBlock=u16FBlock;
            usTmpAddrInfo.u16FBlock=u16FBlock;
            usTmpAddrInfo.u16FPage=gsWproInfo.u16WproFreePagePtr;
            tranAddrInfoTo2Ch(&usTmpAddrInfo);

            uPlaneAddr1=usTmpAddrInfo.uPlaneAddr;
            uIntlvAddr1=usTmpAddrInfo.uIntlvAddr;
            uStartCh=usTmpAddrInfo.uCh;
            uEndCh=uStartCh+cWriteChNum;

            for(uCh=uStartCh; uCh<uEndCh; uCh++)    // (H)WPRO gPlaneNum
            {
                usTmpAddrInfo.uCh=uCh;    // (H)WPRO

                // usTmpAddrInfo.uPlaneAddr=uPlaneAddr1;
                // usTmpAddrInfo.uIntlvAddr=uIntlvAddr1;
                // Diff Type 2 block
                if(uDiffType2)
                {
                    getDiffAddr2(&usTmpAddrInfo, u16FBlock, usTmpAddrInfo.uCh, usTmpAddrInfo.uIntlvAddr, usTmpAddrInfo.uPlaneAddr);
                }

                setFLAddrActCh(usTmpAddrInfo.uCh, &usTmpAddrInfo);

                if(uDiffType2)
                {
                    g16AbstrFBlock=g16FBlock;
                    g16FBlock=u16FBlock;
                }

                gSectorH=0;

                // if(!mChkBitMask(uBzBitMap, uCh))
                // {
                //    mSetBitMask(uBzBitMap, uCh);
                // }

                if(mChkISPMode==cBoot2Isp)
                {
                    if(uWproIdx==cMaxWproPageType)
                    {
                        uOpType=cPwrOnDummyProg;
                    }
                    else
                    {
                        uOpType=cBootProgData;
                    }
                }
                else
                {
                    uOpType=cProgData;
                }

                mSetFRwParam(u16SbufPtr, gSectorPerPlaneH,    /*c16Bit0|*/ c16Bit2|c16Bit15, uOpType);

                usTmpAddrInfo.u16BufPtr=u16SbufPtr;

                waitCmdFifoDpt(usTmpAddrInfo.uCh, &usTmpAddrInfo);
                mSetTabSpr(gpFlashAddrInfo, cBit5);    // gpFlashAddrInfo->uTabSpar=1;

                if((uDiffType2==0)&&(gPlaneAddr==0)&&((u16PageOfst+gPlaneNum)<=u16TotalPlaneOfWproPage))
                {
                    mSetFRwParam(u16SbufPtr, gSectorPerPageH,    /*c16Bit0|*/ c16Bit0|c16Bit2|c16Bit15, uOpType);

                    for(uLoop=0; uLoop<gPlaneNum; uLoop++)
                    {
                        setSprByteOfTabBlk(cWPROBlockID,
                                           uWproIdx,
                                           u16PageOfst+uLoop,
                                           gsWproInfo.u16arWproIdxPagePtr[uWproIdx],
                                           gsWproInfo.u32Serial,
                                           gPlaneAddr+uLoop,
                                           gsWproInfo.u16WproFreePagePtr+uLoop);
                    }

                    uAssignMultiPlane=1;
                }
                else
                {
                    mSetFRwParam(u16SbufPtr, gSectorPerPlaneH,    /*c16Bit0|*/ c16Bit2|c16Bit15, uOpType);

                    setSprByteOfTabBlk(cWPROBlockID,
                                       uWproIdx,
                                       u16PageOfst,
                                       gsWproInfo.u16arWproIdxPagePtr[uWproIdx],
                                       gsWproInfo.u32Serial,
                                       gPlaneAddr,
                                       gsWproInfo.u16WproFreePagePtr);

                    uAssignMultiPlane=0;
                }

                waitChCeBz(usTmpAddrInfo.uCh, gIntlvAddr, cNoOp);
#if _GREYBOX
                if(gsGbInfo.uGreyBoxItem==cErrHdlProgWPROID)
                {
                    if((uWproIdx==gGbSetPgFailCase)&&(g16GbSetPgFailFpage==c16BitFF)&&(gGbSetPgFailIntlvAddr==cBitFF)&&
                       (gGbSetPgFailCh==cBitFF)&&(gGbSetPgFailPlane==cBitFF))
                    {
                        g16GbSetPgFailFpage=g16FPage;
                        gGbSetPgFailIntlvAddr=gIntlvAddr;
                        gGbSetPgFailCh=gCh;
                        gGbSetPgFailPlane=gPlaneAddr;
                    }
                }
#endif/* if _GREYBOX */
                flashProgPage(usTmpAddrInfo.u16BufPtr, usTmpAddrInfo.uRwHalfKb, usTmpAddrInfo.u16RwOpt);
                setBzInfo(gOpTyp, usTmpAddrInfo.uCh, gIntlvAddr);
                gsRwCtrl.usWaitInfo[gCh][gIntlvAddr].uStatusErrStop=1;
                usTmpAddrInfo.uPlaneAddr=uPlaneAddr1;
                usTmpAddrInfo.uIntlvAddr=uIntlvAddr1;
            }    // (H)end of uCh for loop

            if(uAssignMultiPlane)
            {
                u16SbufPtr+=gSectorPerPageH;
                gsWproInfo.u16WproFreePagePtr+=gPlaneNum;
                u16PageOfst+=gPlaneNum;
            }
            else
            {
                u16SbufPtr+=gSectorPerPlaneH;
                gsWproInfo.u16WproFreePagePtr+=1;
                u16PageOfst+=1;
            }

            if(uWproIdx==cMaxWproPageType)
            {
                u16SbufPtr=c16Tsb0SIdx;
            }
        }

        if((gsWproInfo.uCnt>=(cWproGcThr))&&(gsWproInfo.u16WproFreePagePtr>=768)&&uNoSwap)    // 20180328_Louis
        {
            NLOG(cLogHost,
                 WPROBLK_C,
                 2,
                 "SwapWproSpecialCase,  WproBlkCnt=0x%04X, WproFreePagePtr=0x%04X",
                 gsWproInfo.uCnt,
                 gsWproInfo.u16WproFreePagePtr);
#if _EN_Liteon_ErrHandle
            gJdgBootGCFlag|=cWproNeedSwap;
#endif
        }

        if(uWproIdx==cWproQBWithDumyW)
        {
            mSetDummyWrite;
        }

        // #if _PRJ_ISP
        // waitFifoOpIdx(gFullCmdThr, uBzBitMap);
        // #else
        waitAllChCeBz();
        // #endif
#if !_EN_PROGFAILLOG
        mClrCacheInfoFlag(cWproProgramFail);
#endif
#if _GREYBOX
        if(gsGbInfo.uGreyBoxItem==cUGSDProgWPROID)
        {
            if(gsGbInfo.uStag==cVsTriggered)
            {
                if((gsGbInfo.uGreyBoxOpt==cVOpProgCacheInfoInitCacheDone)||(gsGbInfo.uGreyBoxOpt==cVOpProgCacheInfoH2fFullDone))
                {
                    triggerUGSD(cFalse);
                }
            }
        }
#endif
#if 1
        /*
           *  releaes spare block from push spare Q
           */
#else
        if(uWproIdx<cWproGcDesF2hTab00)
        {
            if(g16PushSpareCnt>gsGcInfo.uPushSprbHiThr)
            {
                // codeFuncPtr[cfuncChkPushSpareQ]();
                mCallFuncPtr(cfuncChkPushSpareQ);
            }
        }
#endif
    }
    while(mChkCacheInfoFlag(cWproProgramFail));
}    /* progWproPage2 */

void readWproPage(BYTE uWproIdx, WORD u16SbufPtr, BYTE uStartPageOffset)
{
    // ADDRINFO usTmpAddrInfo;
    BYTE uPageOfst, uCh,    /*uTotalPlaneCnt, uStartBufPtr, */ uTotalPlaneOfWproPage, uIntlvAddr1, uPlaneAddr1, uDiffType2, uStartCh, uEndCh,
         uEccFail, uAssignMultiPlane, uSectorCnt;
    // BLKSPRINFO usBlkSprInfo;
    WORD u16BkWproFreePtr, u16FBlock, u16Opt, u16FPage;
    WORD u16AddPageCnt;

    // WORD u16NowNodeIdx;
#if _ENABLE_E2E_TAB
    gsE2eInfo.uTableType=cE2eWproBlk;
#endif

#if _EN_VPC_SWAP
    if((gsWproInfo.u16arWproIdxPagePtr[uWproIdx]!=c16BitFF)||(uWproIdx==cWproCacheBlkVpCnt))
#else
    if(gsWproInfo.u16arWproIdxPagePtr[uWproIdx]!=c16BitFF)
#endif
    {
        if(uWproIdx==cWproQBootPg)
        {
            uTotalPlaneOfWproPage=gsQBootInfo.uSavePgCnt;
        }
        else if(uWproIdx==cWproQBWithDumyW)
        {
            uTotalPlaneOfWproPage=gsQBootInfo.uSavePgCnt;
        }
        else if(uWproIdx==cWproCacheInfo)
        {
            uTotalPlaneOfWproPage=(c16CacheInfoTabSize/cSctrPer4k)/g4kNumPerPlane;
#if _EN_VPC_SWAP
            // global erase & read count
            u16AddPageCnt=
                (c32CacheBlkVpCntVarSize+sizeof(g16arGlobEraseCnt)+sizeof(g32arPushReclaimQ)+c32SlcQRamSize)%
                (cSctrPer4k*cSectorSize*g4kNumPerPlane);
            u16AddPageCnt=
                ((c32CacheBlkVpCntVarSize+sizeof(g16arGlobEraseCnt)+sizeof(g32arPushReclaimQ)+c32SlcQRamSize)/
                 (cSctrPer4k*cSectorSize*g4kNumPerPlane))+((u16AddPageCnt)?1:0);
#else
            // global erase & read count
            u16AddPageCnt=(sizeof(g16arGlobEraseCnt)+sizeof(g32arGlobReadCnt)+c32SlcQRamSize)%(cSctrPer4k*cSectorSize*g4kNumPerPlane);
            u16AddPageCnt=((sizeof(g16arGlobEraseCnt)+sizeof(g32arGlobReadCnt)+c32SlcQRamSize)/(cSctrPer4k*cSectorSize*g4kNumPerPlane))+
                           ((u16AddPageCnt)?1:0);
#endif/* if _EN_3072_BLOCK */
            uTotalPlaneOfWproPage+=u16AddPageCnt;

            if(uStartPageOffset&cBit7)
            {
                u16BkWproFreePtr=1;    // restore global read count
            }
            else
            {
                u16BkWproFreePtr=0;
            }

            uStartPageOffset=0;
        }
        else if((uWproIdx>=cWproGcDesF2hTab00)&&(uWproIdx<=cWproGcInfoPage))
        {
            if(gsWproInfo.uWPROFull||(uWproIdx==cWproGcInfoPage))
            {
                uTotalPlaneOfWproPage=gsGcInfo.uGCDes4KNumOfF2hTab/g4kNumPerPlane;
                uTotalPlaneOfWproPage<<=1;
            }
            else if(uStartPageOffset&cBit7)
            {
                // load partial table only load 8k
                uStartPageOffset&=~cBit7;
                uTotalPlaneOfWproPage=uStartPageOffset+1;
            }
            else
            {
                uTotalPlaneOfWproPage=gsGcInfo.uGCDes4KNumOfF2hTab/g4kNumPerPlane;
            }
        }
        else if(uWproIdx==cWproBadInfo)
        {
            uTotalPlaneOfWproPage=1+((cDiffMixTableHalfKb+cTotalRTDiffPoolHalfKb)/gSectorPerPlaneH);
        }
        else if(uWproIdx==cWproFeaturePg)
        {
            uTotalPlaneOfWproPage=(((sizeof(NVMEFEATVAR)-0x1000)/(gSectorPerPlaneH*0x200))+1);
        }
        else if(uWproIdx==cWproGetLogPg)
        {
            uTotalPlaneOfWproPage=((sizeof(GETLOGINFO)/(gSectorPerPlaneH*0x200))+1);
        }
        else if(uWproIdx==cWproSecurityBackupAllTsb)
        {
            uTotalPlaneOfWproPage=c16Tsb0Size/gSectorPerPlaneH;
        }

        // else if(uWproIdx==cWproGcBakF2hTab)
        // {
        //    uTotalPlaneOfWproPage=(cCacheF2hTabSctrSize/cSctrPer4k)/g4kNumPerPlane;
        // }
#if _EN_VPC_SWAP
        else if(uWproIdx==cWproCacheBlkVpCnt)
        {
            uTotalPlaneOfWproPage=(c16MaxBlockNum>>7)/gSectorPerPlaneH;

            if((c16MaxBlockNum>>7)%gSectorPerPlaneH)
            {
                uTotalPlaneOfWproPage++;
            }
        }
#endif
        else
        {
            uTotalPlaneOfWproPage=1;
        }

        if(u16SbufPtr&c16Bit15)
        {
            u16SbufPtr&=~c16Bit15;
            u16Opt=c16Bit1|c16Bit4|c16Bit10|c16Bit15;
#if _EN_RAID_GC
            if(!gsGcInfo.uHmbEnGcCache)
            {
                u16Opt|=cReadGcDesF2h;
            }
#endif
        }
        else
        {
            u16Opt=c16Bit4|c16Bit10|c16Bit15;
        }

#if _EN_VPC_SWAP
        if((uWproIdx==cWproCacheBlkVpCnt)&&(gsWproInfo.u16arWproIdxPagePtr[uWproIdx]==c16BitFF))
        {
            if(gsWproInfo.u16arWproIdxPagePtr[cWproCacheInfo]==c16BitFF)
            {
                debugDeadLock(0x00E9);
            }
            else
            {
                u16FBlock=gsWproInfo.u16arWproBlk[mGetWproBlkIdx(cWproCacheInfo)];
                u16FPage=mGetWproPagePtr(cWproCacheInfo);
            }
        }
        else
        {
            u16FBlock=gsWproInfo.u16arWproBlk[mGetWproBlkIdx(uWproIdx)];
            u16FPage=mGetWproPagePtr(uWproIdx);
        }
#else/* if _EN_VPC_SWAP */
        u16FBlock=gsWproInfo.u16arWproBlk[mGetWproBlkIdx(uWproIdx)];
        u16FPage=mGetWproPagePtr(uWproIdx);
#endif/* if _EN_VPC_SWAP */

        if((g16arDiffOffset[u16FBlock]!=c16BitFF)&&(mChkBitMask(g16arDiffOffset[u16FBlock], 0x0F)))
        {
            uDiffType2=1;
        }
        else
        {
            uDiffType2=0;
        }

        // uEccFail=0;
        uPageOfst=uStartPageOffset;

        while(uPageOfst<uTotalPlaneOfWproPage)
        {
            gpFlashAddrInfo=&garSrcAddrInfo[gsRwCtrl.uarFreeSrcQue[gsRwCtrl.u32FreeSrcFifoHead]];
            g16FBlock=u16FBlock;
            g16FPage=u16FPage+uPageOfst;
            gpFlashAddrInfo->uTsb4kIdx=0xFF;
            gpFlashAddrInfo->uSrcIdx=gsRwCtrl.uarFreeSrcQue[gsRwCtrl.u32FreeSrcFifoHead];
            tranAddrInfoTo2Ch(gpFlashAddrInfo);
            uIntlvAddr1=gIntlvAddr;
            uPlaneAddr1=gPlaneAddr;
            uStartCh=uCh=gCh;
            uEndCh=uStartCh+cWriteChNum;
#if _ENABLE_E2E_TAB
            g32FPageNoTran=mGetWproPagePtr(uWproIdx)+uPageOfst;
#endif

            if((uDiffType2==0)&&(gPlaneAddr==0)&&((uPageOfst+gPlaneNum)<=uTotalPlaneOfWproPage))
            {
                uAssignMultiPlane=1;
            }
            else
            {
                uAssignMultiPlane=0;
            }

            // for(uCh=uStartCh; uCh<uEndCh; uCh++)
            do
            {
                // setFLActCh(uCh);

                // Diff Type 2 block
                if(uDiffType2)
                {
                    getDiffAddr2(gpFlashAddrInfo, u16FBlock, gCh, gIntlvAddr, gPlaneAddr);
                    g16AbstrFBlock=g16FBlock;
                    g16FBlock=u16FBlock;
                }

                gSectorH=0;

                if(uAssignMultiPlane)
                {
                    mSetFRwParam(u16SbufPtr, gSectorPerPageH, u16Opt|c16Bit0, cReadData);
                    uSectorCnt=gSectorPerPageH;
                    gPlaneUNCSts[gCh]=0;
                }
                else
                {
                    mClrBitMask(gPlaneUNCSts[gCh], gPlaneAddr);
                    mSetFRwParam(u16SbufPtr, gSectorPerPlaneH, u16Opt, cReadData);
                    uSectorCnt=gSectorPerPlaneH;
                }

                // waitChCeBz(gCh, gIntlvAddr, 0);
                gsRwCtrl.u32FreeSrcFifoHead=(gsRwCtrl.u32FreeSrcFifoHead+1)&(cReadFifoDpt-1);

                // if(gsRwCtrl.u32FreeSrcFifoTrig!=gsRwCtrl.u32FreeSrcFifoHead)
                // {
                insSrcCmdList();
                // }
                chkPostReadFifo3();

                while(gsRwCtrl.usSrcCmdList.u16Cnt)
                {
                    trigFlCmdFfStep2();
                }

#if _ENABLE_E2E_TAB
                if((uAssignMultiPlane&&(!gPlaneUNCSts[gCh])||(!uAssignMultiPlane&&(!mChkBitMask(gPlaneUNCSts[gCh], gPlaneAddr))))&&
                   !chkReadTableCrcCnt(gpFlashAddrInfo))
#else
                if(uAssignMultiPlane&&(!gPlaneUNCSts[gCh])||(!uAssignMultiPlane&&(!mChkBitMask(gPlaneUNCSts[gCh], gPlaneAddr))))
#endif
                {
                    {
                        uEccFail=0;
                        break;    // uCh=gTotalChNum;
                    }
                }
                else
                {
                    uEccFail=1;
                }

                gsRwCtrl.u32FreeSrcFifoHead=(gsRwCtrl.u32FreeSrcFifoHead-1)&(cReadFifoDpt-1);
                gsRwCtrl.u32FreeSrcFifoTrig=gsRwCtrl.u32FreeSrcFifoTail=gsRwCtrl.u32FreeSrcFifoHead;
                gIntlvAddr=uIntlvAddr1;
                gPlaneAddr=uPlaneAddr1;
                uCh++;
                gCh=uCh;

                // if(u16Opt&c16Bit1)
                if(u16Opt&c16Bit1&&(uCh!=uEndCh))
                {
                    WORD u16StartBufIdx;

                    u16StartBufIdx=u16SbufPtr;

                    for(BYTE uLoop=0; uLoop<uSectorCnt; uLoop++)
                    {
#if _EN_RAID_GC
                        if(!gsGcInfo.uHmbEnGcCache)
                        {
                            rmSetBufRaid8Sts(u16StartBufIdx>>3, (BYTE)cb32BitTab[u16StartBufIdx&7]);
                        }
                        else
#endif
                        {
                            rmSetBuf8Sts(u16StartBufIdx>>3, (BYTE)cb32BitTab[u16StartBufIdx&7]);
                        }

                        u16StartBufIdx=addReadBufPtr(u16StartBufIdx, 1);
                    }
                }
            }
            while(uCh<uEndCh);

            if(uAssignMultiPlane)
            {
                u16SbufPtr+=gSectorPerPageH;
                uPageOfst+=gPlaneNum;
            }
            else
            {
                u16SbufPtr+=gSectorPerPlaneH;
                uPageOfst+=1;
            }
        }

        if(uEccFail)    // (H) WPRO
        {
            debugDeadLock(0x00E7);
        }

        if((uWproIdx==cWproQBootPg)||(uWproIdx==cWproQBWithDumyW))
        {
            if(gsQBootInfo.ubQBootValid)
            {
                u16BkWproFreePtr=gsWproInfo.u16WproFreePagePtr;
                bopCopyRam((LWORD)&gsCacheInfo, c32Tsb0SAddr+c32CacheInfoVarAddr,
                           sizeof(gsCacheInfo), cCopyTsb2Stcm|cBopWait);
                // bopCopyRam((LWORD)&gsRwCtrl, c32Tsb0SAddr+c32RwCtrlVarAddr, sizeof(gsRwCtrl), cCopyTsb2Stcm|cBopWait);
                bopCopyRam((LWORD)&gsGcInfo, c32Tsb0SAddr+c32GcInfoVarAddr,
                           sizeof(gsGcInfo), cCopyTsb2Stcm|cBopWait);
                RWCTRL *upRwCtrl=(RWCTRL *)(c32Tsb0SAddr+c32RwCtrlVarAddr);

                if(uWproIdx==cWproQBootPg)
                {
                    gsRwCtrl.u16OccFSkipSize=upRwCtrl->u16OccFSkipSize;
                    gsRwCtrl.u16OccFSkipStBufPtr=upRwCtrl->u16OccFSkipStBufPtr;    // gsRwCtrl.uOneShotPgPtr=upRwCtrl->uOneShotPgPtr;
                }

                bopCopyRam((LWORD)&gsWproInfo, c32Tsb0SAddr+c32WproInfoVarAddr,
                           sizeof(gsWproInfo), cCopyTsb2Stcm|cBopWait);
                gsWproInfo.u16WproFreePagePtr=u16BkWproFreePtr;
                copyTsb2Reg32(r32SkipRam, g32arTsb0[c16SkipRamVarSctrAddr], c32SkipRamVarSize/4);
#if _EN_VPC_SWAP
                bopCopyRam((LWORD)&g16arGlobEraseCnt,
                           c32Tsb0SAddr+c32EraseCntVarAddr,
                           sizeof(g16arGlobEraseCnt),
                           cCopyTsb2Stcm|cBopWait);
                bopCopyRam((LWORD)&g16arGlobReadCnt,
                           c32Tsb0SAddr+c32ReadCntVarAddr,
                           sizeof(g16arGlobReadCnt),
                           cCopyTsb2Tsb|cBopWait);
                bopCopyRam((LWORD)&garGlobReadCntHighByte,
                           c32Tsb0SAddr+c32ReadCntVarAddr+c32LowReadCntVarSize,
                           sizeof(garGlobReadCntHighByte),
                           cCopyTsb2Tsb|cBopWait);
                bopCopyRam((LWORD)&g32arPushReclaimQ,
                           c32Tsb0SAddr+c32ReadCntVarAddr+c32LowReadCntVarSize+c32HighReadCntVarSize,
                           sizeof(g32arPushReclaimQ),
                           cCopyTsb2Cpu1Dccm|cBopWait);
#else/* if _EN_VPC_SWAP */
                bopCopyRam((LWORD)&g16arGlobEraseCnt,
                           c32Tsb0SAddr+c32EraseCntVarAddr,
                           sizeof(g16arGlobEraseCnt),
                           cCopyTsb2Cpu1Dccm|cBopWait);
#if (_TSB_BiCS4)
                bopCopyRam((LWORD)&g32arGlobReadCnt,
                           c32Tsb0SAddr+c32ReadCntVarAddr,
                           sizeof(g32arGlobReadCnt),
                           cCopyTsb2Stcm|cBopWait);
#else
                bopCopyRam((LWORD)&g32arGlobReadCnt,
                           c32Tsb0SAddr+c32ReadCntVarAddr,
                           sizeof(g32arGlobReadCnt),
                           cCopyTsb2Tsb|cBopWait);
#endif
                bopCopyRam((LWORD)&g32arPushReclaimQ,
                           c32Tsb0SAddr+c32ReadCntVarAddr+sizeof(g32arGlobReadCnt),
                           sizeof(g32arPushReclaimQ),
                           cCopyTsb2Cpu1Dccm|cBopWait);
#endif/* if _EN_VPC_SWAP */
                bopCopyRam((LWORD)&g32arGcSrcBlkBitMap,
                           c32Tsb0SAddr+c32GcSrcBlkBitMapAddr,
                           sizeof(g32arGcSrcBlkBitMap),
                           cCopyTsb2Stcm|cBopWait);
#if (!_EN_VPC_SWAP)
                bopCopyRam((LWORD)&g32arGcInvaildPageBimap,
                           c32Tsb0SAddr+c32GcInvalidPageBitMapAddr,
                           sizeof(g32arGcInvaildPageBimap),
                           cCopyTsb2Tsb|cBopWait);
#endif

                if(uWproIdx==cWproQBootPg)
                {
                    bopCopyRam((LWORD)&gsRaidInfo, c32Tsb0SAddr+c32RaidInfoAddr,
                               sizeof(gsRaidInfo), cCopyTsb2Cpu1Dccm|cBopWait);
                }

                // bopCopyRam((LWORD)&gsRdCntCtrl, c32Tsb0SAddr+c32RdCntCtrlAddr,
                //           sizeof(gsRdCntCtrl), cCopyTsb2Cpu1Dccm|cBopWait);

                bopCopyRam((LWORD)&g32arHmbCrc,
                           c32Tsb0SAddr+c32HmbH2fCrcAddr,
                           sizeof(g32arHmbCrc),
                           cCopyTsb2Tsb|cBopWait);
                bopCopyRam((LWORD)&g32arGcDataCrc,
                           c32Tsb0SAddr+c32HmbGcDataCrcAddr,
                           sizeof(g32arGcDataCrc),
                           cCopyTsb2Tsb|cBopWait);
                bopCopyRam((LWORD)&g32arGcInfoCrc,
                           c32Tsb0SAddr+c32HmbGcInfoCrcAddr,
                           sizeof(g32arGcInfoCrc),
                           cCopyTsb2Tsb|cBopWait);
                bopCopyRam((LWORD)&g32arGcPtyCrc,
                           c32Tsb0SAddr+c32HmbGcPtCrcAddr,
                           sizeof(g32arGcPtyCrc),
                           cCopyTsb2Tsb|cBopWait);
#if (_EN_VPC_SWAP&&_EN_GCPWR&&(!_EN_RAID_GC))
                bopCopyRam((LWORD)&g32arGcInvaildPageBimap,
                           c32Tsb0SAddr+c32GcInvalidPageBitMapAddr,
                           sizeof(g32arGcInvaildPageBimap),
                           cCopyTsb2Tsb|cBopWait);
#endif
            }

            bopCopyRam(((LWORD)garTsb0[c16CacheF2hTabSIdx]),
                       ((LWORD)garTsb0[gsQBootInfo.u16QBVarPgSectorCnt]),
                       cCacheF2hSctrSize*0x200,
                       cCopyTsb2Tsb|cBopWait);

            // copy cache info data from H2f ram to cache info ram
            bopCopyRam((c32Tsb2SAddr),
                       ((LWORD)garTsb0[gsQBootInfo.u16QBVarPgSectorCnt+cCacheF2hSctrSize]),
                       c32CacheInfoTabRamSize,
                       cCopyTsb2Tsb|cBopWait);

            if(uWproIdx==cWproQBootPg)
            {
#if _EN_RAID_GSD
                resmRaidAllEngForQB();
#endif
            }
        }
        else if(uWproIdx==cWproCacheInfo)
        {
            // copy cacheInfo to TSB2 and globEraseCnt to &g16arTempGlobEraseCnt in rdlinkStep1()
            if(u16BkWproFreePtr)
            {
#if _EN_VPC_SWAP
                bopCopyRam((LWORD)&g16arGlobReadCnt, (cTsb0Addr+c32ProgCacheInfo_ReadCntStAddr),
                           sizeof(g16arGlobReadCnt), cCopyTsb2Tsb|cBopWait);
                bopCopyRam((LWORD)&garGlobReadCntHighByte, (cTsb0Addr+c32ProgCacheInfo_ReadCntStAddr+c32ProgCacheInfo_LowReadCntSize),
                           sizeof(garGlobReadCntHighByte), cCopyTsb2Tsb|cBopWait);
#else
#if (_TSB_BiCS4)
                bopCopyRam((LWORD)&g32arGlobReadCnt, (cTsb0Addr+c32CacheInfoTabRamSize+sizeof(g16arGlobEraseCnt)),
                           sizeof(g32arGlobReadCnt), cCopyTsb2Stcm|cBopWait);
#else
                bopCopyRam((LWORD)&g32arGlobReadCnt, (cTsb0Addr+c32CacheInfoTabRamSize+sizeof(g16arGlobEraseCnt)),
                           sizeof(g32arGlobReadCnt), cCopyTsb2Tsb|cBopWait);
#endif
#endif/* if _EN_VPC_SWAP */
            }
        }
    }
    else
    {
        bopClrRam(c32Tsb0SAddr+(u16SbufPtr*0x0200), gSectorPerPlaneH*0x0200, (LWORD)0xFFFFFFFF, cClrTsb|cBopWait);
    }    // --> End Of if (gsWproInfo.u16arWproIdxPagePtr[uWproIdx]!=0xFFFF)

#if _SCT_EN
    if(g16SctExtendedStatusCode==0xFFFF)
    {
        gSctIntByCmdFlag=1;    // SCT write same pattern need to reload
    }
#endif

#if _ENABLE_E2E_TAB
    gsE2eInfo.uTableType=cE2eUserDataBlk;
#endif
}    /* readWproPage */

void remWproPage(BYTE uIndex)
{
    BYTE uWproIdx=uIndex;

    if(gsWproInfo.u16arWproIdxPagePtr[uWproIdx]!=0XFFFF)
    {
        while(!gsWproInfo.u16arVpCnt[mGetWproBlkIdx(uWproIdx)])
            ;

        gsWproInfo.u16arVpCnt[mGetWproBlkIdx(uWproIdx)]--;

        if((!gsWproInfo.u16arVpCnt[mGetWproBlkIdx(uWproIdx)])&&(mGetWproBlkIdx(uWproIdx)!=gsWproInfo.uActIdx))
        {
            pushSpareBlock(gsWproInfo.u16arWproBlk[mGetWproBlkIdx(uWproIdx)], cPushNotErase);
            gsWproInfo.u16arWproBlk[mGetWproBlkIdx(uWproIdx)]=0xFFFF;
            gsWproInfo.uCnt--;

            while(!gsWproInfo.uCnt)
                ;
        }

        gsWproInfo.u16arWproIdxPagePtr[uWproIdx]=0XFFFF;
        gsWproInfo.uarWproIdxPtr[uWproIdx]=0xFF;
    }
}    /* remWproPage */







