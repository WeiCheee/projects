







#include "inc/ProType.h"
// #include "inc/FlashCtrl.h"
#include "inc/GlobVar0.h"
#include "inc/GlobVarS.h"
#include "inc/GlobVarT.h"
#include "inc/Reg.h"
#include "inc/FtlCtrl.h"
#include "inc/Mac.h"
#if _EN_CHRONUS_UART_DEBUG
#include "inc/DebugLog.h"
#include "inc/EventLogIDX.h"
#include "inc/EventLogFunctionIDX.h"
#endif

#if (_CPUID!=1)
void readH2fSgmtTable(WORD u16Hblock, WORD u16Hsgmt, BYTE uTabSgmtIdx, BYTE uLoadSgmtCnt)
{
    // BYTE uTabSgmtPlaneAddr, uTabSgmtHalfKb;
    BYTE uLoadH2fTabSctrCnt;
    WORD u16NowNodeIdx;
    LWORD u32SectOffset;

    invalidateDCache();

    u16NowNodeIdx=gsRwCtrl.uarFreeSrcQue[gsRwCtrl.u32FreeSrcFifoHead];
    gpFlashAddrInfo=&garSrcAddrInfo[u16NowNodeIdx];
    u32SectOffset=u16Hsgmt<<2;
    // uTabSgmtPlaneAddr=uTabSgmtHalfKb>>gsCacheInfo.uSctrPerPlaneShift;
    gSectorH=u32SectOffset&(gSectorPerPlaneH-1);
    g16FBlock=g16arH2fTabBlk[mGetH2fTabBlkIndex(u16Hblock)];
    g32FPageNoTran=((mGetH2fTabPagePtr(u16Hblock)*g16H2fTabSctrSize)+u32SectOffset)>>cSctrTo4kShift;
    // g32FPageNoTran=((mGetH2fTabPagePtr(u16Hblock)*g16H2fTabSctrSize)>>gsCacheInfo.uSctrPerPlaneShift)+uTabSgmtPlaneAddr;
    // g16FPage=g32FPageNoTran;
    gpFlashAddrInfo->uTsb4kIdx=0xFF;
    gpFlashAddrInfo->uSrcIdx=u16NowNodeIdx;
    tranAddrInfo(gpFlashAddrInfo);

    // tranCeNum(gpFlashAddrInfo);
    uLoadH2fTabSctrCnt=uLoadSgmtCnt<<2;

    if((gSectorH+uLoadH2fTabSctrCnt)>gSectorPerPlaneH)
    {
        mSetFRwParam(c16RH2fTabSIdx+(uTabSgmtIdx<<2), uLoadH2fTabSctrCnt, c16Bit0|c16Bit4|c16Bit11|c16Bit15, cH2fRead1kTab);
    }
    else
    {
        mSetFRwParam(c16RH2fTabSIdx+(uTabSgmtIdx<<2), uLoadH2fTabSctrCnt, c16Bit4|c16Bit11|c16Bit15, cH2fRead1kTab);
    }

#if _GREYBOX
    if((gsGbInfo.uGreyBoxItem==cRAIDDecOnH2f1kTab))
    {
        if(g16GbFBlock==0)
        {
            g16GbFBlock=gpFlashAddrInfo->u16BufPtr;
        }
    }
#endif

    gpFlashAddrInfo->uPrdPtr=uTabSgmtIdx;
    gpFlashAddrInfo->uPlaneCnt=1;

    gsRwCtrl.u32FreeSrcFifoHead=(gsRwCtrl.u32FreeSrcFifoHead+1)&(cReadFifoDpt-1);
}    /* readH2fSgmtTable */

#endif    // (_CPUID!=1)

void initH2fTabFblock(BYTE uPopOpt)
{
    BYTE uIdx;

/*
   *  if(mChkCacheInfoFlag(cH2fProgramFail)||mChkCacheInfoFlag(cMoveProgramFail))
   *  {
   *      mSetCacheInfoFlag(cH2fTabBlockFull);
   *      gsCacheInfo.u16H2fTabFreePagePtr=gsCacheInfo.u16H2fTabPagePerBlk3;    // g16PagePerBlock3;
   *
   #if (_PRJ_ISP||_PRJ_SEC)
   *      progCacheInfoTab();
   #endif
   *      mClrCacheInfoFlag(cH2fProgramFail);
   *      mClrCacheInfoFlag(cMoveProgramFail);
   *  }
   */
    if(mChkCacheInfoFlag(cH2fTabBlockFull))
    {
#if (_CPUID==1)    // For last Page Program Fail!!
        waitAllChCeBz();
#else
        waitAllChCeBzCore0();
#endif

        if((g16arH2fTabBlk[gsCacheInfo.uActH2fTabBlkIdx]!=0xFFFF)&&(g16arH2fTabBlkVpCnt[gsCacheInfo.uActH2fTabBlkIdx]==0))
        {
            pushH2fBlk(gsCacheInfo.uActH2fTabBlkIdx);
        }

        // gsCacheInfo.uActH2fTabBlkIdx=bopSrchRam((LWORD)g16arH2fTabBlk, 0xFFFF, c32BitFF, 0, c16MaxH2fTabBlkNum,
        // cBopSrchDat|cBopWordMo|cBopWait);
        for(uIdx=0; uIdx<gMaxH2fTabBlkNum; uIdx++)
        {
            if(g16arH2fTabBlk[uIdx]==c16BitFF)
            {
                gsCacheInfo.uActH2fTabBlkIdx=uIdx;
                break;
            }
        }

        while(uIdx>=c16MaxH2fTabBlkNum)
            ;

#if (_CPUID==1)
        g16arH2fTabBlk[gsCacheInfo.uActH2fTabBlkIdx]=popSpareBlock(cPopMinErsCnt|cPopSlcBlock|uPopOpt);
#else
        if(uPopOpt&cPopSkipChkSts)
        {
#if _GREYBOX
            if((gsGbInfo.uGreyBoxItem==cUGSDProgH2fTableID)&&(gsGbInfo.uGreyBoxOpt==cVOpErasing)&&(gsGbInfo.uStag==cVsIdl))
            {
                trigGreyBox(cTrue);
            }
            else if((gsGbInfo.uGreyBoxItem==cUGSDonEraseFail)&&(gsGbInfo.uStag==cVsIdl)&&(gsGbInfo.uGreyBoxOpt==cVOpPopH2fTableBfErase))
            {
                gsGbInfo.uStag=cVsTriggered;
            }
            else if((gsGbInfo.uGreyBoxItem==cUGSDonEraseFail)&&(gsGbInfo.uGreyBoxOpt==cVOpPopH2fTableAfErase)&&(gsGbInfo.u32BkValue==cSuccess))
            {
                gsGbInfo.u32BkValue|=c32Bit1;
            }
#endif
            popSpareBlockCore0(cPopMinErsCnt|cPopSlcBlock|uPopOpt);    // prepopBlkEraseCore0(cPopMinErsCnt|cPopSlcBlock|uPopOpt);
        }
        else
        {
            g16arH2fTabBlk[gsCacheInfo.uActH2fTabBlkIdx]=popSpareBlockCore0(cPopMinErsCnt|cPopSlcBlock|uPopOpt);    // gsTskFifoCtrl.u16PopFBlk;
            // gsTskFifoCtrl.u16PopFBlk=c16FBlockInitValue;
        }
#endif/* if (_CPUID==1) */
        gsCacheInfo.uH2fTabBlockCnt++;

        if(gsCacheInfo.uH2fTabBlockCnt>=gsGcInfo.uGcH2fTabbHiThr)
        {
            mPushGcQue(cGcTypH2fTab);
        }

        gsCacheInfo.u16H2fTabFreePagePtr=0;
        gsCacheInfo.u32H2fTabBlkSerial=addPtrBy1(gsCacheInfo.u32H2fTabBlkSerial, c32MaxCacheSerial);
        g32arH2fTabBlkSn[gsCacheInfo.uActH2fTabBlkIdx]=gsCacheInfo.u32H2fTabBlkSerial;
        // g16arH2fTabBlkVpCnt[gsCacheInfo.uActH2fTabBlkIdx]=0;
        mClrCacheInfoFlag(cH2fTabBlockFull);

#if _EN_Liteon_ErrHandle
        if(gJdgBootGCFlag&(cBootH2FGC))
        {
            while(gsCacheInfo.uH2fTabBlockCnt>gMaxH2fTabBlkNum)
                ;

            if(gsCacheInfo.uH2fTabBlockCnt<12)
            {
                gJdgBootGCFlag&=~(cBootH2FGC);
                mClrGcFlag(cPwOnH2FGcF);
            }
        }
        else
        {
            while(gsCacheInfo.uH2fTabBlockCnt>(gMaxH2fTabBlkNum-2))
                ;
        }
#else/* if _EN_Liteon_ErrHandle */
        while(gsCacheInfo.uH2fTabBlockCnt>gMaxH2fTabBlkNum)
            ;
#endif/* if _EN_Liteon_ErrHandle */
        /*
           * #if _PRJ_ISP
           *      if (!gsGcInfo.ubPartGcH2fTab&&(chkBgdClnH2fTabBlk()==cTrue))
           *      {
           *          gsGcInfo.ubPartGcH2fTab=1;
           *      }
           * #endif
           */
    }
}    /* initH2fTabFblock */

// #define g32SectorPerFBlockSlc (g16PagePerBlock3_SLC*gSectorPerPlaneH)

BYTE jdgH2fTabBlockFull()
{
    if(gsCacheInfo.u16H2fTabFreePagePtr==gsCacheInfo.u16H2fTabPagePerBlk3)
    {
        mSetCacheInfoFlag(cH2fTabBlockFull);

        if(!g16arH2fTabBlkVpCnt[gsCacheInfo.uActH2fTabBlkIdx])
        {
            while(!gsCacheInfo.uH2fTabBlockCnt)
                ;

            pushH2fBlk(gsCacheInfo.uActH2fTabBlkIdx);

            NLOG(cLogHost,
                 H2FTAB_C,
                 7,
                 "H2fBlk is Full, pushH2fBlk! H2fBlk[0x%04x]=0x%04x, H2fBlkCnt=0x%04x, CacheInfo.u32H2fSn=0x%08x, gcTime=0x%08x",
                 gsCacheInfo.uActH2fTabBlkIdx,
                 (WORD)g16arH2fTabBlk[gsCacheInfo.uActH2fTabBlkIdx],
                 gsCacheInfo.uH2fTabBlockCnt,
                 gsCacheInfo.u32H2fTabBlkSerial>>16,
                 gsCacheInfo.u32H2fTabBlkSerial,
                 gsGcInfo.u32BgdGcEndTime>>16,
                 gsGcInfo.u32BgdGcEndTime);
        }
        else
        {
            NLOG(cLogHost,
                 H2FTAB_C,
                 7,
                 "jdgH2fTabBlockFull! H2fVpC[0x%04x]=0x%04x, H2fBlk[0x%04x]=0x%04x, H2fBlkCnt=0x%04x, gcTime=0x%08x",
                 gsCacheInfo.uActH2fTabBlkIdx,
                 (WORD)g16arH2fTabBlkVpCnt[gsCacheInfo.uActH2fTabBlkIdx],
                 gsCacheInfo.uActH2fTabBlkIdx,
                 (WORD)g16arH2fTabBlk[gsCacheInfo.uActH2fTabBlkIdx],
                 gsCacheInfo.uH2fTabBlockCnt,
                 gsGcInfo.u32BgdGcEndTime>>16,
                 gsGcInfo.u32BgdGcEndTime);
        }

        return cTrue;
    }
    else
    {
        return cFalse;
    }
}    /* jdgH2fTabBlockFull */

// move to FtlPub.c
/*
   * void pushH2fBlk(BYTE uTabBlkIdx)
   * {
   * #if (_CPUID==1)
   *  pushSpareBlock(g16arH2fTabBlk[uTabBlkIdx], cPushNotErase);
   * #else
   *  pushSpareBlockCore0(g16arH2fTabBlk[uTabBlkIdx], cPushNotErase);
   * #endif
   *  gsCacheInfo.uH2fTabBlockCnt--;
   *
   *  g16arH2fTabBlk[uTabBlkIdx]=0xFFFF;
   *  g32arH2fTabBlkSn[uTabBlkIdx]=c32InitSerialVal;
   * }
   *
   * void setH2fTabPagePtr(WORD u16Hblock, BYTE uTabBlkIdx, WORD u16TabPagePtr)
   * {
   *  BYTE uOrgTabBlkIdx;    // =mGetH2fTabBlkIndex(u16Hblock);
   *
   *  if(uTabBlkIdx!=0xFF)
   *  {
   *      g16arH2fTabBlkVpCnt[uTabBlkIdx]++;
   *  }
   *
   *  // if(uOrgTabBlkIdx!=0xFF)
   *  if(!mChkH2fTabNullF(u16Hblock))
   *  {
   *      uOrgTabBlkIdx=mGetH2fTabBlkIndex(u16Hblock);
   *      g16arH2fTabBlkVpCnt[uOrgTabBlkIdx]--;
   *
   *      if((!g16arH2fTabBlkVpCnt[uOrgTabBlkIdx])&&(uOrgTabBlkIdx!=gsCacheInfo.uActH2fTabBlkIdx))
   *      {
   *          pushH2fBlk(uOrgTabBlkIdx);
   *      }
   *  }
   *
   *  // garH2fTabBlkIndex[u16Hblock]=uTabBlkIdx;
   *  // g16arH2fTabPagePtr[u16Hblock]=u16TabPagePtr;
   *  mSetH2fTabEntry(u16Hblock, uTabBlkIdx, u16TabPagePtr);
   *
   *  if(uTabBlkIdx!=0xFF)
   *  {
   *      if(mChkH2fTabNullF(u16Hblock))
   *      {
   *          mClrH2fTabNullF(u16Hblock);
   *      }
   *  }
   *  else
   *  {
   *      mSetH2fTabNullF(u16Hblock);
   *
   *      if(gsGcInfo.u16GcIncompleteSrchHblk==u16Hblock)
   *      {
   *          gsGcInfo.u16GcIncompleteSrchFblk=cInvldFBlk;
   *          gsGcInfo.u16GcIncompleteSrchHblk=cInvldHBlk;
   *          gsGcInfo.u16GcIncompleteSrchHpg=0xFFFF;
   *          gsGcInfo.uGcIncompleteSrchSrcBlkPtr=0xFF;
   *      }
   *  }
   * }
   */

#if (_CPUID==1)
BYTE waitH2fProcess()
{
    ADDRINFO usTmpAddrInfo;
    BYTE uPageOfst;

    for(uPageOfst=0; uPageOfst<gPage4kPerH2fTab; uPageOfst+=g4kNumPerPage)
    {
        // wait H2f Table Ch Command fifo
        setWriteDes(uPageOfst, &usTmpAddrInfo, cWriteH2fTab);
        setFLAddrActCh(usTmpAddrInfo.uCh, &usTmpAddrInfo);

        // waitCmdFifoDpt(usTmpAddrInfo.uCh,, &usTmpAddrInfo);
        waitChCeBz(gActiveCh, gIntlvAddr, gsRwCtrl.uRdyTyp[gActiveCh][gIntlvAddr]);

        // mask error handle temp,
        /*
           * if(mChkSataWriteAbort&&!mChkInSataErrOrGc)
           * {
           *  gbSataErrFromProgH2f=1;
           *  gsSataErrLog.u16BkPrgoH2f_AbortCnt++;
           *  // gsSataErrLog.u16BkProgH2f_HBlk=u16Hblock;
           *  return cFalse;
           * }
           */
    }

    return cTrue;
}    /* waitH2fProcess */

#if _EN_PROGFAILLOG
void setH2fBufFlag(WORD u16BufIdx, WORD u16RwOpt)
{
    WORD u16Cnt;

    if(u16RwOpt&c16Bit1)
    {
        u16BufIdx>>=5;
        u16Cnt=(g16H2fTabSctrSize>>5);

        while(u16Cnt)
        {
            rmSetBuf32Sts(u16BufIdx, 0xFFFFFFFF);
            u16BufIdx++;
            u16Cnt--;
        }
    }
    else
    {
#if _EN_RAID_H2F
        u16BufIdx=(u16BufIdx+cRaidHTabTotalSctrCnt)>>5;
        rmSetBuf32Sts(u16BufIdx, 0xFFFFFFFF);
#endif
    }
}    /* setH2fBufFlag */

#endif/* if _EN_PROGFAILLOG */

void progH2fTable(WORD u16SbufPtr, WORD u16Hblock, WORD u16RwOpt, WORD u16Caller, BYTE uSpecialOpt)
{
    ADDRINFO usTmpAddrInfo;
    BYTE uPageOfst, uCh, uStsFlag=0;
    BYTE uBzBitMap=0, uOpTyp;
    WORD u16BkupBufPtr=u16SbufPtr;

    if(mChkDummyWrite)
    {
        return;
    }

#if (C_Log_SaveMask&C_Debug_P2&DEBUG_Bill_FTL)    // 20181031_Bill FTL progH2f
    NLOG(cLogFTL,
         H2FTAB_C,
         5,
         " progH2fTable() Start u16SbufPtr = 0x%04X ,u16Hblock = 0x%04X ,u16RwOpt = 0x%04X ,u16Caller = 0x%04X ,uSpecialOpt = 0x%04X ",
         u16SbufPtr,
         u16Hblock,
         u16RwOpt,
         u16Caller,
         uSpecialOpt);
#endif

#if _EN_RAID_H2F
    hdmaEncRam(u16SbufPtr, cRaidHTabTotalSctrCnt, 0xFFFF, cHdmaNotWait, cRaidHTabBlk, cSLC);
#endif

#if _EN_PROGFAILLOG
    if(!mChkProgFailFlag(cPfH2fTabBlk))
    {
        gsProgFailInfo.u16SbufPtr[gsProgFailInfo.uProgH2fCnt]=u16SbufPtr;
        gsProgFailInfo.u16Hblock[gsProgFailInfo.uProgH2fCnt]=u16Hblock;
        gsProgFailInfo.uProgH2fCnt++;
    }
#endif

    if(uSpecialOpt&cInBoot)
    {
        if(u16Hblock==c16BitFF)
        {
            uOpTyp=cPwrOnDummyProg;    // power on H2f block padding dummy page case
        }
        else
        {
            /*
               * if(u16Caller==cInreFreshH2f_00)
               * {
               *  uOpTyp=cRefreshH2f;
               * }
               * else
               */
            {
                uOpTyp=cBootProgData;
            }
        }
    }
    else
    {
        uOpTyp=cProgData;
    }

    while(mChkCacheInfoChangeFlag(cH2fChg))
    {
        u16SbufPtr=u16BkupBufPtr;    // for program failed re-Programing
        uStsFlag=0;
#if 1    // _EN_PROGFAILLOG
        if((g32Core1State<cCore1BootState_Finished)&&(uSpecialOpt&cInBootWaitAllDie))
        {
            if(mChkCacheInfoFlag(cH2fProgramFail))
            {
                NLOG(cLogCore1, H2FTAB_C, 1, "progH2fTable() setH2fBufFlag, u16SbufPtr= 0x%04X", u16SbufPtr);
                setH2fBufFlag(u16SbufPtr, u16RwOpt);
            }
        }
#endif

        initH2fTabFblock(0);

        if(waitH2fProcess()==cFalse)
        {
            return;    // Sata Error
        }

        for(uPageOfst=0; uPageOfst<gPage4kPerH2fTab; uPageOfst+=g4kNumPerPage)
        {
            // wait H2f Table Ch Command fifo
            setWriteDes(uPageOfst, &usTmpAddrInfo, cWriteH2fTab);

            setFLAddrActCh(usTmpAddrInfo.uCh, &usTmpAddrInfo);
            gSectorH=0;

            gpFlashAddrInfo->uPlaneCnt=gPlaneNum;

            if(!mChkBitMask(uBzBitMap, garChMapTable[gActiveCh]))
            {
                mSetBitMask(uBzBitMap, garChMapTable[gActiveCh]);
            }

            mSetFRwParam(u16SbufPtr, gSectorPerPageH, u16RwOpt, uOpTyp);

            gpFlashAddrInfo->u16BufPtr=u16SbufPtr;
            mSetTabSpr(gpFlashAddrInfo, cBit6);    // gpFlashAddrInfo->uTabSpar=2;

            if((gSparePtrHead[gActiveCh]&(cSpareRegisterCnt-1))<4)
            {
                rmSelSprGroup(0);
            }
            else
            {
                rmSelSprGroup(1);
            }

            setSprByteOfTabBlk(cH2fTableID,
                               u16Hblock,
                               gsCacheInfo.u16H2fTabFreePagePtr,
                               gsCacheInfo.uActH2fTabBlkIdx,
                               gsCacheInfo.u32H2fTabBlkSerial,
                               gSparePtrHead[gActiveCh]&3,
                               u16Caller);

#if _ENABLE_E2E_TAB
            genInternalDataCrc(gpFlashAddrInfo->u16BufPtr,
                               gpFlashAddrInfo->uRwHalfKb,
                               gpFlashAddrInfo->u32FPageNoTran<<cSctrTo4kShift,
                               cE2eH2fBlk);
#endif
            flashProgPage(mGetWriteBuf, mGetProgSctrCnt, mGetWriteOpt);

            gSparePtrHead[gActiveCh]=addPtrBy1(gSparePtrHead[gActiveCh], cSpareRegisterCnt);
            gSparePtrTail[gActiveCh]=addPtrBy1(gSparePtrTail[gActiveCh], cSpareRegisterCnt);

            if((u16RwOpt&c16Bit3)&&mChkFLOption(cEnCacheProg)&&(g16FPage!=(g16PagePerBlock1_SLC-1)))
            {
                gsRwCtrl.uRdyTyp[gActiveCh][gIntlvAddr]=cRdyTypSlcCacheW;
                setBzInfo(cCacheProgData, gActiveCh, gIntlvAddr);
            }
            else
            {
                setBzInfo(gOpTyp, gActiveCh, gIntlvAddr);
            }

            gsRwCtrl.usWaitInfo[gActiveCh][gIntlvAddr].uStatusErrStop=1;
#if _GREYBOX
            if(gsGbInfo.uGreyBoxItem==cErrHdlProgH2fTableID)
            {
                if((g16GbSetPgFailFpage==c16BitFF)&&(gGbSetPgFailIntlvAddr==cBitFF)&&(gGbSetPgFailCh==cBitFF)&&(gGbSetPgFailPlane==cBitFF))
                {
                    g16GbSetPgFailFpage=gsRwCtrl.usWaitInfo[usTmpAddrInfo.uCh][gIntlvAddr].u16FPage;
                    gGbSetPgFailIntlvAddr=gIntlvAddr;
                    gGbSetPgFailCh=gCh;
                    gGbSetPgFailPlane=gPlaneAddr;
                }
            }
#endif
            u16SbufPtr+=gpFlashAddrInfo->uPlaneCnt*gSectorPerPlaneH;
        }

        // currently, waitCmdFifoDpt is no used in 60/63
        // for overlap progH2F busy time, mark wait prog done
        // prog error may handle by raid recover.

#if 0    // _EN_PROGFAILLOG
        waitH2fProcess();
        waitCmdFifoDpt(usTmpAddrInfo.uCh, &usTmpAddrInfo);    // for check program fail
#else
        // mClrCacheInfoFlag(cH2fProgramFail);    // temp disable program error handle.
#endif

        // if((mChkCacheInfoFlag(cH2fProgramFail)==0)&&!mChkCacheInfoFlag(cMoveProgramFail))
        // {
        if((g32Core1State<cCore1BootState_Finished)&&(uSpecialOpt&cInBootWaitAllDie))
        {
            waitH2fProcess();

            for(uCh=0; uCh<gTotalChNum; uCh++)
            {
                setFLActCh(uCh);
#if _EN_PROGFAILLOG
                while(rmChkCmdFifoBz)
                    ;

                if(rmChkStatusFail)
                {
                    uStsFlag|=rmGetOPResultFlag;
                    rmResetEccSts;
                    rmCmdQueResume;

                    while(rmChkCmdFifoBz)
                        ;
                }
#endif
            }

            if(uStsFlag&cBit3)
            {
                NLOG(cLogCore1, H2FTAB_C, 0, "progH2fTable() Program Fail!! H2fChg!!");

                mSetCacheInfoChangeFlag(cH2fChg);
                mSetCacheInfoFlag(cH2fTabBlockFull);
                mSetCacheInfoFlag(cH2fProgramFail);
            }
            else
            {
                mClrCacheInfoChangeFlag(cH2fChg);

                if(mChkCacheInfoFlag(cH2fProgramFail))
                {
                    mClrCacheInfoFlag(cH2fProgramFail);
                }
            }
        }
        else
        {
            mClrCacheInfoChangeFlag(cH2fChg);
        }

        if((u16Hblock!=c16BitFF)&&(uStsFlag==0))    // not power on H2f block padding dummy page case
        {
            if(u16Hblock&c16DropH2fTab)    // Trim command case, remove HMB link???
            {
                setH2fTabPagePtr(u16Hblock&~c16DropH2fTab, 0xFF, gsCacheInfo.u16H2fTabFreePagePtr);
            }
            else
            {
                setH2fTabPagePtr(u16Hblock, gsCacheInfo.uActH2fTabBlkIdx, gsCacheInfo.u16H2fTabFreePagePtr);
            }
        }

        // }
        // else
        // {
        //     mSetCacheInfoChangeFlag(cH2fChg);    // do again
        // }

        gsCacheInfo.u16H2fTabFreePagePtr++;    // =gTotalPlaneOfH2fTab;

        if((uOpTyp!=cPwrOnDummyProg)&&(jdgH2fTabBlockFull()))
        {
            if(!(uSpecialOpt&cInBoot))
            {
                if(!mChkHandlePcieErrF)    // !(mChkSataWriteAbort&&(!mChkInSataErrOrGc)))
                {
                    if(!mChkGcFlag(cGcSkipPrgCacheInfo))    // &&!gsCacheInfo.ubSkipPrgCacheInfo)
                    {
                        progCacheInfoTab();
                    }
                }

                // else
                // {
                //    gsCacheInfo.ubPerAbortCacheInfo=1;
                // }
            }
        }
    }    // --> End Of while (gsCacheInfo.ubH2fChg)

    if(uSpecialOpt&cBypassWaitChDone)
    {
        gsTskFifoCtrl.usProgH2fPara.uWaitChBitMap|=uBzBitMap;
    }
    else
    {
        if(uSpecialOpt&cInBootWaitAllDie)
        {
            waitAllChCeBz();
        }
        else
        {
#if _EN_PROGFAILLOG
            gsTskFifoCtrl.usProgH2fPara.uWaitChBitMap|=uBzBitMap;

            while((rmChkSysCmdFifoBz&uBzBitMap)||rmChkSysStsErr)
            {
                chkAllChStatusFail(cNull);
            }

            gsTskFifoCtrl.usProgH2fPara.uWaitChBitMap=0;
#else
            while(rmChkSysCmdFifoBz&uBzBitMap)
                ;
#endif
        }

#if _EN_PROGFAILLOG
        gsProgFailInfo.uProgH2fCnt=0;
#endif
    }

    if(uSpecialOpt&cInBoot)
    {
        gsRdlinkInfo.ubSaveCacheInfo=1;
    }
}    /* progH2fTable */

#endif    // cpuid==1

void save1stCacheInfoBefW()
{
    if(gsRdlinkInfo.ubSaveCacheInfo)
    {
        progCacheInfoTab();
    }
}







