







#if 0
void popCacheF2hTabInRdlink(WORD u16HBlock)
{
    WORD u16RslOfst, u16H4k, u16StartUnit=0;
    WORD u16UnitLen=g16TotalPgPerF2hTab;
    BYTE uFlag, uBank;
    LWORD u32SrchF4kBase, u32SrchAddr;
    BYTE uLoop, uFBlockLsb;
    F2HTABLE *upF2hTab;
    WORD u16FBlock;
    LWORD *u32pH2FTab=(LWORD *)garTsb0[0];
    LWORD u32NewF4K;
    LWORD *upUpdH2fTab;

    u16HBlock=u16HBlock&(~c16Bit15);

    while(u16HBlock>=g16TotalHBlock)
        ;

    // if(gsCacheInfo.u15ActiveH2fTab!=u16HBlock)
    // {
    swapH2fTable(u16HBlock, c16Tsb0SIdx, cWaitReadDone);
    // }

    // for wait read table ready
    waitCmdAllDone(cWaitTrigRCnt|cWaitCmdBz);

    // for reset H2f table no wait.
    while(rmChkHdmaBz)
        ;

    for(uLoop=0; uLoop<gsRdlinkInfo.uRebuCachebCnt; uLoop++)
    {
        u16StartUnit=0;

        if(uLoop==(gsRdlinkInfo.uRebuCachebCnt-1))
        {
            u32SrchAddr=(LWORD)garCacheF2hTab;
            upF2hTab=garCacheF2hTab;
        }
        else
        {
            u32SrchAddr=(LWORD)garTsb0[c16Tsb0SIdx+512+uLoop*((c32CacheF2hRamSize+c32F2hRsvRamSize)>>9)];
            upF2hTab=(F2HTABLE *)garTsb0[c16Tsb0SIdx+512+uLoop*((c32CacheF2hRamSize+c32F2hRsvRamSize)>>9)];
        }

        u16FBlock=gsRdlinkInfo.u16arReBuCacheBlock[uLoop];
        uBank=gsRdlinkInfo.uarReBuCacheBlockBank[uLoop];
        uFBlockLsb=(!mChkMlcMoBit(u16FBlock));

        if(bopSrchRam((LWORD)u32SrchAddr, (LWORD)u16HBlock<<16, 0xFFFF0000, u16StartUnit, u16UnitLen,
                      cBopSrchDat|cBopLwordMo|cBopWait|cBopNotRstFlag)!=0xFFFF)
        {
            // while (rmChkHdmaBz);

            do
            {
                u16StartUnit=rmGetSrchRslOfst;

                if((upF2hTab+u16StartUnit)->u16HBlock==u16HBlock)
                {
                    u16RslOfst=u16StartUnit;    // div(u16StartUnit, 2);

                    do
                    {
                        uFlag=0;
                        u16StartUnit++;

                        if(u16StartUnit<u16UnitLen)
                        {
                            if((upF2hTab+u16RslOfst+1)->u16HBlock==u16HBlock)
                            {
                                uFlag=1;
                            }
                            else
                            {
                                rmSetBopDesAddr(u16StartUnit);
                                rmTrigBopOpWoPause(cBopSrchOp);
                            }
                        }

                        u16H4k=(upF2hTab+u16RslOfst)->u16HPage;
                        u32SrchF4kBase=(LWORD)(uBank+1)*g16TotalPgPerF2hTab-1;
                        u32NewF4K=u32SrchF4kBase-(u16RslOfst%g16TotalPgPerF2hTab);
                        upUpdH2fTab=u32pH2FTab+u16H4k;

                        if((WORD)(mGetSrcFBlkAddr(u32pH2FTab[u16H4k])!=u16FBlock)||(mGetSrcFPageAddr(u32pH2FTab[u16H4k])<u32NewF4K))
                        {
                            setH2fSrcBlock(upUpdH2fTab, u16FBlock, u32NewF4K, uFBlockLsb, cTrue);
                        }

                        (upF2hTab+u16RslOfst)->u16HBlock|=c16Bit15;

                        u16RslOfst++;
                    }
                    while(uFlag!=0);
                }
                else
                {
                    u16StartUnit++;

                    if(u16StartUnit<u16UnitLen)
                    {
                        rmSetBopDesAddr(u16StartUnit);
                        rmTrigBopOpWoPause(cBopSrchOp);
                    }
                }

                while(rmChkBopBz)
                    ;
            }
            while(rmChkSrchValFind&&(u16StartUnit<u16UnitLen));
        }
    }

    rmSetSrchDefault;
}    /* popCacheF2hTabInRdlink */

void flushF2hTableInRdlink()
{
    BYTE uLoop;
    WORD u16SbufPtr, u16HBlock;
    LWORD u32BankStartPage;

    F2HTABLE *upF2hTab[cMaxReBuBankNum], *upEndF2hTab[cMaxReBuBankNum];

    for(uLoop=0; uLoop<gsRdlinkInfo.uRebuCachebCnt; uLoop++)
    {
        if(uLoop==(gsRdlinkInfo.uRebuCachebCnt-1))
        {
            u16SbufPtr=c16CacheF2hTabSIdx;
            upF2hTab[uLoop]=garCacheF2hTab+g16TotalPgPerF2hTab-1;
            upEndF2hTab[uLoop]=garCacheF2hTab;
        }
        else
        {
            u16SbufPtr=c16WriteSIdx+512+uLoop*((c32CacheF2hRamSize+c32F2hRsvRamSize)>>9);
            upF2hTab[uLoop]=(F2HTABLE *)garTsb0[u16SbufPtr]+g16TotalPgPerF2hTab-1;
            upEndF2hTab[uLoop]=(F2HTABLE *)garTsb0[u16SbufPtr];
        }

        u32BankStartPage=(LWORD)gsRdlinkInfo.uarReBuCacheBlockBank[uLoop]*g16TotalPgPerF2hTab;

        if(readCacheF2hTab(u16SbufPtr, gsRdlinkInfo.u16arReBuCacheBlock[uLoop], u32BankStartPage+g16ValidPgPerF2hTab, cF2hTableID)!=cTrue)
        {
            // buildBlockF2hTab(gsRdlinkInfo.u16arReBuCacheBlock[uLoop], div(u32BankStartPage, gTotalIntlvChNum*g4kNumPerPage), 0xFFFF, 0,
            // upEndF2hTab[uLoop]);
            buildBlockF2hTab(gsRdlinkInfo.u16arReBuCacheBlock[uLoop], u32BankStartPage/(gTotalIntlvChNum*g4kNumPerPage), 0xFFFF, 0,
                             upEndF2hTab[uLoop]);
        }
        else
        {
            restoCacheF2hTab(u16SbufPtr);
        }
    }

    for(uLoop=0; uLoop<gsRdlinkInfo.uRebuCachebCnt; uLoop++)
    {
        while(cTrue)
        {
            if(upF2hTab[uLoop]==upEndF2hTab[uLoop])
            {
                break;
            }
            else
            {
                u16HBlock=upF2hTab[uLoop]->u16HBlock;

                if(!(u16HBlock&c16Bit15))    // bit 15 is for seached HBlock
                {
                    popCacheF2hTabInRdlink(u16HBlock);
                }

                upF2hTab[uLoop]--;

                if(mChkCacheInfoChangeFlag(cH2fChg))
                {
                    // cntF2k();
                    gsRdlinkInfo.u16ProgHCnt++;
                    progH2fTableCore0(c16Tsb0SIdx, u16HBlock, c16Bit0|c16Bit2|c16Bit15, cInflushF2hTableInRdlink_00, 1|cBit7);
                    gsRdlinkInfo.ubSaveCacheInfo=1;
                }
            }
        }
    }
}    /* flushF2hTableInRdlink */

#endif/* if 0 */

#if !_EN_RDLINK_PF
void UpdateCacheFreePagePtr(BYTE u4kNum)
{
    gsCacheInfo.u32CacheFreePagePtr+=u4kNum;

    if(gsCacheInfo.u16CacheF2hTabFreePtr>u4kNum)
    {
        gsCacheInfo.u16CacheF2hTabFreePtr-=u4kNum;    // 0xFFFF: F2hTab is Full, temp condition before progCacheF2h ready.
    }
    else
    {
        // NLOG(cLogBuild, REBUCACHEF2HTAB_C, 1, "full:u16ActiveCacheBlock:0x%04X ", gsCacheInfo.u16ActiveCacheBlock);

        if(gsCacheInfo.u16FluCacheBlock!=c16FBlockInitValue)
        {
            decFluF2hTabPtr();
        }

        convrVarActCache2FluCache();
        gsCacheInfo.u16CacheF2hTabFreePtr=gsCacheInfo.u16TotalPgPerF2hTab-1;
        gsCacheInfo.uF2hTabBank++;
        // gsRwCtrl.u16ProgPageOfst=0;
        setCacheBlockFull();

        // while((u16PagePtr+gPlaneNum)!=(gsRdlinkInfo.u16RiskyEndPagePtr+1))
        //    ;

        // gCheckFlushFlag=1;
        // gCheckFlushBlk=c16FBlockInitValue;
    }
}    /* UpdateCacheFreePagePtr */

#endif/* if !_EN_RDLINK_PF */

#if _EN_RDLINK_PF
void moveRiskyPage(RLFLUSHF2HTAB *upFlushF2hTab)
{
    WORD u16PagePtr, u16F2hPtr;
    ADDRINFO usTmpAddrInfo;
    BLKSPRINFO usBlkSprInfo[cMaxPlaneNum];
    // BLKSPRINFO usBlkSprInfoM[cMaxPlaneNum];
    // _Uncached F2HTABLE *upF2hTab;
    // F2HTABLE *upF2hTab;
    BYTE uLoop, uF2hFlag=0;
    WORD *u16pBlkSprPtr;
    BYTE uPlaneAddr1, uPlaneAddr, uBreak=cFalse;
    volatile BYTE uStop=1;

    // TODO: remove after verify done.
    NLOG(cLogBuild,
         REBUCACHEF2HTAB_C,
         6,
         " move1 Progfst:0x%04X,u32ProgFifoHead:0x%04X,u32UpdFifoPtr:0x%04X,u32SrchFifoPtr:0x%04X,uMaskTgtPtr:0x%04X,u16MskRptF2hBasePtr:0x%04X",
         (WORD)gsRwCtrl.u16ProgPageOfst,
         (WORD)gsRwCtrl.u32ProgFifoHead,
         (WORD)gsRwCtrl.u32UpdFifoPtr,
         (WORD)gsRwCtrl.u32SrchFifoPtr,
         (WORD)gsRwCtrl.uMaskTgtPtr,
         (WORD)gsRwCtrl.u16MskRptF2hBasePtr
         );

    NLOG(cLogFTL, REBUCACHEF2HTAB_C, 4, "moveRisk Blk:0x%04X,VPC:0x%04X_%04X,ERS:0x%04X",
         gsCacheInfo.u16ActiveCacheBlock,
         (WORD)(g32arCacheBlkVpCnt[gsCacheInfo.u16ActiveCacheBlock]>>16),
         (WORD)g32arCacheBlkVpCnt[gsCacheInfo.u16ActiveCacheBlock],
         (WORD)g16arTempGlobEraseCnt[gsCacheInfo.u16ActiveCacheBlock]);

    while(gsRwCtrl.u16ProgPageOfst)
        ;

    while(gsRwCtrl.uCachePtr)
        ;

    while(gsRwCtrl.uMaskTgtPtr)
        ;

    while(gsRwCtrl.u32ProgFifoTail!=gsRwCtrl.u32ProgFifoHead)
        ;

    gsRwCtrl.u32UpdFifoPtr=gsRwCtrl.u32SrchFifoPtr=gsRwCtrl.u32ProgFifoHead;

    gsRwCtrl.u16MskRptF2hBasePtr=0;

    gsRdlinkInfo.u16ReflashEndPagePtr=c16BitFF;

    if(mChkCacheInfoFlag(cCacheBlockFull))
    {
        // bopClrRam((LWORD)garCacheF2hTab, c32CacheF2hRamSize, 0xFFFFFFFF, cClrTsb|cBopWait);
        initCacheFblkProc();    // open new data block
        getGlobEraseCnt();
        gsRdlinkInfo.ubSaveCacheInfo=1;    // prog cache info after rdlink if pop new cache block.

        NLOG(cLogBuild, REBUCACHEF2HTAB_C, 1, " move new blk:0x%04X  ", (WORD)gsCacheInfo.u16ActiveCacheBlock);
    }

    NLOG(cLogBuild, REBUCACHEF2HTAB_C, 1, " move src blk:0x%04X  ", (WORD)gsRdlinkInfo.u16RiskyBlock);

    gsRdlinkInfo.u16ReflashStartPagePtr=gsCacheInfo.u32CacheFreePagePtr/g4kNumPerPlane;

    NLOG(cLogBuild, REBUCACHEF2HTAB_C, 3, " move cacheFreePtr:0x%04X_%04X ReStar:0x%04X ",
         (WORD)(gsCacheInfo.u32CacheFreePagePtr>>16),
         (WORD)gsCacheInfo.u32CacheFreePagePtr,
         (WORD)gsRdlinkInfo.u16ReflashStartPagePtr);

    NLOG(cLogBuild,
         REBUCACHEF2HTAB_C,
         5,
         "u16ActiveCacheBlock:0x%04X,uF2hTabBank:0x%04X,u32SrchF4kBase:0x%04X_%04X,u32CacheBlkSerial:0x%04X",
         (WORD)gsCacheInfo.u16ActiveCacheBlock,
         (WORD)gsCacheInfo.uF2hTabBank,
         (WORD)(gsCacheInfo.u32SrchF4kBase>>16),
         (WORD)(gsCacheInfo.u32SrchF4kBase),
         (WORD)gsCacheInfo.u32CacheBlkSerial);

    NLOG(cLogBuild,
         REBUCACHEF2HTAB_C,
         5,
         "u16FluCacheBlock:0x%04X,uFlushCacheBlkBank:0x%04X,u32SrchF4kBaseFlu:0x%04X_%04X,u32FluBlkSerial:0x%04X",
         (WORD)gsCacheInfo.u16FluCacheBlock,
         (WORD)gsCacheInfo.uFlushCacheBlkBank,
         (WORD)(gsCacheInfo.u32SrchF4kBaseFlu>>16),
         (WORD)(gsCacheInfo.u32SrchF4kBaseFlu),
         (WORD)gsCacheInfo.u32FluBlkSerial);

    // TODO: remove after verify done. check first parital flush range of F2h buffer.
    WORD u16ChkF2hRange=(upFlushF2hTab->uCnt==1)?gsCacheInfo.u16TotalPgPerF2hTab:g16ChkFlushSize;
    WORD u16F2hEndPtr=gsCacheInfo.u16TotalPgPerF2hTab-u16ChkF2hRange;

    u16F2hPtr=gsCacheInfo.u16TotalPgPerF2hTab-1;

    do
    {
        // debug purpose
        if(!(garCacheF2hTab[u16F2hPtr].u16HBlock&c16Bit15))
        {
            while(uStop)
                ;
        }
    }
    while((u16F2hPtr>0)&&((u16F2hPtr--)!=u16F2hEndPtr));

    for(u16PagePtr=gsRdlinkInfo.u16RiskyStartPagePtr; u16PagePtr<(gsRdlinkInfo.u16RiskyEndPagePtr+1); u16PagePtr+=gPlaneNum)
    {
        // -------------------------------------------------------------------------------------
        // SrcAddrInfo
        // -------------------------------------------------------------------------------------

        // fillCcmVal(&(gReadLinkRetrySlcVth[0][0]),cMaxChNum*cMaxPlaneNum, 0);
        rstUNCStsCore0();

        usTmpAddrInfo.u16FBlock=gsRdlinkInfo.u16RiskyBlock;
        usTmpAddrInfo.u32FPageNoTran=(LWORD)u16PagePtr*g4kNumPerPlane;
        tranAddrInfo(&usTmpAddrInfo);
        // tranCeNum(&usAddrInfo);
        setFLAddrActCh(usTmpAddrInfo.uCh, &usTmpAddrInfo);
        gSectorH=0;

        mSetFRwParam(c16Tsb0SIdx, gSectorPerPageH, c16Bit0|c16Bit15, cReadCmdAle);

        assignFreeBtSrcAddrInfo();
#if (!_HwPlane2SprIssue)
        usTmpAddrInfo.uPlaneAddr=0;
        mSetFRwParam(c16Tsb0SIdx, gSectorPerPageH, c16Bit0|c16Bit2|c16Bit4|c16Bit5|c16Bit10|c16Bit14, cReadData);
        gSectorH=0;
        // TODO: _EN_RAID_UGSD decode raid parity here.
        assignFreeBtSrcAddrInfo();
        waitCmdAllDone(cWaitTrigRCnt|cWaitCmdBz);

        for(uPlaneAddr=0; uPlaneAddr<gPlaneNum; uPlaneAddr++)
        {
            if(mChkBitMask(gPlaneUNCSts[usTmpAddrInfo.uCh], uPlaneAddr))
            {
                uBreak=cTrue;
                break;
            }
            else
            {
                getSprByte(&usBlkSprInfo[uPlaneAddr], uPlaneAddr);
            }
        }

        if(uBreak)
        {
            break;
        }
#else/* if (!_HwPlane2SprIssue) */
        for(uPlaneAddr1=0; uPlaneAddr1<gPlaneNum; uPlaneAddr1+=2)
        {
            usTmpAddrInfo.uPlaneAddr=uPlaneAddr1;
            mSetFRwParam(c16Tsb0SIdx+uPlaneAddr1*gSectorPerPlaneH,
                         gSectorPerPlaneH<<1,
                         c16Bit0|c16Bit2|c16Bit4|c16Bit5|c16Bit10|c16Bit14,
                         cReadData);
            gSectorH=0;

            // TODO: _EN_RAID_UGSD decode raid parity here.
            assignFreeBtSrcAddrInfo();
            waitCmdAllDone(cWaitTrigRCnt|cWaitCmdBz);

            for(uPlaneAddr=uPlaneAddr1; uPlaneAddr<uPlaneAddr1+2; uPlaneAddr++)
            {
                if(mChkBitMask(gPlaneUNCSts[usTmpAddrInfo.uCh], uPlaneAddr))
                {
                    uBreak=cTrue;
                    break;
                }
                else
                {
                    getSprByte(&usBlkSprInfo[uPlaneAddr], uPlaneAddr);
                }
            }

            if(uBreak)
            {
                break;
            }
        }
#endif/* if (!_HwPlane2SprIssue) */

        if(uBreak)
        {
            break;
        }

        // -------------------------------------------------------------------------------------
        // DesAddrInfo
        // -------------------------------------------------------------------------------------
        WORD u16NowDesAddrIdx=gsRwCtrl.u32ProgFifoHead;
        BYTE uCachePtr=0;

        while((u16NowDesAddrIdx+1)==gsRwCtrl.u32UpdFifoPtr)
            ;

        setWriteDes(gsRwCtrl.u16ProgPageOfst, &usTmpAddrInfo, cWriteCache);
        setFLAddrActCh(usTmpAddrInfo.uCh, &usTmpAddrInfo);

#if _EN_RAID_UGSD
#if 0
        if(g16RwOpt&cProgPlaneRaid)
        {
            if(g16RwOpt&cProg32kF2H)
            {
                mSetFRwParam(c16Tsb0SIdx, 0, g16RwOpt|cBit0|c16Bit2|c16Bit15, cBootMoveCache);
            }
            else
            {
                mSetFRwParam(c16Tsb0SIdx, gSectorPerPageH-cRaidDataSctrNum, g16RwOpt|cBit0|c16Bit2|c16Bit15, cBootMoveCache);
            }
        }
        else
        {
            mSetFRwParam(c16Tsb0SIdx, gSectorPerPageH, g16RwOpt|cBit0|c16Bit2|c16Bit15, cBootMoveCache);
        }
#else/* if 0 */
        if(g16RwOpt&cProg16kF2H)
        {
            mSetFRwParam(c16Tsb0SIdx, gSectorPerPageH-gSlcSecNumPadF2h_1, g16RwOpt|cBit0|c16Bit2|c16Bit15, cBootMoveCache);
        }
        else if(g16RwOpt&cProg32kF2H)
        {
            mSetFRwParam(c16Tsb0SIdx, gSectorPerPageH-gSlcSecNumPadF2h_2, g16RwOpt|cBit0|c16Bit2|c16Bit15, cBootMoveCache);
        }
        else if(g16RwOpt&cProgPlaneRaid)
        {
            mSetFRwParam(c16Tsb0SIdx, 0, g16RwOpt|cBit0|c16Bit2|c16Bit15, cBootMoveCache);
        }
        else
        {
            mSetFRwParam(c16Tsb0SIdx, gSectorPerPageH, g16RwOpt|cBit0|c16Bit2|c16Bit15, cBootMoveCache);
        }
#endif/* if 0 */
#else/* if _EN_RAID_UGSD */
        mSetFRwParam(c16Tsb0SIdx, gSectorPerPageH, g16RwOpt|cBit0|c16Bit2|c16Bit15, cBootMoveCache);
#endif/* if _EN_RAID_UGSD */

        for(uPlaneAddr=0; uPlaneAddr<gPlaneNum; uPlaneAddr++)
        {
            usBlkSprInfo[uPlaneAddr].u32Spr9and10.u32all=gsCacheInfo.u32CacheBlkSerial;
            usBlkSprInfo[uPlaneAddr].u16Spr11.u16all=mGetGlobEraseCntRL(gsCacheInfo.u16ActiveCacheBlock);
            usBlkSprInfo[uPlaneAddr].u16Spr8.us2BYTE.HighByte=cBootMoveCache;    // usBlkSprInfo.uOpTyp=cBootMoveCache;
            usBlkSprInfo[uPlaneAddr].u16Seed=core0GetRndSeed(gpFlashAddrInfo->u16FPage);
            setSprByte(&usBlkSprInfo[uPlaneAddr], uPlaneAddr);

            u16pBlkSprPtr=&usBlkSprInfo[uPlaneAddr].u16Spr0.u16all;

            // plane 0 & 1 are same data, plane 2 & 3 are same data
            for(uLoop=0; uLoop<g4kNumPerPlane; uLoop++)
            {
                WORD u16Hblock=*(u16pBlkSprPtr+1);
                WORD u16Hpage=*u16pBlkSprPtr;

                garDesF2hInfo[u16NowDesAddrIdx].u16arHBlock[uCachePtr]=u16Hblock;
                garDesF2hInfo[u16NowDesAddrIdx].u16arHPage[uCachePtr]=u16Hpage;
                rmSetSrchTgt(gsRwCtrl.uMaskTgtPtr, (u16Hblock<<16)|u16Hpage);
                gsRwCtrl.uMaskTgtPtr++;

                // TODO: setProgFifoOpt() //!!!!!

                u16pBlkSprPtr+=2;
                uCachePtr++;
            }
        }

        // _EN_RAID_UGSD: re-encode raid parity here if pre-encode RAID parity fail.

        mSetSprSetDone(gpFlashAddrInfo);    // gpFlashAddrInfo->uSprSetDone=1;
        mSetTabSpr(gpFlashAddrInfo, cBit5);    // gTabSpare=1;

        // gsRwCtrl.u32OneShotChPtr=addPtrBy1(gsRwCtrl.u32OneShotChPtr, gTotalChNum);
        // gsRwCtrl.uOneShotChOpenDesIdx[gsRwCtrl.u32OneShotChPtr]=gsRwCtrl.u32ProgFifoHead;
        // TODO: postpone waitCmdAllDone
        // waitCmdAllDone(cWaitTrigWCnt|cWaitCmdBz);

        // while(garDesAddrInfo[gsRwCtrl.u32UpdFifoPtr].u32FPageNoTran!=
        //
        //    ((gsCacheInfo.u16TotalPgPerF2hTab-1)-gsCacheInfo.u16CacheF2hTabFreePtr+(gsCacheInfo.uF2hTabBank*gsCacheInfo.u16TotalPgPerF2hTab)))
        //    ;

        // -------------------------------------------------------------------------------------
        // setProgFifoOpt
        // -------------------------------------------------------------------------------------
        WORD u16DmaSctrCnt=g4kNumPerPage*cSctrPer4k;
        WORD u16DmaBitCtrl=0;

        LWORD u324kNumOfDesFblk=gsCacheInfo.u32CacheFreePagePtr+gsRwCtrl.u16ProgPageOfst;

        while(u324kNumOfDesFblk>=gsCacheInfo.u16TotalPgPerF2hTab)
        {
            u324kNumOfDesFblk-=gsCacheInfo.u16TotalPgPerF2hTab;
        }

        // TODO: modify to judge if(mChkCacheEobFlag(cEob1stF2h)&&(gsRwCtrl.uCachePtr==gsCacheInfo.u4KNumToPadF2h))
        if((u324kNumOfDesFblk>=g16SlcPadF2hTabPgStr)&&(u324kNumOfDesFblk<g16SlcPadF2hTabPgEnd))    // 1st f2h pad // 16kb
        {
            // u16DmaSctrCnt-=gsCacheInfo.uPadF2h4KNum*cSctrPer4k;
            u16DmaSctrCnt-=gSlcSecNumPadF2h_1;
            u16DmaBitCtrl|=c16Bit0;
            uF2hFlag=cEob1stF2h;
            // resetF2hTab(, ); not need to resetF2hTab, because copy F2h from spare byte to garDesF2hInfo for all plane

            NLOG(cLogBuild, REBUCACHEF2HTAB_C, 2, "cEob1stF2h:u324kNumOfDesFblk:0x%04X, u16DmaSctrCnt:0x%04X ",
                 (WORD)u324kNumOfDesFblk, (WORD)u16DmaSctrCnt);
#if _ENABLE_RAID
            while(gsRwCtrl.u32UpdFifoPtr!=(addWrFfPtrBy1(gsRwCtrl.u32ProgFifoHead)))
            {
                // update F2h done before trigger DesAddrInfo let it encode include F2h pad1.
                updateF2hTable(addWrFfPtrBy1(gsRwCtrl.u32ProgFifoHead    /*u16NowDesAddrIdx*/));

                while(rmChkBopNbsBz)
                    ;
            }
#endif

            while(gsGcInfo.ubBgdProcF)
                ;
        }
        // !!!!!
        // TODO:
        else if(((u324kNumOfDesFblk>=g16SlcProgF2hTabStr)&&(u324kNumOfDesFblk<g16SlcProgF2hTabEnd)))
        {
            // u16DmaSctrCnt-=gsCacheInfo.uProgF2HRem4KNum*cSctrPer4k;
            u16DmaSctrCnt-=gSlcSecNumPadF2h_2;    //

            u16DmaBitCtrl|=c16Bit1;
            uF2hFlag=cEob2ndF2h;
            // resetF2hTab(, ); not need to resetF2hTab, because copy F2h from spare byte to garDesF2hInfo for all plane

            NLOG(cLogBuild, REBUCACHEF2HTAB_C, 2, "cEob2ndF2h:u324kNumOfDesFblk:0x%04X, u16DmaSctrCnt:0x%04X ",
                 (WORD)u324kNumOfDesFblk, (WORD)u16DmaSctrCnt);

            while(gsGcInfo.ubBgdProcF)
                ;
        }

        gsRwCtrl.u16ProgPageOfst+=g4kNumPerPage;

        // resetSrchTgt();
        // TODO: modify to judge // else if(mChkCacheEobFlag(cEobRaid)&&(gsRwCtrl.uCachePtr==(g4kNumPerPage-c4kNumPerRaidPty)))
        if((u324kNumOfDesFblk>=g16SlcProgRaidChStr4K)&&(gpFlashAddrInfo->uCh==(gTotalChNum-1))&&
           (gpFlashAddrInfo->uIntlvAddr==(gIntlvWay-1)))
        {
            u16DmaSctrCnt-=c4kNumPerRaidPty*cSctrPer4k;
            u16DmaBitCtrl|=cEobRaid;

            // not need to resetF2hTab, resetSrchTgt, because copy F2h from spare byte to garDesF2hInfo for all plane
            // resetF2hTab(, c4kNumPerRaidPty);
            // resetSrchTgt();

            NLOG(cLogBuild, REBUCACHEF2HTAB_C, 2, "cEobRaid:u324kNumOfDesFblk:0x%04X, u16DmaSctrCnt:0x%04X ",
                 (WORD)u324kNumOfDesFblk, (WORD)u16DmaSctrCnt);

#if 0    // _ENABLE_RAID
            if((uF2hFlag&cEob2ndF2h)&&(gsRwCtrl.u32UpdFifoPtr!=(addWrFfPtrBy1(gsRwCtrl.u32ProgFifoHead))))
            {
                volatile BYTE uStop1=1;

                while(uStop1)
                    ;

                while(rmChkBopNbsBz)
                    ;
            }
#endif
        }

        if(gsGcInfo.ubBgdProcF)
        {
            // let bufPtr the same as host write
            g16WriteBufPtr=addWriteBufPtr(g16WriteBufPtr, u16DmaSctrCnt);    // +=u16DmaSctrCnt;
            g16FlashWBufPtr=addWriteBufPtr(g16FlashWBufPtr, u16DmaSctrCnt);    // +=u16DmaSctrCnt;
        }

        chkAddHostWrCnt(u16DmaSctrCnt, gsCacheInfo.uChkF2hRegion?0:1);

        // after resetF2hTab
        assignFreeBtDesAddrInfo();

        // while(gsRwCtrl.u32ProgFifoHead==gsRwCtrl.u32UpdFifoPtr)
        //    ;

        if(gCh==(gTotalChNum-1))
        {
            updateF2hTable(gsRwCtrl.u32ProgFifoHead);

            while(rmChkBopNbsBz)
                ;
        }

        // for cEob2ndF2h,
        // if the last desAddrInfo of move risky page is at cEob1stF2h, it need to a desAddrInfo for cEob2ndF2h
        // if cEob2ndF2h but not the last desAddrInfo of move risky page, it need to a reset uChkF2hRegion=0 to caculate occSize at next loop
        // like setF2hProgDesAddr().
        if((u16PagePtr+gPlaneNum)>=(gsRdlinkInfo.u16RiskyEndPagePtr+1))
        {
            if(uF2hFlag==cEob1stF2h)
            {
                setF2hProgDesAddr();
                // TODO: need resetSrchTgt()?
                // resetSrchTgt();
            }
        }

        if(uF2hFlag&cEob2ndF2h)
        {
            // ignore chkBufOccupy() and reset uChkF2hRegion to caculate occSize
            gsCacheInfo.uChkF2hRegion=0;
        }

        // -------------------------------------------------------------------------------------
        // chkBufOccupy()
        // -------------------------------------------------------------------------------------
        if(((gsCacheInfo.u32CacheFreePagePtr+gsRwCtrl.u16ProgPageOfst)%g16ChkFlushSize)==0)
        {
            if((gsRwCtrl.u16OccFSkipSize!=0)&&(gsRwCtrl.u16OccFSkipSize!=c16WriteBufSize))
            {
                NLOG(cLogBuild,
                     REBUCACHEF2HTAB_C,
                     5,
                     "movRky: wrPos:0x%04X_%04X, GcQue:0x%04X, uChkF2hRegion|ubBgdProcF:0x%04X, u16OccFSkipSize:0x%04X ",
                     (WORD)(gsCacheInfo.u32CacheFreePagePtr+gsRwCtrl.u16ProgPageOfst)>>16,
                     (WORD)(gsCacheInfo.u32CacheFreePagePtr+gsRwCtrl.u16ProgPageOfst),
                     (WORD)(gsGcInfo.uGcTypBit<<8)|gsGcInfo.uGcQueueCnt,
                     (WORD)((gsCacheInfo.uChkF2hRegion<<8)|gsGcInfo.ubBgdProcF),
                     (WORD)gsRwCtrl.u16OccFSkipSize);

                // if(((gsCacheInfo.u32CacheFreePagePtr+gsRwCtrl.u16ProgPageOfst)%g16ChkFlushSize)==0)
                // it should be if((gsRwCtrl.u16OccFSkipSize!=0)&&(gsRwCtrl.u16OccFSkipSize!=c16WriteBufSize))
                while(uStop)
                    ;
            }

            if(chkWriteDataDone())
            {
                while(rmChkBopNbsBz)
                    ;

                if(mChkGcQue(cGcTypFlushF2h))
                {
#if 1
                    NLOG(cLogBuild, REBUCACHEF2HTAB_C, 6, "flushMov:src[0x%04X,0x%04X]des:[0x%04X,0x%04X]flu[0x%04X,0x%04X]",
                         gsRdlinkInfo.u16RiskyBlock, u16PagePtr,
                         gsCacheInfo.u16ActiveCacheBlock,
                         (WORD)(gsCacheInfo.u32CacheFreePagePtr+gsRwCtrl.u16ProgPageOfst),
                         (WORD)gsCacheInfo.u16F2HTabFlushStart,
                         (WORD)gsCacheInfo.u16F2HTabFlushEnd);
#endif

                    flushCacheHmbTab();

                    if(mChkGcQue(cGcTypFlushF2h)&&((u16PagePtr+gPlaneNum)>=(gsRdlinkInfo.u16RiskyEndPagePtr+1)))
                    {
                        // TODO: excute last actully partial flush after make risky page end .
                        flushCacheF2hTab(cBit1);
                    }
                    else
                    {
                        flushCacheF2hTab(cBit1|cBit3);    // only reorder
                    }
                }
            }

            // just reset variables but not parital flush like chkBufOccupy()
            gsRwCtrl.u16OccFSkipSize=gsGcInfo.ubBgdProcF=gsGcInfo.uGcQueueCnt=gsGcInfo.uGcTypBit=0;

            if(!gsCacheInfo.uChkF2hRegion)
            {
                chkFlushCacheTabOccF();
            }
        }
    }

    while(rmChkBopNbsBz)
        ;

    // TODO: ref flush cache
    while(gsRwCtrl.u32UpdFifoPtr!=gsRwCtrl.u32ProgFifoHead)
    {
        updateF2hTable(gsRwCtrl.u32ProgFifoHead);
    }

    gsRdlinkInfo.u16ReflashEndPagePtr=gsCacheInfo.u32CacheFreePagePtr/g4kNumPerPlane;

    if((gsRwCtrl.u32UpdFifoPtr!=gsRwCtrl.u32ProgFifoHead)||
       (gsRwCtrl.u32SrchFifoPtr!=gsRwCtrl.u32ProgFifoHead))
    {
        while(uStop)
            ;
    }

    NLOG(cLogBuild, REBUCACHEF2HTAB_C, 3, " move cacheFreePtr:0x%04X_%04X ReEnd:0x%04X ",
         (WORD)(gsCacheInfo.u32CacheFreePagePtr>>16),
         (WORD)(gsCacheInfo.u32CacheFreePagePtr),
         (WORD)gsRdlinkInfo.u16ReflashEndPagePtr);

    // TODO: handle the PCIe variable, gsRwCtrl.u16MskRptF2hBasePtr
    // TODO: NLOG:
    // gsRwCtrl.u32ProgFifoHead;
    // gsRwCtrl.u32UpdFifoPtr;
    // gsRwCtrl.u32SrchFifoPtr;
    // gsRwCtrl.uMaskTgtPtr;
    // gsRwCtrl.u16MskRptF2hBasePtr

    NLOG(cLogBuild,
         REBUCACHEF2HTAB_C,
         6,
         " move2 Progfst:0x%04X,u32ProgFifoHead:0x%04X,u32UpdFifoPtr:0x%04X,u32SrchFifoPtr:0x%04X,uMaskTgtPtr:0x%04X,u16MskRptF2hBasePtr:0x%04X",
         (WORD)gsRwCtrl.u16ProgPageOfst,
         (WORD)gsRwCtrl.u32ProgFifoHead,
         (WORD)gsRwCtrl.u32UpdFifoPtr,
         (WORD)gsRwCtrl.u32SrchFifoPtr,
         (WORD)gsRwCtrl.uMaskTgtPtr,
         (WORD)gsRwCtrl.u16MskRptF2hBasePtr);

    // TODO: NLOG
    /*
       * gsRwCtrl.u16MskRptF2hBasePtr=0;
       * gsRwCtrl.uMaskTgtPtr=0;
       * gsRwCtrl.uCachePtr=0;
       * gsRwCtrl.uCacheStartSctr=0;
       * gsRwCtrl.uCacheEndSctr=cSctrPer4k;
       * gsRwCtrl.u16CacheInBuf=0;
       */

    // TODO: truely partial flush
    // TODO: instead of paritial flush above
    // TODO: GreyBox verify this case
    // flushCacheF2hTab(cBit1|cBit3);

#if 1
    // TODO: verify full range
    // TODO: remove reset g32arSrcInCacheFlag and u16HblkCntInCache in recoverCacheF2hTab + flushF2h
    // WORD u16HblkCntInCache=gsCacheInfo.u16HblkCntInCache;

    bopClrRam((LWORD)g32arSrcInCacheFlag, c16MaxH2fTabNum/8, 0x00000000, cBopWait|cClrCore0Dccm);
    gsCacheInfo.u16HblkCntInCache=0;

    // for(u16F2hPtr=0; u16F2hPtr<(gsCacheInfo.u16CacheF2hTabFreePtr+1); u16F2hPtr++)
    for(u16F2hPtr=0; u16F2hPtr<gsCacheInfo.u16TotalPgPerF2hTab; u16F2hPtr++)
    {
        if(!(garCacheF2hTab[u16F2hPtr].u16HBlock&c16Bit15))
        {
            if(!mChkSrcInCache(garCacheF2hTab[u16F2hPtr].u16HBlock))
            {
                mSetSrcInCache(garCacheF2hTab[u16F2hPtr].u16HBlock);
            }
        }
    }

    // TODO: need to debug
    // while(gsCacheInfo.u16HblkCntInCache!=u16HblkCntInCache)
#endif/* if 1 */

    if(gsCacheInfo.u32CacheFreePagePtr&1)    // in Rw flow data block not use signle plane program
    {
        debugLoop(cMoveRiskyPage1);
    }
}    /* moveRiskyPage */

#else/* if _EN_RDLINK_PF */

/*
   *  only move last super page
   */
void moveRiskyPage()
{
    WORD u16PagePtr;
    ADDRINFO usTmpAddrInfo;
    BLKSPRINFO usBlkSprInfo[cMaxPlaneNum];
    // BLKSPRINFO usBlkSprInfoM[cMaxPlaneNum];
    // _Uncached F2HTABLE *upF2hTab;
    F2HTABLE *upF2hTab;
    BYTE uLoop, uF2hFlag=0;
    WORD *u16pBlkSprPtr;
    BYTE uPlaneAddr1, uPlaneAddr, uBreak=cFalse, uLastPage;
    volatile BYTE uStop=1;

    // WORD u16FlushPtr;

    gsRdlinkInfo.u16ReflashEndPagePtr=c16BitFF;

    if(mChkCacheInfoFlag(cCacheBlockFull))
    {
        bopClrRam((LWORD)garCacheF2hTab, c32CacheF2hRamSize, 0xFFFFFFFF, cClrTsb|cBopWait);
        initCacheFblkProc();    // open new data block
        getGlobEraseCnt();
        gsRdlinkInfo.ubSaveCacheInfo=1;    // prog cache info after rdlink if pop new cache block.

        NLOG(cLogBuild, REBUCACHEF2HTAB_C, 1, " move new blk:0x%04X  ", (WORD)gsCacheInfo.u16ActiveCacheBlock);
    }

    NLOG(cLogBuild, REBUCACHEF2HTAB_C, 1, " move src blk:0x%04X  ", (WORD)gsRdlinkInfo.u16RiskyBlock);

    gsRdlinkInfo.u16ReflashStartPagePtr=gsCacheInfo.u32CacheFreePagePtr/g4kNumPerPlane;

    NLOG(cLogBuild, REBUCACHEF2HTAB_C, 3, " move cacheFreePtr:0x%04X_%04X ReStar:0x%04X ",
         (WORD)(gsCacheInfo.u32CacheFreePagePtr>>16),
         (WORD)gsCacheInfo.u32CacheFreePagePtr,
         (WORD)gsRdlinkInfo.u16ReflashStartPagePtr);

    // ???? why ???
    gsCacheInfo.u16FluCacheBlock=gsCacheInfo.u16ActiveCacheBlock;
    gsCacheInfo.uFlushCacheBlkBank=gsCacheInfo.uF2hTabBank;
    // gsCacheInfo.u16FlushF2hTabPtr=gsCacheInfo.u16CacheF2hTabFreePtr;
    gsCacheInfo.u32SrchF4kBaseFlu=(LWORD)(gsCacheInfo.uF2hTabBank+1)*g16TotalPgPerF2hTab-1;

    upF2hTab=garCacheF2hTab+gsCacheInfo.u16CacheF2hTabFreePtr;

    for(u16PagePtr=gsRdlinkInfo.u16RiskyStartPagePtr; u16PagePtr<(gsRdlinkInfo.u16RiskyEndPagePtr+1); u16PagePtr+=gPlaneNum)
    {
        // fillCcmVal(&(gReadLinkRetrySlcVth[0][0]),cMaxChNum*cMaxPlaneNum, 0);
        rstUNCStsCore0();

        usTmpAddrInfo.u16FBlock=gsRdlinkInfo.u16RiskyBlock;
        usTmpAddrInfo.u32FPageNoTran=(LWORD)u16PagePtr*g4kNumPerPlane;
        tranAddrInfo(&usTmpAddrInfo);
        // tranCeNum(&usAddrInfo);
        setFLAddrActCh(usTmpAddrInfo.uCh, &usTmpAddrInfo);
        gSectorH=0;

        mSetFRwParam(c16Tsb0SIdx, gSectorPerPageH, c16Bit0|c16Bit15, cReadCmdAle);

        assignFreeBtSrcAddrInfo();
#if (!_HwPlane2SprIssue)
        usTmpAddrInfo.uPlaneAddr=0;
        mSetFRwParam(c16Tsb0SIdx, gSectorPerPageH, c16Bit0|c16Bit2|c16Bit4|c16Bit5|c16Bit10|c16Bit14, cReadData);
        gSectorH=0;
        // TODO: _EN_RAID_UGSD decode raid parity here.
        assignFreeBtSrcAddrInfo();
        waitCmdAllDone(cWaitTrigRCnt|cWaitCmdBz);

        for(uPlaneAddr=0; uPlaneAddr<gPlaneNum; uPlaneAddr++)
        {
            if(mChkBitMask(gPlaneUNCSts[usTmpAddrInfo.uCh], uPlaneAddr))
            {
                uBreak=cTrue;
                break;
            }
            else
            {
                getSprByte(&usBlkSprInfo[uPlaneAddr], uPlaneAddr);
            }
        }

        if(uBreak)
        {
            break;
        }
#else/* if (!_HwPlane2SprIssue) */
        for(uPlaneAddr1=0; uPlaneAddr1<gPlaneNum; uPlaneAddr1+=2)
        {
            usTmpAddrInfo.uPlaneAddr=uPlaneAddr1;
            mSetFRwParam(c16Tsb0SIdx+uPlaneAddr1*gSectorPerPlaneH,
                         gSectorPerPlaneH<<1,
                         c16Bit0|c16Bit2|c16Bit4|c16Bit5|c16Bit10|c16Bit14,
                         cReadData);
            gSectorH=0;

            // TODO: _EN_RAID_UGSD decode raid parity here.
            assignFreeBtSrcAddrInfo();
            waitCmdAllDone(cWaitTrigRCnt|cWaitCmdBz);

            for(uPlaneAddr=uPlaneAddr1; uPlaneAddr<uPlaneAddr1+2; uPlaneAddr++)
            {
                if(mChkBitMask(gPlaneUNCSts[usTmpAddrInfo.uCh], uPlaneAddr))
                {
                    uBreak=cTrue;
                    break;
                }
                else
                {
                    getSprByte(&usBlkSprInfo[uPlaneAddr], uPlaneAddr);
                }
            }

            if(uBreak)
            {
                break;
            }
        }
#endif/* if (!_HwPlane2SprIssue) */

        if(uBreak)
        {
            break;
        }

        setWriteDes(0, &usTmpAddrInfo, cWriteCache);
        setFLAddrActCh(usTmpAddrInfo.uCh, &usTmpAddrInfo);

#if _EN_RAID_UGSD
#if 0
        if(g16RwOpt&cProgPlaneRaid)
        {
            mSetFRwParam(c16Tsb0SIdx, gSectorPerPageH-cRaidDataSctrNum, cBit0|c16Bit2|c16Bit11|c16Bit15, cBootMoveCache);
        }
        else
        {
            mSetFRwParam(c16Tsb0SIdx, gSectorPerPageH, cBit0|c16Bit2|c16Bit15, cBootMoveCache);
        }
#else
        if(g16RwOpt&cProgPlaneRaid)
        {
            if(g16RwOpt&cProg32kF2H)
            {
                mSetFRwParam(c16Tsb0SIdx, 0, g16RwOpt|cBit0|c16Bit2|c16Bit11|c16Bit15, cBootMoveCache);
            }
            else
            {
                mSetFRwParam(c16Tsb0SIdx, gSectorPerPageH-cRaidDataSctrNum, g16RwOpt|cBit0|c16Bit2|c16Bit11|c16Bit15, cBootMoveCache);
            }

            NLOG(cLogCore1, REBUCACHEF2HTAB_C, 1, "move reskypage, g16RwOpt: 0x%04X  ", g16RwOpt);
        }
        else if(g16RwOpt&cProg32kF2H)
        {
            mSetFRwParam(c16Tsb0SIdx, gSectorPerPageH-gSlcSecNumPadF2h_2, g16RwOpt|cBit0|c16Bit2|c16Bit15, cBootMoveCache);
            NLOG(cLogCore1, REBUCACHEF2HTAB_C, 1, "move reskypage, g16RwOpt: 0x%04X  ", g16RwOpt);
        }
        else if(g16RwOpt&cProg16kF2H)
        {
            mSetFRwParam(c16Tsb0SIdx, gSectorPerPageH-gSlcSecNumPadF2h_1, g16RwOpt|cBit0|c16Bit2|c16Bit15, cBootMoveCache);
            NLOG(cLogCore1, REBUCACHEF2HTAB_C, 1, "move reskypage, g16RwOpt: 0x%04X  ", g16RwOpt);
        }
        else
        {
            mSetFRwParam(c16Tsb0SIdx, gSectorPerPageH, g16RwOpt|cBit0|c16Bit2|c16Bit15, cBootMoveCache);
        }
#endif/* if 0 */
#else/* if _EN_RAID_UGSD */
        mSetFRwParam(c16Tsb0SIdx, gSectorPerPageH, cBit0|c16Bit2|c16Bit15, cBootMoveCache);
#endif/* if _EN_RAID_UGSD */

        for(uPlaneAddr=0; uPlaneAddr<gPlaneNum; uPlaneAddr++)
        {
            usBlkSprInfo[uPlaneAddr].u32Spr9and10.u32all=gsCacheInfo.u32CacheBlkSerial;
            usBlkSprInfo[uPlaneAddr].u16Spr11.u16all=mGetGlobEraseCntRL(gsCacheInfo.u16ActiveCacheBlock);
            usBlkSprInfo[uPlaneAddr].u16Spr8.us2BYTE.HighByte=cBootMoveCache;    // usBlkSprInfo.uOpTyp=cBootMoveCache;
            usBlkSprInfo[uPlaneAddr].u16Seed=core0GetRndSeed(gpFlashAddrInfo->u16FPage);
            setSprByte(&usBlkSprInfo[uPlaneAddr], uPlaneAddr);

            u16pBlkSprPtr=&usBlkSprInfo[uPlaneAddr].u16Spr0.u16all;

            // plane 0 & 1 are same data, plane 2 & 3 are same data
            for(uLoop=0; uLoop<g4kNumPerPlane; uLoop++)
            {
                if(*(u16pBlkSprPtr+1)!=0xFFFF)
                {
                    upF2hTab->u16HBlock=*(u16pBlkSprPtr+1)&(c15BitFF);
                    upF2hTab->u16HPage=*u16pBlkSprPtr;    // |c16Bit15;

                    while(upF2hTab->u16HBlock>=g16TotalHBlock)
                        ;

                    while(upF2hTab->u16HPage>=g16PagePerH2fTab)
                        ;
                }

                u16pBlkSprPtr+=2;
                upF2hTab--;
            }
        }

        // _EN_RAID_UGSD: re-encode raid parity here if pre-encode RAID parity fail.

        mSetSprSetDone(gpFlashAddrInfo);    // gpFlashAddrInfo->uSprSetDone=1;
        mSetTabSpr(gpFlashAddrInfo, cBit5);    // gTabSpare=1;
        mClrCacheInfoFlag(cMoveProgramFail);
        assignFreeBtDesAddrInfo();
        // gsRwCtrl.u32OneShotChPtr=addPtrBy1(gsRwCtrl.u32OneShotChPtr, gTotalChNum);
        // gsRwCtrl.uOneShotChOpenDesIdx[gsRwCtrl.u32OneShotChPtr]=gsRwCtrl.u32ProgFifoHead;
        waitCmdAllDone(cWaitTrigWCnt|cWaitCmdBz);

        if(mChkCacheInfoFlag(cMoveProgramFail))
        {
            // Program fail
            NLOG(cLogCore1, REBUCACHEF2HTAB_C, 2, "move reskypage, Program Fail!! gsCacheInfo.u32CacheInfoFlag: 0x%08X  ",
                 (gsCacheInfo.u32CacheInfoFlag>>16), (gsCacheInfo.u32CacheInfoFlag));
            return;
        }

        // while(garDesAddrInfo[gsRwCtrl.u32UpdFifoPtr].u32FPageNoTran!=
        //
        //    ((gsCacheInfo.u16TotalPgPerF2hTab-1)-gsCacheInfo.u16CacheF2hTabFreePtr+(gsCacheInfo.uF2hTabBank*gsCacheInfo.u16TotalPgPerF2hTab)))
        //    ;

        WORD u16DmaSctrCnt=g4kNumPerPage*cSctrPer4k;
        WORD u16DmaBitCtrl=0;

        LWORD u324kNumOfDesFblk=gsCacheInfo.u32CacheFreePagePtr    /*+u16ProgPageOfst*/;

        while(u324kNumOfDesFblk>=gsCacheInfo.u16TotalPgPerF2hTab)
        {
            u324kNumOfDesFblk-=gsCacheInfo.u16TotalPgPerF2hTab;
        }

#if 1
        if((u324kNumOfDesFblk>=g16SlcPadF2hTabPgStr)&&(u324kNumOfDesFblk<g16SlcPadF2hTabPgEnd))    // 1st f2h pad // 16kb
        {
            // u16DmaSctrCnt-=gsCacheInfo.uPadF2h4KNum*cSctrPer4k;
            u16DmaSctrCnt-=gSlcSecNumPadF2h_1;
            uF2hFlag=cEob1stF2h;

            NLOG(cLogBuild, REBUCACHEF2HTAB_C, 2, "cEob1stF2h:u324kNumOfDesFblk:0x%04X, u16DmaSctrCnt:0x%04X ",
                 (WORD)u324kNumOfDesFblk, (WORD)u16DmaSctrCnt);

            while(gsGcInfo.ubBgdProcF)
                ;
        }
        else if(((u324kNumOfDesFblk>=g16SlcProgF2hTabStr)&&(u324kNumOfDesFblk<g16SlcProgF2hTabEnd)))
        {
            // u16DmaSctrCnt-=gsCacheInfo.uProgF2HRem4KNum*cSctrPer4k;
            if(u324kNumOfDesFblk<(g16SlcProgF2hTabStr+g4kNumPerPage))
            {
                u16DmaSctrCnt-=gSlcSecNumPadF2h_2;
            }

            u16DmaBitCtrl|=c16Bit1;
            uF2hFlag=cEob2ndF2h;

            NLOG(cLogBuild, REBUCACHEF2HTAB_C, 2, "cEob2ndF2h:u324kNumOfDesFblk:0x%04X, u16DmaSctrCnt:0x%04X ",
                 (WORD)u324kNumOfDesFblk, (WORD)u16DmaSctrCnt);

            while(gsGcInfo.ubBgdProcF)
                ;
        }
#endif/* if 0 */

        if((u324kNumOfDesFblk>=g16SlcProgRaidChStr4K)&&(gpFlashAddrInfo->uCh==(gTotalChNum-1))&&
           (gpFlashAddrInfo->uIntlvAddr==(gIntlvWay-1)))
        {
            u16DmaSctrCnt-=(c4kNumPerRaidPty*cSctrPer4k);
            u16DmaBitCtrl|=cEobRaid;

            NLOG(cLogBuild, REBUCACHEF2HTAB_C, 2, "cEobRaid:u324kNumOfDesFblk:0x%04X, u16DmaSctrCnt:0x%04X ",
                 (WORD)u324kNumOfDesFblk, (WORD)u16DmaSctrCnt);
        }

        if(gsGcInfo.ubBgdProcF)
        {
            g16WriteBufPtr=addWriteBufPtr(g16WriteBufPtr, u16DmaSctrCnt);    // +=u16DmaSctrCnt;
            g16FlashWBufPtr=addWriteBufPtr(g16FlashWBufPtr, u16DmaSctrCnt);    // +=u16DmaSctrCnt;
        }

        uLastPage=(((u16PagePtr+gPlaneNum)>=(gsRdlinkInfo.u16RiskyEndPagePtr)));
        UpdateCacheFreePagePtr(g4kNumPerPage);

        chkAddHostWrCnt(u16DmaSctrCnt, gsCacheInfo.uChkF2hRegion?0:1);
        // TODO: invalid F2h

        gsRwCtrl.u32UpdFifoPtr=addWrFfPtrBy1(gsRwCtrl.u32UpdFifoPtr);
        // chkFlushCacheTabOccF();

        if((uLastPage)&&(uF2hFlag==cEob1stF2h))
        {
#if _EN_FW_DEBUG_UART
            NLOG(cLogCore1,
                 REBUCACHEF2HTAB_C,
                 4,
                 "1, u16PagePtr=: 0x%04X, uF2hFlag=: 0x%04X, uLastPage=: 0x%04X, uF2hTabBank= 0x%04X ",
                 u16PagePtr,
                 uF2hFlag,
                 uLastPage, gsCacheInfo.uF2hTabBank);
#endif
            setF2hProgDesAddr();
            UpdateCacheFreePagePtr(gsRwCtrl.u16ProgPageOfst);
            gsRwCtrl.u16ProgPageOfst=0;
            gsRwCtrl.u32UpdFifoPtr=gsRwCtrl.u32ProgFifoHead;
            // waitCmdAllDone(cWaitTrigRCnt|cWaitCmdBz);
        }
        else if(uF2hFlag==cEob2ndF2h)
        {
#if _EN_FW_DEBUG_UART
            NLOG(cLogCore1,
                 REBUCACHEF2HTAB_C,
                 4,
                 "3, u16PagePtr=: 0x%04X, uF2hFlag=: 0x%04X, uLastPage=: 0x%04X, uF2hTabBank= 0x%04X ",
                 u16PagePtr,
                 uF2hFlag,
                 uLastPage, gsCacheInfo.uF2hTabBank);
#endif
            gsCacheInfo.uChkF2hRegion=0;
            // debugDeadLock(0x0055);//20190402_need_Chk
        }

        while(gsRwCtrl.u16ProgPageOfst+gsRwCtrl.uCachePtr)
            ;

        if(((gsCacheInfo.u32CacheFreePagePtr)%g16ChkFlushSize)==0)
        {
            if(mChkGcQue(cGcTypFlushF2h)&&((u16PagePtr+gPlaneNum)>=(gsRdlinkInfo.u16RiskyEndPagePtr+1)))
            {
                // TODO: excute last partial flush here.
            }

            if((gsRwCtrl.u16OccFSkipSize!=0)&&(gsRwCtrl.u16OccFSkipSize!=c16WriteBufSize))
            {
                NLOG(cLogBuild,
                     REBUCACHEF2HTAB_C,
                     5,
                     "movRky: wrPos:0x%04X_%04X, GcQue:0x%04X, uChkF2hRegion|ubBgdProcF:0x%04X, u16OccFSkipSize:0x%04X ",
                     (WORD)(gsCacheInfo.u32CacheFreePagePtr+gsRwCtrl.u16ProgPageOfst)>>16,
                     (WORD)(gsCacheInfo.u32CacheFreePagePtr+gsRwCtrl.u16ProgPageOfst),
                     (WORD)(gsGcInfo.uGcTypBit<<8)|gsGcInfo.uGcQueueCnt,
                     (WORD)((gsCacheInfo.uChkF2hRegion<<8)|gsGcInfo.ubBgdProcF),
                     (WORD)gsRwCtrl.u16OccFSkipSize);

                // volatile BYTE uStop=1;
                // while(uStop)
                //    ;
            }

            gsGcInfo.ubBgdProcF=gsGcInfo.uGcQueueCnt=gsGcInfo.uGcTypBit=0;
            gsRwCtrl.u16OccFSkipSize=0;

            if(!gsCacheInfo.uChkF2hRegion)
            {
                chkFlushCacheTabOccF();
            }
        }
    }

    // if(gsRdlinkInfo.u16ReflashEndPagePtr==c16BitFF)
    {
        gsRdlinkInfo.u16ReflashEndPagePtr=gsCacheInfo.u32CacheFreePagePtr/g4kNumPerPlane;
    }

    while(gsRwCtrl.u32UpdFifoPtr!=gsRwCtrl.u32ProgFifoHead)
        ;

    gsRwCtrl.u32SrchFifoPtr=gsRwCtrl.u32ProgFifoHead;

    NLOG(cLogBuild, REBUCACHEF2HTAB_C, 3, " move cacheFreePtr:0x%04X_%04X ReEnd:0x%04X ",
         (WORD)(gsCacheInfo.u32CacheFreePagePtr>>16),
         (WORD)(gsCacheInfo.u32CacheFreePagePtr),
         (WORD)gsRdlinkInfo.u16ReflashEndPagePtr);

#if _EN_VPC_SWAP    // 20190711_ChrisSu
#if _ENABLE_RAID
    popVPCfromRaidCore0(cCacheBlkVpCntRdlinkEndStrIdx);
    mSetBitMask(g32VPCSwapFlag, cVPCntBufValid);
    g32arCacheBlkVpCnt=(volatile LWORD *)(cCacheBlkVpCntRdlinkEndStrAddr);
#else
    if(!gsRdlinkInfo.ubCacheInfoValid&&(gsWproInfo.u16arWproIdxPagePtr[cWproCacheInfo]==c16BitFF))
    {
        // Prog Changed VPCnt
        progWproPageCore0(cWproCacheBlkVpCnt, cCacheBlkVpCntBootStrIdx);
    }
#endif
#endif

    progCacheInfoTab();    // 20190222_Louis
    NLOG(cLogBuild, REBUCACHEF2HTAB_C, 0, "Before flushCacheF2hTab, progCacheInfoTab End! ");

#if _EN_VPC_SWAP    // 20190711_ChrisSu
#if _ENABLE_RAID
    pushVPCtoRaidCore0(cCacheBlkVpCntRdlinkEndStrIdx);
    mClrBitMask(g32VPCSwapFlag, cVPCntBufValid);
#endif
#endif

    // TODO: instead of paritial flush above
    flushCacheF2hTab(cBit0|cBit3);
    // gsCacheInfo.u16FlushF2hTabPtr=gsCacheInfo.u16CacheF2hTabFreePtr;
    gsCacheInfo.u16HblkCntInCache=0;

    if(gsCacheInfo.u32CacheFreePagePtr&1)    // in Rw flow data block not use signle plane program
    {
        debugLoop(cMoveRiskyPage2);
    }
}    /* moveRiskyPage */

#endif/* if 0 */

void setSprByteforPadDummy(BYTE uTabID, LWORD u32Serial, BYTE uPlaneAddr)
{
    BLKSPRINFO usBlkSprInfo;

    usBlkSprInfo.u16Seed=core0GetRndSeed(gpFlashAddrInfo->u16FPage);    // g16arSeedTable[gpFlashAddrInfo->u16FPage];
    usBlkSprInfo.u16Spr8.us2BYTE.LowByte=uTabID;
    usBlkSprInfo.u16Spr8.us2BYTE.HighByte=cPwrOnDummyProg;
    usBlkSprInfo.u32Spr9and10.u32all=u32Serial;
    usBlkSprInfo.u16Spr11.u16all=mGetGlobEraseCntRL(g16AbstrFBlock);
    usBlkSprInfo.u16Spr0.u16all=0xFFFF;
    usBlkSprInfo.u16Spr1.u16all=0xFFFF;
    usBlkSprInfo.u16Spr2.u16all=0xFFFF;
    usBlkSprInfo.u16Spr3.u16all=0xFFFF;
    usBlkSprInfo.u16Spr4.u16all=0xFFFF;
    usBlkSprInfo.u16Spr5.u16all=0xFFFF;
    usBlkSprInfo.u16Spr6.u16all=0xFFFF;
    usBlkSprInfo.u16Spr7.u16all=0xFFFF;
    setSprByte(&usBlkSprInfo, uPlaneAddr);
}    /* setSprByteforPadDummy */

WORD dummyProgOpenWL(WORD u16FBlock, WORD u16FreePagePtr, LWORD u32Serial, BYTE uHdlWlNum, BYTE uBlkId)
{
    // BYTE uSLCMode= 1;
    BYTE uPlaneAddr;
    WORD uPageOfst, u16HdlOpFpagePtr, u16Fpage;
    ADDRINFO usTmpAddrInfo;

    // BYTE uSetOneShotChPtr=0;

#if !_EN_RAID_UGSD
    WORD u16SLCBankPlane, u16RemPage;
#endif

    if(mChkMlcMoBit(u16FBlock))
    {
        debugDeadLock(0x0060|c16Bit14);
    }

#if _EN_RAID_UGSD
    BYTE uLastBank;

    u16Fpage=u16FreePagePtr/gTotalIntlvChPlaneNum;

    // at least 2 word line
    u16HdlOpFpagePtr=((u16Fpage/cSubBlockNum+uHdlWlNum)*cSubBlockNum)*gTotalIntlvChPlaneNum;

    // NLOG(cLogBuild, REBUCACHEF2HTAB_C, 3, "1: dummyProg: u16FreePage:[0x%04X,0x%04X], u16HdlOpFpagePtr:0x%04X ",
    //    (WORD)u16Fpage, (WORD)u16FreePagePtr, (WORD)u16HdlOpFpagePtr);

    uLastBank=(u16HdlOpFpagePtr*g4kNumPerPlane)/g16TotalPgPerF2hTab;

    if(uLastBank<gTotalBankOfF2hTab)
    {
        uLastBank++;
    }

    while(uLastBank>gTotalBankOfF2hTab)
        ;

    // dummy program until the end of band
    u16HdlOpFpagePtr=(gTotalBankOfF2hTab*g16TotalPgPerF2hTab)/g4kNumPerPlane;    // 20190305_ChrisSu

    // NLOG(cLogBuild, REBUCACHEF2HTAB_C, 3, "2: dummyProg: uLastBank:0x%04X, u16HdlOpFpagePtr:0x%04X ",
    //    (WORD)uLastBank, (WORD)u16HdlOpFpagePtr);
#else/* if _EN_RAID_UGSD */
    u16Fpage=u16FreePagePtr/gTotalIntlvChPlaneNum;
    u16HdlOpFpagePtr=((u16Fpage/cSubBlockNum+uHdlWlNum)*cSubBlockNum)*gTotalIntlvChPlaneNum;

    // Align flush start position
    u16HdlOpFpagePtr=((u16HdlOpFpagePtr*g4kNumPerPlane+g16ChkFlushSize-1)/g16ChkFlushSize)*g16ChkFlushSize;
    u16HdlOpFpagePtr=u16HdlOpFpagePtr/g4kNumPerPlane;

    u16SLCBankPlane=g16PagePerBlock3_SLC/gTotalBankOfF2hTab;

    if(gsRdlinkInfo.u16RiskyStartPagePtr!=c16BitFF)
    {
        u16RemPage=u16HdlOpFpagePtr%u16SLCBankPlane;
        u16RemPage+=(gsRdlinkInfo.u16RiskyFreePagePtr-gsRdlinkInfo.u16RiskyStartPagePtr);

        if(u16RemPage>=(u16SLCBankPlane-(g16ChkFlushSize/g4kNumPerPlane)))
        {
            u16HdlOpFpagePtr=((u16HdlOpFpagePtr+u16SLCBankPlane-1)/u16SLCBankPlane)*u16SLCBankPlane;
        }
    }
#endif/* if _EN_RAID_UGSD */

    // hdmaClrRam(c32Tsb0SAddr, gSectorPerPlaneH*u16HdlOpFpagePtr, 0x55AA_55AA, cClrTsb|cHdmaNotWait);
    bopClrRam(c32Tsb0SAddr, gSectorPerPageH<<9, 0x55AA55AA, cClrTsb|cBopWait);
    uPageOfst=0;

    while((u16FreePagePtr<u16HdlOpFpagePtr)&&(u16FreePagePtr<g16PagePerBlock3_SLC))
    {
        usTmpAddrInfo.u16FBlock=u16FBlock;
        usTmpAddrInfo.u32FPageNoTran=(LWORD)u16FreePagePtr*g4kNumPerPlane;
        usTmpAddrInfo.uAddrOpt=uBlkId;
        usTmpAddrInfo.uPlaneCnt=g4kNumPerPlane;
        tranAddrInfo(&usTmpAddrInfo);

        // tranCeNum(&usTmpAddrInfo);
        // if(!uSetOneShotChPtr)
        // {
        //    uSetOneShotChPtr=1;
        //    gsRwCtrl.u32OneShotChPtr=usTmpAddrInfo.uCh;
        // }

        setFLAddrActCh(usTmpAddrInfo.uCh, &usTmpAddrInfo);
        gSectorH=0;

        if(!usTmpAddrInfo.uPlaneAddr)
        {
            uPageOfst=gPlaneNum;
            mSetFRwParam(c16Tsb0SIdx, gSectorPerPageH, c16Bit0|c16Bit2|c16Bit15, cPwrOnDummyProg);

            for(uPlaneAddr=0; uPlaneAddr<gPlaneNum; uPlaneAddr++)
            {
                setSprByteforPadDummy(uBlkId, u32Serial, uPlaneAddr);
            }
        }
        else
        {
            // debugLoop();
            uPageOfst=1;
            mSetFRwParam(c16Tsb0SIdx, gSectorPerPlaneH, c16Bit2|c16Bit15, cPwrOnDummyProg);
            setSprByteforPadDummy(uBlkId, u32Serial, gPlaneAddr);
        }

        mSetSprSetDone(gpFlashAddrInfo);    // gpFlashAddrInfo->uSprSetDone=1;
        mSetTabSpr(gpFlashAddrInfo, cBit5);    // gTabSpare=1;
        assignFreeBtDesAddrInfo();
        // gsRwCtrl.u32OneShotChPtr=addPtrBy1(gsRwCtrl.u32OneShotChPtr, gTotalChNum);
        // gsRwCtrl.uOneShotChOpenDesIdx[gsRwCtrl.u32OneShotChPtr]=gsRwCtrl.u32ProgFifoHead;
        waitCmdAllDone(cWaitTrigWCnt|cWaitCmdBz);
#if 0    // dubug
        mSetFRwParam(c16Tsb0SIdx+gSectorPerPageH, gSectorPerPageH, c16Bit0|c16Bit15, cReadCmdAle);
        assignFreeBtSrcAddrInfo();
#if (!_HwPlane2SprIssue)
        usTmpAddrInfo.uPlaneAddr=0;
        mSetFRwParam(c16Tsb0SIdx+gSectorPerPageH, gSectorPerPageH, c16Bit0|c16Bit2|c16Bit4|c16Bit5|c16Bit10|c16Bit14, cReadData);
        gSectorH=0;
        assignFreeBtSrcAddrInfo();
        waitCmdAllDone(cWaitTrigRCnt|cWaitCmdBz);

        for(uPlaneAddr=0; uPlaneAddr<gPlaneNum; uPlaneAddr++)
        {
            if(mChkBitMask(gPlaneUNCSts[usTmpAddrInfo.uCh], uPlaneAddr))
            {
                debugLoop();
            }
            else
            {
                getSprByte(&usBlkSprInfo[uPlaneAddr], uPlaneAddr);
            }
        }
#else/* if (!_HwPlane2SprIssue) */
        for(uPlaneAddr1=0; uPlaneAddr1<gPlaneNum; uPlaneAddr1+=2)
        {
            usTmpAddrInfo.uPlaneAddr=uPlaneAddr1;
            mSetFRwParam(c16Tsb0SIdx+gSectorPerPageH+uPlaneAddr1*gSectorPerPlaneH,
                         gSectorPerPlaneH<<1,
                         c16Bit0|c16Bit2|c16Bit4|c16Bit5|c16Bit10|c16Bit14,
                         cReadData);
            gSectorH=0;
            assignFreeBtSrcAddrInfo();
            waitCmdAllDone(cWaitTrigRCnt|cWaitCmdBz);

            for(uPlaneAddr=uPlaneAddr1; uPlaneAddr<uPlaneAddr1+2; uPlaneAddr++)
            {
                if(mChkBitMask(gPlaneUNCSts[usTmpAddrInfo.uCh], uPlaneAddr))
                {
                    debugLoop();
                }
                else
                {
                    getSprByte(&usBlkSprInfo[uPlaneAddr], uPlaneAddr);
                }
            }
        }
#endif/* if (!_HwPlane2SprIssue) */
#endif/* if 1 */
        u16FreePagePtr+=uPageOfst;
    }

    gsRwCtrl.u32UpdFifoPtr=gsRwCtrl.u32ProgFifoTail;

    return u16FreePagePtr;
}    /* dummyProgOpenWL */

void rebuCacheF2hTable()
{
#if _FlushLast2F2h
    WORD    /*u16FreeFPage=c16BitFF, */ u16FreePgPtr=c16BitFF;
    WORD u16StartRiskFPage=c16BitFF, u16StartRiskPgPtr=c16BitFF;
    WORD    /*u16StartRiskFPage=c16BitFF,*/ u16EndRiskPgPtr=c16BitFF;
    WORD u16FirstEmptyPgPtr=c16BitFF;
    WORD u16FirstEmptyPgPtr2=c16BitFF;
    WORD u16LastNoDumPtr;
    WORD u16FBlock1, u16FBlock2;
    LWORD u32Serial1=0, u32Serial2=0;
    BLKSPRINFO usBlkSprInfo;
    BLKSPRINFO usBlkSprInfo2;
    BYTE uLastBank;
    RLFLUSHF2HTAB usFlushF2hTab;
#if _EN_KEEP_RW_ON_ERROR
    WORD u16Loop1=0, u16Loop2=0;
    FOUNDQINFO usBackUpFoundQ;
#endif
#else/* if _FlushLast2F2h */
    WORD u16Loop, u16GrpPtr;
#endif/* if _FlushLast2F2h */

    saveRdTimeStamp(7);

    // debugLoop();
#if _FlushLast2F2h
    usFlushF2hTab.uCnt=0;

    if(g16FoundCachebCnt)
    {
        // cache info table not exit  or  find old cache info table
        if((!gsRdlinkInfo.ubCacheInfoValid)||(g16FoundCachebCnt>2))
        {
#if _EN_KEEP_RW_ON_ERROR
            relinkKeepRwonError((((BYTE)g16FoundCachebCnt<<8)|cRebuCacheF2hTable1),
                                garFoundCacheQ[g16arFoundCacheIdx[0]].u16FBlock,
                                garFoundCacheQ[g16arFoundCacheIdx[1]].u16FBlock,
                                garFoundCacheQ[g16arFoundCacheIdx[2]].u16FBlock);

            if(g16FoundCachebCnt>2)
            {
                for(u16Loop1=0; u16Loop1<g16FoundCachebCnt; u16Loop1++)
                {
                    u16Loop2=u16Loop1;
                    u32Serial1=garFoundCacheQ[g16arFoundCacheIdx[u16Loop2-1]].u32Serial;
                    u32Serial2=garFoundCacheQ[g16arFoundCacheIdx[u16Loop2]].u32Serial;

                    while((u16Loop2>0)&&(u32Serial1>u32Serial2))
                    {
                        usBackUpFoundQ=garFoundCacheQ[g16arFoundCacheIdx[u16Loop2]];
                        garFoundCacheQ[g16arFoundCacheIdx[u16Loop2]]=garFoundCacheQ[g16arFoundCacheIdx[u16Loop2-1]];
                        garFoundCacheQ[g16arFoundCacheIdx[u16Loop2-1]]=usBackUpFoundQ;
                        u16Loop2--;

                        if(u16Loop2>0)
                        {
                            u32Serial1=garFoundCacheQ[g16arFoundCacheIdx[u16Loop2-1]].u32Serial;
                            u32Serial2=garFoundCacheQ[g16arFoundCacheIdx[u16Loop2]].u32Serial;
                        }
                    }
                }

                garFoundCacheQ[g16arFoundCacheIdx[0]]=garFoundCacheQ[g16arFoundCacheIdx[g16FoundCachebCnt-2]];
                garFoundCacheQ[g16arFoundCacheIdx[1]]=garFoundCacheQ[g16arFoundCacheIdx[g16FoundCachebCnt-1]];
                g16FoundCachebCnt=2;    // search max 2 series
            }
            else if(!gsRdlinkInfo.ubCacheInfoValid)
            {
                mSetCacheInfoSpf(crelinkWhileFormat);
            }
#else/* if _EN_KEEP_RW_ON_ERROR */
            relinkSaveDummyQBAnalysis(g16FoundCachebCnt,
                                      garFoundCacheQ[g16arFoundCacheIdx[0]].u16FBlock,
                                      garFoundCacheQ[g16arFoundCacheIdx[1]].u16FBlock,
                                      garFoundCacheQ[g16arFoundCacheIdx[2]].u16FBlock);
            relinkSaveQBDummy(cRebuCacheF2hTable1);
#endif/* if _EN_KEEP_RW_ON_ERROR */
        }

        u16FBlock1=garFoundCacheQ[g16arFoundCacheIdx[g16FoundCachebCnt-1]].u16FBlock;
        u32Serial1=garFoundCacheQ[g16arFoundCacheIdx[g16FoundCachebCnt-1]].u32Serial;

        u16LastNoDumPtr=getFirstFullPage(u16FBlock1, cCacheBlockID, cUseSlcMode, &usBlkSprInfo2, &u16FirstEmptyPgPtr2, 1);    // 20190305_ChrisSu
        u16FreePgPtr=getFirstFullPage(u16FBlock1, cCacheBlockID, cUseSlcMode, &usBlkSprInfo, &u16FirstEmptyPgPtr, 0);    // 20190305_ChrisSu
        u16EndRiskPgPtr=u16LastNoDumPtr-1;

        // u16StartRiskFPage: last full valid page
        u16StartRiskFPage=u16LastNoDumPtr/gTotalIntlvChPlaneNum;

        if(u16StartRiskFPage)
        {
            u16StartRiskFPage--;
        }

        u16StartRiskPgPtr=u16StartRiskFPage*gTotalIntlvChPlaneNum;

        // NLOG(cLogBuild, REBUCACHEF2HTAB_C, 3, "risky,empty,free:[0x%04X, 0x%04X, 0x%04X] ",
        //    (WORD)u16StartRiskPgPtr, (WORD)u16FirstEmptyPgPtr, (WORD)u16FreePgPtr);

        uLastBank=((LWORD)(u16LastNoDumPtr-1)*g4kNumPerPlane)/g16TotalPgPerF2hTab;    // 20190305_ChrisSu

        // NLOG(cLogBuild, REBUCACHEF2HTAB_C, 4, "1.
        // u16RiskyStartPagePtr:0x%04X,u16FirstEmptyPagePtr:0x%04X,u16RiskyEndPagePtr:0x%04X,u16RiskyFreePagePtr:0x%04X ",
        //    (WORD)gsRdlinkInfo.u16RiskyStartPagePtr, (WORD)gsRdlinkInfo.u16FirstEmptyPagePtr, (WORD)gsRdlinkInfo.u16RiskyEndPagePtr,
        // (WORD)gsRdlinkInfo.u16RiskyFreePagePtr);

        BYTE uRiskyStartBank=((LWORD)u16StartRiskPgPtr*g4kNumPerPlane)/g16TotalPgPerF2hTab;
        BYTE uRiskyEndBank=((LWORD)u16EndRiskPgPtr*g4kNumPerPlane)/g16TotalPgPerF2hTab;

        // modify u16StartRiskPgPtr to the start page of current bank
        u16StartRiskPgPtr=(uRiskyStartBank*g16TotalPgPerF2hTab)/g4kNumPerPlane;

        if(uRiskyStartBank!=uRiskyEndBank)
        {
            // if cross bank, modify u16EndRiskPgPtr to the end page of current bank
            //  u16FirstEmptyPgPtr=(uRiskyEndBank*g16TotalPgPerF2hTab)/g4kNumPerPlane;
            //  u16EndRiskPgPtr=u16FirstEmptyPgPtr-1;
            //  uRiskyEndBank=((LWORD)u16EndRiskPgPtr*g4kNumPerPlane)/g16TotalPgPerF2hTab;

            NLOG(cLogBuild, REBUCACHEF2HTAB_C, 2, "cross bank!, startbank =0x%04x, endbank=0x%04x", uRiskyStartBank, uRiskyEndBank);
            NLOG(cLogBuild,
                 REBUCACHEF2HTAB_C,
                 3,
                 "Origin u16StartRiskPgPtr=0x%04x,u16EndRiskPgPtr=0x%04x, u16FirstEmptyPgPtr=0x%04x,",
                 u16StartRiskPgPtr,
                 u16EndRiskPgPtr,
                 u16FirstEmptyPgPtr);

            u16StartRiskPgPtr=(uRiskyEndBank*g16TotalPgPerF2hTab)/g4kNumPerPlane;    // 20190131_ChrisSu
            uRiskyStartBank=((LWORD)u16StartRiskPgPtr*g4kNumPerPlane)/g16TotalPgPerF2hTab;
            NLOG(cLogBuild,
                 REBUCACHEF2HTAB_C,
                 2,
                 " modify uRiskyStartBank to the end page of current u16StartRiskPgPtr=0x%04x, uRiskyStartBank=0x%04x",
                 u16StartRiskPgPtr,
                 uRiskyStartBank);

            while(uRiskyStartBank!=uRiskyEndBank)
                ;

            // TODO: check whether modify last bank, g16FoundCachebCnt.
        }

        gsRdlinkInfo.u16RiskyStartPagePtr=u16StartRiskPgPtr;
        gsRdlinkInfo.u16FirstEmptyPagePtr=u16FirstEmptyPgPtr;
        gsRdlinkInfo.u16RiskyEndPagePtr=u16EndRiskPgPtr;    // (u16FreePgPtr-1);  //20190305_ChrisSu

        if(gsRdlinkInfo.u16RiskyEndPagePtr>((g16SlcProgF2hTabStr+(g16TotalPgPerF2hTab*uRiskyEndBank))/g4kNumPerPlane))
        {
            gsRdlinkInfo.u16RiskyEndPagePtr=(((g16SlcProgF2hTabStr+(g16TotalPgPerF2hTab*uRiskyEndBank))/g4kNumPerPlane)-1);
        }

        gsRdlinkInfo.u16RiskyFreePagePtr=gsRdlinkInfo.u16DummyProgPagePtr=u16FreePgPtr;

#if (_EN_RDLINK_PF)
        if(gsRdlinkInfo.ubCacheInfoValid&&
           (u16FBlock1==g16BkRdActiveCacheBlock)&&
           (u32Serial1==g32BkRdActCBlkSerial)&&
           (uLastBank==gBkRdActF2hTabBank))
        {
            // If current actCacheBlk(u16FBlock1) is the same as the record(g16BkRdActiveCacheBlock) in cacheInfo,
            // the flushCacheBlk may be not the last 2nd bank due to padding dummy at last rdlink,
            // We must set flushCacheBlk using the record(g16BkRdFlushCacheBlock) in cacheInfo instead of the last 2nd bank.

            if(g16BkRdFlushCacheBlock!=c16FBlockInitValue)
            {
                addRdlinkReBuCacheBlock(g16BkRdFlushCacheBlock, gBkRdFlsF2hTabBank);
                addReBuCacheBlock(&usFlushF2hTab, g32BkRdFlsCBlkSerial, g16BkRdFlushCacheBlock, gBkRdFlsF2hTabBank);
            }

            addRdlinkReBuCacheBlock(g16BkRdActiveCacheBlock, gBkRdActF2hTabBank);
            addReBuCacheBlock(&usFlushF2hTab, g32BkRdActCBlkSerial, g16BkRdActiveCacheBlock, gBkRdActF2hTabBank);

            while(g16BkRdActiveCacheBlock!=u16FBlock1)
                ;
        }
        else
        {
            // If host write to next bank of g16BkRdActiveCacheBlock at last runtime, the actCacheBlk and flushCacheBlk are last 2 banks.
#endif/* if (_EN_RDLINK_PF) */

        if(g16FoundCachebCnt==2)    // active cache & flush block all has data
        {
            if(!uLastBank)
            {
                u16FBlock2=garFoundCacheQ[g16arFoundCacheIdx[g16FoundCachebCnt-2]].u16FBlock;
                u32Serial2=garFoundCacheQ[g16arFoundCacheIdx[g16FoundCachebCnt-2]].u32Serial;
                addRdlinkReBuCacheBlock(u16FBlock2, (mChkMlcMoBit(u16FBlock2)?(gTotalTlcBankOfF2hTab-1):(gTotalBankOfF2hTab-1)));
                addReBuCacheBlock(&usFlushF2hTab, u32Serial2, u16FBlock2,
                                  (mChkMlcMoBit(u16FBlock2)?(gTotalTlcBankOfF2hTab-1):(gTotalBankOfF2hTab-1)));
            }
            else
            {
                addRdlinkReBuCacheBlock(u16FBlock1, uLastBank-1);
                addReBuCacheBlock(&usFlushF2hTab, u32Serial1, u16FBlock1, uLastBank-1);
            }
        }
        else    // active cache or flush block has data
        {
            if(uLastBank)
            {
                addRdlinkReBuCacheBlock(u16FBlock1, uLastBank-1);
                addReBuCacheBlock(&usFlushF2hTab, u32Serial1, u16FBlock1, uLastBank-1);
            }
        }

        addRdlinkReBuCacheBlock(u16FBlock1, uLastBank);
        addReBuCacheBlock(&usFlushF2hTab, u32Serial1, u16FBlock1, uLastBank);
#if (_EN_RDLINK_PF)
    }
#endif

        NLOG(cLogBuild,
             REBUCACHEF2HTAB_C,
             7,
             "2.u16RiskyStartPagePtr:0x%04X,u16FirstEmptyPagePtr:0x%04X,u16RiskyEndPagePtr:0x%04X,u16RiskyFreePagePtr:0x%04X,uRiskyBank:[0x%04X,0x%04X,0x%04X] ",
             (WORD)gsRdlinkInfo.u16RiskyStartPagePtr,
             (WORD)gsRdlinkInfo.u16FirstEmptyPagePtr,
             (WORD)gsRdlinkInfo.u16RiskyEndPagePtr,
             (WORD)gsRdlinkInfo.u16RiskyFreePagePtr,
             (WORD)uRiskyStartBank,
             (WORD)uRiskyEndBank,
             (WORD)uLastBank);

        NLOG(cLogBuild, REBUCACHEF2HTAB_C, 5, "rebuCnt:0x%04X,rebuBlk:[0x%04X,0x%04X],rebuBank:[0x%04X,0x%04X] ",
             (WORD)usFlushF2hTab.uCnt,
             (WORD)usFlushF2hTab.u16arBlock[0], (WORD)usFlushF2hTab.u16arBlock[1],
             (WORD)usFlushF2hTab.uarBankNum[0], (WORD)usFlushF2hTab.uarBankNum[1]);

        NLOG(cLogBuild, REBUCACHEF2HTAB_C, 4, " BkActCheBlk1:[0x%04X,0x%04X,0x%04X,0x%04X] ",
             (WORD)g16BkRdActiveCacheBlock, (WORD)gBkRdActF2hTabBank, (WORD)(g32BkRdActCBlkSerial>>16), (WORD)g32BkRdActCBlkSerial);

        NLOG(cLogBuild, REBUCACHEF2HTAB_C, 4, " BkFlsCheBlk1:[0x%04X,0x%04X,0x%04X,0x%04X] ",
             (WORD)g16BkRdFlushCacheBlock, (WORD)gBkRdFlsF2hTabBank, (WORD)(g32BkRdFlsCBlkSerial>>16), (WORD)g32BkRdFlsCBlkSerial);

        // TODO: _EN_RAID_UGSD pre-encode raid parity here.

        if(gsRdlinkInfo.u16RiskyFreePagePtr<g16PagePerBlock3_SLC)
        {
            gsRdlinkInfo.u16DummyProgPagePtr=dummyProgOpenWL(u16FBlock1,
                                                             gsRdlinkInfo.u16RiskyFreePagePtr,
                                                             u32Serial1,
                                                             cHdlOpWLNum,
                                                             cCacheBlockID);
        }

        // NLOG(cLogBuild, REBUCACHEF2HTAB_C, 5, "RiskyStart:0x%04X,FirstEmpty:0x%04X,RiskyEnd:0x%04X,RiskyFree:0x%04X,DummyProg:0x%04X ",
        //    (WORD)gsRdlinkInfo.u16RiskyStartPagePtr, (WORD)gsRdlinkInfo.u16FirstEmptyPagePtr, (WORD)gsRdlinkInfo.u16RiskyEndPagePtr,
        // (WORD)gsRdlinkInfo.u16RiskyFreePagePtr, gsRdlinkInfo.u16DummyProgPagePtr);

        gsRdlinkInfo.u16RiskyBlock=u16FBlock1;
#if _EN_RDLINK_PF
        // only read flushBlk to f2h buffer
        recoverCacheF2hTab(&usFlushF2hTab);
#else
        // only update last 2 F2h bank
        flushCacheF2hInRdlink(&usFlushF2hTab);
#endif

        if(gsRdlinkInfo.u16DummyProgPagePtr<g16PagePerBlock3_SLC)
        {
/*
   *          if(mChkMlcMoBit(u16FBlock1))
   *          {
   *              gsCacheInfo.uMaxBankNum=gTotalTlcBankOfF2hTab;
   *              gsCacheInfo.u16ValidPgPerF2hTab=g16TlcValidPgPerF2hTab;
   *              gsCacheInfo.u4KNumToPadF2h=gTlc4KNumToPadF2h;
   *              gsCacheInfo.uPadF2h4KNum=gTlcPadF2h4KNum;
   *              gsCacheInfo.u16TotalPgPerF2hTab=g16TotalTlcPgPerF2hTab;
   *              gsCacheInfo.uProgF2HRem4KNum=gTlcProgF2HRem4KNum;
   *              gsCacheInfo.uSecNumPadF2h_1=gTlcSecNumPadF2h_1;
   *              gsCacheInfo.u16F2hPadStartAddr_2=g16TlcF2hPadStartAddr_2;
   *              gsCacheInfo.u16F2hChkFlushStart=g16TlcF2hChkStart;
   *              gsCacheInfo.u16F2hChkFlushSize=g16TlcF2hChkSize;
   #if _ENABLE_RAID
   *              gsCacheInfo.u16PartialParityNum=g16TlcPartialParityNum;
   *              gsCacheInfo.u16ProgRaidChStr4K=g16TlcProgRaidChStr4K;
   #endif
   *          }
   *          else
   *          {
   */
            gsCacheInfo.uMaxBankNum=gTotalBankOfF2hTab;
            gsCacheInfo.u16ValidPgPerF2hTab=g16ValidPgPerF2hTab;
            gsCacheInfo.u4KNumToPadF2h=gSlc4KNumToPadF2h;
            gsCacheInfo.uPadF2h4KNum=gSlcPadF2h4KNum;
            gsCacheInfo.u16TotalPgPerF2hTab=g16TotalPgPerF2hTab;
            gsCacheInfo.uProgF2HRem4KNum=gSlcProgF2HRem4KNum;
            gsCacheInfo.uSecNumPadF2h_1=gSlcSecNumPadF2h_1;
            gsCacheInfo.u16F2hPadStartAddr_2=g16SlcF2hPadStartAddr_2;
            gsCacheInfo.u16F2hChkFlushStart=g16SlcF2hChkStart;
            gsCacheInfo.u16F2hChkFlushSize=g16SlcF2hChkSize;
#if _ENABLE_RAID
            gsCacheInfo.u16PartialParityNum=g16SlcPartialParityNum;
            gsCacheInfo.u16ProgRaidChStr4K=g16SlcProgRaidChStr4K;
#endif/* if _ENABLE_RAID */
            // }

            gsCacheInfo.u32CacheFreePagePtr=gsRdlinkInfo.u16DummyProgPagePtr*g4kNumPerPlane;
            gsCacheInfo.u16ActiveCacheBlock=u16FBlock1;
            gsCacheInfo.u16CacheF2hTabFreePtr=gsCacheInfo.u16TotalPgPerF2hTab-
                                               (gsCacheInfo.u32CacheFreePagePtr%gsCacheInfo.u16TotalPgPerF2hTab)-1;
            gsCacheInfo.uF2hTabBank=gsCacheInfo.u32CacheFreePagePtr/gsCacheInfo.u16TotalPgPerF2hTab;
            gsCacheInfo.u32SrchF4kBase=(gsCacheInfo.uF2hTabBank+1)*gsCacheInfo.u16TotalPgPerF2hTab-1;
            mClrCacheInfoFlag(cCacheBlockFull);
            gsCacheInfo.u32CacheBlkSerial=g32BkCacheBlkSerial;
        }
        else
        {
            mSetCacheInfoFlag(cCacheBlockFull);
        }

        // if((gsRdlinkInfo.u16BkActiveCacheBlock==u16FBlock1)&&(gsRdlinkInfo.u16RiskyStartPagePtr!=c16BitFF))
        {
            // u16FBlock1 is flush block case, do not need move risky page
            gsGcInfo.uGcQueueCnt=gsGcInfo.uGcTypBit=gsGcInfo.ubBgdProcF=0;
#if _EN_RDLINK_PF
            moveRiskyPage(&usFlushF2hTab);
#else
            moveRiskyPage();

            if(mChkCacheInfoFlag(cMoveProgramFail))
            {
                while(mChkCacheInfoFlag(cMoveProgramFail)==cMoveProgramFail)
                {
                    moveRiskyPage();
                }
            }
#endif
        }

        // bopClrRam((LWORD)garCacheF2hTab, c32CacheF2hRamSize, 0xFFFFFFFF, cClrTsb|cBopWait);
    }
#else/* if 0 */
    // separete found cache block (active cache/ Gc Des/ TLC)
    for(u16Loop=0; u16Loop<g16FoundCachebCnt; )
    {
        u16GrpPtr=g16arFoundCacheIdx[u16Loop];
        addCacheFblock(u16GrpPtr);
        u16Loop++;
    }
#endif/* if _FlushLast2F2h */

    if(gsRdlinkInfo.ubCacheInfoValid&&(g32BkCacheBlkSerial!=c32InitSerialVal))
    {
        while(judgeSerial(gsCacheInfo.u32CacheBlkSerial, g32BkCacheBlkSerial)==cSerialSmaller)
            ;
    }

    saveRdTimeStamp(8);

    if(gsRdlinkInfo.ubCacheInfoValid)
    {
#if _EN_VPC_SWAP
#if (_EN_RDLINK_PF)
        if((gsRdlinkInfo.u16BkActiveCacheBlock!=c16FBlockInitValue)&&(!mChkVPCntValid(gsRdlinkInfo.u16BkActiveCacheBlock))&&
           (gsRdlinkInfo.u16BkActiveCacheBlock!=gsCacheInfo.u16ActiveCacheBlock)&&
           (gsRdlinkInfo.u16BkActiveCacheBlock!=gsCacheInfo.u16FluCacheBlock))
#else
        if((gsRdlinkInfo.u16BkActiveCacheBlock!=c16FBlockInitValue)&&(!mChkVPCntValid(gsRdlinkInfo.u16BkActiveCacheBlock)))
#endif
#else
#if (_EN_RDLINK_PF)
        if((gsRdlinkInfo.u16BkActiveCacheBlock!=c16FBlockInitValue)&&(mGetCacheBlkVpCnt(gsRdlinkInfo.u16BkActiveCacheBlock)==0)&&
           (gsRdlinkInfo.u16BkActiveCacheBlock!=gsCacheInfo.u16ActiveCacheBlock)&&
           (gsRdlinkInfo.u16BkActiveCacheBlock!=gsCacheInfo.u16FluCacheBlock))
#else
        if((gsRdlinkInfo.u16BkActiveCacheBlock!=c16FBlockInitValue)&&(mGetCacheBlkVpCnt(gsRdlinkInfo.u16BkActiveCacheBlock)==0))
#endif
#endif
        {
            mSetSkipGcBit(gsRdlinkInfo.u16BkActiveCacheBlock);
            // destroySrcBlock(gsRdlinkInfo.u16BkActiveCacheBlock);
            pushSpareBlockCore0(gsRdlinkInfo.u16BkActiveCacheBlock, cPushNotErase);
            // mSetCacheInfoFlag(cCacheBlockFull);
        }

#if _EN_VPC_SWAP
#if (_EN_RDLINK_PF)
        if((gsRdlinkInfo.u16BkFluCacheBlock!=c16FBlockInitValue)&&(!mChkVPCntValid(gsRdlinkInfo.u16BkFluCacheBlock))&&
           (gsRdlinkInfo.u16BkFluCacheBlock!=gsCacheInfo.u16ActiveCacheBlock)&&(gsRdlinkInfo.u16BkFluCacheBlock!=gsCacheInfo.u16FluCacheBlock))
#else
        if((gsRdlinkInfo.u16BkFluCacheBlock!=c16FBlockInitValue)&&(!mChkVPCntValid(gsRdlinkInfo.u16BkFluCacheBlock))&&
           (gsRdlinkInfo.u16BkFluCacheBlock!=gsRdlinkInfo.u16BkActiveCacheBlock))
#endif
#else
#if (_EN_RDLINK_PF)
        if((gsRdlinkInfo.u16BkFluCacheBlock!=c16FBlockInitValue)&&(mGetCacheBlkVpCnt(gsRdlinkInfo.u16BkFluCacheBlock)==0)&&
           (gsRdlinkInfo.u16BkFluCacheBlock!=gsCacheInfo.u16ActiveCacheBlock)&&(gsRdlinkInfo.u16BkFluCacheBlock!=gsCacheInfo.u16FluCacheBlock))
#else
        if((gsRdlinkInfo.u16BkFluCacheBlock!=c16FBlockInitValue)&&(mGetCacheBlkVpCnt(gsRdlinkInfo.u16BkFluCacheBlock)==0)&&
           (gsRdlinkInfo.u16BkFluCacheBlock!=gsRdlinkInfo.u16BkActiveCacheBlock))
#endif
#endif
        {
            mSetSkipGcBit(gsRdlinkInfo.u16BkFluCacheBlock);
            // destroySrcBlock(gsRdlinkInfo.u16BkFluCacheBlock);
            pushSpareBlockCore0(gsRdlinkInfo.u16BkFluCacheBlock, cPushNotErase);
        }

        if((gsRdlinkInfo.u16BkPrePopCacheBlock!=c16FBlockInitValue)&&(mGetCacheBlkVpCnt(gsRdlinkInfo.u16BkPrePopCacheBlock)==0))
        {
            mSetSkipGcBit(gsRdlinkInfo.u16BkPrePopCacheBlock);
            // destroySrcBlock(gsRdlinkInfo.u16BkPrePopCacheBlock);
            pushSpareBlockCore0(gsRdlinkInfo.u16BkPrePopCacheBlock, cPushNotErase);
        }
    }

    saveRdTimeStamp(9);

    if(gsCacheInfo.u32FluBlkSerial==c32InitSerialVal)
    {
        // 20150828, add for power on go to GC while host does not write data
        // because we have set flush block serial number at GC Des block spare
        // at this situation the cache block serial must not equal to c32InitSerialVal
        gsCacheInfo.u32FluBlkSerial=gsCacheInfo.u32CacheBlkSerial;
    }

    // test end
#if _EN_RDLINK_PF
    g16BkRdActiveCacheBlock=gsCacheInfo.u16ActiveCacheBlock;
    g32BkRdCacheFreePagePtr=gsCacheInfo.u32CacheFreePagePtr;
    g32BkRdActCBlkSerial=gsCacheInfo.u32CacheBlkSerial;
    g16BkCacheF2hTabFreePtr=gsCacheInfo.u16CacheF2hTabFreePtr;
    gBkRdActF2hTabBank=gsCacheInfo.uF2hTabBank;

    g16BkRdFlushCacheBlock=gsCacheInfo.u16FluCacheBlock;
    gBkRdFlsF2hTabBank=gsCacheInfo.uFlushCacheBlkBank;
    g32BkRdFlsCBlkSerial=gsCacheInfo.u32FluBlkSerial;
#else
    if(!mChkCacheInfoFlag(cCacheBlockFull))
    {
        g16BkRdActiveCacheBlock=gsCacheInfo.u16ActiveCacheBlock;
        g32BkRdCacheFreePagePtr=gsCacheInfo.u32CacheFreePagePtr;
        g32BkRdActCBlkSerial=gsCacheInfo.u32CacheBlkSerial;
        g16BkCacheF2hTabFreePtr=gsCacheInfo.u16CacheF2hTabFreePtr;
        gBkRdActF2hTabBank=gsCacheInfo.uF2hTabBank;

        g16BkRdFlushCacheBlock=gsCacheInfo.u16FluCacheBlock;
        gBkRdFlsF2hTabBank=gsCacheInfo.uFlushCacheBlkBank;
        g32BkRdFlsCBlkSerial=gsCacheInfo.u32FluBlkSerial;
        // gBkActSeedOfst=gsCacheInfo.uActSeedOfst;
    }
    else
    {
        mSetCacheInfoFlag(cCacheBlockFull);

        g16BkRdFlushCacheBlock=gsCacheInfo.u16ActiveCacheBlock;
        gBkRdFlsF2hTabBank=gsCacheInfo.uF2hTabBank;
        g32BkRdFlsCBlkSerial=gsCacheInfo.u32CacheBlkSerial;

        gsCacheInfo.u16ActiveCacheBlock=c16FBlockInitValue;
        gsCacheInfo.u32CacheFreePagePtr=c32BitFF;
        g16BkRdActiveCacheBlock=c16FBlockInitValue;
        g32BkRdCacheFreePagePtr=c32BitFF;
    }
#endif/* if _EN_RDLINK_PF */

    NLOG(cLogBuild, REBUCACHEF2HTAB_C, 4, " BkActCheBlk2:[0x%04X,0x%04X,0x%04X,0x%04X] ",
         (WORD)g16BkRdActiveCacheBlock, (WORD)gBkRdActF2hTabBank, (WORD)(g32BkRdActCBlkSerial>>16), (WORD)g32BkRdActCBlkSerial);

    NLOG(cLogBuild, REBUCACHEF2HTAB_C, 4, " BkFlsCheBlk2:[0x%04X,0x%04X,0x%04X,0x%04X] ",
         (WORD)g16BkRdFlushCacheBlock, (WORD)gBkRdFlsF2hTabBank, (WORD)(g32BkRdFlsCBlkSerial>>16), (WORD)g32BkRdFlsCBlkSerial);

    // if(gsRdlinkInfo.ubSaveCacheInfo)
    // {
    //    progCacheInfoTab();
    // }
}    /* rebuCacheF2hTable */

void restoSrcInCacheF2hTab(WORD u16SbufPtr)
{
    // _Uncached F2HTABLE *upEofF2hTab=garCacheF2hTab+g16TotalPgPerF2hTab;

    F2HTABLE *upF2hTabStPtr=(F2HTABLE *)(c32Tsb0SAddr+(u16SbufPtr<<9));
    F2HTABLE *upEofF2hTab=(F2HTABLE *)(c32Tsb0SAddr+(u16SbufPtr<<9))+g16TotalPgPerF2hTab;

    while(upF2hTabStPtr!=upEofF2hTab)
    {
        if(upF2hTabStPtr->u16HBlock!=c16BitFF)
        {
            upF2hTabStPtr->u16HBlock&=~c16Bit15;

            // debug purpose
            if((upF2hTabStPtr->u16HBlock!=c16Bit15)&&(upF2hTabStPtr->u16HBlock>g16TotalHBlock))
            {
                volatile BYTE uTestFlag=1;
                WORD u16Hblock=upF2hTabStPtr->u16HBlock;
#if 0    // _INITDRAM
                outCS("CS. buildBlockF2hTab()");
                outString("u16Hblock=@", u16Hblock);
                outString("g16TotalHBlock=@", g16TotalHBlock);
#endif

                while(uTestFlag&&u16Hblock&&upF2hTabStPtr)
                    ;
            }

            // if (!mChkSrcInCache(upF2hTabStPtr->u16HBlock))
            // {
            // mSetSrcInCache(upF2hTabStPtr->u16HBlock);
            // }
        }

        upF2hTabStPtr++;
    }
}    /* restoCacheF2hTab */

void restoCacheF2hTab(WORD u16SbufPtr)
{
    // _Uncached F2HTABLE *upEofF2hTab=garCacheF2hTab+g16TotalPgPerF2hTab;

    F2HTABLE *upF2hTabStPtr=(F2HTABLE *)(c32Tsb0SAddr+(u16SbufPtr<<9));
    F2HTABLE *upEofF2hTab=(F2HTABLE *)(c32Tsb0SAddr+(u16SbufPtr<<9))+g16TotalPgPerF2hTab;

    while(upF2hTabStPtr!=upEofF2hTab)
    {
        if(upF2hTabStPtr->u16HBlock!=c16BitFF)
        {
            upF2hTabStPtr->u16HBlock&=~c16Bit15;

            // debug purpose
            if((upF2hTabStPtr->u16HBlock!=c16Bit15)&&(upF2hTabStPtr->u16HBlock>g16TotalHBlock))
            {
                volatile BYTE uTestFlag=1;
                WORD u16Hblock=upF2hTabStPtr->u16HBlock;

                while(uTestFlag&&u16Hblock&&upF2hTabStPtr)
                    ;
            }

            // if (!mChkSrcInCache(upF2hTabStPtr->u16HBlock))
            // {
            // mSetSrcInCache(upF2hTabStPtr->u16HBlock);
            // }
        }

        upF2hTabStPtr++;
    }
}    /* restoCacheF2hTab */

#if 0
/*
   *  no body call
   */

/****/
// Opt:
// Bit 0 : Reset Active Cache and Save Cache Info  (Original code using)
void setPOP(WORD u16GrpPtr, BYTE uOpt)
{
    WORD u16Fblock=garFoundCacheQ[u16GrpPtr].u16Fblock;

    if(mGetCacheBlkVpCnt(u16Fblock))
    {
        if(!mChkPoppedBit(u16Fblock))
        {
            mSetPoppedBit(u16Fblock);
        }
    }
    else
    {
        if(mChkPoppedBit(u16Fblock))
        {
            mClrPopDeniedF(u16Fblock);
            pushSpareBlockCore0(u16Fblock, cPushNotErase);
        }
        else
        {
            if(!mChkSlcSkipBit(u16Fblock))
            {
                gsCacheInfo.u16SpareBlockCnt++;
            }
            else
            {
                gsCacheInfo.u16TLCSprBlockCnt++;
            }

            mClrPopDeniedF(u16Fblock);
        }
    }

    addRdlinkLog(u16Fblock);
    addRdlinkLog((WORD)gsRdlinkInfo.ubRstDataInvalidF);    // Bit15:0 Typ:CacheBlk
    addRdlinkLog(gsCacheInfo.u32CacheBlkSerial>>16);
    addRdlinkLog(gsCacheInfo.u32CacheBlkSerial&0xFFFF);

    // addRdlinkLog(u16CacheWindow);
    if(uOpt&c16Bit0)
    {
        gsRdlinkInfo.ubSaveCacheInfo=1;
    }
}    /* setPOP */

#endif/* if 0 */

#if _EN_RDLINK_PF

// recover F2h table to last power off
void recoverCacheF2hTab(RLFLUSHF2HTAB *upFlushF2hTab)
{
    BYTE uF2hTabBank;
    // WORD u16RiskFPage;
    // WORD u16FlushPtr;
    WORD u16FBlock;
    LWORD u32BankStartPage;
    // LWORD u32Serial;
    BYTE uStatus;

/*
   *  NLOG(cLogFTL, REBUCACHEF2HTAB_C, 4, "recovF2h Blk:0x%04,VPC:0x%04X_%04X,ERS:0x%04X",
   *       gsCacheInfo.u16ActiveCacheBlock,
   *       (WORD)(g32arCacheBlkVpCnt[gsCacheInfo.u16ActiveCacheBlock]>>16),
   *       (WORD)g32arCacheBlkVpCnt[gsCacheInfo.u16ActiveCacheBlock],
   *       (WORD)g16arTempGlobEraseCnt[gsCacheInfo.u16ActiveCacheBlock]);
   */
    while(upFlushF2hTab->uCnt>2)
        ;

    bopClrRam((LWORD)g32arSrcInCacheFlag, c16MaxH2fTabNum/8, 0x00000000, cBopWait|cClrCore0Dccm);
    gsCacheInfo.u16HblkCntInCache=0;

    if(upFlushF2hTab->uCnt>1)
    {
        do
        {
            u16FBlock=upFlushF2hTab->u16arBlock[0];
            uF2hTabBank=upFlushF2hTab->uarBankNum[0];
            // u32Serial=upFlushF2hTab->u32arSerial[0];

            while(mChkMlcMoBit(u16FBlock))
                ;

            gsCacheInfo.u16ValidPgPerF2hTab=g16ValidPgPerF2hTab;
            gsCacheInfo.u16TotalPgPerF2hTab=g16TotalPgPerF2hTab;

            u32BankStartPage=(LWORD)uF2hTabBank*gsCacheInfo.u16TotalPgPerF2hTab;

            // modify the range more precise

            uStatus=readCacheF2hTab(c16CacheF2hTabSIdx, u16FBlock, u32BankStartPage+gsCacheInfo.u16ValidPgPerF2hTab, cF2hTableID);

            switch(uStatus)
            {
                case cRdFcbStsSuccess:
                    break;

                case cRdFcbStsDummy:

                    if(g16BkRdFlushCacheBlock==c16FBlockInitValue)
                    {
                        // volatile BYTE uStop=1;
                        // while(uStop);

                        gsRdlinkInfo.u16arReBuCacheBlock[0]=gsRdlinkInfo.u16arReBuCacheBlock[1];
                        gsRdlinkInfo.uarReBuCacheBlockBank[0]=gsRdlinkInfo.uarReBuCacheBlockBank[1];
                        gsRdlinkInfo.uRebuCachebCnt=1;

                        upFlushF2hTab->u32arSerial[0]=upFlushF2hTab->u32arSerial[1];
                        upFlushF2hTab->u16arBlock[0]=upFlushF2hTab->u16arBlock[1];
                        upFlushF2hTab->uarBankNum[0]=upFlushF2hTab->uarBankNum[1];
                        upFlushF2hTab->uCnt=1;
                    }
                    else
                    {
                        gsRdlinkInfo.u16arReBuCacheBlock[0]=g16BkRdFlushCacheBlock;
                        gsRdlinkInfo.uarReBuCacheBlockBank[0]=gBkRdFlsF2hTabBank;

                        upFlushF2hTab->u32arSerial[0]=g32BkRdFlsCBlkSerial;
                        upFlushF2hTab->u16arBlock[0]=g16BkRdFlushCacheBlock;
                        upFlushF2hTab->uarBankNum[0]=gBkRdFlsF2hTabBank;
                    }

                    break;

                case cRdFcbStsUnc:
                {
                    // if UNC , read F2h by buildBlockF2hTab
                    F2HTABLE *upF2hTabStPtr=garCacheF2hTab;

                    buildBlockF2hTab(u16FBlock,
                                     u32BankStartPage/(gTotalIntlvChNum*g4kNumPerPage),
                                     0xFFFF,
                                     cReadSprOnly|cAsignEofPgToRdData,
                                     upF2hTabStPtr);
                    break;
                }

                case cRdFcbStsWrongId:
                default:
                    gsRdlinkInfo.u16arReBuCacheBlock[0]=gsRdlinkInfo.u16arReBuCacheBlock[1];
                    gsRdlinkInfo.uarReBuCacheBlockBank[0]=gsRdlinkInfo.uarReBuCacheBlockBank[1];
                    gsRdlinkInfo.uRebuCachebCnt=1;

                    upFlushF2hTab->u32arSerial[0]=upFlushF2hTab->u32arSerial[1];
                    upFlushF2hTab->u16arBlock[0]=upFlushF2hTab->u16arBlock[1];
                    upFlushF2hTab->uarBankNum[0]=upFlushF2hTab->uarBankNum[1];
                    upFlushF2hTab->uCnt=1;

                    break;
            }    /* switch */

            // gsCacheInfo.u16CacheF2hTabFreePtr=gsCacheInfo.u16TotalPgPerF2hTab-1;    // for all src from u16FluCacheBlock in popCacheF2hTab
        }
        while((uStatus!=cRdFcbStsSuccess)&&(upFlushF2hTab->uCnt>1));
    }

    // TODO: verify full range
    // TODO: remove reset g32arSrcInCacheFlag and u16HblkCntInCache in recoverCacheF2hTab + flushF2h
    if(upFlushF2hTab->uCnt>1)
    {
        WORD u16F2hPtr;

        for(u16F2hPtr=0; u16F2hPtr<gsCacheInfo.u16TotalPgPerF2hTab; u16F2hPtr++)
        {
            if(!(garCacheF2hTab[u16F2hPtr].u16HBlock&c16Bit15))
            {
                if(!mChkSrcInCache(garCacheF2hTab[u16F2hPtr].u16HBlock))
                {
                    mSetSrcInCache(garCacheF2hTab[u16F2hPtr].u16HBlock);
                }
            }
        }

        gsCacheInfo.u16FluCacheBlock=upFlushF2hTab->u16arBlock[0];
        gsCacheInfo.uFlushCacheBlkBank=upFlushF2hTab->uarBankNum[0];
        gsCacheInfo.u32SrchF4kBaseFlu=(gsCacheInfo.uFlushCacheBlkBank+1)*gsCacheInfo.u16TotalPgPerF2hTab-1;
        gsCacheInfo.u32FluBlkSerial=upFlushF2hTab->u32arSerial[0];
    }
    else
    {
        // only active cache block bank
        bopClrRam((LWORD)garCacheF2hTab, c32CacheF2hRamSize, 0xFFFFFFFF, cClrTsb|cBopWait);

        gsCacheInfo.u16FluCacheBlock=c16FBlockInitValue;
        gsCacheInfo.uFlushCacheBlkBank=0;
        gsCacheInfo.u32SrchF4kBaseFlu=gsCacheInfo.u16TotalPgPerF2hTab-1;
        gsCacheInfo.u32FluBlkSerial=c32InitSerialVal;

        // TODO: remove after verify done.
        while(gsCacheInfo.u16HblkCntInCache)
            ;
    }

    gsCacheInfo.uMaxFlushBankNum=gsCacheInfo.uMaxBankNum;
    // gsCacheInfo.u16FlushTotalPgPerF2hTab=gsCacheInfo.u16TotalPgPerF2hTab;
}    /* recoverCacheF2hTab */

#else/* if _EN_RDLINK_PF */
void flushCacheF2hInRdlink(RLFLUSHF2HTAB *upFlushF2hTab)
{
    BYTE uF2hTabBank;
    WORD u16RiskFPage;
    WORD u16FlushPtr;
    WORD u16FBlock;
    LWORD u32BankStartPage;
    LWORD u32Serial;
    F2HTABLE *upF2hTabStPtr;
    BYTE uLoop;

    for(uLoop=0; uLoop<upFlushF2hTab->uCnt; uLoop++)
    {
        u16FBlock=upFlushF2hTab->u16arBlock[uLoop];

        if(mChkMlcMoBit(u16FBlock))
        {
            debugLoop(cFlushCacheF2hInRdlink1);
            // gsCacheInfo.uMaxBankNum=gTotalTlcBankOfF2hTab;
            gsCacheInfo.u16ValidPgPerF2hTab=g16TlcValidPgPerF2hTab;
            gsCacheInfo.u16TotalPgPerF2hTab=g16TotalTlcPgPerF2hTab;
        }
        else
        {
            // gsCacheInfo.uMaxBankNum=gTotalBankOfF2hTab;
            gsCacheInfo.u16ValidPgPerF2hTab=g16ValidPgPerF2hTab;
            gsCacheInfo.u16TotalPgPerF2hTab=g16TotalPgPerF2hTab;
        }

        uF2hTabBank=upFlushF2hTab->uarBankNum[uLoop];
        u32Serial=upFlushF2hTab->u32arSerial[uLoop];

        if((u32Serial<g32BkRdActCBlkSerial)||((uF2hTabBank<gBkRdActF2hTabBank)&&(u32Serial==g32BkRdActCBlkSerial)))
        {
            continue;
        }

        NLOG(cLogBuild, REBUCACHEF2HTAB_C, 2, "flushCacheF2hInRdlink,u16FBlock=0x%04x,uF2hTabBank =0x%04x  ", u16FBlock, (WORD)uF2hTabBank);

        u32BankStartPage=(LWORD)uF2hTabBank*gsCacheInfo.u16TotalPgPerF2hTab;

        upF2hTabStPtr=garCacheF2hTab;

        if(readCacheF2hTab(c16CacheF2hTabSIdx, u16FBlock, u32BankStartPage+gsCacheInfo.u16ValidPgPerF2hTab, cF2hTableID)!=cTrue)
        {
            // debugLoop();
            if(uLoop==(upFlushF2hTab->uCnt-1))    // handle risky page
            {
                u16RiskFPage=gsRdlinkInfo.u16RiskyStartPagePtr/gTotalIntlvChPlaneNum;
            }
            else
            {
                u16RiskFPage=0xFFFF;
            }

            buildBlockF2hTab(u16FBlock,
                             u32BankStartPage/(gTotalIntlvChNum*g4kNumPerPage),
                             u16RiskFPage,
                             cReadSprOnly|cAsignEofPgToRdData,
                             upF2hTabStPtr);
        }
        else
        {
            if(uLoop==(upFlushF2hTab->uCnt-1))    // handle risky page
            {
                upF2hTabStPtr=(F2HTABLE *)garCacheF2hTab+
                               (g16TotalPgPerF2hTab-(((LWORD)(gsRdlinkInfo.u16RiskyEndPagePtr+1)*g4kNumPerPlane-1)%g16TotalPgPerF2hTab)-1);
                u16FlushPtr=(gsRdlinkInfo.u16RiskyEndPagePtr-gsRdlinkInfo.u16RiskyStartPagePtr+1)*g4kNumPerPlane;
                bopClrRam((LWORD)upF2hTabStPtr, u16FlushPtr<<2, 0xFFFFFFFF, cClrTsb|cBopWait);
            }
        }

        restoCacheF2hTab(c16CacheF2hTabSIdx);

        gsCacheInfo.u16FluCacheBlock=u16FBlock;
        gsCacheInfo.uFlushCacheBlkBank=uF2hTabBank;

        if(gsRdlinkInfo.ubCacheInfoValid&&(u16FBlock==g16BkRdActiveCacheBlock)&&(u32Serial==g32BkRdActCBlkSerial)&&
           (uF2hTabBank==gBkRdActF2hTabBank))
        {
            if(g32BkRdCacheFreePagePtr>u32BankStartPage)
            {
                if((g32BkRdCacheFreePagePtr-u32BankStartPage)<gsCacheInfo.u16TotalPgPerF2hTab)
                {
                    for(u16FlushPtr=gsCacheInfo.u16TotalPgPerF2hTab-1; u16FlushPtr>g16BkCacheF2hTabFreePtr; u16FlushPtr--)
                    {
                        if((garCacheF2hTab[u16FlushPtr].u16HBlock!=0xFFFF)&&(garCacheF2hTab[u16FlushPtr].u16HPage!=0xFFFF))
                        {
                            garCacheF2hTab[u16FlushPtr].u16HBlock|=c16Bit15;
                        }
                    }

                    // gsCacheInfo.u16FlushF2hTabPtr=g16BkCacheF2hTabFreePtr;
                }
                else
                {
                    debugDeadLock(0x10);
                    // gsCacheInfo.u16FlushF2hTabPtr=gsCacheInfo.u16TotalPgPerF2hTab-1;
                }
            }
            else
            {
                // gsCacheInfo.u16FlushF2hTabPtr=gsCacheInfo.u16TotalPgPerF2hTab-1;
            }
        }
        else
        {
            // gsCacheInfo.u16FlushF2hTabPtr=gsCacheInfo.u16TotalPgPerF2hTab-1;
        }

        gsCacheInfo.u32SrchF4kBaseFlu=(uF2hTabBank+1)*gsCacheInfo.u16TotalPgPerF2hTab-1;
        gsCacheInfo.u16CacheF2hTabFreePtr=gsCacheInfo.u16TotalPgPerF2hTab-1;    // for all src from u16FluCacheBlock in popCacheF2hTab

        flushCacheF2hTab(cBit0|cBit3);
    }
}    /* flushCacheF2hInRdlink */

#endif/* if _EN_RDLINK_PF */

#if 0
void addCacheFblock(WORD u16GrpPtr)
{
    BYTE uF2hTabBank;
    BYTE uStrBank;
    BYTE uMaxBank;
    WORD u16FreePagePtr;
    WORD u16RiskFPage;
    WORD u16FlushPtr;
    WORD u16FBlock=garFoundCacheQ[u16GrpPtr].u16FBlock;
    LWORD u32BankStartPage;
    LWORD u32Serial=garFoundCacheQ[u16GrpPtr].u32Serial;
    BLKSPRINFO usBlkSprInfo;
    // _Uncached F2HTABLE *upF2hTabStPtr;
    F2HTABLE *upF2hTabStPtr;

    if(!mChkMlcMoBit(u16FBlock))
    {
        uMaxBank=gTotalBankOfF2hTab;
    }
    else
    {
        uMaxBank=gTotalTlcBankOfF2hTab;
        debugLoop();
    }

    // addRdlinkReBuCacheBlock(u16Fblock);
#if (!_HwPlane2SprIssue)
    u16FreePagePtr=getLastPageInfo(u16FBlock, cCacheBlockID, &usBlkSprInfo, 0);    // when encounter free plane, just stop.
#else
    u16FreePagePtr=getLastPageInfoInv(u16FBlock, cCacheBlockID, cUseSlcMode, &usBlkSprInfo);    // when encounter free plane, just stop.
#endif
    u16RiskFPage=u16FreePagePtr/gTotalIntlvChPlaneNum;

    if(u16RiskFPage>0)
    {
        u16RiskFPage--;
    }

    gsRdlinkInfo.u16RiskyStartPagePtr=u16RiskFPage*gTotalIntlvChPlaneNum;
    gsRdlinkInfo.u16RiskyEndPagePtr=(u16FreePagePtr-1);
    gsRdlinkInfo.u16RiskyFreePagePtr=u16FreePagePtr;

    if(u16FreePagePtr<g16PagePerBlock3_SLC)
    {
        u16FreePagePtr=dummyProgOpenWL(u16FBlock, u16FreePagePtr, u32Serial, cHdlOpWLNum, cCacheBlockID);
    }

    if(gsRdlinkInfo.ubCacheInfoValid&&(u16FBlock==g16BkRdActiveCacheBlock)&&(u32Serial==g32BkRdActCBlkSerial))
    {
        uStrBank=gBkRdActF2hTabBank;
    }
    else
    {
        uStrBank=0;
    }

    if(mChkMlcMoBit(u16FBlock))
    {
        gsCacheInfo.uMaxBankNum=gTotalTlcBankOfF2hTab;
        gsCacheInfo.u16ValidPgPerF2hTab=g16TlcValidPgPerF2hTab;
        gsCacheInfo.u4KNumToPadF2h=gTlc4KNumToPadF2h;
        gsCacheInfo.uPadF2h4KNum=gTlcPadF2h4KNum;
        gsCacheInfo.u16TotalPgPerF2hTab=g16TotalTlcPgPerF2hTab;
        gsCacheInfo.uProgF2HRem4KNum=gTlcProgF2HRem4KNum;
        gsCacheInfo.uSecNumPadF2h_1=gTlcSecNumPadF2h_1;
        gsCacheInfo.u16F2hPadStartAddr_2=g16TlcF2hPadStartAddr_2;
        gsCacheInfo.u16F2hChkFlushStart=g16TlcF2hChkStart;
        gsCacheInfo.u16F2hChkFlushSize=g16TlcF2hChkSize;
#if _ENABLE_RAID
        gsCacheInfo.u16PartialParityNum=g16TlcPartialParityNum;
        gsCacheInfo.u16ProgRaidChStr4K=g16TlcProgRaidChStr4K;
#endif/* if _ENABLE_RAID */
    }
    else
    {
        gsCacheInfo.uMaxBankNum=gTotalBankOfF2hTab;
        gsCacheInfo.u16ValidPgPerF2hTab=g16ValidPgPerF2hTab;
        gsCacheInfo.u4KNumToPadF2h=gSlc4KNumToPadF2h;
        gsCacheInfo.uPadF2h4KNum=gSlcPadF2h4KNum;
        gsCacheInfo.u16TotalPgPerF2hTab=g16TotalPgPerF2hTab;
        gsCacheInfo.uProgF2HRem4KNum=gSlcProgF2HRem4KNum;
        gsCacheInfo.uSecNumPadF2h_1=gSlcSecNumPadF2h_1;
        gsCacheInfo.u16F2hPadStartAddr_2=g16SlcF2hPadStartAddr_2;
        gsCacheInfo.u16F2hChkFlushStart=g16SlcF2hChkStart;
        gsCacheInfo.u16F2hChkFlushSize=g16SlcF2hChkSize;
#if _ENABLE_RAID
        gsCacheInfo.u16PartialParityNum=g16SlcPartialParityNum;
        gsCacheInfo.u16ProgRaidChStr4K=g16SlcProgRaidChStr4K;
#endif/* if _ENABLE_RAID */
    }

    for(uF2hTabBank=uStrBank; uF2hTabBank<uMaxBank; uF2hTabBank++)
    {
        u32BankStartPage=(LWORD)uF2hTabBank*gsCacheInfo.u16TotalPgPerF2hTab;

        if(u32BankStartPage>=(LWORD)u16FreePagePtr*g4kNumPerPlane)
        {
            break;
        }

        upF2hTabStPtr=garCacheF2hTab;

        if(readCacheF2hTab(c16CacheF2hTabSIdx, u16FBlock, u32BankStartPage+gsCacheInfo.u16ValidPgPerF2hTab, cF2hTableID)!=cTrue)
        {
            // debugLoop();
            buildBlockF2hTab(u16FBlock,
                             u32BankStartPage/(gTotalIntlvChNum*g4kNumPerPage),
                             u16RiskFPage,
                             cReadSprOnly|cAsignEofPgToRdData,
                             upF2hTabStPtr);
        }

        restoCacheF2hTab(c16CacheF2hTabSIdx);

        gsCacheInfo.u16FluCacheBlock=u16FBlock;
        gsCacheInfo.uFlushCacheBlkBank=uF2hTabBank;

        if(gsRdlinkInfo.ubCacheInfoValid&&(u16FBlock==g16BkRdActiveCacheBlock)&&(u32Serial==g32BkRdActCBlkSerial))
        {
            if(g32BkRdCacheFreePagePtr>u32BankStartPage)
            {
                if((g32BkRdCacheFreePagePtr-u32BankStartPage)<gsCacheInfo.u16TotalPgPerF2hTab)
                {
                    for(u16FlushPtr=gsCacheInfo.u16TotalPgPerF2hTab-1; u16FlushPtr>g16BkCacheF2hTabFreePtr; u16FlushPtr--)
                    {
                        if((garCacheF2hTab[u16FlushPtr].u16HBlock!=0xFFFF)&&(garCacheF2hTab[u16FlushPtr].u16HPage!=0xFFFF))
                        {
                            garCacheF2hTab[u16FlushPtr].u16HBlock|=c16Bit15;
                        }
                    }

                    gsCacheInfo.u16FlushF2hTabPtr=g16BkCacheF2hTabFreePtr;
                }
                else
                {
                    debugDeadLock(0x10);
                    gsCacheInfo.u16FlushF2hTabPtr=gsCacheInfo.u16TotalPgPerF2hTab-1;
                }
            }
            else
            {
                gsCacheInfo.u16FlushF2hTabPtr=gsCacheInfo.u16TotalPgPerF2hTab-1;
            }
        }
        else
        {
            gsCacheInfo.u16FlushF2hTabPtr=gsCacheInfo.u16TotalPgPerF2hTab-1;
        }

        gsCacheInfo.u32SrchF4kBaseFlu=(uF2hTabBank+1)*gsCacheInfo.u16TotalPgPerF2hTab-1;
        // gsCacheInfo.u32FluBlkSerial=gsCacheInfo.u32CacheBlkSerial;
        gsCacheInfo.u16CacheF2hTabFreePtr=gsCacheInfo.u16TotalPgPerF2hTab-1;    // for all src from u16FluCacheBlock in popCacheF2hTab

        flushCacheF2hTab(cBit0|cBit3);
    }

#if 1    // temp remove
    if(gsRdlinkInfo.u16BkActiveCacheBlock==u16FBlock)
    {
        if(u16FreePagePtr<g16PagePerBlock3_SLC)
        {
            gsCacheInfo.u32CacheFreePagePtr=u16FreePagePtr*g4kNumPerPlane;
            gsCacheInfo.u16ActiveCacheBlock=u16FBlock;
            gsCacheInfo.u16CacheF2hTabFreePtr=gsCacheInfo.u16TotalPgPerF2hTab-(gsCacheInfo.u32CacheFreePagePtr%gsCacheInfo.u16TotalPgPerF2hTab)-
                                               1;
            gsCacheInfo.uF2hTabBank=gsCacheInfo.u32CacheFreePagePtr/gsCacheInfo.u16TotalPgPerF2hTab;
            gsCacheInfo.u32SrchF4kBase=(gsCacheInfo.uF2hTabBank+1)*gsCacheInfo.u16TotalPgPerF2hTab-1;
            mClrCacheInfoFlag(cCacheBlockFull);
            gsCacheInfo.u32CacheBlkSerial=garFoundCacheQ[u16GrpPtr].u32Serial;
        }
        else
        {
            mSetCacheInfoFlag(cCacheBlockFull);
        }

        if(gsRdlinkInfo.u16RiskyStartPagePtr!=c16BitFF)
        {
            moveRiskyPage();
        }
    }
#else/* if 0 */
    mSetCacheInfoFlag(cCacheBlockFull);
#endif/* if 0 */
}    /* addCacheFblock */

#endif/* if 0 */







