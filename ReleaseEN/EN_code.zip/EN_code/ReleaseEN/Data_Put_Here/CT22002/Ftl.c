







#include "inc/ProType.h"
// #include "inc/FlashCtrl.h"
#include "inc/GlobVar0.h"
#include "inc/GlobVarS.h"
#include "inc/GlobVarT.h"
#include "inc/Reg.h"
#include "inc/Mac.h"

// #include "FakeScript.c"
#include "inc/FtlCtrl.h"

#if (!_PRJ_BOOT)
#include "Hmb.c"
#endif

#include "FtlIndiv.c"

#include "inc/DebugLog.h"
#include "inc/EventLogIDX.h"
#include "inc/EventLogFunctionIDX.h"

/*****************/
// RwCmd / HynixVu
/****************/

void tranLba2HAddr(LWORD u32LbaAddr, HADDRINFO *upHostAddrInfo)
{
    LWORD u32HSector;

    u32HSector=u32LbaAddr%g32SectorPerBlockH;
    upHostAddrInfo->u16HBlock=u32LbaAddr/g32SectorPerBlockH;
    // u32HSector=u32LbaAddr-(upHostAddrInfo->u16HBlock*g32SectorPerBlockH);
    upHostAddrInfo->u16HPage=u32HSector>>cSctrTo4kShift;
    upHostAddrInfo->uStartSector=u32HSector&(cSctrPer4k-1);
    upHostAddrInfo->u32HSector=u32HSector;
    gpHostAddrInfo=upHostAddrInfo;
}

#if (_PRJ_ISP||_PRJ_BOOT||_PRJ_SMIVU||_PRJ_NVME)
/**************/
// RwCmd / Boot
/**************/
#if _EN_Liteon_ErrHandle    // 20190618_Louis_01
void chkVpCnt()
{
    NLOG(cLogBuild, FTL_C, 0, " chkVpCnt start!");
    WORD u16Hblock, u16H4k, u16Fblock;
    // LWORD u32TempVpc;
    UCLWORD *u32pTsb0=(UCLWORD *)garTsb0[0];
    UCLWORD *u32pH2f=(UCLWORD *)garTsb0[c16Tsb0SIdx+g16H2fTabSctrSize];
    BYTE uSaveVpc=0;

    // KSPRINFO usBlkSprInfo;

    bopClrRam(c32Tsb0SAddr, c32Tsb0SizeByte, 0x00000000, cClrTsb|cBopWait);

#if (_EN_VPC_SWAP&&_ENABLE_RAID)
    g32arCacheBlkVpCnt=(volatile LWORD *)(cCacheBlkVpCntRebuH2FStrAddr);
    readWproPageCore0(cWproCacheBlkVpCnt, cCacheBlkVpCntRebuH2FStrIdx, 0);
#endif

    for(u16Hblock=0; u16Hblock<g16TotalHBlock; u16Hblock++)
    {
        if(g16arH2fTabPtr[u16Hblock]!=c16H2FTabInitValue)
        {
            swapH2fTable(u16Hblock, c16Tsb0SIdx+g16H2fTabSctrSize, cWaitReadDone);

            rmWaitSysCmdFifoBz;

            // for reset H2f table no wait.
            while(rmChkHdmaBz)
                ;

            for(u16H4k=0; u16H4k<g16PagePerH2fTab; u16H4k++)
            {
                u16Fblock=mGetSrcFBlkAddr(u32pH2f[u16H4k]);

                if(u16Fblock!=c16FBlockInitValue)
                {
                    if((u16Fblock>=g16TotalFBlock)||(u16Fblock<g16FirstFBlock))
                    {
                        debugLoop(cChkVpCnt1);
                    }

                    u32pTsb0[u16Fblock]++;

                    if(mChkMlcMoBit(u16Fblock))
                    {
                        if(u32pTsb0[u16Fblock]>g32VpcPerTlcBlk)
                        {
                            // debugRdlinkDeadLock();
                            debugLoop(cChkVpCnt2);
                        }
                    }
                    else
                    {
                        if(u32pTsb0[u16Fblock]>g32VpcPerSlcBlk)
                        {
                            // debugRdlinkDeadLock();
                            debugLoop(cChkVpCnt3);
                        }
                    }
                }
            }
        }
    }

    for(u16Fblock=g16FirstFBlock; u16Fblock<g16TotalFBlock; u16Fblock++)
    {
        if(u32pTsb0[u16Fblock]!=mGetCacheBlkVpCnt(u16Fblock))
        {
#if _EN_KEEP_RW_ON_ERROR
            NLOG(cLogBuild, FTL_C, 5, " u32pTsb0[0x%04x]=0x%08x, g32arCacheBlkVpCnt=0x%08x", u16Fblock, u32pTsb0[u16Fblock]>>16,
                 u32pTsb0[u16Fblock], g32arCacheBlkVpCnt[u16Fblock]>>16, g32arCacheBlkVpCnt[u16Fblock]);
            // u32TempVpc=g32arCacheBlkVpCnt[u16Fblock];
            g32arCacheBlkVpCnt[u16Fblock]=u32pTsb0[u16Fblock]|(g32arCacheBlkVpCnt[u16Fblock]&(c32Bit31|c32Bit30));

            if(!u32pTsb0[u16Fblock])
            {
                setZeroVpcBlock(u16Fblock);
            }

#if (_EN_VPC_SWAP&&_ENABLE_RAID)
            if(mGetCacheBlkVpCnt(u16Fblock)&&(!mChkVPCntValid(u16Fblock)))
            {
                mSetVPCntValid(u16Fblock);
            }
            else if(!mGetCacheBlkVpCnt(u16Fblock)&&(mChkVPCntValid(u16Fblock)))
            {
                mClrVPCntValid(u16Fblock);
            }
#endif

            uSaveVpc=1;
#else  /* if _EN_KEEP_RW_ON_ERROR */
            debugLoop(cChkVpCnt4);
#endif /* if _EN_KEEP_RW_ON_ERROR */
        }
    }

    if(uSaveVpc)
    {
#if (_EN_VPC_SWAP&&_ENABLE_RAID)
        progWproPageCore0(cWproCacheBlkVpCnt, cCacheBlkVpCntRebuH2FStrIdx);
#endif
        progCacheInfoTab();
    }
}    /* chkVpCnt */

#endif/* if _EN_Liteon_ErrHandle */
#endif/* if (_PRJ_ISP||_PRJ_BOOT||_PRJ_SMIVU) */

#if (_PRJ_ISP||_PRJ_BOOT||_PRJ_SMIVU||_PRJ_NVME)

void setH2fSrcBlock(LWORD *u32pH2FTab, WORD u16NewSrcFblk, LWORD u32NewSrcFpg, BYTE uNewSrcLsb, BYTE uRstUncType)
{
    WORD u16FBlock=mGetSrcFBlkAddr((*u32pH2FTab));    // (WORD)(((*u32pH2FTab)&c2UncTypeMask)>>c32SrcFPageAddrBitNum);
    LWORD u32FMap;

    u32FMap=mSetH2fSrcFAddr(u16NewSrcFblk, u32NewSrcFpg);

    if((*u32pH2FTab&cUncTypeMask)!=u32FMap)
    {
        if(u16FBlock!=c16FBlockInitValue)
        {
            while(!mGetCacheBlkVpCnt(u16FBlock))
                ;

            g32arCacheBlkVpCnt[u16FBlock]--;
            mDecTotalVpc(u16FBlock);

            if(!mGetCacheBlkVpCnt(u16FBlock))
            {
                setZeroVpcBlock(u16FBlock);
            }
        }

        if(!uRstUncType)
        {
            *u32pH2FTab=(*u32pH2FTab&(c32Bit30|c32Bit31))|u32FMap;
        }
        else
        {
            *u32pH2FTab=u32FMap;
        }

        // *u32pH2FTab=u32FMap;
        g32arCacheBlkVpCnt[u16NewSrcFblk]++;
        mIncTotalVpc(uNewSrcLsb);
#if _EN_VPC_SWAP
        mSetVPCntValid(u16NewSrcFblk);
#endif

        if(!mChkCacheInfoChangeFlag(cH2fChg))
        {
            mSetCacheInfoChangeFlag(cH2fChg);
        }
    }
}    /* setH2fSrcBlock */

#endif/* if (_PRJ_ISP||_PRJ_BOOT||_PRJ_SMIVU) */

#if (_PRJ_ISP||_PRJ_SMIVU||_PRJ_NVME)

/**************/
// RwCmd
/**************/

BYTE srchH2f1kTabSgmt(LWORD u32H2f1kTabSgmt)
{
    rmEnQuickSrch;
    rmSetSrchThVal(u32H2f1kTabSgmt);
    rmDisQuickSrch;

#if !_EN_SEQRSGMTTAB
    BYTE uGetIdx=0;
    LWORD u32SrchTgt32Vld;

    if(rmChkSrchTgt32Vld)
    {
        u32SrchTgt32Vld=rmChkSrchTgt32Vld-1;    // becasue rmChkSrchTgt32Vld is power of 2

        while(u32SrchTgt32Vld)
        {
            uGetIdx+=cbBitNumTab[(BYTE)(u32SrchTgt32Vld    /*&0xFF*/)];
            u32SrchTgt32Vld=u32SrchTgt32Vld>>8;
        }

        return uGetIdx;
    }
    else
    {
        return 0xFF;
    }
#else/* if !_EN_SEQRSGMTTAB */
    if(rmChkSrchTgt32Vld)
    {
        LWORD *u32pH2f1kTabSgmt=g32arH2f1kTabSgmt;

        for(BYTE uIdx=0; uIdx<cMaxRH2fTabNum; uIdx+=4)
        {
            if(*u32pH2f1kTabSgmt++==u32H2f1kTabSgmt)
            {
                return uIdx;
            }

            if(*u32pH2f1kTabSgmt++==u32H2f1kTabSgmt)
            {
                return uIdx+1;
            }

            if(*u32pH2f1kTabSgmt++==u32H2f1kTabSgmt)
            {
                return uIdx+2;
            }

            if(*u32pH2f1kTabSgmt++==u32H2f1kTabSgmt)
            {
                return uIdx+3;
            }
        }
    }
    return 0xFF;
#endif/* if !_EN_SEQRSGMTTAB */
}    /* srchH2f1kTabSgmt */

#if _ENABLE_RAID
BYTE setH2f1kTabSgmt(LWORD u32H2f1kTabSgmt, BYTE uRH2fTabNum)
{
    BYTE uIdx;

    if((uRH2fTabNum==cHalfRH2fTabNum)&&(gsCacheInfo.uH2f1kSgmtFreePtr>=cHalfRH2fTabNum))
    {
        gsCacheInfo.uH2f1kSgmtFreePtr=0;
    }

    uIdx=gsCacheInfo.uH2f1kSgmtFreePtr;

    while(gsCacheInfo.uH2f1kTabCnt>=uRH2fTabNum)
    {
        do
        {
            if(mChkH2f1kTabSgmtExpire(uIdx))
            {
                // remH2f1kTabSgmt(uIdx);
                if(uRH2fTabNum==cHalfRH2fTabNum)
                {
                    gsCacheInfo.uH2f1kTabCnt--;
                }

                g32arH2f1kTabSgmt[uIdx]=u32H2f1kTabSgmt;
                // rmSetSrchTgt(uIdx, u32H2f1kTabSgmt);
                gsCacheInfo.uH2f1kSgmtFreePtr=(uIdx+1)&(uRH2fTabNum-1);
                return uIdx;
            }

            uIdx=(uIdx+1)&(uRH2fTabNum-1);
        }
        while(uIdx!=gsCacheInfo.uH2f1kSgmtFreePtr);
    }

    while(!mChkH2f1kTabSgmtExpire(uIdx))
    {
        uIdx=(uIdx+1)&(uRH2fTabNum-1);
    }

#if _ENABLE_HMB_FLUSH
    if((gsHmbInfo.uHmbEnable)&&(mChkRH2fTabDirty(uIdx)))
    {
        modifyHmbByH2f1kTab(uIdx);
    }
#endif

    g32arH2f1kTabSgmt[uIdx]=u32H2f1kTabSgmt;
    // rmSetSrchTgt(uIdx, u32H2f1kTabSgmt);
    gsCacheInfo.uH2f1kSgmtFreePtr=(uIdx+1)&(uRH2fTabNum-1);
    gsCacheInfo.uH2f1kTabCnt++;

    return uIdx;
}    /* setH2f1kTabSgmt */

#else/* if _ENABLE_RAID */
BYTE setH2f1kTabSgmt(LWORD u32H2f1kTabSgmt)
{
    BYTE uIdx;

    uIdx=gsCacheInfo.uH2f1kSgmtFreePtr;

    while(gsCacheInfo.uH2f1kTabCnt>=cMaxRH2fTabNum)
    {
        do
        {
            if(mChkH2f1kTabSgmtExpire(uIdx))
            {
                // remH2f1kTabSgmt(uIdx);
                // gsCacheInfo.uH2f1kTabCnt--;
                // break;
                g32arH2f1kTabSgmt[uIdx]=u32H2f1kTabSgmt;
                // rmSetSrchTgt(uIdx, u32H2f1kTabSgmt);
                gsCacheInfo.uH2f1kSgmtFreePtr=(uIdx+1)&(cMaxRH2fTabNum-1);
                return uIdx;
            }

            uIdx=(uIdx+1)&(cMaxRH2fTabNum-1);
        }
        while(uIdx!=gsCacheInfo.uH2f1kSgmtFreePtr);
    }

    while(!mChkH2f1kTabSgmtExpire(uIdx))
    {
        uIdx=(uIdx+1)&(cMaxRH2fTabNum-1);
    }

#if _ENABLE_HMB_FLUSH
    if((gsHmbInfo.uHmbEnable)&&(mChkRH2fTabDirty(uIdx)))
    {
        modifyHmbByH2f1kTab(uIdx);
    }
#endif

    g32arH2f1kTabSgmt[uIdx]=u32H2f1kTabSgmt;
    // rmSetSrchTgt(uIdx, u32H2f1kTabSgmt);
    gsCacheInfo.uH2f1kSgmtFreePtr=(uIdx+1)&(cMaxRH2fTabNum-1);
    gsCacheInfo.uH2f1kTabCnt++;

    return uIdx;
}    /* setH2f1kTabSgmt */

#endif/* if _ENABLE_RAID */

BYTE srchH2f1kTabSgmt2(LWORD u32H2f1kTabSgmt, BYTE uH2fTabNum)
{
    BYTE uIdx;

    LWORD *u32pH2f1kTabSgmt=g32arH2f1kTabSgmt;

    for(uIdx=0; uIdx<uH2fTabNum; uIdx+=4)
    {
        if(*u32pH2f1kTabSgmt++==u32H2f1kTabSgmt)
        {
            return uIdx;
        }

        if(*u32pH2f1kTabSgmt++==u32H2f1kTabSgmt)
        {
            return uIdx+1;
        }

        if(*u32pH2f1kTabSgmt++==u32H2f1kTabSgmt)
        {
            return uIdx+2;
        }

        if(*u32pH2f1kTabSgmt++==u32H2f1kTabSgmt)
        {
            return uIdx+3;
        }
    }

    return 0xFF;
}    /* srchH2f1kTabSgmt2 */

#if 0    // _ENABLE_RAID
BYTE srchH2f1kTabSgmt3(LWORD u32H2f1kTabSgmt)
{
    BYTE uIdx;

    LWORD *u32pH2f1kTabSgmt=g32arH2f1kTabSgmt;

    for(uIdx=0; uIdx<cHalfRH2fTabNum; uIdx+=4)
    {
        if(*u32pH2f1kTabSgmt++==u32H2f1kTabSgmt)
        {
            return uIdx;
        }

        if(*u32pH2f1kTabSgmt++==u32H2f1kTabSgmt)
        {
            return uIdx+1;
        }

        if(*u32pH2f1kTabSgmt++==u32H2f1kTabSgmt)
        {
            return uIdx+2;
        }

        if(*u32pH2f1kTabSgmt++==u32H2f1kTabSgmt)
        {
            return uIdx+3;
        }
    }

    return 0xFF;
}    /* srchH2f1kTabSgmt3 */

BYTE setH2f1kTabSgmt2(LWORD u32H2f1kTabSgmt)
{
    BYTE uIdx;

    if(gsCacheInfo.uH2f1kSgmtFreePtr>=cHalfRH2fTabNum)
    {
        gsCacheInfo.uH2f1kSgmtFreePtr=0;
    }

    uIdx=gsCacheInfo.uH2f1kSgmtFreePtr;

    while(gsCacheInfo.uH2f1kTabCnt>=cHalfRH2fTabNum)
    {
        do
        {
            if(mChkH2f1kTabSgmtExpire(uIdx))
            {
                // remH2f1kTabSgmt(uIdx);
                gsCacheInfo.uH2f1kTabCnt--;
                g32arH2f1kTabSgmt[uIdx]=u32H2f1kTabSgmt;
                // rmSetSrchTgt(uIdx, u32H2f1kTabSgmt);
                gsCacheInfo.uH2f1kSgmtFreePtr=(uIdx+1)&(cHalfRH2fTabNum-1);
                return uIdx;
            }

            uIdx=(uIdx+1)&(cHalfRH2fTabNum-1);
        }
        while(uIdx!=gsCacheInfo.uH2f1kSgmtFreePtr);
    }

    while(!mChkH2f1kTabSgmtExpire(uIdx))
    {
        uIdx=(uIdx+1)&(cHalfRH2fTabNum-1);
    }

#if _ENABLE_HMB_FLUSH
    if((gsHmbInfo.uHmbEnable)&&(mChkRH2fTabDirty(uIdx)))
    {
        modifyHmbByH2f1kTab(uIdx);
    }
#endif

    g32arH2f1kTabSgmt[uIdx]=u32H2f1kTabSgmt;
    // rmSetSrchTgt(uIdx, u32H2f1kTabSgmt);
    gsCacheInfo.uH2f1kSgmtFreePtr=(uIdx+1)&(cHalfRH2fTabNum-1);
    gsCacheInfo.uH2f1kTabCnt++;

    return uIdx;
}    /* setH2f1kTabSgmt2 */

#endif/* if _ENABLE_RAID */

/*
   * void remH2f1kTabSgmt(BYTE uStartIdx)
   * {
   *  BYTE uSaveIdx=garH2f1kTabSgmtIdx[uStartIdx];
   *  BYTE *upH2f1kTabSgmtIdxE=&garH2f1kTabSgmtIdx[gsCacheInfo.uH2f1kTabCnt-1];
   *  BYTE *upH2f1kTabSgmtIdx=&garH2f1kTabSgmtIdx[uStartIdx];
   *
   *  while(upH2f1kTabSgmtIdx!=upH2f1kTabSgmtIdxE)
   *  {
   * *upH2f1kTabSgmtIdx++=*(upH2f1kTabSgmtIdx+1);
   *  }
   *
   * *upH2f1kTabSgmtIdx=uSaveIdx;
   *  gsCacheInfo.uH2f1kTabCnt--;
   * }
   *
   * void sortH2f1kTabSgmt(BYTE uSgmtIdx)
   * {
   *  BYTE uIdx;
   *
   *  for(uIdx=0; uIdx<gsCacheInfo.uH2f1kTabCnt; uIdx++)
   *  {
   *      if(garH2f1kTabSgmtIdx[uIdx]==uSgmtIdx)
   *      {
   *          break;
   *      }
   *  }
   *
   *  BYTE *upH2f1kTabSgmtIdxE=&garH2f1kTabSgmtIdx[gsCacheInfo.uH2f1kTabCnt-1];
   *  BYTE *upH2f1kTabSgmtIdx=&garH2f1kTabSgmtIdx[uIdx];
   *
   *  while(upH2f1kTabSgmtIdx!=upH2f1kTabSgmtIdxE)
   *  {
   * *upH2f1kTabSgmtIdx++=*(upH2f1kTabSgmtIdx+1);
   *  }
   *
   * *upH2f1kTabSgmtIdx=uSgmtIdx;
   * }
   */

/**************/
// RwCmd
/**************/

void createPrdTabLink(BYTE uSgmtIdx, BYTE uNewPrd)
{
    BYTE uLinkIdx;
    BYTE uLinkPtr=gsRwCtrl.uarTab2PrdPtr[uSgmtIdx];

    while(uLinkPtr==0xFF)
        ;// for Debug;

    while(1)
    {
        uLinkIdx=gsRwCtrl.uarTabLinkPtr[uLinkPtr];

        if(uLinkIdx==0xFF)
        {
            gsRwCtrl.uarTabLinkPtr[uLinkPtr]=uNewPrd;
            break;
        }
        else
        {
            uLinkPtr=uLinkIdx;
        }
    }
}    /* createPrdTabLink */

#endif/* if (_PRJ_ISP||_PRJ_SMIVU) */

/**************/
// RwCmd
/**************/

BYTE delePrdTabLink(BYTE uSgmtIdx)
{
    BYTE uPrdCnt=1;
    BYTE uLinkIdx;    // , uRdHAddrIdx;
    BYTE uLinkPtr=gsRwCtrl.uarTab2PrdPtr[uSgmtIdx];

    // PRDQUEUE *upPrdInfo;

    while(uLinkPtr==0xFF)
        ;// for Debug;

    // upPrdInfo=&gsPrdInfo.uarPrdQue[uLinkPtr];
    // uRdHAddrIdx=upPrdInfo->uRdHAddrIdx;
    // gpHostAddrInfo=&gsReadHAddrInfo[uLinkPtr];
    // while(gpHostAddrInfo->uLoadTabState!=cSrchSrcTabOk)
    //    ;// for Debug.[CC]
    // gpHostAddrInfo->uLoadTabState=cReadTabOk;
    gsRwCtrl.uarSrcPrdPtr[gsRwCtrl.uSrcPrdHead]=uLinkPtr;
    gsRwCtrl.uSrcPrdHead=(gsRwCtrl.uSrcPrdHead+1)&(cPostSrcDept-1);
    gsRwCtrl.uSrcPrdCnt++;
    gsRwCtrl.uarTab2PrdPtr[uSgmtIdx]=0xFF;

    while(1)
    {
        uLinkIdx=gsRwCtrl.uarTabLinkPtr[uLinkPtr];

        if(uLinkIdx==0xFF)
        {
            break;
        }
        else
        {
            // upPrdInfo=&gsPrdInfo.uarPrdQue[uLinkIdx];
            // uRdHAddrIdx=upPrdInfo->uRdHAddrIdx;
            // gpHostAddrInfo=&gsReadHAddrInfo[uLinkIdx];
            // while(gpHostAddrInfo->uLoadTabState!=cSrchSrcTabOk)
            //    ;// for Debug.[CC]
            // gpHostAddrInfo->uLoadTabState=cReadTabOk;
            gsRwCtrl.uarSrcPrdPtr[gsRwCtrl.uSrcPrdHead]=uLinkIdx;
            gsRwCtrl.uSrcPrdHead=(gsRwCtrl.uSrcPrdHead+1)&(cPostSrcDept-1);
            gsRwCtrl.uSrcPrdCnt++;
            gsRwCtrl.uarTabLinkPtr[uLinkPtr]=0xFF;
            uLinkPtr=uLinkIdx;
            uPrdCnt++;
        }
    }

    return uPrdCnt;
}    /* delePrdTabLink */

#if (_PRJ_ISP||_PRJ_NVME||(_PRJ_SMIVU&&_GREYBOX))

void handleH2fSgmtRdy(void)
{
    BYTE uSgmtIdx, uH2fSgmtRdyTail=gsRwCtrl.u32H2fSgmtRdyTail;

    // while(gH2fSgmtRdyCnt)
    do
    {
        uSgmtIdx=gsRwCtrl.uarH2fSgmtRdyQ[uH2fSgmtRdyTail];
        mClrH2f1kTabSgmtPrep(uSgmtIdx);
        delePrdTabLink(uSgmtIdx);
        uH2fSgmtRdyTail=(uH2fSgmtRdyTail+1)&(cH2fSgmtRdyDept-1);
        // gH2fSgmtRdyCnt--;
    }
    while(uH2fSgmtRdyTail!=gsRwCtrl.u32H2fSgmtRdyHead);

    gsRwCtrl.u32H2fSgmtRdyTail=uH2fSgmtRdyTail;
}    /* handleH2fSgmtRdy */

/*
   * void handleHmbSgmtRdy()
   * {
   *  BYTE uSgmtIdx, uHmbSgmtRdyCnt=gsHmbInfo.uHmbSgmtRdyCnt, uHmbSgmtRdyTail=gsHmbInfo.uHmbSgmtRdyTail;
   *
   *  do
   *  {
   *      uSgmtIdx=gsHmbInfo.uarHmbSgmtRdyQ[uHmbSgmtRdyTail];
   *      mClrH2f1kTabSgmtPrep(uSgmtIdx);
   *      delePrdTabLink(uSgmtIdx);
   *      uHmbSgmtRdyTail=(uHmbSgmtRdyTail+1)&(cMaxRH2fTabNum-1);
   *      uHmbSgmtRdyCnt--;
   *  }
   *  while(uHmbSgmtRdyCnt);
   *
   *  gsHmbInfo.uHmbSgmtRdyTail=uHmbSgmtRdyTail;
   *  gsHmbInfo.uHmbSgmtRdyCnt=uHmbSgmtRdyCnt;
   * }
   */

/**************/
// No one use it
/**************/

/*
   * void setH2fTabSgmt(WORD u16Hblock)
   * {
   *  BYTE uSegCnt, u16Hsgmt;
   *
   *  // while(gH2f1KPrepCnt||gsCacheInfo.ubPrep)
   *  //    ;                                      // for debug [CC]
   *
   *  H2F1KTABSGMT *upH2f1kTabSgmt=garH2f1kTabSgmt;
   *
   *  for(uSegCnt=0; uSegCnt<cMaxRH2fTabNum; uSegCnt++)
   *  {
   *      upH2f1kTabSgmt->u16HSgmt=u16Hsgmt;
   *      upH2f1kTabSgmt->u16HBlock=u16Hblock;
   *      garH2f1kTabSgmtIdx[uSegCnt]=uSegCnt;
   *
   *      upH2f1kTabSgmt++;    // Pointer to next [CC]
   *  }
   * }
   */

/**************/
// RwCmd (GC?)
/**************/

BYTE getBrkBgdGcF()
{
#if _GREYBOX
    if((gsGbInfo.uGreyBoxItem==cGCS2TThree2OneFull)||(gsGbInfo.uGreyBoxItem==cGCS2TSixteen2OneFull)||
       (gsGbInfo.uGreyBoxItem==cGCS2TSixteen2OneNotFull)||(gsGbInfo.uGreyBoxItem==cGCT2TX2OneNotFull)||
       (gsGbInfo.uGreyBoxItem==cGCT2TSixteen2OneMoreFull)||(gsGbInfo.uGreyBoxItem==cGCT2TX2OneFull)||
       (gsGbInfo.uGreyBoxItem==cGCPartialS2Tfour2OneFull)||(gsGbInfo.uGreyBoxItem==cErrHdlReadUncInSlcDataID)||
       (gsGbInfo.uGreyBoxItem==cErrHdlReadUncInTlcDataID)||(gsGbInfo.uGreyBoxItem==cGCS2SThirtytwo2OneNotFull)||
       (gsGbInfo.uGreyBoxItem==cWearleveingRule)||(gsGbInfo.uGreyBoxItem==cErrHdlProgWPROID)||
       ((gsGbInfo.uGreyBoxItem==cErrHdlProgT2TGcDesID)&&(gsGbInfo.uGreyBoxOpt==cVopProgFailSetS2TGc))||(gsGbInfo.uGreyBoxItem==cSecurityRW)||
       (gsGbInfo.uGreyBoxItem==cErrHdlGcFingerFailTestID))
    {
        if(mChkGcFlag(cBrkBgdGcF))
        {
            return cTrue;
        }
        else
        {
            mClrGcFlag(cBrkBgdGcF);
            return cFalse;
        }
    }
    else if((gsGbInfo.uGreyBoxOpt==cVOpProgWproGcInfo)&&(gsGbInfo.uStag==cVsIdl)&&
            (((gsGbInfo.uGreyBoxItem==cUGSDT2TID)&&(mGetGcFlow==cGcFlowT2T))||((gsGbInfo.uGreyBoxItem==cUGSDS2SID)&&(mGetGcFlow==cGcFlowS2S))||
             ((gsGbInfo.uGreyBoxItem==cUGSDonWearleveling)&&(mGetGcFlow==cGcFlowT2T)))&&(gGbGcSrcBlkCnt>0))
    {
        if(mChkGcFlag(cBrkBgdGcF))
        {
            return cTrue;
        }
        else
        {
            mSetGcFlag(cBrkBgdGcF);
            return cTrue;
        }
    }
    else
#endif/* if _GREYBOX */
    {
        if(mChkGcFlag(cGcSpareNotEnough))
        {
            return cFalse;
        }
        else if(mNvmeChkShn||rmChkPcieD3State)    // Bruce_20190624 for BGGC with D3Hot command
        {
            if(!mChkGcFlag(cBrkBgdGcF))
            {
                if(mNvmeChkShn)
                {
                    NLOG(cLogFTL, FTL_C, 0, "Break GC because shut down cmd");
                }

                if(rmChkPcieD3State)
                {
                    NLOG(cLogFTL, FTL_C, 0, "Break GC because D3 Hot cmd");
                }

                mSetGcFlag(cBrkBgdGcF);
            }

            return cTrue;
        }
        else if(mChkGcFlag(cUnderBgdGc))
        {
            // if((rmGetRtc1sTick>=gsGcInfo.u32BgdGcEndTime)||hostRequset()) // to do
            // if((rmGetRtc1sTick>=gsGcInfo.u32BgdGcEndTime))
            if(hostRequset()||mChkGcFlag(cGcDesFailAbort))
            {
                mSetGcFlag(cBrkBgdGcF);
                // mSetGcFlag(cStopBgdClean);
                return cTrue;
            }
            else if(mChkGcFlag(cPwOnH2FGcF)||(mChkGcFlag(cPwOnGcF)))
            {
                return cFalse;
            }
            else if(mChkGcFlag(cPwOnExtraGcF))    // 20190513_Louis
            {
#if _EN_Liteon_ErrHandle
                if(gJdgBootGCFlag&cBootSLCQGC)
                {
                    if(g16SlcSortQCnt<(cMaxSlcBlkQ-2))    // remain 2 SLC Blk
                    {
                        gJdgBootGCFlag&=~(cBootSLCQGC);
                    }
                    else
                    {
                        return cFalse;
                    }
                }
#endif

                if(((getRtcCurrent1s()-gsGcInfo.u32PwrOnGcStartTime)>=gsGcInfo.u32PwrOnExtraGcTimeLimit)||mPSChgChkThrottling)
                {
                    mSetGcFlag(cBrkBgdGcF);
                    return cTrue;
                }
            }
        }
        else if(mChkGcFlag(cGcDesFailAbort)&&(!mChkGcFlag(cUnderGcH2fTab)))    // 20190314_Bruce_Fix Edevx timeout issue
        {
            mSetGcFlag(cBrkBgdGcF);
            return cTrue;
        }

#if _EN_RAID_GC
        else if((gsHmbInfo.uHmbStsChg)&&(!mChkGcFlag(cUnderGcH2fTab)))    // 20190314_Bruce_Fix Edevx timeout issue
        {
            if(gsCacheInfo.u16PartialParityPtrGc)
            {
                mSetGcFlag(cBrkBgdGcF);
                return cTrue;
            }
        }
#endif
        else
        {
            // if(((rmGetRtc32kTick>=gsGcInfo.u32BgdGcEndTime)||gbTrimCmd)&&!mChkGcFlag(cGcForceClean)) to do
            // if(((rmGetRtc32kTick>=gsGcInfo.u32BgdGcEndTime))&&!mChkGcFlag(cGcForceClean))
            if((chkRtc32kTimeout(gsGcInfo.u32BgdGcEndTime))&&!mChkGcFlag(cGcForceClean))
            {
                mSetGcFlag(cBrkBgdGcF);
                // setHostWr4kCntFull();
                return cTrue;
            }
        }

        mClrGcFlag(cBrkBgdGcF);
        return cFalse;
    }
}    /* getBrkBgdGcF */

/**************/
// RwCmd
/**************/

void postSrchF2hTab(void)
{
    BYTE uSrchQIdx, uPrdIdx, uSrchQTail, uNbsQIdx;
    WORD u16NbsHitOfst, u16SrchSrcTabStIdx;

    // PRDQUEUE *upPrdInfo;

    while(!rmChkNbsQueMt)
    {
        while(!gsRwCtrl.uSrchQCnt)
            ;

        gsRwCtrl.uSrchQCnt--;
        // gsRwCtrl.uSrchQTail=addPtrBy1(gsRwCtrl.uSrchQTail, cSrchQDepth);
        uNbsQIdx=rmGetNbsQueIdx;
        gsRwCtrl.uarFreeNbsSlot[gsRwCtrl.uFreeNbsSlotTail]=uNbsQIdx;
        gsRwCtrl.uFreeNbsSlotTail=(gsRwCtrl.uFreeNbsSlotTail+1)&(cSrchEnginDepth-1);
        gsRwCtrl.uFreeNbsSlotCnt++;
        uSrchQIdx=gsRwCtrl.uarNbs2SrchQ[uNbsQIdx];
        gsRwCtrl.uarSrchQ2RdHaddr[uSrchQIdx]&=~cBit7;
        uPrdIdx=gsRwCtrl.uarSrchQ2RdHaddr[uSrchQIdx];
        gpHostAddrInfo=&gsReadHAddrInfo[uPrdIdx];
        u16SrchSrcTabStIdx=(gpHostAddrInfo->u16SrchSrcTabStIdx+(gsRwCtrl.usSrchQ[uSrchQIdx].u16HPage-g16HPage))&(cSrchSrcNum-1);

        // if(r32BopCtrl[rcSrchBitMap]&cb32BitTab[uBopCnt])
        if(rmChkNbsHitBit(uNbsQIdx))
        {
            // r32BopCtrl[rcSrchBitMap]&=~cb32BitTab[uBopCnt];
            // if(r32BopCtrl[rcSrhTgt0+uBopCnt]>gsCacheInfo.u16CacheF2hTabFreePtr)
            u16NbsHitOfst=rmGetNbsHitOfst(uNbsQIdx);
            // rmClrNbsHitOfst(uNbsQIdx);

            if(u16NbsHitOfst>gsCacheInfo.u16CacheF2hTabFreePtr)
            {
                garSrchSrcTab[u16SrchSrcTabStIdx]=(UCLWORD)mSetH2fSrcFAddr(gsCacheInfo.u16ActiveCacheBlock,
                                                                           gsCacheInfo.u32SrchF4kBase-u16NbsHitOfst);
            }
            else
            {
                garSrchSrcTab[u16SrchSrcTabStIdx]=(UCLWORD)mSetH2fSrcFAddr(gsCacheInfo.u16FluCacheBlock,
                                                                           gsCacheInfo.u32SrchF4kBaseFlu-u16NbsHitOfst);
            }

            gpHostAddrInfo->uSrchHitCnt++;
        }
        else
        {
            garSrchSrcTab[u16SrchSrcTabStIdx]=(UCLWORD)mSetSrcFBlkAddr(c16FBlockInitValue);
        }

        rmPopNbsQue;
        gpHostAddrInfo->u16Srch4kCnt--;

        if(!gpHostAddrInfo->u16Srch4kCnt)
        {
            // if((gpHostAddrInfo->uSrchHitCnt+gpHostAddrInfo->uHmbHitCnt)==gsPrdInfo.uarPrdQue[uPrdIdx].u16PrdRd4kCnt)
            if(gpHostAddrInfo->uSrchHitCnt==gsPrdInfo.uarPrdQue[uPrdIdx].u16PrdRd4kCnt)
            {
                // gpHostAddrInfo->uLoadTabState=cReadTabOk;
                gpHostAddrInfo->uTabSgmtIdx=0xFF;
                gsRwCtrl.uarSrcPrdPtr[gsRwCtrl.uSrcPrdHead]=uPrdIdx;
                gsRwCtrl.uSrcPrdHead=(gsRwCtrl.uSrcPrdHead+1)&(cPostSrcDept-1);
                gsRwCtrl.uSrcPrdCnt++;
            }
            else
            {
                gsRwCtrl.uarTabPrdPtr[gsRwCtrl.uTabPrdHead]=uPrdIdx;
                gsRwCtrl.uTabPrdHead=(gsRwCtrl.uTabPrdHead+1)&(cPostTabDept-1);
                gsRwCtrl.uTabPrdCnt++;
            }
        }
    }

    uSrchQTail=gsRwCtrl.uSrchQTail;

    while((uSrchQTail!=gsRwCtrl.uSrchQHead)&&gsRwCtrl.uFreeNbsSlotCnt)    // &&(uBopCnt<cSrchEnginDepth))
    {
        // r32BopCtrl[rcSrhTgt0+uBopCnt]=(LWORD)((gsRwCtrl.usSrchQ[uSrchQTail].u16HBlock*0x00010000)+gsRwCtrl.usSrchQ[uSrchQTail].u16HPage);
        // r32BopCtrl[rcSrchBitMap]|=cb32BitTab[uBopCnt];
        uNbsQIdx=gsRwCtrl.uarFreeNbsSlot[gsRwCtrl.uFreeNbsSlotHead];
        gsRwCtrl.uFreeNbsSlotHead=(gsRwCtrl.uFreeNbsSlotHead+1)&(cSrchEnginDepth-1);
        gsRwCtrl.uFreeNbsSlotCnt--;
        rmSetNbsSrchTgt(uNbsQIdx, (LWORD)((gsRwCtrl.usSrchQ[uSrchQTail].u16HBlock<<16)+gsRwCtrl.usSrchQ[uSrchQTail].u16HPage));
        rmSetNbsActBit(uNbsQIdx);
        gsRwCtrl.uarNbs2SrchQ[uNbsQIdx]=uSrchQTail;
        // uBopCnt++;
        uSrchQTail=(uSrchQTail+1)&(cSrchQDepth-1);
    }

    gsRwCtrl.uSrchQTail=uSrchQTail;
}    /* postSrchF2hTab */

#endif/* if (_PRJ_ISP) */
/**************/
// RwCmd
/**************/

void addLbaAddr(BYTE uSctrCnt)
{
#if _PRJ_ISP||_PRJ_SMIVU
    gpHostAddrInfo->u32HSector+=uSctrCnt;

    if(gpHostAddrInfo->u32HSector>=g32SectorPerBlockH)
    {
        gpHostAddrInfo->u16HBlock++;
        gpHostAddrInfo->u32HSector-=g32SectorPerBlockH;
    }

    // else if (gbChgBlock)
    // {
    // gbChgBlock=0;
    // }

    gpHostAddrInfo->u16HPage=gpHostAddrInfo->u32HSector>>cSctrTo4kShift;
    gpHostAddrInfo->uStartSector=(gpHostAddrInfo->uStartSector+uSctrCnt)&(cSctrPer4k-1);
#else
    while(1)
        ;
#endif/* if _PRJ_ISP */
}    /* addLbaAddr */

#if (_PRJ_BOOT||_PRJ_SMIVU)

/**************/
// Boot
/**************/

BYTE assignFreeBtSrcAddrInfo()
{
    // do at core-0
    WORD u16NowSrcAddrIdx;

    setLock(&gsMutexInfo);    // setLock(&gsBtMutexInfo.uAddSrcAddrLock);

    // u16NowSrcAddrIdx=gsRwCtrl.usBootSrcCmdInfo.uAsignCnt;

    u16NowSrcAddrIdx=gsRwCtrl.uarFreeSrcQue[gsRwCtrl.u32FreeSrcFifoHead];
    copyCcmVal((BYTE *)&garSrcAddrInfo[u16NowSrcAddrIdx], (BYTE *)gpFlashAddrInfo, sizeof(ADDRINFO));
    garSrcAddrInfo[u16NowSrcAddrIdx].uTsb4kIdx=0xFF;
    // copyCcmVal((BYTE *)&garSrcAddrInfo[u16NowSrcAddrIdx], (BYTE *)gpFlashAddrInfo, sizeof(ADDRINFO));
    // gsRwCtrl.usBootSrcCmdInfo.uAsignCnt++;

    gsRwCtrl.u32FreeSrcFifoHead=(gsRwCtrl.u32FreeSrcFifoHead+1)&(cReadFifoDpt-1);

    clrLock(&gsMutexInfo);    // clrLock(&gsBtMutexInfo.uAddSrcAddrLock);
    return u16NowSrcAddrIdx;
}    /* assignFreeBtSrcAddrInfo */

BYTE assignFreeBtDesAddrInfo()
{
    // do at core-0
    WORD u16NowDesAddrIdx;

    setLock(&gsMutexInfo);    // setLock(&gsBtMutexInfo.uAddDesAddrLock);

    u16NowDesAddrIdx=gsRwCtrl.u32ProgFifoHead;
    copyCcmVal((BYTE *)&garDesAddrInfo[u16NowDesAddrIdx], (BYTE *)gpFlashAddrInfo, sizeof(ADDRINFO));
    garDesAddrInfo[u16NowDesAddrIdx].uAddrOpt&=~(cDone|cProgFail);    // cForeClrOccF|cBackClrOccF);
    gsRwCtrl.u32ProgFifoHead=addWrFfPtrBy1(gsRwCtrl.u32ProgFifoHead);    // (gsRwCtrl.u32ProgFifoHead+1)&(cWriteFifoDpt-1);

    // gsRwCtrl.usBootDesCmdInfo.uAsignCnt++;
    clrLock(&gsMutexInfo);    // clrLock(&gsBtMutexInfo.uAddDesAddrLock);
    return u16NowDesAddrIdx;
}    /* assignFreeBtDesAddrInfo */

/**************/
// Boot
/**************/

void waitCmdAllDone(BYTE uOpt)
{
    // wait at core 0

    // while((uOpt&cWaitTrigRCnt)&&(gsRwCtrl.usBootSrcCmdInfo.uAsignCnt!=gsRwCtrl.usBootSrcCmdInfo.uDoneCnt))
    //    ;

    // while((uOpt&cWaitTrigWCnt)&&(gsRwCtrl.usBootDesCmdInfo.uAsignCnt!=gsRwCtrl.usBootDesCmdInfo.uDoneCnt))
    //    ;

    if(uOpt&cWaitTrigRCnt)
    {
        while(gsRwCtrl.u32FreeSrcFifoTrig!=gsRwCtrl.u32FreeSrcFifoHead)
            ;

        while(gsRwCtrl.usSrcCmdList.u16Cnt)
            ;
    }

    if(uOpt&cWaitTrigWCnt)
    {
        while(gsRwCtrl.u32ProgFifoTail!=gsRwCtrl.u32ProgFifoHead)
            ;
    }

    if(uOpt&cWaitCmdBz)
    {
        rmWaitSysCmdFifoBz;
    }
}    /* waitCmdAllDone */

void releaseBtSrcAddrInfo()
{
    // do at core-0
    setLock(&gsMutexInfo);    // setLock(&gsBtMutexInfo.uAddSrcAddrLock);
    // setLock(&gsBtMutexInfo.uAddDoneSrcAddrLock);

    if(gsRwCtrl.usBootSrcCmdInfo.uAsignCnt!=gsRwCtrl.usBootSrcCmdInfo.uDoneCnt)    // debug
    {
        gsFtlDbg.u16DummyFailType=cReleaseBtSrcAddrInfo;
        debugWhile();
    }

    gsRwCtrl.usBootSrcCmdInfo.uAsignCnt=gsRwCtrl.usBootSrcCmdInfo.uDoneCnt=0;
    clrLock(&gsMutexInfo);    // clrLock(&gsBtMutexInfo.uAddDoneSrcAddrLock);
    // clrLock(&gsBtMutexInfo.uAddSrcAddrLock);
}

void releaseBtDesAddrInfo()
{
    // do at core-0
    setLock(&gsMutexInfo);    // setLock(&gsBtMutexInfo.uAddDesAddrLock);
    // setLock(&gsBtMutexInfo.uAddDoneDesAddrLock);

    if(gsRwCtrl.usBootDesCmdInfo.uAsignCnt!=gsRwCtrl.usBootDesCmdInfo.uDoneCnt)    // debug
    {
        gsFtlDbg.u16DummyFailType=cReleaseBtDesAddrInfo;
        debugWhile();
    }

    gsRwCtrl.usBootDesCmdInfo.uAsignCnt=gsRwCtrl.usBootDesCmdInfo.uDoneCnt=0;
    clrLock(&gsMutexInfo);    // clrLock(&gsBtMutexInfo.uAddDoneDesAddrLock);
    // clrLock(&gsBtMutexInfo.uAddDesAddrLock);
}

#endif/* if (_PRJ_BOOT||_PRJ_SMIVU) */

BYTE chkH2fFindHMBQueue(WORD u16Hblock)
{
    BYTE uLoop;

    for(uLoop=0; uLoop<cHmbRacingFreeCnt; uLoop++)
    {
        if(g16WriteHMBH2FTable[uLoop]==u16Hblock)
        {
            return cTrue;
        }
    }

    return cFalse;
}

void readH2fTable(WORD u16SbufPtr, WORD u16Hblock, WORD u16RwOpt, BYTE uOpt)
{
    WORD u16FBlock;
    LWORD u32FPage;

#if _ENABLE_E2E_TAB
    LWORD u32StartFPage;
    WORD u16StartBufPtr=u16SbufPtr;
    uOpt|=cWaitReadDone;
#endif

    if(mChkHmbLink(u16Hblock)&&!chkH2fFindHMBQueue(u16Hblock))
    {
#if (_PRJ_BOOT&&!_ICE_LOAD_ALL)
        gsFtlDbg.u16DummyFailType=cReadH2fTable;
        debugWhile();
#else
        readHmbH2fTab2(u16SbufPtr, u16Hblock, uOpt);

        if(uOpt&cWaitReadDone)
        {
            mWaitHmbTransferDone();
        }
#endif
    }
    else
    {
        if(mChkHmbLink(u16Hblock))
        {
#if (!_PRJ_BOOT||_ICE_LOAD_ALL)
            waitHmbPrdDone();
#endif
            u16FBlock=g16arH2fTabBlk[mGetH2fTabBlkIndex(g16TotalHBlock+mGetHmbLink(u16Hblock))];
            u32FPage=(LWORD)(mGetH2fTabPagePtr(g16TotalHBlock+mGetHmbLink(u16Hblock)))*gPage4kPerH2fTab;
        }
        else
        {
            u16FBlock=g16arH2fTabBlk[mGetH2fTabBlkIndex(u16Hblock)];
            u32FPage=(LWORD)(mGetH2fTabPagePtr(u16Hblock))*gPage4kPerH2fTab;
        }

        readNandH2fTab(u32FPage, u16FBlock, u16SbufPtr, u16RwOpt, uOpt);
    }
}    /* readH2fTable */

void swapH2fTable(WORD u16Hblock, WORD u16SbufPtr, BYTE uOpt)
{
    LWORD u32H2fAddr;
    WORD u16ReadH2fOpt;
    BYTE uHDMAOpt=0;

    if(g16arH2fTabPtr[u16Hblock]!=0xFFFF)
    {
#if (_PRJ_BOOT&&!_ICE_LOAD_ALL)
        if(mChkHmbLink(u16Hblock))
        {
            gsFtlDbg.u16DummyFailType=cSwapH2fTable;
            debugWhile();
        }
#endif
        u16ReadH2fOpt=c16Bit0|c16Bit4|c16Bit15;

        if(uOpt&cSetBufferFlag)
        {
            u16ReadH2fOpt|=c16Bit1;
        }

        readH2fTable(u16SbufPtr, u16Hblock, u16ReadH2fOpt, uOpt);
    }
    else
    {
        u32H2fAddr=c32Tsb0SAddr+u16SbufPtr*0x200;
        uHDMAOpt=cClrTsb|cHdmaNotWait;

        if(uOpt&cWaitReadDone)
        {
            uHDMAOpt|=cHdmaWait;
        }

        if(uOpt&cSetBufferFlag)
        {
            uHDMAOpt|=cHdmaTsbFlag;
        }

#if _EN_RAID_H2F
        hdmaClrRam((LWORD)u32H2fAddr, g32H2fTabValidSize, (LWORD)cUncTypeMask, uHDMAOpt);
#else
        hdmaClrRam((LWORD)u32H2fAddr, g32H2fTabFullSize, (LWORD)cUncTypeMask, uHDMAOpt);
#endif
    }

    // gsCacheInfo.u15ActiveH2fTab=u16Hblock;
}    /* swapH2fTable */

BYTE chkPopBlkOpt()
{
    BYTE uPopOpt;

    /*
       * if(!gsHmbInfo.uHmbEnWrCache||((gsCacheInfo.u16FullCacheBlockCnt<g16CurrSlcCacheBlockThr)&&((g64TotalTlcOneShotCnt>>2)>g64TotalSlcProgCnt)))
       * {
       *   gsCacheInfo.ubSLCCacheEnable=cTrue;
       *   uPopOpt=cPopMinErsCnt|cPopSlcBlock;
       * }
       * else
       * {
       *   gsCacheInfo.ubSLCCacheEnable=cFalse;
       *   uPopOpt=cPopMinErsCnt;
       * }
       *
       * return uPopOpt;*/
    gsCacheInfo.ubSLCCacheEnable=cTrue;
    uPopOpt=cPopMinErsCnt|cPopSlcBlock|cPopDataBlock;
    return uPopOpt;
}    /* chkPopBlkOpt */

void addCacheBlkSerial()
{
    if(gsGcInfo.u32GcDesSerial==c32InitSerialVal)
    {
        gsCacheInfo.u32CacheBlkSerial=addPtrBy1(gsCacheInfo.u32CacheBlkSerial, c32MaxCacheSerial);
    }
    else if(judgeSerial(gsCacheInfo.u32CacheBlkSerial+1, gsGcInfo.u32GcDesSerial)!=cSerialLarger)
    {
        gsCacheInfo.u32CacheBlkSerial=addPtrBy1(gsGcInfo.u32GcDesSerial, c32MaxCacheSerial);
    }
    else
    {
        gsCacheInfo.u32CacheBlkSerial=addPtrBy1(gsCacheInfo.u32CacheBlkSerial, c32MaxCacheSerial);
    }
}    /* addCacheBlkSerial */

void recordCacheBlk()
{
#if (!_PRJ_BOOT)
    // if rdlink, the active cache block change to new block after padding & move risk page.
    // pre cache block, flush cache block are the same as previous runtime.

    BYTE uCacheBlkIdx;

    for(uCacheBlkIdx=0; uCacheBlkIdx<cCacheBlkNum-1; uCacheBlkIdx++)
    {
        g16arCacheBlock[uCacheBlkIdx]=g16arCacheBlock[uCacheBlkIdx+1];
        g32arCacheBlkSerial[uCacheBlkIdx]=g32arCacheBlkSerial[uCacheBlkIdx+1];
        garCacheBlkF2hTabBank[uCacheBlkIdx]=garCacheBlkF2hTabBank[uCacheBlkIdx+1];
    }

    g16arCacheBlock[cActCacheBlkIdx]=gsCacheInfo.u16ActiveCacheBlock;
    g32arCacheBlkSerial[cActCacheBlkIdx]=gsCacheInfo.u32CacheBlkSerial;
    garCacheBlkF2hTabBank[cActCacheBlkIdx]=gsCacheInfo.uF2hTabBank;
#endif
}    /* recordCacheBlk */

void initCacheFblkProc()
{
    // if(gsCacheInfo.ubCacheBlockFull)
    // {
    if(gsCacheInfo.u16PrePopCacheBlock!=c16FBlockInitValue)
    {
        gsCacheInfo.u16ActiveCacheBlock=gsCacheInfo.u16PrePopCacheBlock;
        gsCacheInfo.u16PrePopCacheBlock=c16FBlockInitValue;
    }
    else
    {
#if _GREYBOX
        if((gsGbInfo.uGreyBoxItem==cUGSDProgCacheSlcID)&&(gsGbInfo.uGreyBoxOpt==cVOpErasing)&&(gsGbInfo.uStag==cVsIdl))
        {
            trigGreyBox(cTrue);
        }
        else if((gsGbInfo.uGreyBoxItem==cUGSDonEraseFail)&&(gsGbInfo.uStag==cVsIdl)&&(gsGbInfo.uGreyBoxOpt==cVOpPopCacheSlcBfErase))
        {
            gsGbInfo.uStag=cVsTriggered;
        }
        else if((gsGbInfo.uGreyBoxItem==cUGSDonEraseFail)&&(gsGbInfo.uGreyBoxOpt==cVOpPopCacheSlcAfErase)&&(gsGbInfo.u32BkValue==cSuccess))
        {
            gsGbInfo.u32BkValue|=c32Bit1;
        }
#endif
        gsCacheInfo.u16ActiveCacheBlock=popSpareBlockCore0(chkPopBlkOpt());    // gsTskFifoCtrl.u16PopFBlk;
        // gsTskFifoCtrl.u16PopFBlk=c16FBlockInitValue;
    }

/*
   *  if(mChkMlcMoBit(gsCacheInfo.u16ActiveCacheBlock))
   *  {
   *      gsCacheInfo.uMaxBankNum=gTotalTlcBankOfF2hTab;
   *      gsCacheInfo.u16ValidPgPerF2hTab=g16TlcValidPgPerF2hTab;
   *      gsCacheInfo.u4KNumToPadF2h=gTlc4KNumToPadF2h;
   *      gsCacheInfo.uPadF2h4KNum=gTlcPadF2h4KNum;
   *      gsCacheInfo.u16TotalPgPerF2hTab=g16TotalTlcPgPerF2hTab;
   *      gsCacheInfo.uProgF2HRem4KNum=gTlcProgF2HRem4KNum;
   *      gsCacheInfo.uSecNumPadF2h_1=gTlcSecNumPadF2h_1;
   *      gsCacheInfo.u16F2hPadStartAddr_2=g16TlcF2hPadStartAddr_2;
   *      gsCacheInfo.u16F2hChkFlushStart=g16TlcF2hChkStart;
   *      gsCacheInfo.u16F2hChkFlushSize=g16TlcF2hChkSize;
   #if _ENABLE_RAID
   *      gsCacheInfo.u16PartialParityNum=g16TlcPartialParityNum;
   *      gsCacheInfo.u16ProgRaidChStr4K=g16TlcProgRaidChStr4K;
   #endif
   *  }
   *  else
   *  {
   */
    gsCacheInfo.uMaxBankNum=gTotalBankOfF2hTab;
    gsCacheInfo.u16ValidPgPerF2hTab=g16ValidPgPerF2hTab;
    gsCacheInfo.u4KNumToPadF2h=gSlc4KNumToPadF2h;
    gsCacheInfo.uPadF2h4KNum=gSlcPadF2h4KNum;
    gsCacheInfo.u16TotalPgPerF2hTab=g16TotalPgPerF2hTab;
    gsCacheInfo.uProgF2HRem4KNum=gSlcProgF2HRem4KNum;
    gsCacheInfo.uSecNumPadF2h_1=gSlcSecNumPadF2h_1;
    gsCacheInfo.u16F2hPadStartAddr_2=g16SlcF2hPadStartAddr_2;
    gsCacheInfo.u16F2hChkFlushStart=g16SlcF2hChkStart;
    gsCacheInfo.u16F2hChkFlushSize=g16SlcF2hChkSize;
#if _ENABLE_RAID
    gsCacheInfo.u16PartialParityNum=g16SlcPartialParityNum;
    gsCacheInfo.u16ProgRaidChStr4K=g16SlcProgRaidChStr4K;
#endif/* if _ENABLE_RAID */

    insSlcSortQCore0(gsCacheInfo.u16ActiveCacheBlock);
    // }

    gsCacheInfo.u16CacheBlockCnt++;
    gsCacheInfo.uF2hTabBank=0;
    gsCacheInfo.u32SrchF4kBase=gsCacheInfo.u16TotalPgPerF2hTab-1;
    gsCacheInfo.u32CacheFreePagePtr=0;
    mClrCacheInfoFlag(cCacheBlockFull);
    gsCacheInfo.u16CacheF2hTabFreePtr=gsCacheInfo.u16TotalPgPerF2hTab-1;
    // gsCacheInfo.uMaxBankNum=gTotalTlcBankOfF2hTab;

    // old code use
    // gsRwCtrl.u16MaxProgSctrCnt=gTotalChNum*g4kNumPerPage*cSctrPer4k;
    // g16FPageProgOrder=0;    // need to add to gsRWCtrl.u16FPageProgOrder!!!!!!
    // gNowProgCe=0;    // need to add to gsRWCtrl.uNowProgCe!!!!!!

    addCacheBlkSerial();
    recordCacheBlk();
#if (!(_PRJ_BOOT)||(_ICE_LOAD_ALL))
    flushCacheHmbTab();
#endif

#if (_PRJ_ISP||_PRJ_ATA)    // temp no prog cache info
#if _GREYBOX
    if((gsGbInfo.uGreyBoxItem==cUGSDProgWPROID)&&
       ((gsGbInfo.uGreyBoxOpt==cVOpProgCacheInfoInitCache)||(gsGbInfo.uGreyBoxOpt==cVOpProgCacheInfoInitCacheDone))&&(gsGbInfo.uStag==cVsIdl))
    {
        trigGreyBox(cTrue);
    }
#endif
    progCacheInfoTab();
#endif
    // }
}    /* initCacheFblkProc */

void readNandH2fTab(LWORD u32FPage, WORD u16FBlock, WORD u16SbufPtr, WORD u16RwOpt, BYTE uOpt)
{
#if _ENABLE_E2E_TAB
    LWORD u32StartFPage=u32FPage;
    WORD u16StartBufPtr=u16SbufPtr;
#endif
    WORD u16NowNodeIdx;
    BYTE uRead4kCnt, uRest4kCnt;

#if _GREYBOX
    if(((gsGbInfo.uGreyBoxItem==cRAIDEncOnH2fTab)||(gsGbInfo.uGreyBoxItem==cRAIDDecOnH2fTab))&&(gsGbInfo.u32BkValue!=0))
    {
        uRest4kCnt=gPage4kPerH2fTab;
    }
    else
#endif
    {
#if _EN_RAID_H2F
        uRest4kCnt=gPage4kPerH2fTab-(cRaidHTabSctrNum>>cSctrTo4kShift);
#else
        uRest4kCnt=gPage4kPerH2fTab;
#endif
    }

    while(uRest4kCnt!=0)
    {
        u16NowNodeIdx=gsRwCtrl.uarFreeSrcQue[gsRwCtrl.u32FreeSrcFifoHead];
        gpFlashAddrInfo=&garSrcAddrInfo[u16NowNodeIdx];

        g16FBlock=u16FBlock;
        g32FPageNoTran=u32FPage;
        gpFlashAddrInfo->uTsb4kIdx=0xFF;
        gpFlashAddrInfo->uSrcIdx=u16NowNodeIdx;
        // g16FPage=g32FPageNoTran;
        tranAddrInfo(gpFlashAddrInfo);
        // tranCeNum(gpFlashAddrInfo);
        gSectorH=0;

        if(uRest4kCnt>=g4kNumPerPage)
        {
            uRead4kCnt=g4kNumPerPage;
        }
        else
        {
            uRead4kCnt=uRest4kCnt;
        }

        mSetFRwParam(u16SbufPtr, uRead4kCnt<<cSctrTo4kShift, u16RwOpt, cH2fReadTab);
        // gsCacheInfo.ubPrep++;

        gsRwCtrl.u32FreeSrcFifoHead=(gsRwCtrl.u32FreeSrcFifoHead+1)&(cReadFifoDpt-1);

        u32FPage+=uRead4kCnt;
        u16SbufPtr+=gpFlashAddrInfo->uRwHalfKb;
        uRest4kCnt-=uRead4kCnt;
    }

    if(uOpt&cWaitReadDone)
    {
        while((gsRwCtrl.u32FreeSrcFifoTail!=gsRwCtrl.u32FreeSrcFifoHead)||g32DecodeWait)
            ;

#if _ENABLE_E2E_TAB
        chkInternalDataCrc(u16StartBufPtr, gPage4kPerH2fTab<<cSctrTo4kShift,
                           u32StartFPage<<cSctrTo4kShift, cE2eH2fBlk);
#endif
    }
}    /* readNandH2fTab */

#if (_PRJ_ISP||_PRJ_SMIVU)
void termFuaWFlow()
{
#if (_FUA_PERF)
    mSetTermWFua;

    termFlashOperW(1);
    chkReleaseFreeHwPrd();

    mClrTermWFua;

    if(!gFuaQueueCnt)
    {
        mClrQueueFuaCmd;
    }
#endif
}

#endif/* if (_PRJ_ISP||_PRJ_SMIVU) */







