







#include "inc/EventLogIDX.h"
#include "inc/EventLogFunctionIDX.h"
#include "inc/Security.h"

#if (!_ICE_DEBUG)
#pragma default_function_attributes = @ ".SecurityAPI_Code_Crypto"
#endif

void reverseArray(BYTE *uDataIn, LWORD u32length)    // For FIPS 140
{
    LWORD u32Cnt=0;
    LWORD u32Cnt2=0;

    bopClrRamForTsbCode((LWORD)(&garCryptoTmpBuf[0]), 512, 0x00000000, cBopWait|cClrTsb);    // Reset the last sector of garISPCode as temporary
                                                                                             // buffer

    for(u32Cnt=u32length, u32Cnt2=0; u32Cnt>0; u32Cnt--, u32Cnt2++)
    {
        garCryptoTmpBuf[u32Cnt2]=uDataIn[u32Cnt-1];
    }

    for(u32Cnt=0; u32Cnt<u32length; u32Cnt++)
    {
        uDataIn[u32Cnt]=garCryptoTmpBuf[u32Cnt];
    }
}    /* reverseArray */

LWORD memoryAllocate(BYTE uMode, WORD u16Length, LWORD u32BaseAddr)
{
    LWORD u32Addr;
    WORD *u16TSBPtr=(WORD *)u32BaseAddr;

    if(uMode&cRsaResetTempMemory)
    {
        bopClrRamForTsbCode(u32BaseAddr, 32768*2, 0, cClrTsb|cBopWait);
        g16TempRamPtr=0;
        g16TempRamStackPtr=0;
    }

    if(uMode&cRsaSetMemoryClrPoint)
    {
        u16TSBPtr[(cRsaStackStartOffset-g16TempRamStackPtr)]=g16TempRamPtr;
        g16TempRamStackPtr++;
    }

    u32Addr=(LWORD)(&u16TSBPtr[0])+(LWORD)g16TempRamPtr;
    g16TempRamPtr+=u16Length;

    while(g16TempRamPtr>=((32768-g16TempRamStackPtr)*2))
        ;// the space for g16TempRamPtr should be reserved

    return u32Addr;
}    /* memoryAllocate */

void memoryRelease(LWORD u32BaseAddr)
{
    WORD *u16TSBPtr=(WORD *)u32BaseAddr;

    if(g16TempRamStackPtr!=0)
    {
        g16TempRamStackPtr--;
        g16TempRamPtr=u16TSBPtr[(cRsaStackStartOffset-g16TempRamStackPtr)];
    }
}

BYTE trngRandNum(LWORD u32TrngSampleCnt, WORD u16InputLen, BYTE *upTrngRandNum)
{
    LWORD u32TrngCnt=0;
    LWORD u32TempBuffer;
    WORD u16Loop;
    BYTE uTrngOk;
    BYTE uSuccess=1;

    // enable clock
    // rSysCtrl0[0x2e]=0x42;	   // enhance the trng clk //  bit 4 and bit 5 for  disable gate and power down
    rSysCtrl0[0x2E]=0x40;    // set the trng clk to 431Mhz for A2 ASIC // clear bit 4 (power-down) and bit 5 (enable gate) ; set bit 6 (select
                             // the ring osc as the random source)

    // 2263XT has removed.
    // while(!rmFreeOscChkLock)
    //    ;

    rmRngSoftRst;
    rmRngSrcDis;
    rmDisAllRngInt;

    r32TrngCtrl[rcTrngSmapleCnt/4]=u32TrngSampleCnt;
    rmRngSrcEn;

    // M_En_TRNG_Bypass;
    while(!rmRngValid)
    {
        u32TrngCnt++;

        if(u32TrngCnt>300000000)
        {
            uSuccess=0;
            break;
        }
    }

    for(u16Loop=0; u16Loop<u16InputLen; u16Loop++)
    {
        if((u16Loop&0x0F)==0)
        {
            uTrngOk=0;

            while(!uTrngOk)
            {
                while(!rmRngValid)
                {
                    u32TrngCnt++;

                    if(u32TrngCnt>300000000)
                    {
                        uSuccess=0;
                        break;
                    }
                }

                if(!uSuccess)
                {
                    // Some error happened!!!
                    rmRngSoftRst;
                    rmRngSrcDis;
                    r32TrngCtrl[rcTrngSmapleCnt/4]=u32TrngSampleCnt;
                    rmRngSrcEn;
                    u32TrngCnt=0;
                    uSuccess=1;
                }
                else
                {
                    uTrngOk=1;
                }
            }
        }

        // Trng engine must fetch 4 bytes each times.
        if((u16Loop&0x3)==0)
        {
            u32TempBuffer=r32TrngCtrl[(rcEhrValid0/4)+((u16Loop>>2)&0x3)];
        }

        upTrngRandNum[u16Loop]=(u32TempBuffer>>((u16Loop&0x3)<<3))&0xFF;
    }

    rmRngSrcDis;
    rSysCtrl0[0x2E]=0x30;    // set the trng clk to 431Mhz for A2 ASIC // set bit 4 (power-down) and bit 5 (enable gate)

    return 0;
}    /* trngRandNum */

void getRandom(LWORD u32Length, BYTE *upBuffer)
{
#if _ENABLE_TRNG
    WORD u16OriSysClk;

    // M_SysEnSysDivChkCfg;
    while(!rmAuxChkUartIdle)
        ;// need to wait UART Idle

    u16OriSysClk=r16SysCtrl0[rcSysPllSel/2];
    setSysPllClock(100);

    // SetClockForTrng(); // for perfermance temp disable
    while(!rmChkSysPllLock)
        ;

    trngRandNum(0x2E, (WORD)u32Length, upBuffer);
    // rmSetSysClkPll(u16OriSysClk);    // need to recovery the orginial value
    r16SysCtrl0[rcSysPllSel/2]=u16OriSysClk;

    while(!rmChkSysPllLock)
        ;

    rmUartBaudRate=(tran2DecClk()/921600)-1;
    // M_SysDisSysDivChkCfg;
#endif/* if _ENABLE_TRNG */
}    /* getRandom */

void resetRam(BYTE *ptr, LWORD size, BYTE uVal)
{
    LWORD i;
    LWORD u32Val;
    LWORD *u32Ptr;

    if((size<64)||((LWORD)ptr&0x03)||(size&0x03))
    {
        for(i=0; i<size; i++)
        {
            *ptr++=uVal;
        }
    }
    else
    {
        u32Ptr=(LWORD *)ptr;
        size>>=2;
        u32Val=uVal;
        u32Val=(u32Val<<24)|(u32Val<<16)|(u32Val<<8)|u32Val;

        for(i=0; i<size; i++)
        {
            *u32Ptr++=u32Val;
        }
    }
}    /* resetRam */

void moveData(BYTE *upDesAddr, BYTE *upSrcAddr, LWORD u32Len)
{
    LWORD i;

    for(i=0; i<u32Len; i++)
    {
        upDesAddr[i]=upSrcAddr[i];
    }
}

void moveMem2Mem(LWORD u32SrcAddr, LWORD u32DesAddr, LWORD u32Len)
{
    invalidateDCache();
    LWORD i;
    volatile UCBYTE *upSrcAddr=(volatile UCBYTE *)u32SrcAddr;
    volatile UCBYTE *upDesAddr=(volatile UCBYTE *)u32DesAddr;

    for(i=0; i<u32Len; i++)
    {
        upDesAddr[i]=upSrcAddr[i];
    }

    invalidateDCache();
}

BYTE memoryCompareAddress(LWORD u32SrcAddr, LWORD u32DesAddr, LWORD u32Length)
{
    invalidateDCache();

    LWORD u32Idx;
    volatile UCBYTE *upSrcAddr=(volatile UCBYTE *)u32SrcAddr;
    volatile UCBYTE *upDesAddr=(volatile UCBYTE *)u32DesAddr;

    for(u32Idx=0; u32Idx<u32Length; u32Idx++)
    {
        if(upSrcAddr[u32Idx]!=upDesAddr[u32Idx])
        {
            invalidateDCache();
            return 0;
        }
    }

    invalidateDCache();
    return 1;
}    /* memoryCompareAddress */

void gatherSecurityPageInfo()
{
    bopClrRamForTsbCode((LWORD)(&garTsb0[0]), gSectorPerPageH*512, 0, cClrTsb|cBopWait);

    moveData((UCBYTE *)((&garTsb0[0][0])+cEncryptedRootKeyPtr), garEncryptedRootKey, cSp800_38fEncryptedSize);
    moveData((UCBYTE *)((&garTsb0[0][0])+cEncryptedOriginalKekPtr), garEncryptedOriginalKEK, cSp800_38fEncryptedSize);
    moveData((UCBYTE *)((&garTsb0[0][0])+cEncryptedMekPtr), garEncryptedMEK, cSp800_38fEncryptedMekSize);
}

void updataSecurityKeyInfo()
{
    moveData(garEncryptedRootKey, (UCBYTE *)((&garTsb0[0][0])+cEncryptedRootKeyPtr), cSp800_38fEncryptedSize);
    moveData(garEncryptedOriginalKEK, (UCBYTE *)((&garTsb0[0][0])+cEncryptedOriginalKekPtr), cSp800_38fEncryptedSize);
    moveData(garEncryptedMEK, (UCBYTE *)((&garTsb0[0][0])+cEncryptedMekPtr), cSp800_38fEncryptedMekSize);
}

void initSecurity()
{
    // === Initialize TCG parameters ===
#if _ENABLE_SECAPI
    SecAPI_InitParameter_BaseFW();
    SecAPI_InitSecAPI(cInitForce);
#endif
}

BYTE changeAesKey(BYTE uChangeAESKeyOption, LWORD uSrcAddr, BYTE uLoadKey, BYTE uSaveKeyInfo, BYTE uPassToSecurityFW, BYTE uInitSecurity)
{
    BYTE uByteCnt=0;
    BYTE uarMEK[cMekSize];
    BYTE uarEncryptedMEK[cSp800_38fEncryptedMekSize];
    BYTE uStatus=0;

    // ===Create new AES Key===
    switch(uChangeAESKeyOption)
    {
        case cRandomKey:
            Crypto_GenerateNDRBG(uarMEK, cMekSize);
            break;

        case cPtrInputKey:
            moveMem2Mem(uSrcAddr, (LWORD)(&uarMEK[0]), cMekSize);
            break;

        default:
            Crypto_GenerateNDRBG(uarMEK, cMekSize);
            break;
    }

    // Check AES Key1 != Key2
    if(SecIntf_MemoryCompare((LWORD)((BYTE *)&uarMEK[0]), (LWORD)((BYTE *)&uarMEK[32]), 32))
    {
        Crypto_GenerateNDRBG(uarMEK, cMekSize);

        if(SecIntf_MemoryCompare((LWORD)((BYTE *)&uarMEK[0]), (LWORD)((BYTE *)&uarMEK[32]), 32))
        {
            NLOG(cLogSecApiBaseFw, SECURITY_C, 0, "  ChangeAESKey() failed, AES Key1 = Key2");
        }
    }

    // ===Load new DE(AES) Key===
    if(uLoadKey)
    {
        rmAesNormalMode;    // Switch to normal mode before changing keys
        rmFwAesNormalMode;

        for(uByteCnt=0; uByteCnt<cMekSize; uByteCnt++)
        {
            rAesCtrl[rcAesDefaultKey00+uByteCnt]=uarMEK[uByteCnt];
            rFwAes[rcAesDefaultKey00+uByteCnt]=uarMEK[uByteCnt];
        }

        rmAesMode;
        rmFwAesMode;
    }

#if _ENABLE_ATA_PASSTHROUGH
    if(!gbEnTCG&&gbEnATAPassThrough)
    {
        SecAPI_NoticeModifyMEKs_Request(uarMEK);
    }
    else
#endif
    {
        gatherSecurityPageInfo();
        modifyMeks(uarMEK);

        if(uSaveKeyInfo)
        {
            progWproPageCore0(cWproSecurityId, c16Tsb0SIdx|c16Bit15);
        }

        updataSecurityKeyInfo();
    }

    // ===before passing garTmpAESRangeKey to Security FW, UpdataSecurityKeyDRAMInfo() must be done===
    if(uPassToSecurityFW)
    {
#if _ENABLE_SECAPI
        if(gbEnTCG)
        {
            uStatus=SecAPI_Crypto_UpdateGlobalRangeKey_Request(uarMEK);

            if(uStatus)
            {
                NLOG(cLogSecApiBaseFw, SECURITY_C, 0, "ChangeAESKey()-PassToSecurityFW fails");
                readWproPageCore0(cWproSecurityId, c16Tsb0SIdx, 0);
                updataSecurityKeyInfo();
            }
        }
#endif
    }

    resetRam(uarMEK, cMekSize, 0);
    resetRam(uarEncryptedMEK, cSp800_38fEncryptedMekSize, 0);

    // Initialize TCG
    if(uInitSecurity)
    {
#if _ENABLE_SECAPI
        if(gbEnTCG||gbEnATAPassThrough)
        {
            initSecurity();
        }
#endif
    }

    return uStatus;
}    /* changeAesKey */

BYTE processCryptoErase()
{
    BYTE uProcessCryptoEraseFail;

#if _ENABLE_SECAPI
    if(gbEnTCG)
    {
        uProcessCryptoEraseFail=changeAesKey(cRandomKey, 0, 0, 0, 1, 0);
    }
    else
#endif
    {
        uProcessCryptoEraseFail=changeAesKey(cRandomKey, 0, 1, 1, 0, 0);
    }

    return uProcessCryptoEraseFail;
}

void destroyAesDefaultKey()
{
    BYTE uCnt;

    rmAesNormalMode;
    rmFwAesNormalMode;

    for(uCnt=0; uCnt<cMekSize; uCnt++)
    {
        rAesCtrl[rcAesDefaultKey00+uCnt]=0;
        rFwAes[rcAesDefaultKey00+uCnt]=0;
    }

    rmAesMode;
    rmFwAesMode;
}

void getRootKey(BYTE *upRootKey)
{
    BYTE uStatus;
    BYTE uarDefaultPassword[cPasswordSize];

    if(!rmEfuseChkProdFlag)
    {
        moveMem2Mem((LWORD)&cbSmiSecureDefaultPassword[0], (LWORD)&uarDefaultPassword[0], cPasswordSize);
        uStatus=KeyWraping_AD(uarDefaultPassword,
                              cPasswordSize,
                              (BYTE *)(&garTsb0[0][cEncryptedRootKeyPtr]),
                              cSp800_38fEncryptedSize,
                              upRootKey,
                              cSecurityApiBufferAddr);

        if(uStatus)    // Decrypt fail
        {
            gSecurityWProMode=1;
            resetRam(upRootKey, cRootKeySize, 0);
        }
    }
    else
    {
        moveMem2Mem((LWORD)&gSecuEfuse[0], (LWORD)&upRootKey[0], cRootKeySize);
    }
}    /* getRootKey */

void getDerivedKey(BYTE *upDerivedKey)
{
    BYTE uarDecryptedRootKey[cRootKeySize];

    getRootKey(uarDecryptedRootKey);
    KDF_Counter_Mode((BYTE *)uarDecryptedRootKey,
                     cRootKeySize,
                     (BYTE *)cbRootKeyLabel,
                     cRootKeyLabelSize,
                     (BYTE *)cbRootKeyContext,
                     cRootKeyContextSize,
                     (BYTE *)upDerivedKey,
                     cPasswordSize,
                     cSecurityApiBufferAddr,
                     0);

    resetRam(uarDecryptedRootKey, cRootKeySize, 0);
}    /* getDerivedKey */

void genRootKey()
{
    BYTE uarRootKey[cRootKeySize];
    BYTE uarDefaultPassword[cPasswordSize];

    Crypto_GenerateNDRBG(uarRootKey, cRootKeySize);

    moveMem2Mem((LWORD)&cbSmiSecureDefaultPassword[0], (LWORD)&uarDefaultPassword[0], cPasswordSize);
    KeyWraping_AE((BYTE *)uarDefaultPassword, cRootKeySize, uarRootKey, cRootKeySize, garEncryptedRootKey, cSecurityApiBufferAddr);

    resetRam(uarRootKey, cRootKeySize, 0);
}

void genKek()
{
    BYTE uarDerivedKey[cPasswordSize];
    BYTE uarKEK[cKekSize];

    gatherSecurityPageInfo();    // same as read security page

    // step 1 generate KEK
    Crypto_GenerateNDRBG(uarKEK, cKekSize);    // random number

    // step 2 get Derived Key
    getDerivedKey(uarDerivedKey);

    // step 3 encrypt KEK
    KeyWraping_AE((BYTE *)uarDerivedKey, cPasswordSize, uarKEK, cKekSize, (BYTE *)&garTsb0[0][cEncryptedOriginalKekPtr],
                  cSecurityApiBufferAddr);

    progWproPageCore0(cWproSecurityId, c16Tsb0SIdx);
    updataSecurityKeyInfo();

    resetRam(uarDerivedKey, cPasswordSize, 0);
    resetRam(uarKEK, cKekSize, 0);
}    /* genKek */

void restoreKek(BYTE *upKEK)    // GatherSecurityPageInfo() must be called before
{
    BYTE uarDerivedKey[cPasswordSize];

    // step 1 get Derived Key
    getDerivedKey(uarDerivedKey);

    // step 2 decrypt KEK
    KeyWraping_AD((BYTE *)uarDerivedKey,
                  cPasswordSize,
                  (BYTE *)(void *)(&garTsb0[0][cEncryptedOriginalKekPtr]),
                  cSp800_38fEncryptedSize,
                  upKEK,
                  cSecurityApiBufferAddr);

    resetRam(uarDerivedKey, cPasswordSize, 0);
}

void modifyMeks(BYTE *upMEK)
{
    BYTE uarKEK[cKekSize];

    // Original
    restoreKek(uarKEK);
    KeyWraping_AE((BYTE *)uarKEK, cKekSize, upMEK, cMekSize, (BYTE *)&garTsb0[0][cEncryptedMekPtr], cSecurityApiBufferAddr);

    resetRam(uarKEK, cKekSize, 0);
}

void genMek()
{
    BYTE uarMEK[cMekSize];
    BYTE i;

    gatherSecurityPageInfo();

    Crypto_GenerateNDRBG(uarMEK, cMekSize);

    // Check AES Key1 != Key2
    if(SecIntf_MemoryCompare((LWORD)((BYTE *)&uarMEK[0]), (LWORD)((BYTE *)&uarMEK[32]), 32))
    {
        Crypto_GenerateNDRBG(uarMEK, cMekSize);

        if(SecIntf_MemoryCompare((LWORD)((BYTE *)&uarMEK[0]), (LWORD)((BYTE *)&uarMEK[32]), 32))
        {
            NLOG(cLogSecApiBaseFw, SECURITY_C, 0, "  GenMEK() failed, AES Key1 = Key2");
        }
    }

    rmAesNormalMode;
    rmFwAesNormalMode;

    for(i=0; i<cMekSize; i++)
    {
        rAesCtrl[rcAesDefaultKey00+i]=uarMEK[i];
        rFwAes[rcAesDefaultKey00+i]=uarMEK[i];
    }

    rmAesMode;
    rmFwAesMode;

    modifyMeks(uarMEK);

    progWproPageCore0(cWproSecurityId, c16Tsb0SIdx);
    updataSecurityKeyInfo();

    resetRam(uarMEK, cMekSize, 0);
}    /* genMek */

void loadAesDefaultKey()
{
    BYTE uCnt;
    BYTE uStatus;
    BYTE uarKEK[cKekSize];
    BYTE uarDecryptedMEK[cMekSize];

    gatherSecurityPageInfo();

    restoreKek(uarKEK);
    uStatus=KeyWraping_AD((BYTE *)uarKEK,
                          cKekSize,
                          (BYTE *)(void *)(&garTsb0[0][cEncryptedMekPtr]),
                          cSp800_38fEncryptedMekSize,
                          uarDecryptedMEK,
                          cSecurityApiBufferAddr);

    if(uStatus)    // Decrypt fail
    {
        gSecurityWProMode=1;
        resetRam(uarDecryptedMEK, cMekSize, 0);
        NLOG(cLogSecApiBaseFw, SECURITY_C, 0, "Decrypt MEK fails.");
    }

    rmAesNormalMode;
    rmFwAesNormalMode;

    for(uCnt=0; uCnt<cMekSize; uCnt++)
    {
        rAesCtrl[rcAesDefaultKey00+uCnt]=uarDecryptedMEK[uCnt];
        rFwAes[rcAesDefaultKey00+uCnt]=uarDecryptedMEK[uCnt];
    }

    rmAesMode;
    rmFwAesMode;

    resetRam(uarKEK, cKekSize, 0);
    resetRam(uarDecryptedMEK, cMekSize, 0);
}    /* loadAesDefaultKey */

void initAesDefaultKey(BYTE uLock)
{
    BYTE uLoadWproSecuritySuccess;

#if _ENABLE_SECAPI
    if(gbEnTCG||gbEnATAPassThrough)
    {
        if((!uLock)&&(rmEfuseChkProdFlag))
        {
            // destory AES Key when drive unlock
            destroyAesDefaultKey();
        }
    }
    else
#endif
    {
        // 1. Check if there is old info stored in Wpro
        uLoadWproSecuritySuccess=1;

        if(gsWproInfo.u16arWproIdxPagePtr[cWproSecurityId]!=c16BitFF)
        {
            readWproPageCore0(cWproSecurityId, c16Tsb0SIdx, 0);
        }
        else
        {
            bopClrRamForTsbCode(cTsb0Addr, gSectorPerPlaneH*512, 0, cClrTsb|cBopWait);
            uLoadWproSecuritySuccess=0;
        }

        updataSecurityKeyInfo();

        // 2. Generate MEK/KEK or load old key info according to the result of load Wpro
        if(uLoadWproSecuritySuccess==0)
        {
            if(!rmEfuseChkProdFlag)
            {
                genRootKey();
            }

            genKek();
            genMek();
        }
        else if(uLoadWproSecuritySuccess==1)
        {
            if((!uLock)&&(rmEfuseChkProdFlag))
            {
                // destory AES Key when drive unlock
                destroyAesDefaultKey();
            }
            else
            {
                loadAesDefaultKey();
            }
        }

        // else	 //C_WPRO_SECURITY_ID and C_WPRO_SECURITY_Backup_ID have ECC
        // {
        //	destroyAesDefaultKey();
        // }
    }
}    /* initAesDefaultKey */

void restoreAesKey()
{
#if _ENABLE_SECAPI
    if(gbEnTCG||gbEnATAPassThrough)
    {
        SecAPI_Crypto_RestoreAESHWInfo_Request();
    }
    else
#endif
    {
        loadAesDefaultKey();
    }
}

#if (!_ICE_DEBUG)
#pragma default_function_attributes =
#endif







