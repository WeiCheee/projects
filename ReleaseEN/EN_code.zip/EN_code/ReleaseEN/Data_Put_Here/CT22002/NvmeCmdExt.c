







#include "inc/DebugLog.h"
#include "inc/EventLogIDX.h"
#include "inc/EventLogFunctionIDX.h"
#include "inc/TypeDef.h"
#include "inc/Option.h"
#include "inc/ProType.h"
#include "inc/Reg.h"
#include "inc/NvmeCtrl.h"
#include "inc/table.h"
#include "inc/GlobVar0.h"
#include "inc/GlobVarS.h"
#include "inc/GlobVarT.h"
#include "inc/Mac.h"
#include "inc/GreyBox.h"
#include "inc/Asm.h"
#include "Common/Model.h"

#if (!_ICE_LOAD_ALL)
#pragma default_function_attributes = @ ".CORE0_NVME"
#include "NvmeCommonFunc.c"
#endif

#include "TaskFuncForPrj.c"
#include "GetLogPage.c"
#include "I2cCtrl.c"
#include "FwCommitDl.c"
#include "Sanitize.c"
#include "NvmeIoCmdExt.c"
#include "E2e.c"
#include "GcH2fTab.c"
#include "GcCacheB.c"
#if 1    // _ENABLE_SECAPI
#include "Ftl.c"
#include "H2fTab.c"
#include "TrimCmd.c"
#include "Read.c"
#include "Write.c"
#include "F2hTab.c"
#endif
CBYTE NewModel_FF[4][6] @ ".CORE0_NVME_CTABLE"=
{
    {'S', 'S', 'D', ' ', ' ', ' '},
    {'C', 'L', '1', '-', '3', 'D'},
    {'C', 'L', '1', '-', '4', 'D'},
    {'C', 'L', '1', '-', '8', 'D'},
};

CBYTE NewModel_LITEON[6] @ ".CORE0_NVME_CTABLE"=
{'L', 'I', 'T', 'E', 'O', 'N'};

CBYTE NewModel_size[16][4] @ ".CORE0_NVME_CTABLE"=
{
    {'1', '6', ' ', ' '},
    {'2', '4', ' ', ' '},
    {'3', '2', ' ', ' '},
    {'4', '8', ' ', ' '},
    {'6', '4', ' ', ' '},
    {'8', '0', ' ', ' '},
    {'9', '6', ' ', ' '},
    {'1', '1', '2', ' '},
    {'1', '2', '0', ' '},
    {'1', '2', '8', ' '},
    {'2', '4', '0', ' '},
    {'2', '5', '6', ' '},
    {'4', '8', '0', ' '},
    {'5', '1', '2', ' '},
    {'9', '6', '0', ' '},
    {'1', '0', '2', '4'}
};

#if FWX3FromCapacity
CBYTE FW_X3[16] @ ".CORE0_NVME_CTABLE"=
{
    {'4'},    // { '1','6',' ',' '},
    {'R'},    // { '2','4',' ',' '},
    {'5'},    // { '3','2',' ',' '},
    {'Q'},    // { '4','8',' ',' '},
    {'6'},    // { '6','4',' ',' '},
    {'H'},    // { '8','0',' ',' '},
    {'3'},    // { '9','6',' ',' '},
    {'2'},    // { '1','1','2',' '},
    {'J'},    // { '1','2','0',' '},
    {'7'},    // { '1','2','8',' '},
    {'M'},    // { '2','4','0',' '},
    {'8'},    // { '2','5','6',' '},
    {'N'},    // { '4','8','0',' '},
    {'9'},    // { '5','1','2',' '},
    {'W'},    // { '9','6','0',' '},
    {'A'},    // { '1','0','2','4'}
};
#endif/* if FWX3FromCapacity */

#if (OEM==LITEON_GC)
CBYTE NewModel_LiteonGC_FF[4][8] @ ".CORE0_NVME_CTABLE"=
{
    {'S', 'S', 'D', ' ', ' ', ' ', ' ', ' '},
    {'T', '1', '2', ' ', 'E', 'V', 'O', ' '},
    {'T', '1', '2', ' ', 'P', 'l', 'u', 's'},
    {'T', '1', '2', ' ', ' ', ' ', ' ', ' '},
};

#endif
BYTE GetCapacityIndex()
{
    BYTE u8capacityIndex;

    if(g32HostTotalDataSectorCnt<=0x1DD40B0)    // 16GB
    {
        u8capacityIndex=0;
    }
    else if(g32HostTotalDataSectorCnt<=0x2CBB7B0)    // 24GB
    {
        u8capacityIndex=1;
    }
    else if(g32HostTotalDataSectorCnt<=0x3BA2EB0)    // 32GB
    {
        u8capacityIndex=2;
    }
    else if(g32HostTotalDataSectorCnt<=0x5971CB0)    // 48GB
    {
        u8capacityIndex=3;
    }
    else if(g32HostTotalDataSectorCnt<=0x7740AB0)    // 64GB
    {
        u8capacityIndex=4;
    }
    else if(g32HostTotalDataSectorCnt<=0x950F8B0)    // 80GB
    {
        u8capacityIndex=5;
    }
    else if(g32HostTotalDataSectorCnt<=0xB2DE6B0)    // 96GB
    {
        u8capacityIndex=6;
    }
    else if(g32HostTotalDataSectorCnt<=0xD0AD4B0)    // 112GB
    {
        u8capacityIndex=7;
    }
    else if(g32HostTotalDataSectorCnt<=0xDF94BB0)    // 120GB
    {
        u8capacityIndex=8;
    }
    else if(g32HostTotalDataSectorCnt<=0xEE7C2B0)    // 128GB
    {
        u8capacityIndex=9;
    }
    else if(g32HostTotalDataSectorCnt<=0x1BF244B0)    // 240GB
    {
        u8capacityIndex=10;
    }
    else if(g32HostTotalDataSectorCnt<=0x1DCF32B0)    // 256GB
    {
        u8capacityIndex=11;
    }
    else if(g32HostTotalDataSectorCnt<=0x37E436B0)    // 480GB
    {
        u8capacityIndex=12;
    }
    else if(g32HostTotalDataSectorCnt<=0x3B9E12B0)    // 512GB
    {
        u8capacityIndex=13;
    }
    else if(g32HostTotalDataSectorCnt<=0x6FC81AB0)    // 960GB
    {
        u8capacityIndex=14;
    }
    else    // 1024GB
    {
        u8capacityIndex=15;
    }

    return u8capacityIndex;
}    /* GetCapacityIndex */

void GetModelName(BYTE *upModelName)
{
    BYTE u8Loop;

    BYTE u8capacityIndex;
    BYTE u8arModelNameTemp[40];
    BYTE u8FFTag;

    if((cbRevision1[0]=='C')&&(cbRevision1[1]=='R'))    // CL1-3Dxxx
    {
        u8FFTag=1;
    }
    else if((cbRevision1[0]=='C')&&(cbRevision1[1]=='S'))    // CL1-4Dxxx
    {
        u8FFTag=2;
    }
    else if(((cbRevision1[0]=='C')&&(cbRevision1[1]=='T'))||((cbRevision1[0]=='E')&&(cbRevision1[1]=='9')))    // CL1-8Dxxx
    {
        u8FFTag=3;
    }
    else
    {
        u8FFTag=0;
    }

// Check Capacity
    u8capacityIndex=GetCapacityIndex();

// -----Fill 0x20-----
    for(u8Loop=0; u8Loop<40; u8Loop++)
    {
        u8arModelNameTemp[u8Loop]=0x20;
    }

#if (OEM==DELL)
// 20181122_SamHu  EX.CL1-3D128-Q11 NVMe LITEON 128GB
// -----"CL1-3D"-----
    for(u8Loop=0; u8Loop<6; u8Loop++)
    {
        u8arModelNameTemp[u8Loop]=NewModel_FF[u8FFTag][u8Loop];
    }

// -----"128"-----
    for(u8Loop=0; u8Loop<4; u8Loop++)
    {
        u8arModelNameTemp[u8Loop+6]=NewModel_size[u8capacityIndex][u8Loop];
    }

// -----"-Q11"-----
    u8arModelNameTemp[9]='-';
    u8arModelNameTemp[10]='Q';
    u8arModelNameTemp[11]='1';
    u8arModelNameTemp[12]='1';

// -----"NVMe"-----
    u8arModelNameTemp[14]='N';
    u8arModelNameTemp[15]='V';
    u8arModelNameTemp[16]='M';
    u8arModelNameTemp[17]='e';

// -----"LITEON"-----
    for(u8Loop=0; u8Loop<6; u8Loop++)
    {
        u8arModelNameTemp[u8Loop+19]=NewModel_LITEON[u8Loop];
    }

// -----"128"-----
    for(u8Loop=0; u8Loop<4; u8Loop++)
    {
        u8arModelNameTemp[u8Loop+26]=NewModel_size[u8capacityIndex][u8Loop];
    }

// -----"GB"-----
    u8arModelNameTemp[29]='G';
    u8arModelNameTemp[30]='B';
#else/* if (OEM==DELL) */
// -----"LITEON"-----
    for(u8Loop=0; u8Loop<6; u8Loop++)
    {
        u8arModelNameTemp[u8Loop]=NewModel_LITEON[u8Loop];
    }

#if (OEM==LITEON_GC)
// -----"T12 EVO/Plus"-----

    for(u8Loop=0; u8Loop<8; u8Loop++)
    {
        u8arModelNameTemp[u8Loop+7]=NewModel_LiteonGC_FF[u8FFTag][u8Loop];
    }

// -----"128"-----
    if(u8FFTag==1)
    {
        for(u8Loop=0; u8Loop<4; u8Loop++)
        {
            u8arModelNameTemp[u8Loop+15]=NewModel_size[u8capacityIndex][u8Loop];
        }
    }
    else if(u8FFTag==2)
    {
        for(u8Loop=0; u8Loop<4; u8Loop++)
        {
            u8arModelNameTemp[u8Loop+16]=NewModel_size[u8capacityIndex][u8Loop];
        }
    }
    else if(u8FFTag==3)
    {
        for(u8Loop=0; u8Loop<4; u8Loop++)
        {
            u8arModelNameTemp[u8Loop+11]=NewModel_size[u8capacityIndex][u8Loop];
        }
    }
#else/* if (OEM==LITEON_GC) */
// -----"CL1-3D"-----
    for(u8Loop=0; u8Loop<6; u8Loop++)
    {
        u8arModelNameTemp[u8Loop+7]=NewModel_FF[u8FFTag][u8Loop];
    }

// -----"128"-----
    for(u8Loop=0; u8Loop<4; u8Loop++)
    {
        u8arModelNameTemp[u8Loop+13]=NewModel_size[u8capacityIndex][u8Loop];
    }
#endif/* if (OEM==LITEON_GC) */

#if (OEM==HP)
    // -----"-HP"-----
    u8arModelNameTemp[16]='-';
    u8arModelNameTemp[17]='H';
    u8arModelNameTemp[18]='P';
#endif
#endif/* if (OEM==DELL) */
    copyCcmVal(upModelName, u8arModelNameTemp, 40);
}    /* GetModelName */

void setNvmeCreateDeleteQueue(void)
{
    rmSetUnexCmdDw0(rmNvmeOpCode);
    rmSetUnexCmdDw10(rmNvmeCreateqCmd10);
    rmSetUnexCmdDw11(rmNvmeCreateqCmd11);
    rmSetUnexCmdPrp1L(rmNvmePrp1Low);
    rmSetUnexCmdPrp1H(rmNvmePrp1High);
    rmSetCreateSqCq;
}

// Nvme Get Feature by passing struct
LWORD nvmeGetFeatureAttribute(NVMEFEATURESEL *upFeatureId, BYTE uSEL)
{
    LWORD u32DWord0=0;

    switch(uSEL)
    {
        case cNvmeGetFeatSelCurrent:
            u32DWord0=upFeatureId->u32Current;
            break;

        case cNvmeGetFeatSelDefault:
            u32DWord0=upFeatureId->u32Default;
            break;

        case cNvmeGetFeatSelSaved:
#if _ENABLE_NVME_LS
            if((gsLightSwitch.usNvmeLs.uOncs&cSaveFieldAndTheSelectField)&&(upFeatureId->u32Saved!=cNvmeFeatSavedInvalid))
            {
                u32DWord0=upFeatureId->u32Saved;
            }
            else
#endif
            {
                u32DWord0=upFeatureId->u32Default;
            }

            break;

        case cNvmeGetFeatSelSc:
            u32DWord0=upFeatureId->u32SelSC;
            break;

        default:
            break;
    }    /* switch */

    return u32DWord0;
}    /* nvmeGetFeatureAttribute */

// Nvme Set Feature by passing struct
WORD nvmeSetFeatureAttribute(NVMEFEATURESEL *upFeatureId, LWORD u32FeatureValue, BYTE uSaved)
{
    LWORD u32NsId=rmNvmeNsId;
    WORD u16StatusCode=cStatusSuccess;

#ifdef _SUPPORT_FEATURE_DITM
#if (OEM==LENOVO)    // 20190108_SamHu_01 follow Lenovo Spec1.26 ignore the NSID
    if(rmNvmeFid==cNvmeFeatHdDITM)
    {}
    else
#endif
#endif

    if((!(upFeatureId->u32SelSC&cNamespaceSpecific))&&(u32NsId!=cNamespaceAll)&&(u32NsId!=cNamespaceNotSpecific))
    {
        u16StatusCode=cStatusFeatureNotNsSpecific;
    }

    if(uSaved)
    {
        if(upFeatureId->u32SelSC&cSaveable)
        {
            upFeatureId->u32Saved=u32FeatureValue;
            upFeatureId->u32Current=u32FeatureValue;
            // u16StatusCode=cStatusSuccess;
        }
        else
        {
            u16StatusCode=cStatusFeatureIdUnSavable;
        }
    }
    else
    {
        if(upFeatureId->u32SelSC&cChangeable)
        {
            upFeatureId->u32Current=u32FeatureValue;
            // u16StatusCode=cStatusSuccess;
        }
        else
        {
            u16StatusCode=cStatusFeatureUnChangable;
        }
    }

    return u16StatusCode;
}    /* nvmeSetFeatureAttribute */

WORD handleFeatApst()
{
    LWORD u32Cnt, u32Itpt, u32MaxApstSize;
    WORD u16StatusCode=cStatusSuccess;
    BYTE uItps;

    u32MaxApstSize=sizeof(APSTTABLE)*gsLightSwitch.usNvmeLs.uNpss;

    if(rmNvmeApstEn)    // for apst enable 20181225_SamHu_sync SMI momo release FW
    {
        // Check valid
        for(u32Cnt=0; u32Cnt<gsLightSwitch.usNvmeLs.uNpss; u32Cnt++)
        {
            uItps=(BYTE)((g32arTsb0[0][u32Cnt*2]>>3)&0x0000001F);    // power state
            u32Itpt=((g32arTsb0[0][u32Cnt*2]>>8)&0x00FFFFFF);    // idle time
            NLOG(cLogHost,
                 NVMECMDEXT_C,
                 4,
                 "  APST Entery :0x%04X, Power State: 0x%04X,  Idle Time: 0x%08X",
                 u32Cnt,
                 uItps,
                 u32Itpt>>16,
                 u32Itpt);

            if(uItps>gsLightSwitch.usNvmeLs.uNpss)
            {
                // Trans state can't exceed supported power state (PS4)
                u16StatusCode=cStatusInvalidField;
                return u16StatusCode;
            }
            else if(u32Itpt&&(uItps<cPs3))
            {
                // Trans state must be non-operational power state (PS3 or PS4)
                u16StatusCode=cStatusInvalidField;
                return u16StatusCode;
            }
        }
    }

    if(rmNvmeSv)
    {
        if(gpNvmeFeatVar->usFeat.usAutoPst.u32SelSC&cSaveable)
        {
            g32ApstEnable=rmNvmeApstEn;
            gpNvmeFeatVar->usFeat.usAutoPst.u32Saved=rmNvmeApstEn;
            gpNvmeFeatVar->usFeat.usAutoPst.u32Current=rmNvmeApstEn;
            // gpNvmeFeatVar->usFeat.usAutoPst.u32SelSC|=c32Bit31;

            if(rmNvmeApstEn)    // For apst enable update 20181225_SamHu_sync SMI momo release FW
            {
                bopCopyRam((LWORD)&garApstCurrent, (c32Tsb0SAddr), u32MaxApstSize, cCopyTsb2Dccm|cBopWait);
                bopCopyRam((LWORD)&gpNvmeFeatVar->usApstEntry.uarCurrent, (c32Tsb0SAddr), u32MaxApstSize, cCopyTsb2Tsb|cBopWait);
                bopCopyRam((LWORD)&gpNvmeFeatVar->usApstEntry.uarSaved, (c32Tsb0SAddr), u32MaxApstSize, cCopyTsb2Tsb|cBopWait);
            }
        }
        else
        {
            u16StatusCode=cStatusFeatureIdUnSavable;
        }
    }
    else
    {
        if(gpNvmeFeatVar->usFeat.usAutoPst.u32SelSC&cChangeable)
        {
            g32ApstEnable=rmNvmeApstEn;
            gpNvmeFeatVar->usFeat.usAutoPst.u32Current=rmNvmeApstEn;

            if(rmNvmeApstEn)    // For apst enable update 20181225_SamHu_sync SMI momo release FW
            {
                bopCopyRam((LWORD)&garApstCurrent, (c32Tsb0SAddr), u32MaxApstSize, cCopyTsb2Dccm|cBopWait);
                bopCopyRam((LWORD)&gpNvmeFeatVar->usApstEntry.uarCurrent, (c32Tsb0SAddr), u32MaxApstSize, cCopyTsb2Tsb|cBopWait);
            }
        }
        else
        {
            u16StatusCode=cStatusFeatureUnChangable;
        }
    }

    return u16StatusCode;
}    /* handleFeatApst */

WORD handleFeatLbaRangeType(LWORD u32NsId)
{
    LWORD u32SLba1, u32SLba2, u32Nlb1, u32Nlb2;
    WORD u16StatusCode=nvmeSetFeatureAttribute((NVMEFEATURESEL *)&gpNvmeFeatVar->usFeat.usLbaRangeType[u32NsId],
                                               rmNvmeLbaRangeNumDw,
                                               rmNvmeSv);
    BYTE uNumOfEntry, uEntry1, uEntry2;

    if(u16StatusCode==cStatusSuccess)
    {
        trigNonRWCmd(cTsb0StartBufIdx, 0x08, cTsb0, cNvmeWrite, cManualCq);    // Trigger host, start receiving new table from host
        uNumOfEntry=rmNvmeLbaRangeNumDw;

        // Verify if LBA range overlaps
        for(uEntry1=0; uEntry1<uNumOfEntry; uEntry1++)
        {
            for(uEntry2=0; uEntry2<uNumOfEntry; uEntry2++)
            {
                if(uEntry1!=uEntry2)
                {
                    u32SLba1=*(&g32arTsb0[0][0]+((uEntry1*cLbaRangeEntrySize)+cLbaRangeSlbaOffset));
                    u32Nlb1=*(&g32arTsb0[0][0]+((uEntry1*cLbaRangeEntrySize)+cLbaRangeNlbOffset));

                    u32SLba2=*(&g32arTsb0[0][0]+((uEntry2*cLbaRangeEntrySize)+cLbaRangeSlbaOffset));
                    u32Nlb2=*(&g32arTsb0[0][0]+((uEntry2*cLbaRangeEntrySize)+cLbaRangeNlbOffset));

                    if(((u32SLba1>=u32SLba2)&&(u32SLba1<=(u32SLba2+u32Nlb2)))||
                       (((u32SLba1+u32Nlb1)>=u32SLba2)&&((u32SLba1+u32Nlb1)<=(u32SLba2+u32Nlb2))))
                    {
                        u16StatusCode=cStatusOverlappingRange;
                    }
                }
            }
        }

        if(u16StatusCode==cStatusSuccess)
        {
            bopClrRam((LWORD)&gpNvmeFeatVar->usLbaRangeTypeEntry[u32NsId],
                      sizeof(LBARANGETYPE),
                      0x00000000,
                      cBopWait|cClrTsb);
            bopCopyRam((LWORD)&gpNvmeFeatVar->usLbaRangeTypeEntry[u32NsId],
                       (c32Tsb0SAddr),
                       (uNumOfEntry*64),
                       cCopyTsb2Tsb|cBopWait);
        }
    }

    return u16StatusCode;
}    /* handleFeatLbaRangeType */

WORD handleFeatWriteAtomic(LWORD u32NsId)
{
    WORD u16StatusCode=nvmeSetFeatureAttribute((NVMEFEATURESEL *)&gpNvmeFeatVar->usFeat.usWriteAtomicityNormal[u32NsId],
                                               rmNvmeCmdDw11,
                                               rmNvmeSv);

    if(u16StatusCode==cStatusSuccess)
    {
        // TODO: FW behavior, what if don't support atomic operation?
    }

    return u16StatusCode;
}

WORD handleFeatErrorRecovery(LWORD u32NsId)
{
    WORD u16StatusCode=cStatusSuccess;

    // if(rmNvmeErrRecoveryDulbe)
    // {
    //    u16StatusCode=cStatusInvalidField;    // idenify  namespace data NsFeat=0x00
    // }
    // else
    {
        u16StatusCode=nvmeSetFeatureAttribute((NVMEFEATURESEL *)&gpNvmeFeatVar->usFeat.usErrorRecovery[u32NsId],
                                              rmNvmeCmdDw11,
                                              rmNvmeSv);

        if(u16StatusCode==cStatusSuccess)
        {
            if(rmNvmeErrRecoveryDulbe)
            {
                gsNamespace.uDulbeBitMap|=cbBitTab[u32NsId];
            }
            else
            {
                gsNamespace.uDulbeBitMap&=~cbBitTab[u32NsId];
            }

            if(rmNvmeErrRecoveryTler)
            {
                // Todo: Use the setting here for error recovery timeout
            }
        }
    }

    return u16StatusCode;
}    /* handleFeatErrorRecovery */

LWORD chkHctmValid(WORD u16Tmt1, WORD u16Tmt2)
{
    LWORD u32Valid=0;

    if(!(u16Tmt1)||((u16Tmt1>=gsLightSwitch.usNvmeLs.u16MnTmt)&&(u16Tmt1<=gsLightSwitch.usNvmeLs.u16MxTmt)))
    {
        if(!(u16Tmt2)||((u16Tmt2>=gsLightSwitch.usNvmeLs.u16MnTmt)&&(u16Tmt2<=gsLightSwitch.usNvmeLs.u16MxTmt)))
        {
            u32Valid=1;

            // if both MT1 and MT2 is non-zero, MT1 cann't be bigger or equal than MT2
            if(u16Tmt2&&u16Tmt1&&(u16Tmt1>=u16Tmt2))
            {
// #ifdef _SUPPORT_FEATURE_DITM    // 20181010_Jesse_01, Add for LENOVO "NVMe spec 1.26" DITT function
// #if (OEM==LENOVO)    // 20190313_Jesse_01, Add for LENOVO "NVMe spec 1.26" "Feature 0x10" == "Feature 0xD4(DITT)
//                if(u16Tmt1>u16Tmt2)    // 20190417_Jesse_02, Follow CA3 remove "Lenovo DITT "=" is Valid"
// #endif
// #endif
                u32Valid=0;
            }
        }
    }

    return u32Valid;
}    /* chkHctmValid */

void nvmeDeleteSubQueue()
{
    NLOG(cLogHost, NVMECMDEXT_C, 1, "  Delete I/O Submission Queue: QID=0x%04X ", (WORD)rmNvmeDeleteqQid);

    if(rmNvmeNsId!=cNamespaceNotSpecific)
    {
        manualCompletion(cStatusInvalidField, 0, cNoRwCmd, 0);
    }
    else if((rmNvmeDeleteqQid==0)||(rmNvmeDeleteqQid>cMaxIoSqCqCnt)||!(g16ValidSqBitmap&cb16BitTab[rmNvmeDeleteqQid-1]))
    {
        manualCompletion(cStatusInvalidQid, 0, cDeleteQCmd, 0);
        rmPopNextCmd;
    }
    else
    {
        g16ValidSqBitmap&=(~cb16BitTab[rmNvmeDeleteqQid-1]);
        setNvmeCreateDeleteQueue();
        manualCompletion(cStatusSuccess, rmNvmeDeleteqQid, cDeleteQCmd, 0x0);
        rmPopNextCmd;
    }
}    /* nvmeDeleteSubQueue */

void nvmeCreateSubQueue()
{
    NLOG(cLogHost,
         NVMECMDEXT_C,
         4,
         "  Create I/O Submission Queue: QSIZE=0x%04X, QID=0x%04X, CQID=0x%04X, QPRIO=0x%02X, PC=0x%02X",
         (WORD)rmNvmeCreateqQsize,
         (WORD)rmNvmeCreateqQid,
         (WORD)rmNvmeCreateqCqid,
         (WORD)(rmNvmeCreateqQprio<<8|rmNvmeCreateqPc));

    if(rmNvmeNsId!=cNamespaceNotSpecific)
    {
        manualCompletion(cStatusInvalidField, 0, cNoRwCmd, 0);
    }
    else if((!rmNvmeCreateqPc)||rmNvmeSgl)
    {
        manualCompletion(cStatusInvalidField, 0, cNoRwCmd, 0);
    }
    else if(validatePrp(cValidPrpCreateQueue))
    {
        manualCompletion(cStatusInvalidPrpOffset, 0, cNoRwCmd, 0);
    }
    else if((rmNvmeCreateqQid==0)||(rmNvmeCreateqQid>cMaxIoSqCqCnt)||(g16ValidSqBitmap&cb16BitTab[rmNvmeCreateqQid-1])    // tnvme, 5:5.10.0
            ||(rmNvmeCreateqCqid==0)    /*||(rmNvmeCreateqCqid>cMaxIoSqCqCnt)*/)
    {
        manualCompletion(cStatusInvalidQid, 0, cNoRwCmd, 0);
    }
    else if(    /*(rmNvmeCreateqCqid==0)||*/ (rmNvmeCreateqCqid>cMaxIoSqCqCnt))    // tnvme, 17:0.3.0
    {
        manualCompletion(cStatusInvalidCq, 0, cNoRwCmd, 0);
    }
    else if(rmNvmeCreateqCqid&&(rmNvmeCreateqCqid<=cMaxIoSqCqCnt)&&(!(g16ValidCqBitmap&cb16BitTab[rmNvmeCreateqCqid-1])))    // tnvme, 5:5.10.0
    {
        manualCompletion(cStatusInvalidCq, 0, cNoRwCmd, 0);    // Create CQ msut before create SQ
    }
    else if((rmNvmeCreateqQsize==0)||(rmNvmeCreateqQsize>(gsLightSwitch.usNvmeLs.usControllerCapLo.u32All&0x0000FFFF)))    // MaximumQueueEntriesSupported
    {
        manualCompletion(cStatusMaxQueExceeded, 0, cNoRwCmd, 0);
    }
    else
    {
        g16ValidSqBitmap|=cb16BitTab[rmNvmeCreateqQid-1];
        g16Cq2SqidBitmap[rmNvmeCreateqCqid-1]|=cb16BitTab[rmNvmeCreateqQid-1];
        setNvmeCreateDeleteQueue();
        manualCompletion(cStatusSuccess, 0, cNoRwCmd, 0);    // manual send completion, and pop next cmd
    }
}    /* nvmeCreateSubQueue */

void nvmeDeleteCmplQueue()
{
    NLOG(cLogHost, NVMECMDEXT_C, 1, "  Delete I/O Completion Queue: QID=0x%04X ", (WORD)rmNvmeDeleteqQid);

    if(rmNvmeNsId!=cNamespaceNotSpecific)
    {
        manualCompletion(cStatusInvalidField, 0, cNoRwCmd, 0);
    }
    else if((rmNvmeDeleteqQid==0)||(rmNvmeDeleteqQid>cMaxIoSqCqCnt)||!(g16ValidCqBitmap&cb16BitTab[rmNvmeDeleteqQid-1]))
    {
        manualCompletion(cStatusInvalidQid, 0, cNoRwCmd, 0);
    }
    else if(g16Cq2SqidBitmap[rmNvmeDeleteqQid-1]&g16ValidSqBitmap)
    {
        manualCompletion(cStatusInvalidQueDeletion, 0, cNoRwCmd, 0);    // Delete SQ must before delete CQ
    }
    else
    {
        g16ValidCqBitmap&=(~cb16BitTab[rmNvmeDeleteqQid-1]);
        g16Cq2SqidBitmap[rmNvmeDeleteqQid-1]=0;
        setNvmeCreateDeleteQueue();
        manualCompletion(cStatusSuccess, rmNvmeDeleteqQid, cNoRwCmd, 0x0);
    }
}    /* nvmeDeleteCmplQueue */

void nvmeCreateCmplQueue()
{
    NLOG(cLogHost,
         NVMECMDEXT_C,
         4,
         "  Create I/O Completion Queue: QSIZE=0x%04X, QID=0x%04X, IV=0x%04X, IEN=0x%02X, PC=0x%02X",
         (WORD)rmNvmeCreateqQsize,
         (WORD)rmNvmeCreateqQid,
         (WORD)rmNvmeCreateqQiv,
         (WORD)(rmNvmeCreateqIen<<8|rmNvmeCreateqPc));

    if(rmNvmeNsId!=cNamespaceNotSpecific)
    {
        manualCompletion(cStatusInvalidField, 0, cNoRwCmd, 0);
    }
    else if((!rmNvmeCreateqPc)||rmNvmeSgl)
    {
        manualCompletion(cStatusInvalidField, 0, cNoRwCmd, 0);
    }
    else if(validatePrp(cValidPrpCreateQueue))
    {
        manualCompletion(cStatusInvalidPrpOffset, 0, cNoRwCmd, 0);
    }
    else if((rmNvmeCreateqQid==0)||(rmNvmeCreateqQid>cMaxIoSqCqCnt)||(g16ValidCqBitmap&cb16BitTab[rmNvmeCreateqQid-1]))
    {
        manualCompletion(cStatusInvalidQid, 0, cNoRwCmd, 0);
    }
    else if((rmNvmeCreateqQsize==0)||(rmNvmeCreateqQsize>(gsLightSwitch.usNvmeLs.usControllerCapLo.u32All&0x0000FFFF)))    // MaximumQueueEntriesSupported
    {
        manualCompletion(cStatusMaxQueExceeded, 0, cNoRwCmd, 0);
    }
    else if(rmNvmeCreateqIen&&(rmNvmeCreateqQiv>(gsLightSwitch.usPcieLs.usMessageCtrlLs.u16All&0x07FF)))    // TableSize
    {
        manualCompletion(cStatusInvalidIntVector, 0, cNoRwCmd, 0);
    }
    else
    {
        g16ValidCqBitmap|=cb16BitTab[rmNvmeCreateqQid-1];
        setNvmeCreateDeleteQueue();
        manualCompletion(cStatusSuccess, 0, cNoRwCmd, 0);    // manual send completion, and pop next cmd
    }
}    /* nvmeCreateCmplQueue */

void nvmeIdentify()
{
    IDCONTROLLERDATA *upIdCtrlData;
    IDNAMESPACEDATA *upIdSpaceData;
    IDNSIDENFICATIONDESC *upIdIdentificationDesc;
    IDCONTROLLERLISTDATA *upIdContorllerList;
    LWORD u32NsId=rmNvmeNsId;
    WORD u16Cntid=rmNvmeCntid, u16StatusCode=cStatusSuccess;
    BYTE uCns=rmNvmeCns, uXferCnt=0, uChkNsId=0, uChkTsbIdx=0, uChkNid, uNidt, uNidl=0, uarNid[16], uBitMap;
    BYTE uPSDT;
    BYTE uarFwVersion[8];
    BYTE uCount;
    BYTE u8arModelNameTemp[40];
    BYTE u8capacityIndex;

#if FWX3FromCapacity
    BYTE u8capacityIndex;
#endif

    NLOG(cLogHost, NVMECMDEXT_C, 2, "  Identify: CNTID=0x%04X, CNS=0x%04X ", (WORD)rmNvmeCntid, (WORD)rmNvmeCns);

    bopClrRam((LWORD)(BYTE *)&g32arTsb0[0], 4096, 0x00000000, cBopWait|cClrTsb);

#if (_EN_CHRONUS_UART_DEBUG)
    if(mChkUartCMDRdy)
    {
        u32NsId=gpUartCMD->NSID;
        u16Cntid=gpUartCMD->DW10>>16;
        uCns=gpUartCMD->DW10&0xFF;
        uPSDT=gpUartCMD->DW0B1&0xC0;
    }
    else
#endif
    {
        uPSDT=rmNvmeSgl;
    }

    switch(uCns)
    {
        case cNvmeIdenActiveNsData:
        case cNvmeIdenAllocatedNsdata:

            if((!(gsLightSwitch.usNvmeLs.usIgnoreNsId.uAll&cIgnoreInIdNamespace))&&
               (!((uCns==cNvmeIdenActiveNsData)&&(u32NsId==cNamespaceAll)))&&
               ((u32NsId>gsLightSwitch.usNvme2Ls.u32NamespaceNum)||(u32NsId==cNamespaceNotSpecific)))
            {
                // if(u32NsId==cNamespaceAll)
                // {
                //    u16StatusCode=cStatusInvalidField;    // CSSD-2900, CSSD-2198
                // }
                // else
                {
                    u16StatusCode=cStatusInvalidNsFormat;    // CSSD-2900, CSSD-2198
                }
            }
            else
            {
                if(uCns==cNvmeIdenActiveNsIds)
                {
                    uBitMap=gsNamespace.uActiveBitMap;
                }
                else
                {
                    uBitMap=gsNamespace.uAllocatedBitMap;
                }

                if((uCns==cNvmeIdenActiveNsData)&&(u32NsId==cNamespaceAll))    // 20190104_SamHu_01 DM
                {
                    if(gsLightSwitch.usNvmeLs.uFeatOption&cEnableNamespace)
                    {
                        upIdSpaceData=(void *)&g32arTsb0[0];

                        upIdSpaceData->u32NszeL=0;    // logic range host can access
                        upIdSpaceData->u32NcapL=0;
                        upIdSpaceData->u32NuseL=0;
                        // upIdSpaceData->uNsFeat= 0x00;
                        // upIdSpaceData->uNlbaf= 0x00;
                        // upIdSpaceData->uFlbas= 0x00;
                        // upIdSpaceData->uMc= 0x00;
                        // upIdSpaceData->uFpi=0x00;    // Bit7=0, not support FPI
                        upIdSpaceData->uDlfeat=0x01;

                        // IdPtr1->u16Nawun=0x0;// Lareina: 0h indicates the size for this nampspace is the same size as AWUN of Identify
                        // Controller
                        // IdPtr1->u16Nawupf=0x0;// Lareina: 0h indicates the size for this nampspace is the same size as AWUPF of Identify
                        // Controller
                        // IdPtr1->u16Nacwu=0x0;// Lareina: 0h indicates the size for this nampspace is the same size as ACWU of Identify
                        // Controller
                        copyCcmVal(upIdSpaceData->uarNguid, gsLightSwitch.usNvmeLs.uarNguid, 16);
                        copyCcmVal(upIdSpaceData->uarEui64, gsMPInfo.uarEui64, 8);

                        // upIdSpaceData->uarLbaF[0].u16Ms= 0x00;
                        upIdSpaceData->uarLbaF[0].uLbaDs=0x09;
                        // upIdSpaceData->uarLbaF[0].uRp= 0x00;
                    }
                    else
                    {
                        u16StatusCode=cStatusInvalidNsFormat;
                    }
                }
                else if(uBitMap&cbBitTab[u32NsId-1])
                {
                    upIdSpaceData=(void *)&g32arTsb0[0];

                    upIdSpaceData->u32NszeL=gsNamespace.usInfo[u32NsId-1].u32Size;    // logic range host can access
                    upIdSpaceData->u32NcapL=gsNamespace.usInfo[u32NsId-1].u32Size;
                    upIdSpaceData->u32NuseL=gsNamespace.usInfo[u32NsId-1].u32Size;
                    // upIdSpaceData->uNsFeat= 0x00;
                    // upIdSpaceData->uNlbaf= 0x00;
                    // upIdSpaceData->uFlbas= 0x00;
                    // upIdSpaceData->uMc= 0x00;
                    // upIdSpaceData->uFpi=0x00;    // Bit7=0, not support FPI
                    upIdSpaceData->uDlfeat=0x01;

                    upIdSpaceData->u64arNvmCap[0]=((QWORD)gsNamespace.usInfo[u32NsId-1].u32Size<<9);

                    // IdPtr1->u16Nawun=0x0;// Lareina: 0h indicates the size for this nampspace is the same size as AWUN of Identify Controller
                    // IdPtr1->u16Nawupf=0x0;// Lareina: 0h indicates the size for this nampspace is the same size as AWUPF of Identify
                    // Controller
                    // IdPtr1->u16Nacwu=0x0;// Lareina: 0h indicates the size for this nampspace is the same size as ACWU of Identify Controller
                    copyCcmVal(upIdSpaceData->uarNguid, gsLightSwitch.usNvmeLs.uarNguid, 16);
                    copyCcmVal(upIdSpaceData->uarEui64, gsMPInfo.uarEui64, 8);

                    // upIdSpaceData->uarLbaF[0].u16Ms= 0x00;
                    upIdSpaceData->uarLbaF[0].uLbaDs=0x09;
                    // upIdSpaceData->uarLbaF[0].uRp= 0x00;
                }

                // else
                // {
                //    u16StatusCode=cStatusInvalidNsFormat;  //Should return zero data in this case
                // }

                uXferCnt=8;
            }

            break;

        case cNvmeIdenControllerData:

            if(    /*(!(gsLightSwitch.usNvmeLs.usIgnoreNsId.uAll&cIgnoreInIdController))&&*/ u32NsId)    // CSSD-2069
            {
                u16StatusCode=cStatusInvalidNsFormat;    // CSSD-2198
            }
            else
            {
                uXferCnt=8;
                upIdCtrlData=(void *)&g32arTsb0[0];

                // ====Controller Capabilities and Features
#if _ENABLE_NVME_LS
                upIdCtrlData->u16Vid=gsLightSwitch.usNvmeLs.u16Vid;
                upIdCtrlData->u16Ssvid=gsLightSwitch.usNvmeLs.u16Ssvid;
#else
                upIdCtrlData->u16Vid=0x14A4;
                upIdCtrlData->u16Ssvid=0x8086;
#endif

#if _ENABLE_CID_LS
                copyCcmVal(upIdCtrlData->uarSn, gsMPInfo.uarSerialNum, 20);

                for(uCount=0; uCount<20; uCount++)    // 20190131_SamHu_01 prevent not ASCII case
                {
                    if(upIdCtrlData->uarSn[uCount]==0x0)
                    {
                        upIdCtrlData->uarSn[uCount]=0x20;
                    }
                }

                // copyCcmVal(upIdCtrlData->uarMn, gsLightSwitch.usCidHeader.uarModelNum, 40);
                // copyCcmVal(upIdCtrlData->uarFr, gsLightSwitch.usCidHeader.uarIspRev, 8);

                // Model Name
                GetModelName(u8arModelNameTemp);
                copyCcmVal(upIdCtrlData->uarMn, (BYTE *)u8arModelNameTemp, 40);

                // FW version
                for(uCount=0; uCount<8; uCount++)
                {
                    uarFwVersion[uCount]=cbRevision2[uCount];
                }

#if FWX3FromCapacity
                u8capacityIndex=GetCapacityIndex();
                uarFwVersion[2]=FW_X3[u8capacityIndex];
#endif
                copyCcmVal(upIdCtrlData->uarFr, (BYTE *)uarFwVersion, 8);
#else/* if _ENABLE_CID_LS */
                upIdCtrlData->uarSn[0]=0x38;
                upIdCtrlData->uarSn[1]=0x38;
                upIdCtrlData->uarSn[2]=0x32;
                upIdCtrlData->uarSn[3]=0x35;
                upIdCtrlData->uarSn[4]=0x32;
                upIdCtrlData->uarSn[5]=0x35;
                upIdCtrlData->uarSn[6]=0x32;

                upIdCtrlData->uarMn[0]=0x53;
                upIdCtrlData->uarMn[1]=0x4D;
                upIdCtrlData->uarMn[2]=0x32;
                upIdCtrlData->uarMn[3]=0x32;
                upIdCtrlData->uarMn[4]=0x36;
                upIdCtrlData->uarMn[5]=0x30;
                upIdCtrlData->uarMn[6]=0x44;
                upIdCtrlData->uarMn[7]=0x72;
                upIdCtrlData->uarMn[8]=0x61;
                upIdCtrlData->uarMn[9]=0x6D;
                upIdCtrlData->uarMn[10]=0x4C;
                upIdCtrlData->uarMn[11]=0x65;
                upIdCtrlData->uarMn[12]=0x73;
                upIdCtrlData->uarMn[13]=0x73;

                upIdCtrlData->uarFr[0]=0x47;
                upIdCtrlData->uarFr[1]=0x49;
                upIdCtrlData->uarFr[2]=0x54;
                upIdCtrlData->uarFr[3]=0x30;
                upIdCtrlData->uarFr[4]=0x39;
                upIdCtrlData->uarFr[5]=0x34;
                upIdCtrlData->uarFr[6]=0x35;
                upIdCtrlData->uarFr[7]=0x33;
#endif/* if _ENABLE_CID_LS */

#if _ENABLE_NVME_LS
                upIdCtrlData->uRab=gsLightSwitch.usNvmeLs.uRab;
#else
                upIdCtrlData->uRab=0x06;
#endif

#if _ENABLE_NVME_LS
                copyCcmVal(upIdCtrlData->uarIeee, gsMPInfo.uarIeee, 3);
#else
                upIdCtrlData->uarIeee[0]=0x03;
                upIdCtrlData->uarIeee[1]=0x23;
                upIdCtrlData->uarIeee[2]=0x00;
#endif

                // upIdCtrlData->uCmic= 0x00;
#if _ENABLE_NVME_LS
                upIdCtrlData->uMdts=gsLightSwitch.usNvmeLs.uMdts;    // Maximum Data Transfer Size 128KB
#else
                upIdCtrlData->uMdts=0x05;    // Maximum Data Transfer Size 128KB
#endif
                upIdCtrlData->u16CtrlId=cControllerCurrId;
#if _ENABLE_NVME_LS
                upIdCtrlData->u32Ver=gsLightSwitch.usNvmeLs.u32Ver;    // V1.20
                upIdCtrlData->u32Rtd3R=gsLightSwitch.usNvmeLs.u32Rtd3R;    // 150ms
                upIdCtrlData->u32Rtd3E=gsLightSwitch.usNvmeLs.u32Rtd3E;    // 80ms
#else
                upIdCtrlData->u32Ver=0x00010200;    // V1.20
                upIdCtrlData->u32Rtd3R=0x000249F0;    // 150ms
                upIdCtrlData->u32Rtd3E=0x00013880;    // 80ms
#endif
                upIdCtrlData->u32Oaes=0x00000200;
#if _ENABLE_NVME_FEAT_NONOPPWRSTATE
                upIdCtrlData->u32Ctratt|=c32Bit1;
#endif
                // ====Admin Command Set Attributes & Optional Controller Capabilities
                // upIdCtrlData->u16OACS      = ((gparLS_Nvme->u16OACS.SecuritySendandSecurityReceiveCMD)|
                // (gparLS_Nvme->u16OACS.FormatNVMcommand<<1)|
                // (gparLS_Nvme->u16OACS.FWCommitandImageDownloadCMD<<2));
#if _ENABLE_NVME_LS
                upIdCtrlData->u16Oacs=gsLightSwitch.usNvmeLs.u16Oacs;
#if (_ENABLE_SECAPI)
                if(gbEnTCG||gbEnATAPassThrough||gbEnRpmb)
                {
                    upIdCtrlData->u16Oacs|=cSecuritySendReceiveCmd;
                }

#if 0    // [D.H]For Liteon IF_003
                if(gbEnTCG&&(gTcgNviSpLockingLifeCycleState==C_Manufactured))
                {
                    upIdCtrlData->u16Oacs&=(~c16Bit1);    // Don't support format NVM when security feature enabled
                }
#endif
#endif
                upIdCtrlData->uAcl=gsLightSwitch.usNvmeLs.uAcl;
                upIdCtrlData->uAerl=gsLightSwitch.usNvmeLs.uAerl;
                // upIdCtrlData->uFRMW       = ((gparLS_Nvme->uFRMW.NumberOfFirmwareSlots<<1)|
                // (gparLS_Nvme->uFRMW.FirmwareActivationWithoutReset<<4));
                upIdCtrlData->uFrmw=gsLightSwitch.usNvmeLs.usFrmw;
#if _ENABLE_TELEINITLOG    // 20181225_SamHu_02
                upIdCtrlData->uLpa=(gsLightSwitch.usNvmeLs.uLpa|cBit3);
#else
                upIdCtrlData->uLpa=(gsLightSwitch.usNvmeLs.uLpa&(~cBit3));
#endif
                upIdCtrlData->uElpe=gsLightSwitch.usNvmeLs.uElpe;
                upIdCtrlData->uNpss=gsLightSwitch.usNvmeLs.uNpss;
                upIdCtrlData->uAvScc=0x01;
                upIdCtrlData->uApsta=gsLightSwitch.usNvmeLs.uApsta;
                // Nvme 1.2
                // It is recommended that implementations report a value of 0157h in this field.
                upIdCtrlData->u16Wctemp=gsLightSwitch.usNvmeLs.u16WcTemp;    // 0x157h
                upIdCtrlData->u16Cctemp=gsLightSwitch.usNvmeLs.u16CcTemp;
                upIdCtrlData->u16Mtfa=gsLightSwitch.usNvmeLs.u16Mtfa;
#else/* if _ENABLE_NVME_LS */
                upIdCtrlData->u16Oacs=0x6000;    // gparLS_Nvme->u16OACS.u16All;
                upIdCtrlData->uAcl=0x03;    // gparLS_Nvme->uACL;
                upIdCtrlData->uAerl=0x03;    // gparLS_Nvme->uAERL;
                // upIdCtrlData->uFRMW       = ((gparLS_Nvme->uFRMW.NumberOfFirmwareSlots<<1)|
                // (gparLS_Nvme->uFRMW.FirmwareActivationWithoutReset<<4));
                upIdCtrlData->uFrmw=0x10;    // gparLS_Nvme->uFRMW.uAll;
                // upIdCtrlData->uLpa= 0x00; //gparLS_Nvme->uLPA;
                upIdCtrlData->uElpe=0x3F;    // gparLS_Nvme->uELPE;
                upIdCtrlData->uNpss=0x04;    // gparLS_Nvme->uNPSS;
                upIdCtrlData->uAvScc=0x01;
                // upIdCtrlData->uApsta= 0x00; //gparLS_Nvme->uAPSTA;
                // Nvme 1.2
                // It is recommended that implementations report a value of 0157h in this field.
                // upIdCtrlData->u16Wctemp= 0x0000; //gparLS_Nvme->u16WCTEMP;  //0x157h
                // upIdCtrlData->u16Cctemp= 0x0000; //gparLS_Nvme->u16CCTEMP;
                upIdCtrlData->u16Mtfa=0x0014;    // gparLS_Nvme->u16MTFA;
#endif/* if _ENABLE_NVME_LS */

                upIdCtrlData->uFwUg=(gSectorPerPlaneH/cSctrPer4k);    // 4K Unit, zero means no information, 0xFF means no restriction

                // ===========For HMB Feature================
                if(!(gsLightSwitch.usNvmeLs.uFeatOption&cDisableHmb))
                {
                    upIdCtrlData->u32HmPre=c16HmbPrefSize;    // 4k Units, zero means not support HMB
                    upIdCtrlData->u32HmMin=c16HmbMinSize;    // 4k Units, zero means no limmit
                }

                // ======================================

                upIdCtrlData->u64TnvmCapQw0=((QWORD)g32HostTotalDataSectorCnt<<9);
                upIdCtrlData->u64UnvmCapQw0=((QWORD)gsNamespace.u32UnvmCap<<9);

                upIdCtrlData->u32Rpmbs=0x00;

                // =====Device Self-Test
                if(gsLightSwitch.usNvmeLs.u16Oacs&cDeviseSelfTestCmd)
                {
                    // 20181129_SamHu_01 set DST time by capacity
                    u8capacityIndex=GetCapacityIndex();

                    if(u8capacityIndex<=11)    // under 256GB 2min
                    {
                        upIdCtrlData->u16Edstt=cDstExtendedTimeReportInMin_256;
                    }
                    else if(u8capacityIndex<=13)    // under 512GB 4min
                    {
                        upIdCtrlData->u16Edstt=cDstExtendedTimeReportInMin_512;
                    }
                    else    // 8min
                    {
                        upIdCtrlData->u16Edstt=cDstExtendedTimeReportInMin_1024;
                    }

                    upIdCtrlData->uDsto=1;
                }

                if(gsLightSwitch.usThermalLs.uThermalCtrl&cEnThrottle)
                {
                    upIdCtrlData->u16Hctma=1;
                }

                // 20181114_SamHu
                upIdCtrlData->u16MnTmt=gsLightSwitch.usNvmeLs.u16MnTmt;
                upIdCtrlData->U16MxTmt=gsLightSwitch.usNvmeLs.u16MxTmt;

                upIdCtrlData->u32SaniCap=gsLightSwitch.usNvme2Ls.u32SaniCap;

                // ====NVM Command Set Attributes
                upIdCtrlData->uSqEs=0x66;
                upIdCtrlData->uCqEs=0x44;

                if(gsLightSwitch.usNvmeLs.uFeatOption&cEnableNamespace)
                {
                    upIdCtrlData->u32Nn=gsLightSwitch.usNvme2Ls.u32NamespaceNum;
                }
                else
                {
                    upIdCtrlData->u32Nn=1;
                }

                // upIdCtrlData->u16ONCS      = ((gparLS_Nvme->uONCS.DatasetManagementCommand<<2)|
                // (gparLS_Nvme->uONCS.WriteZeroesCommand<<3)|
                // (gparLS_Nvme->uONCS.SaveFieldAndTheSelectField<<4));    //bit2: support Data Set Management Command, bit3: support Write
                // Zeros Command
#if _ENABLE_NVME_LS
                upIdCtrlData->u16Oncs=gsLightSwitch.usNvmeLs.uOncs;    // Fix Apollo-74
                upIdCtrlData->u16Fuses=(gsLightSwitch.usNvmeLs.uFuses&cFuseSupport);
                upIdCtrlData->uFna=gsLightSwitch.usNvmeLs.uFna;
                upIdCtrlData->uVwc=gsLightSwitch.usNvmeLs.uVwc&cVolatileWriteCacheEn;
#else
                // upIdCtrlData->u16Oncs= 0x0000; //gparLS_Nvme->uONCS.uAll;//Fix Apollo-74
                // upIdCtrlData->u16Fuses= 0x0000; //gparLS_Nvme->u16FUSES.FUSES;
                upIdCtrlData->uFna=0x07;    // gparLS_Nvme->uFNA;
                upIdCtrlData->uVwc=0x00;    // gparLS_Nvme->uVWC.VWC;
#endif
                // upIdCtrlData->u16Awun= 0x0000; //0x0004; //Lareina: zero's based value and specified in logical blocks
                // upIdCtrlData->u16Awupf= 0x0000; //Lareina: zero's based value and specified in logical blocks
                // upIdCtrlData->uNvScc= 0x00; //0x01; //Lareina: zero's based value and specified in logical blocks
                // upIdCtrlData->u16AcWu= 0x00; //0x04; //Lareina: zero's based value and specified in logical blocks
#if _ENABLE_SGLS
                upIdCtrlData->u32Sgls=0x02;    // SGLs are supported. There is a Dword alignment and granularity requirement for Data Blocks
#endif
// 20181126_SmaHu add SUBNQN for GTP Spec
                upIdCtrlData->uarSubqn[0]='n';
                upIdCtrlData->uarSubqn[1]='q';
                upIdCtrlData->uarSubqn[2]='n';
                upIdCtrlData->uarSubqn[3]='.';
                upIdCtrlData->uarSubqn[4]='2';
                upIdCtrlData->uarSubqn[5]='0';
                upIdCtrlData->uarSubqn[6]='1';
                upIdCtrlData->uarSubqn[7]='8';
                upIdCtrlData->uarSubqn[8]='-';
                upIdCtrlData->uarSubqn[9]='1';
                upIdCtrlData->uarSubqn[10]='1';
                upIdCtrlData->uarSubqn[11]='.';
                upIdCtrlData->uarSubqn[12]='c';
                upIdCtrlData->uarSubqn[13]='o';
                upIdCtrlData->uarSubqn[14]='m';
                upIdCtrlData->uarSubqn[15]='.';
                upIdCtrlData->uarSubqn[16]='L';
                upIdCtrlData->uarSubqn[17]='i';
                upIdCtrlData->uarSubqn[18]='t';
                upIdCtrlData->uarSubqn[19]='e';
                upIdCtrlData->uarSubqn[20]='O';
                upIdCtrlData->uarSubqn[21]='n';
                upIdCtrlData->uarSubqn[22]=':';
                upIdCtrlData->uarSubqn[23]='c';
                upIdCtrlData->uarSubqn[24]='l';
                upIdCtrlData->uarSubqn[25]='1';
                upIdCtrlData->uarSubqn[26]='-';

                // last 5 SN
                for(uCount=0; uCount<20; uCount++)
                {
                    if((upIdCtrlData->uarSn[uCount]==0x20)||(upIdCtrlData->uarSn[uCount]==0x00))
                    {
                        break;
                    }
                }

                if(uCount>=5)
                {
                    upIdCtrlData->uarSubqn[27]=upIdCtrlData->uarSn[uCount-5];
                    upIdCtrlData->uarSubqn[28]=upIdCtrlData->uarSn[uCount-4];
                    upIdCtrlData->uarSubqn[29]=upIdCtrlData->uarSn[uCount-3];
                    upIdCtrlData->uarSubqn[30]=upIdCtrlData->uarSn[uCount-2];
                    upIdCtrlData->uarSubqn[31]=upIdCtrlData->uarSn[uCount-1];
                }

                // upIdCtrlData->uarPsd[0].u16Mp      = 0x88;//for test
                // upIdCtrlData->uarPsd[1].u16Mp      = 0x88;//for test
                // future to implement

                // temp Test, copy from sumsung
                upIdCtrlData->uarPsd[0].u16Mp=gsLightSwitch.usNvme2Ls.u16Ps0Mp;    // max power
                upIdCtrlData->uarPsd[0].uMpsNops=gsLightSwitch.usNvme2Ls.uPs0Mxps;    // Max Powe Scale/NOP state (no IO allow)
                upIdCtrlData->uarPsd[0].u32EnLat=gsLightSwitch.usNvme2Ls.u32Ps0EnLat;    // enter latency
                upIdCtrlData->uarPsd[0].u32ExLat=gsLightSwitch.usNvme2Ls.u32Ps0ExLat;    // exit latency

#if _ENABLE_NVME_PM
                if(gsLightSwitch.usNvmeLs.uNpss>=1)
                {
                    upIdCtrlData->uarPsd[1].u16Mp=gsLightSwitch.usNvme2Ls.u16Ps1Mp;
                    upIdCtrlData->uarPsd[1].uMpsNops=gsLightSwitch.usNvme2Ls.uPs1Mxps;
                    upIdCtrlData->uarPsd[1].u32EnLat=gsLightSwitch.usNvme2Ls.u32Ps1EnLat;    // 0x001E;
                    upIdCtrlData->uarPsd[1].u32ExLat=gsLightSwitch.usNvme2Ls.u32Ps1ExLat;    // 0x001E;
                    upIdCtrlData->uarPsd[1].uRrt=0x01;    // read throughput
                    upIdCtrlData->uarPsd[1].uRrl=0x01;    // read latency
                    upIdCtrlData->uarPsd[1].uRwt=0x01;    // write throughput
                    upIdCtrlData->uarPsd[1].uRwl=0x01;
                }

                if(gsLightSwitch.usNvmeLs.uNpss>=2)
                {
                    upIdCtrlData->uarPsd[2].u16Mp=gsLightSwitch.usNvme2Ls.u16Ps2Mp;
                    upIdCtrlData->uarPsd[2].uMpsNops=gsLightSwitch.usNvme2Ls.uPs2Mxps;
                    upIdCtrlData->uarPsd[2].u32EnLat=gsLightSwitch.usNvme2Ls.u32Ps2EnLat;    // 0x001E;
                    upIdCtrlData->uarPsd[2].u32ExLat=gsLightSwitch.usNvme2Ls.u32Ps2ExLat;    // 0x001E;
                    upIdCtrlData->uarPsd[2].uRrt=0x02;
                    upIdCtrlData->uarPsd[2].uRrl=0x02;
                    upIdCtrlData->uarPsd[2].uRwt=0x02;
                    upIdCtrlData->uarPsd[2].uRwl=0x02;
                }

                if(gsLightSwitch.usNvmeLs.uNpss>=3)
                {
                    upIdCtrlData->uarPsd[3].u16Mp=gsLightSwitch.usNvme2Ls.u16Ps3Mp;    // 25 mW, @PCIe L1 link
                    upIdCtrlData->uarPsd[3].uMpsNops=(0x02|gsLightSwitch.usNvme2Ls.uPs3Mxps);    // Max Powe Scale/NOP state (no IO allow)
                    upIdCtrlData->uarPsd[3].u32EnLat=gsLightSwitch.usNvme2Ls.u32Ps3EnLat;    // 2200 us
                    upIdCtrlData->uarPsd[3].u32ExLat=gsLightSwitch.usNvme2Ls.u32Ps3ExLat;    // 3000 us
                    upIdCtrlData->uarPsd[3].uRrt=0x03;
                    upIdCtrlData->uarPsd[3].uRrl=0x03;
                    upIdCtrlData->uarPsd[3].uRwt=0x03;
                    upIdCtrlData->uarPsd[3].uRwl=0x03;
                }

                if(gsLightSwitch.usNvmeLs.uNpss>=4)
                {
                    upIdCtrlData->uarPsd[4].u16Mp=gsLightSwitch.usNvmeLs.u16Ps4Mp;    // 12 mW, @PCIe L1 link
                    upIdCtrlData->uarPsd[4].uMpsNops=(0x02|gsLightSwitch.usNvmeLs.uPs4Mxps);    // Max Powe Scale/NOP state (no IO allow)
                    upIdCtrlData->uarPsd[4].u32EnLat=gsLightSwitch.usNvmeLs.u32Ps4EnLat;    // 15000 us
                    upIdCtrlData->uarPsd[4].u32ExLat=gsLightSwitch.usNvmeLs.u32Ps4ExLat;    // 12000 us
                    upIdCtrlData->uarPsd[4].uRrt=0x04;
                    upIdCtrlData->uarPsd[4].uRrl=0x04;
                    upIdCtrlData->uarPsd[4].uRwt=0x04;
                    upIdCtrlData->uarPsd[4].uRwl=0x04;
                }
#endif/* if _ENABLE_NVME_PM */

#if _ENABLE_SECAPI
#if 0    // default gparLS_VUID->EnableVUSpace=0, future to implement
                if(gparLS_VUID->EnableVUSpace&0x01)
                {
                    SetupVUID((LWORD)upIdCtrlData);
                }
#endif
                /* for Ulink security support check */
                WORD *up16Ptr=(WORD *)(LWORD)(upIdCtrlData);
                BYTE *upPtr=(BYTE *)(LWORD)(upIdCtrlData);

                if(gbEnTCG)
                {
                    upPtr[3279]|=cBit2;
                }

                if(gbEnAes)
                {
                    upPtr[3279]|=cBit1;
                }

                if((gbEnATAPassThrough)&&(gTcgNviSpLockingLifeCycleState!=C_Manufactured))
                {
                    upPtr[3279]|=cBit0;
                }

                // Secure feature from LigtSwtich
                if(gbEnAes)
                {
                    up16Ptr[4000/2]|=c16Bit9;
                }
                // MOVE_TSB2SDRAM(up8Ptr+4002, gsLightSwitch.usVuIdLs.uarWWN, 8);
#endif/* if _ENABLE_SECAPI */
#if (OEM==DELL)    // 20181010_Jesse_01, Add for Dell spec "ENG0013785_A01"
// BYTE uarVs[1024]; // Vendor Specific Byte3072~4095
                // Byte 3072~3103 32Bytes ePPID
                copyCcmVal(upIdCtrlData->uarVs, gsLightSwitch.usVuIdLs.uarEppId, 0x20);
                // Byte 3104~3105 = 0x0002 for M.2 Form factor
                upIdCtrlData->uarVs[32]=0x02;    // Set Byte_3104
                // upIdCtrlData->uarVs[33]=0x00; //Set Byte_3105
                // Set Byte_3106 bit_0 to 1 for define "Value"
                upIdCtrlData->uarVs[34]|=cBit0;    // Set Byte_3106
                // upIdCtrlData->uarVs[34]|=0x00;//Set Byte_3107
#if (_ENABLE_SCP_PLP==_EN_SCP)
                // Byte 3108~3109 = 0x8001 for SCP function support
                upIdCtrlData->uarVs[36]=0x01;    // Set Byte_3108
                upIdCtrlData->uarVs[37]=0x80;    // Set Byte_3109
#endif
// 20190527_Jesse_01, Add for Dell 3D512G GGUID & Component ID
#if ((PRODUCT_NAME&0x0008)==0x0008)    // define 512G GUID & Component ID
                // Byte 3110~3125 Add for Dell GUID = d8b197d0-0b03-4138-8ea6-8366a0cfde4a
                upIdCtrlData->uarVs[38]=0xD0;    // Set Byte_3110 GUID
                upIdCtrlData->uarVs[39]=0x97;    // Set Byte_3111 GUID
                upIdCtrlData->uarVs[40]=0xB1;    // Set Byte_3112 GUID
                upIdCtrlData->uarVs[41]=0xD8;    // Set Byte_3113 GUID

                upIdCtrlData->uarVs[42]=0x03;    // Set Byte_3114 GUID
                upIdCtrlData->uarVs[43]=0x0B;    // Set Byte_3115 GUID

                upIdCtrlData->uarVs[44]=0x38;    // Set Byte_3116 GUID
                upIdCtrlData->uarVs[45]=0x41;    // Set Byte_3117 GUID

                upIdCtrlData->uarVs[46]=0x8E;    // Set Byte_3118 GUID
                upIdCtrlData->uarVs[47]=0xA6;    // Set Byte_3119 GUID
                upIdCtrlData->uarVs[48]=0x83;    // Set Byte_3120 GUID
                upIdCtrlData->uarVs[49]=0x66;    // Set Byte_3121 GUID
                upIdCtrlData->uarVs[50]=0xA0;    // Set Byte_3122 GUID
                upIdCtrlData->uarVs[51]=0xCF;    // Set Byte_3123 GUID
                upIdCtrlData->uarVs[52]=0xDE;    // Set Byte_3124 GUID
                upIdCtrlData->uarVs[53]=0x4A;    // Set Byte_3125 GUID
                // Byte 3126~3133 Add for Dell Component ID(ASCII) ="108814"
                upIdCtrlData->uarVs[54]=0x20;    // " ";    // Set Byte_3126 Component ID
                upIdCtrlData->uarVs[55]=0x20;    // " ";    // Set Byte_3127 Component ID
                upIdCtrlData->uarVs[56]=0x31;    // "1";    // Set Byte_3128 Component ID
                upIdCtrlData->uarVs[57]=0x30;    // "0";    // Set Byte_3128 Component ID
                upIdCtrlData->uarVs[58]=0x38;    // "8";    // Set Byte_3128 Component ID
                upIdCtrlData->uarVs[59]=0x38;    // "8";    // Set Byte_3128 Component ID
                upIdCtrlData->uarVs[60]=0x31;    // "1";    // Set Byte_3128 Component ID
                upIdCtrlData->uarVs[61]=0x34;    // "4";    // Set Byte_3133 Component ID
#else    // define 128G/256G GUID & Component ID
                // Byte 3110~3125 Add for Dell GUID = 1cd7457a-27a9-4af9-912b-73af953d94b4
                upIdCtrlData->uarVs[38]=0x7A;    // Set Byte_3110 GUID
                upIdCtrlData->uarVs[39]=0x45;    // Set Byte_3111 GUID
                upIdCtrlData->uarVs[40]=0xD7;    // Set Byte_3112 GUID
                upIdCtrlData->uarVs[41]=0x1C;    // Set Byte_3113 GUID

                upIdCtrlData->uarVs[42]=0xA9;    // Set Byte_3114 GUID
                upIdCtrlData->uarVs[43]=0x27;    // Set Byte_3115 GUID

                upIdCtrlData->uarVs[44]=0xF9;    // Set Byte_3116 GUID
                upIdCtrlData->uarVs[45]=0x4A;    // Set Byte_3117 GUID

                upIdCtrlData->uarVs[46]=0x91;    // Set Byte_3118 GUID
                upIdCtrlData->uarVs[47]=0x2B;    // Set Byte_3119 GUID
                upIdCtrlData->uarVs[48]=0x73;    // Set Byte_3120 GUID
                upIdCtrlData->uarVs[49]=0xAF;    // Set Byte_3121 GUID
                upIdCtrlData->uarVs[50]=0x95;    // Set Byte_3122 GUID
                upIdCtrlData->uarVs[51]=0x3D;    // Set Byte_3123 GUID
                upIdCtrlData->uarVs[52]=0x94;    // Set Byte_3124 GUID
                upIdCtrlData->uarVs[53]=0xB4;    // Set Byte_3125 GUID
                // Byte 3126~3133 Add for Dell Component ID(ASCII) ="108365"
                upIdCtrlData->uarVs[54]=0x20;    // " ";    // Set Byte_3126 Component ID
                upIdCtrlData->uarVs[55]=0x20;    // " ";    // Set Byte_3127 Component ID
                upIdCtrlData->uarVs[56]=0x31;    // "1";    // Set Byte_3128 Component ID
                upIdCtrlData->uarVs[57]=0x30;    // "0";    // Set Byte_3128 Component ID
                upIdCtrlData->uarVs[58]=0x38;    // "8";    // Set Byte_3128 Component ID
                upIdCtrlData->uarVs[59]=0x33;    // "3";    // Set Byte_3128 Component ID
                upIdCtrlData->uarVs[60]=0x36;    // "6";    // Set Byte_3128 Component ID
                upIdCtrlData->uarVs[61]=0x35;    // "5";    // Set Byte_3133 Component ID
#endif/* #if ((PRODUCT_NAME&0x0008)==0x0008) */
#endif/* if (OEM==DELL) */
#if (_ENABLE_SCP_PLP==_EN_PLP)
//                upPtr1[4000]|=cBit0;    // PLP feature supported
//                upPtr1[4001]=0x3C;    // Completion Time (COPI), Low Byte 3900ms
//                upPtr1[4002]=0x0F;    // Completion Time (COPI), High Byte 3900ms
                upIdCtrlData->uarVs[928]=0x01;    // PLP feature supported
                upIdCtrlData->uarVs[930]=0x3C;    // Completion Time (COPI), Low Byte 3900ms
                upIdCtrlData->uarVs[931]=0x0F;    // Completion Time (COPI), High Byte 3900ms
#endif
            }

            break;

        case cNvmeIdenActiveNsIds:
        case cNvmeIdenAllocatedNsIds:

            if((!(gsLightSwitch.usNvmeLs.usIgnoreNsId.uAll&cIgnoreInIdNamespace))&&(u32NsId>gsLightSwitch.usNvme2Ls.u32NamespaceNum))
            {
                u16StatusCode=cStatusInvalidNsFormat;
            }
            else
            {
                if(uCns==cNvmeIdenActiveNsIds)
                {
                    uBitMap=gsNamespace.uActiveBitMap;
                }
                else
                {
                    uBitMap=gsNamespace.uAllocatedBitMap;
                }

                for(uChkNsId=u32NsId; uChkNsId<gsLightSwitch.usNvme2Ls.u32NamespaceNum; uChkNsId++)
                {
                    if(uBitMap&cbBitTab[uChkNsId])
                    {
                        g32arTsb0[0][uChkTsbIdx]=(uChkNsId+1);
                        uChkTsbIdx++;
                    }
                }

                uXferCnt=8;
            }

            break;

        case cNvmeIdenActiveNsIdenDesc:

            // if(u16CNTID != 0)  //This case will post in newer version
            // {
            // u16StatusCode=cStatusInvalidField;
            // }
            if(gsLightSwitch.usNvmeLs.u32Ver<0x00010300)
            {
                u16StatusCode=cStatusInvalidField;
            }
            else if((!(gsLightSwitch.usNvmeLs.usIgnoreNsId.uAll&cIgnoreInIdNamespace))&&
                    (!(u32NsId&&(u32NsId<=gsLightSwitch.usNvme2Ls.u32NamespaceNum)&&(gsNamespace.uActiveBitMap&cbBitTab[u32NsId-1]))))
            {
                u16StatusCode=cStatusInvalidNsFormat;
            }
            else
            {
                upIdIdentificationDesc=(void *)&garTsb0[0];

                for(uNidt=cNidtEui64; uNidt<=cNidtNuuId; uNidt++)
                {
                    if(uNidt==cNidtEui64)
                    {
                        uNidl=cNidlEui64;
                        copyCcmVal((BYTE *)&uarNid, (BYTE *)&gsMPInfo.uarEui64, uNidl);
                    }
                    else if(uNidt==cNidtNguId)
                    {
                        uNidl=cNidlNguId;
                        copyCcmVal((BYTE *)&uarNid, (BYTE *)&gsLightSwitch.usNvmeLs.uarNguid, uNidl);
                    }
                    else if(uNidt==cNidtNuuId)
                    {
                        uNidl=cNidlNuuId;
                        copyCcmVal((BYTE *)&uarNid, (BYTE *)&gsLightSwitch.usNvme2Ls.uarNamespaceUUID, uNidl);
                    }

                    for(uChkNid=0; uChkNid<uNidl; uChkNid++)
                    {
                        if(uarNid[uChkNid])
                        {
                            break;
                        }
                    }

                    if(uChkNid<uNidl)
                    {
                        upIdIdentificationDesc->uNidt=uNidt;
                        upIdIdentificationDesc->uNidl=uNidl;
                        copyCcmVal((BYTE *)upIdIdentificationDesc->uarNid, (BYTE *)&uarNid, uNidl);
                        upIdIdentificationDesc=(void *)((LWORD)upIdIdentificationDesc+(uNidl+4));
                    }
                }

                if((LWORD)upIdIdentificationDesc==(LWORD)&garTsb0[0])
                {
                    u16StatusCode=cStatusInvalidField;    // All Nid=0
                }
                else
                {
                    uXferCnt=8;
                }
            }

            break;

        case cNvmeIdenAttachedCtrllerIds:

            upIdContorllerList=(void *)&garTsb0[0];

            if(u32NsId&&(u32NsId<=gsLightSwitch.usNvme2Ls.u32NamespaceNum)&&(gsNamespace.uActiveBitMap&cbBitTab[u32NsId-1]))
            {
                if(u16Cntid<=cControllerCurrId)
                {
                    upIdContorllerList->u16NumIdentifier=cControllerNumber;
                    upIdContorllerList->u16Idetifier[0]=cControllerCurrId;

                    uXferCnt=8;
                }
                else
                {
                    u16StatusCode=cStatusInvalidField;
                }
            }

            break;

        case cNvmeIdenAllCtrllerIds:

            upIdContorllerList=(void *)&garTsb0[0];

            if(u16Cntid<=cControllerCurrId)
            {
                upIdContorllerList->u16NumIdentifier=cControllerNumber;
                upIdContorllerList->u16Idetifier[0]=cControllerCurrId;
            }

            uXferCnt=8;
            break;

        default:
            u16StatusCode=cStatusInvalidField;
            break;
    }    /* switch */

    if(((!u16StatusCode)||(u16StatusCode>cStatusInvalidField))&&
       (uPSDT||((uCns!=cNvmeIdenAttachedCtrllerIds)&&(uCns!=cNvmeIdenAllCtrllerIds)&&u16Cntid)))
    {
        u16StatusCode=cStatusInvalidField;
    }

#if (_EN_CHRONUS_UART_DEBUG)
    if(((!u16StatusCode)||(u16StatusCode>cStatusInvalidPrpOffset))&&(!mChkUartCMDRdy&&validatePrp(cValidPrp4kData)))
#else
    if(((!u16StatusCode)||(u16StatusCode>cStatusInvalidPrpOffset))&&validatePrp(cValidPrp4kData))
#endif
    {
        u16StatusCode=cStatusInvalidPrpOffset;
    }

#if (_EN_CHRONUS_UART_DEBUG)
    if(mChkUartCMDRdy)
    {
        g32arUartCQEntryDW[3]=u16StatusCode<<17;
        loadISPCodeCore0(cUartTsbBank, 2);
        sendUartCmdRsp(cTsb0StartBufIdx);
    }
    else
#endif
    {
        if(u16StatusCode)
        {
            manualCompletion(u16StatusCode, 0x0, cNoRwCmd, 0x0);
        }
        else
        {
            trigNonRWCmd(cTsb0StartBufIdx, uXferCnt, cTsb0, cNvmeRead, cAutoCq);
        }
    }
}    /* nvmeIdentify */

void nvmeSetFeature()
{
    LWORD u32CmdSpecific=0, u32Cnt, u32NsId=rmNvmeNsId;
    WORD u16StatusCode=cStatusSuccess, u16TmpThres=0, u16Tmt1, u16Tmt2;
    BYTE uTypeSel, uTmpSel, uFid=rmNvmeFid;

    // BYTE uIdx;

    NLOG(cLogHost,
         NVMECMDEXT_C,
         3,
         "  Set Features: FID=0x%02X, SV=0x%02X, Attr=0x%08X",
         (WORD)(uFid<<8|rmNvmeSv>>7),
         rmNvmeCmdDw11>>16,
         rmNvmeCmdDw11);

    readWproPageCore0(cWproFeaturePg, cNvmeFeatSIdx, 0);

    // if((uFid==cNvmeFeatLbaRange)||(uFid==cNvmeFeatErrRecovery)||(uFid==cNvmeFeatWriteAtomic))  // 20181206_SamHu_01 mark for GTP Spec X09
    if(uFid==cNvmeFeatLbaRange)
    {
        if((u32NsId==cNamespaceNotSpecific)||((u32NsId!=cNamespaceAll)&&
                                              ((u32NsId>gsLightSwitch.usNvme2Ls.u32NamespaceNum)||
                                               (!(gsNamespace.uActiveBitMap&cbBitTab[(BYTE)((u32NsId-1)&0x00000007)])))))    // tnvme 23:3.0.0

        {
            u16StatusCode=cStatusInvalidNsFormat;
        }
    }

    switch(uFid)
    {
        case cNvmeFeatArbitration:
            u16StatusCode=nvmeSetFeatureAttribute((NVMEFEATURESEL *)&gpNvmeFeatVar->usFeat.usArbitration, rmNvmeCmdDw11, rmNvmeSv);

            if(u16StatusCode==cStatusSuccess)
            {
                rmSetFeatArbitrationAll(gpNvmeFeatVar->usFeat.usArbitration.u32Current);
#if (_RR_WORKAROUND)    // HW setting
                rmSetFeatArbitrationHpw(127);    // CSSD-2875, CSSD-2833
                rmSetFeatArbitrationMpw(127);
                rmSetFeatArbitrationLpw(127);
                rmSetFeatArbitrationAb(3);
#endif
            }

            break;

        // Power Management move to nvmeAdminPM()
        // case cNvmeFeatPowerMgmt:
        //      break;

        case cNvmeFeatLbaRange:

#if (OEM==HP)
            if(!u16StatusCode)
            {
                if(u32NsId!=cNamespaceAll)
                {
                    if(!u32NsId)    // 20190222_SamHu_01
                    {
                        u16StatusCode=handleFeatLbaRangeType(0);
                    }
                    else
                    {
                        u16StatusCode=handleFeatLbaRangeType(u32NsId-1);
                    }
                }
                else
                {
                    for(u32Cnt=0; u32Cnt<gsLightSwitch.usNvme2Ls.u32NamespaceNum; u32Cnt++)
                    {
                        if(gsNamespace.uActiveBitMap&cbBitTab[u32Cnt])
                        {
                            u16StatusCode=handleFeatLbaRangeType(u32Cnt);

                            if(u16StatusCode)
                            {
                                break;
                            }
                        }
                    }
                }
            }
#else/* if (OEM==HP) */
            u16StatusCode=cStatusInvalidField;    // 20181030_Jesse_01, Disable LBA Range Feature
#endif/* if (OEM==HP) */
            break;

        case cNvmeFeatTempThresh:
            uTmpSel=rmNvmeTempThresSel;    // bits 19:16 represent Threshold Temperature Select
            uTypeSel=rmNvmeTempThresType;    // bits 21:20 represent Threshold Type Select

            if(((uTmpSel<cNumOfTempSensor)||(uTmpSel==cTempAllSensor))&&(uTypeSel<cNumOfTypeSensor))    // maske sure the fileds are valid
            {
                u16TmpThres=rmNvmeTempThres;    // bits 15:00 represent Temperature Threshold

                if(uTmpSel<cNumOfTempSensor)    // only update one sensor threshold
                {
                    u16StatusCode=nvmeSetFeatureAttribute((NVMEFEATURESEL *)&gpNvmeFeatVar->usFeat.usTemperatureThres[uTypeSel][uTmpSel],
                                                          rmNvmeTempThres,
                                                          rmNvmeSv);
                }
                else    // updates all sensor values
                {
                    for(u32Cnt=0; u32Cnt<cNumOfTempSensor; u32Cnt++)
                    {
                        u16StatusCode=nvmeSetFeatureAttribute((NVMEFEATURESEL *)&gpNvmeFeatVar->usFeat.usTemperatureThres[uTypeSel][u32Cnt],
                                                              rmNvmeTempThres,
                                                              rmNvmeSv);
                    }
                }

                if(uTypeSel==cOverTempTh)
                {
                    gsSmart.usStatus.u16OverTempThres=u16TmpThres;
                }
                else
                {
                    gsSmart.usStatus.u16UnderTempThres=u16TmpThres;
                }
            }
            else    // invlide field, return error
            {
                u16StatusCode=cStatusInvalidField;
            }

            if(u16StatusCode==cStatusSuccess)
            {
                if(!gsNvmeAer.uAerQueueCnt)
                {
                    // CSSD 5023, Oakgate -Async Req Limit Excd : If no async request, need to clear async notification and check temp again
                    mClrAerTemp;
                }

#if _EN_NAND_TEMP
                if(!g32NandTempSensor)
                {
                    // Update Nand temperature
                    LWORD u32Cnt=0;

                    g32NandTempSensor=1;

                    while(g32NandTempSensor&&(u32Cnt<0x100))
                    {
                        sysDelay(10);
                        u32Cnt++;
                    }
                }

                chkAerTempThreshold(g32AvgNandTemp);
#else
                chkAerTempThreshold(getThermalSensorTemp());
#endif/* if _EN_NAND_TEMP */
            }

            break;

        case cNvmeFeatErrRecovery:

            if(!u16StatusCode)
            {
#if 1
                u16StatusCode=handleFeatErrorRecovery(0);
#else    // 20181206_SamHu_01 mark for GTP Spec X09
                if(u32NsId!=cNamespaceAll)
                {
                    u16StatusCode=handleFeatErrorRecovery(u32NsId-1);
                }
                else
                {
                    for(u32Cnt=0; u32Cnt<gsLightSwitch.usNvme2Ls.u32NamespaceNum; u32Cnt++)
                    {
                        if(gsNamespace.uActiveBitMap&cbBitTab[u32Cnt])
                        {
                            u16StatusCode=handleFeatErrorRecovery(u32Cnt);

                            if(u16StatusCode)
                            {
                                break;
                            }
                        }
                    }
                }
#endif/* if 1 */
            }

            break;

        case cNvmeFeatVolatileWc:

            if(gsLightSwitch.usNvmeLs.uVwc&cVolatileWriteCacheEn)
            {
#if _GREYBOX
                if((gsGbInfo.uGreyBoxItem==cUGSDProgWPROID)&&(gsGbInfo.uGreyBoxOpt==cVOpSetFeature)&&(gsGbInfo.uStag==cVsIdl))
                {
                    trigGreyBox(cTrue);
                }
#endif
                u16StatusCode=nvmeSetFeatureAttribute((NVMEFEATURESEL *)&gpNvmeFeatVar->usFeat.usVolatileWc, rmNvmeFeatIntWriteCache, rmNvmeSv);

                if(u16StatusCode==cStatusSuccess)
                {
                    // volatile write cache (in PS, it is not saveable feature)
                    if(gpNvmeFeatVar->usFeat.usVolatileWc.u32Current&cVolatileWriteCacheEn)
                    {
                        mSetCacheEnable;
                    }
                    else
                    {
                        mClrCacheEnable;
                    }
                }
            }
            else
            {
                // TODO:
                // If a volatile write cache is not present,
                // Flush commands complete successfully and have no effect,
                // Set Features with the Volatile Write Cache identifier field set
                // shall fail with Invalid Field status,
                // and Get Features with the Volatile Write Cache identifier field
                // set should fail with Invalid Field status.
            }

            break;

        case cNvmeFeatNumQueues:

            // Apollo-131
            if((rmNvmeNcqr==0xFFFF)||(rmNvmeNsqr==0xFFFF))
            {
                u16StatusCode=cStatusInvalidField;
            }
            else
            {
                u16StatusCode=nvmeSetFeatureAttribute((NVMEFEATURESEL *)&gpNvmeFeatVar->usFeat.usNumberOfQueues, rmNvmeCmdDw11, rmNvmeSv);

                if(u16StatusCode==cStatusSuccess)
                {
                    // always return 0x00070007
                    u32CmdSpecific=(((cMaxIoSqCqCnt-1)<<16)|(cMaxIoSqCqCnt-1));    // Supportting 8 SQ/CQ pairs regardless of host request
                }
            }

            break;

        case cNvmeFeatIrqCoalesce:
            u16StatusCode=nvmeSetFeatureAttribute((NVMEFEATURESEL *)&gpNvmeFeatVar->usFeat.usIntCoalescing, rmNvmeCmdDw11, rmNvmeSv);

            if(u16StatusCode==cStatusSuccess)
            {
                rmSetFeatCoalescing(gpNvmeFeatVar->usFeat.usIntCoalescing.u32Current);
            }

            break;

        case cNvmeFeatIrqConfig:

            if(rmNvmeFeatIntVecCfgIv<16)
            {
                if(rmNvmeFeatIntVecCfgIv)    // make sure not Admin queue
                {
                    // CSSD-1375
                    u16StatusCode=nvmeSetFeatureAttribute((NVMEFEATURESEL *)&gpNvmeFeatVar->usFeat.usIntVecCfg[rmNvmeFeatIntVecCfgIv],
                                                          rmNvmeCmdDw11,
                                                          rmNvmeSv);
                    // M_CLR_FEAT_INT_VEC_CFG_UPDATE;//confirmed with h/w, no need to clear the update bit(jack)
                }
                else    // if is Admin queue
                {
                    // 20180118_WadeHHLee_Fix IOL Test5.5 Case6 issue
                    u16StatusCode=nvmeSetFeatureAttribute((NVMEFEATURESEL *)&gpNvmeFeatVar->usFeat.usIntVecCfg[rmNvmeFeatIntVecCfgIv],
                                                          rmNvmeCmdDw11,
                                                          rmNvmeSv);

                    if(!u16StatusCode)
                    {
                        if(!rmNvmeFeatIntVecCfg)    // CSSD-137
                        {
                            u16StatusCode=cStatusInvalidField;    // Admin queue can't support interrupt coalescing, return error
                        }
                    }
                }

                // CSSD-1375
                if(u16StatusCode==cStatusSuccess)
                {
                    rmSetFeatIntVecCfg(gpNvmeFeatVar->usFeat.usIntVecCfg[rmNvmeFeatIntVecCfgIv].u32Current);
                    rmSetFeatIntVecCfgUpdate;
                }
            }
            else
            {
                u16StatusCode=cStatusInvalidField;
            }

            break;

        case cNvmeFeatWriteAtomic:

            if(!u16StatusCode)
            {
#if 1
                u16StatusCode=handleFeatWriteAtomic(0);
#else    // 20181206_SamHu_01 mark for GTP Spec X09
                if(u32NsId!=cNamespaceAll)
                {
                    u16StatusCode=handleFeatWriteAtomic(u32NsId-1);
                }
                else
                {
                    for(u32Cnt=0; u32Cnt<gsLightSwitch.usNvme2Ls.u32NamespaceNum; u32Cnt++)
                    {
                        if(gsNamespace.uActiveBitMap&cbBitTab[u32Cnt])
                        {
                            u16StatusCode=handleFeatWriteAtomic(u32Cnt);

                            if(u16StatusCode)
                            {
                                break;
                            }
                        }
                    }
                }
#endif/* if 1 */
            }

            break;

        case cNvmeFeatAsyncEvent:
            // 20181225_SamHu_sync SMI Momo release FW
            u16StatusCode=
                nvmeSetFeatureAttribute((NVMEFEATURESEL *)&gpNvmeFeatVar->usFeat.usAsyncEventCfg, rmNvmeAsyncEventValidBits, rmNvmeSv);

            if(u16StatusCode==cStatusSuccess)
            {
                gsNvmeAer.u32AerCriticalWarning=gpNvmeFeatVar->usFeat.usAsyncEventCfg.u32Current;
            }

            break;

        case cNvmeFeatAutoPst:

            // Note: APST data payload size is 256 bytes, but we get 512 bytes because HW limitation
            if(gsLightSwitch.usNvmeLs.uApsta)
            {
#if 0    // _SM226X_A0
                // Backup PCIe MSIx Table once
                if((!gMsixTableFlag)&&rmChkMsixCtrlRegMsixEnable)
                {
                    for(uIdx=0; uIdx<64; uIdx++)
                    {
                        gar32BkMsixTab[uIdx]=rmPcieMsixTable(uIdx);
                    }

                    gMsixTableFlag=1;
                }
#endif
                u16StatusCode=nvmeSetFeatureAttribute((NVMEFEATURESEL *)&gpNvmeFeatVar->usFeat.usAutoPst, rmNvmeCmdDw11, rmNvmeSv);

                if(u16StatusCode==cStatusSuccess)
                {
                    if(rmNvmeApstEn)    // if disable APST don't need check data 20181225_SamHu_sync SMI momo release FW
                    {
                        trigNonRWCmd(cTsb0StartBufIdx, 0x01, cTsb0, cNvmeWrite, cManualCq);
                    }

                    u16StatusCode=handleFeatApst();
                }

                if(u16StatusCode==cStatusSuccess)
                {
                    if(g32ApstEnable)
                    {
                        startRtcCountingMs();
                    }
                }
            }
            else
            {
                u16StatusCode=cStatusInvalidField;
            }

            break;

        case cNvmeFeatHostMemBuff:

            if(!(gsLightSwitch.usNvmeLs.uFeatOption&cDisableHmb))
            {
                u16StatusCode=nvmeSetFeatureAttribute((NVMEFEATURESEL *)&gpNvmeFeatVar->usFeat.usHostMemoryBuffer, rmNvmeCmdDw11, rmNvmeSv);
            }
            else
            {
                NLOG(cLogHost, NVMECMDEXT_C, 0, " Lightswitch disable HMB opt ");
                u16StatusCode=cStatusInvalidField;
            }

            if(u16StatusCode==cStatusSuccess)
            {
                if(rmNvmeHmbEnable)
                {
#if _EN_DisHMBInReset    // 20190805_Chief_DisHMB
                    if(gsHmbInfo.uHmbEnable||(gChkFlag&cEnableFakeHMB))
#else
                    if(gsHmbInfo.uHmbEnable)
#endif
                    {
                        u16StatusCode=cStatusCmdSequenceErr;
                        break;
                    }

#if _EN_DisHMBInReset    // 20190805_Chief_DisHMB
                    if((g16SlcSortQCnt>(cMaxSlcBlkQ-10))||(gDisHMBCnt_NormalBehavior>=cDisHmbMaxThr)||gDisHMBCnt_AbnormalBehavior)    // 20190807_Bruce_DisHMB
                    {
                        gChkFlag|=cEnableFakeHMB;
                        NLOG(cLogHost,
                             NVMECMDEXT_C,
                             4,
                             " SetFeature Fake HMB gChkFlag=0x%04X, NormalBehavior=0x%04X AbnormalBehavior=0x%04X, g16SlcSortQCnt=0x%04X",
                             gChkFlag,
                             gDisHMBCnt_NormalBehavior,
                             gDisHMBCnt_AbnormalBehavior,
                             g16SlcSortQCnt);
                    }
#endif

#if (_GREYBOX)
                    // if((!rmNvmeHmbMemReturn)||(gsGbInfo.uGreyBoxItem==cHmbErrHandle)||(gsGbInfo.uGreyBoxItem==cErrHdlE2EHostData))
#else
                    // if(!rmNvmeHmbMemReturn)
#endif
                    {
                        remAllHmbLink();
                        gsHmbInfo.uHmbValid=getHmbDescList();
#if _EN_DisHMBInReset    // 20190805_Chief_DisHMB
                        if(gChkFlag&cEnableFakeHMB)
                        {
                            gsHmbInfo.uHmbValid=0;
                            NLOG(cLogHost, NVMECMDEXT_C, 1, " Dont HMB gsHmbInfo.uHmbValid=0x%04X ", gsHmbInfo.uHmbValid);
                        }
                        else
#endif

                        if(gsHmbInfo.uHmbValid)
                        {
                            // gsHmbInfo.u32HmbStAddr[cXXXX]=(c16HmbMaxTableNum<<16);
                            // gsHmbInfo.u32HmbStAddr[cHmbWrCache]=g32HmbTotalH2FTableSize+c32HmbTotalGcInfoTableSize;
                            // gsHmbInfo.u32HmbStAddr[cHmbRdCache]=gsHmbInfo.u32HmbStAddr[cHmbWrCache]+cHmbWrCacheSize;
                            gsHmbInfo.u32HmbStAddr[cHmbTsbCache]=g32HmbTotalH2FTableSize;
                            gsHmbInfo.u32HmbStAddr[cHmbGcCache]=gsHmbInfo.u32HmbStAddr[cHmbTsbCache]+cHmbTsbCacheSize+
                                                                 c32HmbTotalGcInfoTableSize;
                            gsHmbInfo.u32HmbStAddr[cHmbCrcCache]=gsHmbInfo.u32HmbStAddr[cHmbGcCache]+cHmbGcCacheSize;
                            gsHmbInfo.u32HmbStAddr[cHmbGcPtCache]=gsHmbInfo.u32HmbStAddr[cHmbCrcCache]+cHmbDataCrcCacheSize;
                            gsHmbInfo.u32HmbStAddr[cHmbPtCrcCache]=gsHmbInfo.u32HmbStAddr[cHmbGcPtCache]+cHmbGcPtCacheSize;
#if _EN_HMB
                            chkHmbEnbleFlag();
#endif
                        }
                        else
                        {
                            NLOG(cLogHost, NVMECMDEXT_C, 0, " HMB MR=0 and HMB invalid !!");
                            u16StatusCode=cStatusInvalidField;
                        }
                    }
                    // else if(gsHmbInfo.uHmbValid)
                    // {
#if _EN_HMB
                    //    chkHmbEnbleFlag();
#endif
                    // }
                    // else
                    // {
                    //    NLOG(cLogHost, NVMECMDEXT_C, 0, " HMB MR=1 and HMB invalid !!");
                    //    u16StatusCode=cStatusInvalidField;
                    // }
                }

#if _EN_DisHMBInReset    // 20190805_Chief_DisHMB
                else if(gsHmbInfo.uHmbEnable||(gChkFlag&cEnableFakeHMB))
#else
                else if(gsHmbInfo.uHmbEnable)
#endif
                {
                    if(!mChkHandlePcieErrF)
                    {
#if _EN_FW_DEBUG_UART
                        NLOG(cLogTempDebug,
                             NVMECMDEXT_C,
                             2,
                             "nvmeSetFeature, mWaitHmbTransferDone!!!!!,rmHmbPrdQueTrigIdx=0x%04X, gsHmbInfo.uHmbHwPrdTail=0x%04X",
                             rmHmbPrdQueTrigIdx,
                             gsHmbInfo.uHmbHwPrdTail);
#endif
                        mWaitHmbTransferDone();
                    }

                    disableHmbFunc(cDisabled);    // LeverYu_0813 SMI S0813A  SQ mismatch issue
                }

#if !_EN_RAID_HMB
                if(gsHmbInfo.uHmbEnPtCache)
                {
                    gsHmbInfo.uHmbEnPtCache=cFalse;
                    gsGcInfo.uHmbEnPtCache=cFalse;    // for Core1 use.
                }
#endif
            }

            break;

        case cNvmeFeatTimerStamp:

            if(gsLightSwitch.usNvmeLs.uOncs&cTimeStampFeat)
            {
                u16StatusCode=nvmeSetFeatureAttribute((NVMEFEATURESEL *)&gpNvmeFeatVar->usFeat.usTimerStamp, rmNvmeCmdDw11, rmNvmeSv);

                if(u16StatusCode==cStatusSuccess)
                {
                    trigNonRWCmd(cTsb0StartBufIdx, 0x01, cTsb0, cNvmeWrite, cManualCq);
                    initTimestamp(g32arTsb0[0][0], g16arTsb0[0][2], cInitializedBySetFeature);
                }
            }
            else
            {
                u16StatusCode=cStatusInvalidField;
            }

            break;

        case cNvmeFeatHostThermalPwrMgmt:
#ifdef _SUPPORT_FEATURE_DITM    // 20181010_Jesse_01, Add for LENOVO "NVMe spec 1.26" DITT function
#if (OEM==LENOVO)
        case cNvmeFeatHdDITM:
#endif
#endif

            if(gsLightSwitch.usThermalLs.uThermalCtrl&cEnThrottle)
            {
                // check if MT1 is valid, MT1 is valid if
                // MT1 == 0 OR
                // (MT1 >= gparLS_NVMe->u16MNTMT) && (MT1 <= gparLS_NVMe->u16MXTMT)
                // zero means disable
                u16Tmt1=rmNvmeFeatHctmLight;
                u16Tmt2=rmNvmeFeatHctmHeavy;

                if(chkHctmValid(u16Tmt1, u16Tmt2))
                {
                    // u16StatusCode = nvmeSetFeatureAttribute((NVMEFEATURESEL *)&gpNvmeFeatVar->usFeat.usHostThermalPwrMgmt, rmNvmeCmdDw11,
                    // rmNvmeSv, u32NSID);
#ifdef _SUPPORT_FEATURE_DITM    // 20181010_Jesse_01, Add for LENOVO "NVMe spec 1.26" DITT function
#if (OEM==LENOVO)
// 20190313_Jesse_01, Add for LENOVO "NVMe spec 1.26" "Feature 0x10" == "Feature 0xD4(DITT)
                    // if(uFid==cNvmeFeatHdDITM)
                    if((uFid==cNvmeFeatHdDITM)||(uFid==cNvmeFeatHostThermalPwrMgmt))
                    {
                        // 3.MT1==0 or MT2==0 than return Good status & no change before data
                        if(u16Tmt1&&u16Tmt2)
                        {
                            u16StatusCode=
                                nvmeSetFeatureAttribute((NVMEFEATURESEL *)&gpNvmeFeatVar->usFeat.usDellHdDITM, rmNvmeCmdDw11, rmNvmeSv);

                            u16StatusCode=
                                nvmeSetFeatureAttribute((NVMEFEATURESEL *)&gpNvmeFeatVar->usFeat.usHostThermalPwrMgmt, rmNvmeCmdDw11, rmNvmeSv);
                        }
                    }
                    else
#endif
#endif/* ifdef _SUPPORT_FEATURE_DITM */
                    {
                        {
                            u16StatusCode=
                                nvmeSetFeatureAttribute((NVMEFEATURESEL *)&gpNvmeFeatVar->usFeat.usHostThermalPwrMgmt, rmNvmeCmdDw11, rmNvmeSv);
                        }
                    }
                }
                else
                {
                    u16StatusCode=cStatusInvalidField;
                }

#ifdef _SUPPORT_FEATURE_DITM    // 20181010_Jesse_01, Add for LENOVO "NVMe spec 1.26" DITT function
#if (OEM==LENOVO)
                // 1.Lenovo DITT set MT1&MT2 outer default than return "Good status"&"Current=default"
                // 2.MT1>MT2 abort(Check at chkHctmValid())
                // 3.MT1==0 or MT2==0 than return Good status & no change before data
// 20190313_Jesse_01, Add for LENOVO "NVMe spec 1.26" "Feature 0x10" == "Feature 0xD4(DITT)
                // if(uFid==cNvmeFeatHdDITM)
                if((uFid==cNvmeFeatHdDITM)||(uFid==cNvmeFeatHostThermalPwrMgmt))
                {
                    if((!u16Tmt1)||(!u16Tmt2))
                    {
                        u16Tmt1=gpNvmeFeatVar->usFeat.usDellHdDITM.u32Current>>16;
                        u16Tmt2=gpNvmeFeatVar->usFeat.usDellHdDITM.u32Current&0x0000FFFF;
                        u16StatusCode=cStatusSuccess;
                    }
                    else if(u16StatusCode==cStatusInvalidField)
                    {
                        if((u16Tmt1<=u16Tmt2)&&
                           ((u16Tmt1<gsLightSwitch.usNvmeLs.u16MnTmt)||(u16Tmt1>gsLightSwitch.usNvmeLs.u16MxTmt)
                            ||(u16Tmt2<gsLightSwitch.usNvmeLs.u16MnTmt)||(u16Tmt2>gsLightSwitch.usNvmeLs.u16MxTmt)))
                        {
                            u16Tmt1=gpNvmeFeatVar->usFeat.usDellHdDITM.u32Default>>16;
                            u16Tmt2=gpNvmeFeatVar->usFeat.usDellHdDITM.u32Default&0x0000FFFF;
                            u16StatusCode=cStatusSuccess;
                        }
                    }
                }
#endif/* if (OEM==LENOVO) */
#endif/* ifdef _SUPPORT_FEATURE_DITM */

                if(u16StatusCode==cStatusSuccess)
                {
                    // Before convert to Celsius, make sure MT1 is non-zero
                    if(u16Tmt1)
                    {
                        gMt1In=mChgKelvintoCelsius(u16Tmt1);
                        gMt1Out=gMt1In-gsLightSwitch.usThermalLs.uMt1FallDelta;
                    }
                    else
                    {
                        gMt1In=0;
                        gMt1Out=0;
                    }

                    // Before convert to Celsius, make sure MT2 is non-zero
                    if(u16Tmt2)
                    {
                        gMt2In=mChgKelvintoCelsius(u16Tmt2);
                        gMt2Out=gMt2In-gsLightSwitch.usThermalLs.uMt2FallDelta;
                    }
                    else
                    {
                        gMt2In=0;
                        gMt2Out=0;
                    }
                }
            }
            else    // Do not support this feature, return error
            {
                u16StatusCode=cStatusInvalidField;
            }

            break;

#ifdef _SUPPORT_FEATURE_DITM    // 20190201_Jesse_01, Add DITM function for Dell spec "ENG0013785_A01"
#if (OEM==DELL)
// 20190528_Jesse_01, Add for Dell 3D512G for Dell spec A02 DITM function
#if ((PRODUCT_NAME&0x0008)!=0x0008)
        case cNvmeFeatHdDITM:

            if(gsLightSwitch.usThermalLs.uThermalCtrl&cEnThrottle)
            {
                // check if MT1 is valid, MT1 is valid if
                // MT1 == 0 OR
                // (MT1 >= gparLS_NVMe->u16MNTMT) && (MT1 <= gparLS_NVMe->u16MXTMT)
                // zero means disable
                u16Tmt1=rmNvmeFeatHctmLight;
                u16Tmt2=rmNvmeFeatHctmHeavy;

                // if(u16Tmt1<=u16Tmt2)//u16Tmt1 & u16Tmt2 is idependent
                {
                    if(!(u16Tmt1)||((u16Tmt1>=gsLightSwitch.usNvmeLs.u16MnTmt)&&(u16Tmt1<=gsLightSwitch.usNvmeLs.u16MxTmt)))
                    {
                        u32CmdSpecific|=0x01;    // Accept MT1
                        gMt1In=mChgKelvintoCelsius(u16Tmt1);
                        gMt1Out=gMt1In-gsLightSwitch.usThermalLs.uMt1FallDelta;
                    }

                    if(!(u16Tmt2)||((u16Tmt2>=gsLightSwitch.usNvmeLs.u16MnTmt)&&(u16Tmt2<=gsLightSwitch.usNvmeLs.u16MxTmt)))
                    {
                        u32CmdSpecific|=0x02;    // Accept MT2
                        gMt2In=mChgKelvintoCelsius(u16Tmt2);
                        gMt2Out=gMt2In-gsLightSwitch.usThermalLs.uMt2FallDelta;
                    }

                    u32Cnt=rmNvmeCmdDw11;

                    if((u32CmdSpecific&0x03)==0x01)    // Only MT1 data OK
                    {
                        u32Cnt=((gpNvmeFeatVar->usFeat.usDellHdDITM.u32Current&0x0000FFFF)
                                |(u32Cnt&0xFFFF0000));
                    }
                    else if((u32CmdSpecific&0x03)==0x02)    // Only MT2 Data OK
                    {
                        u32Cnt=((gpNvmeFeatVar->usFeat.usDellHdDITM.u32Current&0xFFFF0000)
                                |(u32Cnt&0x0000FFFF));
                    }
                }

                // if(chkHctmValid(u16Tmt1, u16Tmt2))
                if(u32CmdSpecific&0x03)    // At least MT1 or MT2 one data OK
                {
                    // if(uFid==cNvmeFeatHdDITM)
                    // {
                    u16StatusCode=
                        // nvmeSetFeatureAttribute((NVMEFEATURESEL *)&gpNvmeFeatVar->usFeat.usDellHdDITM, rmNvmeCmdDw11, rmNvmeSv);
                        nvmeSetFeatureAttribute((NVMEFEATURESEL *)&gpNvmeFeatVar->usFeat.usDellHdDITM, u32Cnt, rmNvmeSv);
                    // }
                }

                // else
                // {
                // u16StatusCode=cStatusInvalidField;
                // }

                /*if(u16StatusCode==cStatusSuccess)
                   * {
                   *  // Before convert to Celsius, make sure MT1 is non-zero
                   *  if(u16Tmt1)
                   *  {
                   *      gMt1In=mChgKelvintoCelsius(u16Tmt1);
                   *      gMt1Out=gMt1In-gsLightSwitch.usThermalLs.uMt1FallDelta;
                   *  }
                   *  else
                   *  {
                   *      gMt1In=0;
                   *      gMt1Out=0;
                   *  }
                   *
                   *  // Before convert to Celsius, make sure MT2 is non-zero
                   *  if(u16Tmt2)
                   *  {
                   *      gMt2In=mChgKelvintoCelsius(u16Tmt2);
                   *      gMt2Out=gMt2In-gsLightSwitch.usThermalLs.uMt2FallDelta;
                   *  }
                   *  else
                   *  {
                   *      gMt2In=0;
                   *      gMt2Out=0;
                   *  }
                   * }*/
            }
            else    // Do not support this feature, return error
            {
                u16StatusCode=cStatusInvalidField;
            }

            if(u16StatusCode)
            {
                u32CmdSpecific=0;    // MT1 & MT2 data abort
            }
            break;
#endif/*#if ((PRODUCT_NAME&0x0008)!=0x0008)*/
#endif/* if (OEM==DELL)*/
#endif/* ifdef _SUPPORT_FEATURE_DITM */

#if _ENABLE_NVME_FEAT_NONOPPWRSTATE
        case cNvmeFeatNonOpPwrStateConfig:
            u16StatusCode=nvmeSetFeatureAttribute((NVMEFEATURESEL *)&gpNvmeFeatVar->usFeat.usNonOpPwrStateConfig,
                                                  rmNvmeNonOpPwrStateConfig,
                                                  rmNvmeSv);
            break;
#endif

#if _ENABLE_NVME_FEAT_SWPROGRESS
        case cNvmeFeatSwProgress:
            u16StatusCode=nvmeSetFeatureAttribute((NVMEFEATURESEL *)&gpNvmeFeatVar->usFeat.usSwProgress, rmNvmeSwProgressMaker, rmNvmeSv);
            break;
#endif

// #if (OEM==DELL)    // 20181010_Jesse_01, Add for Dell spec "ENG0013785_A01"
#if (_ENABLE_SCP_PLP)
#if (_ENABLE_SCP_PLP==_EN_SCP)
        case cNvmeFeatScp:
#elif (_ENABLE_SCP_PLP==_EN_PLP)
        case cNvmeFeatPlp:
#endif
            u16StatusCode=nvmeSetFeatureAttribute((NVMEFEATURESEL *)&gpNvmeFeatVar->usFeat.usPlpScp, rmNvmeScpEn, rmNvmeSv);

            if(u16StatusCode==cStatusFeatureNotNsSpecific)    // 20181224_Jesse_01,Modify for Dell platform XPS-9570
            {
                u16StatusCode=cStatusSuccess;    // cNvmeFeatScp feature bypass NSID checking
            }

            if(u16StatusCode==cStatusSuccess)
            {
                if(rmNvmeSv)
                {
                    if(gpNvmeFeatVar->usFeat.usPlpScp.u32SelSC&cSaveable)
                    {
                        // gScpEnable=rmNvmeScpEn;
                        if(rmNvmeScpEn)
                        {
                            mSetNvmeEnPlpScp;
                            rSysCtrl0[0x13A]|=cBit7;
                            NLOG(cLogHost, NVMECMDEXT_C, 0, " Enable_SCP_PLP(Save)");
                        }
                        else
                        {
                            mClrNvmeEnPlpScp;
                            rSysCtrl0[0x13A]&=~cBit7;
                            NLOG(cLogHost, NVMECMDEXT_C, 0, " Disable_SCP_PLP(Save)");
                        }

                        gpNvmeFeatVar->usFeat.usPlpScp.u32Saved=rmNvmeScpEn;
                        gpNvmeFeatVar->usFeat.usPlpScp.u32Current=rmNvmeScpEn;
                    }
                    else
                    {
                        u16StatusCode=cStatusFeatureIdUnSavable;
                    }
                }
                else
                {
                    if(gpNvmeFeatVar->usFeat.usPlpScp.u32SelSC&cChangeable)
                    {
                        // gScpEnable=rmNvmeScpEn;
                        if(rmNvmeScpEn)
                        {
                            mSetNvmeEnPlpScp;
                            rSysCtrl0[0x13A]|=cBit7;
                            NLOG(cLogHost, NVMECMDEXT_C, 0, " Enable_SCP_PLP(No Save)");
                        }
                        else
                        {
                            mClrNvmeEnPlpScp;
                            rSysCtrl0[0x13A]&=~cBit7;
                            NLOG(cLogHost, NVMECMDEXT_C, 0, " Disable_SCP_PLP(No Save)");
                        }

                        gpNvmeFeatVar->usFeat.usPlpScp.u32Current=rmNvmeScpEn;
                    }
                    else
                    {
                        u16StatusCode=cStatusFeatureUnChangable;
                    }
                }
            }
            break;
#endif/* if _ENABLE_SCP_PLP */
// #endif/* if (OEM==DELL) */

        default:
            u16StatusCode=cStatusInvalidField;
            break;
    }    /* switch */

    if(!u16StatusCode)
    {
        saveNvmeFeatInfo(cNotReadWpro);
    }
    else
    {
#ifdef _SUPPORT_FEATURE_DITM    // 20181010_Jesse_01, Add for Dell spec "ENG0013785_A01"
#if (OEM==DELL)
// 20190528_Jesse_01, Add for Dell 3D512G for Dell spec A02 DITM function
#if ((PRODUCT_NAME&0x0008)!=0x0008)
        if(uFid!=cNvmeFeatHdDITM)
#endif
#endif
#endif
        u32CmdSpecific=0;    // WD Jira-88
    }

#if (OEM==DELL)    // 20190201_Jesse_01, Add for Dell spec "ENG0013785_A01"
// 20190528_Jesse_01, Add for Dell 3D512G for Dell spec A02 DITM function
#if ((PRODUCT_NAME&0x0008)!=0x0008)
    if((uFid==cNvmeFeatHdDITM)||(uFid==cNvmeFeatScp))
    {
        u16StatusCode|=cStatusDoNotRetry;
    }
#endif
#endif

    manualCompletion(u16StatusCode, u32CmdSpecific, cNoRwCmd, 0);    // manual send completion, and pop next cmd
}    /* nvmeSetFeature */

void nvmeGetFeature()
{
    LWORD u32CmdSpecific=0, u32NsId=rmNvmeNsId, u32ApstSize;
    WORD u16StatusCode=cStatusSuccess;
    BYTE uXferCnt=0, uDataXfer=0, uTypeSel=0, uTmpSel=0, uFid=rmNvmeFid, uSel=rmNvmeSel;

    NLOG(cLogHost, NVMECMDEXT_C, 1, "  Get Features: FID=0x%02X, SEL=0x%02X ", (WORD)(uFid<<8|uSel));
    readWproPageCore0(cWproFeaturePg, cNvmeFeatSIdx, 0);

    if(uSel>cNvmeGetFeatSelSc)
    {
        u16StatusCode=cStatusInvalidField;
    }
    else if(uSel!=cNvmeGetFeatSelSc)
    {
        // if((uFid==cNvmeFeatLbaRange)||(uFid==cNvmeFeatErrRecovery)||(uFid==cNvmeFeatWriteAtomic))  // 20181206_SamHu_01 mark for GTP Spec X09
        if(uFid==cNvmeFeatLbaRange)
        {
            // 20181127_SamHu eDevx issue
            if((gsLightSwitch.usNvme2Ls.u32NamespaceNum==1)&&(u32NsId==cNamespaceAll))
            {
                u32NsId=1;
            }

            if((u32NsId>gsLightSwitch.usNvme2Ls.u32NamespaceNum)||(u32NsId==cNamespaceNotSpecific)
               ||    /*(!(gsNamespace.uActiveBitMap&cbBitTab[u32NsId-1]))*/ (!(gsNamespace.uActiveBitMap&
                                                                               cbBitTab[(BYTE)((u32NsId-1)&0x00000007)])))
            {
                u16StatusCode=cStatusInvalidNsFormat;
            }
        }
        else
        {
#ifdef _SUPPORT_FEATURE_DITM
#if (OEM==LENOVO)    // 20190108_SamHu_01 follow Lenovo Spec1.26 ignore the NSID
            if(uFid==cNvmeFeatHdDITM)
            {}
            else
#endif
#endif

            if((u32NsId!=cNamespaceAll)&&((u32NsId>gsLightSwitch.usNvme2Ls.u32NamespaceNum)
                                          ||((u32NsId!=cNamespaceNotSpecific)&&(!(gsNamespace.uActiveBitMap&cbBitTab[u32NsId-1])))))
            {
                u16StatusCode=cStatusInvalidNsFormat;
            }
        }
    }
    else    // cNvmeGetFeatSelSc
    {
        if((u32NsId!=cNamespaceAll)&&(u32NsId>gsLightSwitch.usNvme2Ls.u32NamespaceNum))
        {
            // u16StatusCode=cStatusInvalidField;
            u16StatusCode=cStatusInvalidNsFormat;    // 20190219_SamHu_02 Driver Master fail
        }
        else
        {
            u32NsId=1;    // To prevent use invalid array idx
        }
    }

    if(!u16StatusCode)
    {
        switch(uFid)
        {
            case cNvmeFeatArbitration:
                u32CmdSpecific=nvmeGetFeatureAttribute((NVMEFEATURESEL *)&gpNvmeFeatVar->usFeat.usArbitration, uSel);
                break;

            // Power Management move to nvmeAdminPM()
            // case cNvmeFeatPowerMgmt:
            //    break;

            case cNvmeFeatLbaRange:
#if (OEM==HP)
                // if(!u16StatusCode)
                // if(validatePrp(cValidPrp4kData))  //Check this will cause IOL 7.0b case5.4 fail, temporary mark
                // {
                //    u16StatusCode=cStatusInvalidPrpOffset;
                // }
                // else
                uDataXfer=1;
                uXferCnt=8;
#if 1
                u32CmdSpecific=nvmeGetFeatureAttribute((NVMEFEATURESEL *)&gpNvmeFeatVar->usFeat.usLbaRangeType[0], uSel);
                bopCopyRam(c32Tsb0SAddr,
                           (LWORD)&gpNvmeFeatVar->usLbaRangeTypeEntry[0],
                           sizeof(LBARANGETYPE),
                           cCopyTsb2Tsb|cBopWait);
#else    // 20181206_SamHu_01 mark for GTP Spec X09
                // u32CmdSpecific=nvmeGetFeatureAttribute((NVMEFEATURESEL *)&gpNvmeFeatVar->usFeat.usLbaRangeType[u32NsId-1], uSel);
                // bopCopyRam(c32Tsb0SAddr,
                //           (LWORD)&gpNvmeFeatVar->usLbaRangeTypeEntry[u32NsId-1],
                //           sizeof(LBARANGETYPE),
                //           cCopyTsb2Tsb|cBopWait);
#endif
#else/* if (OEM==HP) */
                u16StatusCode=cStatusInvalidField;    // 20181030_Jesse_01, Disable LBA Range Feature
#endif/* if (OEM==HP) */
                break;

            case cNvmeFeatTempThresh:
                uTmpSel=rmNvmeTempThresSel;    // bits 19:16 represent Threshold Temperature Select
                uTypeSel=rmNvmeTempThresType;    // bits 21:20 represent Threshold Type Select
                NLOG(cLogHost, NVMECMDEXT_C, 2, "TmpSel=0x%04X, TypeSel=0x%04X ", uTmpSel, uTypeSel);

                if(gsSmart.usCnt.u16FeatureFID4Cnt<0xFFFE)    // 20181224_temp add for debug
                {
                    gsSmart.usCnt.u16FeatureFID4Cnt++;
                }

#if _EN_FeatTempThresh_Return_Sensor1    // 20190411_SamHu_01
                if(uTmpSel>=cNumOfTempSensor)
                {
                    uTmpSel=0;

                    if(gsSmart.usCnt.u16FeatureFID4failCnt<0xFFFE)    // 20181224_temp add for debug
                    {
                        gsSmart.usCnt.u16FeatureFID4failCnt++;
                    }

                    NLOG(cLogHost,
                         NVMECMDEXT_C,
                         1,
                         "cNvmeFeatTempThresh StatusInvalidField gsSmart.usCnt.u16FeatureFID4failCnt=0x%04X",
                         gsSmart.usCnt.u16FeatureFID4failCnt);
                }
#endif

                if((uTypeSel<cNumOfTypeSensor)&&(uTmpSel<cNumOfTempSensor))    // maske sure the fileds are valid
                {
                    u32CmdSpecific=
                        nvmeGetFeatureAttribute((NVMEFEATURESEL *)&gpNvmeFeatVar->usFeat.usTemperatureThres[uTypeSel][uTmpSel], uSel);
                }
                else
                {
#if !_EN_FeatTempThresh_Debug    // temp add for debug _Chief_20181224
                    u16StatusCode=cStatusFeatureUnChangable;
#endif

                    if(gsSmart.usCnt.u16FeatureFID4failCnt<0xFFFE)    // 20181224_temp add for debug
                    {
                        gsSmart.usCnt.u16FeatureFID4failCnt++;
                    }

                    NLOG(cLogHost,
                         NVMECMDEXT_C,
                         1,
                         "cNvmeFeatTempThresh StatusInvalidField gsSmart.usCnt.u16FeatureFID4failCnt=0x%04X",
                         gsSmart.usCnt.u16FeatureFID4failCnt);
                }

                break;

            case cNvmeFeatErrRecovery:

                // if(!u16StatusCode)
#if 1
                u32CmdSpecific=nvmeGetFeatureAttribute((NVMEFEATURESEL *)&gpNvmeFeatVar->usFeat.usErrorRecovery[0], uSel);
#else    // 20181206_SamHu_01 mark for GTP Spec X09
                // u32CmdSpecific=nvmeGetFeatureAttribute((NVMEFEATURESEL *)&gpNvmeFeatVar->usFeat.usErrorRecovery[u32NsId-1], uSel);
#endif

                break;

            case cNvmeFeatVolatileWc:
                u32CmdSpecific=nvmeGetFeatureAttribute((NVMEFEATURESEL *)&gpNvmeFeatVar->usFeat.usVolatileWc, uSel);
                break;

            case cNvmeFeatNumQueues:
                u32CmdSpecific=nvmeGetFeatureAttribute((NVMEFEATURESEL *)&gpNvmeFeatVar->usFeat.usNumberOfQueues, uSel);

                if(uSel!=cNvmeGetFeatSelSc)
                {
                    u32CmdSpecific=(((cMaxIoSqCqCnt-1)<<16)|(cMaxIoSqCqCnt-1));
                }

                break;

            case cNvmeFeatIrqCoalesce:
                u32CmdSpecific=nvmeGetFeatureAttribute((NVMEFEATURESEL *)&gpNvmeFeatVar->usFeat.usIntCoalescing, uSel);
                break;

            case cNvmeFeatIrqConfig:

                if(rmNvmeFeatIntVecCfgIv<16)    // Supporting maximum of 16 vectors 0~15
                {
                    u32CmdSpecific=nvmeGetFeatureAttribute((NVMEFEATURESEL *)&gpNvmeFeatVar->usFeat.usIntVecCfg[rmNvmeFeatIntVecCfgIv], uSel);
                }
                else    // Exceed max vector, report error
                {
                    u16StatusCode=cStatusInvalidField;
                }

                break;

            case cNvmeFeatWriteAtomic:

                // if(!u16StatusCode)
#if 1
                u32CmdSpecific=nvmeGetFeatureAttribute((NVMEFEATURESEL *)&gpNvmeFeatVar->usFeat.usWriteAtomicityNormal[0], uSel);
#else    // 20181206_SamHu_01 mark for GTP Spec X09
                // u32CmdSpecific=nvmeGetFeatureAttribute((NVMEFEATURESEL *)&gpNvmeFeatVar->usFeat.usWriteAtomicityNormal[u32NsId-1], uSel);
#endif

                break;

            case cNvmeFeatAsyncEvent:
                u32CmdSpecific=nvmeGetFeatureAttribute((NVMEFEATURESEL *)&gpNvmeFeatVar->usFeat.usAsyncEventCfg, uSel);
                break;

            case cNvmeFeatAutoPst:

                if(gsLightSwitch.usNvmeLs.uApsta)
                {
                    // if(validatePrp(cValidPrpApst))  //Check this will cause IOL 7.0b case5.4 fail, temporary mark
                    // {
                    //    u16StatusCode=cStatusInvalidPrpOffset;
                    // }
                    // else
                    uDataXfer=1;
                    uXferCnt=0;    // (A) represent non sector based transfer type
                    u32ApstSize=sizeof(APSTTABLE)*gsLightSwitch.usNvmeLs.uNpss;
                    bopClrRam(c32Tsb0SAddr, sizeof(APSTTABLE)*32, 0x00000000, cBopWait|cClrTsb);
                    u32CmdSpecific=nvmeGetFeatureAttribute((NVMEFEATURESEL *)&gpNvmeFeatVar->usFeat.usAutoPst, uSel);

                    if(uSel==cNvmeGetFeatSelCurrent)
                    {
                        // bopCopyRam(c32Tsb0SAddr, (LWORD)&gpNvmeFeatVar->usApstEntry.uarCurrent, u32ApstSize, cCopyTsb2Tsb|cBopWait);
                        bopCopyRam(c32Tsb0SAddr, (LWORD)&garApstCurrent, u32ApstSize, cCopyDccm2Tsb|cBopWait);
                    }
                    else if(uSel==cNvmeGetFeatSelSaved)
                    {
                        bopCopyRam(c32Tsb0SAddr, (LWORD)&gpNvmeFeatVar->usApstEntry.uarSaved, u32ApstSize, cCopyTsb2Tsb|cBopWait);
                    }

                    // else    // cNvmeGetFeatSelDefault
                    // {
                    //    bopClrRam(c32Tsb0SAddr, sizeof(APSTTABLE)*32, 0x00000000, cBopWait|cClrTsb);
                    // }
                }
                else
                {
                    u16StatusCode=cStatusInvalidField;
                }

                break;

            case cNvmeFeatHostMemBuff:

                if(validatePrp(cValidPrp4kData))
                {
                    u16StatusCode=cStatusInvalidPrpOffset;
                }
                else
                {
                    bopClrRam(c32Tsb0SAddr, 4096, 0x00000000, cBopWait|cClrTsb);
                    uDataXfer=1;
                    uXferCnt=8;

#if _EN_DisHMBInReset    // 20190805_Chief_DisHMB
                    if(gsHmbInfo.uHmbEnable||(gChkFlag&cEnableFakeHMB))
#else
                    if(gsHmbInfo.uHmbEnable)
#endif
                    {
                        if((uSel!=cNvmeGetFeatSelDefault))
                        {
                            g32arTsb0[0][0]=gpNvmeFeatVar->usHmbHwInfo.u32ActiveSize;
                            g32arTsb0[0][1]=gpNvmeFeatVar->usHmbHwInfo.u32HmbDescListAddrLow;
                            g32arTsb0[0][2]=gpNvmeFeatVar->usHmbHwInfo.u32HmbDescListAddrHigh;
                            g32arTsb0[0][3]=gpNvmeFeatVar->usHmbHwInfo.u32HmbDescListEntryCnt;
                        }
                    }
                    else
                    {
                        // Hmb already disable in fw but not sync to wpro value
                        gpNvmeFeatVar->usFeat.usHostMemoryBuffer.u32Current=0;
                        gpNvmeFeatVar->usFeat.usHostMemoryBuffer.u32Saved=0;
                    }

                    u32CmdSpecific=nvmeGetFeatureAttribute((NVMEFEATURESEL *)&gpNvmeFeatVar->usFeat.usHostMemoryBuffer, uSel);
                }

                break;

            case cNvmeFeatTimerStamp:

                if(gsLightSwitch.usNvmeLs.uOncs&cTimeStampFeat)
                {
                    u32CmdSpecific=nvmeGetFeatureAttribute((NVMEFEATURESEL *)&gpNvmeFeatVar->usFeat.usTimerStamp, uSel);
                    updateTimestamp();
                    uDataXfer=1;
                }
                else
                {
                    u16StatusCode=cStatusInvalidField;
                }

                break;

            case cNvmeFeatHostThermalPwrMgmt:
#ifdef _SUPPORT_FEATURE_DITM    // 20181010_Jesse_01, Add for Dell spec "ENG0013785_A01"
// 20190528_Jesse_01, Add for Dell 3D512G for Dell spec A02 DITM function
#if (OEM==LENOVO)||((OEM==DELL)&&((PRODUCT_NAME&0x0008)!=0x0008))
            case cNvmeFeatHdDITM:
#endif
#endif

                if(gsLightSwitch.usThermalLs.uThermalCtrl&cEnThrottle)
                {
#ifdef _SUPPORT_FEATURE_DITM    // 20181010_Jesse_01, Add for Dell spec "ENG0013785_A01"
// 20190528_Jesse_01, Add for Dell 3D512G for Dell spec A02 DITM function
#if (OEM==LENOVO)||((OEM==DELL)&&((PRODUCT_NAME&0x0008)!=0x0008))
                    if(uFid==cNvmeFeatHdDITM)
                    {
                        u32CmdSpecific=nvmeGetFeatureAttribute((NVMEFEATURESEL *)&gpNvmeFeatVar->usFeat.usDellHdDITM, uSel);
                    }
                    else
#endif
#endif
                    u32CmdSpecific=nvmeGetFeatureAttribute((NVMEFEATURESEL *)&gpNvmeFeatVar->usFeat.usHostThermalPwrMgmt, uSel);
                }
                else
                {
                    u16StatusCode=cStatusInvalidField;
                }

                break;

#if _ENABLE_NVME_FEAT_NONOPPWRSTATE
            case cNvmeFeatNonOpPwrStateConfig:
                u32CmdSpecific=nvmeGetFeatureAttribute((NVMEFEATURESEL *)&gpNvmeFeatVar->usFeat.usNonOpPwrStateConfig, uSel);
                break;
#endif
#if _ENABLE_NVME_FEAT_SWPROGRESS
            case cNvmeFeatSwProgress:
                u32CmdSpecific=nvmeGetFeatureAttribute((NVMEFEATURESEL *)&gpNvmeFeatVar->usFeat.usSwProgress, uSel);
                break;
#endif
// #if (OEM==DELL)    // 20181010_Jesse_01, Add for Dell spec "ENG0013785_A01"
#if (_ENABLE_SCP_PLP)
#if (_ENABLE_SCP_PLP==_EN_SCP)
            case cNvmeFeatScp:
#elif (_ENABLE_SCP_PLP==_EN_PLP)
            case cNvmeFeatPlp:
#endif
                u32CmdSpecific=nvmeGetFeatureAttribute((NVMEFEATURESEL *)&gpNvmeFeatVar->usFeat.usPlpScp, uSel);
                break;
#endif
// #endif

            default:
                u16StatusCode=cStatusInvalidField;
                break;
        }    /* switch */
    }

    if(!u16StatusCode)
    {
        saveNvmeFeatInfo(cNotReadWpro);
    }
    else
    {
        u32CmdSpecific=0;    // WD Jira-88
    }

    if(uDataXfer)
    {
        trigNonRWCmd(cTsb0StartBufIdx, uXferCnt, cTsb0, cNvmeRead, cManualCq);
    }

    manualCompletion(u16StatusCode, u32CmdSpecific, cNoRwCmd, 0);    // manual send completion, and pop next cmd

// 20181224_SamHu_temp save for debug
    if(uFid==cNvmeFeatTempThresh)
    {
        saveSmartInfo(cReadWpro);
        NLOG(cLogHost,
             NVMECMDEXT_C,
             2,
             " GetFeature FID 04h Cnt=0x%04X, GetFeature FID 04h InvalidCnt=0x%04X ",
             (WORD)gsSmart.usCnt.u16FeatureFID4Cnt,
             (WORD)gsSmart.usCnt.u16FeatureFID4failCnt);
    }
}    /* nvmeGetFeature */

void nvmeFormat()
{
    LWORD u32NsId=rmNvmeNsId;
    WORD u16StatusCode=cStatusSuccess;
    BYTE uSes=rmNvmeFormatSes;

    NLOG(cLogHost,
         NVMECMDEXT_C,
         3,
         "  Format NVM: SES=0x%02X, PIL=0x%02X, PI=0x%02X, MSET=0x%02X, LBAF=0x%04X ",
         (WORD)(uSes<<8|rmNvmeFormatPil),
         (WORD)(rmNvmeFormatPi<<8|rmNvmeFormatMs),
         (WORD)rmNvmeFormatLbaf);

    if(gsLightSwitch.usNvmeLs.u16Oacs&cFormatCmd)
    {
        if(mChkDummyWrite)
        {
            mClrDummyWrite;
        }

        if(rmNvmeFormatPi    /*||rmNvmeFormatPil||*/)    // 20181129_SamHu_01 mark for Devx test
        {
            u16StatusCode=cStatusDoNotRetry|cStatusMore|cStatusInvalidFormat;
        }
        else if(uSes>0x2)
        {
            u16StatusCode=cStatusInvalidField;
        }
        else if((rmNvmeFormatLbaf!=0x0)||((uSes==0x2)&&(!gbEnAes)))
        {
            u16StatusCode=cStatusInvalidFormat;
        }
        else if((u32NsId==cNamespaceNotSpecific)||((u32NsId!=cNamespaceAll)&&
                                                   (u32NsId>gsLightSwitch.usNvme2Ls.u32NamespaceNum)))
        {
            u16StatusCode=cStatusInvalidNsFormat;
        }
    }

#if _ENABLE_ATA_PASSTHROUGH
    if(gbEnATAPassThrough)
    {
        if(rmChkSecurityLock||rmChkSecurityFrozen)    // rmChkSecurityFrozen is for liteon.
        {
            NLOG_SAVE(cLogSecApiBaseFw,
                      NVMECMDEXT_C,
                      1,
                      cSaveIdSecurity,
                      "  NVMeFormat(), ATA Security Locked, status = 0x%04X.",
                      gSecurityStatus);
            manualCompletion(cStatusCmdSequenceErr, 0, cNoRwCmd, 0);
            return;
        }
    }
#endif
#if _ENABLE_SECAPI
    if(gbEnTCG)
    {
        // M_ChkWriteLock is unnecessary : WriteLock only exists in Manufactured state
        if(gTcgNviSpLockingLifeCycleState==C_Manufactured)
        {
            NLOG_SAVE(cLogSecApiBaseFw,
                      NVMECMDEXT_C,
                      0,
                      cSaveIdSecurity,
                      "  NVMeFormat() abort, SP Life Cycle = Manufactured.");
            manualCompletion(cStatusInvalidFormat, 0, cNoRwCmd, 0);
            return;
        }
    }
#endif

    if(!u16StatusCode)
    {
        // Abort NVMe DST if in Progress
        // 20181211_SamHu_01
        if(((gsCurrDstResult.u32Nsid!=0)&&((u32NsId==gsCurrDstResult.u32Nsid)||(u32NsId==cNamespaceAll)))||
           ((gsCurrDstResult.u32Nsid==cNamespaceAll)&&(u32NsId)))

        {
            if(((gsCurrDstResult.uDstStatus>>4)==cOperationShortDstInProgress)||
               ((gsCurrDstResult.uDstStatus>>4)==cOperationExtendedDstInProgress))
            {
                if(!(gsCurrDstResult.uDstStatus&0x0F))
                {
                    gsCurrDstResult.uDstStatus|=cOperationAbortFormatNvmeCmd;
                }

                updateNvmeDstData(cReadWpro, cDstLogResultUpdate);
            }
        }

#if _EN_WUNCTable
        if(gsWUNCInfo.uWuncCnt)
        {
            for(BYTE uIdx=0; uIdx<C_MaxWUNCLAACnt; uIdx++)
            {
                gsWUNCInfo.uWuncCnt=0;
                gsWUNCInfo.u16HBlock[uIdx]=c16BitFF;
                gsWUNCInfo.u16HPage[uIdx]=c16BitFF;
                gsWUNCInfo.uBitMap[uIdx]=0;
            }

#if _EN_WuncInNand
            if(gsWproInfo.u16arWproIdxPagePtr[cWproWriteUNC]!=c16BitFF)
            {
                bopCopyRam(((LWORD)garTsb0[0]), (LWORD)&gsWUNCInfo, sizeof(gsWUNCInfo),
                           cCopyStcm2Tsb|cBopWait);
                progWproPageCore0(cWproWriteUNC, c16Tsb0SIdx);
            }
#endif
        }
#endif/* if _EN_WuncInNand */
#if _EN_E2ENonCRCChk    // Oscar_20190220
        if(gsWUNCInfo.uWZeroFlag)
        {
            gsWUNCInfo.uWZeroFlag=0;
            bopCopyRam(((LWORD)garTsb0[0]), (LWORD)&gsWUNCInfo, sizeof(gsWUNCInfo),
                       cCopyStcm2Tsb|cBopWait);
            progWproPageCore0(cWproWriteUNC, c16Tsb0SIdx);
        }
#endif

        if(uSes==0x00)    // return Zero Data // Clear Map
        {
            handleCore0VarErase();
            eraseUnitProcCore0(1);    // eraseUnitProcCore0(cBit2); 20190305_SamHu_01 temp set1
        }
        else if(uSes==0x01)    // return Zero Data // Clear Map, User Data
        {
            handleCore0VarErase();
            eraseUnitProcCore0(1);
        }

#if _ENABLE_SECAPI
        else if(uSes==0x02)    // Cryptographic Erase // Clear Map and AES Key
        {
            gInSecApi=1;    // for progCacheInfoTab();
            loadISPCodeCore0(cSecTsbBank, 3);
            SecAPI_NoticeSecCodeSwap(0);

            if(processCryptoErase())
            {
                u16StatusCode=cStatusDeviceErr;
            }

            SecAPI_NoticeSecCodeSwap(1);
            gInSecApi=0;

            if(!u16StatusCode)
            {
                handleCore0VarErase();
                eraseUnitProcCore0(1);    // eraseUnitProcCore0(cBit2); 20190305_SamHu_01 temp set1
            }
        }
#endif/* if _ENABLE_SECAPI */

        // debug purpose
        while(gsRwCtrl.u32FreeSrcFifoHead!=gsRwCtrl.u32FreeSrcFifoTail)
            ;

        while(gsRwCtrl.u32ProgFifoTail!=gsRwCtrl.u32ProgFifoHead)
            ;

        while(gsRwCtrl.u32UpdFifoPtr!=gsRwCtrl.u32ProgFifoHead)
            ;

        // while(gsHmbInfo.uHmbCache4kCnt)
        //    ;

        while(gsTskFifoCtrl.u32HeadPtr!=gsTskFifoCtrl.u32TailPtr)
            ;

#if _ENABLE_SECAPI
        if(gbSecAPIPendingPCIeReset||gbSecAPIPendingNSSR||gbSecAPIPendingInitATA||gbSecAPIClearATASecurityPrepare)
        {
            handleSecFlag();
        }
#endif
    }

    manualCompletion(u16StatusCode, 0, cNoRwCmd, 0);
}    /* nvmeFormat */

void nvmeDst()
{
    LWORD u32NsId=rmNvmeNsId;
    WORD u16StatusCode=cStatusSuccess;
    BYTE uStc=rmNvmeStc;

    if(gsLightSwitch.usNvmeLs.u16Oacs&cDeviseSelfTestCmd)
    {
        NLOG(cLogHost, NVMECMDEXT_C, 1, " NVMe Device Selt-test Command Received, Selt-Test Code=0x%04X ", uStc);

        if((u32NsId==cNamespaceAll)||(u32NsId==cNamespaceNotSpecific))
        {
            // Acceptable case
        }
        else if(u32NsId>gsLightSwitch.usNvme2Ls.u32NamespaceNum)
        {
            u16StatusCode=cStatusInvalidNsFormat;
        }
        else if(!(gsNamespace.uAllocatedBitMap&cbBitTab[u32NsId-1]))
        {
            u16StatusCode=cStatusInvalidField;
        }

        if(!u16StatusCode)
        {
            readWproPageCore0(cWproGetLogPg, cNvmeGetLogSIdx, 0);

            switch(uStc)
            {
                case cNvmeShortDst:
                case cNvmeExtendedDst:

                    if(gpGetLog->usDstLog.uCurrDstOperation==cOperationNoDstInProgress)
                    {
                        // For DST Result
                        bopClrRam((LWORD)&gsCurrDstResult, sizeof(gsCurrDstResult), 0x00000000, cBopWait|cClrCore0Dccm);
                        gsCurrDstResult.uDstStatus=(uStc<<4);
                        gsCurrDstResult.uSegmentNum=cSegment1RamCheck;
                        gsCurrDstResult.u32Nsid=u32NsId;    // 20181211_SamHu_01
                        gpGetLog->usDstLog.u32NvmeDstStartTimeMs=getRtcCurrentMs();
                        NLOG(cLogHost,
                             NVMECMDEXT_C,
                             2,
                             " NVMe Device Selt-test Start time at %08d ms ",
                             gpGetLog->usDstLog.u32NvmeDstStartTimeMs>>16,
                             gpGetLog->usDstLog.u32NvmeDstStartTimeMs);
                        updateNvmeDstData(cNotReadWpro, cDstLogProgressUpdate);
                    }
                    else if((gpGetLog->usDstLog.uCurrDstOperation==cOperationShortDstInProgress)||
                            (gpGetLog->usDstLog.uCurrDstOperation==cOperationExtendedDstInProgress))
                    {
                        u16StatusCode=cStatusDstInProgress;
                    }

                    break;

#if 0    // Just let this case drop to default case since it don't support now
                case cNvmeVendorSpecific:
                    u16StatusCode=cStatusInvalidField;
                    break;
#endif
                case cNvmeAbortDst:

                    if(gpGetLog->usDstLog.uCurrDstOperation==cOperationNoDstInProgress)
                    {
                        NLOG(cLogHost,
                             NVMECMDEXT_C,
                             0,
                             " NVMe Device Selt-Test Abort, No DST under Progress. ");
                    }
                    else
                    {
                        if(!(gsCurrDstResult.uDstStatus&0x0F))
                        {
                            // 20190326_Jesse_01,CL1-703,Modify for HP LinuxSTOR NVMEDeviceSelf_Secure_v1.001
#if (OEM==HP)
                            gsCurrDstResult.uDstStatus|=cOperationComletedNoError;
#else
                            gsCurrDstResult.uDstStatus|=cOperationAbortDstCmd;
#endif
                        }

                        NLOG(cLogHost,
                             NVMECMDEXT_C,
                             1,
                             " NVMe Device Selt-Test Abort, Current DST Operation=0x%04X ",
                             gpGetLog->usDstLog.uCurrDstOperation);
                        updateNvmeDstData(cNotReadWpro, cDstLogResultUpdate);
                    }

                    break;

                default:
                    u16StatusCode=cStatusInvalidField;
                    break;
            }    /* switch */
        }
    }
    else
    {
        u16StatusCode=cStatusInvalidOpCode;
    }

    manualCompletion(u16StatusCode, 0, cNoRwCmd, 0);
}    /* nvmeDst */

void handleDst()
{
    LWORD u32NvmeDstPeriodMs;
    BYTE uUpdateType=cDstLogResultUpdate;
    BYTE u8capacityIndex;
    WORD u16DstExtendedTime;

    readWproPageCore0(cWproGetLogPg, cNvmeGetLogSIdx, 0);
    u32NvmeDstPeriodMs=(getRtcCurrentMs()-gpGetLog->usDstLog.u32NvmeDstStartTimeMs);
// 20181206_SamHu_02
    u8capacityIndex=GetCapacityIndex();

    if(u8capacityIndex<=11)    // under 256GB 2min
    {
        u16DstExtendedTime=cDstExtendedTime_256;
    }
    else if(u8capacityIndex<=13)    // under 512GB 4min
    {
        u16DstExtendedTime=cDstExtendedTime_512;
    }
    else    // 8min
    {
        u16DstExtendedTime=cDstExtendedTime_1024;
    }

    if(gsCurrDstResult.uDstStatus&0x0F)
    {
        // Abort case
    }
    else if(((gpGetLog->usDstLog.uCurrDstOperation==cOperationShortDstInProgress)&&(u32NvmeDstPeriodMs>=cDstShortTime*1000))
            ||((gpGetLog->usDstLog.uCurrDstOperation==cOperationExtendedDstInProgress)&&(u32NvmeDstPeriodMs>=u16DstExtendedTime*1000)))
    {
        NLOG(cLogHost, NVMECMDEXT_C, 0, " ExtendedDst Finish ");
        gsCurrDstResult.uSegmentNum=cSegmentAllDone;
    }
    else
    {
        NLOG(cLogHost, NVMECMDEXT_C, 1, " NVMe Device Self-test Processing Segment=0x%04X ", gsCurrDstResult.uSegmentNum);
        getLogNvmeSmart(1);

        switch(gsCurrDstResult.uSegmentNum)
        {
            case cSegment1RamCheck:
                break;

            case cSegment2SmartCheck:

                if(gpGetLog->usSmartLog.uCriticalWarning)
                {
                    gpGetLog->usDstLog.uCurrDstFailBitMap|=cSegment2SmartCheckFail;
                }

                break;

            case cSegment3VolatileMemoryBackup:
                break;

#if 0    // Don't support meta data now
            case cSegment4MetadataValidation:
                gsCurrDstResult.uSegmentNum=cSegment5NvmIntegrity;
                break;
#endif
            case cSegment5NvmIntegrity:
                break;

            case cSegment6DataIntegrity:
                break;

            case cSegment7MediaCheck:
                break;

            case cSegment8DriveLife:

                if(gpGetLog->usSmartLog.uCriticalWarning&cSmartWarnReliability)
                {
                    gpGetLog->usDstLog.uCurrDstFailBitMap|=cSegment8DriveLifeFail;
                }

                break;

            case cSegment9SmartCheck:

                if(gpGetLog->usSmartLog.uCriticalWarning)
                {
                    gpGetLog->usDstLog.uCurrDstFailBitMap|=cSegment9SmartCheckFail;
                }

                break;

            case cSegmentAllDone:
                NLOG(cLogHost,
                     NVMECMDEXT_C,
                     3,
                     " NVMe Device Self-test Completed,  FailSegmentBitMap=0x%04X,  DSTPeriod=%08d ms ",
                     gpGetLog->usDstLog.uCurrDstFailBitMap,
                     u32NvmeDstPeriodMs>>16,
                     u32NvmeDstPeriodMs);
                break;

            default:
                break;
        }    /* switch */

        if(gsCurrDstResult.uSegmentNum!=cSegmentAllDone)
        {
            if(u32NvmeDstPeriodMs>gsCurrDstResult.uSegmentNum*10000)
            {
                if(gsCurrDstResult.uSegmentNum!=cSegment9SmartCheck)    // 20181211_SamHu_01
                {
                    gsCurrDstResult.uSegmentNum++;
                }
            }

            if(gsCurrDstResult.uSegmentNum==cSegment4MetadataValidation)
            {
                gsCurrDstResult.uSegmentNum=cSegment5NvmIntegrity;
            }
            else if((gsCurrDstResult.uSegmentNum==cSegment6DataIntegrity)&&
                    (gpGetLog->usDstLog.uCurrDstOperation==cOperationShortDstInProgress))
            {
                // Segment 6 Extended only
                gsCurrDstResult.uSegmentNum=cSegment7MediaCheck;
            }

            uUpdateType=cDstLogProgressUpdate;
        }
    }

    updateNvmeDstData(cNotReadWpro, uUpdateType);
}    /* handleDst */

void nvmeAsynEvent()
{
#if _ENABLE_NVME_LS
    if(gsNvmeAer.uAerQueueCnt>=(gsLightSwitch.usNvmeLs.uAerl+1))    // check if exceed limit
#else
    if(gsNvmeAer.uAerQueueCnt>=4)    // (gparLS_Nvme->uAERL +1))//check if exceed limit
#endif
    {
        NLOG(cLogHost, NVMECMDEXT_C, 0, "  AER exceed limit ");
        manualCompletion(cStatusAsyncEventExceeded, 0x00, cNoRwCmd, 0x00);
        return;
    }
    else
    {
        gsNvmeAer.uarAsyncQueue[gsNvmeAer.uAerQueueHead].u16SqId=rmNvmeSqId;
        gsNvmeAer.uarAsyncQueue[gsNvmeAer.uAerQueueHead].u16CqId=rmNvmeCqId;
        gsNvmeAer.uarAsyncQueue[gsNvmeAer.uAerQueueHead].u16Cid=rmNvmeCid;

        gsNvmeAer.uAerQueueCnt++;
#if _ENABLE_NVME_LS
        gsNvmeAer.uAerQueueHead=addPtrBy1(gsNvmeAer.uAerQueueHead, (gsLightSwitch.usNvmeLs.uAerl+1));    // AERL is 0 based value
#else
        gsNvmeAer.uAerQueueHead=addPtrBy1(gsNvmeAer.uAerQueueHead, 4);
#endif
        rmPopNextCmd;
    }
}    /* nvmeAsynEvent */

// New parsing method for Power State, call another resume function instead of this one while PS recover
BYTE getHmbDescList()
{
    NVMEHMBENTRY *upOriDesc, *upSortDesc, *upSwapDesc;
    LWORD u32Cnt, uSortCnt, u32Size;
    WORD u16SctrCnt;

    bopClrRam((LWORD)&gpNvmeFeatVar->usHmbHwInfo, sizeof(HMBHWDATA), 0x00000000, cBopWait|cClrTsb);

    gpNvmeFeatVar->usHmbHwInfo.u32HmbSize=rmNvmeCdw12;
    gpNvmeFeatVar->usHmbHwInfo.u32HmbDescListAddrLow=rmNvmeCdw13;
    gpNvmeFeatVar->usHmbHwInfo.u32HmbDescListAddrHigh=rmNvmeCdw14;
    gpNvmeFeatVar->usHmbHwInfo.u32HmbDescListEntryCnt=rmNvmeCdw15;

    if(gpNvmeFeatVar->usHmbHwInfo.u32HmbDescListEntryCnt>cHmbMaxDescEntryCnt)
    {
        gpNvmeFeatVar->usHmbHwInfo.u32HmbDescListEntryCnt=cHmbMaxDescEntryCnt;
    }

    if((gpNvmeFeatVar->usHmbHwInfo.u32HmbSize<<rmGetMps)<c16HmbMinSize)
    {
        NLOG(cLogHost, NVMECMDEXT_C, 0, " Hmb Enable Fail, HSIZE<MHMMIN.");
        return cFail;
    }
    else
    {
        NLOG(cLogHost, NVMECMDEXT_C, 2, "Hmb size=0x%08X", ((LWORD)gpNvmeFeatVar->usHmbHwInfo.u32HmbSize)>>16,
             ((LWORD)gpNvmeFeatVar->usHmbHwInfo.u32HmbSize));
    }

    u16SctrCnt=(gpNvmeFeatVar->usHmbHwInfo.u32HmbDescListEntryCnt>>5);

    if((WORD)gpNvmeFeatVar->usHmbHwInfo.u32HmbDescListEntryCnt&0x001F)
    {
        u16SctrCnt+=1;
    }

    trigNonRWCmd(cTsb0StartBufIdx, u16SctrCnt, cTsb0, cNvmeWrite, cManualCq|cHmbDescList);

    // Sorting
    upOriDesc=(void *)&g32arTsb0[0];
    upSortDesc=(void *)((LWORD)gpNvmeFeatVar+sizeof(NVMEFEATVAR));
    bopClrRam((LWORD)upSortDesc, 2*sizeof(NVMEHMBENTRY)*gpNvmeFeatVar->usHmbHwInfo.u32HmbDescListEntryCnt,
              0xFFFFFFFF, cBopWait|cClrTsb);
    bopCopyRam((LWORD)upSortDesc, (LWORD)upOriDesc, sizeof(NVMEHMBENTRY), cCopyTsb2Tsb|cBopWait);
    upOriDesc++;

    for(u32Cnt=1; u32Cnt<gpNvmeFeatVar->usHmbHwInfo.u32HmbDescListEntryCnt; u32Cnt++)
    {
        upSwapDesc=(void *)((LWORD)upSortDesc+sizeof(NVMEHMBENTRY)*gpNvmeFeatVar->usHmbHwInfo.u32HmbDescListEntryCnt);
        upSortDesc=(void *)((LWORD)gpNvmeFeatVar+sizeof(NVMEFEATVAR));
        bopCopyRam((LWORD)upSwapDesc, (LWORD)upSortDesc,
                   sizeof(NVMEHMBENTRY)*gpNvmeFeatVar->usHmbHwInfo.u32HmbDescListEntryCnt, cCopyTsb2Tsb|cBopWait);

        uSortCnt=0;

        while(uSortCnt<=u32Cnt)
        {
            if((upOriDesc->u32AddrHigh<upSortDesc->u32AddrHigh)
               ||((upOriDesc->u32AddrHigh==upSortDesc->u32AddrHigh)&&(upOriDesc->u32AddrLow<upSortDesc->u32AddrLow)))
            {
                bopCopyRam((LWORD)upSortDesc, (LWORD)upOriDesc, sizeof(NVMEHMBENTRY), cCopyTsb2Tsb|cBopWait);
                upSortDesc++;
                break;
            }

            upSortDesc++;
            upSwapDesc++;
            uSortCnt++;
        }

        while(uSortCnt<u32Cnt)
        {
            bopCopyRam((LWORD)upSortDesc, (LWORD)upSwapDesc, sizeof(NVMEHMBENTRY), cCopyTsb2Tsb|cBopWait);
            upSortDesc++;
            upSwapDesc++;
            uSortCnt++;
        }

        upOriDesc++;
    }

    // Range overlap & size check
    if(gpNvmeFeatVar->usHmbHwInfo.u32HmbDescListEntryCnt>1)
    {
        upSortDesc=(void *)((LWORD)gpNvmeFeatVar+sizeof(NVMEFEATVAR));
        upSwapDesc=(void *)((LWORD)upSortDesc+sizeof(NVMEHMBENTRY)*gpNvmeFeatVar->usHmbHwInfo.u32HmbDescListEntryCnt);
        u32Size=upSortDesc->u32Size;    // JIRA-40
        bopCopyRam((LWORD)upSwapDesc, (LWORD)upSortDesc, sizeof(NVMEHMBENTRY), cCopyTsb2Tsb|cBopWait);
        upSortDesc++;

        for(u32Cnt=1; u32Cnt<gpNvmeFeatVar->usHmbHwInfo.u32HmbDescListEntryCnt; u32Cnt++)
        {
            if((upSwapDesc->u32AddrHigh==upSortDesc->u32AddrHigh)&&
               ((upSwapDesc->u32AddrLow+(upSwapDesc->u32Size<<(rmGetMps+12)))>upSortDesc->u32AddrLow))
            {
                NLOG(cLogHost, NVMECMDEXT_C, 0, " Hmb Enable Fail, Descriptor Entry Memory OverLapping.");
                return cFail;
            }

            u32Size+=upSortDesc->u32Size;
            bopCopyRam((LWORD)upSwapDesc, (LWORD)upSortDesc, sizeof(NVMEHMBENTRY), cCopyTsb2Tsb|cBopWait);
            upSortDesc++;
        }
    }
    else
    {
        u32Size=upSortDesc->u32Size;    // JIRA 40
    }

    if((u32Size<<rmGetMps)<c16HmbMinSize)
    {
        NLOG(cLogHost, NVMECMDEXT_C, 0, " Hmb Enable Fail, Hmb not enough within 256 entry.");
        return cFail;
    }
    else
    {
        gpNvmeFeatVar->usHmbHwInfo.u32ActiveSize=u32Size;
    }

    gpNvmeFeatVar->usHmbHwInfo.uFixGroupSize=cSetFixGroupLLMSize;

    upSortDesc=(void *)((LWORD)gpNvmeFeatVar+sizeof(NVMEFEATVAR));

    for(u32Cnt=0; (u32Cnt<gpNvmeFeatVar->usHmbHwInfo.u32HmbDescListEntryCnt); u32Cnt++)
    {
        gpNvmeFeatVar->usHmbHwInfo.u32arDescEntryAddrLow[u32Cnt]=upSortDesc->u32AddrLow;
        gpNvmeFeatVar->usHmbHwInfo.u32arDescEntryAddrHigh[u32Cnt]=upSortDesc->u32AddrHigh;
        gpNvmeFeatVar->usHmbHwInfo.u32arDescEntrySize[u32Cnt]=upSortDesc->u32Size;
        upSortDesc++;
    }

    gpNvmeFeatVar->usHmbHwInfo.u16arDescNumInFixGroup[1]=gpNvmeFeatVar->usHmbHwInfo.u32HmbDescListEntryCnt;
    gpNvmeFeatVar->usHmbHwInfo.u32TotalFixGroupNumber=1;

    resumeHmbSetting(cNotReadWpro);
    NLOG(cLogHost, NVMECMDEXT_C, 0, " Hmb Enable success");

    return cSuccess;
}    /* getHmbDescList */

void handleAsyncEvent()
{
    NVMEAERDW0 u32AsynDw0;
    LWORD u32AerEvent=0;

    // Handle event once a time
    if(gsNvmeAer.uAerQueueCnt)
    {
        bopClrRam((LWORD)(BYTE *)&u32AsynDw0, sizeof(NVMEAERDW0), 0x00000000, cBopWait|cClrCore0Dccm);

        if(mChkSmartType)
        {
            u32AsynDw0.uAsyncEventType=cSmartHealthStatus;
            u32AsynDw0.uLogPageId=cLogSmartInfo;

            if(mChkAerSpare&&mChkAerSpareWarningEn)
            {
                u32AsynDw0.uAsyncEventInfo=cSpareBelowThreshold;
                mClrAerSpare;
                u32AerEvent=c32Bit8;
            }
            else if(mChkAerTemp&&mChkAerTempWarningEn)
            {
                u32AsynDw0.uAsyncEventInfo=cTemperatureThreshold;
                mClrAerTemp;
                u32AerEvent=c32Bit9;
            }
            else if(mChkAerReliability&&mChkAerReliabilityWarningEn)
            {
                u32AsynDw0.uAsyncEventInfo=cNvmSubssytemReliability;
                mClrAerReliability;
                u32AerEvent=c32Bit10;
            }
            else if(mChkAerReadOnly&&mChkAerReadOnlyWarningEn)
            {
                u32AsynDw0.uAsyncEventInfo=cNvmSubssytemReliability;
                mClrAerReadOnly;
                u32AerEvent=c32Bit11;
            }
            else if(mChkAerMemoryFail&&mChkAerMemoryFailWarningEn)
            {
                u32AsynDw0.uAsyncEventInfo=cNvmSubssytemReliability;
                mClrAerMemoryFail;
                u32AerEvent=c32Bit12;
            }

            mSetAerSmartTypeMask;
        }
        else if(mChkErrorType)
        {
            u32AsynDw0.uAsyncEventType=cErrorStatus;
            u32AsynDw0.uLogPageId=cLogErrInfo;

            if(mChkAerWriteInvalidDbReg)
            {
                u32AsynDw0.uAsyncEventInfo=cWriteToInvalidDoorBellReg;
                mClrAerWriteInvalidDbReg;
                u32AerEvent=c32Bit0;
            }
            else if(mChkAerInvalidDbWrite)
            {
                u32AsynDw0.uAsyncEventInfo=cInvalidDoorbellWriteVal;
                mClrAerInvalidDbWrite;
                u32AerEvent=c32Bit1;
            }
            else if(mChkAerTransientInternalErr)
            {
                u32AsynDw0.uAsyncEventInfo=cTransientInternalErr;
                mClrAerTransientInternalErr;
                u32AerEvent=c32Bit4;
            }

            mSetAerErrorTypeMask;
        }
        else if(mChkNoticeType)
        {
            u32AsynDw0.uAsyncEventType=cNotice;

            if(mChkAerFwActive)
            {
                u32AsynDw0.uLogPageId=cLogFwSlotInfo;
                u32AsynDw0.uAsyncEventInfo=cFwActivationStarting;
                mClrAerFwActive;
                u32AerEvent=c32Bit16;
            }
            else if(mChkAerTelemetryLog)
            {
                u32AsynDw0.uLogPageId=cLogTelemetryController;
                u32AsynDw0.uAsyncEventInfo=cTelemetryLogChanged;
                mClrAerTelemetryLog;
                u32AerEvent=c32Bit18;
            }

            mSetAerNoticeTypeMask;
        }
        else if(mChkIoType)
        {
            u32AsynDw0.uAsyncEventType=cIoCommandSetSpecificStatus;

            if(mChkAerSanitizeOperation)
            {
                u32AsynDw0.uLogPageId=cLogSanitize;
                u32AsynDw0.uAsyncEventInfo=cSanitizeLogPageAvailable;
                mClrAerSanitizeOperation;
                u32AerEvent=c32Bit25;
            }

            mSetAerIoTypeMask;
        }

        if(u32AerEvent)
        {
            manualCompletion(cStatusSuccess, *(LWORD *)&u32AsynDw0, cAsyncCmd, gsNvmeAer.uAerQueueTail);
            gsNvmeAer.uAerQueueCnt--;
            gsNvmeAer.uAerQueueTail=addPtrBy1(gsNvmeAer.uAerQueueTail, (gsLightSwitch.usNvmeLs.uAerl+1));
            // DebugLog(C_LOG_Sys, 0x10, 3, u32AerEvent, u32AsynDw0.AsyncEventInfo>>16, u32AsynDw0.AsyncEventInfo, 0, 0);//AER_SMART_Event
            // Type=0x%04X, DW0=0x%08X
        }
    }
}    /* handleAsyncEvent */

void nvmeNamespaceManagement()
{
    IDNAMESPACEDATA *upIdNsData;
    LWORD u32NsId=rmNvmeNsId;
    WORD u16StatusCode=cStatusSuccess, u32CmdSpecific=0;
    BYTE uCreateId;

    NLOG(cLogHost, NVMECMDEXT_C, 1, "  Namespace Management: SEL=0x%04X ", (WORD)rmNvmeSelect);

    if(gsLightSwitch.usNvmeLs.uFeatOption&cEnableNamespace)
    {
        switch(rmNvmeSelect)
        {
            case cNamespaceCreate:

                trigNonRWCmd(cTsb0StartBufIdx, 0x08, cTsb0, cNvmeWrite, cManualCq);
                upIdNsData=(void *)&g32arTsb0[0];

                // Always get the smallest Id first
                for(uCreateId=0; uCreateId<gsLightSwitch.usNvme2Ls.u32NamespaceNum; uCreateId++)
                {
                    if(!(gsNamespace.uAllocatedBitMap&cbBitTab[uCreateId]))
                    {
                        break;
                    }
                }

                if(upIdNsData->uNmic)    // 20181218_SamHu_02 modify for eDevx NNSMA18.a00
                {
                    u16StatusCode=cStatusInvalidField;
                }
                else if((!(upIdNsData->u32NszeH||upIdNsData->u32NszeL))
                        ||(((QWORD)upIdNsData->u32NcapH<<32|upIdNsData->u32NcapL)>
                           ((QWORD)upIdNsData->u32NszeH<<32|upIdNsData->u32NszeL)))
                {
                    u16StatusCode=cStatusInvalidField;
                }
                else if(upIdNsData->u32NszeH||(upIdNsData->u32NszeL>gsNamespace.u32UnvmCap)
                        ||upIdNsData->u32NcapH||(upIdNsData->u32NcapL>gsNamespace.u32UnvmCap))
                {
                    u16StatusCode=cStatusNsInsuffCap;
                }
                else if((gsNamespace.uAllocatedNsNumber+1)>gsLightSwitch.usNvme2Ls.u32NamespaceNum)
                {
                    u16StatusCode=cStatusNsIdUnavailable;
                }
                else if((upIdNsData->u32NszeH!=upIdNsData->u32NcapH)
                        ||(upIdNsData->u32NszeL!=upIdNsData->u32NcapL))
                {
                    u16StatusCode=cStatusNotSupportThinProvisioning;
                }
                // For OakGate test
                else if((upIdNsData->uFlbas||upIdNsData->uDps)&&
                        (!(((upIdNsData->uFlbas==0x10)&&(upIdNsData->uDps==0x08))||((upIdNsData->uFlbas==0x10)&&(upIdNsData->uDps==0x00))||
                           ((upIdNsData->uFlbas==0x00)&&(upIdNsData->uDps==0x08)))))
                {
                    u16StatusCode=cStatusInvalidField;
                }
                else
                {
                    // Normal case for no vendor command to declare total setting
                    if(uCreateId==0)    // NsId=1, use the LBA from the zero
                    {
                        if(gsNamespace.uAllocatedBitMap&cbBitTab[2])
                        {
                            if(upIdNsData->u32NcapL>gsNamespace.usInfo[2].u32StartLba)
                            {
                                u16StatusCode=cStatusNsInsuffCap;
                            }
                        }
                        else
                        {
                            gsNamespace.usInfo[0].u32StartLba=0;
                        }
                    }
                    else if(uCreateId==1)    // NsId=2, use the LBA to the tail
                    {
                        gsNamespace.usInfo[1].u32StartLba=(g32HostTotalDataSectorCnt-upIdNsData->u32NcapL);

                        if(gsNamespace.uAllocatedBitMap&cbBitTab[3])
                        {
                            if((gsNamespace.usInfo[3].u32StartLba+gsNamespace.usInfo[3].u32Size)>gsNamespace.usInfo[1].u32StartLba)
                            {
                                u16StatusCode=cStatusNsInsuffCap;
                            }
                        }
                    }
                    else if(uCreateId==2)    // NsId=3, use the LBA attach to NsId 0
                    {
                        gsNamespace.usInfo[2].u32StartLba=gsNamespace.usInfo[0].u32Size;
                    }
                    else if(uCreateId==3)    // NsId=4, use the LBA attach to NsId 3
                    {
                        gsNamespace.usInfo[3].u32StartLba=(gsNamespace.usInfo[3].u32StartLba-gsNamespace.usInfo[3].u32Size);
                    }
                    else
                    {
                        while(1)
                            ;// Over NN
                    }
                }

                if(!u16StatusCode)
                {
                    gsNamespace.uAllocatedBitMap|=cbBitTab[uCreateId];
                    gsNamespace.usInfo[uCreateId].u32Size=upIdNsData->u32NcapL;
                    gsNamespace.u32UnvmCap-=gsNamespace.usInfo[uCreateId].u32Size;
                    gsNamespace.uAllocatedNsNumber++;

                    u32CmdSpecific=(uCreateId+1);

                    readWproPageCore0(cWproFeaturePg, cNvmeFeatSIdx, 0);
                    bopClrRam((LWORD)&gpNvmeFeatVar->usLbaRangeTypeEntry[uCreateId],
                              (sizeof(LBARANGETYPE)*gsLightSwitch.usNvme2Ls.u32NamespaceNum),
                              0x00000000,
                              cBopWait|cClrTsb);
                    gpNvmeFeatVar->usLbaRangeTypeEntry[uCreateId][0].uAttribute=1;    // LBA range may be overwritten
                    gpNvmeFeatVar->usLbaRangeTypeEntry[uCreateId][0].u64Nlb=upIdNsData->u32NcapL;
                    progWproPageCore0(cWproFeaturePg, cNvmeFeatSIdx);
                }

                break;

            case cNamespaceDelete:

                if(u32NsId==cNamespaceAll)
                {
                    handleCore0VarErase();
                    eraseUnitProcCore0(1);    // eraseUnitProcCore0(cBit2); 20190305_SamHu_01 temp set1

                    bopClrRam((LWORD)&gsNamespace, sizeof(gsNamespace), 0x00000000, cBopWait|cClrTsb);
                    gsNamespace.u32UnvmCap=g32HostTotalDataSectorCnt;

                    readWproPageCore0(cWproFeaturePg, cNvmeFeatSIdx, 0);
                    bopClrRam((LWORD)(BYTE *)&gpNvmeFeatVar->usLbaRangeTypeEntry,
                              (sizeof(LBARANGETYPE)*cNamespaceMax*64),
                              0x00000000,
                              cBopWait|cClrTsb);
                    progWproPageCore0(cWproFeaturePg, cNvmeFeatSIdx);
                }
                else if((!u32NsId)||(u32NsId>gsLightSwitch.usNvme2Ls.u32NamespaceNum))
                {
                    u16StatusCode=cStatusInvalidNsFormat;
                }
                else if(!(gsNamespace.uAllocatedBitMap&cbBitTab[u32NsId-1]))
                {
                    u16StatusCode=cStatusInvalidField;
                }
                else
                {
                    enableLdpcPipe();
                    processTrim(cNvmeCmdNamespaceManagement);
                    disableLdpcPipe();

                    if(gsNamespace.uActiveBitMap&cbBitTab[u32NsId-1])
                    {
                        gsNamespace.uActiveBitMap&=~cbBitTab[u32NsId-1];
                        gsNamespace.uActiveNsNumber--;
                    }

                    gsNamespace.uAllocatedBitMap&=~cbBitTab[u32NsId-1];
                    gsNamespace.uAllocatedNsNumber--;
                    gsNamespace.u32UnvmCap+=gsNamespace.usInfo[u32NsId-1].u32Size;
                    gsNamespace.usInfo[u32NsId-1].u32StartLba=0;
                    gsNamespace.usInfo[u32NsId-1].u32Size=0;

                    if(!gsNamespace.uAllocatedNsNumber)
                    {
                        handleCore0VarErase();
                        eraseUnitProcCore0(1);    // eraseUnitProcCore0(cBit2); 20190305_SamHu_01 temp set1
                    }

                    readWproPageCore0(cWproFeaturePg, cNvmeFeatSIdx, 0);
                    bopClrRam((LWORD)&gpNvmeFeatVar->usLbaRangeTypeEntry[u32NsId-1],
                              sizeof(LBARANGETYPE),
                              0x00000000,
                              cBopWait|cClrTsb);
                    gpNvmeFeatVar->usLbaRangeTypeEntry[u32NsId-1][0].uAttribute=0;
                    gpNvmeFeatVar->usLbaRangeTypeEntry[u32NsId-1][0].u64Nlb=0;
                    progWproPageCore0(cWproFeaturePg, cNvmeFeatSIdx);

                    if(!(gsCurrDstResult.uDstStatus&0x0F))
                    {
                        gsCurrDstResult.uDstStatus|=cOperationAbortRemovalNamespace;
                    }
                }

                break;

            default:
                u16StatusCode=cStatusInvalidField;
                break;
        }    /* switch */

        if(!u16StatusCode)
        {
            progCacheInfoTab();
        }
    }
    else
    {
        u16StatusCode=cStatusInvalidOpCode;
    }

    manualCompletion(u16StatusCode, u32CmdSpecific, cNoRwCmd, 0);
}    /* nvmeNamespaceManagement */

void nvmeNamespaceAttachment()
{
    IDCONTROLLERLISTDATA *upIdContorllerList;
    LWORD u32NsId=rmNvmeNsId;
    WORD u16StatusCode=cStatusSuccess;
    BYTE uSelect=rmNvmeSelect;

    NLOG(cLogHost, NVMECMDEXT_C, 1, "  Namespace Attachment: SEL=0x%04X ", (WORD)uSelect);

    if(gsLightSwitch.usNvmeLs.uFeatOption&cEnableNamespace)
    {
        if(u32NsId==cNamespaceAll)
        {
            u16StatusCode=cStatusInvalidField;
        }
        else if((u32NsId>gsLightSwitch.usNvme2Ls.u32NamespaceNum)||(!u32NsId))
        {
            u16StatusCode=cStatusInvalidNsFormat;
        }
        else if(!(gsNamespace.uAllocatedBitMap&cbBitTab[u32NsId-1]))
        {
            u16StatusCode=cStatusInvalidField;
        }
        else if(validatePrp(cValidPrp4kData))
        {
            u16StatusCode=cStatusInvalidPrpOffset;
        }
        else
        {
            trigNonRWCmd(cTsb0StartBufIdx, 0x08, cTsb0, cNvmeWrite, cManualCq);
            upIdContorllerList=(void *)&g32arTsb0[0];

            if((upIdContorllerList->u16NumIdentifier!=cControllerNumber)||
               (upIdContorllerList->u16Idetifier[0]!=cControllerCurrId))
            {
                u16StatusCode=cStatusInvalidCtrlList;    // Only one controller now
            }
            else
            {
                switch(uSelect)
                {
                    case cNamespaceAttach:

                        if(gsNamespace.uActiveBitMap&cbBitTab[u32NsId-1])
                        {
                            u16StatusCode=cStatusNsAlrdyAttached;
                        }
                        else
                        {
                            gsNamespace.uActiveBitMap|=cbBitTab[u32NsId-1];
                            gsNamespace.uActiveNsNumber++;
                        }

                        break;

                    case cNamespaceDetach:

                        if(!(gsNamespace.uActiveBitMap&cbBitTab[u32NsId-1]))
                        {
                            u16StatusCode=cStatusNsNotAttached;
                        }
                        else
                        {
                            gsNamespace.uActiveBitMap&=~cbBitTab[u32NsId-1];
                            gsNamespace.uActiveNsNumber--;
                        }

                        break;

                    default:
                        u16StatusCode=cStatusInvalidField;
                        break;
                }    /* switch */

                progCacheInfoTab(cInhandleNamespace_00);
            }
        }
    }
    else
    {
        u16StatusCode=cStatusInvalidOpCode;
    }

    manualCompletion(u16StatusCode, 0, cNoRwCmd, 0);
}    /* nvmeNamespaceAttachment */

void nvmeAbort()
{
    LWORD u32CmdSpecific=cAbortFail;
    BYTE uHitTail=gsNvmeAer.uAerQueueTail, uAsyncQueueCnt=gsNvmeAer.uAerQueueCnt, uAerl=(gsLightSwitch.usNvmeLs.uAerl+1);

    NLOG(cLogHost, NVMECMDEXT_C, 2, "  Abort Command: CID=0x%04X, SQID=0x%04X ", (WORD)rmNvmeAbortCid, (WORD)rmNvmeAbortSqId);

    if(uAsyncQueueCnt&&(!rmNvmeAbortSqId))
    {
        while(uAsyncQueueCnt)
        {
            // (A) CSSD-4636, Oakgate, support abort Async
            if(rmNvmeAbortCid==gsNvmeAer.uarAsyncQueue[uHitTail].u16Cid)
            {
                manualCompletion(cStatusCmdAbortRq, 0, cAsyncCmd, uHitTail);    // manual send completion, and pop next cmd
                u32CmdSpecific=cAbortSuccess;
                break;
            }

            uHitTail=addPtrBy1(uHitTail, uAerl);
            uAsyncQueueCnt--;
        }

        if(u32CmdSpecific==cAbortSuccess)
        {
            while(uHitTail!=gsNvmeAer.uAerQueueTail)
            {
                // gsNvmeAer.uarAsyncQueue[uHitTail]=gsNvmeAer.uarAsyncQueue[subPtrBy1(uHitTail, uAerl)];    // copy previous one
                copyCcmVal((BYTE *)(&gsNvmeAer.uarAsyncQueue[uHitTail]), (BYTE *)(&gsNvmeAer.uarAsyncQueue[subPtrBy1(uHitTail, uAerl)]),
                           sizeof(ASYNCEVENTQUEUE));
                uHitTail=subPtrBy1(uHitTail, uAerl);
            }

            gsNvmeAer.uAerQueueTail=addPtrBy1(gsNvmeAer.uAerQueueTail, uAerl);
            gsNvmeAer.uAerQueueCnt--;
        }
    }

    manualCompletion(cStatusSuccess, u32CmdSpecific, cNoRwCmd, 0);
}    /* nvmeAbort */

void chkHmbEnbleFlag()
{
    gsHmbInfo.uHmbEnable=cTrue;
    gsHmbInfo.uHmbStsChg=cTrue;
    gsGcInfo.uHMBchg=cTrue;
    // gsE2eInfo.uHmbEnable=cTrue;    // for Core1 use.
#if 0    // 20190802_Louis
    if(gpNvmeFeatVar->usHmbHwInfo.u32ActiveSize==c16HmbPrefSize)
    {
        // gsHmbInfo.uHmbEnGcInfoCache=cTrue;
        // gsHmbInfo.uHmbEnWrCache=cTrue;
        // gsHmbInfo.uHmbEnRdCache=cTrue;
        gsHmbInfo.uHmbEnGcCache=cTrue;
        gsHmbInfo.uHmbEnPtCache=cTrue;
        gsGcInfo.uHmbEnGcCache=cTrue;    // for Core1 use.
        gsGcInfo.uHmbEnPtCache=cTrue;    // for Core1 use.
    }
#endif
}    /* chkHmbEnbleFlag */

void nvmeDirectiveSend()
{
    WORD u16StatusCode=cStatusSuccess;

    if(gsLightSwitch.usNvmeLs.u16Oacs&cDirectivesCmd)
    {
#if _ENABLE_STREAM
        if(rmNvmeDtype!=cDirectiveStream)
#endif
        {
            u16StatusCode=cStatusInvalidField;
        }
    }
    else
    {
        u16StatusCode=cStatusInvalidOpCode;
    }

    manualCompletion(u16StatusCode, 0, cNoRwCmd, 0);
}    /* nvmeDirectiveSend */

void nvmeDirectiveRece()
{
    IDENDIRECTIVE *upIdenDireRec;
    WORD u16StatusCode=cStatusSuccess;

    if(gsLightSwitch.usNvmeLs.u16Oacs&cDirectivesCmd)
    {
        if(rmNvmeNsId==cNamespaceAll)
        {
            u16StatusCode=cStatusInvalidField;
        }
        else
        {
            bopClrRam((LWORD)(BYTE *)&g32arTsb0[0], 4096, 0x00000000, cBopWait|cClrTsb);

            upIdenDireRec=(void *)&g32arTsb0[0];
            upIdenDireRec->uDirectiveSupport=cIdenDireSupport;
            upIdenDireRec->uDirectiveEnable=cIdenDireEnable;
#if _ENABLE_STREAM
            upIdenDireRec->uDirectiveSupport|=cStreamDireSupport;
#endif
        }
    }
    else
    {
        u16StatusCode=cStatusInvalidOpCode;
    }

    if(u16StatusCode)
    {
        manualCompletion(u16StatusCode, 0, cNoRwCmd, 0);
    }
    else
    {
        trigNonRWCmd(cTsb0StartBufIdx, 0x08, cTsb0, cNvmeRead, cAutoCq);
    }
}    /* nvmeDirectiveRece */

void updateTimestamp()
{
    LWORD u32TimestampNow=getRtcCurrentMs();
    QWORD u64TimestampTemp=(((QWORD)gpNvmeFeatVar->usTimestamp.u16TimestampHigh<<32)+gpNvmeFeatVar->usTimestamp.u32TimestampLow+
                            u32TimestampNow-gpNvmeFeatVar->usTimestamp.u32LastTimestamp);

    if(u64TimestampTemp>cTimestampMax)
    {
        u64TimestampTemp=u64TimestampTemp-cTimestampMax;
    }

    gpNvmeFeatVar->usTimestamp.u32TimestampLow=u64TimestampTemp;
    gpNvmeFeatVar->usTimestamp.u16TimestampHigh=(u64TimestampTemp>>32);
    gpNvmeFeatVar->usTimestamp.u32LastTimestamp=u32TimestampNow;
    NLOG(cLogHost, NVMECMDEXT_C, 3, " Current TimeStamp = 0x%04X%04X%04X", u64TimestampTemp>>32, u64TimestampTemp>>16, u64TimestampTemp, 0);
}

#if (!_ICE_LOAD_ALL)
#pragma default_function_attributes =
#endif







