







#include "inc/ProType.h"
// #include "inc/FlashCtrl.h"
#include "inc/GlobVar1.h"
#include "inc/GlobVarS.h"
#include "inc/GlobVarT.h"
#include "inc/Reg.h"
#include "inc/FtlCtrl.h"
#include "inc/BitDef.h"
// #include "inc/Mac.h"
#if (C_Log_SaveMask&C_Debug_P2)    // 20181031_Bill FTL Spr
#include "inc/DebugLog.h"
#include "inc/EventLogIDX.h"
#include "inc/EventLogFunctionIDX.h"
#endif

LWORD erasedDiffType2Blk(WORD u16Fblock)
{
    ADDRINFO usTmpAddrInfo;
    LWORD u32EraseFail=0;
    BYTE uCh, uIntlvIdx, uPlaneIdx;
    WORD u16PostEraseCmd;

    for(uPlaneIdx=0; uPlaneIdx<gPlaneNum; uPlaneIdx++)
    {
        u16PostEraseCmd=0;

        for(uCh=0; uCh<gTotalChNum; uCh++)
        {
            for(uIntlvIdx=0; uIntlvIdx<gIntlvWay; uIntlvIdx++)
            {
                getDiffAddr2(&usTmpAddrInfo, u16Fblock, uCh, uIntlvIdx, uPlaneIdx);
                setFLAddrActCh(usTmpAddrInfo.uCh, &usTmpAddrInfo);
                g16AbstrFBlock=usTmpAddrInfo.u16FBlock;
                g16FBlock=u16Fblock;

                // while(usTmpAddrInfo.uCh!=uCh);

                if(mChkBitMask(u16PostEraseCmd, usTmpAddrInfo.uCh*gIntlvWay+usTmpAddrInfo.uIntlvAddr))
                {
                    // this channel intlvway has send Erase Cmd

                    waitChCeBz(usTmpAddrInfo.uCh, usTmpAddrInfo.uIntlvAddr, 0);
                    mWaitCmdFifoBz;

                    if(rmChkStatusFail)
                    {
                        rmResetEccSts;    // Status fail can happen in both plane
                        rmCmdQueResume;
                        sysDelay(16);    // wait cmd fifo resume
                        u32EraseFail|=(cBit0<<((uCh*gIntlvWay+uIntlvIdx)*gPlaneNum+uPlaneIdx));
                        mWaitCmdFifoBz;
                        // debugLoop();
                    }
                }

                flashErase(c16Bit2|c16Bit14|c16Bit15);    // 1plane erase
                mSetBitMask(u16PostEraseCmd, usTmpAddrInfo.uCh*gIntlvWay+usTmpAddrInfo.uIntlvAddr);
            }
        }

        for(uCh=0; uCh<gTotalChNum; uCh++)
        {
            for(uIntlvIdx=0; uIntlvIdx<gIntlvWay; uIntlvIdx++)
            {
                getDiffAddr2(&usTmpAddrInfo, u16Fblock, uCh, uIntlvIdx, uPlaneIdx);
                setFLAddrActCh(usTmpAddrInfo.uCh, &usTmpAddrInfo);
                g16AbstrFBlock=usTmpAddrInfo.u16FBlock;
                g16FBlock=u16Fblock;

                if(mChkBitMask(u16PostEraseCmd, usTmpAddrInfo.uCh*gIntlvWay+usTmpAddrInfo.uIntlvAddr))
                {
                    waitChCeBz(usTmpAddrInfo.uCh, usTmpAddrInfo.uIntlvAddr, 0);
                    mWaitCmdFifoBz;

                    if(rmChkStatusFail)
                    {
                        rmResetEccSts;    // Status fail can happen in both plane
                        rmCmdQueResume;
                        sysDelay(16);    // wait cmd fifo resume
                        u32EraseFail|=(cBit0<<((uCh*gIntlvWay+uIntlvIdx)*gPlaneNum+uPlaneIdx));
                        mWaitCmdFifoBz;
                        // debugLoop();
                    }

                    mClrBitMask(u16PostEraseCmd, usTmpAddrInfo.uCh*gIntlvWay+usTmpAddrInfo.uIntlvAddr);
                }
            }

#if (!_EN_EraseFail)
            rmEnStsFailStop;
            u32EraseFail=0;
#if _PWSample
            rmDisStsFailStop;
#endif
#endif
        }
    }

    if(mGetGlobEraseCnt(u16Fblock)<c16BitFF)
    {
        g16arGlobEraseCnt[u16Fblock]++;
    }

    if(u32EraseFail!=0)
    {
        // setEraseBadBlock(u16Fblock, u32EraseFail);
        // g16TotalEraseFailCount++;
    }
    else
    {
#if (!_BypassEraseFlag)
        mClrEraseFlag(u16Fblock);
#endif
    }

    return u32EraseFail;
}    /* erasedDiffType2Blk */

/*
   * BYTE popSysSprBlkIdx()
   * {
   *  BYTE uDoneFlag= 0;
   *  WORD u16DebugSearchCnt= 0;
   *
   *  while(!uDoneFlag)
   *  {
   *      if(gsSysRsvInfo.uNextPopIndex==garSpareRegion[cSysSprEnd])
   *      {
   *          gsSysRsvInfo.uNextPopIndex= garSpareRegion[cSysSprStart];
   *      }
   *      else
   *      {
   *          gsSysRsvInfo.uNextPopIndex++;
   *      }
   *
   *      if(mChkSprAvaiBit(gsSysRsvInfo.uNextPopIndex))
   *      {
   *          //for skip bad block case and check avaiable System spare block
   *          uDoneFlag= 1;
   *      }
   *
   *      u16DebugSearchCnt++;
   *
   *      if(u16DebugSearchCnt>256)
   *      {
   *          debugDeadLock(0x0018); //no system spare block or existing code bug
   *      }
   *  }
   *
   *  mClrSprAvaiBit(gsSysRsvInfo.uNextPopIndex);
   *  return gsSysRsvInfo.uNextPopIndex;
   * }
   */
BYTE popSysSprBlkIdx()
{
    BYTE uDiff=0, uLoop;
    BYTE uMin=0xFF, uMinIdx, uClosestIdx=0xFF, uCloseAddrDiff=0xFF;

    uLoop=cSysBlockSpare0;

    while(uLoop<=cSysBlockSpare1)
    {
        if(uLoop!=gsFwDlInfo.uSysRsvFwDlImageBlk)
        {
            if((garSysBlock[cSysBlockIdx]<garSysBlock[uLoop]))
            {
                if((garSysBlock[cSysBlockIdx]+1)==garSysBlock[uLoop])
                {
                    uClosestIdx=uLoop;
                    break;
                }
                else
                {
                    uDiff=garSysBlock[uLoop]-garSysBlock[cSysBlockIdx];

                    if(uDiff<uCloseAddrDiff)
                    {
                        uCloseAddrDiff=uDiff;

                        uClosestIdx=uLoop;
                    }
                }
            }

            if(garSysBlock[uLoop]<uMin)
            {
                uMin=garSysBlock[uLoop];
                uMinIdx=uLoop;
            }
        }

        uLoop++;
    }

    if(uLoop==(cSysBlockSpare1+1))
    {
        uClosestIdx=uMinIdx;
    }

/*
   *  if(uClosestIdx==gsFwDlInfo.uSysRsvFwDlImageBlk)    // Skip the FFU used blk
   *  {
   *      uLoop=cSysBlockSpare0;
   *
   *      while(uLoop<=cSysBlockSpare1)
   *      {
   *          if(garSysBlock[uLoop]!=gsFwDlInfo.uSysRsvFwDlImageBlk)
   *          {
   *              uClosestIdx=garSysBlock[uLoop];
   *              break;
   *          }
   *
   *          uLoop++;
   *      }
   *  }
   */
    return uClosestIdx;
}    /* popSysSprBlkIdx */

// uOpt bit0-1 use specific System Block idx
void initErasedSysSprBlk(BYTE uNumOfSysBlk, BYTE uOpt)
{
    ADDRINFO usTmpAddrInfo;
    BLKSPRINFO usBlkSprInfo;
    WORD u16SysEraseCnt=0;
    BYTE uSysBlkIdx, uDone;

    uDone=0;

    ctrlOnesCntStop(0);

    while(!uDone)
    {
        if(uOpt&cBit0)
        {
            uSysBlkIdx=uNumOfSysBlk;
        }
        else
        {
            uSysBlkIdx=popSysSprBlkIdx();

            while(garSysBlock[uNumOfSysBlk]==garSysBlock[uSysBlkIdx])
                ;
        }

        tranRsvBlkAddr(garSysBlock[uSysBlkIdx], &usTmpAddrInfo);
        // tranCeNum(&usTmpAddrInfo);
        setFLAddrActCh(usTmpAddrInfo.uCh, &usTmpAddrInfo);
        waitChCeBz(usTmpAddrInfo.uCh, usTmpAddrInfo.uIntlvAddr, cNoOp);

        // => Read this Block fomer erase counts
        usTmpAddrInfo.u16FPage=0;
        gSectorH=0;
        mSetFRwParam(0, 0, c16Bit5|c16Bit10|c16Bit15, cReadData);
        flashReadPage();

        // manual judge ecc fail
        waitCmdFifoDpt(usTmpAddrInfo.uCh, &usTmpAddrInfo);

        if(rmChkUNC)
        {
            ctrlAuxQue(cIntoAuxQue);
            ctrlAuxQue(cOutAuxQue);
        }
        else
        {
            getSprByte(&usBlkSprInfo, usTmpAddrInfo.uPlaneAddr);
            u16SysEraseCnt=usBlkSprInfo.u16Spr11.u16all;    // u16SysEraseCnt=usBlkSprInfo.u16EraseCnt;
        }

        // => Erase This Block for System using
        flashErase(c16Bit15|c16Bit14|c16Bit3);    // 1plane erase
        rFLCtrl[rcStsFailMask]|=cBit2;    // Chronos BICS3 SLC Block using Bit2
        rmCeOn(mGetCEAddr(usTmpAddrInfo.uIntlvAddr));
        pollStatus(cPollMaskNor);
        rmAllCeOff;
        mWaitCmdFifoBz;    // add mark if erase fail
        rFLCtrl[rcStsFailMask]&=~(cBit0);    // |cBit2);

        if(rmChkStatusFail)
        {
            rmResetEccSts;    // Status fail
            rmCmdQueResume;
        }
        else
        {
            uDone=1;
        }
    }

    uDone=garSysBlock[uNumOfSysBlk];    // as temp variable
    garSysBlock[uNumOfSysBlk]=garSysBlock[uSysBlkIdx];
    garSysBlock[uSysBlkIdx]=uDone;

    NLOG(cLogTempDebug, SPRBLK_C, 1, " initErasedSysSprBlk uSysBlkIdx=0x%04X ", (WORD)uNumOfSysBlk);

    while(uDone==0xFF)
        ;// debug

    g16arCurrSysBlkEsCnt[uNumOfSysBlk]=u16SysEraseCnt+1;    // should modify

    ctrlOnesCntStop(cBit0|cBit1);

    if(!(uOpt&cBit0))
    {
        NLOG(cLogHost,
             SPRBLK_C,
             4,
             " garSysBlock: 0x%02X 0x%02X 0x%02X 0x%02X 0x%02X 0x%02X 0x%02X 0x%02X ",
             (WORD)(garSysBlock[cSysBlock1stInfo]<<8|garSysBlock[cSysBlock2ndInfo]),
             (WORD)(garSysBlock[cSysBlockMPInfo]<<8|garSysBlock[cSysBlockIsp]),
             (WORD)(garSysBlock[cSysBlockLog]<<8|garSysBlock[cSysBlockIdx]),
             (WORD)(garSysBlock[cSysBlockSpare0]<<8|garSysBlock[cSysBlockSpare1]));
    }
}    /* initErasedSysSprBlk */

LWORD eraseBlockProc(WORD u16Fblock, BYTE uPopOpt)
{
    ADDRINFO usTmpAddrInfo;
    LWORD u32EraseFail=0;
    WORD u16ReliableErase=0;

/*
   #if _EN_Dynamic_Fix_Boundary
   *  WORD u16SLCblock;
   #endif
   */

    usTmpAddrInfo.u16FBlock=u16Fblock;

    // tranCeNum(&usTmpAddrInfo);
    if(!(uPopOpt&cPopSkipErsCmd))
    {
        waitAllChCeBz();

        if(!mChkMlcMoBit(u16Fblock)&&(uPopOpt&cPopSlcBlock))
        {
            u16ReliableErase=c16Bit3;
        }

#if (_GREYBOX)
        chkGreyBoxStu();
#endif

        for(gActiveCh=0; gActiveCh<gTotalChNum; gActiveCh++)
        {
            setFLAddrActCh(gActiveCh, &usTmpAddrInfo);
            // if(uPopOpt&cPopSlcBlock)
            // {
            flashErase(c16Bit2|c16Bit15|u16ReliableErase);
            // }
            // else
            // {
            //    flashErase(c16Bit2|c16Bit13|c16Bit15);
            // }
        }

        if(mGetGlobEraseCnt(u16Fblock)<c16BitFF)
        {
            g16arGlobEraseCnt[u16Fblock]++;
        }
    }

    if(!(uPopOpt&cPopSkipChkSts))
    {
        for(gActiveCh=0; gActiveCh<gTotalChNum; gActiveCh++)
        {
            setFLAddrActCh(gActiveCh, &usTmpAddrInfo);
            u32EraseFail|=((LWORD)(chkEraseStatus())<<(gActiveCh*cMaxIntlvWay));    // 4Ch*8Way
        }

#if (_GREYBOX)

        if((gsGbInfo.uGreyBoxItem==cErrHdlEraseFID)&&(g16GbFBlock==0))
        {
            if(u32EraseFail==0)
            {
                u32EraseFail=1;
                g16GbFBlock=u16Fblock;
            }
            else
            {
                g16GbFBlock=u16Fblock;
            }
        }
        else if((gsGbInfo.uGreyBoxItem==cUGSDonEraseFail)&&(gsGbInfo.uStag==cVsIdl)&&
                ((gsGbInfo.uGreyBoxOpt==cVOpPopCacheSlcAfErase)||(gsGbInfo.uGreyBoxOpt==cVOpPopH2fTableAfErase)||
                 (gsGbInfo.uGreyBoxOpt==cVOpPopWPROIDAfErase))&&(g16GbFBlock==0))
        {
            if(gsGbInfo.u32BkValue==cFail)
            {
                u32EraseFail=1;
                gsGbInfo.uStag=cVsTriggered;
            }
            else if((gsGbInfo.u32BkValue&c32Bit1)&&(gsGbInfo.u32BkValue&c32Bit0))
            {
                u32EraseFail=1;
                g16GbFBlock=u16Fblock;
            }

            chkGreyBoxStu();
        }
#endif/* if (_GREYBOX) */
#if _EN_ValidationMode

        // if ((gInjectMode == 0x04)&&(g16FBlock == g16InjectFBlock)&&(gActiveCh == gInjectCh)&&(gIntlvAddr == gInjectIntlv)&&(gPlaneAddr ==
        // gInjectPlane)) //Inject EF
        if(gInjectMode==cInjectEF)
        {
            /* Send out debug of message for fail in erase */
            // sendDebugAddr(&usTmpAddrInfo);
            /* Reset Inject mode */
            gInjectMode=0;

            /* Mark fake fail in erase */
            u32EraseFail=1;
            setEraseBadBlock(u16Fblock, u32EraseFail);
            // setPartialEraseFailCount(u32EraseFail);
            g16TotalEraseFailCount++;
        }
        else
#else/* if _EN_ValidationMode */

        if(u32EraseFail!=0)
        {
            setEraseBadBlock(u16Fblock, u32EraseFail);
            // g16TotalEraseFailCount++;
        }
        else
#endif/* if _EN_ValidationMode */
        {
#if (!_BypassEraseFlag)
            mClrEraseFlag(u16Fblock);
#endif
        }

        if(!u32EraseFail)
        {
#if (_EN_SLC_END_PARA)

            if((u16Fblock<g16StaticBound)&&(mGetGlobEraseCnt(u16Fblock)>g32SlcMaxEraseCnt))
            {
                g32SlcMaxEraseCnt=mGetGlobEraseCnt(u16Fblock);

                while(gsCacheInfo.u32SlcNextEraseCntThr==0)
                    ;

                if(g32SlcMaxEraseCnt>gsCacheInfo.u32SlcNextEraseCntThr)
                {
                    setSlcEndurPara();
                }
            }
            else if((u16Fblock>=g16StaticBound)&&(mGetGlobEraseCnt(u16Fblock)>g32TlcMaxEraseCnt))
            {
                g32TlcMaxEraseCnt=mGetGlobEraseCnt(u16Fblock);
            }
#endif/* if (_EN_SLC_END_PARA) */

            if(uPopOpt&cPopSlcBlock)
            {
                mClrMlcMoBit(u16Fblock);
            }
            else
            {
                mSetMlcMoBit(u16Fblock);
            }

            mSetPoppedBit(u16Fblock);

#if !_EN_Always_DynamicMode

            if(!mChkMlcMoBit(u16Fblock))
            {
                gsCacheInfo.u16SpareBlockCnt--;
            }
            else
            {
                gsCacheInfo.u16TLCSprBlockCnt--;
            }
#endif

            if(!mChkGcQue(cGcTypForeGrnd)&&chkBgdClnCacheBlk())
            {
                mPushGcQue(cGcTypForeGrnd);
            }

            if(uPopOpt&cPopSlcBlock)
            {
                if(u16Fblock<g16StaticBound)
                {
                    g32StaticSLCTotalEC++;
                }
                else
                {
                    g32DynamicSLCTotalEC++;
                }
            }

#if _EN_Dynamic_Fix_Boundary

            if(u16Fblock<g16StaticBound)
            {
                gsCacheInfo.u32SLCTotalEraseCnt++;
                gsCacheInfo.u16SLCAvgEraseCnt=(gsCacheInfo.u32SLCTotalEraseCnt/gMinStaticSlcCnt);
            }
            else
            {
                gsCacheInfo.u32DynamicTotalEraseCnt++;
                gsCacheInfo.u16DynamicAvgEraseCnt=(gsCacheInfo.u32DynamicTotalEraseCnt/g16MinStaticTlcCnt);
            }

            if(gsFtlDbg.uStaticMode!=cEndStaticMode)
            {
                if(u16Fblock<g16StaticBound)
                {
                    if(!gsCacheInfo.u16SLCSpareCnt)
                    {
                        gsFtlDbg.u16DummyFailType=cEraseBlockProc1;
                        debugWhile();
                    }
                    else
                    {
                        gsCacheInfo.u16SLCSpareCnt--;
                    }
                }
                else
                {
                    if(!gsCacheInfo.u16DynamicSpareCnt)
                    {
                        gsFtlDbg.u16DummyFailType=cEraseBlockProc2;
                        debugWhile();
                    }
                    else
                    {
                        gsCacheInfo.u16DynamicSpareCnt--;
                    }
                }

#if _EN_Always_DynamicMode

                if(!gsCacheInfo.u16SpareBlockCnt)
                {
                    debugWhile();
                }
                else
                {
                    gsCacheInfo.u16SpareBlockCnt--;
                }
#endif
            }
#endif/* if _EN_Dynamic_Fix_Boundary */
        }

#if 1    // just for No Org Bad

        if(u32EraseFail)
        {
            mSetPoppedBit(u16Fblock);
            // garGlobEraseCnt[u16Fblock].u16EraseCnt= 0x7FFF;
            mSetGlobEraseCnt(u16Fblock, c16BitFF);
            // gsCacheInfo.u16SpareBlockCnt--;
        }
#endif

        // if(gsFtlDbg.uStaticMode==cEndStaticMode)
        // {
    }

    return u32EraseFail;
}    /* eraseBlockProc */

WORD popSpareBlock(BYTE uPopOpt)
{
    BYTE uOrgCh=gActiveCh;
    LWORD u32EraseFail, u32StartRamAddr;
    WORD u16Fblock, u16FirstFblock, u16TotalFblock, uSrchMo;
    // WORD u16AvgEraseCntTemp;
    // WORD u16EraseCntTemp;
    WORD u16EraseB2bCnt;
    WORD u16TempSLCQ=g16SlcSortQCnt;

    u32EraseFail=1;
    u16EraseB2bCnt=0;

    while(rmChkBopNbsBz)
        ;

    while(rmChkBopCmdFifoFull)
        ;

    while(rmChkBopBz)
        ;

#if _EN_Dynamic_Fix_Boundary
#if _EN_VPC_SWAP

    if((uPopOpt&cPopMaxErsCnt)||(uPopOpt&cPopLargeErsCnt))
    {
        uSrchMo=cBopSrchMax|cBopWordMo|cBopWait|cBopSrchStcm;
    }
    else
    {
        uSrchMo=cBopSrchMin|cBopWordMo|cBopWait|cBopSrchStcm;
    }

#else

    if((uPopOpt&cPopMaxErsCnt)||(uPopOpt&cPopLargeErsCnt))
    {
        uSrchMo=cBopSrchMax|cBopWordMo|cBopWait|cBopSrchDccm;
    }
    else
    {
        uSrchMo=cBopSrchMin|cBopWordMo|cBopWait|cBopSrchDccm;
    }
#endif/* if _EN_VPC_SWAP */
    u32StartRamAddr=(LWORD)g16arGlobEraseCnt;

    if((uPopOpt&cPopSlcBlock))
    {
        // u16FirstFblock=g16FirstFBlock;

        // if(uPopOpt&cPopDataBlock)
        {
            // u16TotalFblock=g16TotalFBlock;

#if _EN_FW_DEBUG_UART
            NLOG(cLogFTL, SPRBLK_C, 4, "(g32StaticSLCTotalEC*2): 0x%08X vs(g32DynamicSLCTotalEC*3): 0x%08X", (g32StaticSLCTotalEC*2)>>16,
                 (g32StaticSLCTotalEC*2)
                 , (g32DynamicSLCTotalEC*3)>>16, (g32DynamicSLCTotalEC*3));
#endif

            if((((g32StaticSLCTotalEC*2)<=(g32DynamicSLCTotalEC*3))||(gsCacheInfo.u16DynamicSpareCnt<(g16TLCGCSpareCnt_Run*2)))&&
               gsCacheInfo.u16SLCSpareCnt)
            {
                u16FirstFblock=g16FirstFBlock;
                u16TotalFblock=g16StaticBound;
            }
            else
            {
                u16FirstFblock=g16StaticBound;
                u16TotalFblock=g16TotalFBlock;
            }

            /*
               * if((gsCacheInfo.u16DynamicSpareCnt<g16TLCGCSpareCnt)&&(gsCacheInfo.u16SLCSpareCnt>(gsCacheInfo.u16DynamicSpareCnt*2)))
               * {
               *  u16FirstFblock=g16FirstFBlock;
               *  u16TotalFblock=g16StaticBound;
               * }
               */
        }
        // else
        {
            // u16FirstFblock=g16FirstFBlock;
            // u16TotalFblock=g16StaticBound;
        }

        // uSrchMo|=cBopSrchSkip;
    }
    else
    {
        u16FirstFblock=g16StaticBound;
        u16TotalFblock=g16TotalFBlock;
    }

    uSrchMo|=cBopSrchSkip;
#else/* if _EN_Dynamic_Fix_Boundary */
#if _EN_VPC_SWAP

    if((uPopOpt&cPopMaxErsCnt)||(uPopOpt&cPopLargeErsCnt))
    {
        uSrchMo=cBopSrchMax|cBopWordMo|cBopSrchSkip|cBopWait|cBopSrchStcm;
    }
    else
    {
        uSrchMo=cBopSrchMin|cBopWordMo|cBopSrchSkip|cBopWait|cBopSrchStcm;
    }

#else

    if((uPopOpt&cPopMaxErsCnt)||(uPopOpt&cPopLargeErsCnt))
    {
        uSrchMo=cBopSrchMax|cBopWordMo|cBopSrchSkip|cBopWait|cBopSrchDccm;
    }
    else
    {
        uSrchMo=cBopSrchMin|cBopWordMo|cBopSrchSkip|cBopWait|cBopSrchDccm;
    }
#endif/* if _EN_VPC_SWAP */

    u32StartRamAddr=(LWORD)g16arGlobEraseCnt;

    if((uPopOpt&cPopSlcBlock))
    {
        u16FirstFblock=g16FirstFBlock;
        u16TotalFblock=g16StaticBound;
    }
    else
    {
        u16FirstFblock=g16StaticBound;
        u16TotalFblock=g16TotalFBlock;
    }
#endif/* if _EN_Dynamic_Fix_Boundary */
#if _EN_PopBlk0    // Chief_20190104

    if(g16PushSpareCnt&&(gsCacheInfo.u16SpareBlockCnt<C_BlkEmergencyTh))
    {
        NLOG(cLogHost, SPRBLK_C, 1, "Emergency PopSpareBlock g16PushSpareCnt =0x%04X", g16PushSpareCnt);
        chkPushSpareQ(2);
        gBlkEmergencyflag=cBit0;
    }
#endif/* if _EN_PopBlk0 */

    while(u32EraseFail&&(gsCacheInfo.u16SLCSpareCnt||gsCacheInfo.u16DynamicSpareCnt))    // test by yhlin
    {
        copyReg2Tsb32(r32SkipRam, g32arPopBit, c16MaxBlockNum/32);    // 20190307_Bruce Fixed mis-calculation when erase fail.

        if(gsGcInfo.uGcSkipPopSrcBlockCnt)
        {
            BYTE uBlkNum;

            for(uBlkNum=0; uBlkNum<gsGcInfo.uGcSkipPopSrcBlockCnt; uBlkNum++)
            {
                mSetBitMask(r32SkipRam[gsGcInfo.u16arGcSkipPopSrcBlock[uBlkNum]>>5], gsGcInfo.u16arGcSkipPopSrcBlock[uBlkNum]&0x1F);
            }
        }

        u32EraseFail=0;

        if(u16EraseB2bCnt>=2)
        {
            gsFtlDbg.u16EfB2bCnt++;
        }

        u16EraseB2bCnt++;

        // u16Fblock=bopSrchRam((LWORD)u32StartRamAddr, c31BitFF, u16FirstFblock, u16TotalFblock, uSrchMo);
        if(uPopOpt&cPopLargeErsCnt)
        {
            u16Fblock=bopSrchRam((LWORD)u32StartRamAddr,
                                 (gsCacheInfo.u16DynamicAvgEraseCnt+cWearLevelThr),
                                 c32BitFF,
                                 u16FirstFblock,
                                 u16TotalFblock,
                                 uSrchMo);

            if(u16Fblock==0xFFFF)
            {
                u16Fblock=bopSrchRam((LWORD)u32StartRamAddr, c16BitFF, c32BitFF, u16FirstFblock, u16TotalFblock, uSrchMo);
            }
        }
        else
        {
            u16Fblock=bopSrchRam((LWORD)u32StartRamAddr, c16BitFF, c32BitFF, u16FirstFblock, u16TotalFblock, uSrchMo);
        }

        if((u16Fblock==0xFFFF)&&(uPopOpt&cPopSlcBlock)    /*&&(uPopOpt&cPopDataBlock)*/)
        {
            u16FirstFblock=g16FirstFBlock;
            u16TotalFblock=g16TotalFBlock;
            u16Fblock=bopSrchRam((LWORD)u32StartRamAddr, c16BitFF, c32BitFF, u16FirstFblock, u16TotalFblock, uSrchMo);
        }

        // test end
        if(u16Fblock==0xFFFF)
        {
            gsFtlDbg.u16DummyFailType=cPopSpareBlock1;
            debugWhile();
        }

        if((g16arDiffOffset[u16Fblock]!=0xFFFF)&&mChkBitMask(g16arDiffOffset[u16Fblock], 0x0F))
        {
            gsFtlDbg.u16DummyFailType=cPopSpareBlock2;
            debugWhile();
        }

        /*
           * while(mChkPoppedBit(u16Fblock)||((g32Core1State<cCore1BootState_Finished)&&mChkPopDeniedF(u16Fblock)))
           * {
           *  u16Fblock++;
           *
           *  if(u16Fblock>=g16TotalFBlock)
           *  {
           *      u16Fblock=g16FirstFBlock;
           *  }
           * }
           */

#if _BypassEraseFlag
        u32EraseFail=eraseBlockProc(u16Fblock, uPopOpt);
        setFLActCh(uOrgCh);
#else

        if(mChkEraseFlag(u16Fblock))
        {
            u32EraseFail=eraseBlockProc(u16Fblock, uPopOpt);
            setFLActCh(uOrgCh);
        }
        else
        {
            gsFtlDbg.u16DummyFailType=cPopSpareBlock3;
            debugWhile();
        }
#endif
    }

    while(u32EraseFail&&(!gsCacheInfo.u16SLCSpareCnt))    // test by yhlin
    {
        u16Fblock=0;
    }

    // test by yhlin
    if(gsFtlDbg.u16MinSpareBlockCnt>gsCacheInfo.u16SLCSpareCnt)
    {
        gsFtlDbg.u16MinSpareBlockCnt=gsCacheInfo.u16SLCSpareCnt;
    }

    if(gsFtlDbg.u16TlcMinSpareBlockCnt>gsCacheInfo.u16DynamicSpareCnt)
    {
        gsFtlDbg.u16TlcMinSpareBlockCnt=gsCacheInfo.u16DynamicSpareCnt;
    }

    // NLOG(cLogFTL, SPRBLK_C, 3, "g16MaxECInSpare:0x%04X, u16EraseCntTemp:0x%04X, gsGcInfo.uGcPrioTlcBlkNumPtr:0x%04X", g16MaxECInSpare,
    // mGetGlobEraseCnt(g16WLCheckBlk), gsGcInfo.uGcPrioTlcBlkNumPtr);

    // if(gsCacheInfo.u16DynamicAvgEraseCnt>=cWearLevelBound)
    if(g16MaxECInSpare>cWearLevelBound)    // 20190124_JimmyTsai
    {
        WORD u16AvgEraseCntTemp;
        WORD u16EraseCntTemp;

        if(!mChkGcFlag(cGcSrchWearF))
        {
#if _EN_VPC_SWAP

            if((!mChkSkipGcSrch(g16WLCheckBlk))&&(mChkVPCntValid(g16WLCheckBlk))&&mChkMlcMoBit(g16WLCheckBlk)&&
               (!mChkPushReClaimQBit(g16WLCheckBlk)))
#else

            if((!mChkSkipGcSrch(g16WLCheckBlk))&&(mGetCacheBlkVpCnt(g16WLCheckBlk))&&mChkMlcMoBit(g16WLCheckBlk)&&
               (!mChkPushReClaimQBit(g16WLCheckBlk)))
#endif
            {
                u16EraseCntTemp=mGetGlobEraseCnt(g16WLCheckBlk);

                if(mChkMlcMoBit(g16WLCheckBlk))
                {
                    // u16AvgEraseCntTemp=gsCacheInfo.u16DynamicAvgEraseCnt;
                    u16AvgEraseCntTemp=g16MaxECInSpare;    // 20190124_JimmyTsai

                    if((u16AvgEraseCntTemp>=(u16EraseCntTemp+cWearLevelBound))&&(gsGcInfo.uGcPrioTlcBlkNumPtr<cMaxGcPrioBlkNum))
                    {
                        mPushGcQue(cGcTypTLCWearLvl);
                        pushWLReadReclaimQ(g16WLCheckBlk, cDoWearLeveling);
                    }
                }
            }

            g16WLCheckBlk=addPtrBy1(g16WLCheckBlk, g16TotalFBlock);

            if(g16WLCheckBlk==0)
            {
                g16WLCheckBlk=g16StaticBound;
            }
        }
    }

#if _EN_VPC_SWAP

    if(uPopOpt&cPopDataBlock)    // 20190419_Louis
    {
        if(uPopOpt&cPopSlcBlock)
        {
            u16TempSLCQ=g16SlcSortQCnt+1;
        }
    }
#endif

//
#if ((_EN_CDMTRIG||(_EN_IOMTRIG&&_EN_VPC_SWAP))&&S_SpeedUPSLCProg)

    if(uPopOpt&cPopDataBlock)
    {
        BYTE u8CCTChg=0;

        if(gCCTFlag==cCCT_OFF)
        {
#if _EN_CDMTRIG

            if(gCDMStatus==cCDM_Triger)
            {
                u8CCTChg=1;
            }

#elif _EN_IOMTRIG

            if(gsIomInfo.u8Status==cIoMeterTrig)
            {
                u8CCTChg=1;
            }
#endif

            if(u8CCTChg)
            {
                WORD u16AVG_TLC=AvgECForCore1(1);
                WORD u16AVG_SLC=AvgECForCore1(0);
                NLOG(cLogBuild, SPRBLK_C, 2, "cCDM_Triger AvgTLC=0x%04X, AvgSLC=0x%04X", u16AVG_TLC, u16AVG_SLC);

                //  ReturnNormal();
                if((u16AVG_TLC<3000)&&(u16AVG_SLC<30000))    // ChrisSu_20190225 // ChrisSu_20191225
                {
                    mWaitCmdFifoBz;
                    waitAllChCeBz();
                    Overload_AIPR_Disable();
                    gCCTFlag=cCCT_ON;
                    NLOG(cLogBuild, SPRBLK_C, 0, "GTR On");
                }
            }
        }
        else if(gCCTFlag==cCCT_ON)
        {
#if _EN_CDMTRIG

            if(gCDMStatus!=cCDM_Triger)
            {
                u8CCTChg=1;
            }

#elif _EN_IOMTRIG

            if(gsIomInfo.u8Status!=cIoMeterTrig)
            {
                u8CCTChg=1;
            }
#endif

            if(u8CCTChg)
            {
                mWaitCmdFifoBz;
                waitAllChCeBz();
                ReturnNormal();
                gCCTFlag=cCCT_OFF;
                NLOG(cLogBuild, SPRBLK_C, 0, "GTR Off");
            }
        }
    }
#endif/* if 1 */

#if (C_Log_SaveMask&C_Debug_P2)    // 20181031_Bill FTL Spr

    if((uPopOpt&cPopSlcBlock))
    {
        NLOG(cLogFTL,
             SPRBLK_C,
             5,
             " popSprBlk() SLC Blk = 0x%04X ,SLCSprBlkCnt = 0x%04X ,TLCSprBlkCnt = 0x%04X ,uPopOpt = 0x%04X, SlcQCnt=0x%04x",
             u16Fblock,
             gsCacheInfo.u16SLCSpareCnt,
             gsCacheInfo.u16DynamicSpareCnt,
             uPopOpt,
             u16TempSLCQ);
    }
    else
    {
        NLOG(cLogFTL,
             SPRBLK_C,
             5,
             " popSprBlk() TLC Blk = 0x%04X ,SLCSprBlkCnt = 0x%04X ,TLCSprBlkCnt = 0x%04X ,uPopOpt = 0x%04X, SlcQCnt=0x%04x ",
             u16Fblock,
             gsCacheInfo.u16SLCSpareCnt,
             gsCacheInfo.u16DynamicSpareCnt,
             uPopOpt,
             u16TempSLCQ);
    }
#endif/* if (C_Log_SaveMask&C_Debug_P2) */
    return u16Fblock;
}    /* popSpareBlock */

/*
   * WORD prepopBlockErase(BYTE uPopOpt)
   * {
   *  BYTE uOrgCh=gActiveCh, uSrchMo;
   *  LWORD u32StartRamAddr;
   *  WORD u16Fblock, u16FirstFblock, u16TotalFblock;
   *
   *  while(!gsCacheInfo.u16SpareBlockCnt&&!gsCacheInfo.u16TLCSprBlockCnt);
   *
   *  if(uPopOpt&cPopMaxErsCnt)
   *  {
   *      uSrchMo=cBopSrchMax|cBopWordMo|cBopSrchSkip|cBopWait|cBopSrchDccm;
   *  }
   *  else
   *  {
   *      uSrchMo=cBopSrchMin|cBopWordMo|cBopSrchSkip|cBopWait|cBopSrchDccm;
   *  }
   *
   *  if(uPopOpt&cPopSlcBlock)
   *  {
   *      u32StartRamAddr=(LWORD)g16arGlobEraseCnt;
   *      u16FirstFblock=g16FirstFBlock;
   *      u16TotalFblock=g16TotalFBlock;
   *  }
   *  else
   *  {
   *      u32StartRamAddr=(LWORD)g16arGlobEraseCnt-(c16MaxBlockNum*2);
   *      u16FirstFblock=g16FirstFBlock+c16MaxBlockNum;
   *      u16TotalFblock=g16TotalFBlock+c16MaxBlockNum;
   *  }
   *
   *  // u16Fblock=bopSrchRam((LWORD)u32StartRamAddr, c31BitFF, u16FirstFblock, u16TotalFblock, uSrchMo);
   *  u16Fblock=bopSrchRam((LWORD)u32StartRamAddr, c15BitFF, c32BitFF, u16FirstFblock, u16TotalFblock, uSrchMo);
   *
   *  if(u16Fblock==0xFFFF)
   *  {
   *      u16Fblock=g16FirstFBlock;
   *  }
   *  else if(!(uPopOpt&cPopSlcBlock))
   *  {
   *      u16Fblock-=c16MaxBlockNum;
   *  }
   *
   *  if((g16arDiffOffset[u16Fblock]!=0xFFFF)&&mChkBitMask(g16arDiffOffset[u16Fblock], 0x0F))
   *  {
   *      while(1)
   *          ;
   *  }
   *
   *  while(mChkPoppedBit(u16Fblock)||((g32Core1State<cCore1BootState_Finished)&&mChkPopDeniedF(u16Fblock)))
   *  {
   *      u16Fblock++;
   *
   *      if(u16Fblock>=g16TotalFBlock)
   *      {
   *          u16Fblock=g16FirstFBlock;
   *      }
   *  }
   *
   *  if(mChkEraseFlag(u16Fblock))
   *  {
   *      eraseBlockProc(u16Fblock, uPopOpt);
   *      setFLActCh(uOrgCh);
   *  }
   *
   *  return u16Fblock;
   * }
   *
   * BYTE prepopBlockChkStatus(WORD u16Fblock, BYTE uPopOpt)
   * {
   *  ADDRINFO usTmpAddrInfo;
   *  LWORD u32EraseFail=0;
   *
   *  usTmpAddrInfo.u16FBlock=u16Fblock;
   *
   *  for(gActiveCh=0; gActiveCh<gTotalChNum; gActiveCh++)
   *  {
   *      setFLAddrActCh(gActiveCh, &usTmpAddrInfo);
   *      u32EraseFail|=((LWORD)(chkEraseStatus())<<(gActiveCh*cMaxIntlvWay));    // 4Ch*8Way
   *  }
   *
   *  if(!u32EraseFail)
   *  {
   *      if(uPopOpt&cPopSlcBlock)
   *      {
   *          mClrMlcMoBit(u16Fblock);
   *      }
   *      else
   *      {
   *          mSetMlcMoBit(u16Fblock);
   *      }
   *
   *      mSetPoppedBit(u16Fblock);
   *
   *      if(!mChkSlcSkipBit(u16Fblock))
   *      {
   *          gsCacheInfo.u16SpareBlockCnt--;
   *      }
   *      else
   *      {
   *          gsCacheInfo.u16TLCSprBlockCnt--;
   *      }
   *  }
   *
   #if 1    // just for No Org Bad
   *  if(u32EraseFail)
   *  {
   *      mSetPoppedBit(u16Fblock);
   *      // garGlobEraseCnt[u16Fblock].u16EraseCnt= 0x7FFF;
   *      mSetGlobEraseCnt(u16Fblock, 0x7FFF);
   *      // gsCacheInfo.u16SpareBlockCnt--;
   *  }
   #endif
   *
   *  if(g16MinSpareBlockCnt>gsCacheInfo.u16SpareBlockCnt)
   *  {
   *      g16MinSpareBlockCnt=gsCacheInfo.u16SpareBlockCnt;
   *  }
   *
   *  if(u32EraseFail)
   *  {
   *      return cTrue;
   *  }
   *  else
   *  {
   *      return cFalse;
   *  }
   * }
   */

/*
   * void checkWL(WORD u16EraseCnt, BYTE uWLTyp)
   * {
   *  LWORD u32StartRamAddr;
   *  WORD u16FirstFblock, u16TotalFblock;
   *  WORD u16EraseTemp, u16DataFblk=0xFFFF;
   *  BYTE uSrchMo;
   *
   *  rmSetSrchLorBound(c16Bit15);
   *
   *  if(uWLTyp&cBit0)
   *  {
   *      u32StartRamAddr=(LWORD)g16arGlobEraseCnt-(c16MaxBlockNum<<1);
   *      u16FirstFblock=g16FirstFBlock+c16MaxBlockNum;
   *      u16TotalFblock=g16TotalFBlock+c16MaxBlockNum;
   *      uSrchMo=cBopSrchMin|cBopWordMo|cBopSrchSkip|cBopWait|cBopSrchDccm;
   *  }
   *  else if(uWLTyp&cBit1)
   *  {
   *      u32StartRamAddr=(LWORD)g16arGlobEraseCnt;
   *      u16FirstFblock=g16FirstFBlock;
   *      u16TotalFblock=g16TotalFBlock;
   *      uSrchMo=cBopSrchMin|cBopWordMo|cBopSrchSkip|cBopWait|cBopSrchDccm;
   *  }
   *
   *  u16DataFblk=bopSrchRam(u32StartRamAddr, c16BitFF-1, c32BitFF, u16FirstFblock, u16TotalFblock, uSrchMo);
   *
   *  if(uWLTyp&cBit0)
   *  {
   *      u16DataFblk-=c16MaxBlockNum;
   *  }
   *
   *  rmSetSrchLorBound(0);
   *
   *  if(u16DataFblk!=0xFFFF)
   *  {
   *      if((!mChkSkipGcSrch(u16DataFblk))&&(mGetCacheBlkVpCnt(u16DataFblk))&&(!mChkPushReClaimQBit(u16DataFblk)))
   *      {
   *          u16EraseTemp=mGetGlobEraseCnt(u16DataFblk);
   *
   *          if(u16EraseCnt>=(u16EraseTemp+cWearLevelThr))
   *          {
   *              pushWLReadReclaimQ(u16DataFblk, cDoWearLeveling);
   *          }
   *      }
   *  }
   * }*/    /* checkWL */

void setBlockMoSkipBit(WORD u16Fblock)
{
#if !_EN_Always_DynamicMode

    if(!mChkMlcMoBit(u16Fblock))
    {
        gsCacheInfo.u16SpareBlockCnt++;
    }
    else
    {
        gsCacheInfo.u16TLCSprBlockCnt++;
    }
#endif

#if _EN_Dynamic_Fix_Boundary

    if(gsFtlDbg.uStaticMode!=cEndStaticMode)
    {
        if(u16Fblock<g16StaticBound)
        {
            gsCacheInfo.u16SLCSpareCnt++;
        }
        else
        {
            gsCacheInfo.u16DynamicSpareCnt++;
        }
    }

#if _EN_Always_DynamicMode
    gsCacheInfo.u16SpareBlockCnt++;
#endif
#endif
}    /* setBlockMoSkipBit */

void pushSpareBlock(WORD u16Fblock, BYTE uPushOpt)
{
    WORD u16Loop;
    WORD u16Idx;

    u16Idx=g16PushSpareTail;
    chkPopWLReadReclaimQ(u16Fblock);

    if(mGetGlobEraseCnt(u16Fblock)!=c16BitFF)
    {
        if(g32Core1State<cCore1BootState_Finished)
        {
            for(u16Loop=0; u16Loop<g16PushSpareCnt; u16Loop++)
            {
                if(u16Fblock==garPushSpareQ[u16Idx].u16FBlock)
                {
                    return;
                }

                u16Idx=addPtrBy1(u16Idx, c16MaxPushSprbNum);
            }
        }

        // while(mChkPoppedBit(u16Fblock));

        if((u16Fblock<g16TotalFBlock)&&(u16Fblock>=g16FirstFBlock)&&mChkPoppedBit(u16Fblock))
        {
            if(g16PushSpareCnt<c16MaxPushSprbNum)
            {
                garPushSpareQ[g16PushSpareHead].u16FBlock=u16Fblock;
                garPushSpareQ[g16PushSpareHead].uPushOpt=uPushOpt;
                g16PushSpareCnt++;
                g16PushSpareHead=addPtrBy1(g16PushSpareHead, c16MaxPushSprbNum);

                if(gsFtlDbg.u16MaxPushSpareCnt<g16PushSpareCnt)
                {
                    gsFtlDbg.u16MaxPushSpareCnt=g16PushSpareCnt;
                }
            }
            else
            {
                if(uPushOpt&cPushNotErase)
                {
#if (!_BypassEraseFlag)
                    mSetEraseFlag(u16Fblock);
#endif
                    setBlockMoSkipBit(u16Fblock);
                    mClrPoppedBit(u16Fblock);
                }
            }

            /*
               * if((uPushOpt&cPushJudgeMaxSlc)&&!(mChkMlcMoBit(u16Fblock)))
               * {
               *  if(uPushOpt&cPushDecMaxSlc)
               *  {
               *      if(g16CurrSlcCacheBlockThr)
               *      {
               *          g16CurrSlcCacheBlockThr--;
               *      }
               *  }
               *  else
               *  {
               *      if(g16CurrSlcCacheBlockThr<g16MaxSlcCacheBlockThr)
               *      {
               *          g16CurrSlcCacheBlockThr++;
               *      }
               *  }
               * }
               */
            // chkPopWLReadReclaimQ(u16Fblock);
        }
    }
}    /* pushSpareBlock */

void setEraseBadBlock(WORD u16Fblock, LWORD u32EraseFail)
{
#if _EN_CHRONUS_UART_DEBUG
    ADDRINFO usTmpAddrInfo;
    WORD u16Index;

    for(u16Index=0; u16Index<32; u16Index++)    // 32 bit ch and Intlv status
    {
        if(mChkBitMask(u32EraseFail, u16Index))
        {
            usTmpAddrInfo.u16FBlock=u16Fblock;
            usTmpAddrInfo.u16AbstractFBlock=u16Fblock;
            usTmpAddrInfo.uCh=u16Index/cMaxIntlvWay;
            usTmpAddrInfo.uIntlvAddr=u16Index%cMaxIntlvWay;
            usTmpAddrInfo.uCe=mGetCEAddr(usTmpAddrInfo.uIntlvAddr);
            usTmpAddrInfo.uDieAddr=mGetDieAddr(usTmpAddrInfo.uIntlvAddr);

            for(usTmpAddrInfo.uPlaneAddr=0; usTmpAddrInfo.uPlaneAddr<gPlaneNum; usTmpAddrInfo.uPlaneAddr++)
            {
                printNandPhyAddr(&usTmpAddrInfo);
            }
        }
    }
#endif/* if _EN_CHRONUS_UART_DEBUG */

    if(gsBadInfo.uEraseFailQueCnt<cEraseFailQueDpth)
    {
        gsBadInfo.uarEsFailQue[gsBadInfo.uEraseFailQueCnt].u16EsFailFBlock=u16Fblock;
        gsBadInfo.uarEsFailQue[gsBadInfo.uEraseFailQueCnt].u32EsFailSts=u32EraseFail;
        gsBadInfo.uarEsFailQue[gsBadInfo.uEraseFailQueCnt].u16EraseCnt=mGetGlobEraseCnt(u16Fblock);
        gsBadInfo.uEraseFailQueCnt++;
        mSetBadInfoFlag(cBadInfoChg);

        mSetPoppedBit(u16Fblock);
        mSetGlobEraseCnt(u16Fblock, c16BitFF);

        if(u16Fblock<g16StaticBound)
        {
            gsCacheInfo.u16SLCSpareCnt--;
        }
        else
        {
            gsCacheInfo.u16DynamicSpareCnt--;
        }

#if _EN_Always_DynamicMode
        gsCacheInfo.u16SpareBlockCnt--;
#endif
        // rmBlkFromCacheQ(u16Fblock);//check later//???????????????????????????????
    }
}    /* setEraseBadBlock */

void chkPushSpareQ(BYTE uInBoot)
{
    BYTE u16PushSpareCnt=0;
    WORD u16Fblock;

    if((!uInBoot)&&(gsWproInfo.u16WproFreePagePtr>=(gsWproInfo.u16PagePerBlock3-gsWproInfo.u16CacheInfoPlaneSize+1)))
    {
        // avoid power off during erasing block whick last push block for swap wpro.
        progCacheInfoTab();
    }

    while(g16PushSpareCnt)
    {
        u16Fblock=garPushSpareQ[g16PushSpareTail].u16FBlock;

#if _EN_VPC_SWAP

        if(mChkVPCntValid(u16Fblock))
#else

        if(mGetCacheBlkVpCnt(u16Fblock))
#endif
        {
            setEraseBadBlock(u16Fblock, 0x0000|c16Bit14);
        }
        else if(mChkGcSrcBlkBmap(u16Fblock))
        {
            setEraseBadBlock(u16Fblock, 0x0003|c16Bit14);
        }
        else if(!uInBoot&&!mChkSkipGcSrch(u16Fblock))
        {
            setEraseBadBlock(u16Fblock, 0x0004|c16Bit14);
        }
        else if(garPushSpareQ[g16PushSpareTail].uPushOpt&cPushNotErase)
        {
            if(!mChkPoppedBit(u16Fblock))    // 20190528_Louis_03
            {
                gsFtlDbg.u16DummyFailType=cChkPushSpareQ;
                NLOG(cLogHost,
                     SPRBLK_C,
                     2,
                     "chkPushSpareQ: mChkPoppedBit=0! blk=0x%04X, DummyFailType=0x%04X",
                     u16Fblock,
                     gsFtlDbg.u16DummyFailType);
#if (!_EN_KEEP_RW_ON_ERROR)
                debugWhile();
                // setEraseBadBlock(u16Fblock, 0x0002|c16Bit14);
#endif
            }

#if (!_BypassEraseFlag)
            mSetEraseFlag(u16Fblock);
#endif
            setBlockMoSkipBit(u16Fblock);
            mClrPoppedBit(u16Fblock);

            if((g16MaxECInSpare<mGetGlobEraseCnt(u16Fblock))&&(u16Fblock>g16StaticBound))    // 20190124_JimmyTsai
            {
                g16MaxECInSpare=mGetGlobEraseCnt(u16Fblock);
            }
        }

        g16PushSpareCnt--;
        u16PushSpareCnt++;
        g16PushSpareTail=addPtrBy1(g16PushSpareTail, c16MaxPushSprbNum);
    }

    if(!uInBoot&&u16PushSpareCnt)
    {
        if(mGetGcFlow==cGcFlowIdl)
        {
            if((gsCacheInfo.u16SpareBlockCnt>=gsGcInfo.u16GcCachebActThr)&&mChkGcQue(cGcTypForeGrnd)&&
               (!gsGcInfo.uGcPrioTlcBlkNumPtr)&&
               (!gsGcInfo.uGCSLCReclaimPtr))
            {
                mPopGcQue(cGcTypForeGrnd);
            }
        }

        progCacheInfoTab();
    }
}    /* chkPushSpareQ */







