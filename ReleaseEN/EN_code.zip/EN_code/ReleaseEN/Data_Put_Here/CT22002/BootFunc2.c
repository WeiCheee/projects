







#include "inc/DebugLog.h"
#include "inc/EventLogIDX.h"
#include "inc/EventLogFunctionIDX.h"
#include "inc/Const.h"
#include "inc/TypeDef.h"
#include "inc/Option.h"
#include "inc/ProType.h"
#include "inc/Asm.h"
#include "inc/GlobVarS.h"
#include "inc/GlobVar0.h"
#include "inc/GlobVarT.h"
#include "inc/NvmeCtrl.h"
#include "inc/BitDef.h"
#include "inc/Reg.h"
#include "inc/Rdlink.h"
#include "inc/RdlinkFunc.h"
#include "inc/Mac.h"
#include "Common/Model.h"

#if (_GREYBOX)
#include "inc/GreyBox.h"
#endif

#if (!_ICE_LOAD_ALL)
#pragma default_function_attributes = @ ".CORE0_BOOT2"
#endif

#include "TaskFuncForPrj.c"
#include "SysCtrlBoot.c"
#if (!_ICE_LOAD_ALL)
#include "H2fTab.c"
#include "F2hTab.c"
// #include "FwCommitDl.c"
#endif
#include "Vic0Ctrl.c"
#include "RdlinkFunc.c"
#include "RebuCacheF2hTab.c"
#include "RebuFunc.c"
#include "RebuH2fTab.c"
#include "RebuWproInfo.c"
#include "RebuSprBlk.c"
#include "RebuSysB.c"
#include "RestoCacheInfo.c"
#include "SystemBlockCtl.c"
#include "PhyCtrlBoot.c"
// #include "Core0TempInvFunc.c"
#include "FlashCmdDir.c"
#include "Ftl.c"
#include "SaveIdx.c"

#if _ENABLE_SECAPI
#include "Write.c"
#include "Read.c"
#include "TrimCmd.c"
#include "NvmeCommonFunc.c"
#endif

#if ((_ICE_LOAD_ALL)&&(_WO_INFOB))
#include "LightSwitch.c"
#endif

#include "I2cCtrl.c"

void bootFunc2()
{
    rdlinkFunc();

    gsDebugInfo.u32RdLinkTime=getRtcCurrent32k();

    if(g32MaxRebuTime<gsDebugInfo.u32RdLinkTime)
    {
        g32MaxRebuTime=gsDebugInfo.u32RdLinkTime;
    }

    // gLtssmIntr0=1;
    // while(gLtssmIntr0);

    // clear RdLink variable
    bopClrRam((LWORD)c32RdLinkVarStartAddr, c32RdLinkVarRamSize, 0x00000000, cClrTsb|cBopWait);

    g32Core1State=cCore1BootState_SwapCPU1Rw;

    while(g32Core1State!=cCore1BootState_Finished)
        ;

    initAes();

    gL1TimeOutEnabled=0;
#if _2260PCIE_WORKAROUND
    setExtSync(cDisabled);
#endif

    initThermalVar();

    if(!rmChkInDevSlp)    // Boot from Power On
    {
        initThermal();
        initNvmeFeatureAttribute();
#if _EN_BUILD_FWSLOTISPBLK

        if(!mChkIspBlkInFL)
        {
            buildFwslotIspBlk();
            SaveFWHistory(0xFF, 0xFF);
        }
#endif
        initSmart();

#if 1

        if(rmChkManufactureFlag)
        {
            gFwResetCpuForSec=0;    // if reset cpu by MP, clear gFwResetCpuForSec for InitTCGParameter_IntelAPI(). If FW commit, keep
                                    // gFwResetCpuForSec
            rmClrManufactureFlag;
        }
#endif
    }
    else    // Boot From PS4
    {
        restoreNvmeFeatureForPS4();
        restoreDSTForPS4();    // 20181228_SamHu_01 eDEVX
    }

    rmEnJtagBusyWake;
    rmDisJtagLevelWake;    // need disable for PS4 self-wake up issue

    invalidateDCache();

#if _ENABLE_SECAPI

    if(gbEnTCG||gbEnATAPassThrough||gbEnRpmb||gbEnAes)
    {
        loadISPCodeCore0(cSecTsbBank, 3);
        bootInitSecurity();
    }
#endif

#if _EN_CacheR
#if (!_EN_MutiWayCacheRImprove)

    if(mChkFLOption(cEnCacheRead)&&(gIntlvWay==1))
#endif
    {
        gsRwCtrl.uEnCacheR=1;
    }
#endif
/*
   *  if(rmChkInDevSlp)
   *  {
   *      // Check Set Feature cmd, return PS0 completion before swap RW code
   *      chkDphyPatch();
   *
   *      if((rmChkCmdRdy)&&(rmChkCcRdy))
   *      {
   *          if((!rmNvmeSqId)&&(rmNvmeOpCode==cNvmeCmdSetFeatures)&&(rmNvmeFid==cNvmeFeatPowerMgmt))
   *          {
   *              nvmeAdminPM(cNvmeCmdSetFeatures);
   *              // NLOG(cLogPS, BOOTFUNC_C, 0, " BootFunc(), PS0 completion. ");    // Can remove
   *          }
   *      }
   *
   *      rmClrInDevSlp;
   *  }
   */
#if (_EN_CHRONUS_UART_DEBUG)
#if (!_TSB_BiCS4_WR)
    gp32UartCMDStartAddress=(void *)(cTsb0Addr+cUartTsbCmdOffset);
    g32UartCMDWaitTime=0;
    gUartCMDStatus=0;
#endif
#endif
    gWdtStatus=0;
    rmSetWdtNonResetSys;
    rmSetWdt(0);
    rmClrWdtTimeOut;
    rmResetWdtTimer;
    rmEnWdt;

    startRtcCountingMs();

    // Check EEPROM and load Drive Info
    if(!loadInfoPage(0, gSectorPerPlaneH, c16WriteSIdx, 0, cSysBlockMPInfo, cBit1))
    {
        bopCopyRam((LWORD)&garTsb0[0][0x0], (LWORD)&garTsb0[16][0x0], 8192, cCopyTsb2Tsb|cBopWait);    // Liteon EEPROM at MPInfo Page0 last 8kb

        if(Check_EEPROM_Tag(0)!=cSuccess)
        {
            fillCcmVal((BYTE *)&garTsb0[0][0], 8192, cZero);
            garTsb0[0][0x0]='A';
            garTsb0[0][0x1]='G';
            garTsb0[0][0x2]='I';
            garTsb0[0][0x3]='N';

            garTsb0[0][0x100]='T';
            garTsb0[0][0x101]='S';
            garTsb0[0][0x102]='T';
            garTsb0[0][0x103]='1';
            fillCcmVal((BYTE *)&garTsb0[0][0x104], 12, cInvalid8Bit);

            garTsb0[0][0x110]='T';
            garTsb0[0][0x111]='S';
            garTsb0[0][0x112]='T';
            garTsb0[0][0x113]='2';
            fillCcmVal((BYTE *)&garTsb0[0][0x114], 12, cInvalid8Bit);

            Init_EEPROM();
        }
        else
        {
            // SN
            copyCcmVal(gsLightSwitch.usCidHeader.uarSerialNum, (BYTE *)&garTsb0[0][0xC0], 20);
            copyCcmVal(gsMPInfo.uarSerialNum, (BYTE *)&garTsb0[0][0xC0], 20);
            // EUI64
            copyCcmVal(gsLightSwitch.usNvmeLs.uarEui64, (BYTE *)&garTsb0[0][0xB8], 8);
            copyCcmVal(gsMPInfo.uarEui64, (BYTE *)&garTsb0[0][0xB8], 8);
            // PPID
            copyCcmVal(gsLightSwitch.usVuIdLs.uarEppId, (BYTE *)&garTsb0[0][0xC0], 0x20);
#if (OEM==LENOVO)    // 20190108_SamHu_01 add for Lenovo 1.26 Spec Log DFh
            copyCcmVal(garLenovoLogDFhSN, (BYTE *)&garTsb0[5][0x90], 30);
            copyCcmVal(garLenovoLogDFhNewSN, (BYTE *)&garTsb0[5][0xB0], 30);
#endif
            copyCcmVal(i2cSetPS4CoreIndex, (BYTE *)&garTsb0[0][0x74], 2);    // //2019_0315 LeverYu CorePower Learning

            NLOG(cLogBuild,
                 BOOTFUNC2_C,
                 2,
                 " i2cSetPS4CoreIndex[0]=0x%04X,i2cSetPS4CoreIndex[1]=0x%04X  ",
                 i2cSetPS4CoreIndex[0],
                 i2cSetPS4CoreIndex[1]);
        }
    }

    if(rmChkInDevSlp)
    {
        // Check Set Feature cmd, return PS0 completion before swap RW code
        chkDphyPatch();

        if((rmChkCmdRdy)&&(rmChkCcRdy))
        {
            if((!rmNvmeSqId)&&(rmNvmeOpCode==cNvmeCmdSetFeatures)&&(rmNvmeFid==cNvmeFeatPowerMgmt))
            {
                nvmeAdminPM(cNvmeCmdSetFeatures);
                // NLOG(cLogPS, BOOTFUNC_C, 0, " BootFunc(), PS0 completion. ");    // Can remove
            }
        }

        rmClrInDevSlp;
    }
    else
    {
        i2cInit();
        i2cSetPmicAct88325();
    }    // 20190325_Leveryu

    // if(!rmChkInDevSlp)
    // {
    //    i2cInit();
    //    i2cSetPmicAct88325();
    // }
}    /* bootFunc2 */

void rdlinkFunc()
{
    WORD u16TotalTlcFblkCap;
    LWORD u32Loop;
    LWORD u32TotalHostWrSecCntH;
    LWORD u32TotalHostWrSecCntL;

    // BYTE uIdx;
    // Show FW Name Log 20190220 Wade
    NLOG(cLogBuild, BOOTFUNC2_C, 4, " FNWD=0x%08X_%08X  ", (CWORD)(cbRevision1[0]<<8|cbRevision1[1]),
         (CWORD)(cbRevision1[2]<<8|cbRevision1[3]),
         (CWORD)(cbRevision1[4]<<8|cbRevision1[5]), (CWORD)(cbRevision1[6]<<8|cbHeader[15]));

#if (!(C_Log_SaveMask&C_Debug_P1))
    NLOG(cLogBuild, BOOTFUNC2_C, 0, " rdlinkFunc() ");
#endif

    if(rmChkInDevSlp)    // 20190222_Bill
    {
        g32PS4BootTimeStamp=getRtcCurrentMs();
    }

#if 0    // _INITDRAM
    outCS("CS. rdlinkFunc()");
#endif
    NLOG(cLogHost, BOOTFUNC2_C, 4, " garSysBlock: 0x%02X 0x%02X 0x%02X 0x%02X 0x%02X 0x%02X 0x%02X 0x%02X ",
         (WORD)(garSysBlock[cSysBlock1stInfo]<<8|garSysBlock[cSysBlock2ndInfo]),
         (WORD)(garSysBlock[cSysBlockMPInfo]<<8|garSysBlock[cSysBlockIsp]),
         (WORD)(garSysBlock[cSysBlockLog]<<8|garSysBlock[cSysBlockIdx]), (WORD)(garSysBlock[cSysBlockSpare0]<<8|garSysBlock[cSysBlockSpare1]));
    NLOG(cLogHost, BOOTFUNC2_C, 1, " gSysOption: 0x%04X ", (WORD)gSysOption);

    gsRdlinkInfo.uResumeFromPs4=rmChkInDevSlp;
#if _EN_D3Hot_PS4
    gsRdlinkInfo.ubSaveCacheInfo=0;    // SPOR Count Abonormal;20190704_Eason_01
#endif
    gsDebugInfo.u32RdLinkStartTime=getRtcCurrent32k();
#if _EN_Liteon_ErrHandle
#if _EN_VPC_SWAP
    gJdgBootGCFlag|=(cBootH2FGC);
#else
    gJdgBootGCFlag|=(cBootH2FGC|cBootSLCQGC);
#endif
#endif
#if _EN_VPC_SWAP
    gFor512GbDebug=0;
#endif

#if (C_Log_SaveMask&C_Debug_P1)    // 20181031_Bill
    NLOG(cLogBuild, BOOTFUNC2_C, 1, " rdlinkFunc() ResumeFromPs4 = 0x%04X", gsRdlinkInfo.uResumeFromPs4);
#endif

    if(gsRdlinkInfo.uResumeFromPs4)
    {
        gsQBootInfo.ubQBootValid=1;
    }

    if(rmChkFVdt18)
    {
        gsRdlinkInfo.ubVdt18Triger=1;
    }
    else if(rmChkFVdt23)
    {
        gsRdlinkInfo.ubVdt23Triger=1;
    }

    rmClrFVdt;

    rdlinkStep1();

#if (_EN_SLC_END_PARA)

    // Set SLC endurance parameter
    // 1. normal power on, rather resume from PS4.
    // 2. resume from PS4 and M.2. (BGA not power off NAND flash for PS4)
    if((!gsRdlinkInfo.uResumeFromPs4)||(gFormFactor!=cBGA))
    {
        setSlcEndurParaCore0();
    }
#endif

    gsDebugInfo.u32RdLinkStep1Time=getRtcCurrent32k();

    rdlinkStep2();
    gsDebugInfo.u32RdLinkStep2Time=getRtcCurrent32k();

    g32Core1State=cCore1BootState_3;

    // wait core1 init Raid Engine
    while(!(g32Core1State==cCore1BootState_4))
        ;

    u32TotalHostWrSecCntH=(LWORD)(gsFtlDbg.u64TotalHostWrSecCnt>>32);
    u32TotalHostWrSecCntL=(LWORD)gsFtlDbg.u64TotalHostWrSecCnt;
    NLOG(cLogBuild, BOOTFUNC2_C, 2, " SPOR Cnt: 0x%08X ", gsFtlDbg.u32UGSDPwrOnCnt>>16, gsFtlDbg.u32UGSDPwrOnCnt);
    NLOG(cLogBuild, BOOTFUNC2_C, 2, " POR  Cnt: 0x%08X ", gsFtlDbg.u32PowerOnCnt>>16, gsFtlDbg.u32PowerOnCnt);
    NLOG(cLogBuild,
         BOOTFUNC2_C,
         4,
         " HostWrSecCnt: 0x%08X%08X ",
         u32TotalHostWrSecCntH>>16,
         u32TotalHostWrSecCntH,
         u32TotalHostWrSecCntL>>16,
         u32TotalHostWrSecCntL);
    NLOG(cLogBuild, BOOTFUNC2_C, 1, " g16PushSpareCnt: 0x%04X ", g16PushSpareCnt);

    if(chkPwrOnByQBootInfo())
    {
        if(!gsRdlinkInfo.ubVdt18Triger&&!gsRdlinkInfo.ubVdt23Triger)
        {
            gsFtlDbg.u32GSDPwrOnCnt++;
        }

#if (_EN_VPC_SWAP&&_ENABLE_RAID)
        g32arCacheBlkVpCnt=(volatile LWORD *)cCacheBlkVpCntBootStrAddr;
        readWproPageCore0(cWproCacheBlkVpCnt, cCacheBlkVpCntBootStrIdx, 0);
#endif

        if(!gsRdlinkInfo.uResumeFromPs4)    // 20190222_Bill
        {
            NLOG(cLogBuild, BOOTFUNC2_C, 0, " Boot from Qboot (POR)");    // 20181031_Bill
        }
        else
        {
            NLOG(cLogBuild, BOOTFUNC2_C, 0, " Boot from Qboot (PS4_Resume)");    // 20190304_Bill
        }

        NLOG(cLogBuild, BOOTFUNC2_C, 1, " Active H2f: 0x%04X ", gsRdlinkInfo.u16ActH2fTabFblk);
        gsRdlinkInfo.ubPwrOnByQBoot=1;
        // gsRdlinkInfo.uPowerDownMode=cGSD;
    }
    else
    {
        if(!gsRdlinkInfo.ubVdt18Triger&&!gsRdlinkInfo.ubVdt23Triger)
        {
            gsFtlDbg.u32UGSDPwrOnCnt++;
        }

        NLOG(cLogBuild, BOOTFUNC2_C, 0, " Boot need Rebuild (SPOR)");    // 20181031_Bill
        NLOG(cLogBuild, BOOTFUNC2_C, 1, " UGSD Cnt: 0x%04X ", gsFtlDbg.u32UGSDPwrOnCnt);
        NLOG(cLogBuild, BOOTFUNC2_C, 1, " Wpro: 0x%04X ", gsWproInfo.u16arWproBlk[gsWproInfo.uActIdx]);
        NLOG(cLogBuild, BOOTFUNC2_C, 1, " Active H2f: 0x%04X ", gsRdlinkInfo.u16ActH2fTabFblk);

        gsWproInfo.u16arWproIdxPagePtr[cWproQBootPg]=c16BitFF;
        gsWproInfo.uarWproIdxPtr[cWproQBootPg]=0xFF;
        gsWproInfo.u16arWproIdxPagePtr[cWproInvQBootPg]=c16BitFF;
        gsWproInfo.uarWproIdxPtr[cWproInvQBootPg]=0xFF;
        gsRdlinkInfo.ubPwrOnByQBoot=0;
        gsRdlinkInfo.uPowerDownMode=cUGSD;
#if 0    // _ByPassRdLink
        initVarInCacheInfoTab();
        initWproVar();
        gsRdlinkInfo.ubCacheInfoValid=0;
        g16FoundCachebCnt=0;
#endif
    }

// #ifdef CC_EN_EARLY    // Eason_20190125
//    if((!rmChkSoftwareReset)&&(!rmChkInDevSlp))
//    {
//        tracePcieEvent(0xB2);
//        rmSwFwModePeRst;
//        rmSetFwPeRst;
//        initNvme();
//    }
// #endif
#if (_EN_VPC_SWAP&&_ENABLE_RAID)
    // move VPC to raid ram
    pushVPCtoRaidCore0(cCacheBlkVpCntBootStrIdx);
#endif

    if((gsWproInfo.u16arWproIdxPagePtr[cWproCacheInfo]!=0xFFFF)&&(gBkFidBlock!=0xFF))
    {
        // check Fid block and swap isp block and Reset CPU
        gsFwDlInfo.uSysRsvFwDlImageBlk=gBkFidBlock;

        if(mChkCacheInfoSpf(cFwCommit))    // judge if DM block and swap flow is ok
        {
            judgeSwapIspCore0();

            if(mChkJudgeSwapIsp)
            {
                activateIspCore0();

                if(!mChkActivateFail)
                {
                    // garSmiVndrArg[0]=0;    // gSmiVndrArg0=0;
                    // NLOG(cLogSYS, BOOTFUNC_C, 0, " FW Commit Reset CPU ");
                    waitAllChCeBzCore0();    // wait all busy instead of reset by Rom code
#if 0    // def CC_EN_EARLY
                    resetCpuFwCommit(cResetCpuSrst);    // 20190212_SamHu_01
#else
                    resetCpuFwCommit(cResetCpuAll);
#endif
                }
            }
        }

        if((!(mChkCacheInfoSpf(cFwCommit)))||(!mChkJudgeSwapIsp)||mChkActivateFail)
        {
            // pushSysSprBlk(gsFwDlInfo.uSysRsvFwDlImageBlk);
            gsFwDlInfo.uSysRsvFwDlImageBlk=0xFF;
            gBkFidBlock=0xFF;
            gsRdlinkInfo.ubSaveCacheInfo=1;
            gsSmart.usStatus.uCurrFwSlot=cFwUpdateRdLink;    // As a flag, need to set the correct value in initSmart
        }

        if(!mChkCacheInfoSpf(cFwCommit))
        {
            chkIspBlockCore0();
        }
        else
        {
            mClrCacheInfoSpf(cFwCommit);
        }
    }

#ifdef CC_EN_EARLY    // Eason_20190125

    if((!rmChkSoftwareReset)&&(!rmChkInDevSlp))
    {
        tracePcieEvent(0xB2);
        rmSwFwModePeRst;
        rmSetFwPeRst;
        initNvme();
        gHandlePerstInIsrForLowPower=1;    // Recive PERST need to be processed immediately;20190705_Eason
    }
#endif

    if(gsRdlinkInfo.ubPwrOnByQBoot)    // fix ffu mode0 bug
    {
#if _EN_D3Hot_PS4

        if((gsRdlinkInfo.uResumeFromPs4)&&((gsRdlinkInfo.uPowerDownMode==cDevicePsD3)||(gsRdlinkInfo.uPowerDownMode==cGSD)))
        {
            // keep QBoot
            NLOG(cLogBuild, BOOTFUNC2_C, 1, " Keep Qboot, Dx_state=0x%04X ", rmGetDxstate);
        }
        else
#endif
        {
            progWproPageCore0(cWproInvQBootPg, c16Tsb0SIdx);    // progWproPage(cWproInvQBootPg, c16Tsb0SIdx);

            gsWproInfo.u16arWproIdxPagePtr[cWproQBootPg]=c16BitFF;
            gsWproInfo.uarWproIdxPtr[cWproQBootPg]=0xFF;
            gsWproInfo.u16arWproIdxPagePtr[cWproInvQBootPg]=c16BitFF;
            gsWproInfo.uarWproIdxPtr[cWproInvQBootPg]=0xFF;

            // progCacheInfoTab();
            gsRdlinkInfo.ubSaveCacheInfo=1;    // jalen modify
        }
    }

    if(gsWproInfo.u16arWproIdxPagePtr[cWproBadInfo]!=0xFFFF)
    {
        gsRdlinkInfo.ubBadInfoValid=1;
        chkBadInfo();

        u16TotalTlcFblkCap=((g32TotalDatSector>>3)+g32VpcPerTlcBlk-1)/g32VpcPerTlcBlk;

        g16TLCGCSpareCnt_Run=
            (g16TotalFBlock-g16OrgBadBlockCnt-g16LaterBadBlockCnt-gsBadInfo.u16TotalNewBadCnt-g16FirstFBlock-gMinStaticSlcCnt-
             u16TotalTlcFblkCap)/2;

        if(g16TLCGCSpareCnt_Run>g16TLCGCSpareCnt_Ori)
        {
            g16TLCGCSpareCnt_Run=0;
        }

        g16TlcFullCachebGcThr=u16TotalTlcFblkCap+g16TLCGCSpareCnt_Run;

        if(!gsRdlinkInfo.ubBadInfoFound)
        {
            gsRdlinkInfo.ubSaveIdxBlk=1;
        }

        ADDRINFO usAddrInfo;

        usAddrInfo.u16FBlock=gsWproInfo.u16arWproBlk[mGetWproBlkIdx(cWproBadInfo)];
        usAddrInfo.u16FPage=mGetWproPagePtr(cWproBadInfo);

        tranAddrInfoTo2Ch(&usAddrInfo);

        // first channel
        if((usAddrInfo.u16FPage!=gsRdlinkInfo.u16BadInfoPhyFPage)||
           (gsRdlinkInfo.u16BadInfoPhyFBlock0!=getDifferAddrCore0(&usAddrInfo)))
        {
            gsRdlinkInfo.ubSaveIdxBlk=1;
        }

        // second channel
        usAddrInfo.uCh+=1;

        if(gsRdlinkInfo.u16BadInfoPhyFBlock1!=getDifferAddrCore0(&usAddrInfo))
        {
            gsRdlinkInfo.ubSaveIdxBlk=1;
        }
    }
    else
    {
        gsBadInfo.u16TotalNewBadCnt=0;
        gsBadInfo.u16NewBadInBufPtr=1;
        gsBadInfo.u16TotalTLCEccFailCnt=0;
        gsBadInfo.u16ProgFailFblkCnt=0;
    }

    gsDebugInfo.u32RdLinkStep3Time=getRtcCurrent32k();
#ifndef CC_EN_EARLY    // Eason_20190125

    if((!rmChkSoftwareReset)&&(!rmChkInDevSlp))
    {
        tracePcieEvent(0xB2);
        rmSwFwModePeRst;
        rmSetFwPeRst;
        initNvme();
    }
    else    // Resume from PS4 or cpu reset
#else

    if((rmChkSoftwareReset)||(rmChkInDevSlp))
#endif
    {
        tracePcieEvent(0xB3);

#if (!_SM226X_A0)
        rmClrAllPrpListErr;
#endif

        if(gsLightSwitch.usNvmeLs.uPreCR)
        {
            rmNvmeTsbReadPreCREn;    // 2263
        }

        initNvmeBufWrap();
        initNvmeGlobVar(0);

#if _EN_NVMEWRDUALENGINE
        rmSwTwoNvmeEngine;
#else
        rmSwOneNvmeEngine;    // there are 2 NVMe Engine, but it has some bug. so switch to one engine mode.
#endif
#if _EN_NVMERDDUALENGINE
        rmSrTwoNvmeEngine;
#else
        rmSrOneNvmeEngine;
#endif

        // rmClrSoftwareReset;  // move below else if(rmChkSoftwareReset) to clear the flag
        rmClrPwFail27Fsh2;

        if(rmChkFwCommitPeIsr)
        {
            mPcieSetPerst;
            rmClrFwCommitPeIsr;
        }

        rmClrSysCryPadPd;    // for resume from PS4, set it to default

        // rmSetARBSoftReset;
        rmSetHmbSoftReset;    // Reset Hmb
        sysDelay(2);
        // rmClrARBSoftReset; //LeverYu_0813 SMI S0813A  SQ mismatch issue
        rmClrHmbSoftReset;

        // resume HMB setting
#if _EN_DisHMBInReset    // 20190805_Chief_DisHMB

        if(gsHmbInfo.uHmbEnable||(gChkFlag&cEnableFakeHMB))    // &&(upPrdInfo->uE2eRetry&cBit7))
#else

        if(gsHmbInfo.uHmbEnable)
#endif
        {
            resumeHmbSetting(cReadWpro);
        }

        for(u32Loop=0; u32Loop<cHmbRacingFreeCnt; u32Loop++)
        {
            g16WriteHMBH2FTable[u32Loop]=c16Null;
        }

        gsHmbInfo.uHmbHwPrdTail=rmHmbPrdQueTrigIdx;
        gsHmbInfo.uHmbHwPrdHead=rmHmbPrdQueTrigIdx;
        rmRstCrc32PutAddr;
        gsHmbInfo.uRdCrcIdx=0;
        gsHmbInfo.uWrCrcIdx=0;
    }

    __disable_irq();

    if(rmChkInDevSlp)    // Boot from PS4
    {
        g64PwrOnPs4Cnt++;
/*      temp mark due to out of code size
   *      NLOG(cLogPS,
   *           BOOTFUNC_C,
   *           3,
   *           " Boot from NVMe PS4, Device CurState=%d, CC_EN=0x%02X, CC_RDY=0x%02X, CMD_RDY=0x%04X ",
   *           gsPowerState.uDevLastPs,
   *           (rmChkCcEn<<8)|rmChkCcRdy,
   *           rmChkCmdRdy);
   *      NLOG(cLogPS,
   *           BOOTFUNC_C,
   *           4,
   *           " PS4 resume, PCIe Init_0_1_Sts=0x%08X, PCIe Int_2_3_Sts=0x%08X ",
   *           rmGetPcieIntr01Sts>>16,
   *           rmGetPcieIntr01Sts,
   *           rmGetPcieIntr23Sts>>16,
   *           rmGetPcieIntr23Sts);
   *      NLOG(cLogPS,
   *           BOOTFUNC_C,
   *           4,
   *           " PS4 resume, NVMe Init_LOW_Sts=0x%08X, PCIe Int_HIGH_Sts=0x%08X ",
   *           rmChkNvmeUnexIntStatLow>>16,
   *           rmChkNvmeUnexIntStatLow,
   *           rmChkNvmeUnexIntStatHigh>>16,
   *           rmChkNvmeUnexIntStatHigh);
   */
        initInt(0, 1);    // Keep Status

        // PCIe Setting
        // Resettubg L1.2 timer, set 0 when PS4
        disPcieLowPwrMo(1);    // for PS4
#if 1    // (S_PS35toPS4DoNotWakeLink)
        rmClrKeepPcieLinkSleep;    // clear flag
#endif
        rmSetL1TimerReg((gsLightSwitch.usPcieLs.usLinkStateEntranceIdleTime.u32All&0x0000FFFF)<<3);    // L1 wait time into L1.2, 8=1ms

#if _ENABLE_SCP_PLP
        BYTE uDoPlpScp=0;

        // Ps4 sleep
        if(mChkNvmeEnPlpScp&&(!mChkGpioInitPlpScp))
        {
            if(rmGpioP25PlpInitAssert)
            {
                NLOG(cLogPS, BOOTFUNC2_C, 0, "Assert in Ps4, handlePlpScpFlow");
                hdlPlpScpFlow(0);
                uDoPlpScp=1;
            }

            // Clear interupt source if Plpinit assert in Ps4 sleep but deassert before hanldePlpScpFlow
            if(mGpioP2GetIsrState(cGpioB5))    // hw read check confirm
            {
                if(!uDoPlpScp)
                {
                    gsFtlDbg.u32PlpScpGpioInitCnt++;
                    NLOG(cLogPS,
                         BOOTFUNC2_C,
                         2,
                         "Assert in Ps4 but de-assert before handlePlpScpFlow, PlpScpGpioInitCnt=%08d",
                         gsFtlDbg.u32PlpScpGpioInitCnt>>16,
                         gsFtlDbg.u32PlpScpGpioInitCnt&0xffff);
                }

                gpioClrIsr(rcGpioIntSetP2, cGpioB5);

                if(mGpioP2GetIsrState(cGpioB5))    // hw read check confirm
                {
                    gpioClrIsr(rcGpioIntSetP2, cGpioB5);
                }
            }
        }
#endif/* if _ENABLE_SCP_PLP */
    }
    else if(rmChkSoftwareReset)
    {
        tracePcieEvent(0xB4);
        gFwResetCpuForSec=1;

        rmClrSoftwareReset;
        gChgtoD0=0;

        if(rmChkPcieD0State)
        {
            gChgtoD0=1;
        }

        gLtrEnabled=0;

        if(!    /*rmChkLtrMsgReg0LtrMsgActiveEn*/ rmChkLtrMsgReg0LtrMsgIdle0En)
        {
            waitPclkRdy();
            initPcieLtrMsg();

            if(rmChkLtrEnable)
            {
                gLtrEnabled=1;    // need to check max snoop
                g32LtrValue0=0;    // need reassign
                g32LtrValue2=0;    // need reassign
            }
        }

        if(rmChkNvmeNSSRO)    // after firmware commit activation, the NSSRO must clear 0.
        {
            rmClrNvmeNSSRO;
        }

        initInt(0, 1);
    }
    else
    {
        tracePcieEvent(0xB5);
        initInt(0, 0);
        NLOG(cLogPS, BOOTFUNC2_C, 1, " Boot from power off 0x%04X", gsRdlinkInfo.uPowerDownMode);
        mNvmeSetPowerOn;    // 20190218_Jesse_01, Add for Dell spec "ENG0013785_A01", DITM saveable doesn't keep after Power-off.
    }

    __enable_irq();

    gsDebugInfo.u32InitNvmeTime=getRtcCurrent32k();

    while((mChkCacheInfoSpf(cSecurErase)||(mChkCacheInfoSpf(cSanitize)))&&gsRdlinkInfo.ubPwrOnByQBoot)
        ;

#if (!_ByPassRdLink)

    if((!gsRdlinkInfo.ubPwrOnByQBoot)&&(!mChkCacheInfoSpf(cSecurErase))&&(!mChkCacheInfoSpf(cSanitize)))
    {
        setWproBlkPopBit();

        rebuSpareFblock();

        calWproBlkCnt();

        setDiffType2BlkEraseCnt();

        // setGlobEraseCnt();

        if(!gsRdlinkInfo.ubDoNotScanAllBlk)
        {
            // debugLoop();

            rebuH2fTableInfo();
#if (C_Log_SaveMask&C_Debug_P1)    // _BootFunc2_log    // 20181025_Bill
            NLOG(cLogBuild, BOOTFUNC2_C, 0, " rebuH2fTableInfo() end");
#endif
            // setGlobEraseCnt();

#if _DEBUG_VPCNT
            chkVpCnt();
#endif

            if(gsRdlinkInfo.ubCacheInfoValid)
            {
                if(gsRdlinkInfo.u16BkActiveGcDesBlock!=c16FBlockInitValue)
                {
#if _EN_FLASH_WR_CMD
                    flashWriteCmdCore0(gsRdlinkInfo.u16BkActiveGcDesBlock);
#endif
#if _EN_VPC_SWAP

                    if(!mChkVPCntValid(gsRdlinkInfo.u16BkActiveGcDesBlock))
#else

                    if(mGetCacheBlkVpCnt(gsRdlinkInfo.u16BkActiveGcDesBlock)==0)
#endif
                    {
                        while(gsRdlinkInfo.u16BkActiveGcDesBlock>c16FBlockInitValue)
                            ;

                        mSetSkipGcBit(gsRdlinkInfo.u16BkActiveGcDesBlock);
                        // destroySrcBlock(gsRdlinkInfo.u16BkPrePopCacheBlock);
                        pushSpareBlockCore0(gsRdlinkInfo.u16BkActiveGcDesBlock, cPushNotErase);
                        gsRdlinkInfo.u16BkActiveGcDesBlock=c16FBlockInitValue;
                    }
                }

#if _EN_RAID_UGSD

                for(BYTE uIdx=0; uIdx<cRaidParityBlockNum; uIdx++)
                {
                    if(g16arRaidParityBlk[uIdx]!=c16BitFF)
                    {
                        pushSpareBlockCore0(g16arRaidParityBlk[uIdx], cPushNotErase);
                    }
                }

                bopClrRam((LWORD)g16arRaidParityPtr, cRaidParityPageNum*2, 0xFFFFFFFF, cBopWait|cClrTsb);    // TSB1(Cache INFO)
                bopClrRam((LWORD)g16arRaidParityBlk, cRaidParityBlockNum*2, 0xFFFFFFFF, cBopWait|cClrTsb);    // TSB1(Cache INFO)
                bopClrRam((LWORD)g16arRaidPtyBlkVpCnt, cRaidParityBlockNum*2, 0x00000000, cBopWait|cClrTsb);    // TSB1(Cache INFO)
                gsCacheInfo.u16RaidPtyFreePagePtr=c16BitFF;
                gsCacheInfo.u16RaidGcPtyFreePagePtr=c16BitFF;
                gsCacheInfo.uRaidPtyBlockCnt=0;
                gsCacheInfo.uRaidPtyBlkIdx=0;
                gsCacheInfo.uRaidGcPtyBlkIdx=0;
#endif/* if _EN_RAID_UGSD */
            }

            rebuCacheF2hTable();
#if (C_Log_SaveMask&C_Debug_P1)    // _BootFunc2_log    // 20181025_Bill
            NLOG(cLogBuild, BOOTFUNC2_C, 0, " rebuCacheF2hTable() end");
#endif
#if _DEBUG_VPCNT
            chkVpCnt();
#endif
        }

        clrErrorBlock();

        rdlinkStep3();

        // add pending page
        if((gsWproInfo.uCnt)&&(gsWproInfo.u16WproFreePagePtr<gsWproInfo.u16PagePerBlock3))
        {
            progWproPageCore0(cMaxWproPageType, c16Tsb0SIdx);
        }
    }
    else
#endif    // #if _ByPassRdLink
    {
        getGlobEraseCnt();

        if(mChkCacheInfoSpf(cSecurErase)||(mChkCacheInfoSpf(cSanitize)))
        {
            setWproBlkPopBit();
            calWproBlkCnt();
            setSpareBlockCnt();
        }

        if(g16PushSpareCnt)
        {
            chkPushSpareQCore0(1);
            gsRdlinkInfo.ubSaveCacheInfo=1;
        }
    }

    saveRdTimeStamp(11);

    if(gsRdlinkInfo.ubVdt18Triger)
    {
        gsFtlDbg.u32Vdt18FailCnt++;
        gsRdlinkInfo.ubSaveCacheInfo=1;
    }
    else if(gsRdlinkInfo.ubVdt23Triger)
    {
        gsFtlDbg.u32Vdt23FailCnt++;
        gsRdlinkInfo.ubSaveCacheInfo=1;
    }

#if _EN_VPC_SWAP
#if _ENABLE_RAID
    popVPCfromRaidCore0(cCacheBlkVpCntRdlinkEndStrIdx);
    mSetBitMask(g32VPCSwapFlag, cVPCntBufValid);
    g32arCacheBlkVpCnt=(volatile LWORD *)(cCacheBlkVpCntRdlinkEndStrAddr);
#else

    if(!gsRdlinkInfo.ubCacheInfoValid&&(gsWproInfo.u16arWproIdxPagePtr[cWproCacheInfo]==c16BitFF))
    {
        // Prog Changed VPCnt
        progWproPageCore0(cWproCacheBlkVpCnt, cCacheBlkVpCntBootStrIdx);
    }
#endif
#endif

    // force progCacheInfoTab for Jira-159,160. UGSD mismatch issue.
    // if(gsRdlinkInfo.ubSaveCacheInfo)
    // {
#if _EN_D3Hot_PS4

    if((!(gsRdlinkInfo.uResumeFromPs4&cBit1))&&(gsRdlinkInfo.ubSaveCacheInfo))
#endif
    {
        progCacheInfoTab();
#if (C_Log_SaveMask&C_Debug_P1)    // _BootFunc2_log    // 20181025_Bill
        NLOG(cLogBuild, BOOTFUNC2_C, 0, " progCacheInfoTab() end");
#endif
    }

    // }

#if _EN_VPC_SWAP
    g32VPCSwapFlag=0;
#endif

    // if(gsRdlinkInfo.ubSaveIdxBlk||gbUpdIdxF)  //20190722_SamHu_01
    if(gsRdlinkInfo.ubSaveIdxBlk)
    {
        saveIndexBlockCore0();
#if (C_Log_SaveMask&C_Debug_P1)    // _BootFunc2_log    // 20181025_Bill
        NLOG(cLogBuild, BOOTFUNC2_C, 0, " saveIndexBlockCore0() end");
#endif
    }

    if((gsCacheInfo.u16PrePopCacheBlock!=c16FBlockInitValue)&&(mChkPoppedBitRL(gsCacheInfo.u16PrePopCacheBlock)))
    {
        // destroySrcBlock(gsCacheInfo.u16PrePopCacheBlock);
        pushSpareBlockCore0(gsCacheInfo.u16PrePopCacheBlock, cPushNotErase);
    }

    gsCacheInfo.u16PrePopCacheBlock=c16FBlockInitValue;

    saveWproBadInfoCore0();
#if (C_Log_SaveMask&C_Debug_P1)    // _BootFunc2_log    // 20181025_Bill
    NLOG(cLogBuild, BOOTFUNC2_C, 0, " saveWproBadInfoCore0() end");
#endif
#if 0
    /* test code */
    debugLoop();
#if 0
    g32arCacheBlkVpCnt[0]=0x5555AAAA;
    // progWproPage(cWproCacheInfo, c16CacheInfoTabSIdx);
    progCacheInfoTab();
    g32arCacheBlkVpCnt[0]=0x00000000;
    readWproPageCore0(cWproCacheInfo, c16Tsb0SIdx, 0);

    g32arCacheBlkVpCnt[0]=0xAAAA5555;
    // gsCacheInfo.u32DummyProgFreePagePtr=0x5A5A5A5A;
    // gsRwCtrl.u32LastLbaW=0xAAAA5555;
    gsGcInfo.u32BgdGcEndTime=0x5555AAAA;
    r32SkipRam[0]=0xAAAA5555;
    garCacheF2hTab[0].u16HBlock=0x5555;
    garCacheF2hTab[0].u16HPage=0xAAAA;
    progWproPageCore0(cWproQBootPg, c16Tsb0SIdx);

    g32arCacheBlkVpCnt[0]=0;
    // gsCacheInfo.u32DummyProgFreePagePtr=0;
    garCacheF2hTab[0].u16HBlock=0;
    garCacheF2hTab[0].u16HPage=0;
    // gsRwCtrl.u32LastLbaW=0x0;
    gsGcInfo.u32BgdGcEndTime=0x0;
    r32SkipRam[0]=0x0;

    readWproPageCore0(cWproQBootPg, c16Tsb0SIdx, 0);
#endif/* if 0 */
    WORD u16Loop;
    BYTE uIdx;

    for(u16Loop=0; u16Loop<100; u16Loop++)
    {
        for(uIdx=cWproGcDesF2hTab00; uIdx<cMaxWproPageType; uIdx++)
        {
            // if(gsWproInfo.uCnt>=3)
            // {
            //    progCacheInfoTab();
            // }

            progWproPageCore0(uIdx, c16Tsb0SIdx);
        }

        // readWproPageCore0(cWproCacheInfo, c16Tsb0SIdx, 0);

        for(uIdx=cWproGcDesF2hTab00; uIdx<cMaxWproPageType; uIdx++)
        {
            readWproPageCore0(uIdx, c16Tsb0SIdx, 0);
        }
    }
    debugLoop();
#endif/* if 0 */

    saveRdTimeStamp(13);

    if(mChkCacheInfoSpf(cSecurErase)||(mChkCacheInfoSpf(cSanitize))
#if _EN_KEEP_RW_ON_ERROR    // Chief_20190305
       ||mChkCacheInfoSpf(crelinkWhileFormat)
#endif
       )
    {
        NLOG(cLogSYS,
             BOOTFUNC2_C,
             2,
             "rdlinkFunc For cSecurErase or cSanitize Flag = 0x%08X",
             g32SpecFuncFlag>>16, g32SpecFuncFlag);
        mClrCacheInfoSpf(cSecurErase);
        mClrCacheInfoSpf(cSanitize);
#if _EN_KEEP_RW_ON_ERROR    // Chief_20190305
        mClrCacheInfoSpf(crelinkWhileFormat);
#endif
        eraseUnitProcCore0(1);
    }

    gsRdlinkInfo.ubSaveCacheInfo=1;    // for next time do any Program CMD mark

    gsRdlinkInfo.u16SlcSprBlockCnt=gsCacheInfo.u16SLCSpareCnt;
    gsRdlinkInfo.u32TotalSlcVpc=gsGcInfo.u32TotalSlcVpc;
    gsRdlinkInfo.u32TotalTlcVpc=gsGcInfo.u32TotalTlcVpc;

    NLOG_SAVE(cLogBuild, BOOTFUNC2_C, 0, CBuildLinkFinish, " Build Link Finish! ");

#if (C_Log_SaveMask&C_Debug_P1)    // 20181031_Bill BootFunc2
    NLOG(cLogSYS,
         BOOTFUNC2_C,
         6,
         " SLCSpareBlockCnt = 0x%04X ,TLCSpareBlockCnt = 0x%04X ,SLCFullCacheBlockCnt = 0x%04X, TLCFullCacheBlockCnt = 0x%04X, g16SlcSortQCnt = 0x%04X, g16PushSpareCnt=0x%04X",
         gsCacheInfo.u16SLCSpareCnt,
         gsCacheInfo.u16DynamicSpareCnt,
         gsCacheInfo.u16FullCacheBlockCnt,
         gsCacheInfo.u16TLCFullCacheBlockCnt,
         g16SlcSortQCnt,
         g16PushSpareCnt);
    NLOG(cLogSYS,
         BOOTFUNC2_C,
         4,
         " ActiveCacheBlock = 0x%04X ,CacheFreePagePtr = 0x%08X ,CacheF2hTabFreePtr = 0x%04X",
         gsCacheInfo.u16ActiveCacheBlock,
         gsCacheInfo.u32CacheFreePagePtr>>16,
         gsCacheInfo.u32CacheFreePagePtr,
         gsCacheInfo.u16CacheF2hTabFreePtr);
    NLOG(cLogSYS,
         BOOTFUNC2_C,
         1,
         " g16StaticBound = 0x%04X",
         );
    NLOG(cLogSYS,
         BOOTFUNC2_C,
         6,
         " g16OrgBadBlockCnt = 0x%04X ,g16LaterBadBlockCnt = 0x%04X ,gsBadInfo.u16TotalNewBadCnt = 0x%04X ,u16TotalTlcFblkCap = 0x%04X ,g16TLCGCSpareCnt_Ori = 0x%04X ,g16TLCGCSpareCnt_Run = 0x%04X",
         g16OrgBadBlockCnt,
         g16LaterBadBlockCnt,
         gsBadInfo.u16TotalNewBadCnt,
         (g32TotalDatSector>>3)/g32VpcPerTlcBlk,
         g16TLCGCSpareCnt_Ori,
         g16TLCGCSpareCnt_Run);
#endif/* if (C_Log_SaveMask&C_Debug_P1) */

#if _EN_512Gb_Debug
    WORD u16TotalBlkCnt=gsCacheInfo.u16SLCSpareCnt+gsCacheInfo.u16DynamicSpareCnt+gsCacheInfo.u16FullCacheBlockCnt+
                         gsCacheInfo.u16TLCFullCacheBlockCnt+gsCacheInfo.uH2fTabBlockCnt+gsWproInfo.uCnt+g16LaterBadBlockCnt+g16PushSpareCnt;

    NLOG(cLogTempDebug,
         BOOTFUNC2_C,
         7,
         " SLCSprCnt=0x%04X, TLCSprCnt=0x%04X , SLCFullCnt=0x%04X, TLCFullCnt=0x%04X, H2FCnt=0x%04X, WproCnt=0x%04X, TotalCnt=0x%04X",
         (WORD)gsCacheInfo.u16SLCSpareCnt,
         (WORD)gsCacheInfo.u16DynamicSpareCnt,
         (WORD)gsCacheInfo.u16FullCacheBlockCnt,
         (WORD)gsCacheInfo.u16TLCFullCacheBlockCnt,
         (WORD)gsCacheInfo.uH2fTabBlockCnt,
         (WORD)gsWproInfo.uCnt,
         (WORD)u16TotalBlkCnt);
#endif

    if(g16SaveEventLog)
    {
        // synchronize wpro variable

        // saveEventLog(0);
    }

    waitCmdAllDone(cWaitTrigRCnt|cWaitTrigWCnt|cWaitCmdBz);    // debug

    while(gsRwCtrl.u32UpdFifoPtr!=gsRwCtrl.u32ProgFifoTail)
        ;// debug

    gsRwCtrl.u32SrchFifoPtr=gsRwCtrl.u32UpdFifoPtr;

    /*
       * NLOG(cLogBuild, BOOTFUNC_C, 4, "Spare cnt: 0x%04X, TLC spare cnt: 0x%04X, GC type bit: 0x%04X, GC Queue cnt: 0x%04X",
       *   gsCacheInfo.u16SpareBlockCnt,
       *   gsCacheInfo.u16TLCSprBlockCnt,
       *   gsGcInfo.uGcTypBit,
       *   gsGcInfo.uGcQueueCnt);
       */
}    /* rdlinkFunc */

void initFtlVar()
{
    WORD u16Loop;
    BYTE uLoop;

    // gsCacheInfo.u16SpareBlockCnt=200;
    // gsCacheInfo.u15ActiveH2fTab=c15BitFF;
    // gsCacheInfo.ubPrep=0x00;
    gsCacheInfo.u16ActiveCacheBlock=c16FBlockInitValue;
    mSetCacheInfoFlag(cH2fTabBlockFull);    // gsCacheInfo.ubH2fTabBlockFull=1;

    gsCacheInfo.u32CacheFreePagePtr=c32BitFF;
    gsCacheInfo.u32CacheBlkSerial=c32InitSerialVal;
    gsCacheInfo.u32FluBlkSerial=c32InitSerialVal;
    gsCacheInfo.u32H2fTabBlkSerial=c32InitSerialVal;

    // gsCacheInfo.u16FlushF2hTabPtr=c16BitFF;
    gsCacheInfo.u16FluCacheBlock=c16FBlockInitValue;

    gsCacheInfo.uFlushCacheBlkBank=0;
    gsCacheInfo.u16PrePopCacheBlock=c16FBlockInitValue;

    // gsCacheInfo.u16SpareBlockCnt=200;
    // gsCacheInfo.u15ActiveH2fTab=c15BitFF;
    // gsCacheInfo.ubPrep=0x00;

    g32SectorPerHBlock=g32H2fTabValidSize/4*cSctrPer4k;    // 16K 4KPages (Table size is 64K, one entry 4 Byte,Total (64K/4) 4Knum)
    gsCacheInfo.u16CacheF2hTabFreePtr=c16CacheF2hSize-1;
    g32MaxCachePageNum=c16CacheF2hSize;
    // g16FakeCmdPtr=0x00;
    // gChgBlock=1;
    mSetCacheInfoFlag(cCacheBlockFull);    // gsCacheInfo.ubCacheBlockFull=1;
    mClrCacheInfoChangeFlag(cH2fChg);    // gsCacheInfo.ubH2fChg=0;

    // continue write
    g32LastLbaW=0xFFFFFFFF;
    // gbSeqAccess=1;
    // gsRwCtrl.u32LastLbaW=0xFFFFFFFF;
    gsRwCtrl.uCacheStartSctr=0;
    gsRwCtrl.uCacheEndSctr=cSctrPer4k;
    gsRwCtrl.u32LastTrimLba=c32BitFF;

    // gsRwCtrl.usBootErsCmdInfo.uSysBlkIdx=cInvalid8Bit;

    g32LastLbaR=0xFFFFFFFF;
    g16SrchSrcTabFreePtr=0;
    gLastTrigPrdTaskType=0;

    // gsIsrCtrl.u16BufFree4kCnt=c16ReadBufSize4K;    // (384/4)
    gsRwCtrl.uFreeHSgmtCnt=cMaxRH2fTabNum;
    // gsRwCtrl.u16SrchFreeCnt=cSrchSrcNum;
    gsCacheInfo.u16HblkCntInCache=0;
    // REX
    // gsRwCtrl.uMaxFLChFifoDpt=div(c16WriteBufSize, cSctrPer4k*gTotalChNum);
    gsRwCtrl.u16ProgPageOfst=0;

    // Reset H2F1K table [CC]
    rstH2F1KInfo();

    // Reset HMB management
    // bopClrRam((LWORD)&gsHmbInfo, sizeof(gsHmbInfo), 0xFFFFFFFF, cBopWait|cClrStcm);
    // bopClrRam((LWORD)&gsHmbQueInfo, sizeof(gsHmbQueInfo), 0xFFFFFFFF, cBopWait|cClrStcm);
    for(u16Loop=0; u16Loop<g16HmbMaxTableNum; u16Loop++)
    {
        gsHmbInfo.uarHmbLink[u16Loop].u16Prev=u16Loop-1;
        gsHmbInfo.uarHmbLink[u16Loop].u16Next=u16Loop+1;
        gsHmbInfo.u16arFreeHmbQ[u16Loop]=u16Loop;
    }

    gsHmbInfo.uarHmbLink[g16HmbMaxTableNum-1].u16Next=c16Null;
    gsHmbInfo.uHmbEnable=cFalse;
    // gsE2eInfo.uHmbEnable=cFalse;    // for Core1 use.
    gsHmbInfo.uHmbStsChg=cFalse;
    // gsHmbInfo.usHmbList.u16Cnt=0;
    gsHmbInfo.usHmbList.u16Head=c16Null;
    gsHmbInfo.usHmbList.u16Tail=c16Null;
    gsHmbInfo.usHmbList.u16Trig=c16Null;

    // gReadFlag=0;
    /*
       * for(uLoop=0; uLoop<cMaxRH2fTabNum; uLoop++)
       * {
       *  gsHmbInfo.uarHmbPrdLink[uLoop].uPrev=uLoop-1;
       *  gsHmbInfo.uarHmbPrdLink[uLoop].uNext=uLoop+1;
       *  gsHmbInfo.uarFreeHmbPrdQ[uLoop]=uLoop;
       * }
       *
       * gsHmbInfo.uarHmbPrdLink[cMaxRH2fTabNum-1].uNext=cNull;
       * gsHmbInfo.usHmbPrdList.u16Head=cNull;
       * gsHmbInfo.usHmbPrdList.u16Tail=cNull;
       * gsHmbInfo.usHmbPrdList.u16Trig=cNull;
       */

    // gsHmbInfo.uHmbHwPrdTail=0;
    gsHmbInfo.uHmbFreeHwPrdCnt=cHmbHwPrdDepth;
#if _ENABLE_HMB_FLUSH
    gsHmbInfo.u16HmbLastDirtyPtr=c16Null;
#endif

    for(uLoop=0; uLoop<cMaxRH2fTabNum; uLoop++)
    {
        gsRwCtrl.uarTab2PrdPtr[uLoop]=cNull;
    }

    for(uLoop=0; uLoop<cPrdDepth; uLoop++)
    {
        gsRwCtrl.uarTabLinkPtr[uLoop]=cNull;
    }

    for(uLoop=0; uLoop<cSrchEnginDepth; uLoop++)
    {
        gsRwCtrl.uarFreeNbsSlot[uLoop]=uLoop;
    }

    gsRwCtrl.uFreeNbsSlotCnt=cSrchEnginDepth;

    // gH2fSgmtRdyHead=0;
    // gH2fSgmtRdyTail=0;
    // gH2fSgmtRdyCnt=0;
    // g64H2f1kTabSgmtPrep=0;
    // gH2f1KPrepCnt=0;

    for(uLoop=0; uLoop<cPrdDepth; uLoop++)
    {
        gsPrdInfo.uarPrdLink[uLoop].uPrev=uLoop-1;
        gsPrdInfo.uarPrdLink[uLoop].uNext=uLoop+1;
        gsPrdInfo.uarFreePrdQue[uLoop]=uLoop;
    }

    // gsPrdInfo.uarPrdLink[0].uPrev=cNull;
    gsPrdInfo.uarPrdLink[cPrdDepth-1].uNext=cNull;

    // gsPrdInfo.usReadPrdList.u16Cnt=0;
    gsPrdInfo.usReadPrdList.u16Head=cNull;
    gsPrdInfo.usReadPrdList.u16Tail=cNull;
    gsPrdInfo.usReadPrdList.u16Trig=cNull;
    gsPrdInfo.u16SeqRd4kRstCnt=c16ReadBufSize4K;
    gsPrdInfo.uSeqRTrigCnt=0;
    // gsPrdInfo.usWritePrdList.u16Cnt=0;
    gsPrdInfo.usWritePrdList.u16Head=cNull;
    gsPrdInfo.usWritePrdList.u16Tail=cNull;
    gsPrdInfo.usWritePrdList.u16Trig=cNull;
    gsPrdInfo.u16TrigHostRestSectCnt=0;
    // gsPrdInfo.u32TotalWritePrdListSctrCnt=0;

#if 0    // (_ENABLE_SRC_LINK_LIST) // init at core 1

    for(uLoop=0; uLoop<cReadFifoDpt; uLoop++)
    {
        gsRwCtrl.uarSrcCmdLink[uLoop].uPrev=uLoop-1;
        gsRwCtrl.uarSrcCmdLink[uLoop].uNext=uLoop+1;
        gsRwCtrl.uarFreeSrcQue[uLoop]=uLoop;
    }

    // gsRwCtrl.uarSrcCmdLink[0].uPrev=cNull;
    gsRwCtrl.uarSrcCmdLink[cReadFifoDpt-1].uNext=cNull;

    // gsRwCtrl.usSrcCmdList.u16Cnt=0;
    gsRwCtrl.usSrcCmdList.u16Head=cNull;
    gsRwCtrl.usSrcCmdList.u16Tail=cNull;
    gsRwCtrl.usSrcCmdList.u16Trig=cNull;
#endif/* if (_ENABLE_SRC_LINK_LIST) */

#if _EnSpareFunc

    for(uLoop=0; uLoop<cMaxChNum; uLoop++)
    {
        gWaitSpareTyp[uLoop]=0xFF;
        gSpareCnt[uLoop]=0;
        gSparePtrHead[uLoop]=0;
        gSparePtrTail[uLoop]=0;
    }
    mSetNewDesF;
#endif

    gWriteHMBIndex=0;

    for(uLoop=0; uLoop<cHmbRacingFreeCnt; uLoop++)
    {
        g16WriteHMBH2FTable[uLoop]=c16Null;
    }

    bopClrRam((LWORD)&garSrchSrcTab, sizeof(garSrchSrcTab), 0xFFFFFFFF, cClrCore0Dccm|cBopWait);

    // gsRwCtrl.u32Debug2=1;    // to pass greybox

#if _EN_IDLEGC_DELAY
    g32BgdGCSkipResetCnt=cBgdGcResetSctr;
#endif
}    /* initFtlVar */

void setSpareBlockCnt()
{
    WORD u16Fblock, u16TotalEraseCount;

    if(mChkCacheInfoSpf(cSanitize))
    {
        u16TotalEraseCount=gsEraseUnitInfo.usEraseParam.uTotalPass;
    }
    else    // mChkCacheInfoSpf(cSecurErase)
    {
        u16TotalEraseCount=1;
    }

#if !_EN_Always_DynamicMode
    gsCacheInfo.u16SpareBlockCnt=0;
    gsCacheInfo.u16TLCSprBlockCnt=0;
#endif
#if _EN_Dynamic_Fix_Boundary
    gsCacheInfo.u16SLCSpareCnt=0;
    gsCacheInfo.u16DynamicSpareCnt=0;
#if _EN_Always_DynamicMode
    gsCacheInfo.u16SpareBlockCnt=0;
#endif
#endif

    if(g16PushSpareCnt)    // 20190312_Louis
    {
        chkPushSpareQCore0(1);
        gsRdlinkInfo.ubSaveCacheInfo=1;
    }

    for(u16Fblock=g16FirstFBlock; u16Fblock<g16TotalFBlock; u16Fblock++)
    {
        if(mGetGlobEraseCntRL(u16Fblock)!=c16BitFF)
        {
#if !_EN_Always_DynamicMode

            if(!mChkMlcMoBit(u16Fblock))
            {
                gsCacheInfo.u16SpareBlockCnt++;
            }
            else
            {
                gsCacheInfo.u16TLCSprBlockCnt++;
            }
#endif
#if _EN_Dynamic_Fix_Boundary

            if(u16Fblock<g16StaticBound)
            {
                gsCacheInfo.u16SLCSpareCnt++;
            }
            else
            {
                gsCacheInfo.u16DynamicSpareCnt++;
            }

#if _EN_Always_DynamicMode
            gsCacheInfo.u16SpareBlockCnt++;
#endif
#endif

            mClrPoppedBit(u16Fblock);

            if(!mChkCacheInfoSpf(cSecurErase))
            {
                if(mGetGlobEraseCntRL(u16Fblock)<(c16BitFF-u16TotalEraseCount))
                {
                    mSetGlobEraseCntRL(u16Fblock, (mGetGlobEraseCntRL(u16Fblock)+u16TotalEraseCount));
                    setGlobEraseCnt1Blk(u16Fblock, g16arTempGlobEraseCnt[u16Fblock], 0);
                }
                else
                {
                    mSetGlobEraseCntRL(u16Fblock, c16BitFF);
                    setGlobEraseCnt1Blk(u16Fblock, g16arTempGlobEraseCnt[u16Fblock], 1);
                }
            }
        }
    }
}    /* setSpareBlockCnt */

void relinkSaveQBDummy(BYTE uFailType)
{
    if(gsRdlinkInfo.ubCacheInfoValid)
    {
        NLOG(cLogBuild, BOOTFUNC2_C, 1, " relinkSaveQBDummy! uFailType=0x%04x", uFailType);
        saveQBInfowithDummyCore0(uFailType);
    }
    else
    {
        while(1)
            ;
    }
}

void relinkSaveDummyQBAnalysis(WORD u16Para0, WORD u16Para1, WORD u16Para2, WORD u16Para3)
{
    for(BYTE uCnt=0; uCnt<4; uCnt++)
    {
        g16DummyQBAnalysis[uCnt]=0;
    }

    if(gsRdlinkInfo.ubCacheInfoValid)
    {
        g16DummyQBAnalysis[0]=u16Para0;
        g16DummyQBAnalysis[1]=u16Para1;
        g16DummyQBAnalysis[2]=u16Para2;
        g16DummyQBAnalysis[3]=u16Para3;
    }
    else
    {
        NLOG(cLogBuild, BOOTFUNC2_C, 0, " relinkSaveDummyQBAnalysis! CacheInfo isn't Valid");
    }
}    /* relinkSaveDummyQBAnalysis */

#if _EN_KEEP_RW_ON_ERROR
void relinkKeepRwonError(WORD u16Para0, WORD u16Para1, WORD u16Para2, WORD u16Para3)
{
    WORD u16FreeIdx;
    WORD *u16pErrorInfo;

    if(gsRdlinkInfo.ubCacheInfoValid)
    {
        if(!mChkRLKeepRWBit(u16Para0))
        {
            NLOG(cLogBuild,
                 BOOTFUNC2_C,
                 4,
                 " uFailType=0x%04x , Para1=0x%04x , Para2=0x%04x , Para3=0x%04x",
                 u16Para0,
                 u16Para1,
                 u16Para2,
                 u16Para3);

            rstH2F1KInfo();

            if(gsWproInfo.u16arWproIdxPagePtr[cWproErrorInfo]==0xFFFF)    // first program
            {
                bopClrRam(c32Tsb0SAddr+(c16RH2fTabSIdx<<9), gSectorPerPlaneH*512, 0, cClrTsb|cBopWait);
            }
            else
            {
                readWproPageCore0(cWproErrorInfo, c16RH2fTabSIdx, 0);
            }

            u16pErrorInfo=(WORD *)garTsb0[0]+((c16RH2fTabSIdx<<9)/2);
            u16FreeIdx=u16pErrorInfo[0];

            if(u16FreeIdx>=((gSectorPerPlaneH*512-0x10)/8))
            {
                return;
            }

            u16pErrorInfo[0x08+u16FreeIdx*4]=u16Para0;
            u16pErrorInfo[0x08+u16FreeIdx*4+1]=u16Para1;
            u16pErrorInfo[0x08+u16FreeIdx*4+2]=u16Para2;
            u16pErrorInfo[0x08+u16FreeIdx*4+3]=u16Para3;
            u16FreeIdx++;
            u16pErrorInfo[0]=u16FreeIdx;
            progWproPageCore0(cWproErrorInfo, c16RH2fTabSIdx);
            rstH2F1KInfo();

            mSetRLKeepRWBit(u16Para0);
        }
    }
    else
    {
        mSetCacheInfoSpf(crelinkWhileFormat);
    }
}    /* relinkKeepRwonError */

#endif/* if _EN_KEEP_RW_ON_ERROR */
#if (!_ICE_LOAD_ALL)
#pragma default_function_attributes =
#endif







