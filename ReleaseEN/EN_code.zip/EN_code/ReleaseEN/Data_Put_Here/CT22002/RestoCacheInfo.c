







/*
   * void findCacheInfoBlock()
   * {
   *  WORD u16Fblock;
   *  LWORD u32TempSerial=c32InitSerialVal;
   *  LWORD u32PowerOnCnt=c32InitSerialVal;
   *  BLKSPRINFO usBlkSprInfo;
   *
   *  // disable UNC stop
   *  setSelMulFL(1);
   *  rmDisUNCStop;
   *  rmDisOnesCntStop;
   *  setSelMulFL(0);
   *
   *  // debugLoop();
   *
   *  gsRdlinkInfo.u16CacheInfoBlk=0xFFFF;
   *  gsRdlinkInfo.u16OrgCacheInfoBlk=0xFFFF;
   *
   *  for(u16Fblock=g16FirstFBlock; u16Fblock<g16TotalFBlock; u16Fblock++)
   *  {
   *      //if(!mChkMlcMoBit(u16Fblock))
   *      //{
   *          get1stPageInfo(u16Fblock, cReadWithoutRetry, &usBlkSprInfo);
   *
   *          if(!gbEccFail&&!gbOnesCntFail)
   *          {
   *              if(mGetMetaBlockId(usBlkSprInfo)==cCacheInfoTableID)
   *              {
   *                  if((u32TempSerial==c32InitSerialVal)||(judgeSerial(mGetMetaBlkSn(usBlkSprInfo), u32TempSerial)==cSerialLarger))
   *                  {
   *                      gsRdlinkInfo.u16OrgCacheInfoBlk=gsRdlinkInfo.u16CacheInfoBlk;
   *                      gsRdlinkInfo.u16CacheInfoBlk=u16Fblock;
   *                      u32TempSerial=mGetMetaBlkSn(usBlkSprInfo);
   *
   *                      if(u32PowerOnCnt==c32InitSerialVal)
   *                      {
   *                          u32PowerOnCnt=mGetMetaWord4(usBlkSprInfo)|(mGetMetaWord5(usBlkSprInfo)<<16);
   *                      }
   *                      else
   *                      {
   *                          if(u32PowerOnCnt>(mGetMetaWord4(usBlkSprInfo)|(mGetMetaWord5(usBlkSprInfo)<<16)))
   *                          {
   *                              while(1)
   *                                  ;
   *                          }
   *                      }
   *
   *                      setBlkSerial(cCacheInfoTableID, mGetMetaBlkSn(usBlkSprInfo));
   *                      mSetGlobEraseCnt(u16Fblock, mGetMetaEraseCnt(usBlkSprInfo));
   *                  }
   *              }
   *          }
   *      //}
   *  }
   *
   *  if(gsRdlinkInfo.u16CacheInfoBlk!=0xFFFF)
   *  {
   *      gsRdlinkInfo.ubCacheInfoFound=1;
   *  }
   *  else
   *  {
   *      gsRdlinkInfo.ubCacheInfoFound=0;
   *  }
   *
   *  setSelMulFL(1);
   *  rmEnUNCStop;
   *  rmEnOnesCntStop;
   *  resetECC();
   *  setSelMulFL(0);
   * }
   */

void findIndexBlock(BYTE uPS4Resume)
{
    BLKSPRINFO usBlkSprInfo;
    WORD *u16pBlkSprPtr, u16FPage;
    BYTE uLoop;

    if(uPS4Resume)
    {
        // The parameters need backup and restore
        // g16IdxBlkFreePagePtr, g32IndexBlkSerial,
        // gsRdlinkInfo.u16DiffFBlock0, gsRdlinkInfo.u16DiffFBlock1,
        // gsRdlinkInfo.u16DiffFPageNoTran
        // Backup tran2Ps4Mo()
        // Restore initSram()
        if(g16IdxBlkFreePagePtr<g16PagePerBlock1_SLC)
        {
            mClrCacheInfoFlag(cIndexBlockFull);    // gsCacheInfo.ubIndexBlockFull=0;
        }
        else
        {
            mSetCacheInfoFlag(cIndexBlockFull);    // gsCacheInfo.ubIndexBlockFull=1;
        }
    }
    else
    {
        gsRdlinkInfo.ubDoNotScanAllBlk=0;
        gsRdlinkInfo.ubWproBlkFound=0;
        gsRdlinkInfo.ubBadInfoFound=0;
        gsRdlinkInfo.u16DiffFBlock0=c16BitFF;
        gsRdlinkInfo.u16DiffFBlock1=c16BitFF;
        gsRdlinkInfo.u16DiffFPageNoTran=c16BitFF;

        if(mChkIndexbInFL)
        {
            usBlkSprInfo.u16Spr0.u16all=c16BitFF;
            g16IdxBlkFreePagePtr=getRsvLastPageInfo(garSysBlock[cSysBlockIdx], cIndexBlockID, cUseSlcMode, &usBlkSprInfo);

            if(g16IdxBlkFreePagePtr<g16PagePerBlock1_SLC)
            {
                mClrCacheInfoFlag(cIndexBlockFull);
            }
            else
            {
                mSetCacheInfoFlag(cIndexBlockFull);

                if(g16IdxBlkFreePagePtr==c16BitFF)
                {
                    while(1)
                        ;
                }
            }

            if((g16IdxBlkFreePagePtr==1)&&(mGetMetaWord6(usBlkSprInfo)==0xAA5A)&&(mGetMetaWord7(usBlkSprInfo)==0xAA5A))
            {
                // first time power on
                gsRdlinkInfo.ubDoNotScanAllBlk=1;
            }
            // else if(g16IdxBlkFreePagePtr>=2)
            else
            {
                u16pBlkSprPtr=&usBlkSprInfo.u16Spr0.u16all;
                gsRdlinkInfo.uWproActIdx=mGetMetaWord7(usBlkSprInfo);

                for(uLoop=0; uLoop<cMaxWproBlkCnt; uLoop++)
                {
                    gsRdlinkInfo.u16arWproBlk[uLoop]=*(u16pBlkSprPtr+uLoop);

                    if((gsRdlinkInfo.u16arWproBlk[uLoop]<g16TotalFBlock)&&(gsRdlinkInfo.u16arWproBlk[uLoop]>=g16FirstFBlock))
                    {
                        gsRdlinkInfo.ubWproBlkFound=1;
                    }
                }

                if((usBlkSprInfo.u16Spr4.u16all!=0xFFFF)&&(usBlkSprInfo.u16Spr5.u16all!=0xFFFF)&&(usBlkSprInfo.u16Spr6.u16all!=0xFFFF))
                {
                    gsRdlinkInfo.ubBadInfoFound=1;

                    gsRdlinkInfo.u16BadInfoPhyFBlock0=mGetBadInfoFBlk0(usBlkSprInfo);
                    gsRdlinkInfo.u16BadInfoPhyFBlock1=mGetBadInfoFBlk1(usBlkSprInfo);
                    gsRdlinkInfo.u16BadInfoPhyFPage=mGetBadInfoFPage(usBlkSprInfo);
                    gsRdlinkInfo.uBadInfoPhyCh=mGetBadInfoCh(usBlkSprInfo);
                    gsRdlinkInfo.uBadInfoPhyPlane=mGetBadInfoPlane(usBlkSprInfo);
                    gsRdlinkInfo.uBadInfoPhyIntlv=mGetBadInfoIntlv(usBlkSprInfo);
                }

                u16FPage=g16IdxBlkFreePagePtr-1;

                do
                {
                    if(getRsvPageInfo(garSysBlock[cSysBlockIdx], cIndexBlockID, u16FPage, &usBlkSprInfo, 1))
                    {
                        if(g16arTsb0[0][3]==0x55AA)
                        {
                            gsRdlinkInfo.u16DiffFBlock0=g16arTsb0[0][0];
                            gsRdlinkInfo.u16DiffFBlock1=g16arTsb0[0][1];
                            gsRdlinkInfo.u16DiffFPageNoTran=g16arTsb0[0][2];
                            break;
                        }
                    }

                    u16FPage--;
                }
                while(u16FPage!=c16BitFF);
            }

            // else
            // {
            //    while (1);
            // }
        }
        else
        {
            mSetCacheInfoFlag(cIndexBlockFull);
            g32IndexBlkSerial=c32InitSerialVal;
        }
    }
}    /* findIndexBlock */

void findLogBlock(BYTE uPS4Resume)
{
    BLKSPRINFO usBlkSprInfo;

    if(uPS4Resume)
    {
        if(g16LogBlkFreePagePtr<=g16PagePerBlock1_SLC-cTelemetryCtlrDataPageCnt)
        {
            mClrCacheInfoFlag(cLogInfoBlockFull);    // gsCacheInfo.ubLogInfoBlockFull=0;
        }
        else
        {
            mSetCacheInfoFlag(cLogInfoBlockFull);    // gsCacheInfo.ubLogInfoBlockFull=1;
        }
    }
    else
    {
        if(mChkLogInfoInFL)
        {
            usBlkSprInfo.u16Spr0.u16all=c16BitFF;
            g16LogBlkFreePagePtr=getRsvLastPageInfo(garSysBlock[cSysBlockLog], cLogBlockID, cUseSlcMode, &usBlkSprInfo);

            if(g16LogBlkFreePagePtr<=g16PagePerBlock1_SLC-cTelemetryCtlrDataPageCnt)
            {
                mClrCacheInfoFlag(cLogInfoBlockFull);
            }
            else
            {
                mSetCacheInfoFlag(cLogInfoBlockFull);
            }
        }
        else
        {
            g16LogBlkFreePagePtr=0;
        }
    }
}    /* findIndexBlock */

// 20190305_ChrisSu
WORD chkPageInfoInv(WORD u16Fblock,
                    WORD u16Fpage,
                    WORD u16BlkId,
                    BYTE uFindFirstEmpty,
                    WORD *up16FirstEmptyPagePtr,
                    BLKSPRINFO *upBlkSprInfo,
                    BYTE uSkipDum)
{
    BYTE uIntlvAddr, uIntlvAddr2, uPlaneAddr, uPlaneAddr1, uPlaneAddr2, uCh, uCh2;
    WORD u16LastValidPagePtr=c16BitFF;
    ADDRINFO usTmpAddrInfo[cMaxChNum];
    BLKSPRINFO usBlkSprInfo;

    *up16FirstEmptyPagePtr=(u16Fpage+1)*gTotalIntlvChPlaneNum;

    for(uIntlvAddr2=gIntlvWay; uIntlvAddr2>0; uIntlvAddr2--)
    {
        uIntlvAddr=uIntlvAddr2-1;

        for(uCh2=gTotalChNum; uCh2>0; uCh2--)
        {
            uCh=uCh2-1;
            // trigger read flash command
            usTmpAddrInfo[uCh].u16FBlock=u16Fblock;
            usTmpAddrInfo[uCh].u16FPage=u16Fpage;
            usTmpAddrInfo[uCh].uPlaneAddr=0;
            usTmpAddrInfo[uCh].uCh=uCh;
            usTmpAddrInfo[uCh].uIntlvAddr=uIntlvAddr;
            usTmpAddrInfo[uCh].uCe=(BYTE)mGetCEAddr(usTmpAddrInfo[uCh].uIntlvAddr);
            usTmpAddrInfo[uCh].uDieAddr=mGetDieAddr(uIntlvAddr);
            // setFLAddrActCh(uCh, &usTmpAddrInfo[uCh]);
            gpFlashAddrInfo=&usTmpAddrInfo[uCh];
            mSetFRwParam(0, 0, c16Bit0|c16Bit14|c16Bit15, cReadCmdAle);
            assignFreeBtSrcAddrInfo();
        }
    }

    waitCmdAllDone(cWaitTrigRCnt);

    // outStringRsCacheF2h("bL@", u16FpageLow);
    // outStringRsCacheF2h("bM@", u16Fpage);
    // outStringRsCacheF2h("bH@", u16FpageHigh);

    for(uIntlvAddr2=gIntlvWay; uIntlvAddr2>0; uIntlvAddr2--)
    {
        uIntlvAddr=uIntlvAddr2-1;
        rstUNCStsCore0();

        for(uPlaneAddr2=gPlaneNum; uPlaneAddr2>0; uPlaneAddr2-=2)
        {
            for(uCh2=gTotalChNum; uCh2>0; uCh2--)
            {
                uCh=uCh2-1;
                usTmpAddrInfo[uCh].u16FBlock=u16Fblock;
                usTmpAddrInfo[uCh].u16FPage=u16Fpage;
                usTmpAddrInfo[uCh].uIntlvAddr=uIntlvAddr;
                usTmpAddrInfo[uCh].uCe=(BYTE)mGetCEAddr(usTmpAddrInfo[uCh].uIntlvAddr);
                usTmpAddrInfo[uCh].uDieAddr=mGetDieAddr(uIntlvAddr);
                usTmpAddrInfo[uCh].uCh=uCh;

                gpFlashAddrInfo=&usTmpAddrInfo[uCh];
                mSetFRwParam(0, 0, c16Bit0|c16Bit2|c16Bit5|c16Bit10|c16Bit14|c16Bit15, cReadData);
                gSectorH=0;

                for(uPlaneAddr=uPlaneAddr2-2; uPlaneAddr<uPlaneAddr2; uPlaneAddr++)
                {
                    gPlaneAddr=uPlaneAddr;
                    assignFreeBtSrcAddrInfo();
                }
            }

            waitCmdAllDone(cWaitTrigRCnt|cWaitCmdBz);

            for(uCh2=gTotalChNum; uCh2>0; uCh2--)
            {
                WORD u16PagePtr;
                uCh=uCh2-1;
                setFLActCh(uCh);

                for(uPlaneAddr1=uPlaneAddr2; uPlaneAddr1>(uPlaneAddr2-2); uPlaneAddr1--)
                {
                    uPlaneAddr=uPlaneAddr1-1;

                    u16PagePtr=u16Fpage*(gTotalIntlvChPlaneNum)+uIntlvAddr*(gTotalChPlaneNum)+(uCh*gPlaneNum)+uPlaneAddr;

                    if(!mChkBitMask(gPlaneUNCSts[uCh], uPlaneAddr))
                    {
                        getSprByte(&usBlkSprInfo, uPlaneAddr);

                        if((mGetMetaBlockId(usBlkSprInfo)!=0xFF)    /*&&(uPlaneAddr>=2)*/)
                        {
                            if(uSkipDum&&(u16BlkId==cCacheBlockID)&&(mGetMetaOpTyp(usBlkSprInfo)==cPwrOnDummyProg))    // 20190305_ChrisSu
                            {
                                WORD u16CurPagePtr=u16Fpage*(gTotalIntlvChPlaneNum)+uIntlvAddr*(gTotalChPlaneNum)+(uCh*gPlaneNum)+uPlaneAddr;

                                // emtpy page
                                if(u16CurPagePtr<*up16FirstEmptyPagePtr)
                                {
                                    *up16FirstEmptyPagePtr=u16CurPagePtr;
                                }
                            }
                            else if((mGetMetaBlockId(usBlkSprInfo)==u16BlkId)||
                                    ((u16BlkId==cCacheBlockID)&&
                                     ((mGetMetaBlockId(usBlkSprInfo)==cF2hTableID)||(mGetMetaBlockId(usBlkSprInfo)==cRaidParityID))))
                            {
                                copyCcmVal((BYTE *)upBlkSprInfo, (BYTE *)&usBlkSprInfo, sizeof(usBlkSprInfo));

                                // NLOG(cLogPS, RESTOCACHEINFO_C, 6, "1. pgPtr:0x%04X, u16Fpage:0x%04X, uIntlvAddr:0x%04X, uCh0x%04X,
                                // uPlaneAddr:0x%04X, ID:0x%04X  ",
                                //    u16PagePtr, u16Fpage, (WORD)uIntlvAddr, (WORD)uCh, (WORD)uPlaneAddr, (WORD)mGetMetaBlockId(usBlkSprInfo));

                                if(u16LastValidPagePtr==c16BitFF)
                                {
                                    // valid data page
                                    u16LastValidPagePtr=u16PagePtr;
                                }
                            }
                            else
                            {
                                // u16BlkId not the same
                                // NLOG(cLogPS, RESTOCACHEINFO_C, 6, "2. pgPtr:0x%04X, u16Fpage:0x%04X, uIntlvAddr:0x%04X, uCh0x%04X,
                                // uPlaneAddr:0x%04X, ID:0x%04X  ",
                                //    u16PagePtr, u16Fpage, (WORD)uIntlvAddr, (WORD)uCh, (WORD)uPlaneAddr, (WORD)mGetMetaBlockId(usBlkSprInfo));
                                break;
                            }
                        }
                        else
                        {
                            WORD u16CurPagePtr=u16Fpage*(gTotalIntlvChPlaneNum)+uIntlvAddr*(gTotalChPlaneNum)+(uCh*gPlaneNum)+uPlaneAddr;

                            // emtpy page
                            if(u16CurPagePtr<*up16FirstEmptyPagePtr)
                            {
                                *up16FirstEmptyPagePtr=u16CurPagePtr;
                            }

                            // NLOG(cLogPS, RESTOCACHEINFO_C, 6, "3. pgPtr:0x%04X, u16Fpage:0x%04X, uIntlvAddr:0x%04X, uCh0x%04X,
                            // uPlaneAddr:0x%04X, ID:0x%04X  ",
                            //    u16PagePtr, u16Fpage, (WORD)uIntlvAddr, (WORD)uCh, (WORD)uPlaneAddr, (WORD)mGetMetaBlockId(usBlkSprInfo));
                        }
                    }
                    else
                    {
                        if(u16LastValidPagePtr==c16BitFF)
                        {
                            // ECC fail page
                            u16LastValidPagePtr=u16PagePtr;
                        }

                        // NLOG(cLogPS, RESTOCACHEINFO_C, 6, "4. pgPtr:0x%04X, u16Fpage:0x%04X, uIntlvAddr:0x%04X, uCh0x%04X, uPlaneAddr:0x%04X,
                        // ID:0x%04X  ",
                        //    u16PagePtr, u16Fpage, (WORD)uIntlvAddr, (WORD)uCh, (WORD)uPlaneAddr, (WORD)mGetMetaBlockId(usBlkSprInfo));

                        // while((!get1stPageInfo(u16Fblock, cReadOnePage|cReadWithoutRetry|cReadSprData, upBlkSprInfo))||
                        //      (upBlkSprInfo->u16Spr8.us2BYTE.LowByte!=u16BlkId))
                        //    ;
                    }

                    if((u16LastValidPagePtr!=c16BitFF)&&(!uFindFirstEmpty))
                    {
                        while(*up16FirstEmptyPagePtr!=(u16LastValidPagePtr+1))
                            ;

                        return u16LastValidPagePtr;
                    }
                }
            }
        }
    }    // --> End Of for (uIntlvAddr=0; uIntlvAddr<gIntlvWay; uIntlvAddr++)

    return u16LastValidPagePtr;
}    /* chkPageInfoInv */

WORD getFirstFullPage(WORD u16Fblock, WORD u16BlkId, BYTE uMode, BLKSPRINFO *upBlkSprInfo, WORD *up16FirstEmptyPagePtr, BYTE uSkipDum)    // 20190305_ChrisSu
{
    // BYTE uIntlvAddr, uCh;
    WORD u16Fpage=0, u16LastFullPage=0;
    WORD u16LastFreePagePtr=0xFFFF, u16LastValidPagePtr=0    /*, u16Last2ValidPagePtr=0*/, u16FindEmptyPagePtr, u16FullPagePtr;
    WORD u16PagePerBlock1;
    WORD u16FpageLow=0, u16FpageHigh;
    // BYTE uCh2;
    // BYTE uIntlvAddr2;
    ADDRINFO usTmpAddrInfo[cMaxChNum];
    volatile BYTE uStop=1;

    gsRdlinkInfo.u32RdlinkTimeStamp[30]=getRtcCurrent32k();

    ctrlOnesCntStop(0);

    fillCcmVal((BYTE *)&usTmpAddrInfo, sizeof(usTmpAddrInfo), 0x0);

    // while(uStop);

    if(uMode&cUseSlcMode)
    {
        u16PagePerBlock1=g16PagePerBlock1_SLC;
    }
    else
    {
        u16PagePerBlock1=g16PagePerBlock1;
    }

    u16FpageHigh=u16PagePerBlock1-1;

    // NLOG(cLogPS, RESTOCACHEINFO_C, 2, "===getFirstFullPage:Blk=0x%04X,Pg=0x%04X===", u16Fblock, u16PagePerBlock1);

    while(u16FpageLow<=u16FpageHigh)
    {
        u16Fpage=(u16FpageLow+u16FpageHigh)>>1;
        u16FullPagePtr=((u16Fpage+1)*gTotalIntlvChPlaneNum);

        u16LastValidPagePtr=chkPageInfoInv(u16Fblock, u16Fpage, u16BlkId, 0, &u16FindEmptyPagePtr, upBlkSprInfo, uSkipDum);    // 20190305_ChrisSu
        // NLOG(cLogPS, RESTOCACHEINFO_C, 3, " chkPageInfoInv:FindEmptyPtr=0x%04X,ValidPtr=0x%04X,FullPtr=0x%04X ",
        //    u16FindEmptyPagePtr, u16LastValidPagePtr, u16FullPagePtr);

        if(u16FindEmptyPagePtr==u16FullPagePtr)
        {
            // if (u16LastValidPagePtr==(u16FullPagePtr-1))
            {
                // full valid page
                // NLOG(cLogPS, RESTOCACHEINFO_C, 2, "*** LastFullPage:[0x%04X=>0x%04X] ", u16LastFullPage, u16Fpage);
                while(u16LastValidPagePtr!=(u16FullPagePtr-1))
                    ;

                while(u16LastFullPage>u16Fpage)
                    ;// TODO: remove this , if init u16LastFullPage to 0xFFFF

                u16LastFullPage=u16Fpage;
            }
        }
        else
        {
            // NLOG(cLogPS, RESTOCACHEINFO_C, 2, "***firstEmpPtr:[0x%04X=>0x%04X] ", *up16FirstEmptyPagePtr, u16FindEmptyPagePtr);
            // while(u16FindEmptyPagePtr<(*up16FirstEmptyPagePtr));
            *up16FirstEmptyPagePtr=u16FindEmptyPagePtr;
        }

        if(u16LastValidPagePtr!=0xFFFF)
        {
            // full empty page
            u16LastFreePagePtr=u16LastValidPagePtr+1;

            while(u16Fpage>(u16PagePerBlock1-1))
                ;

            u16FpageLow=u16Fpage+1;
        }
        else
        {
            if(u16Fpage==0)
            {
                u16LastValidPagePtr=0;
                break;
            }

            u16FpageHigh=u16Fpage-1;
        }
    }

    while(u16LastFreePagePtr==0xFFFF)
        ;

    // u16LastFullPage=u16Last2ValidPagePtr/gTotalIntlvChPlaneNum;
    // u16FullPagePtr=u16FindEmptyPagePtr=up16FirstEmptyPagePtr;

    // TODO: remove this , if init u16LastFullPage to 0xFFFF
    if(!u16LastFullPage)
    {
        u16LastFullPage=0xFFFF;
    }

    // NLOG(cLogPS, RESTOCACHEINFO_C, 2, "===findPrevFullPg:curPg=0x%04X,lastFullPg=0x%04X===", u16Fpage, u16LastFullPage);

    while(u16LastFullPage!=u16Fpage)
    {
        u16FullPagePtr=((u16Fpage+1)*gTotalIntlvChPlaneNum);
        u16LastValidPagePtr=chkPageInfoInv(u16Fblock, u16Fpage, u16BlkId, 1, &u16FindEmptyPagePtr, upBlkSprInfo, uSkipDum);    // 20190305_ChrisSu
        // NLOG(cLogPS, RESTOCACHEINFO_C, 3, " chkPageInfoInv:FindEmptyPtr=0x%04X,ValidPtr=0x%04X,FullPtr=0x%04X ",
        //    u16FindEmptyPagePtr, u16LastValidPagePtr, u16FullPagePtr);

        if(u16FindEmptyPagePtr==u16FullPagePtr)
        {
            // NLOG(cLogPS, RESTOCACHEINFO_C, 2, " u16LastFullPage:[0x%04X=>0x%04X] ", u16LastFullPage, u16Fpage);
            while(u16LastValidPagePtr!=(u16FullPagePtr-1))
                ;

            u16LastFullPage=u16Fpage;
            break;
        }
        else
        {
            // NLOG(cLogPS, RESTOCACHEINFO_C, 2, "***firstEmpPtr:[0x%04X=>0x%04X] ", *up16FirstEmptyPagePtr, u16FindEmptyPagePtr);
            while(u16FindEmptyPagePtr>u16FullPagePtr)
                ;

            *up16FirstEmptyPagePtr=u16FindEmptyPagePtr;

            if(u16Fpage==0)
            {
                break;
            }
        }

        while(u16Fpage==0)
            ;

        u16Fpage--;
    }

    ctrlOnesCntStop(3);

    if(gsRdlinkInfo.u32RdlinkTimeStamp[32]==c32BitFF)
    {
        gsRdlinkInfo.u32RdlinkTimeStamp[32]=0;
    }
    else
    {
        gsRdlinkInfo.u32RdlinkTimeStamp[32]+=(getRtcCurrent32k()-gsRdlinkInfo.u32RdlinkTimeStamp[30]);
    }

    if(*up16FirstEmptyPagePtr==0xFFFF)
    {
        *up16FirstEmptyPagePtr=u16LastFreePagePtr;
    }

    return u16LastFreePagePtr;
}    /* getFirstFullPage */

#if 1
BYTE getRsvPageInfo(BYTE uRsvFBlockIdx, WORD u16BlkId, WORD u16FPage, BLKSPRINFO *upBlkSprInfo, BYTE uReadData)
{
    BLKSPRINFO usBlkSprInfo;
    ADDRINFO usAddrInfo;
    BYTE uPageStatus=0;

    tranRsvBlkAddr(uRsvFBlockIdx, &usAddrInfo);
    usAddrInfo.u16FPage=u16FPage;
    setFLAddrActCh(usAddrInfo.uCh, &usAddrInfo);

    rstUNCSts1PlaneCore0(gCh, gPlaneAddr);

    mSetFRwParam(c16Tsb0SIdx, gSectorPerPlaneH, c16Bit0|c16Bit5|c16Bit10|c16Bit14|c16Bit15, cReadData);

    if(uReadData)
    {
        g16RwOpt|=c16Bit4;
    }

    gSectorH=0;
    assignFreeBtSrcAddrInfo();
    waitCmdAllDone(cWaitTrigRCnt|cWaitCmdBz);

    if(!mChkBitMask(gPlaneUNCSts[gCh], gPlaneAddr))
    {
        // this plane no UNC
        getSprByte(&usBlkSprInfo, usAddrInfo.uPlaneAddr);
        copyCcmVal((BYTE *)upBlkSprInfo, (BYTE *)&usBlkSprInfo, sizeof(usBlkSprInfo));

        if(mGetMetaBlockId(usBlkSprInfo)==u16BlkId)
        {
            mSetBitMask(uPageStatus, 0);
        }
        else if(mGetMetaBlockId(usBlkSprInfo)==0xFF)
        {
            mSetBitMask(uPageStatus, 1);
        }
        else
        {
            uPageStatus=0xF;
            debugLoop(cGetRsvPageInfo1);
        }
    }

    return uPageStatus;
}    /* getRsvPageInfo */

WORD getRsvLastPageInfo(BYTE uRsvFBlockIdx, WORD u16BlkId, BYTE uMode, BLKSPRINFO *upBlkSprInfo)
{
    BLKSPRINFO usBlkSprInfo;
    WORD u16FPage=0;
    WORD u16FreePagePtr=0;
    WORD u16Left=0;
    WORD u16Right=g16PagePerBlock1_SLC-1;
    BYTE uPageStatus, uDone=0;

    ctrlOnesCntStop(0);

    uPageStatus=getRsvPageInfo(uRsvFBlockIdx, u16BlkId, 0, &usBlkSprInfo, 0);

    if(uPageStatus==0xF)    // not Rsv block case
    {
        uDone=1;
        u16FreePagePtr=c16BitFF;
    }

    // empty block
    if(mChkBitMask(uPageStatus, 1))
    {
        uDone=1;
        u16FreePagePtr=0;
        copyCcmVal((BYTE *)upBlkSprInfo, (BYTE *)&usBlkSprInfo, sizeof(usBlkSprInfo));
    }
    else if(!uPageStatus)
    {
        uDone=1;
        u16FreePagePtr=c16BitFF;
    }

    if(!uDone)
    {
        uPageStatus=getRsvPageInfo(uRsvFBlockIdx, u16BlkId, u16Right, &usBlkSprInfo, 0);

        // full block
        if(!mChkBitMask(uPageStatus, 1))
        {
            uDone=1;
            u16FreePagePtr=g16PagePerBlock1_SLC;
            copyCcmVal((BYTE *)upBlkSprInfo, (BYTE *)&usBlkSprInfo, sizeof(usBlkSprInfo));

            if(!uPageStatus)
            {
                uPageStatus=getRsvPageInfo(uRsvFBlockIdx, u16BlkId, 0, &usBlkSprInfo, 0);
                copyCcmVal((BYTE *)upBlkSprInfo, (BYTE *)&usBlkSprInfo, sizeof(usBlkSprInfo));

                if(!uPageStatus)
                {
                    debugLoop(cGetRsvLastPageInfo1);
                }
            }
        }
    }

    if(!uDone)
    {
        while(u16Left<=u16Right)
        {
            u16FPage=(u16Left+u16Right)>>1;
            uPageStatus=getRsvPageInfo(uRsvFBlockIdx, u16BlkId, u16FPage, &usBlkSprInfo, 0);

            if(uPageStatus)
            {
                if(mChkBitMask(uPageStatus, 1))
                {
                    u16FreePagePtr=u16FPage;
                    u16Right=u16FPage-1;
                }
                else
                {
                    u16Left=u16FPage+1;
                    // copyCcmVal((BYTE *)upBlkSprInfo, (BYTE *)&usBlkSprInfo, sizeof(usBlkSprInfo));
                }
            }
            else
            {
                u16Left=u16FPage+1;
            }
        }

        u16FPage=u16FreePagePtr;

        while(u16FPage>0)
        {
            u16FPage--;
            uPageStatus=getRsvPageInfo(uRsvFBlockIdx, u16BlkId, u16FPage, &usBlkSprInfo, 0);

            if(mChkBitMask(uPageStatus, 0))
            {
                uDone=1;
                copyCcmVal((BYTE *)upBlkSprInfo, (BYTE *)&usBlkSprInfo, sizeof(usBlkSprInfo));
                break;
            }
        }
    }

    while(!uDone)
        ;

    ctrlOnesCntStop(cBit0|cBit1);

    return u16FreePagePtr;
}    /* getRsvLastPageInfo */

#else/* if 1 */

WORD getRsvLastPageInfo(BYTE uRsvFblockIdx, WORD u16BlkId, BYTE uMode, BLKSPRINFO *upBlkSprInfo)
{
    BLKSPRINFO usBlkSprInfo;
    BYTE uBkupPlaneAddr, uFlag;
    WORD u16Fpage=0;
    WORD u16LastFreePagePtr=0;

    ADDRINFO usTmpAddrInfo;

    ctrlOnesCntStop(0);

    tranRsvBlkAddr(uRsvFblockIdx, &usTmpAddrInfo);
    uBkupPlaneAddr=usTmpAddrInfo.uPlaneAddr;
    // tranCeNum(&usTmpAddrInfo);
    setFLAddrActCh(usTmpAddrInfo.uCh, &usTmpAddrInfo);
    gsRdlinkInfo.ubPageWithErr=gsRdlinkInfo.ubMultiCopiesErr=0;
    uFlag=0;

    while((u16Fpage<g16PagePerBlock1_SLC)&&!uFlag)
    {
        usTmpAddrInfo.u16FPage=u16Fpage;
        usTmpAddrInfo.uPlaneAddr=uBkupPlaneAddr;

        mSetFRwParam(c16Tsb0SIdx, gSectorPerPlaneH, c16Bit0|c16Bit5|c16Bit10|c16Bit14|c16Bit15, cReadData);
        gSectorH=0;
        // waitChCeBz(usTmpAddrInfo.uCh, usTmpAddrInfo.uIntlvAddr, cNoOp);
        // flashReadPage();
        // setBzInfo(cReadData, usTmpAddrInfo.uCh, usTmpAddrInfo.uIntlvAddr);
        assignFreeBtSrcAddrInfo();

        waitCmdAllDone(cWaitTrigRCnt|cWaitCmdBz);
        // releaseBtSrcAddrInfo();

        if(!uFlag)
        {
            // usTmpAddrInfo.uPlaneAddr=uBkupPlaneAddr;

            if(!mChkBitMask(gPlaneUNCSts[usTmpAddrInfo.uCh], usTmpAddrInfo.uPlaneAddr))
            {
                // this plane no UNC
                getSprByte(&usBlkSprInfo, usTmpAddrInfo.uPlaneAddr);

                if(mGetMetaBlockId(usBlkSprInfo)==0xFF)
                {
                    uFlag=1;
                }
                else if(!uFlag)
                {
                    u16LastFreePagePtr++;

                    if(mGetMetaBlockId(usBlkSprInfo)==u16BlkId)
                    {
                        copyCcmVal((BYTE *)upBlkSprInfo, (BYTE *)&usBlkSprInfo, sizeof(usBlkSprInfo));
                    }
                    else
                    {
                        u16LastFreePagePtr=0xFFFF;
                        debugLoop();
                        // break;
                    }
                }
                else
                {
                    // uarCopyNum[uPlaneAddr]--;
                }
            }
            else if(!uFlag)
            {
                // this plane UNC
                u16LastFreePagePtr++;
                gsRdlinkInfo.ubPageWithErr=1;
            }
        }

        u16Fpage++;
    }

    if(gsRdlinkInfo.ubPageWithErr)
    {
        gsRdlinkInfo.ubSporF=1;
    }

    ctrlOnesCntStop(cBit0|cBit1);

    return u16LastFreePagePtr;
}    /* getRsvLastPageInfo */

#endif/* if 1 */







