







#include "inc/Reg.h"
#include "inc/TypeDef.h"
#include "inc/ProType.h"

#if _PRJ_BOOT1

void initVic0(LWORD u32IntsEnable)
{
    rmVic0VectAddr00=0x00000020;    // isrClkReqLatQ
    rmVic0VectAddr01=0x00000024;    // isrPwFail18
    rmVic0VectAddr02=0x00000028;    // isrPwFail23
    rmVic0VectAddr03=0x0000002C;    // isrWdtIntPwFail27
    rmVic0VectAddr04=0x00000030;    // isrPwFail40IntPwFail10
    rmVic0VectAddr05=0x00000034;    // isrPwFailEx
    rmVic0VectAddr06=0x00000038;    // isrPwFailPor1
    rmVic0VectAddr07=0x0000003C;    // isrThsorValue
    rmVic0VectAddr08=0x00000040;    // isrJtag
    rmVic0VectAddr09=0x00000044;    // isrGpioAll
    rmVic0VectAddr10=0x00000048;    // isrP11
    rmVic0VectAddr11=0x0000004C;    // isrAllTimer
    rmVic0VectAddr12=0x00000050;    // isrI2cSlave
    rmVic0VectAddr13=0x00000054;    // isrI2cMaster
    rmVic0VectAddr14=0x00000058;    // isrUart
    rmVic0VectAddr15=0x0000005C;    // isrRng
    rmVic0VectAddr16=0x00000060;    // isrPcieAppIrq0
    rmVic0VectAddr17=0x00000064;    // isrPcieAppIrq1
    rmVic0VectAddr18=0x00000068;    // isrPcieAppIrq2
    rmVic0VectAddr19=0x0000006C;    // isrPcieAppIrq3
    rmVic0VectAddr20=0x00000070;    // isrPcieIrq0
    rmVic0VectAddr21=0x00000074;    // isrPcieIrq1
    rmVic0VectAddr22=0x00000078;    // isrPcieIrq2
    rmVic0VectAddr23=0x0000007C;    // isrPcieIrq3
    rmVic0VectAddr24=0x00000080;    // isrSetBvb2CfgTmoFlag
    rmVic0VectAddr25=0x00000084;    // isrRsa
    rmVic0VectAddr26=0x00000088;    // isrFakeFailStop
    rmVic0VectAddr27=0x0000008C;    // isrCmdFifoFull
    rmVic0VectAddr28=0x00000090;    // isrFlash
    rmVic0VectAddr29=0x00000094;    // isrHdaDone
    rmVic0VectAddr30=0x00000098;    // isrBopDone
    rmVic0VectAddr31=0x0000009C;    // isrVIC31

    // Clear event select register
    rmVic0DisEvent(0xFFFFFFFF);
    rmVic0EnEvent((LWORD)(1<<31));

    // rmVicInt03Pri0;                    // Set UART INT highest priority
    // rmVicInt02Pri2;                    // Set TRNG INT 3rd priority
    rmVic0IntSel=0x00000000;    // 1 = FIQ, 0 = IRQ
    // for ClkReq# wake up, Clk_reg (bit0) must set Pulse mode
    rmVic0IntMode=0xE100B57E;    // 1 = Pulse Mode, 0 = Level Mode  //skyhsu FFFFFFFF-->E100B77E
    // for ClkReq# wake up, Clk_reg (bit0) must set Low Active
    rmVic0IntPolarity=0xFFFFFFFF;    // 1 = High Active, 0 = Low Active
    rmVic0SoftMaskN=0xFFFFFFFF;    // 1 = Non Masked, 0 = Marsked
    rmVic0IntEnable=u32IntsEnable;    // 1 = interrupt enable, 0= interrupt disable(reset)
    // rmClrFakeInt = 0xFFFFFFFF;         // Clear All Fake Interrupt
    rmVic0IrqClr;
    rmVic0Enable;    // Enable VIC CTL, HW switch

    __enable_ve();
    __enable_irq();
    __enable_fiq();
}    /* initVic */

#endif/* if _PRJ_BOOT */

#if _PRJ_BOOT2

void initInt(BYTE uFromResume, BYTE uKeepSts)
{
#if 1    // Enable IrqPCIe1 for the host compatibility.
    // g32IntSrc=(cIrqNvmeRst|cIrqPcie0|cIrqPcie1|cIrqTimerAll|cIrqEnUart|cIrqNvmeErr);    // CSSD-1740
    g32IntSrc=(cIrqNvmeRst|cIrqPcie0|cIrqPcie1|cIrqTimerAll|cIrqNvmeErr);    // Disable UART_RX_ISR
#else
    // g32IntSrc=(cIrqNvmeRst|cIrqPcie0|cIrqTimerAll|cIrqEnUart|cIrqNvmeErr);
    g32IntSrc=(cIrqNvmeRst|cIrqPcie0|cIrqTimerAll|cIrqNvmeErr);    // Disable UART_RX_ISR
#endif
    g32IntSrc|=cIrqGpioAll;    // for p11
#if _LOAD_OPROM
    g32IntSrc|=cIrqPcie2;    // IRQ for Op Rom
#endif
    g32IntSrc|=cIrqPcie3;    // IRQ for AXI error

#if (_ENABLE_BUS_ERR_HANDLE)
    g32IntSrc|=cIrqBusErr;    // IRQ for TSB Like, AHB error
#endif

    // VDT interrupts
#if (!(_INITDRAM||_GREYBOX))
    if(gsLightSwitch.usVdtLs.VdtEnableBit&cEnVdtFshVcc)
    {
        g32IntSrc|=cIrqVdt27Wdt|cIrqVdt23;
    }
#endif

    if(gsLightSwitch.usVdtLs.VdtEnableBit&cEnVdtFshFio)
    {
        g32IntSrc|=cIrqVdtFio;
    }

    g32IntSrc|=cEnPcieClkReqIrq;

    rmVic0EnInt(g32IntSrc);

    // Resume from PS3, don't clr any interrupt source
    if(!uFromResume)    // furturn implement
    {
        if(!uKeepSts)
        {
            rmClrCdiInt;

            // Set NVMe interrupt
            rmNvmeIntLowDisAll;    // disable all interrupts for now
            rmNvmeIntHighDisAll;    // disable all interrupts for now

            // clear all interrupt source before enabling
            clrNvmeIntStatus();

            g32LtrValue0=0;
            g32LtrValue2=0;
            gLtrEnabled=0;
            gChgtoD0=0;
        }

        rmNvmeResetIntEn;
        rmNvmeCcEnOnEn;
        rmNvmeShnChangeEn;    // Enable NVMe shutdown notice interrupt
        rmNvmeInvDbWriteEn;    // CSSD-1740
        rmNvmeDmaEngineIntEn;    // CSSD-1871
#if _PCIE_FUN_LVL_RST
        rmNvmeEnFlrInt;
#endif

#if 0    // _ENABLE_E2E_PROTECTION
        rmNvmeCrcIntEn;
#endif

        if(!rmChkInDevSlp)
        {
            // Setup PERST GPIO11 Interrupt
            gpioClrIsr(rcGpioIntSetP1, cGpioB1);    // Clear Int status
            gpioIsrDisable(rcGpioIntSetP1, cGpioB1);    // Disable Int
            gpioSetEdgeMode(rcGpioIntSetP1, cGpioB1);    // Set Edge Mode
            gpioLoActiveEnable(rcGpioIntSetP1, cGpioB1);    // Enable Low Active
            gpioHiActiveDisable(rcGpioIntSetP1, cGpioB1);    // Disable High Active
            gpioIsrEnable(rcGpioIntSetP1, cGpioB1);    // Enable Int
#if _ENABLE_SCP_PLP
            // Setup  GPIO25 Interrupt
            gpioClrIsr(rcGpioIntSetP2, cGpioB5);    // Clear Int status
            gpioIsrDisable(rcGpioIntSetP2, cGpioB5);    // Disable Int
            gpioSetEdgeMode(rcGpioIntSetP2, cGpioB5);    // Set Edge Mode
            gpioLoActiveEnable(rcGpioIntSetP2, cGpioB5);    // Enable Low Active
            gpioHiActiveEnable(rcGpioIntSetP2, cGpioB5);    // Enable High Active
            gpioIsrEnable(rcGpioIntSetP2, cGpioB5);    // Enable Int
#endif
        }

#if (_EN_CHRONUS_UART_DEBUG)
        // GPIO13 to wake up device from PS3/4
        gpioClrIsr(rcGpioIntSetP1, cGpioB3);    // Clear Int status
        gpioIsrDisable(rcGpioIntSetP1, cGpioB3);    // Disable Int
        gpioSetLevelMode(rcGpioIntSetP1, cGpioB3);    // Set Level Mode
        gpioLoActiveEnable(rcGpioIntSetP1, cGpioB3);    // Enable Low Active
        gpioHiActiveDisable(rcGpioIntSetP1, cGpioB3);    // Disable High Active
        gpioIsrEnable(rcGpioIntSetP1, cGpioB3);    // Enable Int
#endif

        // Set PCIe interrupt
        rmSetLinkRstDetectEn;    // Enable PCIe Link Down interrupt
        rmSetLtrEnChangeEn;    // Enable LTR enable interrupt

        if(gsLightSwitch.usPhyLs.u16CustomizeF&cEarlyPCIeResetEn)    // remove for 2263, EarlyPCIeResetEn
        {
            rmSetLtssmIntr2En;
        }

        rmSetBusMaterChangeEn;    // remove for 2263
        rmSetPcieDstateChangeIntrEn;    // (Sam)Enable D state change interrupt. It is for LTR PCIe compliance Test.

#if (_ENABLE_BUS_ERR_HANDLE)
        initBusErrHandler();    // PW1, PW2 register setting, use to call when power state resume

        // set AXI bus timeout value and enable error condition
        rmSetAxiRdWaitCnt(0xFF);
        rmSetAxiWrWaitCnt(0xFF);
        rmSetAes2TsbRdWaitCnt(0xFF);
        rmSetAes2TsbWrWaitCnt(0xFF);
        rmSetAxiWrTimeoutErrEn;
        rmSetAxiRdTimeoutErrEn;
        rmSetAes2TsbWrTimeoutErrEn;
        // rmSetAes2TsbRdDramTimeoutErrEn;
        rmSetAes2TsbRdSramTimeoutErrEn;
#endif/* if (_ENABLE_BUS_ERR_HANDLE) */

        rmClrL1TimeoutEn;    // will enable by check flow
#if _2260PCIE_WORKAROUND
        rmSetLtssmTraceIntr0En;    //
#endif

#if _ACER_ESD_ONELANE    // Sam Test Code for Acer platform
        rmClrLtssmTraceIntr0;
        rmSetLtssmTraceIntr0En;
#endif
        // CSSD-2883, malform TLP and CLP timeout
        rmClrFormDebugInt;
        // rmClrRadmCplTimeoutInt;
        rmClrRadmDebugIntrEn;

        rmFormFiltMalformTlpErrEnable;
        rmRadmCplTimeoutDiagrEnable;
        // rmRadmCplTimeoutIntEn;
        rmSetRadmDebugIntrEn;

        rmFormDebugIntEn;    // CSSD-2883, detect malformed TLP
        rmSetPcieVpdIntrEn;
    }
}    /* initInt */

#endif/* if _PRJ_BOOT2 */







