







#include "inc/Option.h"
#include "inc/TypeDef.h"
#include "inc/ProType.h"
#include "inc/Security.h"
#include "inc/FlashCtrl.h"
#include "inc/CryptoLibExtern.h"

#pragma default_function_attributes = @ ".SecurityAPI_Code_CryptoLibExtern"

void DMA_MOVE_Lib(LWORD Src_Addr, LWORD Des_Addr, LWORD len, BYTE u8EnSrcAutoFlg, BYTE u8EnDesAutoFlg, BYTE wait)
{
    WORD u16Opt=cDmaTsb2Tsb;

    /* TSB */
    if((Src_Addr>>24)==0x40)
    {
        if((Des_Addr>>24)==0x40)
        {
            u16Opt=cDmaTsb2Tsb;
        }
        else if((Des_Addr>>16)==0x02)
        {
            u16Opt=cDmaTsb2Dccm;
        }
        // #if S_SecAPI_NVMe
        else if((Des_Addr>>16)==0x03)
        {
            u16Opt=cDmaTsb2Stcm;
        }
        // #endif
        else if((Des_Addr>>17)==0x00)
        {
            u16Opt=cDmaTsb2Iccm;
        }
    }
    /* DCCM */
    else if((Src_Addr>>16)==0x02)
    {
        if((Des_Addr>>24)==0x40)
        {
            u16Opt=cDmaDccm2Tsb;
        }
    }
    /* STCM */
    else if(((Src_Addr>>16)==0x03)&&((Des_Addr>>24)==0x40))
    {
        u16Opt=cDmaStcm2Tsb;
    }
    /* ICCM */
    else if(((Src_Addr>>17)==0x00)&&((Des_Addr>>24)==0x40))
    {
        u16Opt=cCopyIccm2Tsb;
    }

    if((u16Opt<cCopyTsb2Cpu1Dccm))
    {
        u16Opt=(u8EnSrcAutoFlg)?(u16Opt|cBopSrcAutoBuf):u16Opt;
        u16Opt=(u8EnDesAutoFlg)?(u16Opt|cBopDesAutoBuf):u16Opt;
        u16Opt=(wait)?(u16Opt|cBopWait):u16Opt;

        bopCopyRam(Des_Addr, Src_Addr, len, u16Opt);
    }
    else
    {
        moveMem2Mem(Src_Addr, Des_Addr, len);
    }
}    /* DMA_MOVE_Lib */

void DebugLog_Lib(BYTE u8Priority, BYTE u8Idx, BYTE u8ParaCnt, WORD u16para0, WORD u16para1, WORD u16para2, WORD u16para3, WORD u16SaveLogID)
{
    debugLog(u8Priority, u8Idx, u8ParaCnt, u16para0, u16para1, u16para2, u16para3);
}

void ResetRam_Lib(BYTE *ptr, LWORD size, BYTE u8Val)
{
    resetRam(ptr, size, u8Val);
}

void ReverseArray_Lib(BYTE *u8Datain, LWORD u32length)
{
    reverseArray(u8Datain, u32length);
}

LWORD MemoryAllocate_Lib(BYTE u8Mode, WORD u16Length, LWORD u32BaseAddr)
{
    LWORD u32Addr;

    u32Addr=memoryAllocate(u8Mode, u16Length, u32BaseAddr);
    return u32Addr;
}

void MemoryRelease_Lib(LWORD u32BaseAddr)
{
    memoryRelease(u32BaseAddr);
}

LWORD Tran2DecClock_Lib(WORD u16Clk)
{
    LWORD u32Clk;

    u32Clk=tran2DecClk();
    return u32Clk;
}

void MOVE_SDRAM2SDRAM_Lib(BYTE *Des_Addr, BYTE *Src_Addr, LWORD len)
{
    LWORD i;

    for(i=0; i<len; i++)
    {
        Des_Addr[i]=Src_Addr[i];
    }
}

#pragma default_function_attributes =







