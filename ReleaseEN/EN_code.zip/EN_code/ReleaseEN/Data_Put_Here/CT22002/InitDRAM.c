







#if _INITDRAM
#include "inc/Const.h"
#include "inc/GlobVar0.h"
#include "inc/Reg.h"
#include "inc/ProType.h"

#if (!_ICE_LOAD_ALL)
#pragma default_function_attributes = @ ".CORE0_BOOT"
#endif
#if (!_CPUID)
// ==================================================================================================INIT DRAM
void setDramCtl(BYTE uDdrType, BYTE uDramVendor, BYTE uDramSize, BYTE uBiDram)
{
    volatile BYTE uLoop;
    volatile LWORD u32ClkSysPeriod, u32PtPhyLock, u32PtPllPd, u32PtPllGs, u32PtPllRst, u32PtCkeLow, u32PtFirstCmd, u32PtRstLow, u32PtZqInit,
                   u32PtPhyReLock;

    rmSetDramPhySrst;
    rmSetDramMacSrst;
    rmClrDramPhySrst;
    rmClrDramMacSrst;

    u32ClkSysPeriod=1000/400;    // 400M
    u32PtPhyLock=(25000/u32ClkSysPeriod)+1;    // 25us
    u32PtPllPd=(1000/u32ClkSysPeriod)+1;    // 1us
    u32PtPllGs=(4000/u32ClkSysPeriod)+1;    // 4us
    u32PtPllRst=(9000/u32ClkSysPeriod)+1;    // 9us
    u32PtCkeLow=(600000/u32ClkSysPeriod)+1;    // 600us
    u32PtFirstCmd=(360/u32ClkSysPeriod)+1;    // 360ns
    u32PtRstLow=(200000/u32ClkSysPeriod)+1;    // 200us
    u32PtZqInit=(1000/u32ClkSysPeriod)+1;    // 1us
    u32PtPhyReLock=(5000/u32ClkSysPeriod)+1;    // 5us

    rmSetPtr0(0x10|(u32PtPllGs<<6)|(u32PtPllPd<<21));
    rmSetPtr1(u32PtPllRst|(u32PtPhyLock<<16));
    rmSetPtr3(u32PtCkeLow|(u32PtFirstCmd<<20));
    rmSetPtr4(u32PtRstLow|(u32PtZqInit<<18));
    rmSetPtr5(u32PtPhyReLock);

    // |-------|--------|
    // |   0   |   1    |
    // |-------|--------|
    // |   2   |   3    |
    // |-------|--------|
    // uBiDram =0x00, die0 exist
    // uBiDram =0x01, die1 exist
    // uBiDram =0x02, (die0+die1) exist
    // uBiDram =0x03, (die0+die2) exist
    // uBiDram =0x04, (die1+die3) exist
    // uBiDram =0x05, (die0+die1+die2+die3) exist
    if((uBiDram==cDram0)||(uBiDram==cDram02))
    {
        rmEnx16DQBus;    // brett add
        rmSetLowDQBus;    // brett add
        rmDisDx2;    // disable Byte2
        rmDisDx3;    // disable Byte3
        rmSetDramMacSrst;    // workaround read fifo not empty bug
        rmClrDramMacSrst;    // workaround read fifo not empty bug
    }
    else if((uBiDram==cDram1)||(uBiDram==cDram13))
    {
        rmEnx16DQBus;    // brett add
        rmSetHighDQBus;    // brett add
        rmDisDx0;    // disable Byte0
        rmDisDx1;    // disable Byte1
        rmSetDramMacSrst;    // workaround read fifo not empty bug
        rmClrDramMacSrst;    // workaround read fifo not empty bug
    }
    else if((uBiDram==cDram01)||(uBiDram==cDram0123))
    {
        rmDisx16DQBus;
    }

    // DDR3
    rmEnDxOdt;

    if(uDdrType==cDramSettingDdr3)
    {
        rmSetDdrMd3;
        rmSetPgcr1(c32RegDramPgcr1);
        rmSetPir(0x00000073);
        sysDelay(20);

        while(!(rmGetPgSr==0x8000000F))
            ;

        rmSetMr0(c32RegDramMR0);
        rmSetMr1(c32RegDramMR1);
        rmSetMr2(c32RegDramMR2);

        rmSetPgcr2(c32RegDramPgcr2);

        rmSetDtpr0(c32RegDramDptr0);
        rmSetDtpr1(c32RegDramDptr1);
        rmSetDtpr2(c32RegDramDptr2);
        rmSetDtpr3(c32RegDramDptr3);
        rmSetDtpr4(c32RegDramDptr4);
        rmSetDtpr5(c32RegDramDptr5);

        // rmSetZq0Pr(0x5B);    // HW Golbo request

        rmSetDsgcr(c32RegDramDsgcr);

        rmSetRankWid(0);
        sysDelay(20);
        rmSetOdtCr(c32Bit16);
        rmSetRankWid(1);
        sysDelay(20);
        rmSetOdtCr(c32Bit17);
        rmSetDtcr0(c32RegDramDtcr0);
        rmSetDtcr1(c32RegDramDtcr1);

        rmSetPir(c32RegDramPir);
        sysDelay(20);

        while(!rmChkDramaReady)
            ;
    }
    else
    {
        gsFtlDbg.u16DummyFailType=cSetDramCtl;
        debugWhile();
    }
}    /* setDramCtl */

void setDramSize(BYTE uDramSize)
{
    if(uDramSize==cDramSetting1Gb)
    {
        rmSetDramSize(0x0A0);
    }
    else if(uDramSize==cDramSetting2Gb)
    {
        rmSetDramSize(0x5A0);
    }
    else if(uDramSize==cDramSetting4Gb)
    {
        rmSetDramSize(0xAA0);
    }
    else if(uDramSize==cDramSetting8Gb)
    {
        rmSetDramSize(0xFA0);
    }
    else
    {
        gsFtlDbg.u16DummyFailType=cSetDramSize;
        debugWhile();
    }
}    /* setDramSize */

void initDramSetting(void)
{
    volatile LWORD *up32DramPtr=(LWORD *)c32DramAddr;
    volatile LWORD *up32CodeCoverDramPtr=(LWORD *)(c32GreyBoxCore0CodeAddr+0x1000000);
    volatile LWORD u32Loop;
    volatile LWORD u32CheckSize=(LWORD)0x100;    // c512KBytes>>2;
    volatile LWORD u32CodeCoverCheckSize=(LWORD)0x4000000;    // c512KBytes>>2;
    volatile BYTE uDdrMode;
    volatile BYTE uDramVendor;
    volatile BYTE uDramSize;
    volatile BYTE uBiDram;

    // ================================================================================================
    // Dram paramter for SM2263 EVB: Nanya SDRAM NT5CC256M16DP-DI
    // Type :DDR3
    // Size : 512M
    // Max Clock : 800M Hz
    uDdrMode=cDramSettingDdr3;
    uDramVendor=cSM2260EvbDramVndr;    // 0x03;
    uDramSize=cDramSetting4Gb;    // 512~4G
    uBiDram=cDram0;    // cSM2260EvbDramMap;    // cSM2263EvbDramMap;
    // ================================================================================================
    // GPIO P2.x
    rSysCtrl0[rcGpioP2Oe]|=0x40;
    rSysCtrl0[rcGpioP2Io]|=0x40;
    // ================================================================================================

    if(!rmChkDramSetReady)
    {
        rmSetCk3SourceXtal;
        rmSetPllTopSourceXtal;
        sysDelay(0x200);
        rmSetDramClkPll(cDramFreq400Mhz);

        while(!rmChkSysChkDrmPllLock)
            ;

        // rmSetDramClkPll(0X220);    // Freq100Mhz

        do
        {
            setDramCtl(uDdrMode, uDramVendor, uDramSize, uBiDram);
        }
        while(!rmChkDramaReady);

        rmEnDramCke;

        rmClrDramBankIntleav;

        setDramSize(uDramSize);
        // DDR3
        rmDramSetRfc(0x50);

        // set multi-CS and bus
        if((uBiDram==cDram0)||(uBiDram==cDram02))
        {
            if(uBiDram==cDram0)
            {
                rmDisMultiCS;
            }
            else
            {
                rmEnMultiCS;
            }
        }
        else if((uBiDram==cDram1)||(uBiDram==cDram13))
        {
            if(uBiDram==cDram1)
            {
                rmDisMultiCS;
            }
            else
            {
                rmEnMultiCS;
            }
        }
        else if((uBiDram==cDram01)||(uBiDram==cDram0123))
        {
            if(uBiDram==cDram01)
            {
                rmDisMultiCS;
            }
            else
            {
                rmEnMultiCS;
            }
        }

        // Enable DRAM MAC, must enable at last step
        rmEnMctl;

        for(u32Loop=0; u32Loop<u32CheckSize; u32Loop++)
        {
            // Double-check
            up32DramPtr[u32Loop]=c32DramPattern;

            if(up32DramPtr[u32Loop]!=c32DramPattern)
            {
                // keep whil loop if fail in init-SDRAM.
                gsFtlDbg.u16DummyFailType=cInitDramSetting1;
                debugWhile();
            }
        }

        for(u32Loop=0; u32Loop<u32CodeCoverCheckSize; u32Loop++)
        {
            // Double-check
            up32CodeCoverDramPtr[u32Loop]=0x00;

            if(up32CodeCoverDramPtr[u32Loop]!=0x00)
            {
                // keep whil loop if fail in init-SDRAM.
                gsFtlDbg.u16DummyFailType=cInitDramSetting2;
                debugWhile();
            }
        }

        rmSetDramSetReady;
    }
}    /* initDramSetting */

void goCore0DramCode(void)
{
    void (*ISPPretestFunPtr)(BYTE)=0;
    LWORD u32JumpAddr=c32MainCodeDramAddr;
    BYTE uChkLoop;

    /* Check DRAM cdoe is ready */
    copySdram2Tsb(&garTsb0[0][0], (BYTE *)c32Core0MainTagDramAddr, cMainTagSize);

    for(uChkLoop=0; uChkLoop<cMainTagSize; uChkLoop++)
    {
        if(cbMainTag[uChkLoop]!=garTsb0[0][uChkLoop])
        {
            return;
        }
    }

    /* Finish the read and write operations */
    // termFlashOperRw(1);
    // codeFuncPtr2[cfuncTermFlashOperRw](1);    // termFlashOperRw(1);
    mCallFuncPtr2(cfuncTermFlashOperRw, 1);

    while(g32NvmeCondition||gsPowerState.uPsChg)
    {
        handleNvmeCondition();
    }

    /* Check FW and HW prd is idle before jume code */
    if(!((rmChkCmdRdy)&&(rmChkCcRdy)))
    {
        gGreyBoxBootSta=cGreyBoxBootCore0Ready;
        ISPPretestFunPtr=(void (*)(BYTE))(u32JumpAddr);
        disableCache();
        g32CodeCoverMapOffset=c32GreyBoxCore0CodeAddr+0x2000000;
        ISPPretestFunPtr(0);
    }

    gsFtlDbg.u16DummyFailType=cGoCore0DramCode;
    debugWhile();
}    /* goCore0DramCode */

#endif/* if (!_CPUID) */
void goCore1DramCode(void)
{
#if 0
    void (*ISPPretestFunPtr)(BYTE)=0;
    LWORD u32JumpAddr=c32GreyBoxCode1CodeAddr;
    BYTE uChkLoop;

    /* Check DRAM cdoe is ready */
    copySdram2Tsb(&garTsb0[0][0], (BYTE *)c32Core1MainTagDramAddr, cMainTagSize);

    for(uChkLoop=0; uChkLoop<cMainTagSize; uChkLoop++)
    {
        if(cbMainTag[uChkLoop]!=garTsb0[0][uChkLoop])
        {
            while(1)
                ;
        }
        else if(uChkLoop==(cMainTagSize-1))
        {
            ISPPretestFunPtr=(void (*)(BYTE))(u32JumpAddr);
            gGreyBoxBootSta=cGreyBoxBootCore1Ready;
            __flushCache();
            __enableInstCache();
            ISPPretestFunPtr(0);
        }
    }
#endif/* if 0 */
    void (*ISPPretestFunPtr)(BYTE)=0;
    LWORD u32JumpAddr=c32GreyBoxCode1CodeAddr;

    /* Check DRAM cdoe is ready */
    copySdram2Tsb(&garTsb0[0][0], (BYTE *)c32Core1ErrHdlTagDramAddr, cMainTagSize);

    if(('E'!=garTsb0[0][7])||('R'!=garTsb0[0][8])||('R'!=garTsb0[0][9]))
    {
        gsFtlDbg.u16DummyFailType=cGoCore1DramCode;
        debugWhile();
    }

    ISPPretestFunPtr=(void (*)(BYTE))(u32JumpAddr);
    gGreyBoxBootSta=cGreyBoxBootCore1Ready;
    ISPPretestFunPtr(0);
}    /* goCore1DramCode */

#if (!_ICE_LOAD_ALL)
#pragma default_function_attributes =
#endif
#endif/* if (_INITDRAM) */







