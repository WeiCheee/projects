







#include "inc/ProType.h"
#include "inc/Reg.h"

#if (_PRJ_SMIVU||_ICE_LOAD_ALL)
void dataOutVendorCmdWriteRam()
{
    BYTE *upMem;
    BYTE *upPtr;
    LWORD u32TotalBytes;

    upMem=(BYTE *)(rmNvmeSubCmdParam1);
    u32TotalBytes=g32HostXfrCnt*512;
    upPtr=(BYTE *)(garTsb0[0]);

    while(u32TotalBytes)
    {
        *upMem++=*upPtr++;
        u32TotalBytes--;
    }
}    /* dataOutVendorCmdWriteRam */

#if 0
void dataOutVendorCmdSetCardMode()
{
    // Copy tsb0 to ParamTable

    setCeMapTable();
    setChMapTable();

    setAleRegister();    // setAutoAleCtrl();//setChunkMem();

    if(rmGpioP06SelToggle)
    {
        setBusToggleMode();
    }
}    /* dataOutVendorCmdSetCardMode */

#endif/* if 0 */
void dataOutVendorCmdWritePhysicalPage()
{
#if 1
    insertVendorTask(cVendorCore1ProgFlash);
#else
    LWORD u32TlcMode;

    // BLKSPRINFO *upBlkSprInfo;

    u32TlcMode=mChkMlcMoBit(rmVndrFBlock);
    gpFlashAddrInfo=&gpVendorAddrInfo;
    gOpTyp=cVenderWrite;
    setVendorRwInfo();
    setSprByteforVendor(gPlaneAddr, g16FBlock, g16FPage, gCh, gIntlvAddr, 0xFF);
    mSetFRwParam(c16Tsb0SIdx, gSectorPerPlaneH, 0, cVenderWrite);
    setFLActCh(gCh);

    // flashProgPage(mGetWriteBuf, mGetProgSctrCnt, mGetWriteOpt);
    insertVendorTask(cVendorCore1ProgFlash);

    gSpareCnt[gCh]=cZero;

    if(u32TlcMode)
    {
        mSetMlcMoBit(g16FBlock);
    }
    else
    {
        mClrMlcMoBit(g16FBlock);
    }
#endif/* if 1 */
}    /* dataOutVendorCmdWritePhysicalPage */

void dataOutVendorCmdWdPhyProgram()
{
    insertVendorTask(cVendorCore1WdPhyProgram);
}

void dataOutVendorCmdWriteMPInfo()
{
    insertVendorTask(cVendorCore1WriteMPInfo);
}

#endif/* if (_PRJ_SMIVU||_ICE_LOAD_ALL) */

#if _GREYBOX
void dataOutVendorCmdGreyBoxTrig()
{
    outCS(cbTagdataOutVendorCmdGreyBoxTrig);
    copyCcmVal((BYTE *)&gsGbInfo, (BYTE *)&garTsb0[0][0], sizeof(gsGbInfo));
    gsGbInfo.uGreyBoxItem=rmNvmeSubCmdParam1;
    gsGbInfo.uGreyBoxOpt=rmNvmeSubCmdParam2;

    if((gsGbInfo.uGreyBoxItem==cErrHdlReadUncInSlcDataID)||(gsGbInfo.uGreyBoxItem==cErrHdlReadUncInTlcDataID)||
       (gsGbInfo.uGreyBoxItem==cRAIDDecOnH2fTab)||(gsGbInfo.uGreyBoxItem==cRAIDDecOnH2f1kTab)||
       (gsGbInfo.uGreyBoxItem==cRAIDDecOnNormData)||(gsGbInfo.uGreyBoxItem==cRAIDDecOnOpenData)||
       (gsGbInfo.uGreyBoxItem==cRAIDDecOnPreReadData)||(gsGbInfo.uGreyBoxItem==cRAIDDecOnLastReadData)||
       (gsGbInfo.uGreyBoxItem==cRAIDDecOnMoveReadData)||((gsGbInfo.uGreyBoxItem==cSecurityRW)&&(gsGbInfo.uGreyBoxOpt==cVOpSecurityRAID)))
    {
        gReadErrinjectEn=cTrue;
        g16GbRetryTabLoop=c16BitFF;
    }
    else if(gsGbInfo.uGreyBoxItem==cErrHdlGcFingerFailTestID)
    {
        gReadErrinjectEn=cTrue;
        g16GbRetryTabLoop=c16BitFF;
        g16GbGcCachebActThr=gsGcInfo.u16GcCachebActThr;
        gsGcInfo.u16GcCachebActThr=gsCacheInfo.u16SLCSpareCnt-gsGbInfo.uGreyBoxOpt;
    }
    else if(gsGbInfo.uGreyBoxItem==cReadRetryDecodeTestID)
    {
        gReadErrinjectEn=cTrue;
    }
    else if(gsGbInfo.uGreyBoxItem==cFtlRuleReadReclaimID)
    {
        g16GbSetReclaimBlk=gsGbInfo.u32BkValue;
    }
    else if(gsGbInfo.uGreyBoxItem==cUGSDonWearleveling)
    {
        g16GbWLGcSrcTLCBlock=gsGbInfo.u32BkValue&0x0000FFFF;
        g16GbWLGcDesTLCBlock=(gsGbInfo.u32BkValue>>16);
    }
    else if((gsGbInfo.uGreyBoxItem==cErrHdlProgCacheBlk)||(gsGbInfo.uGreyBoxItem==cErrHdlProgS2TGcDesID)||
            (gsGbInfo.uGreyBoxItem==cErrHdlProgT2TGcDesID)||(gsGbInfo.uGreyBoxItem==cErrHdlProgS2SGcDesID))
    {
        gGbSetPgFailCase=(*(BYTE *)(c32Tsb0SAddr+cGbSetGcPgFailFblkIndex));
        g16GbSetPgFailFpage=(*(WORD *)(c32Tsb0SAddr+cGbSetPgFailFpage));
        gGbSetPgFailCh=(*(BYTE *)(c32Tsb0SAddr+cGbSetPgFailCh));
        gGbSetPgFailIntlvAddr=(*(BYTE *)(c32Tsb0SAddr+cGbSetPgFailIntlvAddr));
        gGbSetPgFailPlane=(*(BYTE *)(c32Tsb0SAddr+cGbSetPgFailPlane));
    }
    else if(gsGbInfo.uGreyBoxItem==cErrHdlProgWPROID)
    {
        gGbSetPgFailCase=(BYTE)gsGbInfo.u32BkValue;

        if(gGbSetPgFailCase==cWproBadInfo)
        {
            gReadErrinjectEn=cTrue;
            g16GbRetryTabLoop=c16BitFF;
        }
    }

    // copyCcmVal((BYTE *)&garTsb0[0][0], (BYTE *)&gsGbInfo, sizeof(gsGbInfo));
    garTsb0[0x07][0x1F9]='G';
    garTsb0[0x07][0x1FA]='B';
    garTsb0[0x07][0x1FB]='W';
    garTsb0[0x07][0x1FC]='T';
    garTsb0[0x07][0x1FD]='R';
    garTsb0[0x07][0x1FE]='I';
    garTsb0[0x07][0x1FF]='G';
    // closeVendorCmdDebugInfo(cSuccess, cZero);
}    /* dataOutVendorCmdGreyBoxTrig */

void dataOutVendorCmdGreyBoxFwUniTestIn()
{
    BYTE uResult=cFalse;

    gsUtInfo.u64UtPath=0;
    gsUtInfo.u32UtFunc=rmNvmeSubCmdParam1;
    gsUtInfo.u32UtItem=rmNvmeSubCmdParam2;
    gsUtInfo.u32UtCase=rmNvmeSubCmdParam3;

#if 0
    if(!uResult)
    {
        while(1)
            ;
    }
#endif
}    /* dataOutVendorCmdGreyBoxFwUniTestIn */

#endif/* if _GREYBOX */







