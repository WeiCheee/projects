







/* Set ASIC PHY Control on boot code */
#include "inc/Reg.h"
#include "inc/TypeDef.h"
#include "inc/ProType.h"

void setDummyPHYAddr(BYTE uAPhy)
{
    BYTE uLoop;

    for(uLoop=0; uLoop<5; uLoop++)
    {
        if(uAPhy)
        {
            crRead(cAddrAphyLane0|0xFF);
            crRead(cAddrAphyLane1|0xFF);
            crRead(cAddrAphyLane2|0xFF);
            crRead(cAddrAphyLane3|0xFF);
        }
        else
        {
            crRead(cAddrDphyLane0|0xFF);
            crRead(cAddrDphyLane1|0xFF);
            crRead(cAddrDphyLane2|0xFF);
            crRead(cAddrDphyLane3|0xFF);
        }
    }
}    /* setDummyPHYAddr */

void setDphyParameter(WORD u16LaneNum, BYTE uSet)
{
    WORD u16DphyAddr=cAddrDphyLane0|(u16LaneNum<<8);
    WORD u16CrData;

// #if _Enable_Customize_Patch
    BYTE uPresetValueCnt=chkEqPhase2PresetValueCnt();

// #endif
    crWrite((u16DphyAddr|cAddrDphyParityBit), cDatSetDphyParityBit);    // enable write priority

#if (_PHYCHG2_3_KI)
    gsLightSwitch.usPhyLs.uG3Ki=0;    // (Sam)
    gsLightSwitch.usPhyLs.uG2Ki=0;    // (Sam)
    gsLightSwitch.usPhyLs.uG1Ki=0;    // (Sam)
#endif

    if(uSet)
    {
        u16CrData=((crRead(u16DphyAddr|cAddrRxRonCtrl)&(0xC0))|0x3F);    // Set RxRON on all state
        crWrite((u16DphyAddr|cAddrRxRonCtrl), u16CrData);

#if (!_SM226X_A0)    // Lane drop issue that only fixed by SM2262 A1.
        u16CrData=(crRead((u16DphyAddr|cAddrErrRpt)))&0x6F;
        crWrite((u16DphyAddr|cAddrErrRpt), (u16CrData|cEnRdErrRpt|cEnDecErrRpt));
#endif
        // Set DPHY parameter

        crWrite((u16DphyAddr|cAddrGen12DfEqc), cDatSetGen12DfEqc);    // GEN12_DF_Eqc

        // Set Equalization Algorithm
        crWrite((u16DphyAddr|cAddrFomEcCntLenH), cDatSetFomEcCntLenH);    // 2263
        // crWrite((u16DphyAddr|cAddrFomEcCntLenL), cDatSetFomEcCntLenL); //2263
        crWrite((u16DphyAddr|cAddrEcCntLenH), cDatSetEcCntLenH);    // ec_cntlen_H
        crWrite((u16DphyAddr|cAddrEcCntLenL), cDatSetEcCntLenL);    // ec_cntlen_L

        if(uPresetValueCnt<9)    // 2263
        {
            crWrite((u16DphyAddr|cAddrChkPtFom), 0x31);    // chkpt_fom  130
            crWrite((u16DphyAddr|cAddrChkPtCtle), 0x6A);    // chkpt_ctle 170
            crWrite((u16DphyAddr|cAddrChkPtDfe), 0xB9);    // chkpt_dfe  209
            crWrite((u16DphyAddr|cAddrChkPtOffd), 0xBE);    // chkpt_offd 224
        }
        else
        {
            crWrite((u16DphyAddr|cAddrChkPtFom), 0x43);    // chkpt_fom  130
            crWrite((u16DphyAddr|cAddrChkPtCtle), 0x7C);    // chkpt_ctle 170
            crWrite((u16DphyAddr|cAddrChkPtDfe), 0xCA);    // chkpt_dfe  209
            crWrite((u16DphyAddr|cAddrChkPtOffd), 0xCB);    // chkpt_offd 224
        }

        // crWrite((u16DphyAddr|cAddrRxtVth), cDatSetRxtVth);    // rxt_vth  //40:0x28
        crWrite((u16DphyAddr|cAddrRxtOffvVthL), cDatSetRxtOffvVthL);

        // Set RX Parameter
        // crWrite((u16DphyAddr|cAddrEqrIni),cDatSetEqrIni);           //Eqr_INI
        crWrite((u16DphyAddr|cAddrEqrIniMag), cDatSetEqrIniMag);    // Eqr_INI_MAG

        crWrite((u16DphyAddr|cAddrEqcDir), cDatSetEqcDir);    // Eqc_DIR
        // crWrite((u16DphyAddr|cAddrEqcIni),cDatSetEqcIni);           //Eqc_INI
        crWrite((u16DphyAddr|cAddrEqcMag), cDatSetEqcMag);    // Eqc_MAG

        // crWrite((u16DphyAddr|cAddrTap1Ini),cDatSetTap1Ini);         //Tap1_INI
        crWrite((u16DphyAddr|cAddrTap1IniDir), cDatSetTap1IniDir);
        crWrite((u16DphyAddr|cAddrTap1IniMag), cDatSetTap1IniMag);    // Tap1_INI_MAG

        // crWrite((u16DphyAddr|cAddrTap2Ini),cDatSetTap2Ini);         //Tap2_INI
        crWrite((u16DphyAddr|cAddrTap2IniDir), cDatSetTap2IniDir);    // Tap2_INI_DIR
        crWrite((u16DphyAddr|cAddrTap2IniMag), cDatSetTap2IniMag);    // Tap2_INI_MAG

        // crWrite((u16DphyAddr|cAddrTap3Ini),cDatSetTap3Ini);         //Tap3_INI
        crWrite((u16DphyAddr|cAddrTap3IniDir), cDatSetTap3IniDir);
        crWrite((u16DphyAddr|cAddrTap3IniMag), cDatSetTap3IniMag);    // Tap3_INI_MAG

        crWrite((u16DphyAddr|cAddrOffdIni), cDatSetOffdIni);    // Offd_INI
        crWrite((u16DphyAddr|cAddrOffdIniMag), cDatSetOffdIniMag);    // Offd_INI_MAG

        u16CrData=crRead((u16DphyAddr|cAddrVgat));
        crWrite((u16DphyAddr|cAddrVgat), ((u16CrData&0xFC)|cDatSetVgat));
        crWrite((u16DphyAddr|cAddrVga), cDatSetVga);

        if(gsLightSwitch.usPhyLs.uDphyManual&cDeemphManual)    // DEEMPH_MANUAL
        {
            crWrite((u16DphyAddr|cAddrDeemphManualGen1Dm0Ini),
                    (gsLightSwitch.usPhyLs.uDphyManual&cDeemphManual)|(gsLightSwitch.usPhyLs.uG1Dm0));
            crWrite((u16DphyAddr|cAddrGen3Dm0Ini), gsLightSwitch.usPhyLs.uG3Dm0);
            crWrite((u16DphyAddr|cAddrGen3Dm1Ini), gsLightSwitch.usPhyLs.uG3Dm1);
            crWrite((u16DphyAddr|cAddrGen3Dm2Ini), gsLightSwitch.usPhyLs.uG3Dm2);
            crWrite((u16DphyAddr|cAddrGen2Dm0Ini), gsLightSwitch.usPhyLs.uG2Dm0);
            crWrite((u16DphyAddr|cAddrGen2Dm1Ini), gsLightSwitch.usPhyLs.uG2Dm1);
            crWrite((u16DphyAddr|cAddrGen2Dm2Ini), gsLightSwitch.usPhyLs.uG2Dm2);
            // crWrite((u16DphyAddr | cAddrGen1Dm0Ini), gsLightSwitch.usPhyLs.uG1Dm0);
            crWrite((u16DphyAddr|cAddrGen1Dm1Ini), gsLightSwitch.usPhyLs.uG1Dm1);
            crWrite((u16DphyAddr|cAddrGen1Dm2Ini), gsLightSwitch.usPhyLs.uG1Dm2);
        }

        crWrite((u16DphyAddr|cAddrGen3KdIni), gsLightSwitch.usPhyLs.uG3Kd);
        crWrite((u16DphyAddr|cAddrGen3KpIni), gsLightSwitch.usPhyLs.uG3Kp);
        crWrite((u16DphyAddr|cAddrGen3KiIni), gsLightSwitch.usPhyLs.uG3Ki);
        crWrite((u16DphyAddr|cAddrGen3EqrIni), gsLightSwitch.usPhyLs.uG3Eqr);    // Eqr_INI
        crWrite((u16DphyAddr|cAddrGen3EqcIni), gsLightSwitch.usPhyLs.uG3Eqc);    // Eqc_INI
        crWrite((u16DphyAddr|cAddrGen3Tap1Ini), gsLightSwitch.usPhyLs.uG3Tap1);    // Tap1_INI
        crWrite((u16DphyAddr|cAddrGen3Tap2Ini), gsLightSwitch.usPhyLs.uG3Tap2);    // Tap2_INI
        crWrite((u16DphyAddr|cAddrGen3Tap3Ini), gsLightSwitch.usPhyLs.uG3Tap3);    // Tap3_INI

        if(gsLightSwitch.usPhyLs.uDphyManual&cG2DphyManual)    // G2_DPHY_MANUAL
        {
            crWrite((u16DphyAddr|cAddrGen2KdIni), gsLightSwitch.usPhyLs.uG2Kd);
            crWrite((u16DphyAddr|cAddrGen2KpIni), gsLightSwitch.usPhyLs.uG2Kp);
            crWrite((u16DphyAddr|cAddrGen2KiIni), gsLightSwitch.usPhyLs.uG2Ki);
            crWrite((u16DphyAddr|cAddrGen2EqrIni), gsLightSwitch.usPhyLs.uG2Eqr);    // Eqr_INI
            crWrite((u16DphyAddr|cAddrGen2EqcIni), gsLightSwitch.usPhyLs.uG2Eqc);    // Eqc_INI
            crWrite((u16DphyAddr|cAddrGen2Tap1Ini), gsLightSwitch.usPhyLs.uG2Tap1);    // Tap1_INI
            crWrite((u16DphyAddr|cAddrGen2Tap2Ini), gsLightSwitch.usPhyLs.uG2Tap2);    // Tap2_INI
            crWrite((u16DphyAddr|cAddrGen2Tap3Ini), gsLightSwitch.usPhyLs.uG2Tap3);
        }

        if(gsLightSwitch.usPhyLs.uDphyManual&cG1DphyManual)    // G1_DPHY_MANUAL
        {
            crWrite((u16DphyAddr|cAddrGen1KdIni), gsLightSwitch.usPhyLs.uG1Kd);
            crWrite((u16DphyAddr|cAddrGen1KpIni), gsLightSwitch.usPhyLs.uG1Kp);
            crWrite((u16DphyAddr|cAddrGen1KiIni), gsLightSwitch.usPhyLs.uG1Ki);
            crWrite((u16DphyAddr|cAddrGen1EqrIni), gsLightSwitch.usPhyLs.uG1Eqr);    // Eqr_INI
            crWrite((u16DphyAddr|cAddrGen1EqcIni), gsLightSwitch.usPhyLs.uG1Eqc);    // Eqc_INI
            crWrite((u16DphyAddr|cAddrGen1Tap1Ini), gsLightSwitch.usPhyLs.uG1Tap1);    // Tap1_INI
            crWrite((u16DphyAddr|cAddrGen1Tap2Ini), gsLightSwitch.usPhyLs.uG1Tap2);    // Tap2_INI
            crWrite((u16DphyAddr|cAddrGen1Tap3Ini), gsLightSwitch.usPhyLs.uG1Tap3);
        }

#if 0    // remove, 2263
        if(gsLightSwitch.usPhyLs.uL0SRxOff)
#endif
        {
            // if enabled, decide RX on/off depends on RX electrical idle
            // this function will cause link drop to gen1 after exit L1.2, so we need force KI to zero
            u16CrData=crRead((u16DphyAddr|cAddrDphyParityBit));    // (0x3CFF);
            u16CrData=crRead((u16DphyAddr|cAddrD0DisLane));    // (0x3C8f);
            crWrite((u16DphyAddr|cAddrD0DisLane), (u16CrData|cDatSetD0DisLane));    // (0x3C8f, (u16CrData | 0x0001));
            crWrite((u16DphyAddr|cAddrAb), cDatSetAb);    // (0x3CAB, 0x1E);
        }

#if (!_SM226X_A0)    // Only for SM2263 A1. (Lane drop patch)
#if (!_TBCOFF_PATCH_OPTION2_EN)
        u16CrData=crRead((u16DphyAddr|cAddrTbcOffIssueOp12En));    // (0x3C8f);
        crWrite((u16DphyAddr|cAddrTbcOffIssueOp12En), (u16CrData|cDatClrTbcOffIssueOp2En));    // (0x3CAB, 0x1E);
#endif

#if (!_TBCOFF_PATCH_OPTION1_EN)
        u16CrData=crRead((u16DphyAddr|cAddrTbcOffIssueOp12En));    // (0x3C8f);
        crWrite((u16DphyAddr|cAddrTbcOffIssueOp12En), (u16CrData|cDatClrTbcOffIssueOp1En));    // (0x3CAB, 0x1E);
#endif
#endif
        u16CrData=crRead((u16DphyAddr|cAddrDphyParityBit));
        u16CrData=crRead((u16DphyAddr|cAddrEieosDetAlways));
        crWrite((u16DphyAddr|cAddrEieosDetAlways), (cDatSetAddrEieosDetAlways|u16CrData));
        crWrite((u16DphyAddr|cAddrDpatchCtl), (cDatSetEnSpdChgDisRx|cDatSetEnFilterCom    /*| DAT_SET_EN_FSH_EIOS_CLR_BLKALIGN_N |
                                                                                             * DAT_SET_EN_EIOS_CLR_BLKALIGN_N*/
                                               ));

        u16CrData=crRead((u16DphyAddr|cAddrDphyParityBit));
        u16CrData=crRead((u16DphyAddr|cAddrDpatch1Ctl));
        crWrite((u16DphyAddr|cAddrDpatch1Ctl), (cDatSetCheckBlockAlign|cDatSetCheckFollowAlignContRo|u16CrData));

#if ModernStandby_Dis3mW    // For the platfrom not flow PCIE L1.1/1.2 used  //Enanle;20181221_Eason_01
        // Following code forces PHY enable SQ circuit while PCIe LINK is in L1.1 and L1.2.
        u16CrData=((crRead(u16DphyAddr|0x88)&(0x3F))|0x40);    // Keep SQON when PHY enter L1.2 state
        crWrite((u16DphyAddr|0x88), u16CrData);
#endif
        // new light switch
        writeWiMask((u16DphyAddr|cAddrNormalModeMax), cSmbNormalModeMax, gsLightSwitch.usPhyLs.uNormalModeMax);
        writeWiMask((u16DphyAddr|cAddrSrisSrnsMax), cSmbSrisSrnsMax, gsLightSwitch.usPhyLs.uSrisSrnsMax);
        writeWiMask((u16DphyAddr|cAddrSqaOffset), cSmbSqaOffset, gsLightSwitch.usPhyLs.uSqaOffSet);

        u16CrData=((crRead(u16DphyAddr|0x90)&(0xFE))|0x01);    // ENSOC in L2
        crWrite((u16DphyAddr|0x90), u16CrData);
        u16CrData=((crRead(u16DphyAddr|0x91)&(0xFE))|0x01);    // REFCLK Exist in L2
        crWrite((u16DphyAddr|0x91), u16CrData);
        u16CrData=((crRead(u16DphyAddr|0x92)&(0xFE))|0x01);    // ENDIFREF in L2
        crWrite((u16DphyAddr|0x92), u16CrData);
        u16CrData=((crRead(u16DphyAddr|0x93)&(0xFE))|0x01);    // PLL ON in L2
        crWrite((u16DphyAddr|0x93), u16CrData);
        u16CrData=((crRead(u16DphyAddr|0x94)&(0xFE))|0x01);    // TBC ON in L2
        crWrite((u16DphyAddr|0x94), u16CrData);
        u16CrData=((crRead(u16DphyAddr|0x97)&(0xFE))|0x01);    // WPull ON in L2
        crWrite((u16DphyAddr|0x97), u16CrData);
        u16CrData=((crRead(u16DphyAddr|0x99)&(0xFE))|0x01);    // RXRON in L2
        crWrite((u16DphyAddr|0x99), u16CrData);
    }
    else    // check
    {
        chkWriteWiMask((u16DphyAddr|cAddrGen12DfEqc), 0xFF, cDatSetGen12DfEqc);    // GEN12_DF_Eqc
        chkWriteWiMask((u16DphyAddr|cAddrFomEcCntLenH), 0xFF, cDatSetFomEcCntLenH);

        // Set Equalization Algorithm
        chkWriteWiMask((u16DphyAddr|cAddrEcCntLenH), 0xFF, cDatSetEcCntLenH);    // ec_cntlen_H
        chkWriteWiMask((u16DphyAddr|cAddrEcCntLenL), 0xFF, cDatSetEcCntLenL);    // ec_cntlen_L

        if(uPresetValueCnt<9)    // 2263
        {
            chkWriteWiMask((u16DphyAddr|cAddrChkPtFom), 0xFF, 0x31);    // chkpt_fom  130
            chkWriteWiMask((u16DphyAddr|cAddrChkPtCtle), 0xFF, 0x6A);    // chkpt_ctle 170
            chkWriteWiMask((u16DphyAddr|cAddrChkPtDfe), 0xFF, 0xB9);    // chkpt_dfe  209
            chkWriteWiMask((u16DphyAddr|cAddrChkPtOffd), 0xFF, 0xBE);    // chkpt_offd 224
        }
        else
        {
            chkWriteWiMask((u16DphyAddr|cAddrChkPtFom), 0xFF, 0x43);    // chkpt_fom  130
            chkWriteWiMask((u16DphyAddr|cAddrChkPtCtle), 0xFF, 0x7C);    // chkpt_ctle 170
            chkWriteWiMask((u16DphyAddr|cAddrChkPtDfe), 0xFF, 0xCA);    // chkpt_dfe  209
            chkWriteWiMask((u16DphyAddr|cAddrChkPtOffd), 0xFF, 0xCB);    // chkpt_offd 224
        }

        // crWrite((u16DphyAddr|cAddrRxtVth), cDatSetRxtVth);    // rxt_vth  //40:0x28
        chkWriteWiMask((u16DphyAddr|cAddrRxtOffvVthL), 0xFF, cDatSetRxtOffvVthL);    // rxt_vth  //40:0x28

        // Set RX Parameter
        // chkWriteWiMask((u16DphyAddr|cAddrEqrIni),0xFF,cDatSetEqrIni);           //Eqr_INI
        chkWriteWiMask((u16DphyAddr|cAddrEqrIniMag), 0xFF, cDatSetEqrIniMag);    // Eqr_INI_MAG

        // chkWriteWiMask((u16DphyAddr|cAddrEqcIni),0xFF,cDatSetEqcIni);           //Eqc_INI
        chkWriteWiMask((u16DphyAddr|cAddrEqcDir), 0x01, cDatSetEqcDir);    // Eqc_DIR
        chkWriteWiMask((u16DphyAddr|cAddrEqcMag), 0xFF, cDatSetEqcMag);    // Eqc_MAG

        // chkWriteWiMask((u16DphyAddr|cAddrTap1Ini),0xFF,cDatSetTap1Ini);         //Tap1_INI
        chkWriteWiMask((u16DphyAddr|cAddrTap1IniDir), 0xFF, cDatSetTap1IniDir);
        chkWriteWiMask((u16DphyAddr|cAddrTap1IniMag), 0xFF, cDatSetTap1IniMag);    // Tap1_INI_MAG

        // chkWriteWiMask((u16DphyAddr|cAddrTap2Ini),0xFF,cDatSetTap2Ini);         //Tap2_INI
        chkWriteWiMask((u16DphyAddr|cAddrTap2IniDir), 0xFF, cDatSetTap2IniDir);    // Tap2_INI_DIR
        chkWriteWiMask((u16DphyAddr|cAddrTap2IniMag), 0xFF, cDatSetTap2IniMag);    // Tap2_INI_MAG

        // chkWriteWiMask((u16DphyAddr|cAddrTap3Ini),0xFF,cDatSetTap3Ini);         //Tap3_INI
        chkWriteWiMask((u16DphyAddr|cAddrTap3IniDir), 0xFF, cDatSetTap3IniDir);
        chkWriteWiMask((u16DphyAddr|cAddrTap3IniMag), 0xFF, cDatSetTap3IniMag);    // Tap3_INI_MAG

        chkWriteWiMask((u16DphyAddr|cAddrOffdIni), 0xFF, cDatSetOffdIni);    // Offd_INI
        chkWriteWiMask((u16DphyAddr|cAddrOffdIniMag), 0xFF, cDatSetOffdIniMag);    // Offd_INI_MAG

        u16CrData=crRead((u16DphyAddr|cAddrVgat));
        chkWriteWiMask((u16DphyAddr|cAddrVgat), 0xFF, ((u16CrData&0xFC)|cDatSetVgat));
        chkWriteWiMask((u16DphyAddr|cAddrVga), 0xFF, cDatSetVga);

        chkWriteWiMask((u16DphyAddr|cAddrC0), 0xFF, cDatClrF5);    // (0x3CC0, 0x00c0);
        chkWriteWiMask((u16DphyAddr|cAddrF5), 0xFF, cDatClrC0);    // (0x3CF5, 0x0001);

        // new light switch
        chkWriteWiMask((u16DphyAddr|cAddrNormalModeMax), cSmbNormalModeMax, gsLightSwitch.usPhyLs.uNormalModeMax);
        chkWriteWiMask((u16DphyAddr|cAddrSrisSrnsMax), cSmbSrisSrnsMax, gsLightSwitch.usPhyLs.uSrisSrnsMax);
        chkWriteWiMask((u16DphyAddr|cAddrSqaOffset), cSmbSqaOffset, gsLightSwitch.usPhyLs.uSqaOffSet);

        chkWriteWiMask((u16DphyAddr|cAddrGen3KdIni), cSmbGen3Kd, gsLightSwitch.usPhyLs.uG3Kd);
        chkWriteWiMask((u16DphyAddr|cAddrGen3KpIni), cSmbGen3Kp, gsLightSwitch.usPhyLs.uG3Kp);
        chkWriteWiMask((u16DphyAddr|cAddrGen3KiIni), cSmbGen3Ki, gsLightSwitch.usPhyLs.uG3Ki);
        chkWriteWiMask((u16DphyAddr|cAddrGen3EqrIni), cSmbGen3Eqr, gsLightSwitch.usPhyLs.uG3Eqr);    // Eqr_INI
        chkWriteWiMask((u16DphyAddr|cAddrGen3EqcIni), cSmbGen3Eqc, gsLightSwitch.usPhyLs.uG3Eqc);    // Eqc_INI
        chkWriteWiMask((u16DphyAddr|cAddrGen3Tap1Ini), cSmbGen3Tap1, gsLightSwitch.usPhyLs.uG3Tap1);    // Tap1_INI
        chkWriteWiMask((u16DphyAddr|cAddrGen3Tap2Ini), cSmbGen3Tap2, gsLightSwitch.usPhyLs.uG3Tap2);    // Tap2_INI
        chkWriteWiMask((u16DphyAddr|cAddrGen3Tap3Ini), cSmbGen3Tap3, gsLightSwitch.usPhyLs.uG3Tap3);    // Tap3_INI

        if(gsLightSwitch.usPhyLs.uDphyManual&cG2DphyManual)    // G2_DPHY_MANUAL
        {
            chkWriteWiMask((u16DphyAddr|cAddrGen2KdIni), cSmbGen2Kd, gsLightSwitch.usPhyLs.uG2Kd);
            chkWriteWiMask((u16DphyAddr|cAddrGen2KpIni), cSmbGen2Kp, gsLightSwitch.usPhyLs.uG2Kp);
            chkWriteWiMask((u16DphyAddr|cAddrGen2KiIni), cSmbGen2Ki, gsLightSwitch.usPhyLs.uG2Ki);
            chkWriteWiMask((u16DphyAddr|cAddrGen2EqrIni), cSmbGen2Eqr, gsLightSwitch.usPhyLs.uG2Eqr);    // Eqr_INI
            chkWriteWiMask((u16DphyAddr|cAddrGen2EqcIni), cSmbGen2Eqc, gsLightSwitch.usPhyLs.uG2Eqc);    // Eqc_INI
            chkWriteWiMask((u16DphyAddr|cAddrGen2Tap1Ini), cSmbGen2Tap1, gsLightSwitch.usPhyLs.uG2Tap1);    // Tap1_INI
            chkWriteWiMask((u16DphyAddr|cAddrGen2Tap2Ini), cSmbGen2Tap2, gsLightSwitch.usPhyLs.uG2Tap2);    // Tap2_INI
            chkWriteWiMask((u16DphyAddr|cAddrGen2Tap3Ini), cSmbGen2Tap3, gsLightSwitch.usPhyLs.uG2Tap3);
        }

        if(gsLightSwitch.usPhyLs.uDphyManual&cG1DphyManual)    // G1_DPHY_MANUAL
        {
            chkWriteWiMask((u16DphyAddr|cAddrGen1KdIni), cSmbGen1Kd, gsLightSwitch.usPhyLs.uG1Kd);
            chkWriteWiMask((u16DphyAddr|cAddrGen1KpIni), cSmbGen1Kp, gsLightSwitch.usPhyLs.uG1Kp);
            chkWriteWiMask((u16DphyAddr|cAddrGen1KiIni), cSmbGen1Ki, gsLightSwitch.usPhyLs.uG1Ki);
            chkWriteWiMask((u16DphyAddr|cAddrGen1EqrIni), cSmbGen1Eqr, gsLightSwitch.usPhyLs.uG1Eqr);    // Eqr_INI
            chkWriteWiMask((u16DphyAddr|cAddrGen1EqcIni), cSmbGen1Eqc, gsLightSwitch.usPhyLs.uG1Eqc);    // Eqc_INI
            chkWriteWiMask((u16DphyAddr|cAddrGen1Tap1Ini), cSmbGen1Tap1, gsLightSwitch.usPhyLs.uG1Tap1);    // Tap1_INI
            chkWriteWiMask((u16DphyAddr|cAddrGen1Tap2Ini), cSmbGen1Tap2, gsLightSwitch.usPhyLs.uG1Tap2);    // Tap2_INI
            chkWriteWiMask((u16DphyAddr|cAddrGen1Tap3Ini), cSmbGen1Tap3, gsLightSwitch.usPhyLs.uG1Tap3);
        }

        if(gsLightSwitch.usPhyLs.uL0SRxOff)
        {
            chkWriteWiMask((u16DphyAddr|cAddrD0DisLane), 0x01, cDatSetD0DisLane);    // Isa RXOFF
        }
    }

    u16CrData=crRead((u16DphyAddr|cAddrDphyParityBit));    // (0x3CFF);
    chkPhyValue(u16CrData, 0x00, (u16DphyAddr|cAddrDphyParityBit));

    crWrite((u16DphyAddr|cAddrDphyParityBit), cDatClrDphyParityBit);    // disable write priority
}    /* setDphyParameter */

void setDphyGlobalParameter(BYTE uSet)
{
    WORD u16CrData;

    crWrite((cAddrDphyLane0|cAddrDphyParityBit), cDatSetDphyParityBit);    // enable write priority

    if(uSet)
    {
        // if(gsLightSwitch.usPhyLs.SRIS_Enable_SSC)
        // {
        // rmEnablePcieSsc;
        // rmSetPcieStep(gsLightSwitch.usPhyLs.SRIS_SRNS_STEP);
        // rmSetPcieSmax(gsLightSwitch.usPhyLs.SRIS_SRNS_SMAX);
        // rmSetPcieSmin(gsLightSwitch.usPhyLs.SRIS_SRNS_SMIN);
        // }

        u16CrData=crRead((cAddrDphyLane0|cAddrLaneRevOpt));    // ADD by sam
        crWrite((cAddrDphyLane0|cAddrLaneRevOpt), (cDatSetLaneRevOpt|u16CrData));    // ADD by sam
        u16CrData=crRead((cAddrDphyLane0|cAddrOffset0A));    // ADD by sam
        crWrite((cAddrDphyLane0|cAddrOffset0A), (cDatSetOffset0A|(u16CrData&0xE0)));    // ADD by sam
    }
    else    // check
    {
        // if(gsLightSwitch.usPhyLs.SRIS_Enable_SSC)
        // {
        // while(!rmCheckPcieSsc);
        // while(rmGetPcieStep != gsLightSwitch.usPhyLs.SRIS_SRNS_STEP);
        // while(rmGetPcieSmax != gsLightSwitch.usPhyLs.SRIS_SRNS_SMAX);
        // while(rmGetPcieSmin != gsLightSwitch.usPhyLs.SRIS_SRNS_SMIN);
        // }
    }

#if _EN_TX_SWING
#if (OEM==GC||OEM==VERIFY)    // Raise Txswing to 0x1F for GC&verify  2019/0604,  F.J. Kuo
    u16CrData=crRead((cAddrDphyLane0|cAddrG3NormalTxSwing));
    crWrite((cAddrDphyLane0|cAddrG3NormalTxSwing), ((cSmbG3NormalTxSwing&0x1F)|(u16CrData&0xE0)));
#else
    u16CrData=crRead((cAddrDphyLane0|cAddrG3NormalTxSwing));
    crWrite((cAddrDphyLane0|cAddrG3NormalTxSwing), ((cSmbG3NormalTxSwing&gsLightSwitch.usPhyLs.uG3NormalTxSwing)|(u16CrData&0xE0)));
#endif
#endif

    u16CrData=crRead((cAddrDphyLane0|cAddrDphyParityBit));    // (0x3CFF);
    chkPhyValue(u16CrData, 0x00, (cAddrDphyLane0|cAddrDphyParityBit));

    crWrite((cAddrDphyLane0|cAddrDphyParityBit), cDatClrDphyParityBit);    // disable write priority
}    /* setDphyGlobalParameter */

void disableUnusedLanes()
{
    WORD u16CrData=0;

    // === Disable unused lanes
    // crWrite((0x3C00 | 0x008F), 0x08);//Lane 0 cannot be disabled

    if((gsLightSwitch.usPcieLs.usLinkCapLs.u32All&0x000003F0)==0x00000010)    // 1 lane
    {
        crWrite((cAddrDphyLane1|cAddrDphyParityBit), cDatSetDphyParityBit);    // enable write priority
        crWrite((cAddrDphyLane2|cAddrDphyParityBit), cDatSetDphyParityBit);    // enable write priority
        crWrite((cAddrDphyLane3|cAddrDphyParityBit), cDatSetDphyParityBit);    // enable write priority

        u16CrData=crRead((cAddrDphyLane1|0x008F));
        crWrite((cAddrDphyLane1|0x008F), u16CrData|0x08);    // Disable Lane 1
        u16CrData=crRead((cAddrDphyLane2|0x008F));
        crWrite((cAddrDphyLane2|0x008F), u16CrData|0x08);    // Disable Lane 2
        u16CrData=crRead((cAddrDphyLane3|0x008F));
        crWrite((cAddrDphyLane3|0x008F), u16CrData|0x08);    // Disable Lane 3

        crWrite((cAddrDphyLane1|cAddrDphyParityBit), cDatClrDphyParityBit);    // disable write priority
        crWrite((cAddrDphyLane2|cAddrDphyParityBit), cDatClrDphyParityBit);    // disable write priority
        crWrite((cAddrDphyLane3|cAddrDphyParityBit), cDatClrDphyParityBit);    // disable write priority

        rSysCtrl0[rcPciePd1]|=0xEE;    // Power Down Lane[1,2,3] TX and TX Weak Pull
        rSysCtrl0[rcPciePd2]|=0xEE;    // Power Down Lane[1,2,3] RX and SQ
    }
    else if((gsLightSwitch.usPcieLs.usLinkCapLs.u32All&0x000003F0)==0x00000020)    // 2 lanes
    {
        crWrite((cAddrDphyLane2|cAddrDphyParityBit), cDatSetDphyParityBit);    // enable write priority
        crWrite((cAddrDphyLane3|cAddrDphyParityBit), cDatSetDphyParityBit);    // enable write priority

        u16CrData=crRead((cAddrDphyLane2|0x008F));
        crWrite((cAddrDphyLane2|0x008F), u16CrData|0x08);    // Disable Lane 2
        u16CrData=crRead((cAddrDphyLane3|0x008F));
        crWrite((cAddrDphyLane3|0x008F), u16CrData|0x08);    // Disable Lane 3

        crWrite((cAddrDphyLane2|cAddrDphyParityBit), cDatClrDphyParityBit);    // disable write priority
        crWrite((cAddrDphyLane3|cAddrDphyParityBit), cDatClrDphyParityBit);    // disable write priority

        rSysCtrl0[rcPciePd1]|=0xCC;    // Power Down Lane[2,3] TX and TX Weak Pull
        rSysCtrl0[rcPciePd2]|=0xCC;    // Power Down Lane[2,3] RX and SQ
    }
}    /* disableUnusedLanes */

void aPhyReadBack(WORD u16Addr, BYTE uMask, BYTE uVal)
{
    WORD u16CrData;

    u16CrData=crRead((u16Addr|cAddrSmb));
    chkPhyValue(u16CrData, uMask, (u16Addr|cAddrSmb));

    chkWriteWiMask(u16Addr, uMask, uVal);    // ?
}

void aPhyWrite(WORD u16Addr, BYTE uMask, BYTE uVal)
{
    crWrite((u16Addr|cAddrSmb), uMask);    // (0x3CC0, 0x00c0);
    crWrite(u16Addr, uVal);
}

void aPhyParameter(WORD u16LaneNum, BYTE uSet)
{
    WORD u16APhyAddr=cAddrAphyLane0|(u16LaneNum<<8);
    BYTE uSmb2B=0;
    BYTE uVal2B=0;

    if(uSet)
    {
#if _EN_CPLtimeouttest
        aPhyWrite((u16APhyAddr|cAddrDm1), 0x1F, 0x00);    // [CPL TEST]
#endif

        if((gsLightSwitch.usPhyLs.uAPhyManual&cKDmanual)||gsLightSwitch.usPhyLs.uAPhyManual&cEQCmanual)
        {
            if(gsLightSwitch.usPhyLs.uAPhyManual&cKDmanual)
            {
                uSmb2B|=cSmbKd;
                uVal2B|=gsLightSwitch.usPhyLs.uKd;
            }

            if(gsLightSwitch.usPhyLs.uAPhyManual&cEQCmanual)
            {
                uSmb2B|=cSmbEqc;
                uVal2B|=(gsLightSwitch.usPhyLs.uEqc<<4);
            }

            aPhyWrite((u16APhyAddr|cAddrKd), uSmb2B, uVal2B);
        }

        if(gsLightSwitch.usPhyLs.uAPhyManual&cKPmanual)
        {
            aPhyWrite((u16APhyAddr|cAddrKp), cSmbKp, gsLightSwitch.usPhyLs.uKp);
        }

        if(gsLightSwitch.usPhyLs.uAPhyManual&cKImanual)
        {
            aPhyWrite((u16APhyAddr|cAddrKi), cSmbKi, gsLightSwitch.usPhyLs.uKi);
        }

        if(gsLightSwitch.usPhyLs.uAPhyManual&cEQRmanual)
        {
            aPhyWrite((u16APhyAddr|cAddrEqr), cSmbEqr, gsLightSwitch.usPhyLs.uEqr);
        }

        if(gsLightSwitch.usPhyLs.uAPhyManual&cTAP1manual)
        {
            aPhyWrite((u16APhyAddr|cAddrTap1), cSmbTap1, gsLightSwitch.usPhyLs.uTap1);
        }

        if(gsLightSwitch.usPhyLs.uAPhyManual&cTAP2manual)
        {
            aPhyWrite((u16APhyAddr|cAddrTap2), cSmbTap2, gsLightSwitch.usPhyLs.uTap2);
        }

        if(gsLightSwitch.usPhyLs.uAPhyManual&cTAP3manual)
        {
            aPhyWrite((u16APhyAddr|cAddrTap3), cSmbTap3, gsLightSwitch.usPhyLs.uTap3);
        }

// #if S_PhyChg1_OFFCb4        //(Sam) BERT long channel
        aPhyWrite((u16APhyAddr|cAddrOffc), cSmbOffcLimt, 0x00);
// #endif

        aPhyWrite((u16APhyAddr|0x24), 0x0080, 0x0080);
    }
    else
    {
        if((gsLightSwitch.usPhyLs.uAPhyManual&cKDmanual)||gsLightSwitch.usPhyLs.uAPhyManual&cEQCmanual)
        {
            if(gsLightSwitch.usPhyLs.uAPhyManual&cKDmanual)
            {
                uSmb2B|=cSmbKd;
                uVal2B|=gsLightSwitch.usPhyLs.uKd;
            }

            if(gsLightSwitch.usPhyLs.uAPhyManual&cEQCmanual)
            {
                uSmb2B|=cSmbEqc;
                uVal2B|=(gsLightSwitch.usPhyLs.uEqc<<4);
            }

            aPhyReadBack((u16APhyAddr|cAddrKd), uSmb2B, uVal2B);
        }

        if(gsLightSwitch.usPhyLs.uAPhyManual&cKPmanual)
        {
            aPhyReadBack((u16APhyAddr|cAddrKp), cSmbKp, gsLightSwitch.usPhyLs.uKp);
        }

        if(gsLightSwitch.usPhyLs.uAPhyManual&cKImanual)
        {
            aPhyReadBack((u16APhyAddr|cAddrKi), cSmbKi, gsLightSwitch.usPhyLs.uKi);
        }

        if(gsLightSwitch.usPhyLs.uAPhyManual&cEQRmanual)
        {
            aPhyReadBack((u16APhyAddr|cAddrEqr), cSmbEqr, gsLightSwitch.usPhyLs.uEqr);
        }

        if(gsLightSwitch.usPhyLs.uAPhyManual&cTAP1manual)
        {
            aPhyReadBack((u16APhyAddr|cAddrTap1), cSmbTap1, gsLightSwitch.usPhyLs.uTap1);
        }

        if(gsLightSwitch.usPhyLs.uAPhyManual&cTAP2manual)
        {
            aPhyReadBack((u16APhyAddr|cAddrTap2), cSmbTap2, gsLightSwitch.usPhyLs.uTap2);
        }

        if(gsLightSwitch.usPhyLs.uAPhyManual&cTAP3manual)
        {
            aPhyReadBack((u16APhyAddr|cAddrTap3), cSmbTap3, gsLightSwitch.usPhyLs.uTap3);
        }

// #if S_PhyChg1_OFFCb4        //(Sam) BERT long channel
        aPhyReadBack((u16APhyAddr|cAddrOffc), cSmbOffcLimt, 0x00);
// #endif
    }
}    /* aPhyParameter */

void aPhyGlobalParameter(BYTE uSet)
{
    if(uSet)
    {
        writeWiMask((cAddrAphyLane1|cAddrPllVvco), cSmbPllVvco, gsLightSwitch.usPhyLs.uPllVvco);
    }
    else    // check
    {
        chkWriteWiMask((cAddrAphyLane1|cAddrPllVvco), cSmbPllVvco, gsLightSwitch.usPhyLs.uPllVvco);
    }
}

void initPhy()
{
    rmClrCtrl;

    setDummyPHYAddr(1);

    // === DPHY set
    setDphyParameter(0x0000, 1);
    setDphyParameter(0x0001, 1);
    setDphyParameter(0x0002, 1);
    setDphyParameter(0x0003, 1);

    setDphyGlobalParameter(1);

    // === DPHY check
    setDphyParameter(0x0000, 0);
    setDphyParameter(0x0001, 0);
    setDphyParameter(0x0002, 0);
    setDphyParameter(0x0003, 0);

    setDphyGlobalParameter(0);

    disableUnusedLanes();    // CSSD-2896 and CSSD-3005

    setDummyPHYAddr(0);

    // === APHY set
    aPhyParameter(0x0000, 1);
    aPhyParameter(0x0001, 1);
    aPhyParameter(0x0002, 1);
    aPhyParameter(0x0003, 1);

    aPhyGlobalParameter(1);

    // === APHY check
    aPhyParameter(0x0000, 0);
    aPhyParameter(0x0001, 0);
    aPhyParameter(0x0002, 0);
    aPhyParameter(0x0003, 0);

    aPhyGlobalParameter(0);

    crRead(cAddrDphyLane0|0xFF);    // freeze all setting
}    /* initPhy */







