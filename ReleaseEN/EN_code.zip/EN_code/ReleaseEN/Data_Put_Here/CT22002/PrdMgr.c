







#include "inc/Option.h"
#include "inc/TypeDef.h"
#include "inc/table.h"
#include "inc/Reg.h"
#include "inc/NvmeCtrl.h"
#include "inc/ProType.h"
// #if (_CPUID==1)
// #include "inc/GlobVar1.h"
// #else
#include "inc/GlobVar0.h"
// #endif
#include "inc/GlobVarS.h"
#include "inc/Mac.h"

#if (!_ICE_LOAD_ALL)
#pragma default_function_attributes = @ ".PRD_MGR"
#endif

void chkReleaseFreeHwPrd()
{
    if(rmChkDpsDppFifoNotEmpty)
    {
        releaseFreeHwPrd();
    }
}

void releaseFreeHwPrd()
{
    BYTE uFreeHwPrdIdx, uTotalPrdTaskCnt, uPrpListErr, uCurrentEng, uCrcErrEngine;

#if _ENABLE_E2E_CMD_RETRY
    BYTE uDoCommandRetry=0;
#endif
    WORD u16PrevNodeIdx, u16NextNodeIdx, u16PrdInfoIdx, u16FreeHostBufSize;
    PRDQUEUE *upPrdInfo;
    volatile LINKINFO *upDelLlInfo;

    uTotalPrdTaskCnt=gsPrdInfo.uTotalPrdTaskCnt;

    do
    {
        uFreeHwPrdIdx=rmCurrentPrd;
        u16PrdInfoIdx=gsPrdInfo.u16arIdxToPrdInfo[uFreeHwPrdIdx];
        uPrpListErr=rmChkPrpListErr;
        uCurrentEng=rmCurrentEngine;
        uCrcErrEngine=rmNvmeCrcFailInfo;

        if(rmChkDppBit)
        {
            if(mChkHandlePcieErrF)
            {
                break;
            }

            upPrdInfo=&gsPrdInfo.uarPrdQue[u16PrdInfoIdx];

            if(gsGcInfo.ubBgdProcF)
            {
                u16FreeHostBufSize=
                    (g16WriteBufPtr>=
                     gsRwCtrl.u16OccFSkipStBufPtr)?(c16WriteBufSize-
                                                    (g16WriteBufPtr-gsRwCtrl.u16OccFSkipStBufPtr)):(gsRwCtrl.u16OccFSkipStBufPtr-
                                                                                                    g16WriteBufPtr);
            }
            else
            {
                u16FreeHostBufSize=c16WriteBufSize;
            }

            if(upPrdInfo->u32RestScrtCnt>u16FreeHostBufSize)
            {
                r32NvmePrd[uFreeHwPrdIdx][5]=u16FreeHostBufSize;
                upPrdInfo->u32RestScrtCnt-=u16FreeHostBufSize;
                gsPrdInfo.u16TrigHostRestSectCnt+=u16FreeHostBufSize;
            }
            else
            {
                r32NvmePrd[uFreeHwPrdIdx][0]|=cLastPrd;
                r32NvmePrd[uFreeHwPrdIdx][5]=upPrdInfo->u32RestScrtCnt;
                gsPrdInfo.u16TrigHostRestSectCnt+=upPrdInfo->u32RestScrtCnt;
                upPrdInfo->u32RestScrtCnt=0;
            }

            g16WriteBufPtr=addWriteBufPtr(g16WriteBufPtr, gsPrdInfo.u16TrigHostRestSectCnt);
            rmClrDpp(uCurrentEng);    // clear dpp flag
        }
        else    // DPS or UNC
        {
            rmClrPrdDoneFlag(uFreeHwPrdIdx);    // clear prd done flag

            if(u16PrdInfoIdx&c16Bit15)
            {}
            else
            {
                upPrdInfo=&gsPrdInfo.uarPrdQue[u16PrdInfoIdx];

                if(upPrdInfo->uOpCode==cNvmeCmdRead)
                {
                    g64TotalHostRdSecCnt+=upPrdInfo->u32SctrCnt;
                    g64HostRdCmdCnt++;

                    if(upPrdInfo->ubQRdCmd)
                    {
                        gsPrdInfo.uQCmdCnt--;
                    }
                    else
                    {
                        gsPrdInfo.uSeqRTrigCnt--;
                    }

                    if(upPrdInfo->uUncFlag)    // HW set this to inform FW there is a UNC case
                    {
                        gsSmart.usCnt.u32TotalUncCnt++;
                        manualCompletion(cStatusUnrecoveredRdErr, 0, cRwCmd, u16PrdInfoIdx);    // manual send completion

                        if(rmChkUncBit)
                        {
                            rmNvmeClrUncFlag(uFreeHwPrdIdx);    // FW set to inform HW
                            rmNmveClrUncPrdReady(uFreeHwPrdIdx);    // HW set to inform FW
                        }

                        if(uCrcErrEngine)
                        {
                            rmClrNvmeCrcFail(uCrcErrEngine);
                        }
                    }
                    else if(uCrcErrEngine)
                    {
                        if(((uCrcErrEngine&cBit0)&&(uCurrentEng==0))||((uCrcErrEngine&cBit1)&&(uCurrentEng==1)))
                        {
                            rmSetEngineMap(uCurrentEng);

                            if(rmChkEngineMap==uFreeHwPrdIdx)
                            {
#if _ENABLE_E2E_WHILE
                                while(uCrcErrEngine)
                                    ;
#endif
                                NLOG(cLogError,
                                     PRDMGR_C,
                                     7,
                                     "E2E : User Data happened CRC error, Prd:0x%04X, Addr:0x%08X, Len:0x%08X, E2E Addr:0x%08X",
                                     u16PrdInfoIdx,
                                     upPrdInfo->u32LbaAddr>>16,
                                     upPrdInfo->u32LbaAddr,
                                     upPrdInfo->u32SctrCnt>>16,
                                     upPrdInfo->u32SctrCnt,
                                     rmGetCrcFailLbaLo(uCurrentEng)>>16,
                                     rmGetCrcFailLbaLo(uCurrentEng));
#if _ENABLE_SECAPI_DEBUG
                                NLOG(cLogError,
                                     PRDMGR_C,
                                     " GetFrdIdxFromE2EFail(): O32_AES_Default_Key0_0=0x%08X, O32_AES_Default_Key0_1=0x%08X ",
                                     (r32AesCtrl[rcAesDefaultKey00])>>16,
                                     (r32AesCtrl[rcAesDefaultKey00]),
                                     (r32AesCtrl[rcAesDefaultKey01])>>16,
                                     (r32AesCtrl[rcAesDefaultKey01]));
                                NLOG(cLogError, PRDMGR_C, " GetFrdIdxFromE2EFail(): O32_AES_P0_Key0_0=0x%08X, O32_AES_P0_Key0_1=0x%08X ",
                                     (r32AesCtrl[rcAesP0Key00])>>16, (r32AesCtrl[rcAesP0Key00]), (r32AesCtrl[rcAesP0Key01])>>16,
                                     (r32AesCtrl[rcAesP0Key01]));
                                NLOG(cLogError, PRDMGR_C, " GetFrdIdxFromE2EFail(): O32_AES_P1_Key0_0=0x%08X, O32_AES_P1_Key0_1=0x%08X ",
                                     (r32AesCtrl[rcAesP1Key00])>>16, (r32AesCtrl[rcAesP1Key00]), (r32AesCtrl[rcAesP1Key01])>>16,
                                     (r32AesCtrl[rcAesP1Key01]));
#endif

#if _ENABLE_E2E_CMD_RETRY
                                if(gsE2eInfo.u16CommandRetryPrd==u16PrdInfoIdx)
                                {
                                    manualCompletion(cStatusUnrecoveredRdErr, 0, cRwCmd, u16PrdInfoIdx);
                                    gsE2eInfo.u16CommandRetryPrd=c16BitFF;
                                }
                                else if(gsE2eInfo.u16CommandRetryPrd==c16BitFF)
                                {
                                    // if(uTotalPrdTaskCnt<cPrdDepth)
                                    // {
                                    uDoCommandRetry=1;
                                    gsE2eInfo.u16CommandRetryPrd=u16PrdInfoIdx;
                                    // gsE2eInfo.u32CommandRetryCnt++;
                                    g32PrdCommandRetryCnt++;
                                    // }
                                    // else
                                    // {
                                    //    manualCompletion(cStatusUnrecoveredRdErr, 0, cRwCmd, u16PrdInfoIdx);
                                    // }
                                }
                                else
                                {
                                    manualCompletion(cStatusUnrecoveredRdErr, 0, cRwCmd, u16PrdInfoIdx);
                                }
#else/* if _ENABLE_E2E_CMD_RETRY */
                                manualCompletion(cStatusUnrecoveredRdErr, 0, cRwCmd, u16PrdInfoIdx);
#endif/* if _ENABLE_E2E_CMD_RETRY */

                                rmClrNvmeCrcFail(1<<uCurrentEng);

                                // gsE2eInfo.u32HostDataCrcCnt++;
                                g32E2eDetectCnt++;
                                g32InternalDataPath++;
                            }
                        }
                    }
                    else if(gsE2eInfo.u16CommandRetryPrd==u16PrdInfoIdx)
                    {
                        gsE2eInfo.u16CommandRetryPrd=c16BitFF;
                    }

                    upDelLlInfo=&gsPrdInfo.usReadPrdList;
                }
                else    // if(upPrdInfo->uOpCode==cNvmeCmdWrite)
                {
                    if(upPrdInfo->uFua&cHdlNvmeFlush)    // 20190417_ChrisSu
                    {
                        if(upPrdInfo->uFuaDone&cBit0)
                        {
                            manualCompletion(cStatusSuccess, 0, cRwCmd, u16PrdInfoIdx);
                        }
                    }
                    else if(upPrdInfo->uFua&cHdl1RestSctr)
                    {
                        manualCompletion(cStatusSuccess, 0, cRwCmd, u16PrdInfoIdx);
                    }
                    else if(upPrdInfo->uFua&cDelayComplect)    // 20190531_ChirsSu
                    {
                        upPrdInfo->uFua=cDelayPrdDone;
                        //           NLOG(cLogTempDebug,
                        //                PRDMGR_C,
                        //                3,
                        //                "releaseFreeHwPrd(),cDelayPrdDone! gbEnAes=0x%04X , upPrdInfo->uFua=0x%04X u16PrdInfoIdx=0x%04x",
                        //                gbEnAes,
                        //                upPrdInfo->uFua,
                        //               u16PrdInfoIdx);
                    }

                    if(mChkDummyWrite&&upPrdInfo->ubSetOccF)
                    {
                        clrFwPreOccuFlag(upPrdInfo->u16BufPtr);
                    }
                    else
                    {
                        gsFtlDbg.u64TotalHostWrSecCnt+=upPrdInfo->u32SctrCnt;
                        g64HostWrCmdCnt++;
                    }

                    upDelLlInfo=&gsPrdInfo.usWritePrdList;
                }

                if((upPrdInfo->uFua&cHdlNvmeFlush)&&(!(upPrdInfo->uFuaDone&cBit0)))
                {
                    upPrdInfo->uFuaDone|=cBit1;
                }
                else if(upPrdInfo->uFua!=cDelayPrdDone)    // 20190531_ChirsSu
                {
                    /*//for FUA CMD
                       * if(upPrdInfo->uFua)
                       * {
                       * NLOG(cLogError,
                       * PRDMGR_C,
                       * 3,
                       * "release DelNode u16PrdInfoIdx:0x%04X, uFreeHwPrdIdx:0x%04X, uFuaDone:0x%04X",
                       * u16PrdInfoIdx,
                       * uFreeHwPrdIdx,
                       * upPrdInfo->uFuaDone);
                       * }
                       */

                    mDelNode(u16PrevNodeIdx, gsPrdInfo.uarPrdLink, u16PrdInfoIdx, u16NextNodeIdx, upDelLlInfo);

#if 1    // debug
                    NVMEPRDSTRUCT *upIOCmd;
                    upIOCmd=&garCmdValidHistory[g32EndCmdHistoryPtr];

                    upIOCmd->u32Dword0=r32NvmePrd[uFreeHwPrdIdx][0];
                    upIOCmd->u32Dword1=r32NvmePrd[uFreeHwPrdIdx][1];
                    upIOCmd->u32Dword5=r32NvmePrd[uFreeHwPrdIdx][5];
                    upIOCmd->u32Dword6=r32NvmePrd[uFreeHwPrdIdx][6];
                    upIOCmd->u32TimeStamp=getRtcCurrent32k();

                    g32EndCmdHistoryPtr++;

                    if(g32EndCmdHistoryPtr>=cCmdHistorySize)
                    {
                        g32EndCmdHistoryPtr=0;
                    }

#if _GREYBOX
                    NVMEPRDSTRUCT *upGbIOCmd;
                    upGbIOCmd=&garGbCmdValidHistory[g32GbEndCmdHistoryPtr];

                    upGbIOCmd->u32Dword0=r32NvmePrd[uFreeHwPrdIdx][0];
                    upGbIOCmd->u32Dword1=r32NvmePrd[uFreeHwPrdIdx][1];
                    upGbIOCmd->u32Dword5=r32NvmePrd[uFreeHwPrdIdx][5];
                    upGbIOCmd->u32Dword6=r32NvmePrd[uFreeHwPrdIdx][6];
                    upGbIOCmd->u32TimeStamp=rmGetRtc32kTick;

                    g32GbEndCmdHistoryPtr++;

                    if(g32GbEndCmdHistoryPtr>=(cCmdHistorySize*cCmdHistorySize))
                    {
                        g32GbEndCmdHistoryPtr=0;
                    }
#endif
#endif/* if 1 */

#if _ENABLE_E2E_CMD_RETRY
                    if(uDoCommandRetry)
                    {
#if (_GREYBOX)
                        if(gsGbInfo.uGreyBoxItem==cErrHdlE2EHostData)
                        {
                            gsGbInfo.uResult=cSuccess;
                        }
#endif
                        mInsNode(u16PrevNodeIdx, upDelLlInfo, u16NextNodeIdx, gsPrdInfo.uarPrdLink, u16PrdInfoIdx);
                        upPrdInfo->ubQRdCmd=0;
                        upPrdInfo->ubSetOccF=0;
                        upPrdInfo->uHwPrdIdx=cNull;
                        upPrdInfo->uUncFlag=0;
                        upPrdInfo->uE2eRetry=1;
#if _EN_DisHMBInReset    // 20190805_Chief_DisHMB
                        if(gsHmbInfo.uHmbEnable||(gChkFlag&cEnableFakeHMB))    // &&(upPrdInfo->uE2eRetry&cBit7))
#else
                        if(gsHmbInfo.uHmbEnable)
#endif
                        {
                            disableHmbFunc(cDisabled);    // LeverYu_0813 SMI S0813A  SQ mismatch issue
                        }

                        // upPrdInfo->uE2eRetry|=cBit6;

                        uDoCommandRetry=0;
                    }
                    else
#endif/* if _ENABLE_E2E_CMD_RETRY */
                    {
                        gsPrdInfo.uarFreePrdQue[gsPrdInfo.uFreePrdTail]=u16PrdInfoIdx;
                        gsPrdInfo.uFreePrdTail=(gsPrdInfo.uFreePrdTail+1)&(cPrdDepth-1);
                        uTotalPrdTaskCnt--;
                    }
                }
            }

            uPrpListErr=rmChkPrpListErr;

            if(uPrpListErr)
            {
                rmSetEngineMap(uCurrentEng);

                if((((uPrpListErr&cBit0)&&(uCurrentEng==0))||((uPrpListErr&cBit1)&&(uCurrentEng==1))||(uPrpListErr&cBit2)&&(uCurrentEng==6))&&
                   (rmChkEngineMap==uFreeHwPrdIdx))
                {
                    manualCompletion(cStatusInvalidPrpOffset, 0, cRwCmd, u16PrdInfoIdx);

                    if(uCurrentEng==6)
                    {
                        rmClrOnePrpListErr(2);
                    }
                    else
                    {
                        rmClrOnePrpListErr(uCurrentEng);
                    }
                }
            }

            gsPrdInfo.uarFreeHwPrdQue[gsPrdInfo.uFreeHwPrdHead]=uFreeHwPrdIdx;
            gsPrdInfo.uFreeHwPrdHead=(gsPrdInfo.uFreeHwPrdHead+1)&(cHwPrdDepth-1);
            gsPrdInfo.uFreeHwPrdCnt++;
        }

        rmPopNextValue;
    }
    while(rmChkDpsDppFifoNotEmpty);

    gsPrdInfo.uTotalPrdTaskCnt=uTotalPrdTaskCnt;
}    /* releaseFreeHwPrd */

/**
   * @brief �Ψ�delete Prd Read/Write ���� Link List
   *
   *  �ثe�D�n�O�n�g�Ӹ� partial work �� AES + HMB �P�ɶ}�Ҫ��ɭԡA
   *  AES ����QHMB���_�A�ҥH�n���@��work around ���@�k
   *  �{���q�u�O����delete NVME write Prd �Q���� multi Prd �� command
   *
   * @param u16PrdInfoIdx ���n�R����Prd Index (0~cPrdDepth-1)
   * @return �L�^�ǭ�
   */
void deletePrdLinkList(WORD u16PrdInfoIdx)
{
    WORD u16NextNodeIdx, u16PrevNodeIdx;
    volatile LINKINFO *upDelLlInfo;

    if(gsPrdInfo.uarPrdQue[u16PrdInfoIdx].uOpCode==cNvmeCmdWrite)
    {
        upDelLlInfo=&gsPrdInfo.usWritePrdList;
    }
    else if(gsPrdInfo.uarPrdQue[u16PrdInfoIdx].uOpCode==cNvmeCmdRead)
    {
        upDelLlInfo=&gsPrdInfo.usReadPrdList;
    }
    else
    {
        return;    // cannot access by other command
    }

    mDelNode(u16PrevNodeIdx, gsPrdInfo.uarPrdLink, u16PrdInfoIdx, u16NextNodeIdx, upDelLlInfo);
    gsPrdInfo.uarFreePrdQue[gsPrdInfo.uFreePrdTail]=u16PrdInfoIdx;
    gsPrdInfo.uFreePrdTail=(gsPrdInfo.uFreePrdTail+1)&(cPrdDepth-1);
    gsPrdInfo.uTotalPrdTaskCnt--;
}    /* deletePrdLinkList */

BYTE getFreeHwPrd()
{
    BYTE uHwPrdIdx;

    while(!gsPrdInfo.uFreeHwPrdCnt)
    {
        releaseFreeHwPrd2();
    }

    uHwPrdIdx=gsPrdInfo.uarFreeHwPrdQue[gsPrdInfo.uFreeHwPrdTail];
    gsPrdInfo.uFreeHwPrdTail=(gsPrdInfo.uFreeHwPrdTail+1)&(cHwPrdDepth-1);
    gsPrdInfo.uFreeHwPrdCnt--;

    return uHwPrdIdx;
}    /* getFreeHwPrd */

// void releaseFreePrdInfo(WORD u16FreePrdInfoIdx)
// {
//    insertNodeToList(gsPrdInfo.uarPrdLink, &gsPrdInfo.usFreePrdList, gsPrdInfo.usFreePrdList.u16Head, u16FreePrdInfoIdx);
// }
/*
   * BYTE getFreePrdInfo()
   * {
   *  BYTE uPrdInfoIdx;
   *
   *  if(gsPrdInfo.usFreePrdList.u16Cnt==0)
   *  {
   *      while(1)
   *          ;
   *  }
   *
   *  uPrdInfoIdx=gsPrdInfo.usFreePrdList.u16Tail;
   *  deleteNodeFromList(gsPrdInfo.uarPrdLink, &gsPrdInfo.usFreePrdList, uPrdInfoIdx);
   *
   *  return uPrdInfoIdx;
   * }
   */
/*
   * BYTE deleteTaskFromRwPrdList(WORD u16NowPrdInfoIdx)
   * {
   *  BYTE uNowPrdOpCode=gsPrdInfo.uarPrdQue[u16NowPrdInfoIdx].uOpCode;
   *
   *  // gsPrdInfo.uarPrdQue[u16NowPrdInfoIdx].ubStatusF= 1;
   *
   *  if(uNowPrdOpCode==cNvmeCmdRead)
   *  {
   *      deleteNodeFromList(gsPrdInfo.uarPrdLink, &gsPrdInfo.usReadPrdList, u16NowPrdInfoIdx);
   *  }
   *  else    // cNvmeCmdWrite
   *  {
   *      deleteNodeFromList(gsPrdInfo.uarPrdLink, &gsPrdInfo.usWritePrdList, u16NowPrdInfoIdx);
   *  }
   *
   *  // releaseFreePrdInfo(u16NowPrdInfoIdx);
   *  insertNodeToList(gsPrdInfo.uarPrdLink, &gsPrdInfo.usFreePrdList, gsPrdInfo.usFreePrdList.u16Head, u16NowPrdInfoIdx);
   *  gsPrdInfo.uTotalPrdTaskCnt--;
   *
   *  return 0;
   * }
   */
/*
   * void insertTaskToReadPrdList(WORD u16PrevPrdIdx, WORD u16NowPrdInfoIdx)
   * {
   *  insertNodeToList(gsPrdInfo.uarPrdLink, &gsPrdInfo.usReadPrdList, u16PrevPrdIdx, u16NowPrdInfoIdx);
   *
   *  if(gsPrdInfo.usReadPrdList.u16Trig==c16Null)
   *  {
   *      gsPrdInfo.usReadPrdList.u16Trig=u16NowPrdInfoIdx;
   *  }
   * }
   */
/*
   * void insertTaskToWritePrdList(WORD u16PrevPrdIdx, WORD u16NowPrdInfoIdx)
   * {
   *  insertNodeToList(gsPrdInfo.uarPrdLink, &gsPrdInfo.usWritePrdList, u16PrevPrdIdx, u16NowPrdInfoIdx);
   *
   *  gsPrdInfo.u32TotalWritePrdListSctrCnt+=gsPrdInfo.uarPrdQue[u16NowPrdInfoIdx].u32SctrCnt;
   *
   *  if(gsPrdInfo.usWritePrdList.u16Trig==c16Null)
   *  {
   *      gsPrdInfo.usWritePrdList.u16Trig=u16NowPrdInfoIdx;
   *  }
   * }
   */
/*
   * void sortRwTaskAndInsertToPrdList(WORD u16NowPrdInfoIdx)
   * {
   *  PRDQUEUE *upPrdInfo;
   *  WORD u16PrevPrdInfoIdx;
   *
   *  upPrdInfo=&gsPrdInfo.uarPrdQue[u16NowPrdInfoIdx];
   *
   *  if(upPrdInfo->uOpCode==cNvmeCmdRead)
   *  {
   *      if(upPrdInfo->u32SctrCnt>cSctrPer4k)
   *      {
   *          u16PrevPrdInfoIdx=gsPrdInfo.usReadPrdList.u16Head;    // insert after last
   *      }
   *      else    // preemptive 4k Read Cmd
   *      {
   *          if(gsPrdInfo.u16ReadPrdList4kPtr!=c16Null)
   *          {
   *              u16PrevPrdInfoIdx=gsPrdInfo.u16ReadPrdList4kPtr;    // insert after last 4k Read Cmd
   *          }
   *          else if(gsPrdInfo.usReadPrdList.u16Trig!=c16Null)
   *          {
   *              u16PrevPrdInfoIdx=gsPrdInfo.uarPrdLink[gsPrdInfo.usReadPrdList.u16Trig].u16Prev;    // insert before trig
   *              gsPrdInfo.usReadPrdList.u16Trig=u16NowPrdInfoIdx;
   *          }
   *          else    // u16Trig==c16Null
   *          {
   *              u16PrevPrdInfoIdx=gsPrdInfo.usReadPrdList.u16Head;    // insert after last
   *          }
   *
   *          gsPrdInfo.u16ReadPrdList4kPtr=u16NowPrdInfoIdx;
   *      }
   *
   *      insertTaskToReadPrdList(u16PrevPrdInfoIdx, u16NowPrdInfoIdx);
   *  }
   *  else  // if (upPrdInfo->uOpCode==cNvmeCmdWrite)
   *  {
   *      u16PrevPrdInfoIdx=gsPrdInfo.usWritePrdList.u16Head;    // alway insert after last
   *
   *      insertTaskToWritePrdList(u16PrevPrdInfoIdx, u16NowPrdInfoIdx);
   *  }
   *
   *  gsPrdInfo.uTotalPrdTaskCnt++;
   * }
   */
/*
   * void releaseSrcAddrInfo(WORD u16NowSrcAddrIdx)
   * {
   * deleteNodeFromList(gsRwCtrl.uarSrcCmdLink, &gsRwCtrl.usSrcCmdList, u16NowSrcAddrIdx);
   * insertNodeToList(gsRwCtrl.uarSrcCmdLink, &gsRwCtrl.usFreeSrcCmdList, gsRwCtrl.usFreeSrcCmdList.u16Head, u16NowSrcAddrIdx);
   * }
   */
/*
   * BYTE getFreeSrcAddrInfo()
   * {
   *  WORD u16NowSrcAddrIdx;
   *
   *  if(gsRwCtrl.usFreeSrcCmdList.u16Cnt==0)
   *  {
   *      while(1)
   *          ;
   *  }
   *
   *  u16NowSrcAddrIdx=gsRwCtrl.usFreeSrcCmdList.u16Tail;
   *  deleteNodeFromList(gsRwCtrl.uarSrcCmdLink, &gsRwCtrl.usFreeSrcCmdList, u16NowSrcAddrIdx);
   *
   *  return u16NowSrcAddrIdx;
   * }
   */
/*
   * void insertTaskToSrcAddrInfo(WORD u16NowSrcAddrIdx)
   * {
   *  if(gsRwCtrl.usSrcCmdList.u16Cnt>=cReadFifoDpt)
   *  {
   *      while(1)
   *          ;
   *  }
   *
   *  insertNodeToList(gsRwCtrl.uarSrcCmdLink, &gsRwCtrl.usSrcCmdList, gsRwCtrl.usSrcCmdList.u16Head, u16NowSrcAddrIdx);
   *
   *  if(gsRwCtrl.usSrcCmdList.u16Trig==c16Null)
   *  {
   *      gsRwCtrl.usSrcCmdList.u16Trig=u16NowSrcAddrIdx;
   *  }
   * }
   */

void releaseFreeHwPrd2()
{
    BYTE uFreeHwPrdIdx, uPrpListErr, uCurrentEng;
    WORD u16PrdInfoIdx;

    while(rmChkDpsDppFifoNotEmpty)
    {
        uFreeHwPrdIdx=rmCurrentPrd;
        rmClrPrdDoneFlag(uFreeHwPrdIdx);    // clear prd done flag

        u16PrdInfoIdx=gsPrdInfo.u16arIdxToPrdInfo[uFreeHwPrdIdx];

        while(!(u16PrdInfoIdx&c16Bit15))
            ;

        uPrpListErr=rmChkPrpListErr;

        if(uPrpListErr)
        {
            uCurrentEng=rmCurrentEngine;
            rmSetEngineMap(uCurrentEng);

            if((((uPrpListErr&cBit0)&&(uCurrentEng==0))||((uPrpListErr&cBit1)&&(uCurrentEng==1))||(uPrpListErr&cBit2)&&(uCurrentEng==6))&&
               (rmChkEngineMap==uFreeHwPrdIdx))
            {
                manualCompletion(cStatusInvalidPrpOffset, 0, cRwCmd, u16PrdInfoIdx);

                if(uCurrentEng==6)
                {
                    rmClrOnePrpListErr(2);
                }
                else
                {
                    rmClrOnePrpListErr(uCurrentEng);
                }
            }
        }

        gsPrdInfo.uarFreeHwPrdQue[gsPrdInfo.uFreeHwPrdHead]=uFreeHwPrdIdx;
        gsPrdInfo.uFreeHwPrdHead=(gsPrdInfo.uFreeHwPrdHead+1)&(cHwPrdDepth-1);
        gsPrdInfo.uFreeHwPrdCnt++;

        rmPopNextValue;
    }
}    /* releaseFreeHwPrd2 */

#if (!_ICE_LOAD_ALL)
#pragma default_function_attributes =
#endif







