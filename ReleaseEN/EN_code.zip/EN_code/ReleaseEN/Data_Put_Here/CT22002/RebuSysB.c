







// #include "SystemBlockCtl.c"

/*
   *  Bit 6: only read last page
   */

BYTE srchRsvBlockID(BYTE uIdx, BLKSPRINFO *usBlkSprInfo, BYTE uChkPgNum, BYTE uMode)
{
    ADDRINFO usTmpAddrInfo;
    WORD u16Fpage=0, u16LastChkPage;
    BYTE uStatus=0;

    if(uIdx<=garSysBlock[cSysBlock2ndInfo])
    {
        u16Fpage=gBadBlockBitMapStartPage;
    }

    if(uChkPgNum)
    {
        u16LastChkPage=u16Fpage+uChkPgNum;
    }
    else    // 0 is inifinity
    {
        u16LastChkPage=g16PagePerBlock1_SLC;
    }

    if(uMode&cReadLastPage)
    {
        u16Fpage=g16PagePerBlock1_SLC-1;
    }

    while(u16Fpage<u16LastChkPage)
    {
        tranRsvBlkAddr(uIdx, &usTmpAddrInfo);
        usTmpAddrInfo.u16FPage=u16Fpage;
        setFLAddrActCh(usTmpAddrInfo.uCh, &usTmpAddrInfo);
        rstUNCSts1PlaneCore0(gCh, gPlaneAddr);

        gSectorH=0;
        mSetFRwParam(0, 0, c16Bit5|c16Bit10|c16Bit14, cReadData);
        // flashReadPage();
        assignFreeBtSrcAddrInfo();
        waitCmdAllDone(cWaitTrigRCnt|cWaitCmdBz);
        // releaseBtSrcAddrInfo();

        if(!mChkBitMask(gPlaneUNCSts[gCh], gPlaneAddr))
        {
            getSprByte(usBlkSprInfo, gPlaneAddr);
            uStatus=1;
            break;
        }

        u16Fpage++;
    }

    // if(uIdx<=garSysBlock[cSysBlock2ndInfo])
    // {
    // usBlkSprInfo->uBlkId=(BYTE)(usBlkSprInfo->u16Spr0);
    // usBlkSprInfo->u16Spr8.us2BYTE.LowByte= (BYTE)(usBlkSprInfo->u16Spr0.u16all);
    // }
    return uStatus;
}    /* srchRsvBlockID */

LWORD cmprSerial(LWORD u32Serial1, LWORD u32Serial2)
{
    // judge if (serial2>serial1)
    LWORD u32Fa;

    u32Fa=0;

    if((u32Serial2==((u32Serial1+1)&0x0000FFFF))||(u32Serial2>u32Serial1))
    {
        u32Fa=1;
    }

    return u32Fa;
}

void dummyProgRsvBlk(WORD u16LoopIdx)
{
#if 0
    ADDRINFO usTmpAddrInfo;
    BLKSPRINFO usBlkSprInfo;

    srchRsvBlockID(u16LoopIdx, &usBlkSprInfo, 0, cReadLastPage);

    if((!gbSprEccFail)&&(mGetMetaBlockId(usBlkSprInfo)==0xFF)&&(mGetMetaSeed(usBlkSprInfo)==0xFFFF))
    {
        tranRsvBlkAddr(u16LoopIdx, &usTmpAddrInfo);
        setFLAddrActCh(usTmpAddrInfo.uCh, &usTmpAddrInfo);
        flashDummyProgram(c16Bit14);
        // waitCmdFifoDpt(gActiveCh, 0xF0, &usTmpAddrInfo);
        waitChCeBz(gActiveCh, gIntlvAddr, 0);
    }
#endif
}    /* dummyProgRsvBlk */

void initErasedSysSprBlkCore0(BYTE uSysBlkIdx, BYTE uOpt)
{
    gsRwCtrl.usBootErsCmdInfo.uOpt=uOpt;
    gsRwCtrl.usBootErsCmdInfo.uSysBlkIdx=uSysBlkIdx;

    while(gsRwCtrl.usBootErsCmdInfo.uSysBlkIdx!=cInvalid8Bit)
        ;
}

#define _ENTestBuildRoot     0
void rebuildInfoBlk()
{
    // ADDRINFO usTmpAddrInfo;
    // LWORD u32FinishBitFlag;
    WORD u16PageLoop, u16ActHalfKB;
    BYTE uEccFlag, uBkpSectrPerPlnH, uCount;
    BLKSPRINFO *upBlkSprInfo;

    uBkpSectrPerPlnH=gSectorPerPlaneH;

    uEccFlag=1;
    uCount=0;

#if _EN_FW_DEBUG_UART
    NLOG(cLogBuild, REBUSYSB_C, 1, "rebuildInfoBlk Func: 0x%04X", gsRdlinkInfo.ubExistTempInfoBlk);
#endif

    while(uEccFlag)
    {
        uEccFlag=0;

        // use spare-0 as temp Info Block (it must exist)
        if(!gsRdlinkInfo.ubExistTempInfoBlk)
        {
            initErasedSysSprBlkCore0(cSysBlockSpare0, cBit0);

            // copy max Ecc 5 page
            gSectorPerPlaneH-=4;    // 2K
            enEccInMax();

            loadRootPage(0, gSectorPerPlaneH*gNorEccStrPage, c16WriteSIdx, cSysBlock1stInfo, 0, cBit5);

            for(u16ActHalfKB=0; u16ActHalfKB<gNorEccStrPage; u16ActHalfKB++)
            {
                // chunk Address let spare could be read
                upBlkSprInfo=(BLKSPRINFO *)(&garTsb0[c16WriteSIdx][(u16ActHalfKB*0x20)]);
                (upBlkSprInfo->u16Spr8.us2BYTE.LowByte)=cInfoBlockID;
            }

            progRootPage(0, cSysBlockSpare0, gSectorPerPlaneH*gNorEccStrPage, c16WriteSIdx);

            enEccInNormal();
            gSectorPerPlaneH=uBkpSectrPerPlnH;

            // use 256KB buffer to fill it
            for(u16PageLoop=gNorEccStrPage; u16PageLoop<g16PagePerBlock1_SLC; u16PageLoop+=(256/gSectorPerPlaneF))
            {
                if((g16PagePerBlock1_SLC-u16PageLoop)>(256/gSectorPerPlaneF))
                {
                    u16ActHalfKB=256*2;    // 256KB
                }
                else
                {
                    u16ActHalfKB=(g16PagePerBlock1_SLC-u16PageLoop)*gSectorPerPlaneH;
                }

                loadRootPage(u16PageLoop, u16ActHalfKB, c16WriteSIdx, cSysBlock1stInfo, 0, cBit5);
                progRootPage(u16PageLoop, cSysBlockSpare0, u16ActHalfKB, c16WriteSIdx);
            }
        }

        gsRdlinkInfo.ubExistTempInfoBlk=cTrue;

        // check temp Block
        for(u16PageLoop=0; u16PageLoop<g16PagePerBlock1_SLC; u16PageLoop++)
        {
            if(u16PageLoop<gNorEccStrPage)
            {
                enEccInMax();
                uEccFlag=loadInfoPage(u16PageLoop, gSectorPerPlaneH-4, c16WriteSIdx, 0, cSysBlockSpare0, cBit1);
                enEccInNormal();
            }
            else
            {
                uEccFlag=loadInfoPage(u16PageLoop, gSectorPerPlaneH, c16WriteSIdx, 0, cSysBlockSpare0, cBit1);
            }

            if(uEccFlag)
            {
                if((!mChkInjuredAllInfo)&&(uCount<10))
                {
                    gsRdlinkInfo.ubExistTempInfoBlk=cFalse;
                    uCount++;
                    break;
                }
                else
                {
                    debugLoop(cRebuInfoBlk);    // no ok Info Block
                }
            }
        }
    }

    uEccFlag=mChkInjuredInfo;
#if _ENTestBuildRoot
    /**********/
    BYTE uTestFlag;
    uTestFlag=1;
    uEccFlag=1;
    // mSet1stInfoInjured;
    // mSet2ndInfoInjured;
    /**********/
#endif
    uCount=0;

    while(uEccFlag)
    {
        uEccFlag=0;

        if(mChk1stInfoInjured)
        {
            NLOG(cLogBuild, REBUSYSB_C, 0, "initErasedSysSprBlkCore0 Info1");
            initErasedSysSprBlkCore0(cSysBlock1stInfo, cBit0);
            mClr1stInfoInFL;
        }

        if(mChk2ndInfoInjured)
        {
            NLOG(cLogBuild, REBUSYSB_C, 0, "initErasedSysSprBlkCore0 Info2");
            initErasedSysSprBlkCore0(cSysBlock2ndInfo, cBit0);
            mClr2ndInfoInFL;
        }

#if _ENTestBuildRoot
        // test
        if(uTestFlag)
        {
            initErasedSysSprBlkCore0(cSysBlockSpare1, cBit0);
            uTestFlag=0;
        }
#endif
        // copy max Ecc 5 page
        gSectorPerPlaneH-=4;    // 2K
        enEccInMax();

        loadRootPage(0, gSectorPerPlaneH*gNorEccStrPage, c16WriteSIdx, cSysBlockSpare0, 0, cBit4|cBit5);
#if _ENTestBuildRoot
        progRootPage(0, cSysBlockSpare1, gSectorPerPlaneH*gNorEccStrPage, c16WriteSIdx);
#endif

        if(mChk1stInfoInjured)
        {
            progRootPage(0, cSysBlock1stInfo, gSectorPerPlaneH*gNorEccStrPage, c16WriteSIdx);
        }

        if(mChk2ndInfoInjured)
        {
            progRootPage(0, cSysBlock2ndInfo, gSectorPerPlaneH*gNorEccStrPage, c16WriteSIdx);
        }

        enEccInNormal();
        gSectorPerPlaneH=uBkpSectrPerPlnH;

        // use 256KB buffer to fill it
        for(u16PageLoop=gNorEccStrPage; u16PageLoop<g16PagePerBlock1_SLC; u16PageLoop+=(256/gSectorPerPlaneF))
        {
            if((g16PagePerBlock1_SLC-u16PageLoop)>(256/gSectorPerPlaneF))
            {
                u16ActHalfKB=256*2;    // 256KB
            }
            else
            {
                u16ActHalfKB=(g16PagePerBlock1_SLC-u16PageLoop)*gSectorPerPlaneH;
            }

            loadRootPage(u16PageLoop, u16ActHalfKB, c16WriteSIdx, cSysBlockSpare0, 0, cBit4|cBit5);
#if _ENTestBuildRoot
            progRootPage(u16PageLoop, cSysBlockSpare1, u16ActHalfKB, c16WriteSIdx);
#endif

            if(mChk1stInfoInjured)
            {
                progRootPage(u16PageLoop, cSysBlock1stInfo, u16ActHalfKB, c16WriteSIdx);
            }

            if(mChk2ndInfoInjured)
            {
                progRootPage(u16PageLoop, cSysBlock2ndInfo, u16ActHalfKB, c16WriteSIdx);
            }
        }

#if _ENTestBuildRoot
        // check copyed Block
        for(u16PageLoop=0; u16PageLoop<g16PagePerBlock1_SLC; u16PageLoop++)
        {
            if(u16PageLoop<gNorEccStrPage)
            {
                enEccInMax();
                uEccFlag=loadInfoPage(u16PageLoop, gSectorPerPlaneH-4, c16WriteSIdx, 0, cSysBlockSpare1, cBit1);
                enEccInNormal();
            }
            else
            {
                uEccFlag=loadInfoPage(u16PageLoop, gSectorPerPlaneH, c16WriteSIdx, 0, cSysBlockSpare1, cBit1);
            }

            if(uEccFlag)
            {
                break;
            }
        }
#endif/* if _ENTestBuildRoot */

        // 1st Root check all
        // if(mChk1stInfoInjured)
        {
            mSet1stInfoInFL;

            for(u16PageLoop=0; u16PageLoop<g16PagePerBlock1_SLC; u16PageLoop++)
            {
                if(u16PageLoop<gNorEccStrPage)
                {
                    enEccInMax();
                    uEccFlag=loadInfoPage(u16PageLoop, gSectorPerPlaneH-4, c16WriteSIdx, 0, cSysBlock1stInfo, cBit1);
                    enEccInNormal();
                }
                else
                {
                    uEccFlag=loadInfoPage(u16PageLoop, gSectorPerPlaneH, c16WriteSIdx, 0, cSysBlock1stInfo, cBit1);
                }

                if(uEccFlag)
                {
                    mClr1stInfoInFL;
                    break;
                }
            }

            if(mChk1stInfoInFL)
            {
                mClr1stInfoInjured;
            }
        }

        // 2nd Root check all
        // if(mChk2ndInfoInjured)
        {
            mSet2ndInfoInFL;

            for(u16PageLoop=0; u16PageLoop<g16PagePerBlock1_SLC; u16PageLoop++)
            {
                if(u16PageLoop<gNorEccStrPage)
                {
                    enEccInMax();
                    uEccFlag=loadInfoPage(u16PageLoop, gSectorPerPlaneH-4, c16WriteSIdx, 0, cSysBlock2ndInfo, cBit1);
                    enEccInNormal();
                }
                else
                {
                    uEccFlag=loadInfoPage(u16PageLoop, gSectorPerPlaneH, c16WriteSIdx, 0, cSysBlock2ndInfo, cBit1);
                }

                if(uEccFlag)
                {
                    mClr2ndInfoInFL;
                    break;
                }
            }

            if(mChk2ndInfoInFL)
            {
                mClr2ndInfoInjured;
            }
        }

        // do again ?
        uEccFlag=mChkInjuredInfo;
        uCount++;

        if((uCount>10)&&(mChkInjuredAllInfo))
        {
            debugLoop(cRebuInfoBlk);
        }
    }

    if(mChkAllInfoInFL&&gsRdlinkInfo.ubExistTempInfoBlk)
    {
        initErasedSysSprBlkCore0(cSysBlockSpare0, cBit0);
        // Dummy program
        bopClrRam(c32Tsb0SAddr, 0x40000, 0x55AA55AA, cClrTsb|cBopWait);    // clear 256K

        for(u16PageLoop=0; u16PageLoop<g16PagePerBlock1_SLC; u16PageLoop+=(256/gSectorPerPlaneF))
        {
            if((g16PagePerBlock1_SLC-u16PageLoop)>(256/gSectorPerPlaneF))
            {
                u16ActHalfKB=256*2;    // 256KB
            }
            else
            {
                u16ActHalfKB=(g16PagePerBlock1_SLC-u16PageLoop)*gSectorPerPlaneH;
            }

            progRootPage(u16PageLoop, cSysBlockSpare0, u16ActHalfKB, c16WriteSIdx);
        }
    }

    gsRwCtrl.u32UpdFifoPtr=gsRwCtrl.u32ProgFifoTail;
}    /* rebuildInfoBlk */

void rebuildMPInfoBlk()
{
    // ADDRINFO usTmpAddrInfo;
    // LWORD u32FinishBitFlag;
    WORD u16PageLoop, u16ActHalfKB;
    BYTE uEccFlag;    // , uBkpSectrPerPlnH;

    // uBkpSectrPerPlnH=gSectorPerPlaneH;

    uEccFlag=1;

    while(uEccFlag)
    {
        uEccFlag=0;
        // use spare-0 as temp Root Block (it must exist)
        initErasedSysSprBlkCore0(cSysBlockSpare0, cBit0);

        // copy 256KB (for SPOR)
        loadRootPage(0, 256*2, c16WriteSIdx, cSysBlockMPInfo, 0, cBit4|cBit5);
        progRootPage(0, cSysBlockSpare0, 256*2, c16WriteSIdx);

        // use 256KB buffer to fill it
        initErasedSysSprBlkCore0(cSysBlockMPInfo, cBit0);

        for(u16PageLoop=0; u16PageLoop<g16PagePerBlock1_SLC; u16PageLoop+=(256/gSectorPerPlaneF))
        {
            if((g16PagePerBlock1_SLC-u16PageLoop)>(256/gSectorPerPlaneF))
            {
                u16ActHalfKB=256*2;    // 256KB
            }
            else
            {
                u16ActHalfKB=(g16PagePerBlock1_SLC-u16PageLoop)*gSectorPerPlaneH;
            }

            progRootPage(u16PageLoop, cSysBlockMPInfo, u16ActHalfKB, c16WriteSIdx);
        }

        // check temp Block
        for(u16PageLoop=0; u16PageLoop<g16PagePerBlock1_SLC; u16PageLoop++)
        {
            uEccFlag=loadInfoPage(u16PageLoop, gSectorPerPlaneH, c16WriteSIdx, 0, cSysBlockMPInfo, cBit1);

            if(uEccFlag)
            {
                break;
            }
        }
    }
}    /* rebuildMPInfoBlk */

void rebuSysBlk()
{
#if (!_WO_INFOB)
    BYTE uCurrentSetBit;    // , uMaxSerial= 0;//, uInfoCnt= 0, uISPCnt= 0;
    // BYTE *uSerialPtr;
    // LWORD *u32SerialPtr;
    BLKSPRINFO usBlkSprInfo;
    // ADDRINFO usTmpAddrInfo;
    // BYTE uTempChkSprAvaiBit;
    BYTE uLoopIdx;

    // WORD u16LoopIdx= 0;

    ctrlOnesCntStop(0);

// build system block infomation
    for(uLoopIdx=cSysBlock1stInfo; uLoopIdx<(cSysBlockSpare1+1); uLoopIdx++)    // assign sys block
    {
        if(garSysBlock[uLoopIdx]==cInvalid8Bit)
        {
            continue;
        }

        uCurrentSetBit=0xFF;

        if(srchRsvBlockID(garSysBlock[uLoopIdx], &usBlkSprInfo, 3, 0))
        {
            // if (uLoopIdx<=cSysBlock2ndInfo)
            // {
            // uCurrentSetBit=mGetMetaBlockId(usBlkSprInfo);
            // }
            // else
            // {
            // uCurrentSetBit=mGetMetaWord0(usBlkSprInfo);
            // }
            uCurrentSetBit=mGetMetaBlockId(usBlkSprInfo);

            switch(uCurrentSetBit)
            {
                case cInfoBlockID:

                    g16arCurrSysBlkEsCnt[uLoopIdx]=mGetMetaEraseCnt(usBlkSprInfo);
                    break;

                case cMPInfoBlockID:
                    g16arCurrSysBlkEsCnt[uLoopIdx]=mGetMetaEraseCnt(usBlkSprInfo);
                    // u32SerialPtr= &gsMPInfo.u32MPInfoSerial;
                    break;

                case cIndexBlockID:
                    g16arCurrSysBlkEsCnt[uLoopIdx]=mGetMetaEraseCnt(usBlkSprInfo);
                    // u32SerialPtr= &g32IndexBlkSerial;
                    break;

                case 0xFF:
                    dummyProgRsvBlk(uLoopIdx);
                    break;

                default:
                    break;
            }    /* switch */
        }
        else
        {
            dummyProgRsvBlk(uLoopIdx);
        }

        if(uCurrentSetBit!=cInvalid8Bit)
        {
            gsRdlinkInfo.u16arSysBlockEraseCnt[uLoopIdx]=mGetMetaEraseCnt(usBlkSprInfo);
            gsRdlinkInfo.u32arPwrOnSysBlockSerial[uLoopIdx]=mGetMetaSysBlkSn(usBlkSprInfo);
        }
        else
        {
            gsRdlinkInfo.u16arSysBlockEraseCnt[uLoopIdx]=0;
            gsRdlinkInfo.u32arPwrOnSysBlockSerial[uLoopIdx]=0;
        }
    }

    ctrlOnesCntStop(cBit0|cBit1);

    // re-build error block
    if(mChkInjuredInfo)
    {
        NLOG(cLogBuild, REBUSYSB_C, 0, "rebuildInfoBlk");
        rebuildInfoBlk();
    }
    else
    {
        gsRdlinkInfo.ubExistTempInfoBlk=0;
    }

    /**debug**/
    // mSetMPInfoInjured;
    /****/
    if(mChkMPInfoInjured)
    {
        rebuildMPInfoBlk();
    }
#endif/* if !_WO_INFOB */
}    /* rebuSysBlk */

void chkBadInfo()
{
    WORD u16FBlock;

    readWproPageCore0(cWproBadInfo, c16Tsb0SIdx, 0);

    gsRdlinkInfo.u16BadInfoWproBlock=gsWproInfo.u16arWproBlk[gsWproInfo.uarWproIdxPtr[cWproBadInfo]];
    gsRdlinkInfo.u16BadInfoWproPagePtr=gsWproInfo.u16arWproIdxPagePtr[cWproBadInfo];

    gsBadInfo.u16TotalNewBadCnt=g16arBadInfoBuf[cMarkBadCntOfst];
    gsBadInfo.u16ProgFailFblkCnt=g16arBadInfoBuf[1];    // 20181213_KevinGG_01
    gsBadInfo.u16EraseFailFblkCnt=g16arBadInfoBuf[2];    // 20181213_KevinGG_01
    gsBadInfo.u16NewBadInBufPtr=g16arBadInfoBuf[cMarkBadBufOfst];

    for(u16FBlock=g16FirstFBlock; u16FBlock<g16TotalFBlock; u16FBlock++)
    {
        if(mChkBadBitTab(u16FBlock))
        {
            mSetPoppedBitRL(u16FBlock);
            mSetGlobEraseCntRL(u16FBlock, c16BitFF);
            setGlobEraseCnt1Blk(u16FBlock, g16arTempGlobEraseCnt[u16FBlock], 1);
        }
    }
}    /* chkBadInfo */

/******/
// Mode :
// ==0   : find Last Page
// cBit0 : Get MPinfo Page
/******/
WORD getSysInfoPagePtr(BYTE uSysBlkAddr, WORD u16BlkId, BYTE uMode, BLKSPRINFO *upBlkSprInfo)
{
    ADDRINFO usTmpAddrInfo;
    BLKSPRINFO usBlkSprInfo;
    BYTE uExitFlag;
    BYTE uMtPageCnt=0;
    WORD u16Fpage=0;
    WORD u16LastFreePagePtr=0;
    WORD u16MPInfoPagePtr=0;

    // setSprOnesCntCondition(cDisSprOnesCntSetting);
    ctrlOnesCntStop(0);

    tranRsvBlkAddr(uSysBlkAddr, &usTmpAddrInfo);
    setFLAddrActCh(usTmpAddrInfo.uCh, &usTmpAddrInfo);
    gsRdlinkInfo.ubPageWithErr=0;
    uExitFlag=0;

    while(u16Fpage<g16PagePerBlock1_SLC)
    {
        g16FPage=u16Fpage;
        rstUNCSts1PlaneCore0(gCh, gPlaneAddr);

        mSetFRwParam(c16Tsb0SIdx, 0, c16Bit5|c16Bit10|c16Bit14, cReadData);
        gSectorH=0;

        // flashReadPage();
        assignFreeBtSrcAddrInfo();

        waitCmdAllDone(cWaitTrigRCnt|cWaitCmdBz);
        releaseBtSrcAddrInfo();

        if(!uExitFlag)
        {
            if(!mChkBitMask(gPlaneUNCSts[gCh], gPlaneAddr))
            {
                getSprByte(&usBlkSprInfo, gPlaneAddr);

                if(mGetMetaBlockId(usBlkSprInfo)==0xFF)
                {
                    uMtPageCnt++;
                }
                else
                {
                    u16LastFreePagePtr+=(uMtPageCnt+1);

                    if(uMode&cBit0)
                    {
                        if(mGetMetaBlockId(usBlkSprInfo)==u16BlkId)
                        {
                            copyCcmVal((BYTE *)upBlkSprInfo, (BYTE *)&usBlkSprInfo, sizeof(usBlkSprInfo));

                            if(mGetMetaWord0(usBlkSprInfo)==cMPInfo)
                            {
                                // Signature OK
                                u16MPInfoPagePtr=u16Fpage;
                                u16Fpage=g16PagePerBlock1_SLC;
                            }
                        }
                        else
                        {
                            u16MPInfoPagePtr=0xFFFF;
                            break;
                        }
                    }

                    uMtPageCnt=0;
                }
            }
            else
            {
                u16LastFreePagePtr+=(uMtPageCnt+1);
                uMtPageCnt=0;
                gsRdlinkInfo.ubPageWithErr=1;
            }

            if(uMtPageCnt>=cMaxSlcMtPageCnt)
            {
                uExitFlag=1;
                u16Fpage=g16PagePerBlock1_SLC;
            }
        }

        u16Fpage++;
    }

    // setSprOnesCntCondition(cEnSprOnesCntSetting);
    ctrlOnesCntStop(3);

    // return u16LastFreePagePtr;
    if(uMode&cBit0)
    {
        return u16MPInfoPagePtr;
    }
    else
    {
        return u16LastFreePagePtr;
    }
}    /* getSysInfoPagePtr */

void chkMPInfo()
{
    BLKSPRINFO usBlkSprInfo;

    // find last page
    if(mChkMPInfoInFL)
    {
        // modify chkMPInfo(), do not need check free page ptr.
        // gsMPInfo.u16MPInfoPageFreePtr=getSysInfoPagePtr(garSysBlock[cSysBlockMPInfo], cMPInfoBlockID, 0, &usBlkSprInfo);
        gsMPInfo.u16MPInfoPageFreePtr=g16PagePerBlock1_SLC;
        gsMPInfo.u16MPInfoPage=getSysInfoPagePtr(garSysBlock[cSysBlockMPInfo], cMPInfoBlockID, cBit0, &usBlkSprInfo);

        if(gsMPInfo.u16MPInfoPageFreePtr<g16PagePerBlock1_SLC)
        {
            mClrCacheInfoFlag(cMPInfoBlockFull);
        }
        else
        {
            mSetCacheInfoFlag(cMPInfoBlockFull);
        }
    }
}    /* chkMPInfo */







