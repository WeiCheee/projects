







#include "inc/EventLogIDX.h"
#include "inc/EventLogFunctionIDX.h"

void funcTskProgFwDlTempIspBlock(BYTE uTskTail)
{
    LWORD u32PagePtr=0;
    WORD u16BufPtr=gsTskFifoCtrl.uarTskFifo[uTskTail].u16TskSBufPtr;

    if(!mChkFidUnderProcess    /*(gsFwDlInfo.uFidStatus&cFidUnderProcess)*/)
    {
        gsFwDlInfo.uSysRsvFwDlImageBlk=cSysBlockSpare0;
        initErasedSysSprBlk(gsFwDlInfo.uSysRsvFwDlImageBlk, cBit0);

        rmWaitSysCmdFifoBz;    // add mark if erase fail

        // mSetSeedOfst(usTmpAddrInfo.u16FBlock, 0);
        progCacheInfoTab();

        // copy max Ecc 0~(gNorEccStrPage-1)
        enEccInMax();

        while(u32PagePtr<gNorEccStrPage)
        {
            loadInfoPage(u32PagePtr, (gSectorPerPlaneH-4), c16Tsb0SIdx, 0, cSysBlock1stInfo, cBit1);
            progFwDlImageBlk(u32PagePtr, c16Tsb0SIdx);
            u32PagePtr++;
        }

        enEccInNormal();

        while(u32PagePtr<gISPCore1StartPage)
        {
            loadInfoPage(u32PagePtr, gSectorPerPlaneH, c16Tsb0SIdx, 0, cSysBlock1stInfo, cBit1);
            progFwDlImageBlk(u32PagePtr, c16Tsb0SIdx);
            u32PagePtr++;
        }

        gsFwDlInfo.u16FidFreePagePtr=gISPCore1StartPage;
        mSetFidUnderProcess;
    }
    else
    {
        if(gsFwDlInfo.u16FidFreePagePtr<(gISPCore1StartPage+cTotalPlaneOfIsp))
        {
            gsFwDlInfo.u32ChkSum+=getChkSumofFwImageDl(u16BufPtr);    // total check sum
            progFwDlImageBlk(gsFwDlInfo.u16FidFreePagePtr, u16BufPtr);
            gsFwDlInfo.u16FidFreePagePtr++;
        }
        else    // Program to the end
        {
            u32PagePtr=gsFwDlInfo.u16FidFreePagePtr;

            while(u32PagePtr<g16PagePerBlock1_SLC)
            {
                loadInfoPage(u32PagePtr, gSectorPerPlaneH, c16Tsb0SIdx, 0, cSysBlock1stInfo, cBit1);
                progFwDlImageBlk(u32PagePtr, c16Tsb0SIdx);
                u32PagePtr++;
            }
        }
    }
}    /* funcTskProgFwDlTempIspBlock */

void funcTskActivateIsp(BYTE uTskTail)
{
    BYTE uTryCnt, uEccFail, uDesRsvBlk;

    for(uDesRsvBlk=cSysBlock1stInfo; uDesRsvBlk<=cSysBlock2ndInfo; uDesRsvBlk++)
    {
        uEccFail=1;
        uTryCnt=6;

        while(uEccFail&&uTryCnt)
        {
            // if(uTryCnt>=3)
            {
                swapIspBlock(uDesRsvBlk);
            }
            // else
            // {
            // swapIspBlock(uDesRsvBlk, 0);
            // }

            uEccFail=confirmIspBlock(uDesRsvBlk);
            uTryCnt--;
        }

        if(uTryCnt==0)
        {
            mSetActivateFail;
            break;
        }
        else
        {
            mSetSelInfoInFL(uDesRsvBlk);
        }
    }

    if(!mChkActivateFail)
    {
        initErasedSysSprBlk(gsFwDlInfo.uSysRsvFwDlImageBlk, cBit0);
    }
}    /* activateIsp */

void funcTskJudgeSwapIsp(BYTE uTskTail)
{
    judgeSwapIsp();
}    /* judgeSwapISP */

void funcTskChkIspBlock(BYTE uTskTail)
{
    BYTE uIspLoop;

    for(uIspLoop=cSysBlock1stInfo; uIspLoop<(cSysBlock1stInfo+cRsvInfoIspBlkNum); uIspLoop++)
    {
        if(confirmIspBlock(uIspLoop))
        {
            if(mChkSelInfoInFL(uIspLoop))
            {
                mClrSelInfoInFL(uIspLoop);
            }
        }
    }
}

void funcTskLoadIspPage(BYTE uTskTail)
{
    WORD u16PagePtr=gsTskFifoCtrl.uarTskFifo[uTskTail].u16TskSBufPtr;
    BYTE uType=gsTskFifoCtrl.uarTskFifo[uTskTail].uTskOpt;

    gsTskFifoCtrl.uarTskFifo[uTskTail].uTskPgOfst=loadInfoPage(u16PagePtr, gSectorPerPlaneH, c16Tsb0SIdx, 0, uType, 0);
}

void funcTskSwapFwSlotIsp(BYTE uTskTail)
{
    BLKSPRINFO usBlkSprInfo;
    LWORD u32IspPageSize=div(cTotalIspCodeSize, gSectorPerPlaneH);
    WORD u16SouPagePtr, u16DesPagePtr;
    BYTE uSource, uFwSlot=gsTskFifoCtrl.uarTskFifo[uTskTail].uTskOpt, uFwslotMax;

    if(uFwSlot&&(uFwSlot<=cFwSlotMaxNum))
    {
        if(uFwSlot!=1)
        {
            uSource=cSysBlockIsp;
            u16SouPagePtr=0;
        }
    }
    else
    {
        return;
    }

    initErasedSysSprBlk(cSysBlockSpare1, cBit0);

    if(g16PagePerBlock1_SLC<(cFwSlotMaxNum*u32IspPageSize))
    {
        uFwslotMax=mod(g16PagePerBlock1_SLC, u32IspPageSize);
    }
    else
    {
        uFwslotMax=cFwSlotMaxNum;
    }

    for(u16DesPagePtr=0; u16DesPagePtr<(uFwslotMax*u32IspPageSize); u16DesPagePtr++)
    {
        if(u16DesPagePtr==((uFwSlot-1)*u32IspPageSize))
        {
            uSource=gsFwDlInfo.uSysRsvFwDlImageBlk;
            u16SouPagePtr=gISPCore1StartPage;
        }
        else if(u16DesPagePtr==(uFwSlot*div(cTotalIspCodeSize, gSectorPerPlaneH)))
        {
            uSource=cSysBlockIsp;
            u16SouPagePtr=u16DesPagePtr;
        }

        if(!readIspBlock(u16SouPagePtr, uSource, &usBlkSprInfo))
        {
#if _ENABLE_E2E_TAB
            genInternalDataCrc(c16Tsb0SIdx, gSectorPerPlaneH, u16DesPagePtr*gSectorPerPlaneH, cE2eInfoBlk);
#endif
            progSysBlk(u16DesPagePtr, c16Tsb0SIdx, gSectorPerPlaneH, cSysBlockSpare1);
        }
        else
        {
            break;
        }

        u16SouPagePtr++;
    }

    bopClrRam((LWORD)(BYTE *)&g32arTsb0[0], (gSectorPerPlaneH*cSectorSize), 0xFFFFFFFF, cBopWait|cClrTsb);

    while(u16DesPagePtr<g16PagePerBlock1_SLC)
    {
#if _ENABLE_E2E_TAB
        genInternalDataCrc(c16Tsb0SIdx, gSectorPerPlaneH, u16DesPagePtr*gSectorPerPlaneH, cE2eInfoBlk);
#endif
        progSysBlk(u16DesPagePtr, c16Tsb0SIdx, gSectorPerPlaneH, cSysBlockSpare1);
        u16DesPagePtr++;
    }

    u16SouPagePtr=0;

    if(!confirmIspBlock(cSysBlockSpare1))
    {
        initErasedSysSprBlk(cSysBlockIsp, cBit0);

        while(u16SouPagePtr<g16PagePerBlock1_SLC)
        {
            readIspBlock(u16SouPagePtr, cSysBlockSpare1, &usBlkSprInfo);
            progSysBlk(u16SouPagePtr, c16Tsb0SIdx, gSectorPerPlaneH, cSysBlockIsp);
            u16SouPagePtr++;
        }
    }
}    /* funcTskSwapFwSlotIsp */

void progIspBlock(WORD u16PagePtr, BYTE uIndex, BLKSPRINFO *upBlkSprInfo)
{
    ADDRINFO usTmpAddrInfo;
    BYTE uSectorPerPlaneH=gSectorPerPlaneH;

    if(u16PagePtr<gNorEccStrPage)
    {
        enEccInMax();
        uSectorPerPlaneH-=4;
    }

    bopClrRam((LWORD)(BYTE *)&usTmpAddrInfo, sizeof(ADDRINFO), 0x00000000, cClrCore1Dccm|cBopWait);
    tranRsvBlkAddr(garSysBlock[uIndex], &usTmpAddrInfo);
    // tranCeNum(&usTmpAddrInfo);
    usTmpAddrInfo.uSectorH=0;
    usTmpAddrInfo.u16FPage=u16PagePtr;

    setFLAddrActCh(usTmpAddrInfo.uCh, &usTmpAddrInfo);
    mSetTabSpr(gpFlashAddrInfo, cBit5);    // gTabSpare=1;
    mSetFRwParam(c16Tsb0SIdx, uSectorPerPlaneH, c16Bit2|c16Bit4|c16Bit14|c16Bit15, cProgData);
    waitCmdFifoDpt(usTmpAddrInfo.uCh, &usTmpAddrInfo);
    setSprByteOfIspBlk(upBlkSprInfo, g16arCurrSysBlkEsCnt[uIndex], usTmpAddrInfo.uPlaneAddr);
    waitChCeBz(usTmpAddrInfo.uCh, gIntlvAddr, cNoOp);
    flashProgPage(c16Tsb0SIdx, usTmpAddrInfo.uRwHalfKb, usTmpAddrInfo.u16RwOpt);
    setBzInfo(cProgData, gActiveCh, gIntlvAddr);
    gsRwCtrl.usWaitInfo[gActiveCh][gIntlvAddr].uStatusErrStop=0;

    waitAllChCeBz();

    if(u16PagePtr<gNorEccStrPage)
    {
        enEccInNormal();
    }
}    /* progIspBlock */

/******/
// uType bit0---Downlaod Mirco code
/******/
void swapIspBlock(BYTE uDesIndex)
{
    BLKSPRINFO usBlkSprInfo;
    WORD u16PagePtr;
    BYTE uEccFail;

    if(judgeSwapIsp())
    {
        initErasedSysSprBlk(uDesIndex, cBit0);
        NLOG(cLogTempDebug, FWCOMMITDLCORE1_C, 0, " progIspBlock Start ");

        // u16PageNumber=(div(cTotalIspCodeSize, gSectorPerPlaneH)+gISPCore1StartPage);    // getTotalPlaneOfIsp();

        for(u16PagePtr=0; u16PagePtr<g16PagePerBlock1_SLC; u16PagePtr++)
        {
            uEccFail=readIspBlock(u16PagePtr, gsFwDlInfo.uSysRsvFwDlImageBlk, &usBlkSprInfo);

            if(!uEccFail)
            {
                progIspBlock(u16PagePtr, uDesIndex, &usBlkSprInfo);    // (ptr, which isp ,channel)
                // sysDelay(0xFFFF);
            }
            else
            {
                break;
            }

            if((u16PagePtr%10)==0)
            {
                NLOG(cLogTempDebug, FWCOMMITDLCORE1_C, 1, " Page=0x%04X ", (WORD)u16PagePtr);
            }
        }

        NLOG(cLogTempDebug, FWCOMMITDLCORE1_C, 0, " progIspBlock End ");

        waitAllChCeBz();
    }
}    /* swapIspBlock */

BYTE confirmIspBlock(BYTE uIndex)
{
    BLKSPRINFO usBlkSprInfo;
    WORD u16Fpage=0;

    while(u16Fpage<g16PagePerBlock1_SLC)
    {
        if(readIspBlock(u16Fpage, uIndex, &usBlkSprInfo))
        {
            return cReadIspFail;
        }

        u16Fpage++;
    }

    return cReadIspSuccess;
}    /* confirmIspBlock */

void progSysBlk(WORD u16PagePtr, WORD u16BufPtr, BYTE uLength, BYTE uBlkIdx)
{
    ADDRINFO usTmpAddrInfo;

    bopClrRam((LWORD)(BYTE *)&usTmpAddrInfo, sizeof(ADDRINFO), 0x00000000, cClrCore1Dccm|cBopWait);
    tranRsvBlkAddr(garSysBlock[uBlkIdx], &usTmpAddrInfo);

    usTmpAddrInfo.uSectorH=0;
    usTmpAddrInfo.u16FPage=u16PagePtr;

    // tranCeNum(&usTmpAddrInfo);
    setFLAddrActCh(usTmpAddrInfo.uCh, &usTmpAddrInfo);
    mSetTabSpr(gpFlashAddrInfo, cBit5);    // gTabSpare=1;
    mSetFRwParam(u16BufPtr, uLength, c16Bit2|c16Bit4|c16Bit14|c16Bit15, cProgData);    // ptr,length, opt,typ
    waitCmdFifoDpt(gActiveCh, &usTmpAddrInfo);

    if(uBlkIdx==gsFwDlInfo.uSysRsvFwDlImageBlk)
    {
        setSprByteOfSysBlk(u16PagePtr, usTmpAddrInfo.uPlaneAddr, cFwDlDesBlockID);
    }
    else if(uBlkIdx==cSysBlockIsp)
    {
        setSprByteOfSysBlk(u16PagePtr, usTmpAddrInfo.uPlaneAddr, cIspBlockID);
    }
    else
    {
        setSprByteOfSysBlk(u16PagePtr, usTmpAddrInfo.uPlaneAddr, cTmpBlockID);
    }

    waitChCeBz(gActiveCh, gIntlvAddr, cNoOp);
    flashProgPage(u16BufPtr, usTmpAddrInfo.uRwHalfKb, usTmpAddrInfo.u16RwOpt);
    setBzInfo(gOpTyp, gActiveCh, gIntlvAddr);
    gsRwCtrl.usWaitInfo[gActiveCh][gIntlvAddr].uStatusErrStop=0;

    waitAllChCeBz();
    // sysDelay(0xFFFF);
}    /* progSysBlk */

void progFwDlImageBlk(WORD u16PagePtr, WORD u16BufPtr)
{
    BYTE uSectorPerPlaneH=gSectorPerPlaneH;

    if(u16PagePtr<gNorEccStrPage)
    {
        uSectorPerPlaneH-=4;
    }

#if _ENABLE_E2E_TAB
    if(rmChkGlobalCrc)
    {
        genInternalDataCrc(u16BufPtr, gSectorPerPlaneH, u16PagePtr*gSectorPerPlaneH, cE2eInfoBlk);
    }
#endif

    progSysBlk(u16PagePtr, u16BufPtr, uSectorPerPlaneH, gsFwDlInfo.uSysRsvFwDlImageBlk);
}    /* progFwDlImageBlk */

BYTE judgeSwapIsp()
{
    BLKSPRINFO usBlkSprInfo;

    if(!readIspBlock((g16PagePerBlock1_SLC-1), gsFwDlInfo.uSysRsvFwDlImageBlk, &usBlkSprInfo))
    {
        mSetJudgeSwapIsp;
        return cTrue;
    }

    return cFalse;
}

LWORD getChkSumofFwImageDl(WORD u16Ptr1)
{
    BYTE uLoop1;
    BYTE uLoop2;
    LWORD u32ChkSum=0;

    for(uLoop1=0; uLoop1<gSectorPerPlaneH; uLoop1++)
    {
        for(uLoop2=0; uLoop2<(512/4); uLoop2++)
        {
            u32ChkSum+=g32arTsb0[u16Ptr1+uLoop1][uLoop2];
        }
    }

    return u32ChkSum;
}







