







// use for setting injured info and save in index block
void setInjuredInfo(BYTE uWhichInfo, BYTE uOpt)
{
    if((uWhichInfo==cSysBlock1stInfo)&&(!mChk1stInfoInjured)&&(!(uOpt&cBit6)))
    {
        mSet1stInfoInjured;
        gbUpdIdxF=cTrue;
    }

    if((uWhichInfo==cSysBlock2ndInfo)&&(!mChk2ndInfoInjured)&&(!(uOpt&cBit6)))
    {
        mSet2ndInfoInjured;
        gbUpdIdxF=cTrue;
    }
}

//
// opt
// cBit1=1 - only read 1 system block
// cBit6=1 - for rebuild flow checking
//
// cBit2 : Bypass E2E check
#if ((_CPUID==1)||(_PRJ_BOOT==1)||(_PRJ_SMIVU==1))
BYTE loadInfoPage(WORD u16Fpage, BYTE uHalfKB, WORD u16BufIdx, BYTE uSectorH, BYTE uWhichInfo, BYTE uOpt)
{
    ADDRINFO usTmpAddrInfo;
    BYTE uOrgCh, uCopies=0, u1stFoundInfo, uMaxInfoIdx, uSrchAllFlag=0, uEccFail=1;
    BLKSPRINFO usBlkSprInfo;

#if (_CPUID==1)
    BYTE uEnLdpcPipe=gEnableLdpcPipe;
#endif
    uOrgCh=gActiveCh;
    u1stFoundInfo=uWhichInfo;
#if (_CPUID==1)
#if _ENABLE_LDPCPIPELINE
    waitAllChCeBz();

    if(uEnLdpcPipe)
    {
        funcTskDisLdpcPipe(0);
    }
#endif
#endif

#if _ENABLE_E2E_TAB
    gsE2eInfo.uTableType=cE2eInfoBlk;
#endif

    if((uOpt&cBit0)||(uOpt&cBit1))
    {
        uMaxInfoIdx=uWhichInfo;
        uSrchAllFlag=0;
    }
    else if(uWhichInfo==cSysBlock1stInfo)
    {
        uMaxInfoIdx=cSysBlock2ndInfo;
        uSrchAllFlag=1;
    }

    if((uSrchAllFlag==1)&&(mChkAllInfoInFL))
    {
        uCopies=2;
    }
    else if(!(uOpt&cBit1))
    {
        if(mChkBitMask(gSysOption, uWhichInfo))
        {
            uCopies=1;
        }
        else if(uSrchAllFlag&&(mChkBitMask(gSysOption, uWhichInfo+1)))
        {
            u1stFoundInfo=uWhichInfo+1;
            uCopies=1;
            uOpt|=cBit1;
        }
        else
        {
            uCopies=0;
#if (!_PRJ_MPISP)
            while(1)
                ;// finn: give me time to think how to do
#endif
        }
    }
    else
    {
        uCopies=1;
    }

    uWhichInfo=u1stFoundInfo;

#if (!_PRJ_MPISP)
    while(uEccFail&&(uCopies!=0))
#else
    while(uEccFail)
#endif
    {
        tranRsvBlkAddr(garSysBlock[uWhichInfo], &usTmpAddrInfo);
        usTmpAddrInfo.u16FPage=u16Fpage;
        usTmpAddrInfo.uSectorH=uSectorH;
        setFLAddrActCh(usTmpAddrInfo.uCh, &usTmpAddrInfo);

#if (_CPUID==1)
        mClrBitMask(gPlaneUNCSts[gCh], gPlaneAddr);
#else
        rstUNCSts1PlaneCore0(gCh, gPlaneAddr);
#endif

        // tranCeNum(&usTmpAddrInfo);
        mSetFRwParam(u16BufIdx, uHalfKB, (c16Bit4|c16Bit5|c16Bit10|c16Bit13), cReadData);
#if (_CPUID==1)
        waitCmdFifoDpt(gActiveCh, &usTmpAddrInfo);
        waitChCeBz(gActiveCh, gIntlvAddr, 0);
        flashReadPage();
#else
        assignFreeBtSrcAddrInfo();
        waitCmdAllDone(cWaitTrigRCnt|cWaitCmdBz);
        // releaseBtSrcAddrInfo();
#endif

#if _ENABLE_E2E_TAB
        if(!mChkBitMask(gPlaneUNCSts[gCh],
                        gPlaneAddr)&&((!(uOpt&cBit2))&&!chkReadTableCrcCnt(gpFlashAddrInfo)))
#else
        if(!mChkBitMask(gPlaneUNCSts[gCh], gPlaneAddr))
#endif
        {
            getSprByte(&usBlkSprInfo, gPlaneAddr);

            // mSetMetaBlockId(usBlkSprInfo,(BYTE)(usBlkSprInfo.u16Spr0.u16all));
            if(uWhichInfo<=cSysBlock2ndInfo)
            {
                u1stFoundInfo=cInfoBlockID;
            }
            else if(uWhichInfo==cSysBlockIsp)
            {
                u1stFoundInfo=cIspBlockID;
            }
            else if(!(uOpt&cBit1))
            {
                debugDeadLock(0x0002|c16Bit13);    // bug
            }

            if((mGetMetaBlockId(usBlkSprInfo)!=u1stFoundInfo)&&(!(uOpt&cBit1)))    // use as blk-ID
            {
                uEccFail=1;
                setInjuredInfo(uWhichInfo, uOpt);
                NLOG(cLogBuild, FLASHCMDDIR_C, 2, "setInjuredInfo uWhichInfo: 0x%04X, uOpt: 0x%04X", uWhichInfo, uOpt);
            }
            else
            {
                uEccFail=0;
            }
        }
        else
        {
            setInjuredInfo(uWhichInfo, uOpt);
            NLOG(cLogBuild, FLASHCMDDIR_C, 2, "setInjuredInfo uWhichInfo: 0x%04X, uOpt: 0x%04X", uWhichInfo, uOpt);
        }

        if(uEccFail)
        {
            uCopies--;
            uWhichInfo++;

            do
            {
                // count Info or ISP block count
                if(mChkBitMask(gSysOption, uWhichInfo))
                {
                    break;    // exist do-while
                }
                else
                {
                    uWhichInfo++;
                }
            }
            while(uWhichInfo<=uMaxInfoIdx);
        }
    }

#if (_CPUID==1)
#if _ENABLE_LDPCPIPELINE
    waitAllChCeBz();

    if(uEnLdpcPipe)
    {
        funcTskEnLdpcPipe(0);
    }
#endif
#endif

    setFLActCh(uOrgCh);

#if _ENABLE_E2E_TAB
    gsE2eInfo.uTableType=cE2eUserDataBlk;
#endif

    return uEccFail;
}    /* loadInfoPage */

#endif/* if 1 */







