







#include "inc/TypeDef.h"
#include "inc/Option.h"
#include "inc/ProType.h"
#include "inc/Reg.h"
#include "inc/table.h"
#include "inc/GlobVar0.h"
#include "inc/GlobVarS.h"
#include "inc/GlobVarT.h"
#include "inc/Mac.h"
#include "inc/Asm.h"
#include "inc/BitDef.h"
#include "Common/Model.h"

#if (_PRJ_NVME||_PRJ_SMIVU||_PRJ_ISP||_PRJ_BOOT1||_PRJ_BOOT2)
void handleCore0VarErase()
{
#if 0
    // Abort NVMe DST if in Progress
    if(((gsCurrDstResult.uDstStatus>>4)==cOperationShortDstInProgress)||
       ((gsCurrDstResult.uDstStatus>>4)==cOperationExtendedDstInProgress))
    {
        if(!(gsCurrDstResult.uDstStatus&0x0F))
        {
            gsCurrDstResult.uDstStatus|=cOperationAbortFormatNvmeCmd;
        }

        updateNvmeDstData(cReadWpro, cDstLogResultUpdate);
    }
#endif

    // wait core 1 flash action done
    while(gsRwCtrl.u32FreeSrcFifoTail!=gsRwCtrl.u32FreeSrcFifoHead)
        ;

    while(gsRwCtrl.u32UpdFifoPtr!=gsRwCtrl.u32ProgFifoHead)
        ;

    // while(gsHmbInfo.uHmbCache4kCnt)
    //    ;

    while(gsTskFifoCtrl.u32HeadPtr!=gsTskFifoCtrl.u32TailPtr)
        ;

    // Core0 var, temporary reset here
    // fillCcmVal((BYTE *)&gsFwDlInfo, sizeof(gsFwDlInfo), 0x00);
    // gsFwDlInfo.uSysRsvFwDlImageBlk=0xFF;
    bopClrRam((LWORD)g32arSrcInCacheFlag, c16MaxH2fTabNum/8, 0x00000000, cBopWait|cClrCore0Dccm);

    nvmeInitFtlVar();

#if _EN_WUNCTable
    if(gsWUNCInfo.uWuncCnt)
    {
        for(BYTE uIdx=0; uIdx<C_MaxWUNCLAACnt; uIdx++)
        {
            gsWUNCInfo.uWuncCnt=0;
            gsWUNCInfo.u16HBlock[uIdx]=c16BitFF;
            gsWUNCInfo.u16HPage[uIdx]=c16BitFF;
            gsWUNCInfo.uBitMap[uIdx]=0;
        }

#if _EN_WuncInNand
        if(gsWproInfo.u16arWproIdxPagePtr[cWproWriteUNC]!=c16BitFF)
        {
            bopCopyRam(((LWORD)garTsb0[0]), (LWORD)&gsWUNCInfo, sizeof(gsWUNCInfo),
                       cCopyStcm2Tsb|cBopWait);
            progWproPageCore0(cWproWriteUNC, c16Tsb0SIdx);
        }
#endif
    }
#endif/* if _EN_WuncInNand */
}    /* handleCore0VarErase */

void nvmeInitFtlVar()
{
    WORD u16Loop;
    BYTE uLoop;

    // gsCacheInfo.u16SpareBlockCnt=200;
    // gsCacheInfo.u15ActiveH2fTab=c15BitFF;
    // gsCacheInfo.ubPrep=0x00;
    gsCacheInfo.u16ActiveCacheBlock=c16FBlockInitValue;
    mSetCacheInfoFlag(cH2fTabBlockFull);    // gsCacheInfo.ubH2fTabBlockFull=1;

    gsCacheInfo.u32CacheFreePagePtr=c32BitFF;
    gsCacheInfo.u32CacheBlkSerial=c32InitSerialVal;
    gsCacheInfo.u32FluBlkSerial=c32InitSerialVal;
    gsCacheInfo.u32H2fTabBlkSerial=c32InitSerialVal;

    // gsCacheInfo.u16FlushF2hTabPtr=c16BitFF;
    gsCacheInfo.u16FluCacheBlock=c16FBlockInitValue;

    gsCacheInfo.uFlushCacheBlkBank=0;
    gsCacheInfo.u16PrePopCacheBlock=c16FBlockInitValue;

    // gsCacheInfo.u16SpareBlockCnt=200;
    // gsCacheInfo.u15ActiveH2fTab=c15BitFF;
    // gsCacheInfo.ubPrep=0x00;

    g32SectorPerHBlock=(g32H2fTabValidSize/4*cSctrPer4k);    // 16K 4KPages (Table size is 64K, one entry 4 Byte,Total (64K/4) 4Knum)
    gsCacheInfo.u16CacheF2hTabFreePtr=c16CacheF2hSize-1;
    g32MaxCachePageNum=c16CacheF2hSize;
    // g16FakeCmdPtr=0x00;
    // gChgBlock=1;
    mSetCacheInfoFlag(cCacheBlockFull);    // gsCacheInfo.ubCacheBlockFull=1;
    mClrCacheInfoChangeFlag(cH2fChg);    // gsCacheInfo.ubH2fChg=0;

    // continue write
    g32LastLbaW=0xFFFFFFFF;
    // gbSeqAccess=1;
    // gsRwCtrl.u32LastLbaW=0xFFFFFFFF;
    gsRwCtrl.uCacheStartSctr=0;
    gsRwCtrl.uCacheEndSctr=cSctrPer4k;
    gsRwCtrl.u32LastTrimLba=c32BitFF;
    gsRwCtrl.u16OccFSkipSize=0;
    // gsRwCtrl.u32OneShotChPtr=0;
    // gsRwCtrl.u32BkOneShotChPtr=0;

    // gsRwCtrl.usBootErsCmdInfo.uSysBlkIdx=cInvalid8Bit;

    g32LastLbaR=0xFFFFFFFF;
    g16SrchSrcTabFreePtr=0;
    gLastTrigPrdTaskType=0;

    // gsIsrCtrl.u16BufFree4kCnt=c16ReadBufSize4K;    // (384/4)
    gsRwCtrl.uFreeHSgmtCnt=cMaxRH2fTabNum;
    // gsRwCtrl.u16SrchFreeCnt=cSrchSrcNum;
    gsCacheInfo.u16HblkCntInCache=0;
    // REX
    // gsRwCtrl.uMaxFLChFifoDpt=div(c16WriteBufSize, cSctrPer4k*gTotalChNum);
    gsRwCtrl.u16ProgPageOfst=0;

    // Reset H2F1K table [CC]
    rstH2F1KInfo();

    // Reset HMB management
    // bopClrRam((LWORD)&gsHmbInfo, sizeof(gsHmbInfo), 0xFFFFFFFF, cBopWait|cClrStcm);
    // bopClrRam((LWORD)&gsHmbQueInfo, sizeof(gsHmbQueInfo), 0xFFFFFFFF, cBopWait|cClrStcm);
    for(u16Loop=0; u16Loop<g16HmbMaxTableNum; u16Loop++)
    {
        gsHmbInfo.uarHmbLink[u16Loop].u16Prev=u16Loop-1;
        gsHmbInfo.uarHmbLink[u16Loop].u16Next=u16Loop+1;
        gsHmbInfo.u16arFreeHmbQ[u16Loop]=u16Loop;
    }

    gsHmbInfo.uarHmbLink[g16HmbMaxTableNum-1].u16Next=c16Null;
    // gsHmbInfo.uHmbEnable=cFalse;
    gsHmbInfo.usHmbList.u16Cnt=0;
    gsHmbInfo.u16FreeHmbHead=0;
    gsHmbInfo.u16FreeHmbTail=0;
    gsHmbInfo.usHmbList.u16Head=c16Null;
    gsHmbInfo.usHmbList.u16Tail=c16Null;
    gsHmbInfo.usHmbList.u16Trig=c16Null;

    // gReadFlag=0;

    // gsHmbInfo.uHmbHwPrdTail=0;
    gsHmbInfo.uHmbFreeHwPrdCnt=cHmbHwPrdDepth;
#if _ENABLE_HMB_FLUSH
    gsHmbInfo.u16HmbLastDirtyPtr=c16Null;
#endif

    for(uLoop=0; uLoop<cMaxRH2fTabNum; uLoop++)
    {
        gsRwCtrl.uarTab2PrdPtr[uLoop]=cNull;
    }

    for(uLoop=0; uLoop<cPrdDepth; uLoop++)
    {
        gsRwCtrl.uarTabLinkPtr[uLoop]=cNull;
    }

    for(uLoop=0; uLoop<cSrchEnginDepth; uLoop++)
    {
        gsRwCtrl.uarFreeNbsSlot[uLoop]=uLoop;
    }

    gsRwCtrl.uFreeNbsSlotCnt=cSrchEnginDepth;

    // gH2fSgmtRdyHead=0;
    // gH2fSgmtRdyTail=0;
    // gH2fSgmtRdyCnt=0;
    // g64H2f1kTabSgmtPrep=0;
    // gH2f1KPrepCnt=0;

    for(uLoop=0; uLoop<cPrdDepth; uLoop++)
    {
        gsPrdInfo.uarPrdLink[uLoop].uPrev=uLoop-1;
        gsPrdInfo.uarPrdLink[uLoop].uNext=uLoop+1;
        gsPrdInfo.uarFreePrdQue[uLoop]=uLoop;
    }

    // gsPrdInfo.uarPrdLink[0].uPrev=cNull;
    gsPrdInfo.uarPrdLink[cPrdDepth-1].uNext=cNull;

    // gsPrdInfo.usReadPrdList.u16Cnt=0;
    gsPrdInfo.usReadPrdList.u16Head=cNull;
    gsPrdInfo.usReadPrdList.u16Tail=cNull;
    gsPrdInfo.usReadPrdList.u16Trig=cNull;
    gsPrdInfo.u16SeqRd4kRstCnt=c16ReadBufSize4K;
    gsPrdInfo.uSeqRTrigCnt=0;
    // gsPrdInfo.usWritePrdList.u16Cnt=0;
    gsPrdInfo.usWritePrdList.u16Head=cNull;
    gsPrdInfo.usWritePrdList.u16Tail=cNull;
    gsPrdInfo.usWritePrdList.u16Trig=cNull;
    gsPrdInfo.u16TrigHostRestSectCnt=0;
    // gsPrdInfo.u32TotalWritePrdListSctrCnt=0;
#if 0    // _ENABLE_SRC_LINK_LIST // init at core 1
    for(uLoop=0; uLoop<cReadFifoDpt; uLoop++)
    {
        gsRwCtrl.uarSrcCmdLink[uLoop].uPrev=uLoop-1;
        gsRwCtrl.uarSrcCmdLink[uLoop].uNext=uLoop+1;
        gsRwCtrl.uarFreeSrcQue[uLoop]=uLoop;
    }

    // gsRwCtrl.uarSrcCmdLink[0].uPrev=cNull;
    gsRwCtrl.uarSrcCmdLink[cReadFifoDpt-1].uNext=cNull;

    // gsRwCtrl.usSrcCmdList.u16Cnt=0;
    gsRwCtrl.usSrcCmdList.u16Head=cNull;
    gsRwCtrl.usSrcCmdList.u16Tail=cNull;
    gsRwCtrl.usSrcCmdList.u16Trig=cNull;
#endif/* if (_ENABLE_SRC_LINK_LIST) */

#if _EnSpareFunc
    for(uLoop=0; uLoop<cMaxChNum; uLoop++)
    {
        gWaitSpareTyp[uLoop]=0xFF;
        gSpareCnt[uLoop]=0;
        gSparePtrHead[uLoop]=0;
        gSparePtrTail[uLoop]=0;
    }
    mSetNewDesF;
#endif
    /*
       * for(uLoop=0; uLoop<cMax4kNum; uLoop++)
       * {
       *  gsHmbInfo.u32HmbCacheHp[uLoop]=c32BitFF;
       *  gsHmbInfo.u16HmbCacheHb[uLoop]=c16BitFF;
       * }
       */

    gWriteHMBIndex=0;

    for(uLoop=0; uLoop<cHmbRacingFreeCnt; uLoop++)
    {
        g16WriteHMBH2FTable[uLoop]=c16Null;
    }

    bopClrRam((LWORD)&garSrchSrcTab, sizeof(garSrchSrcTab), 0xFFFFFFFF, cClrCore0Dccm|cBopWait);
    // gsRwCtrl.u32Debug2=1;    // to pass greybox
}    /* initFtlVar */

#endif/* if (_PRJ_NVME||_PRJ_SMIVU||_PRJ_ISP||_PRJ_BOOT1||_PRJ_BOOT2) */

#if (_PRJ_NVME||_PRJ_SMIVU)
void updateNvmeDstData(BYTE uReadWpro, BYTE uUpdateType)
{
    LWORD u32DstIdx;
    BYTE uFailIdx;

    if(uReadWpro)
    {
        readWproPageCore0(cWproGetLogPg, cNvmeGetLogSIdx, 0);
    }

    if(uUpdateType==cDstLogResultUpdate)
    {
        if(gpGetLog->usDstLog.uCurrDstFailBitMap&&(!(gsCurrDstResult.uDstStatus&0x0F)))
        {
            gsCurrDstResult.uDstStatus|=cOperationCompletedKnowSegmentFailed;

            for(uFailIdx=0; uFailIdx<cSegmentAllDone; uFailIdx++)
            {
                if(gpGetLog->usDstLog.uCurrDstFailBitMap&cbBitTab[uFailIdx])
                {
                    gsCurrDstResult.uSegmentNum=(uFailIdx+1);
                    break;
                }
            }
        }
        else
        {
            gsCurrDstResult.uSegmentNum=cSegment0Initial;    // Complete no error case
        }

        // Shift 1st-19th DST Result ro 2nd-20th DST Result
        for(u32DstIdx=19; u32DstIdx>0; u32DstIdx--)
        {
            bopCopyRam((LWORD)&gpGetLog->usDstLog.usDstResult[u32DstIdx],
                       (LWORD)&gpGetLog->usDstLog.usDstResult[u32DstIdx-1],
                       sizeof(DSTRESULT),
                       cCopyTsb2Tsb|cBopWait);
        }

        // update newest DST Result to 1st DST Result
        bopCopyRam((LWORD)&gpGetLog->usDstLog.usDstResult[0], (LWORD)&gsCurrDstResult, sizeof(DSTRESULT), cCopyDccm2Tsb|cBopWait);
        // gpGetLog->usDstLog.usDstResult[0].uDstStatus=(gsCurrDstResult.uDstStatus&0xF0)|(uDstResult&0x0F);
        gpGetLog->usDstLog.usDstResult[0].u64Poh=gpGetLog->usSmartLog.u64arPowerOnHours[0];
        gpGetLog->usDstLog.u32NvmeDstStartTimeMs=0;
        gpGetLog->usDstLog.uCurrDstFailBitMap=0x00;
        gsCurrDstResult.uDstStatus=cOperationNoDstInProgress;
        // gsCurrDstResult.uSegmentNum=cSegment0Initial;
        bopClrRam((LWORD)&gpGetLog->usDstLog.usDstResult[20], sizeof(DSTRESULT), 0x00000000, cBopWait|cClrTsb);    // 20181211_SamHu_01
    }
    else
    {
        // update newest DST Result to backup DST Result
        bopCopyRam((LWORD)&gpGetLog->usDstLog.usDstResult[20], (LWORD)&gsCurrDstResult, sizeof(DSTRESULT), cCopyDccm2Tsb|cBopWait);
    }

    gpGetLog->usDstLog.uCurrDstOperation=(gsCurrDstResult.uDstStatus>>4);
    gpGetLog->usDstLog.uCurrDstCompletion=(gsCurrDstResult.uSegmentNum*10);    // Process percentage

    saveSmartInfo(cNotReadWpro);
}    /* updateNvmeDstData */

#endif/* if (_PRJ_NVME||_PRJ_SMIVU) */

#if 1    // (_PRJ_NVME||_PRJ_ISP)

#if _ENABLE_SECAPI
BYTE chkHitRange(LWORD LBAStart, LWORD XfrCnt, LWORD *up32RangeStartPtr, LWORD *up32RangeEndPtr)
{
    BYTE uLoop;
    LWORD LBAEnd=LBAStart+XfrCnt;    // Be careful that LBAEnd is just the boundary not the actual LBA. The exact LBAs requested from host

    // is from LBAStrat to (LBAEnd-1)

    for(uLoop=0; uLoop<(cTcgMaxRange+1); uLoop++)
    {
        if(up32RangeStartPtr[uLoop]<up32RangeEndPtr[uLoop])
        {
            if((LBAStart<up32RangeEndPtr[uLoop])&&(up32RangeStartPtr[uLoop]<LBAEnd))    // C_RangeHit
            {
                if((LBAStart>=up32RangeStartPtr[uLoop])&&(LBAEnd<=up32RangeEndPtr[uLoop]))    // C_RangeFullyOverlap
                {
                    return cRangeFullyOverlap;    // the requested LBA range is inside the locking range
                }

                return cRangeHit;    // overlap occurs
            }
        }
    }

    return cRangeMiss;
}    /* chkHitRange */

void SecAPI_ChkHitRange(LWORD u32LBAStart, LWORD u32XfrCnt, BYTE uIsRCmd, BYTE uExcludeMBR)
{
    BYTE uRangeHit=cRangeMiss;
    LWORD u32LBAEnd=u32LBAStart+u32XfrCnt;    // u32LBAEnd is just the boundary not the actual LBA
    // MBR range parameter
    LWORD u32MbrLBAEnd=(cTcgMbrSize<<11);

    if(gMBRShadow&&(!uExcludeMBR))    // 1. Check MBR Range
    {
        if(u32LBAEnd<=u32MbrLBAEnd)    // startLBA and endLBA are in MBR range
        {
            gMbrRangeHit=1;
        }
        else if((u32LBAStart<u32MbrLBAEnd)&&(u32LBAEnd>u32MbrLBAEnd))    // startLBA is in MBR range but endLBA isn't in MBR range
        {
            // M_SetCmdErr;
            gSecurityLockRWErr=1;
        }
        else    // startLBA and endLBA aren't in MBR range
        {
            if(uIsRCmd)
            {
                uRangeHit=chkHitRange(u32LBAStart, u32XfrCnt, g32arReadRangeStart, g32arReadRangeEnd);
            }
            else
            {
                uRangeHit=chkHitRange(u32LBAStart, u32XfrCnt, g32arWriteRangeStart, g32arWriteRangeEnd);
            }

            if(uRangeHit==cRangeFullyOverlap)    // hit and all in fully range
            {
                if(uIsRCmd&&(gMBRShadow==cTrue))
                {
                    gMbrReturnZero=1;
                }
                else
                {
                    // M_SetCmdErr;
                    gSecurityLockRWErr=1;
                }
            }
            else if(uRangeHit==cRangeHit)    // hit range
            {
                // M_SetCmdErr;
                gSecurityLockRWErr=1;
            }
        }
    }
    else    // 2. Check Locking Range
    {
        if(uIsRCmd)
        {
            uRangeHit=chkHitRange(u32LBAStart, u32XfrCnt, g32arReadRangeStart, g32arReadRangeEnd);
        }
        else
        {
            uRangeHit=chkHitRange(u32LBAStart, u32XfrCnt, g32arWriteRangeStart, g32arWriteRangeEnd);
        }

        if(uRangeHit)
        {
            // M_SetCmdErr;
            gSecurityLockRWErr=1;
        }
    }

    if(uRangeHit)
    {
        NLOG(cLogSecApiBaseFw,
             NVMECOMMONFUNC_C,
             4,
             "  SecAPI_ChkHitRange() uRangeHit = 0x%04X , gMBRShadow = 0x%04X , gLockingStatus = 0x%04X , uIsRCmd = 0x%04X.",
             (WORD)uRangeHit,
             (WORD)gMBRShadow,
             (WORD)gLockingStatus,
             (WORD)uIsRCmd);
    }
}    /* SecAPI_ChkHitRange */

#endif/* if _ENABLE_SECAPI */
WORD chkCmdInfo(LWORD u32Nlb, LWORD u32LbaLow, LWORD u32NsId)
{
    WORD u16CommandStatus;    // =cStatusSuccess;

    if(u32Nlb>(1<<(gsLightSwitch.usNvmeLs.uMdts+3)))    // check if transfer count exceeds maximum payload size
    {
        NLOG(cLogComErr, NVMECOMMONFUNC_C, 2, " u32Nlb=%08x ", (WORD)(u32Nlb>>16), (WORD)u32Nlb);
        u16CommandStatus=cStatusInvalidField;
    }

#if (!_ENABLE_SGLS)
    else if(rmNvmeSgl)
    {
        NLOG(cLogComErr, NVMECOMMONFUNC_C, 0, " not support SGL ");
        u16CommandStatus=cStatusInvalidField;
    }
#endif
    else if((u32NsId==cNamespaceNotSpecific)||(u32NsId>gsLightSwitch.usNvme2Ls.u32NamespaceNum)||
            (!(gsNamespace.uActiveBitMap&cbBitTab[u32NsId-1])))    //
                                                                   // validate
                                                                   // NSID
    {
        NLOG(cLogComErr, NVMECOMMONFUNC_C, 2, " NSID=%08x ", (WORD)(u32NsId>>16), (WORD)(u32NsId));
        u16CommandStatus=(cStatusMore|cStatusInvalidNsFormat);    // WD Jira-87
    }
    else
    {
        u16CommandStatus=chkLbaRange(rmNvmeLbaHigh, u32LbaLow, u32Nlb, u32NsId, cNvmeCmdRead);
    }

#if 0    // future to implement
    else if((M_ChkDummyWrite||!g16TotalSpareCnt)&&(rmNvmeOpCode==cNvmeCmdWrite))    // if in read only mode or g16TotalSpareCnt==0 =>
    {
        // read only
        u16CommandStatus=cStatusWrFault;    // (Evan) handle Read Only Mode
    }
#endif

    // if(u16CommandStatus)
    // {
    //    manualCompletion(u16CommandStatus, 0, cNoRwCmd, 0);
    // }

    return u16CommandStatus;
}    /* chkCmdInfo */

// check command info Error or not by HW register
WORD chkCmdInfoError(LWORD u32NvmeNlb, LWORD u32NvmeLbaLow, LWORD u32NsId)
{
    // LWORD u32NvmeNLB=rmNvmeNlb;
    WORD u16CommandStatus;    // =cStatusSuccess;
    BYTE uOpCode=rmNvmeOpCode;

#if _ENABLE_SECAPI
    if(gbEnTCG)
    {
        if((uOpCode==cNvmeCmdRead)||(uOpCode==cNvmeCmdCompare))
        {
            if(gMBRShadow||rmChkReadLock)
            {
                SecAPI_ChkHitRange(u32NvmeLbaLow, u32NvmeNlb, 1, 0);
            }

            if(gSecurityLockRWErr)
            {
                NLOG(cLogSecApiBaseFw, NVMECOMMONFUNC_C, 4, "chkCmdInfoError()-READ LBAStart = 0x%08X , XfrCnt = 0x%08X.",
                     (WORD)(u32NvmeLbaLow>>16), (WORD)u32NvmeLbaLow, (WORD)(u32NvmeNlb>>16), (WORD)u32NvmeNlb);
                // manualCompletion(cStatusAccessDenied, 0, cNoRwCmd, 0);
                u16CommandStatus=(cStatusDoNotRetry|cStatusAccessDenied);
                gSecurityLockRWErr=0;
                // break;
            }
            else
            {
                u16CommandStatus=chkCmdInfo(u32NvmeNlb, u32NvmeLbaLow, u32NsId);
            }
        }
        else if(uOpCode==cNvmeCmdWrite)
        {
            if(gMBRShadow||rmChkWriteLock)
            {
                SecAPI_ChkHitRange(u32NvmeLbaLow, u32NvmeNlb, 0, 0);
            }

            if(gMbrRangeHit==1)
            {
                gSecurityLockRWErr=1;
                gMbrRangeHit=0;
            }

            if(gSecurityLockRWErr)
            {
                NLOG(cLogSecApiBaseFw, NVMECOMMONFUNC_C, 4, "chkCmdInfoError()-WRITE LBAStart = 0x%08X , XfrCnt = 0x%08X.",
                     (WORD)(u32NvmeLbaLow>>16), (WORD)u32NvmeLbaLow, (WORD)(u32NvmeNlb>>16), (WORD)u32NvmeNlb);
                // manualCompletion(cStatusAccessDenied, 0, cNoRwCmd, 0);
                u16CommandStatus=(cStatusDoNotRetry|cStatusAccessDenied);
                gSecurityLockRWErr=0;
                // break;
            }
            else
            {
                u16CommandStatus=chkCmdInfo(u32NvmeNlb, u32NvmeLbaLow, u32NsId);
            }
        }
    }
    else
    {
        u16CommandStatus=chkCmdInfo(u32NvmeNlb, u32NvmeLbaLow, u32NsId);
    }
#else/* if _ENABLE_SECAPI */
    u16CommandStatus=chkCmdInfo(u32NvmeNlb, u32NvmeLbaLow, u32NsId);
#endif/* if _ENABLE_SECAPI */

    if(u16CommandStatus)
    {
        manualCompletion(u16CommandStatus, 0, cNoRwCmd, 0);
    }

    return u16CommandStatus;
}    /* chkCmdInfoError */

WORD chkLbaRange(LWORD u32LbaH, LWORD u32LbaL, LWORD u32Nlb, LWORD u32NsId, BYTE uOpCode)
{
    LWORD u32HostTotalDataSectorCnt=g32HostTotalDataSectorCnt;
    WORD u16CommandStatus=cStatusSuccess;

    if(uOpCode==cNvmeCmdSecuritySend)
    {
        u32HostTotalDataSectorCnt=u32HostTotalDataSectorCnt+gTcgReservedSecShiftCnt+cTcgReserveSecCnt;

        if(u32LbaH||(u32LbaL>=u32HostTotalDataSectorCnt)||((u32LbaL+u32Nlb)>u32HostTotalDataSectorCnt))
        {
            u16CommandStatus=cStatusLbaOutofRange;
        }
    }
    else if(u32LbaH||(u32LbaL>=gsNamespace.usInfo[u32NsId-1].u32Size)||((u32LbaL+u32Nlb)>gsNamespace.usInfo[u32NsId-1].u32Size))
    {
        NLOG(cLogHost, NVMECOMMONFUNC_C, 2, " u32LbaH=%08x ", u32LbaH>>16, u32LbaH);
        NLOG(cLogHost, NVMECOMMONFUNC_C, 2, " u32LbaL=%08x ", u32LbaL>>16, u32LbaL);
        NLOG(cLogHost, NVMECOMMONFUNC_C, 2, " u32Nlb=%08x ", u32Nlb>>16, u32Nlb);
        NLOG(cLogHost, NVMECOMMONFUNC_C, 0, " LbaOutofRange ");
        NLOG(cLogHost, NVMECOMMONFUNC_C, 2, " u32Size=%08x ", gsNamespace.usInfo[u32NsId-1].u32Size>>16, gsNamespace.usInfo[u32NsId-1].u32Size);
        u16CommandStatus=cStatusLbaOutofRange;
    }

    // else if((u32LbaL+u32Nlb)>gsNamespace.usInfo[u32NsId-1].u32Size)  //The case don't fit the definition of Nvme spec
    // {
    //    return cStatusCapExceeded;
    // }
#if _ENABLE_SECAPI
    else if((rmNvmeOpCode==cNvmeCmdWriteUnc)||(rmNvmeOpCode==cNvmeCmdWriteZero)||(rmNvmeOpCode==cNvmeCmdDataSetMgm))    // TCG SIIS
                                                                                                                        // (CSSD-4301)
    {
        if(gbEnTCG)
        {
            if((gMBRShadow&&(rmNvmeOpCode!=cNvmeCmdDataSetMgm))||rmChkWriteLock)
            {
                SecAPI_ChkHitRange(u32LbaL, u32Nlb, 0, (rmNvmeOpCode==cNvmeCmdDataSetMgm)?1:0);
            }

            if(gMbrRangeHit==1)
            {
                gSecurityLockRWErr=1;
                gMbrRangeHit=0;
            }

            if(gSecurityLockRWErr)
            {
                gSecurityLockRWErr=0;
                u16CommandStatus=(cStatusDoNotRetry|cStatusAccessDenied);
            }
            else
            {
                u16CommandStatus=cStatusSuccess;
            }
        }
    }
#endif/* if _ENABLE_SECAPI */
    else
    {
        u16CommandStatus=cStatusSuccess;
    }
    return u16CommandStatus;
}    /* chkLbaRange */

#endif/* if (_PRJ_NVME||_PRJ_ISP) */

void resetCpu(BYTE uType)
{
    LWORD u32Loop=0;
    BYTE uStopBk;

    NLOG(cLogSecApiBaseFw, NVMECOMMONFUNC_C, 0, "ResetCPU!!!");

#if 0    // _ENABLE_SECAPI
    if(gbEnTCG||gbEnATAPassThrough||gbEnRpmb)
    {
        loadISPCodeCore0(cSecTsbBank, 3);
        SecAPI_NoticeSecCodeSwap(0);
        SecAPI_NoticeBackupResume_Request(cSwapBackup);
        // [D.H] Maybe after security API will refer to the argument. Now both cDevSlpBackup and cSwapBackup are the same flow.
    }
#endif

    if(gSecurityOption&cEnE2e)
    {
        rmDisGlobalCrc;
        rmDisE2eCrc15;
    }

#if _ENABLE_SRAM_ECC_PROTECTION
    // cpuEccDisable();
    __disableArmEccFunc();

    // tsbEccDisable();
    // TSB 0, 1, 2, 3
    rmClrTsbEccCorr;
    rmClrTsbEccErr;
    rmDisTsbEcc;

    // TSB4
    rmClrTsb4EccCorr;
    rmClrTsb4EccErr;
    rmDisTsb4Ecc;
#endif

    rmHdmaDisAutoAes;    // Disable HDMA AES function
    rmBopDisAutoAes;    // Disable BOP AES function

    rmWaitSysCmdFifoBz;

    while(!rmAuxChkAllIdle)
        ;

    disableBranchPredict();
    sysDelay(20);

    // Disable interrupt
    __disable_irq();
    sysDelay(10);

    if(uType==cResetCpuSrst)
    {
        rmPcieForceLeaveL1;

        while(!rmChkPclkReady)
            ;

        rmPcieDisForceLeaveL1;
    }

    rmVic0IntEnable=0x00000000;
    rmVic0Disable;
    disableVe();

    rmWaitSysCmdFifoBz;

#if 0    // _ENABLE_RAID
    initRaidEngineCore0();
#endif
    // ======================================================================
    // disable auto Gate, System /CPU
    rmDisBusIdleClkDiv;
    // BCH/LDPC ECC
    rmDisBchDecClkDiv2;
    rmSysDisLdpcClkAutoGate2;
    rmDisEncClkAGate;
    rmSysDisBchDecClkAGate;
    rmSysDisLdpcAutoClkDiv;
    rmSysDisLdpcHDecAutoDiv;
    rmSysDisLdpcSDecAutoDiv;
    // DRAM
    // AHCI
    rmSysEnAhciMemPd;
    // NVMe
    // M_SysDisNvmeClkGate;
    // AES
    rmSysDisFwAesClkGate;
    rmDisAesClkGate;
    // Flash
    rmDisFlashClkAutoGate;
    rmDisFshPllClkGate;
    // BOP
    rmDisBopClkAGate;
    // RAID
    rmSysDisRaidClkGate;
    rmSysDisRaidClkAutoGate;
    rmSysDisRaidEncClkAutoGate;
    rmSysDisRaidDecClkAutoGate;
    // RSA
    rmSysDisRsaClkGate;

    // Not need yet.
    // Flash init.
    // RAID init
    // ===================================================================
    // Set clock for Rom code.
    rmWaitSysCmdFifoBz;
    setSysPllClock(250);
    setFlashClock(38);
    // ===================================================================
    // reset ECC for all ch
    rmWaitSysCmdFifoBz;
    setSelMulFL(1);
    // rmChSoftReset;
    resetEcc();
    setSelMulFL(0);
    rmWaitSysCmdFifoBz;
    // ===================================================================
    disAllChStop(&uStopBk);
    rmWaitSysCmdFifoBz;
    // ===================================================================
    // reset core 1
    rmCohCpu1ResetStart;
    rmCohDisCpu1;
    rmCohDisAllRegion;
    rmCohCpu1ResetEnd;
    // ===================================================================
    // reset core 1 ITCM
    invalidateDCache();
    rmChkBopFree;
    rmRstBopParam;
    rmSetBopTsb2Bvci;
    rmSetBopCcm;
    rmSetBopFillMo;
    rmEnBop2Iccm;
    rmSetDmaPatn(0);
    rmSetBopDesAddr(0x3000000);
    rmSetBopXfrLen((128<<10));
    rmTrigBopDmaOp(0);
    rmChkBopDone;
    // ===================================================================
    disableCache();
    invalidateInstCache();
    // ===================================================================
    // enable max ECC
    enEccInMax();
    // ===================================================================
    // rmEnSpi2Iccm;
    rSysCtrl0[rcSysContrl1]=(rSysCtrl0[rcSysContrl1]&0xFE);    // elva
    // ===================================================================

    if(uType==cResetCpuSrst)
    {
        rmSetSoftwareReset;
    }
    else
    {
        rmClrSoftwareReset;
    }

    // ===================================================================
    // while(!rmAuxChkAllIdle);
#if (_GREYBOX)
    sysDelay(0x500);
#else
    while(!((r32Aux[rcCpuAuxClt00>>2]&0x000FFB00)==0x000FFB00))
        ;
#endif
    ;

    __DSB();
    __DMB();
    __ISB();
    rmSysClrSpiRst;

    while(u32Loop<0xFFFFFFFE)
    {
        _nop();
        _nop();
        _nop();
        _nop();
        _nop();
        u32Loop++;
    }
}    /* resetCpu */

#if _PRJ_BOOT2

void clrNvmeIntStatus()
{
    BYTE uIdx;

    // clear 8 DMA status
    for(uIdx=0; uIdx<8; uIdx++)
    {
        rmClrDmaStatus(uIdx);
    }

    rmUnexIntHighClr;
    rmUnexIntLowClr;
}

void initNvme()
{
    rmClrEndIfReff;
    rmSysEnGen12AutoGate;
    rmClrEnExtOsc;

    rmPclkPolarSelClr;    // (Sam)
    sysDelay(30);
    rmPclkPolarSelSet;

    rmClrPhyRst;

    initPhy();

    while(!rmChkPerstDeassert)
        ;// Make sure PeRst has been asserted

// #if 0    //
//    rmSetPhyRst;    // << Original phy reset assertion
//    rmSetFwPeRst;
//    rmSwFwModePeRst;
//    sysDelay(2);
//    rmPclkPolarSelClr;
//
//    while(rmChkPclkReady)
//        ;
//
//    sysDelay(2);
//    rmClrPhyRst;    // << Original phy reset de-assertion
//    sysDelay(255);
//    rmPclkPolarSelSet;
//    sysDelay(2);
//    rmClrFwPeRst;
//    // rmSwHwModePeRst;  //?????
//    sysDelay(2);
//
//    while(!rmChkPclkReady)
//        ;
// #else
    rmClrFwPeRst;

    _nop();
    rmSetBypassPhyStatusReady;    // HW patch to ignore wait PCLK in FW mode
    _nop();

    while(!rmChkPclkReady)
        ;

// #endif/* if 1 */

    // rmPcieForceLeaveL1;  //mark here, 2263

    // while(!rmChkPclkReady)
    //    ;

    // rmPcieDisForceLeaveL1; //mark here, 2263

    resetNvmeIp();

    // Just Set one times after power cycle
    rmSetPcieLinkCtrl2(gsLightSwitch.usPcieLs.usLinkCapLs.u32All&0x0000000F);    // 3);// 1=gen1, 2=gen2, 3=gen3

    initPcie();

    initNvmeIp();    // (cDataCache0Size, cDataCache1Size, cDramCacheBias);

    initNvmeGlobVar(1);

    while(!rmChkPerstDeassert)
        ;// Make sure PeRst has been asserted

    rmSetPcieAppCtrlAppLtssmEn(0x01);    // Enable LTSSM (Link training & status state manchine)

    if(gsLightSwitch.usNvmeLs.uPreCR)
    {
        rmNvmeTsbReadPreCREn;    // 2263
    }

#if _EN_NVMEWRDUALENGINE
    rmSwTwoNvmeEngine;
#else
    rmSwOneNvmeEngine;    // there are 2 NVMe Engine, but it has some bug. so switch to one engine mode.
#endif
#if _EN_NVMERDDUALENGINE
    rmSrTwoNvmeEngine;
#else
    rmSrOneNvmeEngine;
#endif
    rmSetARBSoftReset;    // Reset Hmb
    rmSetHmbSoftReset;
    sysDelay(2);
    rmClrARBSoftReset;
    rmClrHmbSoftReset;
}    /* initNvme */

void initThermalVar()
{
    // gChkTemperature=0;
    mPSChgClrThrottling;
    mClrThermalThrottlingReason;
    // mPSChgClrThrottlingInRw;
    // g16Code85=gsLightSwitch.usThermalLs.u16Code85;    // =0x175
    // g16Code30=gsLightSwitch.usThermalLs.u16Code30;    // =0xDC

    g16Code85=rmEfuse85Code;
    g16Code30=rmEfuse30Code;

// renew thermal offset value F.J. Kuo 20190618
    if((cbRevision1[0]=='C')&&(cbRevision1[1]=='R'))    // CL1-3Dxxx
    {
        gThermalOffset=0;
    }
    else if((cbRevision1[0]=='C')&&(cbRevision1[1]=='S'))    // CL1-4Dxxx
    {
        gThermalOffset=1;
    }
    else if((cbRevision1[0]=='C')&&(cbRevision1[1]=='T')&&(g32HostTotalDataSectorCnt>0x37E436B0))    // CL1-8D512
    {
        gThermalOffset=4;
    }
    else if((cbRevision1[0]=='C')&&(cbRevision1[1]=='T')&&(g32HostTotalDataSectorCnt<=0x37E436B0))        // CL1-8D128 8D256
    {
        gThermalOffset=2;
    }
    else
    {
        gThermalOffset=0;
    }

    if(!g16Code30)    // For SM2263AA, the rmEfuse30 Code is zero
    {
        g16Code30=gsLightSwitch.usThermalLs.u16Code30;    // =0xDC
    }

    g16FlashClkForThermal=gsLightSwitch.usThermalLs.usPs0.u16FlashClock;
}    /* initThermalVar */

// Initial Nvme all Feature's Supported Capability
void initNvmeFeatureSC()
{
    NVMEFEATURESEL *upNvmeFeature;
    BYTE uLoop;

    upNvmeFeature=(void *)(&gpNvmeFeatVar->usFeat);

    for(uLoop=0; uLoop<cNvmeFeatEntryNumber; uLoop++)
    {
        upNvmeFeature->u32SelSC|=cChangeable;
        upNvmeFeature++;
    }

    upNvmeFeature=(void *)(&gpNvmeFeatVar->usFeat.usTemperatureThres[cOverTempTh][cCompositeTempSensor]);

    for(uLoop=0; uLoop<18; uLoop++)
    {
        upNvmeFeature->u32SelSC=0;
        upNvmeFeature++;
    }

    gpNvmeFeatVar->usFeat.usTemperatureThres[cOverTempTh][cCompositeTempSensor].u32SelSC|=cChangeable;
    gpNvmeFeatVar->usFeat.usTemperatureThres[cUnderTempTh][cCompositeTempSensor].u32SelSC|=cChangeable;

#if _ENABLE_NVME_LS
    if(gsLightSwitch.usNvmeLs.uOncs&cSaveFieldAndTheSelectField)
    {
        for(uLoop=0; uLoop<gsLightSwitch.usNvme2Ls.u32NamespaceNum; uLoop++)
        {
            gpNvmeFeatVar->usFeat.usLbaRangeType[uLoop].u32SelSC|=cSaveable;
        }

        gpNvmeFeatVar->usFeat.usPowerManagement.u32SelSC|=cSaveable;
// 20190523_Jesse_01, 3D512G for Dell NVMe spec A02 13.2.3 Set Feature FID_0x02 Saveable=0
#if (OEM==DELL)
#if ((PRODUCT_NAME&0x0008)==0x0008)    // define 512G
        gpNvmeFeatVar->usFeat.usPowerManagement.u32SelSC&=(~cSaveable);
#endif
#endif

        // 20181206_SamHu_01 mark for Devx NINFO17.o
        // gpNvmeFeatVar->usFeat.usNumberOfQueues.u32SelSC|=cSaveable;
        // gpNvmeFeatVar->usFeat.usAsyncEventCfg.u32SelSC|=cSaveable;
#if (OEM==LENOVO)    // 20190314_SamHu_ follow Lenovo Spec
        gpNvmeFeatVar->usFeat.usAutoPst.u32SelSC|=cSaveable;
#else
        gpNvmeFeatVar->usFeat.usAutoPst.u32SelSC&=(~cSaveable);
#endif
        gpNvmeFeatVar->usFeat.usHostThermalPwrMgmt.u32SelSC|=cSaveable;
        // 20181206_SamHu_01 mark for Devx NINFO17.o
        // gpNvmeFeatVar->usFeat.usTemperatureThres[cOverTempTh][cCompositeTempSensor].u32SelSC|=cSaveable;
        // gpNvmeFeatVar->usFeat.usTemperatureThres[cUnderTempTh][cCompositeTempSensor].u32SelSC|=cSaveable;
        // gpNvmeFeatVar->usFeat.usSwProgress.u32SelSC|=cSaveable;
        gpNvmeFeatVar->usFeat.usDellHdDITM.u32SelSC|=cSaveable;    // 20181010_Jesse_01, Add for Dell spec "ENG0013785_A01" HCTM & HD-DITM
                                                                   // saveable but doesn't keep when power off.
        gpNvmeFeatVar->usFeat.usPlpScp.u32SelSC|=cSaveable;
    }
#endif/* if _ENABLE_NVME_LS */

    for(uLoop=0; uLoop<gsLightSwitch.usNvme2Ls.u32NamespaceNum; uLoop++)
    {
        gpNvmeFeatVar->usFeat.usLbaRangeType[uLoop].u32SelSC|=cNamespaceSpecific;
#if 0    // 20181206_SamHu_01 mark for GTP Spec
        gpNvmeFeatVar->usFeat.usErrorRecovery[uLoop].u32SelSC|=cNamespaceSpecific;
        gpNvmeFeatVar->usFeat.usWriteAtomicityNormal[uLoop].u32SelSC|=cNamespaceSpecific;
#endif
    }
}    /* initNvmeFeatureSC */

// Initial Nvme all Feature's Attribute
void initNvmeFeatureDefaultAttribute(BYTE uInitSaveFlag)
{
    NVMEFEATURESEL *upNvmeFeature;
    BYTE uLoop;

#if _ENABLE_NVME_LS
    gpNvmeFeatVar->usFeat.usArbitration.u32Default=gsLightSwitch.usNvmeLs.uRab;
#else
    gpNvmeFeatVar->usFeat.usArbitration.u32Default=0x00000006;
#endif

#if _ENABLE_NVME_LS
    gpNvmeFeatVar->usFeat.usTemperatureThres[cOverTempTh][cCompositeTempSensor].u32Default=gsLightSwitch.usNvmeLs.u16WcTemp;
#endif

    for(uLoop=1; uLoop<9; uLoop++)
    {
        gpNvmeFeatVar->usFeat.usTemperatureThres[cOverTempTh][uLoop].u32Default=cOverTempDefault;
    }

#if _ENABLE_NVME_LS
    if(gsLightSwitch.usNvmeLs.uVwc&cVolatileWriteCacheEn)
    {
        gpNvmeFeatVar->usFeat.usVolatileWc.u32Default=0x00000001;    // This will cause somtimes hw don't fetch fwsq
    }
#endif

    gpNvmeFeatVar->usFeat.usNumberOfQueues.u32Default=(((cMaxIoSqCqCnt-1)<<16)|(cMaxIoSqCqCnt-1));

    gpNvmeFeatVar->usFeat.usIntVecCfg[0].u32Default=0x00010000;

    for(uLoop=1; uLoop<16; uLoop++)
    {
        gpNvmeFeatVar->usFeat.usIntVecCfg[uLoop].u32Default=uLoop;
    }

    for(uLoop=0; uLoop<gsLightSwitch.usNvme2Ls.u32NamespaceNum; uLoop++)
    {
        gpNvmeFeatVar->usFeat.usWriteAtomicityNormal[uLoop].u32Default=0x00000001;
    }

#if _ENABLE_NVME_LS
    gpNvmeFeatVar->usFeat.usAsyncEventCfg.u32Default=gsLightSwitch.usNvmeLs.uAsynConfig;
#endif

#if _ENABLE_THRMLTHROTTLING_LS
    gpNvmeFeatVar->usFeat.usHostThermalPwrMgmt.u32Default=(mChgCelsiustoKelvin(gsLightSwitch.usThermalLs.uMt2))|
                                                           ((mChgCelsiustoKelvin(gsLightSwitch.usThermalLs.uMt1))<<16);
// #ifdef _SUPPORT_FEATURE_DITM    // 20181010_Jesse_01, Add for Dell spec "ENG0013785_A01"
    gpNvmeFeatVar->usFeat.usDellHdDITM.u32Default=gpNvmeFeatVar->usFeat.usHostThermalPwrMgmt.u32Default;
// #endif
#endif

    // Set saved value to 0xFFFFFFFF to represent the saved value is invalid
    upNvmeFeature=(void *)(&gpNvmeFeatVar->usFeat);

    if(uInitSaveFlag)
    {
        for(uLoop=0; uLoop<cNvmeFeatEntryNumber; uLoop++)
        {
            upNvmeFeature->u32Saved=cNvmeFeatSavedInvalid;
            upNvmeFeature++;
        }
    }
}    /* initNvmeFeatureDefaultAttribute */

// Initial Nvme Feature's Attibute
void initNvmeFeatureAttribute()
{
    if(gsWproInfo.u16arWproIdxPagePtr[cWproFeaturePg]==c16BitFF)
    {
        bopClrRam(c32Tsb0SAddr, sizeof(NVMEFEATVAR), 0x00000000, cClrTsb|cBopWait);

        // need to check the entry of Supported Capability? Pretest? CID?
        initNvmeFeatureSC();

        // need to check the entry of Default attibute? Pretest? CID?
        initNvmeFeatureDefaultAttribute(1);

        // Init LBA range type default
        bopClrRam((LWORD)&gsNamespace, sizeof(gsNamespace), 0x00000000, cClrTsb|cBopWait);

        gpNvmeFeatVar->usLbaRangeTypeEntry[0][0].uAttribute=1;    // LBA range may be overwritten
        gpNvmeFeatVar->usLbaRangeTypeEntry[0][0].u64Nlb=(g32HostTotalDataSectorCnt-1);    // logic range host can access

        gsNamespace.uActiveBitMap|=cBit0;
        gsNamespace.uAllocatedBitMap|=cBit0;
        gsNamespace.usInfo[0].u32StartLba=0;
        gsNamespace.usInfo[0].u32Size=g32HostTotalDataSectorCnt;
        gsNamespace.u32UnvmCap=(g32HostTotalDataSectorCnt-gsNamespace.usInfo[0].u32Size);
        gsNamespace.uActiveNsNumber++;
        gsNamespace.uAllocatedNsNumber++;

        progCacheInfoTab();
        // progWproPageCore0(cWproFeaturePg, cNvmeFeatSIdx);
    }
    else    // update when power on 20190311_SamHu_02
    {
        readWproPageCore0(cWproFeaturePg, cNvmeFeatSIdx, 0);
        initNvmeFeatureSC();
        initNvmeFeatureDefaultAttribute(0);    // 20190329_Jesse_01, Disable, Because function will initial feature save data
        progWproPageCore0(cWproFeaturePg, cNvmeFeatSIdx);
    }

    bopClrRam((LWORD)&gsPowerState, sizeof(gsPowerState), 0x00000000, cClrCore0Dccm|cBopWait);    // Will modify value in following func
    updateNvmeFeatureSetting();
}    /* initNvmeFeatureAttribute */

void initSmart()
{
    BYTE uCnt;

    if(gsWproInfo.u16arWproIdxPagePtr[cWproGetLogPg]!=c16BitFF)
    {
        readWproPageCore0(cWproGetLogPg, cNvmeGetLogSIdx, 0);
    }
    else
    {
        bopClrRam((LWORD)(BYTE *)gpGetLog, sizeof(GETLOGINFO), 0x00, cBopWait|cClrTsb);

        // LID 02h Smart Information
#if _ENABLE_SMART_LS
        gpGetLog->usSmartLog.uAvailableSpareThreshold=gsLightSwitch.usSmartLs.uAvaliableSpareThres;
#else
        gpGetLog->usSmartLog.uAvailableSpareThreshold=0x10;
#endif

        // LID 03h Fw Slot Information
        gpGetLog->usFwSlot.uarFrs[cFirmwareSlotAfi][0]=cFirmwareSlot1;
#if _ENABLE_CID_LS
        bopCopyRam((LWORD)&gpGetLog->usFwSlot.uarFrs[cFirmwareSlot1][0],
                   (LWORD)&gsLightSwitch.usCidHeader.uarIspRev[0],
                   8,
                   cCopyDccm2Tsb|cBopWait);
#else
        gpGetLog->usFwSlot.uarFrs[cFirmwareSlot1][0]=0x47;
        gpGetLog->usFwSlot.uarFrs[cFirmwareSlot1][1]=0x49;
        gpGetLog->usFwSlot.uarFrs[cFirmwareSlot1][2]=0x54;
        gpGetLog->usFwSlot.uarFrs[cFirmwareSlot1][3]=0x30;
        gpGetLog->usFwSlot.uarFrs[cFirmwareSlot1][4]=0x39;
        gpGetLog->usFwSlot.uarFrs[cFirmwareSlot1][5]=0x34;
        gpGetLog->usFwSlot.uarFrs[cFirmwareSlot1][6]=0x35;
        gpGetLog->usFwSlot.uarFrs[cFirmwareSlot1][7]=0x33;
#endif

        // LID 05h Command Effect Log
        // Admin Commands
        gpGetLog->usCmdEffectLog.u32arAcs[cNvmeCmdDeleteSq]|=(cLogPageCmdEffCsupp);
        gpGetLog->usCmdEffectLog.u32arAcs[cNvmeCmdCreateSq]|=(cLogPageCmdEffCsupp);
        gpGetLog->usCmdEffectLog.u32arAcs[cNvmeCmdGetLogPage]|=(cLogPageCmdEffCsupp);
        gpGetLog->usCmdEffectLog.u32arAcs[cNvmeCmdDeleteCq]|=(cLogPageCmdEffCsupp);
        gpGetLog->usCmdEffectLog.u32arAcs[cNvmeCmdCreateCq]|=(cLogPageCmdEffCsupp);
        gpGetLog->usCmdEffectLog.u32arAcs[cNvmeCmdIdentify]|=(cLogPageCmdEffCsupp);
        gpGetLog->usCmdEffectLog.u32arAcs[cNvmeCmdAbortCmd]|=(cLogPageCmdEffCsupp);
        gpGetLog->usCmdEffectLog.u32arAcs[cNvmeCmdSetFeatures]|=(cLogPageCmdEffCsupp);
        gpGetLog->usCmdEffectLog.u32arAcs[cNvmeCmdGetFeatures]|=(cLogPageCmdEffCsupp);
        gpGetLog->usCmdEffectLog.u32arAcs[cNvmeCmdAsyncEvent]|=(cLogPageCmdEffCsupp);

        if(gsLightSwitch.usNvmeLs.uFeatOption&cEnableNamespace)
        {
            gpGetLog->usCmdEffectLog.u32arAcs[cNvmeCmdNamespaceManagement]|=(cLogPageCmdEffCsupp|cLogPageCmdEffLbcc|cLogPageCmdEffNcc);
        }

        gpGetLog->usCmdEffectLog.u32arAcs[cNvmeCmdActivateFw]|=(cLogPageCmdEffCsupp|cLogPageCmdEffCcc);
        gpGetLog->usCmdEffectLog.u32arAcs[cNvmeCmdDownloadFw]|=(cLogPageCmdEffCsupp);

        if(gsLightSwitch.usNvmeLs.u16Oacs&cDeviseSelfTestCmd)
        {
            gpGetLog->usCmdEffectLog.u32arAcs[cNvmeCmdDst]|=(cLogPageCmdEffCsupp);
        }

        if(gsLightSwitch.usNvmeLs.uFeatOption&cEnableNamespace)
        {
            gpGetLog->usCmdEffectLog.u32arAcs[cNvmeCmdNamespaceAttachment]|=(cLogPageCmdEffCsupp|cLogPageCmdEffLbcc|cLogPageCmdEffNcc);
        }

        if(gsLightSwitch.usNvmeLs.u16Oacs&cDirectivesCmd)
        {
            gpGetLog->usCmdEffectLog.u32arAcs[cNvmeCmdDirectiveSend]|=(cLogPageCmdEffCsupp);
            gpGetLog->usCmdEffectLog.u32arAcs[cNvmeCmdDirectiveRecv]|=(cLogPageCmdEffCsupp);
        }

        gpGetLog->usCmdEffectLog.u32arAcs[cNvmeCmdFormat]|=(cLogPageCmdEffCsupp|cLogPageCmdEffLbcc|cLogPageCmdEffCseSameNs);

#if (_ENABLE_TCG)
        gpGetLog->usCmdEffectLog.u32arAcs[cNvmeCmdSecuritySend]|=(cLogPageCmdEffCsupp|cLogPageCmdEffLbcc);
        gpGetLog->usCmdEffectLog.u32arAcs[cNvmeCmdSecurityRecv]|=(cLogPageCmdEffCsupp);
#endif

        if(gsLightSwitch.usNvme2Ls.u32SaniCap)
        {
            gpGetLog->usCmdEffectLog.u32arAcs[cNvmeCmdSanitize]|=(cLogPageCmdEffCsupp|cLogPageCmdEffLbcc);
        }

        // Vendor Commands
        gpGetLog->usCmdEffectLog.u32arAcs[cNvmeCmdVendorNonData]|=(cLogPageCmdEffCsupp|cLogPageCmdEffLbcc|cLogPageCmdEffNcc|cLogPageCmdEffCcc);
        gpGetLog->usCmdEffectLog.u32arAcs[cNvmeCmdVendorDataOut]|=(cLogPageCmdEffCsupp|cLogPageCmdEffLbcc|cLogPageCmdEffNcc|cLogPageCmdEffCcc);
        gpGetLog->usCmdEffectLog.u32arAcs[cNvmeCmdVendorDataIn]|=(cLogPageCmdEffCsupp);

        // Vendor Commands
        gpGetLog->usCmdEffectLog.u32arAcs[cNvmeCmdLiteonVendorNonData]|=(cLogPageCmdEffCsupp);
        gpGetLog->usCmdEffectLog.u32arAcs[cNvmeCmdLiteonVendorDataOut]|=(cLogPageCmdEffCsupp);
        gpGetLog->usCmdEffectLog.u32arAcs[cNvmeCmdLiteonVendorDataIn]|=(cLogPageCmdEffCsupp);

        // IO Commands
        // gpGetLog->usCmdEffectLog.u32arIocs[cNvmeCmdFlush]|=(cLogPageCmdEffCsupp|cLogPageCmdEffLbcc);
        gpGetLog->usCmdEffectLog.u32arIocs[cNvmeCmdFlush]|=(cLogPageCmdEffCsupp);    // 20181031_Jesse_01,Modify Flush command Command Effect
                                                                                     // log data for eDEVX test

        gpGetLog->usCmdEffectLog.u32arIocs[cNvmeCmdWrite]|=(cLogPageCmdEffCsupp|cLogPageCmdEffLbcc);
        gpGetLog->usCmdEffectLog.u32arIocs[cNvmeCmdRead]|=(cLogPageCmdEffCsupp);

        if(gsLightSwitch.usNvmeLs.uOncs&cCompareCommand)
        {
            gpGetLog->usCmdEffectLog.u32arIocs[cNvmeCmdCompare]|=(cLogPageCmdEffCsupp);
        }

        if(gsLightSwitch.usNvmeLs.uOncs&cWriteUncCommand)
        {
            gpGetLog->usCmdEffectLog.u32arIocs[cNvmeCmdWriteUnc]|=(cLogPageCmdEffCsupp|cLogPageCmdEffLbcc);
        }

        if(gsLightSwitch.usNvmeLs.uOncs&cWriteZeroesCommand)
        {
            gpGetLog->usCmdEffectLog.u32arIocs[cNvmeCmdWriteZero]|=(cLogPageCmdEffCsupp|cLogPageCmdEffLbcc);
        }

        if(gsLightSwitch.usNvmeLs.uOncs&cDatasetManagementCommand)
        {
            gpGetLog->usCmdEffectLog.u32arIocs[cNvmeCmdDataSetMgm]|=(cLogPageCmdEffCsupp|cLogPageCmdEffLbcc);
        }

        // LID 06h Device Self-test
        for(uCnt=0; uCnt<20; uCnt++)
        {
            gpGetLog->usDstLog.usDstResult[uCnt].uDstStatus=cOperationEntryNotUsed;
        }

        // LID 07h Telemetry Host-Initiated Log
        gpGetLog->usTeleHostLog.uLid=cLogTelemetryHost;
        copyCcmVal((UCBYTE *)gpGetLog->usTeleHostLog.uarIeee, gsMPInfo.uarIeee, 3);

        // LID 08h Telemetry Controller-Initiated Log
        gpGetLog->usTeleHostLog.uLid=cLogTelemetryController;
        copyCcmVal((UCBYTE *)gpGetLog->usTeleCtrlLog.uarIeee, gsMPInfo.uarIeee, 3);

        // LID 81h Sanitize Status
        gpGetLog->usSaniLog.u16Sprog=c16BitFF;
        gpGetLog->usSaniLog.uSstatH=cSanitizeGlobalDataErased;
        gpGetLog->usSaniLog.u32EstiTimeForOverWrite=c32BitFF;
        gpGetLog->usSaniLog.u32EstiTimeForBlkErase=c32BitFF;
        gpGetLog->usSaniLog.u32EstiTimeForCrpErase=c32BitFF;

        gpGetLog->usSmartLog.usSmart.usStatus.uCurrFwSlot=0;
        gpGetLog->usSmartLog.usSmart.usStatus.uNextFwSlot=cNoNextActiveFirmwareSlot;

        if(mChkIspBlkInFL)
        {
            gpGetLog->usSmartLog.usSmart.usStatus.uSavedFwSlotBitMap|=(cbBitTab[0]|cbBitTab[1]);    // 20190722_SamHu_01
        }
    }

    gpGetLog->usSmartLog.usSmart.usCnt.u64PowerOnSec+=(gsCacheInfo.u32RecRtcTime1s+getRtcDiff1s());
    startRtcCounting1s();
    gsCacheInfo.u32RecRtcTime1s=0;

    gpGetLog->usSmartLog.usSmart.usStatus.u16OverTempThres=gsLightSwitch.usNvmeLs.u16WcTemp;
    gpGetLog->usSmartLog.usSmart.usStatus.u16UnderTempThres=0;
    gpGetLog->usSmartLog.usSmart.usStatus.u32KeepSmartRtcTimeStamp=0;
    gpGetLog->usSmartLog.usSmart.usStatus.u32RtcStartTimeWcTemp=0;
    gpGetLog->usSmartLog.usSmart.usStatus.u32RtcStartTimeCcTemp=0;
    gpGetLog->usSmartLog.usSmart.usStatus.uOverTempBitMap=0;

    if((gsSmart.usStatus.uCurrFwSlot==cFwUpdateRdLink)&&(gpGetLog->usSmartLog.usSmart.usStatus.uNextFwSlot!=cNoNextActiveFirmwareSlot))
    {
        gpGetLog->usFwSlot.uarFrs[cFirmwareSlotAfi][0]=(gpGetLog->usSmartLog.usSmart.usStatus.uNextFwSlot+1);
        gpGetLog->usSmartLog.usSmart.usStatus.uCurrFwSlot=gpGetLog->usSmartLog.usSmart.usStatus.uNextFwSlot;
        gpGetLog->usSmartLog.usSmart.usStatus.uNextFwSlot=cNoNextActiveFirmwareSlot;
    }

    // LID 06h Device Self-test  //20181211_SamHu_01
    if(gpGetLog->usDstLog.uCurrDstOperation==cOperationExtendedDstInProgress)
    {
        gpGetLog->usDstLog.u32NvmeDstStartTimeMs=getRtcCurrentMs();
        NLOG(cLogHost, NVMECOMMONFUNC_C, 0, " Resume Extended Dst ");
        NLOG(cLogHost,
             NVMECOMMONFUNC_C,
             2,
             " gpGetLog->usDstLog.u32NvmeDstStartTimeMs=%08d ",
             gpGetLog->usDstLog.u32NvmeDstStartTimeMs>>16,
             gpGetLog->usDstLog.u32NvmeDstStartTimeMs);
    }

    progWproPageCore0(cWproGetLogPg, cNvmeGetLogSIdx);
    bopCopyRam((LWORD)&gsSmart, (LWORD)&gpGetLog->usSmartLog.usSmart, sizeof(SMARTATTRIBUTE), cCopyTsb2Dccm|cBopWait);
    bopCopyRam((LWORD)&gsCurrDstResult, (LWORD)&gpGetLog->usDstLog.usDstResult[20], sizeof(DSTRESULT), cCopyTsb2Dccm|cBopWait);
    bopCopyRam((LWORD)&gsSanitizeInfo, (LWORD)&gpGetLog->usSaniLog.usSanitizeInfo, sizeof(SANITIZE), cCopyTsb2Dccm|cBopWait);
    bopCopyRam((LWORD)&gsEraseUnitInfo, (LWORD)&gpGetLog->usSaniLog.usEraseUnitInfo, sizeof(ERASEUNITINFO), cCopyTsb2Stcm|cBopWait);
    // 20181224_SamHu_temp for debug
    NLOG(cLogHost,
         NVMECOMMONFUNC_C,
         2,
         " GetFeature FID 04h Cnt=0x%04X, GetFeature FID 04h InvalidCnt=0x%04X ",
         (WORD)gsSmart.usCnt.u16FeatureFID4Cnt,
         (WORD)gsSmart.usCnt.u16FeatureFID4failCnt);

    // LID 06h Device Self-test  //20181211_SamHu_01
    if(gpGetLog->usDstLog.uCurrDstOperation==cOperationShortDstInProgress)
    {
        gsCurrDstResult.uDstStatus|=cOperationAbortControllerLevelReset;
        NLOG(cLogHost, NVMECOMMONFUNC_C, 0, " short DST aborted by cold/warm boot ");
    }
}    /* initSmart */

void restoreNvmeFeatureForPS4()
{
    // if(gsWproInfo.u16arWproIdxPagePtr[cWproFeaturePg]!=c16BitFF)
    // {
    //    readWproPageCore0(cWproFeaturePg, cNvmeFeatSIdx, 0);
    // }

    // if(gpNvmeFeatVar.usFeat.usVolatileWc.u32Current)
    // {
    //    mSetCacheEnable;
    // }
    // else
    // {
    //    mClrCacheEnable;
    // }

    mSetStartThrottlingSt;

    gsPowerState.uDevCurPs=gsPowerState.uDevPrePs;
    gsPowerState.uDevLastPs=gsPowerState.uDevCurPs;
}    /* restoreNvmeFeatureForPS4 */

void restoreDSTForPS4()    // 20181228_SamHu_01 eDEVX
{
    if(gsWproInfo.u16arWproIdxPagePtr[cWproGetLogPg]!=c16BitFF)
    {
        readWproPageCore0(cWproGetLogPg, cNvmeGetLogSIdx, 0);
        bopCopyRam((LWORD)&gsCurrDstResult, (LWORD)&gpGetLog->usDstLog.usDstResult[20], sizeof(DSTRESULT), cCopyTsb2Dccm|cBopWait);
    }
}

#if _EN_BUILD_FWSLOTISPBLK    // Temoprary use, need program the Isp bin to Isp blk while MP
void buildFwslotIspBlk()
{
    LWORD u32PagePtr=gISPCore1StartPage;

    // if(!gsSmart.usStatus.uSavedFwSlotBitMap)
    {
        resetFwDlFlow(0x00);

        if(!(gsFwDlInfo.uFidStatus&cFidUnderProcess))
        {
            progFwDlTempIspblockCore0(c16Tsb0SIdx);
        }

        while(gsFwDlInfo.u32IspCodePerEndOffset<cTotalIspCodeSize)
        {
            loadIspPageCore0(u32PagePtr, cSysBlock1stInfo);
            progFwDlTempIspblockCore0(c16Tsb0SIdx);
            gsFwDlInfo.u32IspCodePerEndOffset+=gSectorPerPlaneH;
            u32PagePtr++;
        }

        rmResetBufFlg;

        if(gsFwDlInfo.u32IspCodePerEndOffset==cTotalIspCodeSize)
        {
            progFwDlTempIspblockCore0(c16Tsb0SIdx);
        }

        swapFwSlotIspCore0(1);
        swapFwSlotIspCore0(2);
        resetFwDlFlow(0x00);

        mSetIspBlkInFL;
        // gsSmart.usStatus.uSavedFwSlotBitMap|=0x01;
        // saveSmartInfo(cUpdateFrs|cUpdateSlotInfo);
    }
}    /* buildFwslotIspBlk */

#endif/* if _EN_BUILD_FWSLOTISPBLK */

#endif/* if _PRJ_BOOT2 */

#if _PRJ_BOOT1

void loadLightSwitch()
{
#if (!(_GREYBOX))
    BYTE uWhichInfo=cSysBlock1stInfo;
    BYTE uWhichInfo2=cSysBlock2ndInfo;
    BYTE uExist=0;

    WORD u16IspPage;
    MPINFO *upMpInfo;
    upMpInfo=(void *)&g32arTsb0[cMPInfoDataStOfst>>9];
#endif

#if ((_ICE_LOAD_ALL)&&(_WO_INFOB))
    copyCcmVal((BYTE *)(&gsLightSwitch), (BYTE *)(&cbLightSwTab[0x0000]), 2048);    // 4096); ////Load LightSwitch table from ISP default
#else
#if (_GREYBOX||_INITDRAM)
    if(!loadInfoPage(0, gSectorPerPlaneH, c16WriteSIdx, 0, cSysBlockMPInfo, cBit1))
#else
    u16IspPage=gISPBlockStartPage+(((cLightswitchBank+1)*cSwapCodeSize)/gSectorPerPlaneH);

    if(!mChk1stInfoInFL)
    {
        uWhichInfo=cSysBlock2ndInfo;
        uWhichInfo2=cSysBlock1stInfo;
    }

// 20190705_SamHu_01
    if(!loadInfoPage(u16IspPage, gSectorPerPlaneH, c16WriteSIdx, 0, uWhichInfo, cBit1))    // read lightswitch from isp blk
    {
        uExist=1;
    }
    else if(!loadInfoPage(u16IspPage, gSectorPerPlaneH, c16WriteSIdx, 0, uWhichInfo2, cBit1))    // read lightswitch from isp blk
    {
        uExist=1;
    }

    if(uExist)
#endif /* if (_GREYBOX||_INITDRAM) */
    {
        bopCopyRam((LWORD)&gsLightSwitch, (c32Tsb0SAddr), sizeof(gsLightSwitch), cCopyTsb2Dccm|cBopWait);    // LightSwitch Table
#if ((!_GREYBOX)&&_EN_AUTHENTICATION)
        if(!rmChkInDevSlp)
        {
            bopClrRam((LWORD)(BYTE *)&g32arTsb0[0], cMPInfoDataStOfst+sizeof(MPINFO), 0x00000000, cBopWait|cClrTsb);

            if(!loadInfoPage(0, gSectorPerPlaneH, c16WriteSIdx, 0, cSysBlockMPInfo, cBit1))
            {
                if(gsLightSwitch.usSecLs.uHpAuthen&cBit0)
                {
                    bopCopyRam((LWORD)&gHashOffsetBk[0]    /*gsLightSwitch.uarHashOffSetTable[0]*/,
                               0    /*c32MpInfoShaSAddr*/,
                               32,
                               cCopyTsb2Dccm|cBopWait);
                }

                copyCcmVal((BYTE *)&gsMPInfo, (BYTE *)upMpInfo, sizeof(MPINFO));
            }
            else
            {
                copyCcmVal(gsMPInfo.uarSerialNum, gsLightSwitch.usCidHeader.uarSerialNum, 20);
                copyCcmVal(gsMPInfo.uarModelName, gsLightSwitch.usCidHeader.uarModelNum, 40);
                copyCcmVal(gsMPInfo.uarIeee, gsLightSwitch.usNvmeLs.uarIeee, 3);
                copyCcmVal(gsMPInfo.uarEui64, gsLightSwitch.usNvmeLs.uarEui64, 8);
                copyCcmVal(gsMPInfo.uarFwVersion, gsLightSwitch.usCidHeader.uarIspRev, 8);
            }

            // 20190219_SamHu_Liteon fix Ieee value
            gsMPInfo.uarIeee[0]=0x03;
            gsMPInfo.uarIeee[1]=0x23;
            gsMPInfo.uarIeee[2]=0x00;
        }
#endif/* if ((!_GREYBOX)&&_EN_AUTHENTICATION) */
    }
#endif/* if ((_ICE_LOAD_ALL)&&(_WO_INFOB)) */
}    /* loadLightSwitch */

void initGlobOpt(BYTE uFromPS4)    // for CID, feature support, feature enable/disable
{
    // mSetCacheEnable;

    g32OutputUART=1;
    // g32OutputUart=gsLightSwitch.uLegacy[2]&cBit0;
    g32Ps3EnPwrDomain1=gsLightSwitch.usOem3Ls.uPs3EnPwrDomain1;

#if _LOAD_OPROM
    gsLightSwitch.usPcieLs.usRefClkAndOROM.uAll&=0xFE;
#endif

    if(!uFromPS4)
    {
        gSmartBackup=0;
    }

    // if(cbCidTable[0x42]&cBit3)
    // {
    //    g32GrtPeCycle=((cbCidTable[0x6B]<<8)|(cbCidTable[0x6A]))&0xFFFF;
    // }
    // else
    {
        // g32GrtPeCycle=7000;    // (80*30000+(548-80)*3000)/548  //The value need to discuss
#if (OEM==LENOVO)
        g32GrtPeCycle=1500;    // 20190529_SamHu_01 follow Lenovo DR report sync Bruce
#else
        g32GrtPeCycle=3000;    // 20181217_Kevin_01
#endif
        // g32GrtPeCycle=1500;    // 1500 is default TLC SPEC
    }

    // gkeepSerialModelNumFlag=0;

#if _GREYBOX
    gsLightSwitch.usThermalLs.uThermalCtrl&=~cEnThrottle;
#endif

#if (!_ENABLE_NVME_PM)
    gsLightSwitch.usNvmeLs.uNpss=0;
#endif

    gOpRomRead=0;
    mClrFwCommitSuccess;

    if(gsLightSwitch.usNvmeLs.uElpe>=cMaxErrLogEntryCnt)
    {
        gsLightSwitch.usNvmeLs.uElpe=(cMaxErrLogEntryCnt-1);    // zero based
    }

#if _ENABLE_SECAPI
    if(!(gbEnTCG||gbEnATAPassThrough||gbEnRpmb))
    {
        gsLightSwitch.usNvmeLs.u16Oacs&=(~cSecuritySendReceiveCmd);
    }

    if(!gbEnAes)
    {
        gsLightSwitch.usNvmeLs.uFna&=~cFnaCryptographicEraseSupported;
    }
    else
    {
        gsLightSwitch.usNvmeLs.uFna|=cFnaCryptographicEraseSupported;
    }
#endif

    if(!(gsLightSwitch.usNvmeLs.uFeatOption&cEnableNamespace))
    {
        gsLightSwitch.usNvmeLs.u16Oacs&=(~cNamespaceManageAttachCmd);
    }

#if (!_ENABLE_NVME_DST)
    gsLightSwitch.usNvmeLs.u16Oacs&=(~cDeviseSelfTestCmd);
#endif
#if (!_ENABLE_DIRECTIVE)
    gsLightSwitch.usNvmeLs.u16Oacs&=(~cDirectivesCmd);
#endif
#if (!_ENABLE_COMPARE)
    gsLightSwitch.usNvmeLs.uOncs&=(~cCompareCommand);
#endif
#if (!_ENABLE_WUNC)
    gsLightSwitch.usNvmeLs.uOncs&=(~cWriteUncCommand);
#endif
#if (!_ENABLE_TRIM)
    gsLightSwitch.usNvmeLs.uOncs&=(~cDatasetManagementCommand);
#endif
#if (!_ENABLE_WRITE_ZERO)
    gsLightSwitch.usNvmeLs.uOncs&=(~cWriteZeroesCommand);
#endif
#if (!_ENABLE_NVME_FEAT_TIMESTAMP)
    gsLightSwitch.usNvmeLs.uOncs&=(~cTimeStampFeat);
#endif
#if _ENABLE_SANITIZE
#if 0    // _ENABLE_SECAPI //[D.H]For Liteon IF_003
    if(gbEnTCG&&(gTcgNviSpLockingLifeCycleState==C_Manufactured))
    {
        gsLightSwitch.usNvme2Ls.u32SaniCap=0;    // Don't support Sanitize when security feature enabled
    }
#endif
#else
    gsLightSwitch.usNvme2Ls.u32SaniCap=0;
#endif
#if (!_ENABLE_NVMEFEAT_APST)
    gsLightSwitch.usNvmeLs.uApsta=0;
#endif
#if (!_EN_BgdGc)
    gsLightSwitch.usOem3Ls.uFtlCtrl&=(~cFtlBgdGc);
#endif
#if (!_EN_CacheR)
    gsLightSwitch.usOem3Ls.uFtlCtrl&=(~cFtlCacheRead);
#endif
#if (!_EN_CACHEPROG)
    gsLightSwitch.usOem3Ls.uFtlCtrl&=(~cFtlCacheProg);
#endif
#if (!_EN_SLCOpenBlkReadScrub)
    gsLightSwitch.usOem3Ls.uFtlCtrl&=(~cFtlReadScrub);
#endif

    if(gsLightSwitch.usOem3Ls.uFtlCtrl&cFtlCacheProg)
    {
        mSetFLOption(cEnCacheProg);
    }
    else
    {
        mClrFLOption(cEnCacheProg);
    }

#if _EN_LS_CACHER
    gsLightSwitch.usOem3Ls.uFtlCtrl|=cFtlCacheRead;     // 20191220_ChrisSu
#endif

    if(gsLightSwitch.usOem3Ls.uFtlCtrl&cFtlCacheRead)
    {
        NLOG(cLogSecApiBaseFw, NVMECOMMONFUNC_C, 0, "ENable Cache R");
        mSetFLOption(cEnCacheRead);
    }
    else
    {
        mClrFLOption(cEnCacheRead);
    }

    if(gsLightSwitch.usOem3Ls.uFtlCtrl&cFtlReadScrub)
    {
        mSetFLOption(cEnReadScrub);
    }
    else
    {
        mClrFLOption(cEnReadScrub);
    }

    gLowPowerStateRetryCnt=0;
    gApstRetryCnt=0;

// ----------PCIE Reg----------
// Max_Payload_Size Supported (MPS)
#if (OEM==HP)
    gsLightSwitch.usPcieLs.usDeviceCapLs.u16All|=0x01;    // 256B
#endif

// Maximum Link Width (MLW)
#if (OEM==HP)
    if(g32HostTotalDataSectorCnt==0xEE7C2B0)    // 20190515_SamHu_01 128GB just support Gen3x2
    {
        gsLightSwitch.usPcieLs.usLinkCapLs.u32All&=(~0x000003F0);    // clear
        gsLightSwitch.usPcieLs.usLinkCapLs.u32All|=0x00000020;    // x2
    }
#elif (OEM==LENOVO)
    if(g32HostTotalDataSectorCnt<=0x1DCF32B0)    // 20190710_SamHu_01 128/256GB just support Gen3x2
    {
        gsLightSwitch.usPcieLs.usLinkCapLs.u32All&=(~0x000003F0);    // clear
        gsLightSwitch.usPcieLs.usLinkCapLs.u32All|=0x00000020;    // x2
    }
#endif

// ----------Controller Reg----------
// Timeout (TO)
#if (OEM==HP)
    gsLightSwitch.usNvmeLs.usControllerCapLo.u32All&=0x00FFFFFF;    // clear
    gsLightSwitch.usNvmeLs.usControllerCapLo.u32All|=0x0A000000;    // 5s
#endif

// ----------Identify----------
// Maximum Time for Firmware Activation (MTFA)
    gsLightSwitch.usNvmeLs.u16Mtfa=0x32;
// Sanitize Capabilities (SANICAP)
    gsLightSwitch.usNvme2Ls.u32SaniCap=gsLightSwitch.usNvme2Ls.u32SaniCap&(~c32Overwrite);
// Maximum Data Transfer Size (MDTS)
#if (OEM==HP)
    gsLightSwitch.usNvmeLs.uMdts=6;    // 256KB
#endif

// ----------Smart----------
// Available Spare Threshold
#if (OEM==DELL)
    gsLightSwitch.usSmartLs.uAvaliableSpareThres=50;
    gsLightSwitch.usSmartLs.uWearLevelingCntThres=90;    // 20190225_SamHu_01
#elif (OEM==HP)    // 20190219_SamHu_01
    gsLightSwitch.usSmartLs.uAvaliableSpareThres=5;
#endif
// ---------Thermal Setting------
// By OEM assign thermal throttling setting
#if (OEM==HP)
    gsLightSwitch.usThermalLs.uMt2=84;
    gsLightSwitch.usThermalLs.uMt2FallDelta=3;
    gsLightSwitch.usThermalLs.uMt3=90;
    gsLightSwitch.usThermalLs.usPs1.u16FlashClock=100;
    gsLightSwitch.usThermalLs.usPs1.u16LdpcClock=100;
    // PS timing issue:align with STD MT2 clock F.J. Kuo 20190712
    // gsLightSwitch.usThermalLs.usPs2.u16SysClock=25;
    // gsLightSwitch.usThermalLs.usPs2.u16FlashClock=33;
    // gsLightSwitch.usThermalLs.usPs2.u16LdpcClock=33;
    gsLightSwitch.usThermalLs.usPsShutdown.u16SysClock=25;
    gsLightSwitch.usThermalLs.usPsShutdown.u16FlashClock=33;
    gsLightSwitch.usThermalLs.usPsShutdown.u16LdpcClock=33;
#elif (OEM==DELL)
    gsLightSwitch.usThermalLs.uMt1=82;
    gsLightSwitch.usThermalLs.uMt1FallDelta=3;
    gsLightSwitch.usThermalLs.uMt2=84;
    gsLightSwitch.usThermalLs.uMt2FallDelta=5;
    gsLightSwitch.usThermalLs.uMt3=85;
    gsLightSwitch.usThermalLs.uMt3FallDelta=6;
#endif/* if (OEM==HP) */
}    /* initGlobOpt */

#endif/* if _PRJ_BOOT1 */

#if (_PRJ_BOOT2||_PRJ_NVME)
void SaveFWHistory(BYTE uFwSlot, BYTE uAction)
{
    VUFWHISTORY *upFWHistoryData=(void *)&garTsb0[16][0];
    WORD u16LeastIndex=0;
    WORD u16TableIndex=0;
    BYTE uarIntFwVersion1[8];
    BYTE uarIntFwVersion2[8];
    BYTE uSlot2PageOffset;

    // Raed FW Name first
    loadIspPageCore0(0x0B, cSysBlockIsp);
    copyCcmVal((BYTE *)uarIntFwVersion1, (BYTE *)&garTsb0[31][0x188], 8);
    uSlot2PageOffset=(cTotalIspCodeSize/gSectorPerPlaneH)+0x0B;
    loadIspPageCore0(uSlot2PageOffset, cSysBlockIsp);
    copyCcmVal((BYTE *)uarIntFwVersion2, (BYTE *)&garTsb0[31][0x188], 8);

    // Check Wpro exist
    if(gsWproInfo.u16arWproIdxPagePtr[cWproWriteUNC]!=c16BitFF)
    {
        readWproPageCore0(cWproWriteUNC, c16Tsb0SIdx, 0);
    }
    else
    {
        bopClrRam(c32Tsb0SAddr, gSectorPerPlaneH*512, 0, cClrTsb|cBopWait);
    }

    u16LeastIndex=upFWHistoryData->usVUFWHeadInfo.u16Index;

    // first init
    if(u16LeastIndex==0)
    {
        upFWHistoryData->usVUFWHeadInfo.u16PowerOnCnt=gsFtlDbg.u32PowerOnCnt;
        upFWHistoryData->usVUFWHeadInfo.uFwSlot=uFwSlot;
        upFWHistoryData->usVUFWHeadInfo.uAction=uAction;
        copyCcmVal(upFWHistoryData->usVUFWHeadInfo.uarSlot1FwVersion, uarIntFwVersion1, 8);
        copyCcmVal(upFWHistoryData->usVUFWHeadInfo.uarSlot2FwVersion, uarIntFwVersion2, 8);
    }

    u16LeastIndex++;
    upFWHistoryData->usVUFWHeadInfo.u16Index=u16LeastIndex;
    u16TableIndex=(u16LeastIndex-1)%cMaxFWHistoryNum;

    upFWHistoryData->usVUFWSlotInfo[u16TableIndex].u16Index=u16LeastIndex;
    upFWHistoryData->usVUFWSlotInfo[u16TableIndex].u16PowerOnCnt=gsFtlDbg.u32PowerOnCnt;
    upFWHistoryData->usVUFWSlotInfo[u16TableIndex].uFwSlot=uFwSlot;
    upFWHistoryData->usVUFWSlotInfo[u16TableIndex].uAction=uAction;
    copyCcmVal(upFWHistoryData->usVUFWSlotInfo[u16TableIndex].uarSlot1FwVersion, uarIntFwVersion1, 8);
    copyCcmVal(upFWHistoryData->usVUFWSlotInfo[u16TableIndex].uarSlot2FwVersion, uarIntFwVersion2, 8);
    progWproPageCore0(cWproWriteUNC, c16Tsb0SIdx);
} /* SaveFWHistory */

#endif /* if (_PRJ_BOOT2||_PRJ_NVME) */







