// -----------------------------------------------------------------------
//  OEM definition
// -----------------------------------------------------------------------
#define VERIFY     0x01
#define DELL       0x02
#define LENOVO     0x03
#define LENOVO_LBG LENOVO
#define LENOVO_EBG LENOVO
#define HP         0x04
#define STD        0x05
#define SAMSUNG    0x06
#define GC         0x07
#define PLEXTOR    0x08
#define IS         0x09
#define LITEON_GC  0x0A
#define ASUS       0x0B

