







#include "inc/TypeDef.h"
#include "inc/Option.h"
#include "inc/ProType.h"
#include "inc/Reg.h"

#if (!_ICE_LOAD_ALL)
#pragma default_function_attributes = @ ".BOP"
#endif

#if (!_CPUID)
void initBop()
{
    BYTE uQuickSrchCnt;

    // rmSetNbsEnBit;
    rmSetSrchRgnAddr0((LWORD)garCacheF2hTab);

    // rmSetSrchRgnLen0(g16MaxCachePageNum);
    // if(g16TotalTlcPgPerF2hTab>g16TotalPgPerF2hTab)
    // {
    //     rmSetSrchRgnLen0(g16TotalTlcPgPerF2hTab);
    // }
    // else
    // {
    rmSetSrchRgnLen0(g16TotalPgPerF2hTab);
    // }

    rmSetSrchDir(cSrchTsb, cSrchTsb, cSrchCcm);    // now only single region
    rmSetNbsMaskHiVal(0);    // default 4b
    rmSetSrchDefault;

    // for target initial value is 0, init target value
    for(uQuickSrchCnt=0; uQuickSrchCnt<cQuickSrchSize; uQuickSrchCnt++)
    {
        rmSetSrchTgt(uQuickSrchCnt, 0xFFFFFFFF);
    }
}    /* initBop */

#endif/* if (!_CPUID) */

// Avoid TSB code jump code.
void bopClrRamForTsbCode(LWORD u32RamSAddr, LWORD u32Len, LWORD u32Patn, WORD u16Opt)
{
    bopClrRam(u32RamSAddr, u32Len, u32Patn, u16Opt);
}

void bopClrRam(LWORD u32RamSAddr, LWORD u32Len, LWORD u32Patn, WORD u16Opt)
{
#if _GREYBOX
    if(u32RamSAddr>c32DramAddr)
    {
        for(LWORD u32Loop=0; u32Loop<u32Len; u32Loop+=4)
        {
            *(LWORD *)(u32RamSAddr+u32Loop)=u32Patn;
        }
    }
    else
#endif
    {
        while(rmChkBopNbsBz)
            ;

        while(rmChkBopCmdFifoFull)
            ;

        if(u16Opt&cBopWait)
        {
            while(rmChkBopBz)
                ;
        }

        rmRstBopParam;
        rmSetBopFillMo;
        rmBopDisAutoAes;

        rmSetDmaPatn(u32Patn);

        if(u16Opt&cBopEnCrc)
        {
            rmForceEnCrcfun;

            if(u16Opt&cBopGenCrc)
            {
                rmBopCrcGenEnable;
                rmBopAutoAesLba(gsE2eInfo.u32GenerateLba);
                rmBopAutoAesExtLba(0);
            }
        }

#if _ENABLE_RAID
        // rmRstBopRaidFlag;
#endif

        switch(u16Opt&cLoNibble)
        {
            case cClrCore0Iccm:
                rmSetBopDataDir(cBopTsb2Bvci);
                rmSetBopCcm;
                rmEnSysBop2Ccm;
                u32RamSAddr+=c32IccmSAddr0;    // constant need use macro instead
                break;

            case cClrCore0Dccm:
                // invalidDCache();
                rmSetBopDataDir(cBopTsb2Bvci);
                rmSetBopCcm;
                rmEnSysBop2Ccm;
                u32RamSAddr+=c32DccmSAddr0;
                break;

            case cClrCore1Iccm:
                // flushDCache();
                rmSetBopDataDir(cBopTsb2Bvci);
                rmSetBopCcm;
                rmEnSysBop2Ccm;
                u32RamSAddr+=c32IccmSAddr1;
                break;

            case cClrCore1Dccm:
                rmSetBopDataDir(cBopTsb2Bvci);
                rmSetBopCcm;
                rmEnSysBop2Ccm;
                u32RamSAddr+=c32DccmSAddr1;
                break;

            case cClrStcm:
                // invalidDCache();
                rmSetBopDataDir(cBopTsb2Bvci);
                rmSetBopCcm;
                rmEnSysBop2Ccm;
#if _CPUID
                u32RamSAddr+=c32StcmSAddr1;
#else
                u32RamSAddr+=c32StcmSAddr0;
#endif
                break;

            case cClrTsb:
                // flushDCache();
                rmSetBopDataDir(cBopBvci2Tsb);
                u32RamSAddr-=c32Tsb0SAddr;
                break;

            case cClrDram:
                // flushDCache();
                rmSetBopDram;
                rmSetBopDataDir(cBopTsb2Bvci);
                break;

            default:
                break;
        }    /* switch */

        rmSetBopDesAddr(u32RamSAddr);
        rmSetBopXfrLen(u32Len);

        if(u16Opt&cBopTsbFlag)
        {
            rmBopAutoFlagDes;

            if(u16Opt&cBopRaidFlag)
            {
                rmEnBopRaidFlagDes;
            }
        }

        /*
           *  if (uOpt&cBopTsbFlag)
           *  {
           *      rmDisBopTBypass;
           *  }
           *  if (rmChkSysDiv2)
           *  {
           *      rmEnBopDmaClkSync;
           *  }
           *  else
           *  {
           *      rmDisBopDmaClkSync;
           *  }
           */

        if(u16Opt&cBopWait)
        {
            rmTrigBopOp(cDisBopPause, cBopDmaOp);

            while(rmChkBopBz)
                ;
        }
        else
        {
            rmTrigBopOp(cDisBopPause, cBopDmaOp);
        }
    }
}    /* bopClrRam */

/************************************************************************************************
   * function name : void bopCopyRam(LWORD u32RamDAddr, LWORD u32RamSAddr, LWORD u32Len, BYTE uOpt)
   * input         :
   *                 u32RamDAddr - source memory start address
   *                 u32RamSAddr - destination memory start address
   *                 u32Len - move size, unit:1Byte
   *                 uOpt -
   *                        Low  nibble - direction
   *                        Hign nibble - Bit4 Wait
   *                                      Bit6 source buuffer flag handshake
   *                                      Bit7 destination buuffer flag handshake
   * output        : none
   * descriptor    : move data from source to destination memory by DMA (Bop Copy)
   *
   *************************************************************************************************/

void bopCopyRam(LWORD u32RamDAddr, LWORD u32RamSAddr, LWORD u32Len, WORD u16Opt)
{
#if _GREYBOX
    if((u32RamDAddr>c32DramAddr)&&(u32RamSAddr<c32DramAddr))    // Tsb2Dram
    {
        for(LWORD u32Loop=0; u32Loop<u32Len; u32Loop+=4)
        {
            *(LWORD *)(u32RamDAddr+u32Loop)=*(LWORD *)(u32RamSAddr+u32Loop);
        }
    }
    else if((u32RamSAddr>c32DramAddr)&&(u32RamDAddr<c32DramAddr))    // Dram2Tsb
    {
        for(LWORD u32Loop=0; u32Loop<u32Len; u32Loop+=4)
        {
            *(LWORD *)(u32RamDAddr+u32Loop)=*(LWORD *)(u32RamSAddr+u32Loop);
        }
    }
    else
#endif/* if 0 */
    {
        while(rmChkBopNbsBz)
            ;

        while(rmChkBopCmdFifoFull)
            ;

        if(u16Opt&cBopWait)
        {
            while(rmChkBopBz)
                ;
        }

        if(rmChkBopCompMo)
        {
            rmRstBopwithCompMo;
        }
        else
        {
            rmRstBopParam;

#if _ENABLE_RAID
            // rmRstBopRaidFlag;
#endif
        }

        if(u16Opt&cBopEnCrc)
        {
            rmForceEnCrcfun;

            if(u16Opt&cBopGenCrc)
            {
                rmBopCrcGenEnable;
                rmBopAutoAesLba(gsE2eInfo.u32GenerateLba);
                rmBopAutoAesExtLba(0);
            }
            else if(u16Opt&cBopCmpCrc)
            {
                rmBopCrcCompareEnable;
                rmBopAutoAesLba(gsE2eInfo.u32CompareLba);
                rmBopAutoAesExtLba(0);
            }
        }

        switch(u16Opt&cLoNibble)
        {
            case cCopyTsb2Tsb:
                rmSetBopDataDir(cBopTsb2Tsb);
                u32RamSAddr-=c32Tsb0SAddr;
                u32RamDAddr-=c32Tsb0SAddr;

                break;

#if 0    // (_INITDRAM||_GREYBOX)
            case cCopyTsb2Dram:
                rmSetBopDataDir(cBopTsb2Bvci);
                rmSetBopDram;
                u32RamSAddr-=c32Tsb0SAddr;
                u32RamDAddr-=c32DramAddr;
                // r16BopCtrl[0x2A/2]=0x200;
                // r16BopCtrl[0x56/2]=0x100;
                break;

            case cCopyDram2Tsb:
                rmSetBopDataDir(cBopBvci2Tsb);
                rmSetBopDram;
                u32RamSAddr-=c32DramAddr;
                u32RamDAddr-=c32Tsb0SAddr;
                break;

            case cCopyDram2Dram:
                rmSetBopDataDir(cBopBvci2Bvci);
                rmSetBopDram;
                u32RamSAddr-=c32DramAddr;
                u32RamDAddr-=c32DramAddr;
                break;
#endif/* if ((_INITDRAM)||(_GREYBOX)) */
            case cCopyTsb2Dccm:
                // invalidDCache();
                rmSetBopDataDir(cBopTsb2Bvci);
                rmSetBopCcm;
                rmEnBop2Dccm;
                u32RamSAddr-=c32Tsb0SAddr;
                u32RamDAddr+=c32DccmSAddr0;    // KT - CPU slave port decode address translation
                break;

            case cCopyDccm2Tsb:
                // flushDCache();
                rmSetBopDataDir(cBopBvci2Tsb);
                rmSetBopCcm;
                rmEnBop2Dccm;
                u32RamSAddr+=c32DccmSAddr0;
                u32RamDAddr-=c32Tsb0SAddr;
                break;

            case cCopyIccm2Tsb:
                rmSetBopDataDir(cBopBvci2Tsb);
                rmSetBopCcm;
                rmEnBop2Iccm;
                u32RamSAddr+=c32IccmSAddr0;
                u32RamDAddr-=c32Tsb0SAddr;
                break;

            case cCopyTsb2Iccm:
                rmSetBopDataDir(cBopTsb2Bvci);
                rmSetBopCcm;
                rmEnBop2Iccm;
                u32RamSAddr-=c32Tsb0SAddr;
                u32RamDAddr+=c32IccmSAddr0;
                break;

            case cCopyTsb2Stcm:
                rmSetBopDataDir(cBopTsb2Bvci);
                rmSetBopCcm;
                rmEnBop2Dccm;
                u32RamSAddr-=c32Tsb0SAddr;
#if _CPUID
                u32RamDAddr+=c32StcmSAddr1;
#else
                u32RamDAddr+=c32StcmSAddr0;
                // u32RamDAddr += 0xFC0000;    // KT - CPU slave port decode address translation
#endif
                break;

            case cCopyStcm2Tsb:
                rmSetBopDataDir(cBopBvci2Tsb);
                rmSetBopCcm;
                rmEnBop2Dccm;
#if _CPUID
                u32RamSAddr+=c32StcmSAddr1;
#else
                u32RamSAddr+=c32StcmSAddr0;
                // u32RamSAddr += 0xFC0000;    // KT - CPU slave port decode address translation
#endif
                u32RamDAddr-=c32Tsb0SAddr;
                break;

            case cCopyTsb2Cpu1Dccm:
                rmSetBopDataDir(cBopTsb2Bvci);
                rmSetBopCcm;
                rmEnBop2Dccm;
                u32RamSAddr-=c32Tsb0SAddr;
                u32RamDAddr+=c32DccmSAddr1;    // KT - CPU slave port decode address translation
                break;

            case cCopyCpu1Dccm2Tsb:
                rmSetBopDataDir(cBopBvci2Tsb);
                rmSetBopCcm;
                rmEnBop2Dccm;
                u32RamSAddr+=c32DccmSAddr1;    // KT - CPU slave port decode address translation
                u32RamDAddr-=c32Tsb0SAddr;
                break;

            case cCopyCpu1Iccm2Tsb:
                rmSetBopDataDir(cBopBvci2Tsb);
                rmSetBopCcm;
                rmEnBop2Iccm;
                u32RamSAddr+=c32IccmSAddr1;
                u32RamDAddr-=c32Tsb0SAddr;
                break;

            case cCopyTsb2Cpu1Iccm:
                rmSetBopDataDir(cBopTsb2Bvci);
                rmSetBopCcm;
                rmEnBop2Iccm;
                u32RamSAddr-=c32Tsb0SAddr;
                u32RamDAddr+=c32IccmSAddr1;
                break;

            default:
                break;
        }    /* switch */

        rmSetBopSrcAddr(u32RamSAddr);
        rmSetBopDesAddr(u32RamDAddr);
        rmSetBopXfrLen(u32Len);

        if(u16Opt&cBopSrcAutoBuf)
        {
            rmBopAutoFlagSrc;
        }
        else
        {
            rmBopBypassSrc;
        }

        if(u16Opt&cBopDesAutoBuf)
        {
            rmBopAutoFlagDes;
        }
        else
        {
            rmBopBypassDes;
        }

        /*
           *  if (((uOpt&cLoNibble)>=cCopyTsb2Dccm)&&rmChkSysDiv2)
           *  {
           *      rmEnBopDmaClkSync;
           *  }
           *  else
           *  {
           *      rmDisBopDmaClkSync;
           *  }
           */
        rmTrigBopOp(cDisBopPause, cBopDmaOp);

        if(u16Opt&cBopWait)
        {
            while(rmChkBopBz)
                ;
        }
    }
}    /* bopCopyRam */

WORD bopSrchRam(LWORD u32RamAddr, LWORD u32SrchVal, LWORD u32MaskVal, WORD u16StartUnit, WORD u16UnitLen, WORD u16Opt)
{
    // flushDCache();
    while(rmChkBopNbsBz)
        ;

    while(rmChkBopCmdFifoFull)
        ;

    if(u16Opt&cBopWait)
    {
        while(rmChkBopBz)
            ;
    }

    rmRstBopParam;
    rmBopDisAutoAes;
    rmClrSrchRslVal;
    rmSetSrchMsk(u32MaskVal);

    if(u16Opt&cBopSrchDccm)
    {
        rmSetBopCcm;
        rmEnBop2Dccm;
        rmSetBopDataDir(cBopBvci2Tsb);
#if _CPUID
        u32RamAddr+=c32DccmSAddr1;
#else
        u32RamAddr+=c32DccmSAddr0;
#endif
    }
    else if(u16Opt&cBopSrchIccm)
    {
        rmSetBopCcm;
        rmEnBop2Iccm;
        rmSetBopDataDir(cBopBvci2Tsb);
#if _CPUID
        u32RamAddr+=c32IccmSAddr1;
#else
        u32RamAddr-=c32IccmSAddr0;
#endif
    }
    else if(u16Opt&cBopSrchStcm)
    {
        rmSetBopDataDir(cBopBvci2Tsb);
        rmSetBopCcm;
        rmEnBop2Dccm;
#if _CPUID
        u32RamAddr+=c32StcmSAddr1;
#else
        u32RamAddr+=c32StcmSAddr0;
#endif
    }
    else
    {
        rmSetBopDataDir(cBopTsb2Bvci);
        u32RamAddr-=c32Tsb0SAddr;
    }

    rmSetBopSrcAddr(u32RamAddr);
    rmSetBopDesAddr(u16StartUnit);
    rmSetBopXfrLen(u16UnitLen);
    rmSetSrchThVal(u32SrchVal);
    rmSetSrchMode(u16Opt&cLoNibble);

    if(u16Opt&cBopSrchSkip)
    {
        rmEnSrchSkip;
    }
    else
    {
        rmDisSrchSkip;
    }

    if(u16Opt&cBopWait)
    {
        rmTrigBopOp(0, cBopSrchOp);

        while(rmChkBopBz)
            ;

        if(!(u16Opt&cBopNotRstFlag))
        {
            rmSetSrchDefault;
        }

        if(rmChkSrchValFind)
        {
            return rmGetSrchRslOfst;
        }

        // else
        // {
        //    return 0xFFFF;
        // }
    }
    else
    {
        rmTrigBopOp(0, cBopSrchOp);
    }

    return 0xFFFF;
}    /* bopSrchRam */

#if (!_CPUID)
BYTE bopDmaComp(LWORD u32RamDAddr, LWORD u32RamSAddr, LWORD u32Len, WORD u16Opt)
{
    BYTE uCompResult=cFail;

    rmSetBopCompMo;
    bopCopyRam(u32RamDAddr, u32RamSAddr, u32Len, u16Opt);

    while(rmChkBopBusy)
        ;

    rmBopResume;

    /*
       *  This bye is valid when the DMA operation is finished in the compare mode.
       *  1: compared data are the same.
       *  0: compared data are different.
       */
    if(rmChkDmaComp)
    {
        uCompResult=cSuccess;
    }

    rmClrBopCompMo;
    return uCompResult;
}    /* bopDmaComp */

#endif/* if (!_CPUID) */

#if (!_ICE_LOAD_ALL)
#pragma default_function_attributes =
#endif







