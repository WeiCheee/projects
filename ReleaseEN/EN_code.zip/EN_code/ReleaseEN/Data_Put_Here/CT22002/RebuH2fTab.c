







// uOpt

// Bit1: Load to data buffer 0 + H2f table size
#if (!_HwPlane2SprIssue)
BYTE getH2fTabBlkPageInfo(WORD u16FBlock, WORD u16FPage, BLKSPRINFO *upBlkSprInfo, BYTE uOpt)
{
    BLKSPRINFO usBlkSprInfo;
    ADDRINFO usTmpAddrInfo[2];
    WORD u16BufPtr;
    // BYTE uPageOfst, uFail=0;
    BYTE uPlaneAddr;
    BYTE uLoop;

    gsRdlinkInfo.ubH2fTabRefreshF=0;

    if(uOpt&cBit1)
    {
        u16BufPtr=c16Tsb0SIdx+g16H2fTabSctrSize;
    }
    else
    {
        u16BufPtr=c16Tsb0SIdx;
    }

    rstUNCStsCore0();

    for(uLoop=0; uLoop<2; uLoop++)
    {
        usTmpAddrInfo[uLoop].u16FBlock=u16FBlock;
        usTmpAddrInfo[uLoop].u32FPageNoTran=(u16FPage*gPage4kPerH2fTab)+(uLoop*c4kNumPerPage);
        tranAddrInfo(&usTmpAddrInfo[uLoop]);
        setFLAddrActCh(usTmpAddrInfo[uLoop].uCh, &usTmpAddrInfo[uLoop]);
        gSectorH=0;
        gPlaneAddr=0;
        mSetFRwParam(u16BufPtr, gSectorPerPageH, c16Bit0|c16Bit14|c16Bit15, cReadCmdAle);
        assignFreeBtSrcAddrInfo();
    }

    waitCmdAllDone(cWaitTrigRCnt);

    // fillCcmVal((BYTE *)&gPlaneUNCSts, cMaxChNum, 0);

    for(uLoop=0; uLoop<2; uLoop++)
    {
        setFLAddrActCh(usTmpAddrInfo[uLoop].uCh, &usTmpAddrInfo[uLoop]);
        mSetFRwParam(u16BufPtr, gSectorPerPageH, c16Bit0|c16Bit2|c16Bit4|c16Bit5|c16Bit10|c16Bit15, cReadData);
        gSectorH=0;
        gPlaneAddr=0;

        // waitChCeBz(usTmpAddrInfo[uLoop].uCh, usTmpAddrInfo[uLoop].uIntlvAddr, 0);

        // for(uPlaneAddr=0; uPlaneAddr<gPlaneNum; uPlaneAddr++)
        // {
        //    gPlaneAddr=uPlaneAddr;
        //    flashReadPage();
        // }

        // flashReadPage();

        // setBzInfo(cReadData, uCh, usTmpAddrInfo.uIntlvAddr);

        assignFreeBtSrcAddrInfo();
        u16BufPtr+=gSectorPerPageH;
    }

    // for(uLoop=0; uLoop<2; uLoop++)
    // {
    //    setFLAddrActCh(usTmpAddrInfo[uLoop].uCh, &usTmpAddrInfo[uLoop]);
    //    jdgReadRetry(&usTmpAddrInfo[uLoop], 0);
    // }
    waitCmdAllDone(cWaitTrigRCnt|cWaitCmdBz);    // (F) Ecc Fail use /*|c16Bit15*/ to do
    // releaseBtSrcAddrInfo();

    for(uLoop=0; uLoop<2; uLoop++)
    {
        setFLAddrActCh(usTmpAddrInfo[uLoop].uCh, &usTmpAddrInfo[uLoop]);

        for(uPlaneAddr=0; uPlaneAddr<gPlaneNum; uPlaneAddr++)
        {
            if(!mChkBitMask(gPlaneUNCSts[usTmpAddrInfo[uLoop].uCh], uPlaneAddr))
            {
                getSprByte(&usBlkSprInfo, uPlaneAddr);

                if(mGetMetaH2fPgPtr(usBlkSprInfo)!=u16FPage)
                {
                    debugLoop();
                }

                if((mGetMetaBlockId(usBlkSprInfo)!=cH2fTableID)    /*||mChkSporRetryVth(usTmpAddrInfo.uCh, usTmpAddrInfo.uPlaneAddr)*/)
                {
                    return cFalse;
                }
            }
            else
            {
                return cFalse;
            }
        }
    }

    copyCcmVal((BYTE *)upBlkSprInfo, (BYTE *)&usBlkSprInfo, sizeof(usBlkSprInfo));
    return cTrue;
}    /* getH2fTabBlkPageInfo */

#else/* if (!_HwPlane2SprIssue) */
BYTE getH2fTabBlkPageInfo(WORD u16FBlock, WORD u16FPage, BLKSPRINFO *upBlkSprInfo, BYTE uOpt)
{
    BLKSPRINFO usBlkSprInfo;
    ADDRINFO usTmpAddrInfo;
    WORD u16BufPtr;
    BYTE uPageOfst;

    if(uOpt&cBit1)
    {
        u16BufPtr=c16Tsb0SIdx+g16H2fTabSctrSize;
    }
    else
    {
        u16BufPtr=c16Tsb0SIdx;
    }

    rstUNCStsCore0();

    for(uPageOfst=0; uPageOfst<gTotalPlaneOfH2fTab; uPageOfst+=2)
    {
        usTmpAddrInfo.u16FBlock=u16FBlock;
        usTmpAddrInfo.u32FPageNoTran=((LWORD)(u16FPage<<gsCacheInfo.uH2fTabProgSlotShift)+uPageOfst)*g4kNumPerPlane;
        tranAddrInfo(&usTmpAddrInfo);
        setFLAddrActCh(usTmpAddrInfo.uCh, &usTmpAddrInfo);
        gSectorH=0;
        mSetFRwParam(u16BufPtr, gSectorPerPlaneH<<1, c16Bit0|c16Bit4|c16Bit5|c16Bit10|c16Bit14|c16Bit15, cReadData);

        assignFreeBtSrcAddrInfo();

        waitCmdAllDone(cWaitTrigRCnt|cWaitCmdBz);    // (F) Ecc Fail use /*|c16Bit15*/ to do

        if(!gPlaneUNCSts[usTmpAddrInfo.uCh])
        {
            // setFLActCh(usTmpAddrInfo.uCh);

            getSprByte(&usBlkSprInfo, usTmpAddrInfo.uPlaneAddr);

            if(mGetMetaH2fPgPtr(usBlkSprInfo)!=u16FPage)
            {
                debugLoop(cGetH2fTabBlkPageInfo1);
            }

            if((mGetMetaBlockId(usBlkSprInfo)!=cH2fTableID)    /*||mChkSporRetryVth(usTmpAddrInfo.uCh, usTmpAddrInfo.uPlaneAddr)*/)
            {
                return cFalse;
            }

            gsRdlinkInfo.ubH2fTabRefreshF=1;    // always refresh H2f Table
            u16BufPtr+=(gSectorPerPlaneH<<1);
        }
        else
        {
            return cFalse;
        }
    }

    copyCcmVal((BYTE *)upBlkSprInfo, (BYTE *)&usBlkSprInfo, sizeof(usBlkSprInfo));
    return cTrue;
}    /* getH2fTabBlkPageInfo */

#endif/* getH2fTabBlkPageInfo */

BYTE chkLastH2fTab(WORD u16Fpage, WORD u16LastFreePagePtr)
{
    BYTE uLoop, uRet;

    for(uLoop=0; uLoop<cMaxUpdateH2fCnt; uLoop++)
    {
        if(u16Fpage==(u16LastFreePagePtr-(uLoop+1)))
        {
            break;
        }
    }

    if(uLoop<=(cMaxUpdateH2fCnt-1))
    {
        uRet=cTrue;
    }
    else
    {
        uRet=cFalse;
    }

    return uRet;
}    /* getH2fMemLocation */

void reFreshH2f(WORD u16SbufPtr, WORD u16HBlock)
{
    BYTE uDebugStopCnt=0;
    BLKSPRINFO usBlkSprInfo;

    while(cTrue)
    {
        mSetCacheInfoChangeFlag(cH2fChg);
        progH2fTableCore0(u16SbufPtr, u16HBlock, c16Bit0|c16Bit2|c16Bit15, cInreFreshH2f_00, cInBoot|cInBootWaitAllDie);

        if(    /*(u16HBlock&c16DropH2fTab)||*/
            getH2fTabBlkPageInfo(g16arH2fTabBlk[gsCacheInfo.uActH2fTabBlkIdx], gsCacheInfo.u16H2fTabFreePagePtr-1, &usBlkSprInfo, 0))
        {
            break;
        }

        uDebugStopCnt++;

        if(uDebugStopCnt>8)
        {
            debugLoop(cReFreshH2f1);
        }
    }
}    /* reFreshH2f */

#if 0
void setActiveH2fBlk()
{
    BYTE uLoop, uDebugStopCnt=0;
    WORD u16SbufPtr;
    BLKSPRINFO usBlkSprInfo;

    if(gsCacheInfo.uActH2fTabBlkIdx!=0xFF)
    {
        if(gsCacheInfo.u16H2fTabFreePagePtr<gsCacheInfo.u16H2fTabPagePerBlk3)
        {
            mClrCacheInfoFlag(cH2fTabBlockFull);
        }
        else
        {
            mSetCacheInfoFlag(cH2fTabBlockFull);
        }

        for(uLoop=0; uLoop<cMaxUpdateH2fCnt; uLoop++)
        {
            // if (g16arLast4H2fTab[uLoop]!=c16BitFF)
            if((gsRdlinkInfo.u16arMoveH2fTab[uLoop]!=c16BitFF)&&
               (gsRdlinkInfo.u16arMoveH2fTabPagePtr[uLoop]==g16arH2fTabPtr[gsRdlinkInfo.u16arMoveH2fTab[uLoop]])&&
               // (gsRdlinkInfo.uarMoveH2fTabBlkIdx[uLoop]==garH2fTabBlkIndex[gsRdlinkInfo.u16arMoveH2fTab[uLoop]])&&
               (gsRdlinkInfo.uarMoveH2fTabOptype[uLoop]!=cPwrOnDummyProg)&&
               (gsRdlinkInfo.uarMoveH2fTabOptype[uLoop]!=cBootProgData))
            {
                u16SbufPtr=setMemAddr(uLoop);

                while(cTrue)
                {
                    // gsCacheInfo.u15ActiveH2fTab=gsRdlinkInfo.u16arMoveH2fTab[uLoop];
                    mSetCacheInfoChangeFlag(cH2fChg);
                    progH2fTableCore0(u16SbufPtr, gsRdlinkInfo.u16arMoveH2fTab[uLoop], c16Bit0|c16Bit2|c16Bit15, cInsetActiveH2fBlk_00, 1);

                    // if(chkReadTabEcc(cWriteH2fTab))
                    if(getH2fTabBlkPageInfo(g16arH2fTabBlk[gsCacheInfo.uActH2fTabBlkIdx], gsCacheInfo.u16H2fTabFreePagePtr-1, &usBlkSprInfo, 0))
                    {
                        break;
                    }

                    uDebugStopCnt++;

                    if(uDebugStopCnt>8)
                    {
                        debugLoop();
                    }
                }
            }
        }

        if(gsCacheInfo.u16H2fTabFreePagePtr<gsCacheInfo.u16H2fTabPagePerBlk3)
        {
            mClrCacheInfoFlag(cH2fTabBlockFull);
        }
        else
        {
            mSetCacheInfoFlag(cH2fTabBlockFull);
        }
    }
    else
    {
        mSetCacheInfoFlag(cH2fTabBlockFull);
    }
}    /* setActiveH2fBlk */

#endif/* if 0 */
void rebuH2fTableInfo()
{
    BYTE uCmprResult;
    WORD u16Loop, u16Fpage;
    BLKSPRINFO usBlkSprInfo;
    BYTE uH2fTabValid;
    RLH2FTABQINFO *upH2fTabInfo;
    BYTE uLastH2fTabBlk;

#if _EN_VPC_SWAP
    BYTE uProgVPC=0;

    if((gsRdlinkInfo.ubCacheInfoValid&&(gsRdlinkInfo.u16ActH2fTabFblk!=c16BitFF))||gsRdlinkInfo.u16FoundH2fTabBlkCnt)
    {
        waitAllChCeBzBtCore0();
        uProgVPC=1;
        // read VPCnt
        g32arCacheBlkVpCnt=(volatile LWORD *)(cCacheBlkVpCntRebuH2FStrAddr);
#if _ENABLE_RAID
        popVPCfromRaidCore0(cCacheBlkVpCntRebuH2FStrIdx);
#else
        readWproPageCore0(cWproCacheBlkVpCnt, cCacheBlkVpCntRebuH2FStrIdx, 0);
#endif
    }
#endif/* if _EN_VPC_SWAP */

    saveRdTimeStamp(5);

    // rstLast4H2fTab();
    gsCacheInfo.uH2fTabBlockCnt=0;

    for(u16Loop=0; u16Loop<gMaxH2fTabBlkNum; u16Loop++)
    {
        if(g16arH2fTabBlk[u16Loop]!=c16BitFF)
        {
            gsCacheInfo.uH2fTabBlockCnt++;
        }
    }

    if(gsRdlinkInfo.ubCacheInfoValid)
    {
        if(gsRdlinkInfo.u16ActH2fTabFblk!=c16BitFF)
        {
            uH2fTabValid=cFalse;
            u16Fpage=0;

            while((uH2fTabValid==cFalse)&&(u16Fpage<gsCacheInfo.u16H2fTabPagePerBlk3))
            {
                uH2fTabValid=getH2fTabBlkPageInfo(gsRdlinkInfo.u16ActH2fTabFblk, u16Fpage, &usBlkSprInfo, 0);

                // debugLoop();

                if(uH2fTabValid==cTrue)
                {
                    gsCacheInfo.u32H2fTabBlkSerial=mGetMetaBlkSn(usBlkSprInfo);
                    gsCacheInfo.uActH2fTabBlkIdx=mGetMetaH2fIdx(usBlkSprInfo);
                    gsCacheInfo.u16H2fTabFreePagePtr=gsRdlinkInfo.u16H2fTabFreePagePtr;    // from cache info record

                    if(judgeSerial(g32BkH2fTabBlkSerial, mGetMetaBlkSn(usBlkSprInfo))==cSerialLarger)
                    {
#if _EN_KEEP_RW_ON_ERROR
                        relinkKeepRwonError((((BYTE)gsCacheInfo.uActH2fTabBlkIdx<<8)|cRebuH2fTableInfo1), gsRdlinkInfo.u16ActH2fTabFblk,
                                            (WORD)(mGetMetaBlkSn(usBlkSprInfo)&0xffff), (WORD)(mGetMetaBlkSn(usBlkSprInfo)>>16));

                        if(!gsRdlinkInfo.u16FoundH2fTabBlkCnt)
                        {
                            mSetCacheInfoFlag(cH2fTabBlockFull);
                        }

                        break;
#else
                        relinkSaveDummyQBAnalysis(gsCacheInfo.uActH2fTabBlkIdx, gsRdlinkInfo.u16ActH2fTabFblk,
                                                  (WORD)(mGetMetaBlkSn(usBlkSprInfo)>>16), (WORD)(mGetMetaBlkSn(usBlkSprInfo)&0xffff));
                        relinkSaveQBDummy(cRebuH2fTableInfo1);
#endif
                    }

                    if(gsRdlinkInfo.u16H2fTabFreePagePtr<gsCacheInfo.u16H2fTabPagePerBlk3)
                    {
                        // debugLoop();
                        uLastH2fTabBlk=((gsRdlinkInfo.u16FoundH2fTabBlkCnt==0)?(cTrue):(cFalse));
                        mClrCacheInfoFlag(cH2fTabBlockFull);
                        updateH2fTabWindow(gsRdlinkInfo.u16ActH2fTabFblk, gsRdlinkInfo.u16H2fTabFreePagePtr, uLastH2fTabBlk);
                        gsRdlinkInfo.ubSaveCacheInfo=1;
                    }
                }

                u16Fpage++;    // =gTotalPlaneOfH2fTab;
            }

            if(uH2fTabValid==cFalse)
            {
#if _EN_KEEP_RW_ON_ERROR    // Chief_20190305
                relinkKeepRwonError(cUpdateH2fTabWindowFail4, gsRdlinkInfo.u16ActH2fTabFblk, gsRdlinkInfo.u16H2fTabFreePagePtr,
                                    gsCacheInfo.u32H2fTabBlkSerial);
#else
                // setRebuAbnorInfo(c16Bit2);
                relinkSaveDummyQBAnalysis(gsRdlinkInfo.u16ActH2fTabFblk, gsRdlinkInfo.u16H2fTabFreePagePtr,
                                          (WORD)(gsCacheInfo.u32H2fTabBlkSerial>>16), (WORD)(gsCacheInfo.u32H2fTabBlkSerial&0xffff));
                relinkSaveQBDummy(cUpdateH2fTabWindowFail4);
#endif
            }
        }
        else if((gsCacheInfo.u32H2fTabBlkSerial==c32InitSerialVal)&&!gsRdlinkInfo.u16FoundH2fTabBlkCnt)    // 20190109_Louis
        {
            gsCacheInfo.u32H2fTabBlkSerial=g32BkH2fTabBlkSerial;
            NLOG(cLogBuild,
                 REBUH2FTAB_C,
                 2,
                 "ActH2fTabFblk is NULL, set BkH2fTabBlkSerial to gsCacheInfo! SN=0x%08x",
                 gsCacheInfo.u32H2fTabBlkSerial>>16,
                 gsCacheInfo.u32H2fTabBlkSerial);
        }
    }

    if(gsRdlinkInfo.u16FoundH2fTabBlkCnt!=0)
    {
        u16Loop=0;

        if(gsRdlinkInfo.ubCacheInfoValid)
        {
            for(; u16Loop<gsRdlinkInfo.u16FoundH2fTabBlkCnt; u16Loop++)
            {
                // uCmprResult=cmprWindowGroup(garH2fTabQ[garH2fTabQIndex[u16Loop]].u32H2fTabBlkSerial, gsCacheInfo.u32H2fTabBlkSerial);
                uCmprResult=judgeSerial(garH2fTabQ[garH2fTabQIndex[u16Loop]].u32H2fTabBlkSerial, gsCacheInfo.u32H2fTabBlkSerial);
                upH2fTabInfo=&garH2fTabQ[garH2fTabQIndex[u16Loop]];

                if(uCmprResult==cSerialSmaller)
                {
                    // if(!mChkMlcMoBit(upH2fTabInfo->u16FBlock))
#if !_EN_Always_DynamicMode
                    if(!mChkMlcMoBit(upH2fTabInfo->u16FBlock))
                    {
                        gsCacheInfo.u16SpareBlockCnt++;
                    }
                    else
                    {
                        gsCacheInfo.u16TLCSprBlockCnt++;
                    }
#endif
#if _EN_Dynamic_Fix_Boundary
                    if(gsFtlDbg.uStaticMode!=cEndStaticMode)
                    {
                        if(upH2fTabInfo->u16FBlock<g16StaticBound)
                        {
                            gsCacheInfo.u16SLCSpareCnt++;
                        }
                        else
                        {
                            gsCacheInfo.u16DynamicSpareCnt++;
                        }

#if _EN_Always_DynamicMode
                        gsCacheInfo.u16SpareBlockCnt++;
#endif
                    }
#endif
                }
                else
                {
                    break;
                }
            }
        }

        for(; u16Loop<gsRdlinkInfo.u16FoundH2fTabBlkCnt; u16Loop++)
        {
            upH2fTabInfo=&garH2fTabQ[garH2fTabQIndex[u16Loop]];
            uCmprResult=judgeSerial(g32arH2fTabBlkSn[upH2fTabInfo->u16Index], upH2fTabInfo->u32H2fTabBlkSerial);

            if(uCmprResult==cSerialLarger)
            {
                // Keep track for debug....
                setErrorBlock(upH2fTabInfo->u16FBlock, upH2fTabInfo->u16EraseCnt, 0x0012|c16Bit15);
            }
            else if(uCmprResult==cSerialSmaller)
            {
#if 1
                if((gsCacheInfo.u16H2fTabFreePagePtr<gsCacheInfo.u16H2fTabPagePerBlk3)&&(gsRdlinkInfo.u16ActH2fTabFblk!=c16BitFF))
                {
#if _EN_KEEP_RW_ON_ERROR
                    relinkKeepRwonError((((BYTE)gsCacheInfo.uActH2fTabBlkIdx<<8)|cRebuH2fTableInfo2), gsRdlinkInfo.u16ActH2fTabFblk,
                                        (WORD)(gsCacheInfo.u16H2fTabFreePagePtr), (WORD)(gsRdlinkInfo.u16FoundH2fTabBlkCnt));
#else
                    relinkSaveDummyQBAnalysis(gsCacheInfo.uActH2fTabBlkIdx, gsRdlinkInfo.u16ActH2fTabFblk,
                                              (WORD)(gsCacheInfo.u16H2fTabFreePagePtr), (WORD)(gsRdlinkInfo.u16FoundH2fTabBlkCnt));
                    relinkSaveQBDummy(cRebuH2fTableInfo2);    // last H2f Tab is not closed
#endif
                }
#endif

                if(g16arH2fTabBlk[upH2fTabInfo->u16Index]!=c16BitFF)
                {
                    // push to SpareBlock
                    // gsCacheInfo.uH2fTabBlockCnt--;
                    pushSpareBlockCore0(g16arH2fTabBlk[upH2fTabInfo->u16Index], cPushNotErase);
/*
   *                  if(!mChkSlcSkipBit(upH2fTabInfo->u16FBlock))
   *                  {
   *                      gsCacheInfo.u16SpareBlockCnt++;
   *                  }
   *                  else
   *                  {
   *                      gsCacheInfo.u16TLCSprBlockCnt++;
   *                  }
   *
   *                  mClrPopDeniedF(garH2fTabQ[garH2fTabQIndex[u16Loop]].u16FBlock);
   */
                }
                else
                {
                    gsCacheInfo.uH2fTabBlockCnt++;
                }

                if((upH2fTabInfo->u16FBlock<g16FirstFBlock)||(upH2fTabInfo->u16FBlock>=g16TotalFBlock))    // while(upH2fTabInfo->u16FBlock<g16FirstFBlock);
                                                                                                           // while(upH2fTabInfo->u16FBlock>=g16TotalFBlock);
                {
#if _EN_KEEP_RW_ON_ERROR    // Chief_20190305
                    relinkKeepRwonError(cUpdateH2fTabWindowFail5, upH2fTabInfo->u16FBlock, 0x01, 0x00);
                    continue;
#else
                    relinkSaveDummyQBAnalysis(upH2fTabInfo->u16FBlock, 0, 0, 0);
                    relinkSaveQBDummy(cUpdateH2fTabWindowFail5);
#endif
                }

                if(judgeSerial(g32BkH2fTabBlkSerial, upH2fTabInfo->u32H2fTabBlkSerial)==cSerialLarger)
                {
#if _EN_KEEP_RW_ON_ERROR
                    relinkKeepRwonError((((BYTE)upH2fTabInfo->u16Index<<8)|cRebuH2fTableInfo3), upH2fTabInfo->u16FBlock,
                                        (WORD)(upH2fTabInfo->u32H2fTabBlkSerial&0xffff), (WORD)(upH2fTabInfo->u32H2fTabBlkSerial>>16));

                    if(u16Loop==(gsRdlinkInfo.u16FoundH2fTabBlkCnt-1))
                    {
                        mSetCacheInfoFlag(cH2fTabBlockFull);
                        return;
                    }
                    else
                    {
                        continue;
                    }
#else
                    relinkSaveDummyQBAnalysis(((BYTE)upH2fTabInfo->u16Index), upH2fTabInfo->u16FBlock,
                                              (WORD)(upH2fTabInfo->u32H2fTabBlkSerial>>16), (WORD)(upH2fTabInfo->u32H2fTabBlkSerial&0xffff));
                    relinkSaveQBDummy(cRebuH2fTableInfo3);
#endif
                }

                // Use founded to instead of original
                g16arH2fTabBlk[upH2fTabInfo->u16Index]=upH2fTabInfo->u16FBlock;
                g32arH2fTabBlkSn[upH2fTabInfo->u16Index]=upH2fTabInfo->u32H2fTabBlkSerial;
                gsCacheInfo.u32H2fTabBlkSerial=upH2fTabInfo->u32H2fTabBlkSerial;
                gsCacheInfo.uActH2fTabBlkIdx=upH2fTabInfo->u16Index;
                // debugLoop();
                mSetPoppedBitRL(upH2fTabInfo->u16FBlock);
                mSetGlobEraseCntRL(upH2fTabInfo->u16FBlock, upH2fTabInfo->u16EraseCnt);
                setGlobEraseCnt1Blk(upH2fTabInfo->u16FBlock, g16arTempGlobEraseCnt[upH2fTabInfo->u16FBlock], 1);
                uLastH2fTabBlk=((u16Loop==(gsRdlinkInfo.u16FoundH2fTabBlkCnt-1))?(cTrue):(cFalse));
                mClrCacheInfoFlag(cH2fTabBlockFull);
                updateH2fTabWindow(upH2fTabInfo->u16FBlock, 0, uLastH2fTabBlk);
                gsRdlinkInfo.ubSaveCacheInfo=1;
            }
            else    // uCmprResult==cGrpEqual
            {
                // Keep track for debug....
                setErrorBlock(upH2fTabInfo->u16FBlock, upH2fTabInfo->u16EraseCnt, 0x0014|c16Bit15);
            }
        }

        // gsCacheInfo.u15ActiveH2fTab=c15BitFF;
        mClrCacheInfoChangeFlag(cH2fChg);
    }

    gsRdlinkInfo.uH2fTabBlockCnt=gsCacheInfo.uH2fTabBlockCnt;

#if _EN_VPC_SWAP
    if(uProgVPC)
    {
        waitAllChCeBzBtCore0();
#if _ENABLE_RAID
        g32arCacheBlkVpCnt=(volatile LWORD *)(cCacheBlkVpCntRebuH2FStrAddr);
        pushVPCtoRaidCore0(cCacheBlkVpCntRebuH2FStrIdx);
#else
        // prevent swap WPRO ram overwrite
        bopCopyRam(cCacheBlkVpCntEndRebuH2FStrAddr,
                   (LWORD)g32arCacheBlkVpCnt,
                   c32CacheBlkVpCntVarSize,
                   cCopyTsb2Tsb|cBopWait);
        g32arCacheBlkVpCnt=(volatile LWORD *)(cCacheBlkVpCntEndRebuH2FStrAddr);
        // Prog Changed VPCnt

        progWproPageCore0(cWproCacheBlkVpCnt, cCacheBlkVpCntEndRebuH2FStrIdx);
#endif
    }
#endif/* if _EN_VPC_SWAP */

    saveRdTimeStamp(6);

    // if(gsCacheInfo.uH2fTabBlockCnt)
    // {
    //    // debugLoop();
    //    setActiveH2fBlk();    // copy last 4 good H2f table to new flash address
    // }
}    /* rebuH2fTableInfo */

BYTE chkRefreshH2f(WORD u16Hblock, WORD u16PagePtr)
{
    BYTE uLoop;
    BYTE uRet=cFalse;

    for(uLoop=0; uLoop<cMaxUpdateH2fCnt; uLoop++)
    {
        if((u16Hblock==gsRdlinkInfo.u16arMoveH2fTab[uLoop])&&(u16PagePtr==gsRdlinkInfo.u16arMoveH2fTabPagePtr[uLoop]))
        {
            uRet=cTrue;
            break;
        }
    }

    return uRet;
}

void addRefreshH2f(WORD u16Hblock, WORD u16PagePtr)
{
    if(gsRdlinkInfo.uRefreshH2fCnt<cMaxUpdateH2fCnt)
    {
        gsRdlinkInfo.u16arMoveH2fTab[gsRdlinkInfo.uRefreshH2fCnt]=u16Hblock;
        gsRdlinkInfo.u16arMoveH2fTabPagePtr[gsRdlinkInfo.uRefreshH2fCnt]=u16PagePtr;
        gsRdlinkInfo.uRefreshH2fCnt++;
    }
    else
    {
#if _EN_KEEP_RW_ON_ERROR
        relinkKeepRwonError(cAddRefreshH2f, u16Hblock, u16PagePtr, (WORD)gsRdlinkInfo.uRefreshH2fCnt);
#else
        relinkSaveDummyQBAnalysis(u16Hblock, u16PagePtr, (WORD)gsRdlinkInfo.uRefreshH2fCnt, 0);
        relinkSaveQBDummy(cAddRefreshH2f);
#endif
    }
}    /* addRefreshH2f */

void updateH2fTabWindow(WORD u16H2fTabFBlock, WORD u16StartPage, BYTE uLastH2fTabBlk)
{
    WORD u16Fpage, u16Hblock;
    BYTE uActH2fTabBlkIdx;
    BLKSPRINFO usBlkSprInfo, usBlkSprInfoOrg;
    BYTE uAbnorF;    // , uRefreshH2fTabF;
    WORD u16LastFreePagePtr;

    // handle risky page
    WORD u16RiskFpage, u16HdlOpH2fPagePtr, u16FirstEmptyPgPtr;
    // LWORD u32CopyAddr;
    BYTE uBkActH2fTabBlkIdx=gsCacheInfo.uActH2fTabBlkIdx;

    rstLastH2fTab();

#if (!_HwPlane2SprIssue)
    u16LastFreePagePtr=getLastPageInfo(u16H2fTabFBlock, cH2fTableID, &usBlkSprInfo, cMaxH2fTabCntOnce);
#else
    // u16LastFreePagePtr=getLastPageInfoInv(u16H2fTabFBlock, cH2fTableID, cUseSlcMode, &usBlkSprInfo);
    u16LastFreePagePtr=getFirstFullPage(u16H2fTabFBlock, cH2fTableID, cUseSlcMode, &usBlkSprInfo, &u16FirstEmptyPgPtr, 0);    // 20190305_ChrisSu
#endif

    gsRdlinkInfo.u16LastH2fTabFblk=u16H2fTabFBlock;

    while(u16LastFreePagePtr==c16BitFF)
        ;

    gsRdlinkInfo.u16LastH2fTabFreePage=gsCacheInfo.u16H2fTabFreePagePtr=u16LastFreePagePtr>>gsCacheInfo.uH2fTabProgSlotShift;

    u16RiskFpage=u16LastFreePagePtr/gTotalIntlvChPlaneNum;
    u16HdlOpH2fPagePtr=((u16RiskFpage/cSubBlockNum+cHdlOpWLNum)*cSubBlockNum)*gTotalIntlvChPlaneNum>>gsCacheInfo.uH2fTabProgSlotShift;

    while((gsCacheInfo.u16H2fTabFreePagePtr<gsCacheInfo.u16H2fTabPagePerBlk3)&&(gsCacheInfo.u16H2fTabFreePagePtr<u16HdlOpH2fPagePtr))    //
    {
        // padding dummy page
        mSetCacheInfoChangeFlag(cH2fChg);
        progH2fTableCore0(c16Tsb0SIdx, c16BitFF, c16Bit0|c16Bit2|c16Bit15, cInupdateH2fTabWindow_00, cInBoot|cInBootWaitAllDie);
        // waitCmdAllDone(cWaitTrigWCnt|cWaitCmdBz);
        // gsCacheInfo.u16H2fTabFreePagePtr++;
    }

    if(gsCacheInfo.u16H2fTabFreePagePtr>=gsCacheInfo.u16H2fTabPagePerBlk3)
    {
        mSetCacheInfoFlag(cH2fTabBlockFull);
    }

    for(u16Fpage=u16StartPage; u16Fpage<gsRdlinkInfo.u16LastH2fTabFreePage; u16Fpage++)    // =gTotalPlaneOfH2fTab)//u16LastFreePagePtr?
    {
        if(getH2fTabBlkPageInfo(u16H2fTabFBlock, u16Fpage, &usBlkSprInfo, 0)==cTrue)
        {
            if(mGetMetaOpTyp(usBlkSprInfo)!=cPwrOnDummyProg)
            {
                gsRdlinkInfo.u16UpdH2fTabPageCnt++;
                uAbnorF=0;

                u16Hblock=mGetMetaTabIdx(usBlkSprInfo);
                uActH2fTabBlkIdx=mGetMetaH2fIdx(usBlkSprInfo);

                if(g16arH2fTabPtr[u16Hblock&~c16DropH2fTab]!=c16H2FTabInitValue)    // !mChkH2fTabNullF(u16Hblock&~c16DropH2fTab))
                {
                    if((g16arH2fTabBlk[mGetH2fTabBlkIndex(u16Hblock&~c16DropH2fTab)]==u16H2fTabFBlock)&&
                       (mGetH2fTabPagePtr(u16Hblock&~c16DropH2fTab)>=u16Fpage)&&
                       (!chkRefreshH2f((u16Hblock&~c16DropH2fTab), mGetH2fTabPagePtr(u16Hblock&~c16DropH2fTab))))
                    {
                        uAbnorF|=cBit0;
                    }
                    /*
                       * else if (getH2fTabBlkPageInfo(g16arH2fTabBlk[garH2fTabBlkIndex[u16Hblock&~c16DropH2fTab]],
                       *  g16arH2fTabPagePtr[u16Hblock&~c16DropH2fTab], &usBlkSprInfoOrg, cBit0|cBit1)==cTrue)   //load org table to update
                       * {
                       *  if (mGetMetaOpTyp(usBlkSprInfo)!=cMoveProgData) // GC H2f table
                       *  {
                       *      rebuCacheBlkVpCnt(0, 0xFFFF);
                       *  }
                       * }
                       */
                    else if(mGetMetaOpTyp(usBlkSprInfo)!=cMoveProgData)    // GC H2f table
                    {
                        if(getH2fTabBlkPageInfo(g16arH2fTabBlk[mGetH2fTabBlkIndex(u16Hblock&~c16DropH2fTab)],
                                                mGetH2fTabPagePtr(u16Hblock&~c16DropH2fTab), &usBlkSprInfoOrg, cBit1)==cTrue)
                        {
                            rebuCacheBlkVpCnt(0, 0xFFFF);
                        }
                        else
                        {
#if _EN_KEEP_RW_ON_ERROR    // Chief_20190305
                            relinkKeepRwonError(cUpdateH2fTabWindowFail1, g16arH2fTabBlk[mGetH2fTabBlkIndex(
                                                                                             u16Hblock&~c16DropH2fTab)],
                                                mGetH2fTabPagePtr(u16Hblock&~c16DropH2fTab),
                                                0x00);
#else
                            // setRebuAbnorInfo(c16Bit6);
                            relinkSaveDummyQBAnalysis(g16arH2fTabBlk[mGetH2fTabBlkIndex(u16Hblock&~c16DropH2fTab)],
                                                      mGetH2fTabPagePtr(u16Hblock&~c16DropH2fTab), u16Hblock, 0);
                            relinkSaveQBDummy(cUpdateH2fTabWindowFail1);
#endif
                        }
                    }

                    /*
                       * else
                       * {
                       *  setRebuAbnorInfo(c16Bit6);
                       *  //rebuCacheBlkVpCnt(1, 0xFFFF);
                       * }
                       */
                }
                // else if(g16pLinkTable[u16Hblock&~c16DropH2fTab]!=0xFFFF)
                // {
                // debugRdlinkDeadLock();    // rebuCacheBlkVpCnt(2, g16pLinkTable[u16Hblock&~c16DropH2fTab]);
                // }
                else
                {
                    rebuCacheBlkVpCnt(1, 0xFFFF);
                }

                if(uAbnorF!=0)
                {
#if _EN_KEEP_RW_ON_ERROR    // Chief_20190305
                    relinkKeepRwonError(cUpdateH2fTabWindowFail2, g16arH2fTabBlk[mGetH2fTabBlkIndex(
                                                                                     u16Hblock&~c16DropH2fTab)],
                                        mGetH2fTabPagePtr(u16Hblock&~c16DropH2fTab),
                                        0x00);
#else
                    // setRebuAbnorInfo(c16Bit0);
                    relinkSaveDummyQBAnalysis(g16arH2fTabBlk[mGetH2fTabBlkIndex(u16Hblock&~c16DropH2fTab)],
                                              mGetH2fTabPagePtr(u16Hblock&~c16DropH2fTab), mGetMetaOpTyp(usBlkSprInfo), u16Hblock);
                    relinkSaveQBDummy(cUpdateH2fTabWindowFail2);
#endif
                }

                if(u16Hblock&c16DropH2fTab)    // from trim cmd, all 4k are invalid
                {
                    setH2fTabPagePtr(u16Hblock&~c16DropH2fTab, 0xFF, u16Fpage);

                    if(uLastH2fTabBlk&&chkLastH2fTab(u16Fpage, gsRdlinkInfo.u16LastH2fTabFreePage))
                    {
                        reFreshH2f(c16Tsb0SIdx, u16Hblock);
                        addRefreshH2f((u16Hblock&~c16DropH2fTab), gsCacheInfo.u16H2fTabFreePagePtr-1);
                    }
                }
                else if(uBkActH2fTabBlkIdx==uActH2fTabBlkIdx)    // else if(gsCacheInfo.uActH2fTabBlkIdx==uActH2fTabBlkIdx)
                {
                    // setH2fTabPagePtr(u16Hblock, gsCacheInfo.uActH2fTabBlkIdx, u16Fpage);
                    setH2fTabPagePtr(u16Hblock, uBkActH2fTabBlkIdx, u16Fpage);

                    if(uLastH2fTabBlk&&chkLastH2fTab(u16Fpage, gsRdlinkInfo.u16LastH2fTabFreePage))
                    {
                        reFreshH2f(c16Tsb0SIdx, u16Hblock);
                        addRefreshH2f(u16Hblock, gsCacheInfo.u16H2fTabFreePagePtr-1);
                    }
                }
                else
                {
#if _EN_KEEP_RW_ON_ERROR    // Chief_20190305
                    relinkKeepRwonError(cUpdateH2fTabWindowFail3, g16arH2fTabBlk[mGetH2fTabBlkIndex(
                                                                                     u16Hblock&~c16DropH2fTab)],
                                        mGetH2fTabPagePtr(u16Hblock&~c16DropH2fTab),
                                        0x00);
#else
                    // setRebuAbnorInfo(c16Bit1);
                    relinkSaveDummyQBAnalysis(g16arH2fTabBlk[mGetH2fTabBlkIndex(u16Hblock&~c16DropH2fTab)],
                                              mGetH2fTabPagePtr(u16Hblock&~c16DropH2fTab), u16Hblock, 0);
                    relinkSaveQBDummy(cUpdateH2fTabWindowFail3);
#endif
                }

                // u32CopyAddr=getH2fMemLocation(u16Fpage, u16LastFreePagePtr>>gsCacheInfo.uH2fTabProgSlotShift, &usBlkSprInfo);

                // if(u32CopyAddr!=c32InitSerialVal)
                // {
                //    bopCopyRam(u32CopyAddr, (LWORD)c32Tsb0SAddr, c32H2fTabRamSize, cCopyTsb2Tsb|cBopWait);
                // }
            }
        }
        else if(gbOnesCntFail)    // empty
        {
            break;
        }
    }

    gsRdlinkInfo.u16LastH2fTabFblk=c16BitFF;

    jdgH2fTabBlockFull();    // pushH2fBlk again.

    // gsCacheInfo.u15ActiveH2fTab=c15BitFF;
    mClrCacheInfoChangeFlag(cH2fChg);

    // addRdlinkLog(u16H2fTabFBlock);
    // addRdlinkLog(gsRdlinkInfo.u16UpdH2fTabPageCnt);

    // gsCacheInfo.u16H2fTabFreePagePtr=u16LastFreePagePtr;
}    /* updateH2fTabWindow */

void rebuCacheBlkVpCnt(BYTE uTyp, WORD u16Mblk)
{
    WORD u16H4k;
    WORD u16NewFBlock, u16OldFBlock;
    LWORD u32NewF4k, u32OldF4k;

    UCLWORD *u32pNewH2fTab=(UCLWORD *)garTsb0[0];
    UCLWORD *u32pOldH2fTab=(UCLWORD *)garTsb0[g16H2fTabSctrSize];

    if(uTyp==0)
    {
        for(u16H4k=0; u16H4k<g16PagePerH2fTab; u16H4k++)
        {
            u16NewFBlock=mGetSrcFBlkAddr(u32pNewH2fTab[u16H4k]);
            u16OldFBlock=mGetSrcFBlkAddr(u32pOldH2fTab[u16H4k]);
            u32NewF4k=mGetSrcFPageAddr(u32pNewH2fTab[u16H4k]);
            u32OldF4k=mGetSrcFPageAddr(u32pOldH2fTab[u16H4k]);

            if((u16OldFBlock!=u16NewFBlock)||(u32OldF4k!=u32NewF4k))
            {
                if(u16OldFBlock!=c16FBlockInitValue)
                {
                    // while(u16OldFBlock>=g16TotalFBlock)
                    // ;

                    // while(u16OldFBlock<g16FirstFBlock)
                    // ;
                    if((u16OldFBlock<g16FirstFBlock)||(u16OldFBlock>=g16TotalFBlock))
                    {
#if _EN_KEEP_RW_ON_ERROR    // Chief_20190305
                        relinkKeepRwonError(cUpdateH2fTabWindowFail5, u16OldFBlock, 0x02, 0x00);
                        continue;
#else
                        relinkSaveDummyQBAnalysis(u16OldFBlock, 0, 0, 0);
                        relinkSaveQBDummy(cUpdateH2fTabWindowFail5);
#endif
                    }

                    if(mGetCacheBlkVpCnt(u16OldFBlock)==0)
                    {
#if _EN_KEEP_RW_ON_ERROR    // Chief_20190305
                        g32arCacheBlkVpCnt[u16OldFBlock]++;
                        mIncTotalVpc(u16OldFBlock);
                        relinkKeepRwonError(cRebuCacheBlkVpCnt1, u16OldFBlock, 0x00, 0x00);
#else
                        relinkSaveDummyQBAnalysis(u16OldFBlock, 0, 0, 0);
                        relinkSaveQBDummy(cRebuCacheBlkVpCnt1);    // debugRdlinkDeadLock();    // setRebuAbnorInfo(c16Bit6);
#endif
                    }

                    g32arCacheBlkVpCnt[u16OldFBlock]--;
                    mDecTotalVpc(u16OldFBlock);

#if _EN_VPC_SWAP
                    if(mGetCacheBlkVpCnt(u16OldFBlock)==0)
                    {
                        mClrVPCntValid(u16OldFBlock);
                    }
#endif

                    if((mGetCacheBlkVpCnt(u16OldFBlock)==0)&&
                       (mChkPoppedBitRL(u16OldFBlock))&&
                       (u16OldFBlock!=gsRdlinkInfo.u16BkActiveCacheBlock)&&
                       (u16OldFBlock!=gsRdlinkInfo.u16BkActiveGcDesBlock)&&
                       (u16OldFBlock!=gsRdlinkInfo.u16BkFluCacheBlock))
                    {
                        mSetSkipGcBit(u16OldFBlock);
                        pushSpareBlockCore0(u16OldFBlock, cPushNotErase);
                    }
                }

                if(u16NewFBlock!=c16FBlockInitValue)
                {
                    // while(u16NewFBlock>=g16TotalFBlock)
                    // ;

                    // while(u16NewFBlock<g16FirstFBlock)
                    // ;
                    if((u16NewFBlock<g16FirstFBlock)||(u16NewFBlock>=g16TotalFBlock))
                    {
#if _EN_KEEP_RW_ON_ERROR    // Chief_20190305
                        relinkKeepRwonError(cUpdateH2fTabWindowFail5, u16NewFBlock, 0x03, 0x00);
                        continue;
#else
                        relinkSaveDummyQBAnalysis(u16NewFBlock, 0, 0, 0);
                        relinkSaveQBDummy(cUpdateH2fTabWindowFail5);
#endif
                    }

                    g32arCacheBlkVpCnt[u16NewFBlock]++;
                    mIncTotalVpc((!mChkMlcMoBit(u16NewFBlock)));
#if _EN_VPC_SWAP
                    mSetVPCntValid(u16NewFBlock);
#endif

                    if(mChkMlcMoBit(u16NewFBlock))
                    {
                        if(mGetCacheBlkVpCnt(u16NewFBlock)>g32VpcPerTlcBlk)
                        {
#if _EN_KEEP_RW_ON_ERROR    // Chief_20190305
                            relinkKeepRwonError(cRebuCacheBlkVpCnt2, u16NewFBlock, mGetCacheBlkVpCnt(u16NewFBlock)>>16,
                                                mGetCacheBlkVpCnt(u16NewFBlock));
                            g32arCacheBlkVpCnt[u16NewFBlock]=g32VpcPerTlcBlk;
                            mDecTotalVpc((!mChkMlcMoBit(u16NewFBlock)));
#else
                            relinkSaveDummyQBAnalysis(u16NewFBlock, (WORD)(g32arCacheBlkVpCnt[u16NewFBlock]>>16),
                                                      (WORD)(g32arCacheBlkVpCnt[u16NewFBlock]&0xFFFF), 0);
                            relinkSaveQBDummy(cRebuCacheBlkVpCnt2);    // debugRdlinkDeadLock();
#endif
                        }
                    }
                    else
                    {
                        if(mGetCacheBlkVpCnt(u16NewFBlock)>g32VpcPerSlcBlk)
                        {
#if _EN_KEEP_RW_ON_ERROR    // Chief_20190305
                            relinkKeepRwonError(cRebuCacheBlkVpCnt3, u16NewFBlock, mGetCacheBlkVpCnt(u16NewFBlock)>>16,
                                                mGetCacheBlkVpCnt(u16NewFBlock));
                            g32arCacheBlkVpCnt[u16NewFBlock]=g32VpcPerSlcBlk;
                            mDecTotalVpc((!mChkMlcMoBit(u16NewFBlock)));
#else
                            relinkSaveDummyQBAnalysis(u16NewFBlock, (WORD)(g32arCacheBlkVpCnt[u16NewFBlock]>>16),
                                                      (WORD)(g32arCacheBlkVpCnt[u16NewFBlock]&0xFFFF), 0);
                            relinkSaveQBDummy(cRebuCacheBlkVpCnt3);    // debugRdlinkDeadLock();
#endif
                        }
                    }
                }
            }
        }
    }
    else if(uTyp==2)
    {
        // for (u16H4k=0; u16H4k<g16PagePerH2fTab; u16H4k++)
        // {
        // if (u16Mblk!=upH2fTab[u16H4k].u16FBlock)
        // {
        // if (g16arCacheBlkVpCnt[u16Mblk]==0)
        // {
        // debugRdlinkDeadLock();//setRebuAbnorInfo(c16Bit7);
        // }
        // g16arCacheBlkVpCnt[u16Mblk]--;
        // if ((g16arCacheBlkVpCnt[u16Mblk]==0)&&g32arGlobEraseCnt[u16Mblk].ubPopped)
        // {
        // pushSpareBlock(u16Mblk, cPushNotErase);
        // }
        //
        // if (upH2fTab[u16H4k].u16FBlock!=0xFFFF)
        // {
        // g16arCacheBlkVpCnt[upH2fTab[u16H4k].u16FBlock]++;
        // if (g16arCacheBlkVpCnt[upH2fTab[u16H4k].u16FBlock]>g32PagePerBlock2)
        // {
        // debugRdlinkDeadLock();
        // }
        // }
        // }
        // }
        // debugRdlinkDeadLock();
#if _EN_KEEP_RW_ON_ERROR    // Chief_20190305
        relinkKeepRwonError(cRebuCacheBlkVpCnt4, 0x00, 0x00, 0x00);
#else
        relinkSaveQBDummy(cRebuCacheBlkVpCnt4);
#endif
    }
    else
    {
        for(u16H4k=0; u16H4k<g16PagePerH2fTab; u16H4k++)
        {
            u16NewFBlock=mGetSrcFBlkAddr(u32pNewH2fTab[u16H4k]);
            u32NewF4k=mGetSrcFPageAddr(u32pNewH2fTab[u16H4k]);

            if(u16NewFBlock!=c16FBlockInitValue)
            {
                // while(u16NewFBlock>=g16TotalFBlock)
                // ;

                // while(u16NewFBlock<g16FirstFBlock)
                // ;
                if((u16NewFBlock<g16FirstFBlock)||(u16NewFBlock>=g16TotalFBlock))
                {
#if _EN_KEEP_RW_ON_ERROR    // Chief_20190305
                    relinkKeepRwonError(cUpdateH2fTabWindowFail5, u16NewFBlock, 0x04, 0x00);
                    continue;
#else
                    relinkSaveDummyQBAnalysis(u16NewFBlock, 0, 0, 0);
                    relinkSaveQBDummy(cUpdateH2fTabWindowFail5);
#endif
                }

                g32arCacheBlkVpCnt[u16NewFBlock]++;
                mIncTotalVpc((!mChkMlcMoBit(u16NewFBlock)));

#if _EN_VPC_SWAP
                mSetVPCntValid(u16NewFBlock);
#endif

                if(mChkMlcMoBit(u16NewFBlock))
                {
                    if(mGetCacheBlkVpCnt(u16NewFBlock)>g32VpcPerTlcBlk)
                    {
#if _EN_KEEP_RW_ON_ERROR    // Chief_20190305
                        relinkKeepRwonError(cRebuCacheBlkVpCnt5, u16NewFBlock, mGetCacheBlkVpCnt(u16NewFBlock)>>16,
                                            mGetCacheBlkVpCnt(u16NewFBlock));
                        g32arCacheBlkVpCnt[u16NewFBlock]=g32VpcPerTlcBlk;
                        mDecTotalVpc((!mChkMlcMoBit(u16NewFBlock)));
#else
                        relinkSaveDummyQBAnalysis(u16NewFBlock, (WORD)(g32arCacheBlkVpCnt[u16NewFBlock]>>16),
                                                  (WORD)(g32arCacheBlkVpCnt[u16NewFBlock]&0xFFFF), 0);
                        relinkSaveQBDummy(cRebuCacheBlkVpCnt5);    // debugRdlinkDeadLock();
#endif
                        // debugRdlinkDeadLock();
                    }
                }
                else
                {
                    if(mGetCacheBlkVpCnt(u16NewFBlock)>g32VpcPerSlcBlk)
                    {
#if _EN_KEEP_RW_ON_ERROR    // Chief_20190305
                        relinkKeepRwonError(cRebuCacheBlkVpCnt6, u16NewFBlock, mGetCacheBlkVpCnt(u16NewFBlock)>>16,
                                            mGetCacheBlkVpCnt(u16NewFBlock));
                        g32arCacheBlkVpCnt[u16NewFBlock]=g32VpcPerSlcBlk;
                        mDecTotalVpc((!mChkMlcMoBit(u16NewFBlock)));
#else
                        relinkSaveDummyQBAnalysis(u16NewFBlock, (WORD)(g32arCacheBlkVpCnt[u16NewFBlock]>>16),
                                                  (WORD)(g32arCacheBlkVpCnt[u16NewFBlock]&0xFFFF), 0);
                        relinkSaveQBDummy(cRebuCacheBlkVpCnt6);    // debugRdlinkDeadLock();
#endif
                        // debugRdlinkDeadLock();
                    }
                }
            }
        }
    }
}    /* rebuCacheBlkVpCnt */

#if 0
LWORD getH2fMemLocation(WORD u16Fpage, WORD u16LastFreePagePtr, BLKSPRINFO *upBlkSprInfo)
{
    BYTE uLoop;
    // WORD u16EndPagePtr;
    LWORD u32MemAddr=0xFFFFFFFF;

    // u16EndPagePtr=u16LastFreePagePtr-mod(u16LastFreePagePtr, gTotalPlaneOfH2fTab);

    for(uLoop=0; uLoop<cMaxUpdateH2fCnt; uLoop++)
    {
        // if(u16Fpage==(u16EndPagePtr-gTotalPlaneOfH2fTab*(uLoop+1)))
        if(u16Fpage==(u16LastFreePagePtr-(uLoop+1)))
        {
            break;
        }
    }

    if(uLoop<=3)
    {
        gsRdlinkInfo.u16arMoveH2fTab[uLoop]=mGetMetaTabIdxPtr(upBlkSprInfo);
        gsRdlinkInfo.u16arMoveH2fTabPagePtr[uLoop]=(WORD)(mGetMetaH2fIdxPtr(upBlkSprInfo)<<gsCacheInfo.uH2fTabPagePtrShift)|
                                                    (u16Fpage&gsCacheInfo.u16H2fTabPagePtrMsk);
        gsRdlinkInfo.uarMoveH2fTabOptype[uLoop]=mGetMetaOpTypPtr(upBlkSprInfo);
        u32MemAddr=0x40020000+c32H2fTabRamSize*uLoop;
    }

    return u32MemAddr;
}    /* getH2fMemLocation */

// gsRdlinkInfo.uarMoveH2fTabBlkIdx[uLoop]=0xFF;

WORD setMemAddr(BYTE uLoop)
{
    WORD u16SbufPtr=0xFFFF;

    //  0x4002_0000 ~ 0x4005_0000
    if(uLoop<=3)
    {
        u16SbufPtr=c16WriteSIdx+(c32H2fTabFullSize/512)*2+(c32H2fTabFullSize/512)*uLoop;
    }

    return u16SbufPtr;
}    /* setMemAddr */

#endif/* if 0 */

void rstLastH2fTab()
{
    BYTE uLoop;

    gsRdlinkInfo.uRefreshH2fCnt=0;

    for(uLoop=0; uLoop<cMaxUpdateH2fCnt; uLoop++)
    {
        gsRdlinkInfo.u16arMoveH2fTab[uLoop]=0xFFFF;
        gsRdlinkInfo.u16arMoveH2fTabPagePtr[uLoop]=0xFFFF;
    }
}







