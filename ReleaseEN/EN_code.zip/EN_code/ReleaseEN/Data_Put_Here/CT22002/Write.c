







#include "inc/ProType.h"
// #include "inc/FlashCtrl.h"
#include "inc/GlobVar0.h"
#include "inc/Const.h"
#include "inc/GlobVarS.h"
#include "inc/GlobVarT.h"
#include "inc/Reg.h"
#include "inc/FtlCtrl.h"
#include "inc/Mac.h"
#include "inc/BitDef.h"
#if _EN_FW_DEBUG_UART
#include "inc/DebugLog.h"
#include "inc/EventLogIDX.h"
#include "inc/EventLogFunctionIDX.h"
#endif

#if _PRJ_ISP||(_PRJ_SMIVU&&_GREYBOX)
WORD getWrPrdCnt(LWORD u32SctrCnt, BYTE uStartSctr)
{
    WORD u16PrdWrSctrCnt;

    if(u32SctrCnt>(c16WriteBufSize-uStartSctr))
    {
        u16PrdWrSctrCnt=c16WriteBufSize-uStartSctr;
    }
    else
    {
        u16PrdWrSctrCnt=u32SctrCnt;
    }

    return u16PrdWrSctrCnt;
}

WORD getWriteBufPtr(WORD u16WriteBufPtr)
{
    u16WriteBufPtr+=(cSctrPer4k-1);

    if(u16WriteBufPtr<(c16WriteSIdx+c16WriteBufSize))
    {
        // u16WriteBufPtr=(u16WriteBufPtr>>cSctrTo4kShift)<<cSctrTo4kShift;
        u16WriteBufPtr&=~(cSctrPer4k-1);
    }
    else
    {
        u16WriteBufPtr=c16WriteSIdx;
    }

    return u16WriteBufPtr;
}

/*
   * BYTE getWriteSctrCnt(WORD u16PrdSctrCnt)    // , LWORD u32WriteSctr2ChgBlk)
   * {
   *  BYTE uWriteSctrCnt;
   *
   *  uWriteSctrCnt=cSctrPer4k-gStartSector;
   *
   *  if(uWriteSctrCnt>u16PrdSctrCnt)
   *  {
   *      uWriteSctrCnt=u16PrdSctrCnt;
   *      gbCacheInBuf=1;
   *  }
   *  else
   *  {
   *      gbCacheInBuf=0;
   *  }
   *
   *  return uWriteSctrCnt;
   * }
   *
   * void incWriteAddr(BYTE uWriteSctrCnt)
   * {
   *  addLbaAddr(uWriteSctrCnt);
   *  gsCacheInfo.u32WriteSctr2ChgBlk-=uWriteSctrCnt;
   *
   *  if(gsCacheInfo.u32WriteSctr2ChgBlk==0)
   *  {
   *      mSetChgBlock;    // gChgBlock=1;
   *  }
   * }
   */

void chkTrigHostWrQue(BYTE uBrk)
{
    WORD u16PrdTrig;

    while(gsPrdInfo.uTrigWCmdCnt)
    {
        chkReleaseFreeHwPrd();

        if(mChkHandlePcieErrF)
        {
            break;
        }
        else if(gsPrdInfo.uFreeHwPrdCnt)
        {
            u16PrdTrig=gsPrdInfo.uarSeqPrdQue[gsPrdInfo.u32TrigWrCmdTail];
#if _EN_WRHWPRDCORE1
            BYTE uHwPrdIdx=gsPrdInfo.uarFreeHwPrdQue[gsPrdInfo.uFreeHwPrdTail];
            gsPrdInfo.uFreeHwPrdTail=(gsPrdInfo.uFreeHwPrdTail+1)&(cHwPrdDepth-1);
            gsPrdInfo.uFreeHwPrdCnt--;
            gsPrdInfo.u16arIdxToPrdInfo[uHwPrdIdx]=u16PrdTrig;
            gsPrdInfo.uarPrdQue[u16PrdTrig].uHwPrdIdx=uHwPrdIdx;

            if(gsPrdInfo.uarPrdQue[u16PrdTrig].ubSetOccF)
            {
                setFwPreOccuFlag(gsPrdInfo.uarPrdQue[u16PrdTrig].u16BufPtr);
            }
#else
#if !(_GREYBOX&&_PRJ_SMIVU)
#if _ENABLE_RAID
            trigHostRw(u16PrdTrig, c32AutoDmaTrigW, cLastPrd|cTsb|cAutoRaidFlag);
#else
            trigHostRw(u16PrdTrig, c32AutoDmaTrigW, cLastPrd|cTsb|cAutoBufflag);
#endif
#endif
#endif/* if _EN_WRHWPRDCORE1 */
            gsPrdInfo.u32TrigWrCmdTail=((gsPrdInfo.u32TrigWrCmdTail+1)&(cSeqPrdDepth-1));
            gsPrdInfo.uTrigWCmdCnt--;
        }

        if(uBrk)
        {
            break;
        }
    }
}    /* chkTrigHostWrQue */

void trigHostPrdTaskW(WORD u16PrdTrig)
{
    LWORD u32SctrCnt, u32LbaAddr, u32TrigDmaMode;
    WORD u16FreeHostBufSize, u16AlignBuf;
    BYTE uStartSctr;
    PRDQUEUE *upPrdInfo;

    upPrdInfo=&gsPrdInfo.uarPrdQue[u16PrdTrig];
    u16AlignBuf=g16WriteBufPtr;

    if(!gsRwCtrl.ubDelayTrigHost)
    {
        u32LbaAddr=upPrdInfo->u32LbaAddr;
        u32SctrCnt=upPrdInfo->u32SctrCnt;
        uStartSctr=upPrdInfo->uStartSctr=u32LbaAddr&(cSctrPer4k-1);
        // upPrdInfo->ubSetOccF=0;
        // upPrdInfo->ubQRdCmd=0;

        // continue write
        if(g32LastLbaW!=u32LbaAddr)
        {
            upPrdInfo->ubContLba=0;
            g32LastLbaW=u32LbaAddr+u32SctrCnt;
            u16AlignBuf=getWriteBufPtr(g16WriteBufPtr);
            g16WriteBufPtr=u16AlignBuf+uStartSctr;

            if(uStartSctr!=0)
            {
                upPrdInfo->ubSetOccF=1;
            }
        }
        else
        {
            upPrdInfo->ubContLba=1;
            g32LastLbaW+=u32SctrCnt;
        }

        upPrdInfo->u16BufPtr=g16WriteBufPtr;
    }
    else
    {
        if(!(upPrdInfo->ubContLba))
        {
            u16AlignBuf=g16WriteBufPtr&c16BufPtrAlign4k;
        }

        u32SctrCnt=upPrdInfo->u32SctrCnt;
        uStartSctr=upPrdInfo->uStartSctr;
    }

    if(gsGcInfo.ubBgdProcF)
    {
        if(u16AlignBuf>gsRwCtrl.u16OccFSkipStBufPtr)
        {
            u16FreeHostBufSize=c16WriteBufSize-(u16AlignBuf-gsRwCtrl.u16OccFSkipStBufPtr);
        }
        else
        {
            u16FreeHostBufSize=gsRwCtrl.u16OccFSkipStBufPtr-u16AlignBuf;
        }

        if(upPrdInfo->ubSetOccF)
        {
            if(u16FreeHostBufSize>uStartSctr)
            {
                u16FreeHostBufSize-=uStartSctr;
            }
            else
            {
                u16FreeHostBufSize=0;
            }
        }

        if(!u16FreeHostBufSize&&!gsRwCtrl.u16OccFSkipSize)
        {
            u16FreeHostBufSize=c16WriteBufSize;
        }
    }
    else
    {
        u16FreeHostBufSize=c16WriteBufSize-uStartSctr;
    }

    if(u16FreeHostBufSize)
    {
        if(u32SctrCnt>u16FreeHostBufSize)
        {
            upPrdInfo->u32RestScrtCnt=u16FreeHostBufSize;
            chkTrigHostWrQue(0);

#if _EN_NVMEWRDUALENGINE
            while((gsPrdInfo.uFreeHwPrdCnt!=cHwPrdDepth)&&(!mChkHandlePcieErrF))
#endif
            {
                chkReleaseFreeHwPrd();
            }

#if _EN_WRHWPRDCORE1
            while(gsPrdInfo.u32TrigWrCmdTrig!=gsPrdInfo.u32TrigWrCmdTail)
                ;
#endif

            while(!gsPrdInfo.uFreeHwPrdCnt)
            {
                chkReleaseFreeHwPrd();
            }

            if(!mChkHandlePcieErrF)
            {
#if !(_GREYBOX&&_PRJ_SMIVU)
                // when restSctrCnt=1, hw will keep 1 sector data to local Buf then reply completion to Host.
                // use Manual Mode to avoid auto reply CQ
                if(gbEnAes&&gsHmbInfo.uHmbEnable)                    // 20190531_ChirsSu
                {
                    u32TrigDmaMode=c32ManualDmaTrigW;
                    upPrdInfo->uFua|=cDelayComplect;
                }
                else if(u32SctrCnt-u16FreeHostBufSize==1)    // 20190417_ChrisSu
                {
                    u32TrigDmaMode=c32ManualDmaTrigW;
                    upPrdInfo->uFua|=cHdl1RestSctr;
                }
                else
                {
                    u32TrigDmaMode=c32AutoDmaTrigW;
                }

#if _ENABLE_RAID
                trigHostRw(u16PrdTrig, u32TrigDmaMode, cTsb|cAutoRaidFlag);
#else
                trigHostRw(u16PrdTrig, u32TrigDmaMode, cTsb|cAutoBufflag);
#endif
#endif/* if !(_GREYBOX&&_PRJ_SMIVU) */
            }

            upPrdInfo->u32RestScrtCnt=u32SctrCnt-u16FreeHostBufSize;
            gsPrdInfo.u16TrigHostRestSectCnt+=u16FreeHostBufSize;
            g16WriteBufPtr=addWriteBufPtr(g16WriteBufPtr, u16FreeHostBufSize);
        }
        else
        {
            upPrdInfo->u32RestScrtCnt=0;

            gsPrdInfo.uarSeqPrdQue[gsPrdInfo.u32TrigWrCmdHead]=u16PrdTrig;
            gsPrdInfo.u32TrigWrCmdHead=((gsPrdInfo.u32TrigWrCmdHead+1)&(cSeqPrdDepth-1));
            gsPrdInfo.uTrigWCmdCnt++;

            do
            {
                chkReleaseFreeHwPrd();

                if(mChkHandlePcieErrF)
                {
                    break;
                }
                else if(gsPrdInfo.uFreeHwPrdCnt)
                {
                    u16PrdTrig=gsPrdInfo.uarSeqPrdQue[gsPrdInfo.u32TrigWrCmdTail];
#if _EN_WRHWPRDCORE1
                    BYTE uHwPrdIdx=gsPrdInfo.uarFreeHwPrdQue[gsPrdInfo.uFreeHwPrdTail];
                    gsPrdInfo.uFreeHwPrdTail=(gsPrdInfo.uFreeHwPrdTail+1)&(cHwPrdDepth-1);
                    gsPrdInfo.uFreeHwPrdCnt--;
                    gsPrdInfo.u16arIdxToPrdInfo[uHwPrdIdx]=u16PrdTrig;
                    gsPrdInfo.uarPrdQue[u16PrdTrig].uHwPrdIdx=uHwPrdIdx;

                    if(gsPrdInfo.uarPrdQue[u16PrdTrig].ubSetOccF)    // Enable Occupy flg & Set occupy Address inside
                    {
                        setFwPreOccuFlag(gsPrdInfo.uarPrdQue[u16PrdTrig].u16BufPtr);
                    }
#else
#if !(_GREYBOX&&_PRJ_SMIVU)
#if _ENABLE_RAID
                    trigHostRw(u16PrdTrig, c32AutoDmaTrigW, cLastPrd|cTsb|cAutoRaidFlag);
#else
                    trigHostRw(u16PrdTrig, c32AutoDmaTrigW, cLastPrd|cTsb|cAutoBufflag);
#endif
#endif
#endif/* if _EN_WRHWPRDCORE1 */
                    gsPrdInfo.u32TrigWrCmdTail=((gsPrdInfo.u32TrigWrCmdTail+1)&(cSeqPrdDepth-1));
                    gsPrdInfo.uTrigWCmdCnt--;
                    break;
                }
            }
            while(gsPrdInfo.uTrigWCmdCnt==cSeqPrdDepth);

            g16WriteBufPtr=addWriteBufPtr(g16WriteBufPtr, u32SctrCnt);
        }

        gsRwCtrl.ubDelayTrigHost=0;
    }
    else
    {
        chkTrigHostWrQue(0);
        gsRwCtrl.ubDelayTrigHost=1;
    }
}    /* trigHostPrdTaskW */

void chkAddProgFifoHead(WORD u16PrdTrig)
{
    if(mChkDummyWrite){return;}

    garDesAddrInfo[gsRwCtrl.u32ProgFifoHead].uAddrOpt&=~(cDone|cProgFail);    // cForeClrOccF|cBackClrOccF);
    garDesAddrInfo[gsRwCtrl.u32ProgFifoHead].uSrcIdx=gsRwCtrl.u32ProgFifoHead;    // Mata data for PCIe Error
    gsRwCtrl.u32ProgFifoHead=addWrFfPtrBy1(gsRwCtrl.u32ProgFifoHead);

    while(gsRwCtrl.u32ProgFifoTail==addWrFfPtrBy1(gsRwCtrl.u32ProgFifoHead))
    {
        chkTrigHostWrQue(1);

        if(mChkHandlePcieErrF&&chkBrkWriteInPcieErr(u16PrdTrig))
        {
            break;
        }
    }
}    /* chkAddProgFifoHead */

BYTE getTailFifoOffset()
{
    if(gsRwCtrl.u32ProgFifoHead>=gsRwCtrl.u32ProgFifoTail)
    {
        return gsRwCtrl.u32ProgFifoHead-gsRwCtrl.u32ProgFifoTail;
    }
    else
    {
        return gsRwCtrl.u32ProgFifoHead+cWriteFifoDpt-gsRwCtrl.u32ProgFifoTail;
    }
}

/*
   * void addDesAddrInfo()
   * {
   *  if(gbLsbOnly)
   *  {
   *      chkAddProgFifoHead();
   *      mSetNewDesF;
   *      //gsRwCtrl.u32OneShotChPtr=addPtrBy1(gsRwCtrl.u32OneShotChPtr, gTotalChNum);
   *      // gsRwCtrl.uOneShotChOpenDesIdx[gsRwCtrl.u32OneShotChPtr]=gsRwCtrl.u32ProgFifoHead;
   *  }
   *  // 1. if MSB and last ch. 2. TODO: write idle
   *  if((gsRwCtrl.u32OneShotChPtr==0))    // &&(gsRwCtrl.u32OneShotPgPtr==cLSB))
   *  {
   *      updateF2hTable();
   *  }
   *
   *  while(getTailFifoOffset()>4)
   *      ;// this '4' should be defined?????????????????????
   * }
   */

void chkWriteSctr2ChgBlk()
{
    if(gsCacheInfo.u32WriteSctr2ChgBlk==0)
    {
        mSetChgBlock;
        mSetCalWriteSctr2ChgBlk;
    }
}

#if _ENABLE_RAID
void setOpt(BYTE uF2hFlag, BYTE uPlaneRaid, WORD u16PrdTrig)
{
    WORD u16DmaSctrCnt;

    gpFlashAddrInfo->uPrdPtr=gsRwCtrl.uPrdPtr[gsRwCtrl.uCachePtr-1];
    gSectorH=0;
    gpFlashAddrInfo->u16BufPtr=g16FlashWBufPtr;
    // gpFlashAddrInfo->uPlaneCnt+=gsRwCtrl.uCachePtr;
    u16DmaSctrCnt=gsRwCtrl.uCachePtr<<cSctrTo4kShift;
    g16FlashWBufPtr=addWriteBufPtr(g16FlashWBufPtr, u16DmaSctrCnt);
    gpFlashAddrInfo->uRwHalfKb=u16DmaSctrCnt;

    if(u16PrdTrig!=c16Null)
    {
        gsRwCtrl.u16ProgPageOfst+=gsRwCtrl.uCachePtr;
    }
    else
    {
        gsRwCtrl.u16ProgPageOfst+=g4kNumPerPage;
    }

    if(uF2hFlag)
    {
        if(u16PrdTrig!=c16Null)
        {
            gsRwCtrl.u16ProgPageOfst+=gsCacheInfo.uPadF2h4KNum;
        }

        resetF2hTab(gsRwCtrl.uCachePtr, gsCacheInfo.uPadF2h4KNum);

        while(gsRwCtrl.u32UpdFifoPtr!=(addWrFfPtrBy1(gsRwCtrl.u32ProgFifoHead)))
        {
            updateF2hTable(addWrFfPtrBy1(gsRwCtrl.u32ProgFifoHead));
        }
    }
    else if(uPlaneRaid)
    {
        if(u16PrdTrig!=c16Null)
        {
            gsRwCtrl.u16ProgPageOfst+=c4kNumPerRaidPty;
        }

        resetF2hTab(gsRwCtrl.uCachePtr, c4kNumPerRaidPty);
        resetSrchTgt();
        gsCacheInfo.u32WriteSctr2ChgBlk-=(c4kNumPerRaidPty<<cSctrTo4kShift);

        chkWriteSctr2ChgBlk();
    }

    gsRwCtrl.uCachePtr=0;
    gsRwCtrl.u16CacheInBuf=0;

    chkAddHostWrCnt(u16DmaSctrCnt, gsCacheInfo.uChkF2hRegion?0:1);

    // addDesAddrInfo();
    // gAddrOpt&=~(cDone|cProgFail);
    // gsRwCtrl.u32ProgFifoHead=addWrFfPtrBy1(gsRwCtrl.u32ProgFifoHead);
    if(u16PrdTrig!=c16Null)
    {
        chkAddProgFifoHead(u16PrdTrig);

        // while(gsRwCtrl.u32ProgFifoTail==addWrFfPtrBy1(gsRwCtrl.u32ProgFifoHead))
        // {
        //    chkTrigHostWrQue(1);
        // }
    }
    else
    {
        chkAddProgFifoHead(cNull);
    }

    mSetNewDesF;

    if(gCh==(gTotalChNum-1))    // &&(gsRwCtrl.uFirstPageOfLarge==0))
    {
        updateF2hTable(gsRwCtrl.u32ProgFifoHead);
    }

    // deal with ProgF2h2 case
    if(uF2hFlag)
    {
        setF2hProgDesAddr();
    }
}    /* setOpt */

#else/* if _ENABLE_RAID */
void setOpt(BYTE uF2hFlag, BYTE uNotByFlush)
{
    WORD u16DmaSctrCnt;

    gpFlashAddrInfo->uPrdPtr=gsRwCtrl.uPrdPtr[gsRwCtrl.uCachePtr-1];
    gSectorH=0;
    gpFlashAddrInfo->u16BufPtr=g16FlashWBufPtr;
    // gpFlashAddrInfo->uPlaneCnt+=gsRwCtrl.uCachePtr;
    u16DmaSctrCnt=gsRwCtrl.uCachePtr<<cSctrTo4kShift;
    g16FlashWBufPtr=addWriteBufPtr(g16FlashWBufPtr, u16DmaSctrCnt);
    gpFlashAddrInfo->uRwHalfKb=u16DmaSctrCnt;

    if(uF2hFlag)
    {
        if(uNotByFlush)
        {
            gsRwCtrl.u16ProgPageOfst+=gsCacheInfo.uPadF2h4KNum;
        }

        resetF2hTab(gsRwCtrl.uCachePtr, gsCacheInfo.uPadF2h4KNum);
    }

    if(uNotByFlush)
    {
        gsRwCtrl.u16ProgPageOfst+=gsRwCtrl.uCachePtr;
    }
    else
    {
        gsRwCtrl.u16ProgPageOfst+=g4kNumPerPage;
    }

    gsRwCtrl.uCachePtr=0;
    gsRwCtrl.u16CacheInBuf=0;

    chkAddHostWrCnt(u16DmaSctrCnt, gsCacheInfo.uChkF2hRegion?0:1);
    // addDesAddrInfo();
    // gAddrOpt&=~(cDone|cProgFail);
    // gsRwCtrl.u32ProgFifoHead=addWrFfPtrBy1(gsRwCtrl.u32ProgFifoHead);
    chkAddProgFifoHead(cNull);

    if(uNotByFlush)
    {
        while(gsRwCtrl.u32ProgFifoTail==addWrFfPtrBy1(gsRwCtrl.u32ProgFifoHead))
        {
            chkTrigHostWrQue(1);
        }
    }

    mSetNewDesF;

    if(gCh==(gTotalChNum-1))    // &&(gsRwCtrl.uFirstPageOfLarge==0))
    {
        updateF2hTable(gsRwCtrl.u32ProgFifoHead);
    }

    // deal with ProgF2h2 case
    if(uF2hFlag)
    {
        setF2hProgDesAddr();
    }
}    /* setOpt */

#endif/* if _ENABLE_RAID */

void setFlushCacheOpt()
{
    BYTE uF2hFlag=0;

#if _ENABLE_RAID
    BYTE uPlaneRaid=0;
#endif
    // if(gsRwCtrl.u32OneShotPgPtr==cLSB)
    // {
    gpFlashAddrInfo->uPrdPtr=gsRwCtrl.uPrdPtr[gsRwCtrl.uCachePtr-1];
    gpFlashAddrInfo->uRwHalfKb=0;
    gSectorH=0;
    // }

    // if(((gsRwCtrl.u32OneShotPgPtr==cMSB)||(gbLsbOnly))&&(gpFlashAddrInfo->u16RwOpt&cProg16kF2H)&&
    //   (gsRwCtrl.uCachePtr==gsCacheInfo.u4KNumToPadF2h))
    if((gpFlashAddrInfo->u16RwOpt&cProg16kF2H)&&(gsRwCtrl.uCachePtr==gsCacheInfo.u4KNumToPadF2h))
    {
        uF2hFlag=1;
    }

#if _ENABLE_RAID
    else if((gpFlashAddrInfo->u16RwOpt&cProgPlaneRaid)&&(gsRwCtrl.uCachePtr==(g4kNumPerPage-c4kNumPerRaidPty)))
    {
        uPlaneRaid=1;
    }
#endif

    gOpTyp=cFlushData;
    gpFlashAddrInfo->u16RwOpt|=c16Bit0|c16Bit1|c16Bit2|c16Bit6|c16Bit15;
    gpFlashAddrInfo->uPlaneCnt+=gsRwCtrl.uCachePtr;
    // gpFlashAddrInfo->u32Serial=gsCacheInfo.u32CacheBlkSerial;

#if _ENABLE_RAID
    setOpt(uF2hFlag, uPlaneRaid, c16Null);
#else
    setOpt(uF2hFlag, c16Null);
#endif
}    /* setFlushCacheOpt */

#endif/* if _PRJ_ISP */

void setProgFifoOpt(WORD u16PrdTrig)
{
#if _PRJ_ISP||(_PRJ_SMIVU&&_GREYBOX)
    BYTE uF2hFlag=0;

#if _ENABLE_RAID
    BYTE uPlaneRaid=0;
#endif

    // BYTE uPgIdxDes= gsRwCtrl.uPgCntDes[uCh];

    mSetCacheInBuf(gsRwCtrl.uCachePtr);
    gsRwCtrl.uCachePtr++;

    if(mChkCacheEobFlag(cEob1stF2h)&&(gsRwCtrl.uCachePtr==gsCacheInfo.u4KNumToPadF2h))
    {
        uF2hFlag=1;
        chkTrigHostWrQue(0);
        mClrCacheEobFlag(cEob1stF2h);
    }

#if _ENABLE_RAID
    else if(mChkCacheEobFlag(cEobRaid)&&(gsRwCtrl.uCachePtr==(g4kNumPerPage-c4kNumPerRaidPty)))
    {
        uPlaneRaid=1;
        mClrCacheEobFlag(cEobRaid);
    }
#endif

#if _ENABLE_RAID
    if((gsRwCtrl.uCachePtr==g4kNumPerPage)||uF2hFlag||uPlaneRaid)
#else
    if((gsRwCtrl.uCachePtr==g4kNumPerPage)||uF2hFlag)
#endif
    {
        gpFlashAddrInfo=&garDesAddrInfo[gsRwCtrl.u32ProgFifoHead];
        gpFlashAddrInfo->uPlaneCnt+=gsRwCtrl.uCachePtr;

#if _ENABLE_RAID
        if(((gpFlashAddrInfo->uPlaneCnt!=g4kNumPerPage)&&(!uPlaneRaid))||(g16FPage==(g16PagePerBlock1_SLC-1)))
#else
        if((gpFlashAddrInfo->uPlaneCnt!=g4kNumPerPage)||(g16FPage==(g16PagePerBlock1_SLC-1)))
#endif
        {
            gpFlashAddrInfo->u16RwOpt|=c16Bit0|c16Bit1|c16Bit2|c16Bit6|c16Bit15;
            gOpTyp=cProgData;
        }
        else
        {
            gpFlashAddrInfo->u16RwOpt|=c16Bit0|c16Bit1|c16Bit2|c16Bit3|c16Bit6|c16Bit15;

            if(mChkFLOption(cEnCacheProg))    // &&gbLsbOnly)
            {
                gOpTyp=cCacheProgData;
            }
            else
            {
                gOpTyp=cProgData;
            }
        }

#if _ENABLE_RAID
        setOpt(uF2hFlag, uPlaneRaid, u16PrdTrig);
#else
        setOpt(uF2hFlag, u16PrdTrig);
#endif

        // deal with ProgF2h2 case
        if(uF2hFlag)
        {
#if _GREYBOX
            if((gsGbInfo.uGreyBoxItem==cUGSDProgCacheSlcID)&&
               ((gsGbInfo.uGreyBoxOpt==cVOpProgFristF2H)||(gsGbInfo.uGreyBoxOpt==cVOpProgLastF2H)||
                (gsGbInfo.uGreyBoxOpt==cVOpProgLastF2HDone))&&
               (gsGbInfo.uStag==cVsIdl))
            {
                trigGreyBox(cTrue);
            }
#endif

#if (_GREYBOX)
            if(gsGbInfo.uGreyBoxItem==cUGSDProgCacheSlcID)
            {
                if((gsGbInfo.uGreyBoxOpt==cVOpProgPause)&&(gsGbInfo.uStag==cVsTriggered))
                {
                    triggerUGSD(cFalse);
                }
            }
#endif

            while((gsRwCtrl.u32ProgFifoTail!=gsRwCtrl.u32ProgFifoHead)&&!mChkHandlePcieErrF)
                ;

            if(mChkHandlePcieErrF)
            {
                mSetToDoHdlPcieWErrF;
            }
        }
    }
#else/* if _PRJ_ISP */
    while(1)
        ;
#endif/* if _PRJ_ISP */
}    /* setProgFifoOpt */

// padding dummy to first page of bank for FUA.
BYTE chkPadDummyFua()
{
    WORD u16FPage;
    LWORD u32TempFPageNoTran=(gsCacheInfo.u32CacheFreePagePtr+gsRwCtrl.u16ProgPageOfst+gsRwCtrl.uCachePtr);

    if((mChkTermWFua)&&(u32TempFPageNoTran>=gsCacheInfo.u16TotalPgPerF2hTab))    // if bank 1, 2, 3
    {
        while(u32TempFPageNoTran>=gsCacheInfo.u16TotalPgPerF2hTab)
        {
            u32TempFPageNoTran-=gsCacheInfo.u16TotalPgPerF2hTab;
        }

        u16FPage=(WORD)((u32TempFPageNoTran>>gPhyPageAddrBitShiftCnt)&g32PhyPageAddrMask);

        return (u32TempFPageNoTran>0)&&(!u16FPage);
    }

    return cFalse;
}    /* chkPadDummyFua */

#if _PRJ_ISP||(_PRJ_SMIVU&&_GREYBOX)
void flushWriteCache()
{
    BYTE uReadDummyF=0, uPrdPtr, uRest4kCnt, uRestSctrCnt, uCachePtr;
    WORD u16StFlWBufPtr;    // = addWriteBufPtr(g16FlashWBufPtr, (gsRwCtrl.uCachePtr*cSctrPer4k));
    BYTE uPadDummyFua;    // padding dummy to first page of bank for FUA.

    if(mChkCacheInBuf(gsRwCtrl.uCachePtr))
    {
        uPrdPtr=gsRwCtrl.uPrdPtr[gsRwCtrl.uCachePtr];
        rmSetSrchTgt(gsRwCtrl.uMaskTgtPtr, (gsRwCtrl.u16arCacheHBlock[gsRwCtrl.uCachePtr]<<16)|gsRwCtrl.u16arCacheHPage[gsRwCtrl.uCachePtr]);
        gsRwCtrl.uMaskTgtPtr++;
        gsRwCtrl.uCachePtr++;
    }
    else
    {
        if(gsRwCtrl.uCachePtr==0)
        {
            uPrdPtr=0xFF;
        }
        else
        {
            uPrdPtr=gsRwCtrl.uPrdPtr[gsRwCtrl.uCachePtr-1];
        }
    }

    uPadDummyFua=chkPadDummyFua();

    while((gsRwCtrl.uCachePtr)||(uPadDummyFua))
    {
        uRest4kCnt=g4kNumPerPage-gsRwCtrl.uCachePtr;
        gpFlashAddrInfo=&garDesAddrInfo[gsRwCtrl.u32ProgFifoHead];

        if(mChkNewDesF)
        {
            setWriteDes(gsRwCtrl.u16ProgPageOfst, gpFlashAddrInfo, cWriteCache);
            mClrNewDesF;    // gbNewDesF=0;
        }

        if(gpFlashAddrInfo->u16RwOpt&cProg16kF2H)    // &&((gsRwCtrl.u32OneShotPgPtr==cMSB)||gbLsbOnly))
        {
            uRest4kCnt-=(gsCacheInfo.uSecNumPadF2h_1>>cSctrTo4kShift);
        }

#if _ENABLE_RAID
        else if(gpFlashAddrInfo->u16RwOpt&cProgPlaneRaid)
        {
            uRest4kCnt-=c4kNumPerRaidPty;
        }
#endif

        if(uRest4kCnt!=0)
        {
            uReadDummyF=1;
            u16StFlWBufPtr=addWriteBufPtr(g16FlashWBufPtr, (gsRwCtrl.uCachePtr<<cSctrTo4kShift));
            uRestSctrCnt=uRest4kCnt<<cSctrTo4kShift;

            gsCacheInfo.u32WriteSctr2ChgBlk-=uRestSctrCnt;

            chkWriteSctr2ChgBlk();

            while(uRest4kCnt!=0)
            {
                gsRwCtrl.u16arCacheHPage[gsRwCtrl.uCachePtr]=0xFFFF;
                gsRwCtrl.u16arCacheHBlock[gsRwCtrl.uCachePtr]=0xFFFF;
                gsRwCtrl.uPrdPtr[gsRwCtrl.uCachePtr]=uPrdPtr;
                mSetCacheInBuf(gsRwCtrl.uCachePtr);
                gsRwCtrl.uCachePtr++;

                uRest4kCnt--;
            }
        }
        else
        {
            uReadDummyF=0;
        }

        uCachePtr=0;
        uPrdPtr=0xFF;

        while(uCachePtr<gsRwCtrl.uCachePtr)
        {
            garDesF2hInfo[gsRwCtrl.u32ProgFifoHead].u16arHPage[uCachePtr]=gsRwCtrl.u16arCacheHPage[uCachePtr];
            garDesF2hInfo[gsRwCtrl.u32ProgFifoHead].u16arHBlock[uCachePtr]=gsRwCtrl.u16arCacheHBlock[uCachePtr];
            uCachePtr++;
        }

        if(uReadDummyF&&(!((mChkHandlePcieErrF)&&chkBrkWriteInPcieErr(cNull))))
        {
            while(getTailFifoOffset()>gTotalChNum)
            {
                if(mChkHandlePcieErrF)
                {
#if _EN_PCIE_PATH_REC
                    mRecPcieErrPath(cErrBrkWaitflushCache);
#endif
                    setFlushCacheOpt();
                    return;
                }
            }

#if _ENABLE_RAID
            bopClrRam((LWORD)(c32Tsb0SAddr+(u16StFlWBufPtr<<9)), (uRestSctrCnt<<9), (LWORD)0x00000000,
                      cBopWait|cBopTsbFlag|cBopRaidFlag|cClrTsb);
#else
            bopClrRam((LWORD)(c32Tsb0SAddr+(u16StFlWBufPtr<<9)), (uRestSctrCnt<<9), (LWORD)0x00000000,
                      cBopWait|cBopTsbFlag|cClrTsb);
#endif
        }

        setFlushCacheOpt();

        if(!gsRwCtrl.uCachePtr)
        {
            uPadDummyFua=chkPadDummyFua();
        }
    }

    if(uReadDummyF)
    {
        g16WriteBufPtr=g16FlashWBufPtr;
        g32LastLbaW=0xFFFFFFFF;
    }
}    /* flushWriteCache */

/*
   * void clrOccFlag()
   * {
   *  WORD u16OccFClrSize, u16BufPtr;
   *  BYTE uSctrCnt;
   *
   *  while((gsRwCtrl.u32ProgFifoTail!=gsRwCtrl.u32ProgFifoHead)&&!mChkHandlePcieErrF)
   *      ;
   *
   *  while(rmChkSysCmdFifoBz&&!mChkHandlePcieErrF)
   *      ;
   *
   *  updateF2hTable();
   *
   *  setFLActCh(0);    // setFLAddrActCh(0, &usTmpAddrInfo);
   *  u16BufPtr=gsGcInfo.u16OccFSkipStBufPtr;
   *  u16OccFClrSize=gsGcInfo.u16OccFSkipSize;
   *
   *  while(u16OccFClrSize!=0)
   *  {
   *      if(u16OccFClrSize>0x80)
   *      {
   *          uSctrCnt=0x80;
   *          u16OccFClrSize-=0x80;
   *          setFifoClrOccF(u16BufPtr, uSctrCnt, 1);
   *          u16BufPtr=addWriteBufPtr(u16BufPtr, 0x80);
   *      }
   *      else
   *      {
   *          uSctrCnt=u16OccFClrSize;
   *          setFifoClrOccF(u16BufPtr, uSctrCnt, 1);
   *          u16OccFClrSize=0;
   *      }
   *  }
   *
   *  // while(rmChkSysCmdFifoBz&&!mChkHandlePcieErrF)
   *  //    ;
   *
   *  // if(uChk)
   *  // {
   *  // for(u16BufPtr=0; u16BufPtr<u16OccFClrNum; u16BufPtr++)
   *  // {
   *  // u16OccFClrSize=addWriteBufPtr(gsGcInfo.u16OccFSkipStBufPtr, u16BufPtr);
   *  //
   *  // while((rTsbCtrl[rcBuf0OccFlag+(u16OccFClrSize>>3)]&cb32BitTab[u16OccFClrSize&7])!=0)
   *  // ;
   *  // }
   *  // }
   *  //
   *
   *  gsGcInfo.u16OccFSkipSize=0;
   * }
   */

/*
   * void chkBufFlag()
   * {
   *  BYTE uPtr;
   *
   *  for(uPtr=0; uPtr<(0x300/32); uPtr++)
   *  {
   *      while(r32TsbCtrl[uPtr]!=0)
   *          ;
   *  }
   * }
   */
/*
   * void clnH2fTabBlk()
   * {
   *  if(chkWriteDataDone(0)==cTrue)
   *  {
   *      bgdClnH2fTabblkProc();
   *  }
   * }
   */

#endif/* if _PRJ_ISP */

void chkBufOccupy(WORD u16PrdTrig)
{
#if _PRJ_ISP||(_PRJ_SMIVU&&_GREYBOX)
    BYTE uBufFlagIdx=0, uDoPlpScpflow=0, uTsbIdx;
    WORD u16BufPtr;
    LWORD u32Temp1, u32Temp2;
#if _ENABLE_SCP_PLP
    WORD u32PlpAbrotGcTime;
#endif

    // if(gsRwCtrl.u16OccFSkipSize>=c16WriteBufSize)
    // {
    if(chkWriteDataDone()==cTrue)
    {
        // rmRtc32kReset;
        u32Temp1=getRtcCurrent32k();

        // if((gsWproInfo.uCnt>=(cWproGcThr))&&(gsWproInfo.u16WproFreePagePtr>=(gsWproInfo.u16PagePerBlock3/2)))
        if(mChkGcQue(cGcTypWPROSwap))
        {
#if _ENABLE_SECAPI
            if(gInSecApi)
            {
                while(1)
                    ;
            }
#endif
            swapWproBlkCore0();
            mPopGcQue(cGcTypWPROSwap);
        }

#if _ENABLE_SECAPI
        if(gInSecApi)
        {
            backupRwBufferForSecApi(1);    // TSB0 backup
        }
        else
#endif

        if(gbEnAes&&gsHmbInfo.uHmbEnable)
        {
            if((u16PrdTrig!=0xFFFF)&&gsPrdInfo.uarPrdQue[u16PrdTrig].u32RestScrtCnt)
            {
                // while(uSTOP);
                // Force Trigger second DPP data for multi-PRD when both AES and HMB were enabled.
                BYTE uBgdProcF=gsGcInfo.ubBgdProcF;
                gsGcInfo.ubBgdProcF=0;

                while(gsPrdInfo.uFreeHwPrdCnt!=cHwPrdDepth&&!mChkHandlePcieErrF)
                {
                    chkReleaseFreeHwPrd();
                }

                gsGcInfo.ubBgdProcF=uBgdProcF;

                // Backup buffer flag of 384KB
                for(uBufFlagIdx=0; uBufFlagIdx<24; uBufFlagIdx++)
                {
#if _ENABLE_RAID
                    if(rm32BufRaidStatus(uBufFlagIdx))
                    {
                        g32TempBufFlag[uBufFlagIdx]=rm32BufRaidStatus(uBufFlagIdx);
                        rmSetBufRaid32Sts(uBufFlagIdx, g32TempBufFlag[uBufFlagIdx]);
                    }
#else
                    if(rm32BufStatus(uBufFlagIdx))
                    {
                        g32TempBufFlag[uBufFlagIdx]=rm32BufStatus(uBufFlagIdx);
                        rmSetBuf32Sts(uBufFlagIdx, g32TempBufFlag[uBufFlagIdx]);
                    }
#endif
                }

                if(!mChkHandlePcieErrF)
                {
                    setBufStatus(c16Tsb0SIdx, c16Tsb0Size, cTsb0);

                    for(uTsbIdx=0; uTsbIdx<(c16WriteBufSize/cHmbChunkSctrSize); uTsbIdx++)
                    {
                        u16BufPtr=c16Tsb0SIdx+(uTsbIdx*cHmbChunkSctrSize);
                        mWaitHmbRelease(2);
                        txfrHmbData(cHmbWriteData,
                                    u16BufPtr,
                                    cHmbChunkSctrSize,
                                    (uTsbIdx*cHmbChunkSctrSize)<<9,
                                    uTsbIdx,
                                    cHmbTsbCache,
                                    cHmbTsbPath|cHmbBufflagChk,
                                    0);
                        writeTsbE2e2Hmb(u16BufPtr>>5, uTsbIdx);
                    }

                    waitHmbPrdDone();
                }
            }
        }

        if(mChkGcQue(cGcTypFlushF2h))
        {
            flushCacheHmbTab();
            flushCacheF2hTab(cBit1);
            mPopGcQue(cGcTypFlushF2h);
#if 0    // _ENABLE_SECAPI
            if(gInSecApi)
            {
#if _ENABLE_SECAPI_W_DEBUG
                NLOG(cLogSecApiDebug,
                     WRITE_C,
                     0,
                     "SecIntf_TCG_Write() Flush F2h, Zero Buffer Ptr");
#endif

                g16BackupWriteBufPtr=0xFFFF;
            }
#endif
        }

        u32Temp2=chkRtc32kProcTime(u32Temp1);    // rmGetRtc32kTick-u32Temp1;
        u32Temp1=getRtcCurrent32k();

        if(u32Temp2>gsRwCtrl.u32Debug3)
        {
            gsRwCtrl.u32Debug3=u32Temp2;
        }

        if(mChkGcQue(cGcTypH2fTab)||mChkGcFlag(cReadScrubH2F))
        {
            waitHmbPrdDone();
            flushCacheHmbTab();
            g32Rtc32kStartVal=getRtcCurrent32k();
            gsGcInfo.u32BgdGcEndTime=    /*rmGetRtc32kTick+*/ c32PartialCleanRtc20ms;
            bgdClnH2fTabblkProc();
        }

        u32Temp2=chkRtc32kProcTime(u32Temp1);    // rmGetRtc32kTick-u32Temp1;
        u32Temp1=getRtcCurrent32k();

        if(u32Temp2>gsRwCtrl.u32Debug4)
        {
            gsRwCtrl.u32Debug4=u32Temp2;
        }

#if _EN_FW_DEBUG_UART
        // NLOG(cLogGC, WRITE_C, 1, "Static mode: 0x%04X ", gsFtlDbg.uStaticMode);
        // NLOG(cLogGC, WRITE_C, 1, "SLC spare block count: 0x%04X ", gsCacheInfo.u16SLCSpareCnt);
        // NLOG(cLogGC, WRITE_C, 1, "TLC full cache block count: 0x%04X ", gsCacheInfo.u16TLCFullCacheBlockCnt);
#endif
#if _ENABLE_SCP_PLP
        if(mChkInitPlpScp)
        {
            u32PlpAbrotGcTime=c32PartialCleanRtc480ms;

            if((gsGcInfo.u32GcCachebTime*5)>c32PartialCleanRtc480ms)
            {
                u32PlpAbrotGcTime=gsGcInfo.u32GcCachebTime*5;
            }

            if((chkRtc32kProcTime(g32arPlpScpTimeStamp)+u32PlpAbrotGcTime)>=c32PartialCleanRtc2s)
            {
                uDoPlpScpflow=1;
#if _EN_FW_DEBUG_UART
                NLOG(cLogGC, WRITE_C, 1, "Do PlpScpflow on Gc: 0x%02X ", uDoPlpScpflow);
#endif
            }
        }
#endif/* if _ENABLE_SCP_PLP */

        if(mChkGcQue(cGcTypForeGrnd)&&(!uDoPlpScpflow))
        {
            if(g16PushSpareCnt)
            {
                chkPushSpareQCore0(0);
            }

            if(chkBgdClnCacheBlk())
            {
                if(!mChkGcQue(cGcTypForeGrnd))
                {
                    mPushGcQue(cGcTypForeGrnd);
                }

                setGcFlowAndBlkCnt();

                g32Rtc32kStartVal=getRtcCurrent32k();
                gsGcInfo.u32BgdGcEndTime=gsGcInfo.u32GcCachebTime;
                flushCacheHmbTab();
                waitHmbPrdDone();
                bgdClnCacheblkProc(cWriteFunc);
            }

            if(mChkGcQue(cGcTypH2fTab)||mChkGcFlag(cReadScrubH2F))
            {
                g32Rtc32kStartVal=getRtcCurrent32k();
                gsGcInfo.u32BgdGcEndTime=    /*rmGetRtc32kTick+*/ c32PartialCleanRtc20ms;
                bgdClnH2fTabblkProc();
            }
        }
        else if(g16PushSpareCnt>(gsGcInfo.u16GcCachebActThr/3))
        {
            chkPushSpareQCore0(0);
        }

        u32Temp2=chkRtc32kProcTime(u32Temp1);    // rmGetRtc32kTick-u32Temp1;
        u32Temp1=getRtcCurrent32k();

        if(u32Temp2>gsRwCtrl.u32Debug5)
        {
            gsRwCtrl.u32Debug5=u32Temp2;
        }

        if(mChkBadInfoFlag(cBadInfoChg))
        {
#if (!_ICE_DEBUG)
            waitHmbPrdDone();
            markBadBlockCore0();
#endif
        }

        gsGcInfo.ubBgdProcF=0;
        gsRwCtrl.u16OccFSkipSize=0;

        if(!gsCacheInfo.uChkF2hRegion)
        {
            chkFlushCacheTabOccF();
        }

#if (_FUA_PERF)
        if(mChkQueueFuaCmd)
        {
            mSetTermWFua;
            chkReleaseFreeHwPrd();
            mClrTermWFua;

            if(!gFuaQueueCnt)
            {
                mClrQueueFuaCmd;
            }
        }
#endif

#if _ENABLE_SECAPI
        if(gInSecApi)
        {
            backupRwBufferForSecApi(0);    // TSB0 restore
        }
        else
#endif

        if(gbEnAes&&gsHmbInfo.uHmbEnable&&!mChkHandlePcieErrF)
        {
            // gsPrdInfo.uarPrdQue[u16PrdTrig].u32RestScrtCnt has cleared here.
            if((u16PrdTrig!=0xFFFF)&&uBufFlagIdx)
            {
                for(uTsbIdx=0; uTsbIdx<(c16WriteBufSize/cHmbChunkSctrSize); uTsbIdx++)
                {
                    mWaitHmbRelease(2);
                    txfrHmbData(cHmbReadData,
                                c16Tsb0SIdx+(uTsbIdx*cHmbChunkSctrSize),
                                cHmbChunkSctrSize,
                                (uTsbIdx*cHmbChunkSctrSize)<<9,
                                uTsbIdx,
                                cHmbTsbCache,
                                cHmbTsbPath|cHmbReadDir|cHmbBufflagChk,
                                g32arTsbCrc[uTsbIdx*2]);
                    readTsbE2eFromHmb(uTsbIdx);
                }

                // Restore buffer flag of 384KB
                for(uBufFlagIdx=0; uBufFlagIdx<24; uBufFlagIdx++)
                {
                    if(g32TempBufFlag[uBufFlagIdx])
                    {
#if _ENABLE_RAID
                        rmSetBufRaid32Sts(uBufFlagIdx, g32TempBufFlag[uBufFlagIdx]);
#else
                        rmSetBuf32Sts(uBufFlagIdx, g32TempBufFlag[uBufFlagIdx]);
#endif
                        g32TempBufFlag[uBufFlagIdx]=0;
                    }
                }

                if(gsPrdInfo.uarPrdQue[u16PrdTrig].uFua&cDelayPrdDone)    // 20190531_ChirsSu
                {
                    waitHmbPrdDone();

                    //     NLOG(cLogTempDebug, WRITE_C, 1, "AES,chkBufOccupy(), Manual Prd Hmbdelete u16PrdTrig=0x%04X", u16PrdTrig);
                    manualCompletion(cStatusSuccess, 0, cRwCmd, u16PrdTrig);
                    deletePrdLinkList(u16PrdTrig);
                }
            }
        }

        if(gsRwCtrl.ubDelayTrigHost)
        {
            while(u16PrdTrig==0xFFFF)
                ;

            // chkWaitHmbPrdDone();
            trigHostPrdTaskW(u16PrdTrig);
            gsRwCtrl.ubDelayTrigHost=0;
        }

        waitHmbPrdDone();
    }
    else    // 20190307_Bill_SMI_S0215F
    {
        NLOG(cLogGC, WRITE_C, 3, "PCIE ERROR current prd: 0x%04X , LBA:0x%08X", u16PrdTrig,
             (WORD)(gsPrdInfo.uarPrdQue[u16PrdTrig].u32LbaAddr>>16), (WORD)(gsPrdInfo.uarPrdQue[u16PrdTrig].u32LbaAddr));
    }
    // }
#endif/* if _PRJ_ISP */
}    /* chkBufOccupy */

/*
   * BYTE chkCacheHmbW()
   * {
   *  if(!gbLsbOnlyCurActCBlk)    // ||gsGcInfo.u16OccFSkipSize)    // slc only now
   *  {
   *      return cFalse;
   *  }
   *  else if(mChkCacheInBuf(gsRwCtrl.uCachePtr))
   *  {
   *      if(gsRwCtrl.uCachePtr>=(g4kNumPerPage-(gsRwCtrl.u32Debug2+1)))    // 2260 is XXXX
   *      {
   *          return cFalse;
   *      }
   *  }
   *  else if(!gsRwCtrl.uCachePtr||(gsRwCtrl.uCachePtr>=(g4kNumPerPage-gsRwCtrl.u32Debug2)))    // 2260 is XXXX
   *  {
   *      return cFalse;
   *  }
   *
   *  return cTrue;
   * }
   */

void termFlashOperW(BYTE uWait)
{
#if _PRJ_ISP||(_PRJ_SMIVU&&_GREYBOX)
    BYTE uCachePtr;    // , uCache4kCnt;

#if _ENABLE_HMB_FLUSH
    BYTE uSgmtIdx;
#endif

    chkTrigHostWrQue(0);

    if((mGetStartSctr!=0)||(mGetEndSctr!=cSctrPer4k))
    {
        readNop1Proc();
    }

    /*
       * if(gsHmbInfo.uHmbEnWrCache&&!uWait&&chkCacheHmbW())
       * {
       *  uCache4kCnt=gsRwCtrl.uCachePtr;
       *
       *  if(mChkCacheInBuf(gsRwCtrl.uCachePtr))
       *  {
       *      uCache4kCnt++;
       *  }
       *
       *  writeHmbData(g16FlashWBufPtr, uCache4kCnt<<cSctrTo4kShift, 0, cHmbWrCache, 1);
       *
       *  for(uCachePtr=0; uCachePtr<uCache4kCnt; uCachePtr++)
       *  {
       *      gsHmbInfo.u32HmbCacheHp[uCachePtr]=gsRwCtrl.u16arCacheHPage[uCachePtr];
       *      gsHmbInfo.u16HmbCacheHb[uCachePtr]=gsRwCtrl.u16arCacheHBlock[uCachePtr];
       *
       *      if(!mChkSrcInCache(gsRwCtrl.u16arCacheHBlock[uCachePtr]))
       *      {
       *          mSetSrcInCache(gsRwCtrl.u16arCacheHBlock[uCachePtr]);
       *      }
       *  }
       *
       *  gsHmbInfo.u16HmbCacheBufPtr=g16FlashWBufPtr;
       *  gsHmbInfo.uHmbCache4kCnt=uCache4kCnt;
       *
       *  while(gsRwCtrl.u32UpdFifoPtr!=gsRwCtrl.u32ProgFifoHead)
       *  {
       *      updateF2hTable(gsRwCtrl.u32ProgFifoHead);
       *  }
       *
       *  mWaitHmbTransferDone();
       * }
       * else
       */
    // {
    flushWriteCache();

    while(gsRwCtrl.u32UpdFifoPtr!=gsRwCtrl.u32ProgFifoHead)
    {
        updateF2hTable(gsRwCtrl.u32ProgFifoHead);
    }

    // }

    if(gsRwCtrl.u16OccFSkipSize>=c16WriteBufSize)
    {
        chkBufOccupy(c16Null);
    }

    g32LastLbaW=0xFFFFFFFF;
    // bkOneShotChPtr();
    // gsGcInfo.u16OccFSkipSizeBk=gsGcInfo.u16OccFSkipSize;
    // rmResetOccupyFlg;

#if (_ENABLE_HMB_FLUSH)
    for(uSgmtIdx=0; uSgmtIdx<cMaxRH2fTabNum; uSgmtIdx++)
    {
        // release all sgmts, and upload to HMB if dirty
        if(mChkRH2fTabDirty(uSgmtIdx))
        {
            modifyHmbByH2f1kTab(uSgmtIdx);
        }
    }
    mWaitHmbTransferDone();
#endif/* if (_ENABLE_HMB_FLUSH) */

    for(uCachePtr=0; uCachePtr<cMaxRH2fTabNum; uCachePtr++)
    {
        rmSetSrchTgt(uCachePtr, g32arH2f1kTabSgmt[uCachePtr]);
    }

#if _EN_PROGFAILLOG
    while(((gsRwCtrl.u32ProgFifoTail!=gsRwCtrl.u32ProgFifoHead)&&!mChkHandlePcieErrF)||mChkCacheInfoFlag(cDataProgramFail))
        ;
#else
    while((gsRwCtrl.u32ProgFifoTail!=gsRwCtrl.u32ProgFifoHead)&&!mChkHandlePcieErrF)
        ;
#endif

#if _ENABLE_RAID
    rstH2F1KInfo2(1);
#endif

    if(uWait&&(!mChkHandlePcieErrF))
    {
        waitAllChCeBzCore0();

#if _EN_PROGFAILLOG
        while((gsTskFifoCtrl.u32HeadPtr!=gsTskFifoCtrl.u32TailPtr)&&(!mChkHandlePcieErrF))
            ;
#endif
    }
#else/* if _PRJ_ISP */
    while(1)
        ;
#endif/* if _PRJ_ISP */
}    /* termFlashOperW */

#if _PRJ_ISP
WORD findSrcInBuf(WORD u16Hblock, WORD u16Hpage)
{
    BYTE uCachePtr;
    WORD u16HitBufPtr=0xFFFF;

    uCachePtr=gsRwCtrl.uCachePtr;

    while(uCachePtr>0)
    {
        uCachePtr--;

        if((gsRwCtrl.u16arCacheHPage[uCachePtr]==u16Hpage)&&(gsRwCtrl.u16arCacheHBlock[uCachePtr]==u16Hblock))
        {
            u16HitBufPtr=addWriteBufPtr(g16FlashWBufPtr, (uCachePtr*cSctrPer4k));
            break;
        }
    }

    return u16HitBufPtr;
}    /* findSrcInBuf */

void findSrcInWfifo(WORD u16Hblock, WORD u16Hpage)
{
    BYTE uPlanePtr, uProgFifoPtr;

    if(gsRwCtrl.u32ProgFifoHead==gsRwCtrl.u32UpdFifoPtr)
    {
        return;
    }

    uProgFifoPtr=gsRwCtrl.u32ProgFifoHead;

    do
    {
        uProgFifoPtr=subWrFfPtrBy1(uProgFifoPtr);
        uPlanePtr=g4kNumPerPage;

        while(uPlanePtr>0)
        {
            uPlanePtr--;

            if((garDesF2hInfo[uProgFifoPtr].u16arHPage[uPlanePtr]==u16Hpage)&&(garDesF2hInfo[uProgFifoPtr].u16arHBlock[uPlanePtr]==u16Hblock))
            {
                gsCacheInfo.u16SrchRslFBlock=garDesAddrInfo[uProgFifoPtr].u16FBlock;
                gsCacheInfo.u32SrchRslFPage=garDesAddrInfo[uProgFifoPtr].u32FPageNoTran+uPlanePtr;
                return;
            }
        }
    }
    while(uProgFifoPtr!=gsRwCtrl.u32UpdFifoPtr);
}    /* findSrcInWfifo */

// uBrk 0 - wait
//     1 - break Prd
BYTE waitHitBufDatRdy(WORD u16HitBufPtr, BYTE uBrk)
{
    LWORD u32BufSetBit=0;
    WORD u16SBufIdx=u16HitBufPtr&0x1F;
    WORD u16EBufIdx=u16SBufIdx+cSctrPer4k;

    u16HitBufPtr=u16HitBufPtr>>5;

    for(; u16SBufIdx<u16EBufIdx; u16SBufIdx++)
    {
        mSetBitMask(u32BufSetBit, u16SBufIdx&0x1F);
    }

#if _ENABLE_RAID
    while((rm32BufRaidStatus(u16HitBufPtr)&u32BufSetBit)!=u32BufSetBit)
#else
    while((rm32BufStatus(u16HitBufPtr)&u32BufSetBit)!=u32BufSetBit)
#endif
    {
        chkTrigHostWrQue(uBrk);    // 1122 here should wait prd trigger when compensate Head

        if(mChkHandlePcieErrF)
        {
            return cFalse;
        }
    }

    return cTrue;
}    /* waitHitBufDatRdy */

void setNop1Opt()
{
    WORD u16NowNodeIdx;

    u16NowNodeIdx=gsRwCtrl.uarFreeSrcQue[gsRwCtrl.u32FreeSrcFifoHead];
    gpFlashAddrInfo=&garSrcAddrInfo[u16NowNodeIdx];
    g16FBlock=gsCacheInfo.u16SrchRslFBlock;
    g32FPageNoTran=gsCacheInfo.u32SrchRslFPage;
    gpFlashAddrInfo->uTsb4kIdx=0xFF;
    gpFlashAddrInfo->uSrcIdx=u16NowNodeIdx;
    gpFlashAddrInfo->uPrdPtr=gsRwCtrl.uPrdPtr[gsRwCtrl.uCachePtr];
    tranAddrInfo(gpFlashAddrInfo);
}

#endif/* if _PRJ_ISP */
void readNop1Proc()
{
#if _PRJ_ISP
    BYTE uBrk=1;
    WORD u16BufPtr, u16HitBufPtr, u16Hblock, u16Hpage, u16ReadOpTyp, u16PrdTrig;
    LWORD u32DesAddr, u32XfrCnt;

    // if((mGetStartSctr!=0)||(mGetEndSctr!=cSctrPer4k))
    // {
    u16Hblock=gsRwCtrl.u16arCacheHBlock[gsRwCtrl.uCachePtr];
    u16Hpage=gsRwCtrl.u16arCacheHPage[gsRwCtrl.uCachePtr];
    u16PrdTrig=gsRwCtrl.uPrdPtr[gsRwCtrl.uCachePtr];
    u16BufPtr=addWriteBufPtr(g16FlashWBufPtr, (gsRwCtrl.uCachePtr<<cSctrTo4kShift));
    u16HitBufPtr=findSrcInBuf(u16Hblock, u16Hpage);

#if _GREYBOX
    if((gsGbInfo.uGreyBoxItem==cRAIDDecOnPreReadData))
    {
        g16GbGcCachebActThr=u16BufPtr;
    }
    else if((gsGbInfo.uGreyBoxItem==cRAIDDecOnLastReadData))
    {
        g16GbGcCachebActThr=u16BufPtr+mGetEndSctr;
    }
#endif

    if((mGetStartSctr!=0)&&(mGetEndSctr!=cSctrPer4k))
    {
        uBrk=0;    // should wait trigger prd to set FW occupy flag first
    }

    // while(gsRwCtrl.u32ProgFifoTail!=gsRwCtrl.u32ProgFifoHead)
    do
    {
        chkTrigHostWrQue(uBrk);

        if((mChkHandlePcieErrF)&&chkBrkWriteInPcieErr(u16PrdTrig))
        {
#if _EN_PCIE_PATH_REC
            if(mGetStartSctr!=0)
            {
                mRecPcieErrPath(cErrBrkReadNopHead);
            }
            else
            {
                mRecPcieErrPath(cErrBrkReadNopTail);
            }
#endif
            return;
        }
    }
    while((gsRwCtrl.u32ProgFifoTail!=gsRwCtrl.u32ProgFifoHead)||(gsRwCtrl.u32FreeSrcFifoTail!=gsRwCtrl.u32FreeSrcFifoHead));

    if(u16HitBufPtr!=0xFFFF)    // hit in cache
    {
        while(gsRwCtrl.u32FreeSrcFifoTail!=gsRwCtrl.u32FreeSrcFifoHead)
            ;

        while(waitHitBufDatRdy(u16HitBufPtr, (mGetStartSctr==0))!=cTrue)
        {
            if((mChkHandlePcieErrF)&&chkBrkWriteInPcieErr(u16PrdTrig))
            {
#if _EN_PCIE_PATH_REC
                if(mGetStartSctr!=0)
                {
                    mRecPcieErrPath(cErrBrkReadNopCopyHead);
                }
                else
                {
                    mRecPcieErrPath(cErrBrkReadNopCopyTail);
                }
#endif
                return;
            }
        }

        if(mGetStartSctr!=0)    // preload
        {
#if 1
            bopCopyRam((LWORD)(c32Tsb0SAddr+(u16BufPtr*0x0200)),
                       (LWORD)(c32Tsb0SAddr+(u16HitBufPtr*0x0200)),
                       (mGetStartSctr*0x0200),
                       cCopyTsb2Tsb|cBopWait|cBopEnCrc);
#else
            hdmaCopyRam((LWORD)(c32Tsb0SAddr+(u16BufPtr*0x0200)),
                        (LWORD)(c32Tsb0SAddr+(u16HitBufPtr*0x0200)),
                        (mGetStartSctr*0x0200),
                        cCopyTsb2Tsb|cHdmaWait|cHdmaEnCrc);
#endif
#if (_GREYBOX)
            if(gsGbInfo.uGreyBoxItem==cErrHdlE2EHostData)
            {
                if((gsGbInfo.uGreyBoxOpt==cVOpE2EWriteNopError)&&(gsGbInfo.uStag!=cVsTriggered))
                {
                    (*(WORD *)(c32TsbCrcAddr+(u16BufPtr*8)))=c16BitFF;
                    outSta(cVTrig);
                    gsGbInfo.u32BkValue=u16Hblock*g32SectorPerBlockH+(u16Hpage<<cSctrTo4kShift);
                    gsGbInfo.uStag=cVsTriggered;
                }
            }
#endif/* if (_GREYBOX) */
            invPlaneBufFlagCore0(u16BufPtr, mGetStartSctr, cInvBufFlag|cInvOccFlag);
        }

        if(mGetEndSctr!=cSctrPer4k)    // post load
        {
#if 1
            bopCopyRam((LWORD)(c32Tsb0SAddr+((u16BufPtr+mGetEndSctr)*0x0200)), (LWORD)(c32Tsb0SAddr+((u16HitBufPtr+mGetEndSctr)*0x0200)),
                       ((cSctrPer4k-mGetEndSctr)*0x0200), cCopyTsb2Tsb|cBopWait|cBopEnCrc);
#else
            hdmaCopyRam((LWORD)(c32Tsb0SAddr+((u16BufPtr+mGetEndSctr)*0x0200)), (LWORD)(c32Tsb0SAddr+((u16HitBufPtr+mGetEndSctr)*0x0200)),
                        ((cSctrPer4k-mGetEndSctr)*0x0200), cCopyTsb2Tsb|cHdmaWait|cHdmaEnCrc);
#endif

            invPlaneBufFlagCore0(u16BufPtr+mGetEndSctr, cSctrPer4k-mGetEndSctr, cInvBufFlag);
        }
    }
    else
    {
        gsCacheInfo.u16SrchRslFBlock=c16FBlockInitValue;
        gsCacheInfo.u32SrchRslFPage=c32BitFF;

        if(gsRwCtrl.u32UpdFifoPtr!=gsRwCtrl.u32ProgFifoHead)
        {
            findSrcInWfifo(u16Hblock, u16Hpage);
        }

        if(gsCacheInfo.u16SrchRslFBlock==c16FBlockInitValue)
        {
            findReadSrc(u16Hblock, u16Hpage, (gbEnAes?cBit0:0));
        }

        u16ReadOpTyp=c16Bit1|c16Bit4|c16Bit6|c16Bit15;

        if(mGetStartSctr!=0)    // pre load
        {
            if(gsCacheInfo.u16SrchRslFBlock!=c16FBlockInitValue)
            {
                setNop1Opt();
                gSectorH=mTranSctr4kAddr(g32FPageNoTran);
                mSetFRwParam(u16BufPtr, mGetStartSctr, u16ReadOpTyp, cPreReadData);
                gsRwCtrl.u32FreeSrcFifoHead=(gsRwCtrl.u32FreeSrcFifoHead+1)&(cReadFifoDpt-1);
                u16ReadOpTyp|=c16Bit2;
            }
            else
            {
                u32DesAddr=c32Tsb0SAddr+0x200*u16BufPtr;
                u32XfrCnt=0x200*mGetStartSctr;

                gsE2eInfo.u32GenerateLba=u16Hblock*g32SectorPerBlockH+(u16Hpage<<cSctrTo4kShift);

#if 1
                bopClrRam((LWORD)u32DesAddr, u32XfrCnt, gsNamespace.u32DummyPatt, cClrTsb|cBopWait|cBopEnCrc|cBopGenCrc);
#else
                hdmaClrRam((LWORD)u32DesAddr, u32XfrCnt, gsNamespace.u32DummyPatt, cClrTsb|cHdmaWait|cHdmaEnCrc|cHdmaGenCrc);
#endif
#if (_GREYBOX)
                if(gsGbInfo.uGreyBoxItem==cErrHdlE2EHostData)
                {
                    if((gsGbInfo.uGreyBoxOpt==cVOpE2EReadDummyError)&&(gsGbInfo.uStag!=cVsTriggered))
                    {
                        (*(WORD *)(c32TsbCrcAddr+(u16BufPtr*8)))=c16BitFF;
                        outSta(cVTrig);
                        gsGbInfo.u32BkValue=u16Hblock*g32SectorPerBlockH+(u16Hpage<<cSctrTo4kShift);
                        gsGbInfo.uStag=cVsTriggered;
                    }
                }
#endif

                chkTrigHostWrQue(0);
#if _EN_WRHWPRDCORE1
                while(gsPrdInfo.u32TrigWrCmdTrig!=gsPrdInfo.u32TrigWrCmdTail)
                    ;
#endif
                invPlaneBufFlagCore0(u16BufPtr, mGetStartSctr, cInvBufFlag|cInvOccFlag);
                // }
            }
        }

        if(mGetEndSctr!=cSctrPer4k)    // post load
        {
            if(gsCacheInfo.u16SrchRslFBlock!=c16FBlockInitValue)
            {
                setNop1Opt();
                gSectorH=mTranSctr4kAddr(g32FPageNoTran)+mGetEndSctr;
                mSetFRwParam(u16BufPtr+mGetEndSctr, cSctrPer4k-mGetEndSctr, u16ReadOpTyp, cLastReadData);
                setFwPreOccuFlag(u16BufPtr+mGetEndSctr);    // Finn
                gsRwCtrl.u32FreeSrcFifoHead=(gsRwCtrl.u32FreeSrcFifoHead+1)&(cReadFifoDpt-1);
            }
            else
            {
                u32DesAddr=c32Tsb0SAddr+0x200*(u16BufPtr+mGetEndSctr);
                u32XfrCnt=0x200*(cSctrPer4k-mGetEndSctr);

                gsE2eInfo.u32GenerateLba=u16Hblock*g32SectorPerBlockH+((LWORD)u16Hpage<<cSctrTo4kShift)+mGetEndSctr;

#if 1
                bopClrRam((LWORD)u32DesAddr, u32XfrCnt, gsNamespace.u32DummyPatt, cClrTsb|cBopWait|cBopEnCrc|cBopGenCrc);
#else
                hdmaClrRam((LWORD)u32DesAddr, u32XfrCnt, gsNamespace.u32DummyPatt, cClrTsb|cHdmaWait|cHdmaEnCrc|cHdmaGenCrc);
#endif
                invPlaneBufFlagCore0((u16BufPtr+mGetEndSctr), (cSctrPer4k-mGetEndSctr), cInvBufFlag);
            }
        }
    }

    gsCacheInfo.u32WriteSctr2ChgBlk-=(mGetStartSctr+(cSctrPer4k-mGetEndSctr));

    chkWriteSctr2ChgBlk();

    gsRwCtrl.uCacheStartSctr=0;
    gsRwCtrl.uCacheEndSctr=cSctrPer4k;
    // }
#else/* if _PRJ_ISP */
    while(1)
        ;
#endif/* if _PRJ_ISP */
}    /* readNop1Proc */

#if _PRJ_ISP||_PRJ_NVME||(_PRJ_SMIVU&&_GREYBOX)
void rstRdyTyp()
{
    fillCcmVal((BYTE *)&gsRwCtrl.uRdyTyp[0][0], cMaxChNum*cMaxIntlvWay, cRdyTypNorm);
    /*
       * BYTE uCh, uIntlv;
       *
       * for (uCh=0; uCh<gTotalChNum; uCh++)
       * {
       *  for (uIntlv=0; uIntlv<cMaxIntlvWay; uIntlv++)
       *  {
       *      gsRwCtrl.uRdyTyp[uCh][uIntlv]=0;
       *  }
       * }
       */
}

BYTE chkCacheF2hTabFull(WORD u16ProgPageOfst)
{
    if((gsCacheInfo.u32CacheFreePagePtr+u16ProgPageOfst)>=
       (LWORD)((gsCacheInfo.uF2hTabBank*gsCacheInfo.u16TotalPgPerF2hTab)+gsCacheInfo.u16ValidPgPerF2hTab))
    {
        return cTrue;
    }
    else
    {
        return cFalse;
    }
}

#endif/* if _PRJ_ISP */
BYTE chkBrkWriteInPcieErr(WORD u16PrdTrig)
{
    chkReleaseFreeHwPrd();

    if(mChkToDoHdlPcieWErrF)
    {
        return cTrue;
    }
    else if(gsPrdInfo.usWritePrdList.u16Tail==cNull)
    {
        return cFalse;
    }
    else if(u16PrdTrig==gsPrdInfo.usWritePrdList.u16Tail)
    {
        if(r32NvmePrd[gsPrdInfo.uarPrdQue[u16PrdTrig].uHwPrdIdx][5]||gsPrdInfo.uarPrdQue[u16PrdTrig].u32RestScrtCnt||
           (gsPrdInfo.uarPrdQue[u16PrdTrig].uHwPrdIdx==cNull))
        {
            tracePcieEvent(cDebugRwDigit|6);
            mSetToDoHdlPcieWErrF;
            return cTrue;
        }

        return cFalse;
    }
    else
    {
        while(u16PrdTrig!=cNull)
        {
            if(u16PrdTrig==gsPrdInfo.usWritePrdList.u16Tail)
            {
                return cFalse;
            }

            u16PrdTrig=gsPrdInfo.uarPrdLink[u16PrdTrig].uNext;
        }

        tracePcieEvent(cDebugRwDigit|5);
        mSetToDoHdlPcieWErrF;
        gsPcieErrInfo.u16GetWrPrdTailPtr=gsPrdInfo.usWritePrdList.u16Tail;
        return cTrue;
    }
}    /* chkBrkWriteInPcieErr */

void initNewFblkProc(WORD u16PrdTrig)
{
#if _PRJ_ISP||(_PRJ_SMIVU&&_GREYBOX)
#if _GREYBOX
    outCS(cbTaginitNewFblkProc);
#endif

    if(mChkCacheInBufF)
    {
        if((mGetStartSctr!=0)||(mGetEndSctr!=cSctrPer4k))
        {
            readNop1Proc();
        }

        if(mChkCacheInBuf(gsRwCtrl.uCachePtr)&&(!mChkToDoHdlPcieWErrF))
        {
            if(mChkNewDesF)
            {
                setWriteDes(gsRwCtrl.u16ProgPageOfst, &garDesAddrInfo[gsRwCtrl.u32ProgFifoHead], cWriteCache);
                mClrNewDesF;
            }

            garDesF2hInfo[gsRwCtrl.u32ProgFifoHead].u16arHPage[gsRwCtrl.uCachePtr]=gsRwCtrl.u16arCacheHPage[gsRwCtrl.uCachePtr];
            garDesF2hInfo[gsRwCtrl.u32ProgFifoHead].u16arHBlock[gsRwCtrl.uCachePtr]=gsRwCtrl.u16arCacheHBlock[gsRwCtrl.uCachePtr];
            rmSetSrchTgt(gsRwCtrl.uMaskTgtPtr,
                         (gsRwCtrl.u16arCacheHBlock[gsRwCtrl.uCachePtr]<<16)|gsRwCtrl.u16arCacheHPage[gsRwCtrl.uCachePtr]);
            gsRwCtrl.uMaskTgtPtr++;
            setProgFifoOpt(u16PrdTrig);
        }
    }

    if(chkCacheF2hTabFull(gsRwCtrl.u16ProgPageOfst)==cTrue)
    {
        while(gsRwCtrl.u32UpdFifoPtr!=gsRwCtrl.u32ProgFifoHead)
        {
            updateF2hTable(gsRwCtrl.u32ProgFifoHead);
        }

        while((gsRwCtrl.u32ProgFifoTail!=gsRwCtrl.u32ProgFifoHead)&&!mChkHandlePcieErrF)
            ;

        // rstRdyTyp();
    }

    if(mChkHandlePcieErrF&&chkBrkWriteInPcieErr(u16PrdTrig)&&!mChkDummyWrite)
    {
#if _EN_PCIE_PATH_REC
        mRecPcieErrPath(cErrInitNewFblkProc);
#endif
        return;
    }

    if(mChkCacheInfoFlag(cCacheBlockFull))
    {
        initCacheFblkProc();    // POP 1 BLOCK
        mSetCalWriteSctr2ChgBlk;
    }

    if(mChkCalWriteSctr2ChgBlk)
    {
        getWriteSctr2ChgBlk();
    }
#else/* if _PRJ_ISP */
    while(1)
        ;
#endif/* if _PRJ_ISP */
}    /* initNewFblkProc */

#if _PRJ_ISP||(_PRJ_SMIVU&&_GREYBOX)
void getWriteSctr2ChgBlk()
{
    LWORD u32RestSctrOfDesFblk, u32CacheFreePagePtr=gsCacheInfo.u32CacheFreePagePtr;

    mClrCalWriteSctr2ChgBlk;

    while(u32CacheFreePagePtr>=gsCacheInfo.u16TotalPgPerF2hTab)
    {
        u32CacheFreePagePtr-=gsCacheInfo.u16TotalPgPerF2hTab;
    }

    u32RestSctrOfDesFblk=(LWORD)(gsCacheInfo.u16ValidPgPerF2hTab-gsRwCtrl.u16ProgPageOfst-u32CacheFreePagePtr);

    if(mChkCacheInBufF)
    {
        u32RestSctrOfDesFblk-=gsRwCtrl.uCachePtr;
    }

    u32RestSctrOfDesFblk<<=cSctrTo4kShift;
    gsCacheInfo.u32WriteSctr2ChgBlk=u32RestSctrOfDesFblk;
}    /* getWriteSctr2ChgBlk */

void postFlashAddrInfoW()
{
    BYTE uWriteSctrCnt, uStartSector;
    WORD u16PrdSctrCnt, u16PrdTrig, u16Hblock, u16Hpage;
    LWORD u32TotalSctrCnt;
    PRDQUEUE *upPrdInfo;

#if (_EN_IOMTRIG&&_EN_VPC_SWAP)
    LWORD u32LbaAddr, u32SctrCnt;
#endif
#if _EN_CDMTRIG
    LWORD u32CDM_nowTime;
#endif
    u16PrdTrig=gsPrdInfo.usWritePrdList.u16Trig;

    // while(u16PrdTrig!=cNull)
    do
    {
        trigHostPrdTaskW(u16PrdTrig);

        upPrdInfo=&gsPrdInfo.uarPrdQue[u16PrdTrig];

#if _EN_CDMTRIG
        if(gCDMStatus!=cCDM_Triger)
        {
            if(upPrdInfo->ubContLba&&(!upPrdInfo->uStartSctr))    // 20190618_ChrisSu
            {
                if((g32CDM_WSctrCnt>cCDM750M)&&(g32CDM_WSctrCnt<cCDM1200M))
                {
                    // 800MB                  //1200MB
                    if(gCDMStatus==cCDM_Non)
                    {
                        NLOG(cLogGC, WRITE_C, 2, "CDM PrePare ,g32CDM_WSctrCnt=0x%08x ", g32CDM_WSctrCnt>>16, g32CDM_WSctrCnt);
                    }

                    gCDMStatus=cCDM_PrePare;
                }
                else if(g32CDM_WSctrCnt>=cCDM1200M)
                {
                    gCDMStatus=cCDM_Non;
                    // NLOG(cLogGC, WRITE_C, 0, "CDM_non, over 1200M");
                }

                g32CDM_SWCnt++;
                g32CDM_WSctrCnt+=upPrdInfo->u32SctrCnt;
            }
            else if(g32CDM_SWCnt)    // NON cdm SeqW 128K Cmd && g32CDM_SWCount
            {
                g32CDM_WBrkCnt++;

                if((g32CDM_SWCnt>>3)<g32CDM_WBrkCnt)
                {
                    /*
                       * NLOG(cLogGC,
                       *   WRITE_C,
                       *   4,
                       *   "g32CDM_WBrkCnt = 0x%08x,g32CDM_SWCnt=0x%08x",
                       *   g32CDM_WBrkCnt>>16,
                       *   g32CDM_WBrkCnt,
                       *   g32CDM_SWCnt>>16,
                       *   g32CDM_SWCnt);*/
                    InitCDM();
                }
            }
        }
        else
        {
            u32CDM_nowTime=rmGetRtc1sTick;

            if(u32CDM_nowTime>(g32CDMTimer+250))    // 250s
            {
                NLOG(cLogGC, WRITE_C, 0, "CDM_Triger Cancel,5mins");

                InitCDM();
            }
        }
#endif/* if _EN_CDMTRIG */

#if (_EN_IOMTRIG&&_EN_VPC_SWAP)
        if(gsIomInfo.u8Status!=cIoMeterTrig)
        {
            u32LbaAddr=upPrdInfo->u32LbaAddr;
            u32SctrCnt=upPrdInfo->u32SctrCnt;

            if((gsIomInfo.u32SeqLba==u32LbaAddr)||(gsIomInfo.u32SeqLba==(u32LbaAddr+u32SctrCnt))||
               (gsIomInfo.u32SeqLba==(u32LbaAddr-u32SctrCnt)))
            {
                gsIomInfo.u8ThrdCnt++;

                if(gsIomInfo.u8ThrdCnt==4)    // 4 Thr W
                {
                    // cIoMeterChk only data < 1GB  //20190604_ChrisSu
                    if((gsIomInfo.u8Status!=cIoMeterChk)&&(gsGcInfo.u32TotalSlcVpc+gsGcInfo.u32TotalTlcVpc<IM_Chk_Size))
                    {
                        gsIomInfo.u8Status=cIoMeterChk;
                    }

                    if((gsIomInfo.u8Status==cIoMeterChk))
                    {
                        gsIomInfo.u8ThrdCnt=0;
                        gsIomInfo.u32SeqLba=gsIomInfo.u32SeqLba+u32SctrCnt;
                        gsIomInfo.u32SeqLen+=u32SctrCnt;
                        gsIomInfo.u32SeqCmdCnt++;
                    }
                }
            }
            else
            {
                gsIomInfo.u8ThrdCnt=1;
                gsIomInfo.u32SeqLba=u32LbaAddr;

                if(gsIomInfo.u8Status==cIoMeterChk)
                {
                    gsIomInfo.u32RanCmdCnt++;

                    if(gsIomInfo.u32SeqCmdCnt<gsIomInfo.u32RanCmdCnt)    // 4:1 4ThrdSeq <80%
                    {
                        NLOG(cLogGC,
                             WRITE_C,
                             4,
                             "Cancel IOMeterChk RanCmd= 0x%08X,SeqCmd= 0x%08X ",
                             gsIomInfo.u32RanCmdCnt>>16,
                             gsIomInfo.u32RanCmdCnt,
                             gsIomInfo.u32SeqCmdCnt>>16,
                             gsIomInfo.u32SeqCmdCnt);
                        InitIoMeter();
                    }
                }
            }
        }    // gIOMeterSts!=cIoMeterTrig

        if(gsIomInfo1Thr.u8Status!=cIoMeterTrig)
        {
            u32SctrCnt=upPrdInfo->u32SctrCnt;

            if(upPrdInfo->ubContLba)
            {
                if((gsIomInfo1Thr.u8Status!=cIoMeterChk)&&(gsGcInfo.u32TotalSlcVpc+gsGcInfo.u32TotalTlcVpc<IM_Chk_Size))
                {
                    gsIomInfo1Thr.u8Status=cIoMeterChk;
                }

                if((gsIomInfo1Thr.u8Status==cIoMeterChk))
                {
                    gsIomInfo1Thr.u32SeqLen+=u32SctrCnt;
                    gsIomInfo1Thr.u32SeqCmdCnt++;
                }
            }
            else
            {
                if(gsIomInfo1Thr.u8Status==cIoMeterChk)
                {
                    gsIomInfo1Thr.u32RanCmdCnt++;

                    if((gsIomInfo1Thr.u32SeqCmdCnt>>3)<gsIomInfo1Thr.u32RanCmdCnt)    // 8:1
                    {
                        InitIoMeter1Thr();
                    }
                    else if((gsIomInfo1Thr.u32SeqCmdCnt>>3)<gsIomInfo1Thr.u32ReadCmdCnt)
                    {
                        InitIoMeter1Thr();
                    }
                }
            }
        }    // gIOMeterSts!=cIoMeterTrig
#endif/* if _EN_IOMTRIG */

#if _EN_Lenovo_RecoveryChk
        if(gsIomInfo_RecoveryCheck.u8Status!=cRecoverychkTrig)
        {
            if(upPrdInfo->ubContLba)
            {
                if((gsIomInfo_RecoveryCheck.u8Status!=cIoMeterChk)&&(gsGcInfo.u32TotalSlcVpc+gsGcInfo.u32TotalTlcVpc<IM_Chk_Size))
                {
                    // NLOG(cLogGC, WRITE_C, 0, "Iometer RecoveryCheck PreChk!!!! <4GB");
                    gsIomInfo_RecoveryCheck.u8Status=cIoMeterChk;
                }

                if(gsIomInfo_RecoveryCheck.u8Status==cIoMeterChk)
                {
                    gsIomInfo_RecoveryCheck.u32SeqLen+=upPrdInfo->u32SctrCnt;
                    gsIomInfo_RecoveryCheck.u32SeqCmdCnt++;
                }
            }
            else
            {
                gsIomInfo_RecoveryCheck.u32RanCmdCnt++;

                if((gsIomInfo_RecoveryCheck.u32SeqCmdCnt)>>8<gsIomInfo_RecoveryCheck.u32RanCmdCnt)    // 8:1
                {
                    InitIoMeter_RecoveryChk();
                }
            }
        }
#endif/* if _EN_Lenovo_RecoveryChk */

        if(!upPrdInfo->ubContLba)
        {
            tranLba2HAddr(upPrdInfo->u32LbaAddr, &gsWriteHAddrInfo);
            mSetChgBlock;
            // restoOneShotChPtr();
        }

        if(gsRwCtrl.ubDelayTrigHost)
        {
            initNewFblkProc(u16PrdTrig);
            mClrChgBlock;

            if(gsRwCtrl.u16OccFSkipSize>=c16WriteBufSize)
            {
                chkBufOccupy(u16PrdTrig);
            }

            if(mChkHandlePcieErrF&&chkBrkWriteInPcieErr(u16PrdTrig))
            {
#if _EN_PCIE_PATH_REC
                mRecPcieErrPath(cErrDelayTrigHost);
#endif
                return;
            }
        }

        u32TotalSctrCnt=upPrdInfo->u32SctrCnt;

        while(1)
        {
            if(mChkDummyWrite)
            {
                break;
            }

            uStartSector=gStartSector;

            if(gsPrdInfo.u16TrigHostRestSectCnt)
            {
                u16PrdSctrCnt=getWrPrdCnt(gsPrdInfo.u16TrigHostRestSectCnt, uStartSector);
                gsPrdInfo.u16TrigHostRestSectCnt-=u16PrdSctrCnt;
            }
            else
            {
                u16PrdSctrCnt=getWrPrdCnt(u32TotalSctrCnt, uStartSector);
            }

            u32TotalSctrCnt-=u16PrdSctrCnt;

            while(1)
            {
                u16Hblock=g16HBlock;
                u16Hpage=g16HPage;

                if(mChkChgBlock)
                {
                    initNewFblkProc(u16PrdTrig);
                    mClrChgBlock;

                    if(gsRwCtrl.u16OccFSkipSize>=c16WriteBufSize)
                    {
                        chkBufOccupy(u16PrdTrig);
                    }

                    if(mChkHandlePcieErrF&&chkBrkWriteInPcieErr(u16PrdTrig))
                    {
#if _EN_PCIE_PATH_REC
                        mRecPcieErrPath(cErrChkChgBlock);
#endif
                        return;
                    }
                }

                if(mChkDummyWrite)
                {
                    break;
                }

                // uWriteSctrCnt=getWriteSctrCnt(u16PrdSctrCnt);
                uWriteSctrCnt=cSctrPer4k-uStartSector;

                if(uWriteSctrCnt>u16PrdSctrCnt)
                {
                    uWriteSctrCnt=u16PrdSctrCnt;
                    mSetCacheInBufW;
                }
                else
                {
                    mClrCacheInBufW;
                }

#if _EN_WUNCTable    // WUNCTable Chief_21081121
                if(gsWUNCInfo.uWuncCnt&(~cBit4))
                {
                    NLOG(cLogHost, WRITE_C, 3, "Write clear u16HBlock[uIdx]=0x%04X,u16HPage[uIdx]=0x%04X,uWuncCnt=0x%04X",
                         gpHostAddrInfo->u16HBlock,
                         gpHostAddrInfo->u16HPage,
                         gsWUNCInfo.uWuncCnt);

                    BYTE uIdx, uStartSct=gStartSector, uChkSctrCnt=0;

                    for(uIdx=0; uIdx<C_MaxWUNCLAACnt; uIdx++)
                    {
                        if((gsWUNCInfo.u16HBlock[uIdx]==gpHostAddrInfo->u16HBlock)&&(gsWUNCInfo.u16HPage[uIdx]==gpHostAddrInfo->u16HPage))
                        {
                            for(; uChkSctrCnt<uWriteSctrCnt; uChkSctrCnt++)
                            {
                                gsWUNCInfo.uBitMap[uIdx]&=(~cbBitTab[uStartSct]);
                                uStartSct++;
                            }

                            NLOG(cLogHost, WRITE_C, 3, "Write clear uStartSct=0x%04X,uWriteSctrCnt=0x%04X,uBitMap=0x%04X",
                                 uStartSct, uWriteSctrCnt, gsWUNCInfo.uBitMap[uIdx]);

                            if(!gsWUNCInfo.uBitMap[uIdx])
                            {
                                gsWUNCInfo.u16HBlock[uIdx]=c16BitFF;
                                gsWUNCInfo.u16HPage[uIdx]=c16BitFF;
                                gsWUNCInfo.uWuncCnt--;
                                NLOG(cLogHost, WRITE_C, 3, "Write clear u16HBlock[uIdx]=0x%04X,u16HPage[uIdx]=0x%04X, uWuncCnt=0x%04X",
                                     gpHostAddrInfo->u16HBlock, gpHostAddrInfo->u16HPage, gsWUNCInfo.uWuncCnt);
                            }

                            gsWUNCInfo.uWuncCnt|=cBit4;

                            break;
                        }
                    }
                }
#endif/* if _EN_WUNCTable */

                if(!mChkCacheInBuf(gsRwCtrl.uCachePtr))
                {
                    gsRwCtrl.u16arCacheHPage[gsRwCtrl.uCachePtr]=u16Hpage;
                    gsRwCtrl.u16arCacheHBlock[gsRwCtrl.uCachePtr]=u16Hblock;
                    gsRwCtrl.uCacheStartSctr=uStartSector;
                }

                gsRwCtrl.uPrdPtr[gsRwCtrl.uCachePtr]=u16PrdTrig;
                gsRwCtrl.uCacheEndSctr=uStartSector+uWriteSctrCnt;

                if(mChkCacheInBufW)    // need wait host or read back the latter data of this HPage4K
                {
                    mSetCacheInBuf(gsRwCtrl.uCachePtr);
                }
                else
                {
                    if((mGetStartSctr!=0)||(mGetEndSctr!=cSctrPer4k))
                    {
                        readNop1Proc();

                        if(mChkHandlePcieErrF&&chkBrkWriteInPcieErr(u16PrdTrig))
                        {
#if _EN_PCIE_PATH_REC
                            mRecPcieErrPath(cErrBrkReadNopBfPostWr);
#endif
                            return;
                        }
                    }

                    if(mChkHandlePcieErrF&&chkBrkWriteInPcieErr(u16PrdTrig))
                    {
                        return;
                    }

                    if(mChkNewDesF)
                    {
                        setWriteDes(gsRwCtrl.u16ProgPageOfst, &garDesAddrInfo[gsRwCtrl.u32ProgFifoHead], cWriteCache);
                        mClrNewDesF;    // gbNewDesF=0;
                    }

                    garDesF2hInfo[gsRwCtrl.u32ProgFifoHead].u16arHPage[gsRwCtrl.uCachePtr]=u16Hpage;
                    garDesF2hInfo[gsRwCtrl.u32ProgFifoHead].u16arHBlock[gsRwCtrl.uCachePtr]=u16Hblock;
                    rmSetSrchTgt(gsRwCtrl.uMaskTgtPtr, (u16Hblock<<16)|u16Hpage);
                    gsRwCtrl.uMaskTgtPtr++;
                    setProgFifoOpt(u16PrdTrig);
                }

                // incWriteAddr(uWriteSctrCnt);
                addLbaAddr(uWriteSctrCnt);
                gsCacheInfo.u32WriteSctr2ChgBlk-=uWriteSctrCnt;

                chkWriteSctr2ChgBlk();

                u16PrdSctrCnt-=uWriteSctrCnt;

                if(gsRwCtrl.u16OccFSkipSize>=c16WriteBufSize)
                {
                    chkBufOccupy(u16PrdTrig);
                }

                if(u16PrdSctrCnt)
                {
                    uStartSector=gStartSector;
                }
                else
                {
                    break;
                }

                if(mChkHandlePcieErrF&&chkBrkWriteInPcieErr(u16PrdTrig))
                {
                    return;
                }
            }

            if(u32TotalSctrCnt)
            {
                chkReleaseFreeHwPrd();

                if(gsPrdInfo.uTrigWCmdCnt)
                {
                    chkTrigHostWrQue(1);
                }
            }
            else
            {
#if (_FUA_PERF)
                if(mChkQueueFuaCmd&&(gsPrdInfo.uTotalPrdTaskCnt>=cFuaQueueSize))    // cFuaQueueSize
                {
                    termFuaWFlow();
                }
#endif

                if((upPrdInfo->uFua&cHdlNvmeFlush)&&(!(upPrdInfo->uFuaDone&cBit0)))    // 20190417_ChrisSu
                {
#if (!_FUA_PERF)
                    mSetTermWFua;
                    termFlashOperW(1);
                    mClrTermWFua;
#else
                    mSetQueueFuaCmd;
                    gFuaQueueCnt++;
#endif
                    upPrdInfo->uFuaDone|=cBit0;

                    if(upPrdInfo->uFuaDone&cBit1)
                    {
                        NLOG(cLogFTL,
                             WRITE_C,
                             3,
                             "postFlashAddrInfoW DelNode u16PrdInfoIdx:0x%04X, uFuaDone:0x%04X",
                             u16PrdTrig,
                             upPrdInfo->uFuaDone);
                        manualCompletion(cStatusSuccess, 0, cRwCmd, u16PrdTrig);
                        deletePrdLinkList(u16PrdTrig);
                    }
                }

                break;
            }
        }

        u16PrdTrig=gsPrdInfo.uarPrdLink[u16PrdTrig].uNext;
    }
    while((u16PrdTrig!=cNull)&&(!mChkHandlePcieErrF));

    gsPrdInfo.usWritePrdList.u16Trig=cNull;
}    /* postFlashAddrInfoW */

#if _ENABLE_SECAPI
void backupRwBufferForSecApi(BYTE uBackup)
{
    WORD u16BufPtr;
    BYTE uBufFlagIdx=0, uTsbIdx;

    if(uBackup)    // backup
    {
        // Backup buffer flag of 64KB
        for(uBufFlagIdx=0; uBufFlagIdx<4; uBufFlagIdx++)
        {
#if _ENABLE_RAID
            if(rm32BufRaidStatus(uBufFlagIdx))
            {
                g32TempBufFlag[uBufFlagIdx]=rm32BufRaidStatus(uBufFlagIdx);
                rmSetBufRaid32Sts(uBufFlagIdx, g32TempBufFlag[uBufFlagIdx]);
            }
#else
            if(rm32BufStatus(uBufFlagIdx))
            {
                g32TempBufFlag[uBufFlagIdx]=rm32BufStatus(uBufFlagIdx);
                rmSetBuf32Sts(uBufFlagIdx, g32TempBufFlag[uBufFlagIdx]);
            }
#endif
        }

        if(gsHmbInfo.uHmbEnable)
        {
            setBufStatus(c16Tsb0SIdx, c16Tsb0Size, cTsb0);

            for(uTsbIdx=0; uTsbIdx<(c16WriteBufSize/cHmbChunkSctrSize); uTsbIdx++)
            {
                u16BufPtr=c16Tsb0SIdx+(uTsbIdx*cHmbChunkSctrSize);
                mWaitHmbRelease(2);
                txfrHmbData(cHmbWriteData,
                            u16BufPtr,
                            cHmbChunkSctrSize,
                            (uTsbIdx*cHmbChunkSctrSize)<<9,
                            uTsbIdx,
                            cHmbTsbCache,
                            cHmbTsbPath|cHmbBufflagChk,
                            0);
                writeTsbE2e2Hmb(u16BufPtr>>5, uTsbIdx);
            }

            waitHmbPrdDone();
        }
        else
        {
            // The last sector in IF-RECV Payload Buffer move to last sector in Most of the Security Algorithm.
            bopCopyRam(c32Tsb0SAddr+(255*0x200), c32Tsb0SAddr+(c16Tsb0Size-1)*0x200, 0x200, cCopyTsb2Tsb|cBopWait);
            progWproPageCore0(cWproSecurityBackupAllTsb, c16Tsb0SIdx|c16Bit15);
        }
    }
    else    // restore
    {
        if(gsHmbInfo.uHmbEnable)
        {
            for(uTsbIdx=0; uTsbIdx<(c16WriteBufSize/cHmbChunkSctrSize); uTsbIdx++)
            {
                mWaitHmbRelease(2);
                txfrHmbData(cHmbReadData,
                            c16Tsb0SIdx+(uTsbIdx*cHmbChunkSctrSize),
                            cHmbChunkSctrSize,
                            (uTsbIdx*cHmbChunkSctrSize)<<9,
                            uTsbIdx,
                            cHmbTsbCache,
                            cHmbTsbPath|cHmbReadDir|cHmbBufflagChk,
                            g32arTsbCrc[uTsbIdx*2]);
                readTsbE2eFromHmb(uTsbIdx);
            }
        }
        else
        {
            readWproPageCore0(cWproSecurityBackupAllTsb, c16Tsb0SIdx, 0);
            bopCopyRam(c32Tsb0SAddr+(c16Tsb0Size-1)*0x200, c32Tsb0SAddr+(255*0x200), 0x200, cCopyTsb2Tsb|cBopWait);
            remWproPageCore0(cWproSecurityBackupAllTsb);
        }

        // Restore buffer flag of 64KB
        for(uBufFlagIdx=0; uBufFlagIdx<4; uBufFlagIdx++)
        {
            if(g32TempBufFlag[uBufFlagIdx])
            {
#if _ENABLE_RAID
                rmSetBufRaid32Sts(uBufFlagIdx, g32TempBufFlag[uBufFlagIdx]);
#else
                rmSetBuf32Sts(uBufFlagIdx, g32TempBufFlag[uBufFlagIdx]);
#endif
                g32TempBufFlag[uBufFlagIdx]=0;
            }
        }
    }
}    /* backupRwBufferForSecApi */

#endif/* if _ENABLE_SECAPI */
#endif/* if _PRJ_ISP */







