







#if _EN_FW_DEBUG_UART
#include "inc/DebugLog.h"
#include "inc/EventLogIDX.h"
#include "inc/EventLogFunctionIDX.h"
#endif

#if _EN_VPC_SWAP
void setSkipRamInGc(BYTE uMlcMode)
{
    LWORD u32FlashModeMask;
    WORD u16Fblock;

    for(u16Fblock=0; u16Fblock<(c16MaxBlockNum/32); u16Fblock++)
    {
        u32FlashModeMask=g32arMlcMoBit[u16Fblock];

        if(uMlcMode)
        {
            u32FlashModeMask=(~u32FlashModeMask);
        }

        r32SkipRam[u16Fblock]=g32arSkipGcSrch[u16Fblock]|u32FlashModeMask;
    }
}

#endif/* if _EN_VPC_SWAP */

#if _EN_VPC_SWAP
void getGcSrcBlk()
{
    LWORD u32DiffVPC;
    BYTE uNowGcSrcBlkIdx, uPtr=0;
    BYTE uMode;
    WORD u16StartBlock, u16EndBlock;
    WORD u16FBlk=cInvldFBlk;
    BYTE uflag=cGetSlcBlockInital;

#if S_NvmeQRWT_timeout
    BYTE uMoreVpcFlow=0;
#endif
#if 0
    NLOG(cLogTempDebug,
         GCCORE1_C,
         8,
         "getGcSrcBlk Start! Act=0x%04X, Flu= 0x%04X, SrcCnt=0x%04X, GcFlow=0x%04x, SLCAvgVpc=0x%08X, VpcPerSlc=0x%08X",
         gsCacheInfo.u16ActiveCacheBlock,
         gsCacheInfo.u16FluCacheBlock,
         gsGcInfo.uGcMaxSrcBlkCnt,
         mGetGcFlow,
         g32SLCAvgVpc>>16,
         g32SLCAvgVpc,
         g32VpcPerSlcBlk>>16,
         g32VpcPerSlcBlk);
#if (_EN_VPC_SWAP&&_EN_IOMTRIG)
    NLOG(cLogTempDebug,
         GCCORE1_C,
         2,
         "MaxSlcQ=0x%04x, IoStatus=0x%04x",
         g16MaxSlcBlkQ,
         gsIomInfo.u8Status);
#endif
#endif/* if 0 */

    while(gsGcInfo.uGcSrcBlkCnt<gsGcInfo.uGcMaxSrcBlkCnt)
    {
        uNowGcSrcBlkIdx=gsGcInfo.uGcSrcBlkIdx[gsGcInfo.uGcSrcBlkCnt];
        uflag=cGetSlcBlockInital;
        uMode=0;

        if((mGetGcFlow==cGcFlowS2T)||(mGetGcFlow==cGcFlowS2S))
        {
            if(uPtr<gsGcInfo.uGCSLCReclaimPtr)
            {
                u16FBlk=gsGcInfo.u16GcRCSlcBlock[uPtr];
                uPtr++;

                if(u16FBlk==0xFFFF)
                {
                    gsFtlDbg.u16DummyFailType=cGetGcSrcBlk1;
                    debugWhile();
                }
            }
            else
            {
#if (_EN_IOMTRIG&&_EN_VPC_SWAP)
                if((gsIomInfo.u8Status==cIoMeterTrig)||(gsIomInfo1Thr.u8Status==cIoMeterTrig))
                {
                    setSkipRamInGc(0);
                    rmSetSrchLorBound(1);    // rmSetSrchLorBound(c32Bit30+1);
                    u16FBlk=
                        bopSrchRam((LWORD)g32arCacheBlkVpCnt, c32BitFF, c32BitFF, g16FirstFBlock, g16TotalFBlock, cBopSrchMin|
                                   cBopSrchSkip|cBopLwordMo|cBopWait);

                    NLOG(cLogGC, GCCORE1_C, 4, "HardwareSrch, Blk=0x%04X, BlkVpc=0x%08x, mChkMlcMoBit=0x%04x,", u16FBlk, mGetCacheBlkVpCnt(
                             u16FBlk)>>16, mGetCacheBlkVpCnt(u16FBlk), mChkMlcMoBit(u16FBlk));
                }
                else
#endif
                {
                    if(gsCacheInfo.u16DynamicSpareCnt<(g16TLCGCSpareCnt_Ori-4))
                    {
                        uMode=1;    // DynamicSLC
                        u16StartBlock=((g16GcTLCStartBlk<g16StaticBound)||(g16GcTLCStartBlk>=g16TotalFBlock))?g16StaticBound:g16GcTLCStartBlk;
                        u16EndBlock=g16TotalFBlock;
                    }
                    else
                    {
                        uMode=0;    // SLC
                        u16StartBlock=((g16GcSLCStartBlk<g16FirstFBlock)||(g16GcSLCStartBlk>=g16StaticBound))?g16FirstFBlock:g16GcSLCStartBlk;
                        u16EndBlock=g16StaticBound;
                    }

                    NLOG(cLogHost,
                         GCCORE1_C,
                         3,
                         "GetSrc Forloop start! u16StartBlock=0x%04X, u16EndBlock= 0x%04X, uMode=0x%04X",
                         u16StartBlock,
                         u16EndBlock,
                         uMode);

                    for(WORD u16FBlock=u16StartBlock; u16FBlock<=u16EndBlock; u16FBlock++)
                    {
                        if(!mChkMlcMoBit(u16FBlock)&&mChkDataBlockBit(u16FBlock)&&(u16FBlock!=u16EndBlock)&&!mChkGcSrcBlkBmap(u16FBlock)&&
                           !mChkSkipGcSrch(u16FBlock))
                        {
                            if((mGetGcFlow==cGcFlowS2S)&&(mGetCacheBlkVpCnt(u16FBlock)>g32SLCAvgVpc))
                            {}
                            else
                            {
                                u16FBlk=u16FBlock;
                                u16StartBlock=(++u16FBlock);

                                if(!uMode)
                                {
                                    g16GcSLCStartBlk=(u16StartBlock<g16StaticBound)?u16StartBlock:g16FirstFBlock;
                                }
                                else
                                {
                                    g16GcTLCStartBlk=(u16StartBlock<g16TotalFBlock)?u16StartBlock:g16StaticBound;
                                }

                                break;
                            }
                        }

                        if(u16EndBlock==u16FBlock)
                        {
                            if((((u16StartBlock==g16FirstFBlock)&&(u16EndBlock==g16StaticBound))||
                                ((u16StartBlock==g16StaticBound)&&(u16EndBlock==g16TotalFBlock)))&&!uflag)
                            {
                                NLOG(cLogTempDebug,
                                     GCCORE1_C,
                                     2,
                                     "Special case! TLCStartBlk=0x%04x, SLCStartBlk=0x%04x",
                                     g16GcTLCStartBlk,
                                     g16GcSLCStartBlk);
                                uflag=cGetSlcBlockStep1;
                            }

                            switch(uflag)
                            {
                                case 0:
                                    u16EndBlock=u16StartBlock-1;
                                    u16StartBlock=(!uMode)?g16FirstFBlock:g16StaticBound;
                                    uflag=cGetSlcBlockStep1;
                                    NLOG(cLogGC,
                                         GCCORE1_C,
                                         2,
                                         "GetSlcBlockStep1: u16StartBlock=0x%04X, u16EndBlock=0x%04X",
                                         u16StartBlock,
                                         u16EndBlock);
                                    break;

                                case 1:
                                    u16StartBlock=(!uMode)?g16StaticBound:g16FirstFBlock;
                                    u16EndBlock=(!uMode)?g16TotalFBlock:g16StaticBound;
                                    uflag=cGetSlcBlockStep2;
                                    uMode=(u16StartBlock==g16FirstFBlock)?0:1;
                                    NLOG(cLogGC,
                                         GCCORE1_C,
                                         3,
                                         "GetSlcBlockStep2: u16StartBlock=0x%04X, u16EndBlock=0x%04X, uMode=0x%04x",
                                         u16StartBlock,
                                         u16EndBlock,
                                         uMode);
                                    break;

                                default:
                                    NLOG(cLogGC, GCCORE1_C, 0, "GetSlcBlockStep3: not find Src block!");
                                    return;
                            }    /* switch */

                            u16FBlock=u16StartBlock-1;
                        }
                    }
                }
            }
        }
        else
        {
            // if((mChkGcQue(cGcTypTLCWearLvl)||mChkGcQue(cGcTypReadReclaim))&&(gsCacheInfo.u16TLCFullCacheBlockCnt<g16TlcFullCachebGcThr))
            if(gsGcInfo.uGcPrioTlcBlkNumPtr&&(gsCacheInfo.u16TLCFullCacheBlockCnt<g16TlcFullCachebGcThr))
            {
                if(uPtr<gsGcInfo.uGcPrioTlcBlkNumPtr)
                {
                    u16FBlk=gsGcInfo.u16Gc1stPrioTlcBlock[uPtr];
                    uPtr++;

                    if(u16FBlk==0xFFFF)
                    {
                        gsFtlDbg.u16DummyFailType=cGetGcSrcBlk2;
                        debugWhile();
                    }
                }
                else
                {
                    setSkipRamInGc(1);
                    rmSetSrchLorBound(1);    // rmSetSrchLorBound(c32Bit30+1);
                    u16FBlk=
                        bopSrchRam((LWORD)g32arCacheBlkVpCnt, c32BitFF, c32BitFF, g16FirstFBlock, g16TotalFBlock, cBopSrchMin|
                                   cBopSrchSkip|cBopLwordMo|cBopWait);
                }
            }
            else
            {
                setSkipRamInGc(1);

                rmSetSrchLorBound(1);    // rmSetSrchLorBound(c32Bit30+1);
                u16FBlk=
                    bopSrchRam((LWORD)g32arCacheBlkVpCnt, c32BitFF, c32BitFF, g16FirstFBlock, g16TotalFBlock, cBopSrchMin|
                               cBopSrchSkip|cBopLwordMo|cBopWait);
            }

            if(gsCacheInfo.u16DynamicSpareCnt<(cMinGCSprCnt/2))
            {
                if((gsGcInfo.u32TotalSrcBlkVpc+mGetCacheBlkVpCnt(u16FBlk))>g32VpcPerTlcBlk)
                {
                    rmSetSrchLorBound(0);
                    // return;
                    break;
                }
            }
        }

        rmSetSrchLorBound(0);
        // }

        if(u16FBlk==cInvldFBlk)
        {
            return;
        }

        if(mChkSkipGcSrch(u16FBlk))
        {
            continue;
        }

        if((mGetGcFlow==cGcFlowS2S)&&((mGetCacheBlkVpCnt(u16FBlk)+gsGcInfo.u32TotalSrcBlkVpc)>g32VpcPerSlcBlk))
        {
            return;
        }

#if S_NvmeQRWT_timeout
        else if(uMoreVpcFlow&&(mGetGcFlow!=cGcFlowS2S)&&((mGetCacheBlkVpCnt(u16FBlk)+gsGcInfo.u32TotalSrcBlkVpc)>g32VpcPerTlcBlk))
        {
            break;    // abort then go to more 1 flow
        }
#endif
        gsGcInfo.u16GcSrcBlock[uNowGcSrcBlkIdx]=u16FBlk;
        gsGcInfo.u32GcSrcBlkVpc[uNowGcSrcBlkIdx]=mGetCacheBlkVpCnt(u16FBlk);
        gsGcInfo.u32TotalSrcBlkVpc+=mGetCacheBlkVpCnt(u16FBlk);

        if(!mChkSkipGcSrch(u16FBlk))
        {
            mSetSkipGcSrch(u16FBlk);
        }

        if(!mChkGcSrcBlkBmap(u16FBlk))
        {
            mSetGcSrcBlkBmap(u16FBlk);
        }

        // if(mGetGcFlow!=cGcFlowT2T)
        // {
        if(gsGcInfo.uGcSkipPopSrcBlockCnt<cMaxSkipGcSrcBlkNum)
        {
            gsGcInfo.u16arGcSkipPopSrcBlock[gsGcInfo.uGcSkipPopSrcBlockCnt]=u16FBlk;
            gsGcInfo.uGcSkipPopSrcBlockCnt++;
        }

        // }

        gsGcInfo.uGcSrcBlkCnt++;

#if (C_Log_SaveMask&C_Debug_P2)
        NLOG(cLogGC,
             GCCORE1_C,
             8,
             "GC source blkcnt=0x%04X, blk=0x%04X, VPC=0x%08X, SLCStart=0x%04X, TLCStart=0x%04X, NextStartBlk=0x%04X, NextEndBlk=0x%04X ",
             gsGcInfo.uGcSrcBlkCnt,
             u16FBlk,
             mGetCacheBlkVpCnt(u16FBlk)>>16,
             mGetCacheBlkVpCnt(u16FBlk),
             g16GcSLCStartBlk,
             g16GcTLCStartBlk,
             u16StartBlock,
             u16EndBlock);
#endif

        if((mGetGcFlow==cGcFlowS2T)&&!mChkGcFlag(cUnderBgdGc)&&(gsGcInfo.uGcSrcBlkCnt>cMinS2SSrcBlkNum)&&
           (gsGcInfo.u32TotalSrcBlkVpc<g32VpcPerSlcBlk))
        {
            mSetGcFlow(cGcFlowS2S);
            gsGcInfo.uGcMaxSrcBlkCnt=cMaxGcSrcBlkNum;
        }

#if S_NvmeQRWT_timeout
        if((mGetGcFlow!=cGcFlowS2S)&&(!uMoreVpcFlow)&&(gsGcInfo.uGcSrcBlkCnt==gsGcInfo.uGcMaxSrcBlkCnt)&&
           (gsGcInfo.u32TotalSrcBlkVpc<g32VpcPerTlcBlk))
        {
            NLOG(cLogGC, GCCORE1_C, 1, "MoreVpcflow, OrgMaxSrcBlkCnt: 0x%04X", gsGcInfo.uGcMaxSrcBlkCnt);
            gsGcInfo.uGcMaxSrcBlkCnt=cMaxGcSrcBlkNum;
            uMoreVpcFlow=1;
        }
#endif
    }

    if(mGetGcFlow==cGcFlowS2S)
    {
        return;
    }

    if((mGetGcFlow!=cGcFlowS2S)&&(gsGcInfo.u32TotalSrcBlkVpc<g32VpcPerTlcBlk)&&(gsGcInfo.uGcSrcBlkCnt<cMaxGcSrcBlkNum))
    {
        uNowGcSrcBlkIdx=gsGcInfo.uGcSrcBlkIdx[gsGcInfo.uGcSrcBlkCnt];
        u32DiffVPC=g32VpcPerTlcBlk-gsGcInfo.u32TotalSrcBlkVpc;

        if(mGetGcFlow!=cGcFlowT2T)
        {
            setSkipRamInGc(0);
            rmSetSrchLorBound(1);
            u16FBlk=
                bopSrchRam((LWORD)g32arCacheBlkVpCnt, u32DiffVPC, c32BitFF, g16FirstFBlock, g16TotalFBlock, cBopSrchMax|
                           cBopSrchSkip|cBopLwordMo|cBopWait);
        }
        else
        {
            setSkipRamInGc(1);
            rmSetSrchLorBound(1);    // rmSetSrchLorBound(c32Bit30+1);

            if(gsGcInfo.uGcSrcBlkCnt==1)
            {
                u16FBlk=
                    bopSrchRam((LWORD)g32arCacheBlkVpCnt, c32BitFF, c32BitFF, g16FirstFBlock, g16TotalFBlock, cBopSrchMin|
                               cBopSrchSkip|cBopLwordMo|cBopWait);
            }
            else
            {
                u16FBlk=
                    bopSrchRam((LWORD)g32arCacheBlkVpCnt, u32DiffVPC, c32BitFF, g16FirstFBlock, g16TotalFBlock, cBopSrchMax|
                               cBopSrchSkip|cBopLwordMo|cBopWait);
            }
        }

        rmSetSrchLorBound(0);

        if(u16FBlk==cInvldFBlk)
        {
            return;
        }

        gsGcInfo.u16GcSrcBlock[uNowGcSrcBlkIdx]=u16FBlk;
        gsGcInfo.u32GcSrcBlkVpc[uNowGcSrcBlkIdx]=mGetCacheBlkVpCnt(u16FBlk);
        gsGcInfo.u32TotalSrcBlkVpc+=mGetCacheBlkVpCnt(u16FBlk);

        if(!mChkSkipGcSrch(u16FBlk))
        {
            mSetSkipGcSrch(u16FBlk);
        }

        if(!mChkGcSrcBlkBmap(u16FBlk))
        {
            mSetGcSrcBlkBmap(u16FBlk);
        }

        // if(mGetGcFlow!=cGcFlowT2T)
        // {
        if(gsGcInfo.uGcSkipPopSrcBlockCnt<cMaxSkipGcSrcBlkNum)
        {
            gsGcInfo.u16arGcSkipPopSrcBlock[gsGcInfo.uGcSkipPopSrcBlockCnt]=u16FBlk;
            gsGcInfo.uGcSkipPopSrcBlockCnt++;
        }

        // }

        gsGcInfo.uGcSrcBlkCnt++;
#if 0    // _EN_FW_DEBUG_UART //Chief_Disable Log_20181123
        NLOG(cLogGC, GCCORE1_C, 1, "Add One SourceBlk, again; GcSrcBlkCnt: 0x%04X ", gsGcInfo.uGcSrcBlkCnt);
        NLOG(cLogGC, GCCORE1_C, 1, "GC source block: 0x%04X ", u16FBlk);
        NLOG(cLogGC, GCCORE1_C, 2, "GC source VPC: 0x%08X ", mGetCacheBlkVpCnt(u16FBlk)>>16, mGetCacheBlkVpCnt(u16FBlk));
#endif
    }
}    /* getGcSrcBlk */

#else/* if _EN_VPC_SWAP */
void getGcSrcBlk()
{
    LWORD u32DiffVPC;
    BYTE uNowGcSrcBlkIdx, uPtr=0, uTailPtrTemp=gsSlcSortQList.u16Tail;

#if S_NvmeQRWT_timeout
    BYTE uMoreVpcFlow=0;
#endif
    WORD u16FBlk=cInvldFBlk;
    BYTE uflag=cGetSlcBlockInital;
    BYTE ufirstOut=0;

    while(gsGcInfo.uGcSrcBlkCnt<gsGcInfo.uGcMaxSrcBlkCnt)
    {
        uNowGcSrcBlkIdx=gsGcInfo.uGcSrcBlkIdx[gsGcInfo.uGcSrcBlkCnt];

        if((mGetGcFlow==cGcFlowS2T)||(mGetGcFlow==cGcFlowS2S))
        {
            if(uPtr<gsGcInfo.uGCSLCReclaimPtr)
            {
                u16FBlk=gsGcInfo.u16GcRCSlcBlock[uPtr];
                uPtr++;

                if(u16FBlk==0xFFFF)
                {
                    gsFtlDbg.u16DummyFailType=cGetGcSrcBlk1;
                    debugWhile();
                }
            }
            else
            {
                if(gsSlcSortQList.u16Head==uTailPtrTemp)
                {
                    NLOG(cLogGC, GCCORE1_C, 1, "Kevin Flow step: 0x%04X", uflag);

                    if(uflag==cGetSlcBlockStep1)
                    {
                        uTailPtrTemp=gsSlcSortQList.u16Tail;
                        uflag=cGetSlcBlockStep2;
                    }
                    else
                    {
                        return;
                    }
                }

                u16FBlk=g16SlcSortQFBlk[uTailPtrTemp];
                uTailPtrTemp=garSlcSortQLink[uTailPtrTemp].uNext;

                if((mGetGcFlow==cGcFlowS2T)&&(gsCacheInfo.u16DynamicSpareCnt<(g16TLCGCSpareCnt_Ori-4))&&(u16FBlk<g16StaticBound)&&
                   (uflag!=cGetSlcBlockStep2))    //
                                                  // 20181224_KevinTest
                {
                    if(!ufirstOut)
                    {
                        NLOG(cLogGC,
                             GCCORE1_C,
                             4,
                             "Kevin Flow TLCspare: 0x%04X ,TLCfull: 0x%04X SLCspare: 0x%04X, SLCFull: 0x%04X ",
                             (WORD)gsCacheInfo.u16DynamicSpareCnt,
                             (WORD)gsCacheInfo.u16TLCFullCacheBlockCnt,
                             gsCacheInfo.u16SLCSpareCnt,
                             gsCacheInfo.u16FullCacheBlockCnt);
                        ufirstOut=1;
                    }

                    uflag=cGetSlcBlockStep1;

                    continue;
                }
            }
        }
        else
        {
            // if((mChkGcQue(cGcTypTLCWearLvl)||mChkGcQue(cGcTypReadReclaim))&&(gsCacheInfo.u16TLCFullCacheBlockCnt<g16TlcFullCachebGcThr))
            if(gsGcInfo.uGcPrioTlcBlkNumPtr&&(gsCacheInfo.u16TLCFullCacheBlockCnt<g16TlcFullCachebGcThr))
            {
                if(uPtr<gsGcInfo.uGcPrioTlcBlkNumPtr)
                {
                    u16FBlk=gsGcInfo.u16Gc1stPrioTlcBlock[uPtr];
                    uPtr++;

                    if(u16FBlk==0xFFFF)
                    {
                        gsFtlDbg.u16DummyFailType=cGetGcSrcBlk2;
                        debugWhile();
                    }
                }
                else
                {
#if _EN_VPC_SWAP
                    setSkipRamInGc(1);
                    rmSetSrchLorBound(1);    // rmSetSrchLorBound(c32Bit30+1);
                    u16FBlk=
                        bopSrchRam((LWORD)g32arCacheBlkVpCnt, c32BitFF, c32BitFF, g16FirstFBlock, g16TotalFBlock, cBopSrchMin|
                                   cBopSrchSkip|cBopLwordMo|cBopWait);
#else
                    rmSetSrchLorBound(c32Bit30+1);
                    u16FBlk=
                        bopSrchRam((LWORD)g32arCacheBlkVpCnt, c32Bit31-1, c32BitFF, g16FirstFBlock, g16TotalFBlock, cBopSrchMin|
                                   cBopLwordMo|cBopWait);
#endif
                }
            }
            else
            {
#if _EN_VPC_SWAP
                setSkipRamInGc(1);

                rmSetSrchLorBound(1);    // rmSetSrchLorBound(c32Bit30+1);
                u16FBlk=
                    bopSrchRam((LWORD)g32arCacheBlkVpCnt, c32BitFF, c32BitFF, g16FirstFBlock, g16TotalFBlock, cBopSrchMin|
                               cBopSrchSkip|cBopLwordMo|cBopWait);
#else
                rmSetSrchLorBound(c32Bit30+1);
                u16FBlk=
                    bopSrchRam((LWORD)g32arCacheBlkVpCnt, c32Bit31-1, c32BitFF, g16FirstFBlock, g16TotalFBlock, cBopSrchMin|
                               cBopLwordMo|cBopWait);
#endif
            }

            if(gsCacheInfo.u16DynamicSpareCnt<(cMinGCSprCnt/2))
            {
                if((gsGcInfo.u32TotalSrcBlkVpc+mGetCacheBlkVpCnt(u16FBlk))>g32VpcPerTlcBlk)
                {
                    rmSetSrchLorBound(0);
                    // return;
                    break;
                }
            }
        }

        rmSetSrchLorBound(0);
        // }

        if(u16FBlk==cInvldFBlk)
        {
            return;
        }

        if(mChkSkipGcSrch(u16FBlk))
        {
            continue;
        }

        if((mGetGcFlow==cGcFlowS2S)&&((mGetCacheBlkVpCnt(u16FBlk)+gsGcInfo.u32TotalSrcBlkVpc)>g32VpcPerSlcBlk))
        {
            return;
        }

#if S_NvmeQRWT_timeout
        else if(uMoreVpcFlow&&(mGetGcFlow!=cGcFlowS2S)&&((mGetCacheBlkVpCnt(u16FBlk)+gsGcInfo.u32TotalSrcBlkVpc)>g32VpcPerTlcBlk))
        {
            break;    // abort then go to more 1 flow
        }
#endif
        gsGcInfo.u16GcSrcBlock[uNowGcSrcBlkIdx]=u16FBlk;
        gsGcInfo.u32GcSrcBlkVpc[uNowGcSrcBlkIdx]=mGetCacheBlkVpCnt(u16FBlk);
        gsGcInfo.u32TotalSrcBlkVpc+=mGetCacheBlkVpCnt(u16FBlk);

        if(!mChkSkipGcSrch(u16FBlk))
        {
            mSetSkipGcSrch(u16FBlk);
        }

        if(!mChkGcSrcBlkBmap(u16FBlk))
        {
            mSetGcSrcBlkBmap(u16FBlk);
        }

        // if(mGetGcFlow!=cGcFlowT2T)
        // {
        if(gsGcInfo.uGcSkipPopSrcBlockCnt<cMaxSkipGcSrcBlkNum)
        {
            gsGcInfo.u16arGcSkipPopSrcBlock[gsGcInfo.uGcSkipPopSrcBlockCnt]=u16FBlk;
            gsGcInfo.uGcSkipPopSrcBlockCnt++;
        }

        // }

        gsGcInfo.uGcSrcBlkCnt++;

#if (C_Log_SaveMask&C_Debug_P2)
        NLOG(cLogGC, GCCORE1_C, 4, "GC source block cnt: 0x%04X block: 0x%04X VPC: 0x%08X ", gsGcInfo.uGcSrcBlkCnt, u16FBlk,
             mGetCacheBlkVpCnt(u16FBlk)>>16, mGetCacheBlkVpCnt(u16FBlk));
#endif

        if((mGetGcFlow==cGcFlowS2T)&&!mChkGcFlag(cUnderBgdGc)&&(gsGcInfo.uGcSrcBlkCnt>cMinS2SSrcBlkNum)&&
           (gsGcInfo.u32TotalSrcBlkVpc<g32VpcPerSlcBlk))
        {
            mSetGcFlow(cGcFlowS2S);
            gsGcInfo.uGcMaxSrcBlkCnt=cMaxGcSrcBlkNum;
        }

#if S_NvmeQRWT_timeout
        if((mGetGcFlow!=cGcFlowS2S)&&(!uMoreVpcFlow)&&(gsGcInfo.uGcSrcBlkCnt==gsGcInfo.uGcMaxSrcBlkCnt)&&
           (gsGcInfo.u32TotalSrcBlkVpc<g32VpcPerTlcBlk))
        {
            NLOG(cLogGC, GCCORE1_C, 1, "MoreVpcflow, OrgMaxSrcBlkCnt: 0x%04X", gsGcInfo.uGcMaxSrcBlkCnt);
            gsGcInfo.uGcMaxSrcBlkCnt=cMaxGcSrcBlkNum;
            uMoreVpcFlow=1;
        }
#endif
    }

    if(mGetGcFlow==cGcFlowS2S)
    {
        return;
    }

    if((mGetGcFlow!=cGcFlowS2S)&&(gsGcInfo.u32TotalSrcBlkVpc<g32VpcPerTlcBlk)&&(gsGcInfo.uGcSrcBlkCnt<cMaxGcSrcBlkNum))
    {
        uNowGcSrcBlkIdx=gsGcInfo.uGcSrcBlkIdx[gsGcInfo.uGcSrcBlkCnt];
        u32DiffVPC=g32VpcPerTlcBlk-gsGcInfo.u32TotalSrcBlkVpc;

        if(mGetGcFlow!=cGcFlowT2T)
        {
#if _EN_VPC_SWAP
            setSkipRamInGc(0);
            rmSetSrchLorBound(1);
            u16FBlk=
                bopSrchRam((LWORD)g32arCacheBlkVpCnt, u32DiffVPC, c32BitFF, g16FirstFBlock, g16TotalFBlock, cBopSrchMax|
                           cBopSrchSkip|cBopLwordMo|cBopWait);
#else
            rmSetSrchLorBound(1);
            u16FBlk=
                bopSrchRam((LWORD)g32arCacheBlkVpCnt, u32DiffVPC, c32BitFF, g16FirstFBlock, g16TotalFBlock, cBopSrchMax|
                           cBopLwordMo|cBopWait);
#endif
        }
        else
        {
#if _EN_VPC_SWAP
            setSkipRamInGc(1);
            rmSetSrchLorBound(1);    // rmSetSrchLorBound(c32Bit30+1);

            if(gsGcInfo.uGcSrcBlkCnt==1)
            {
                u16FBlk=
                    bopSrchRam((LWORD)g32arCacheBlkVpCnt, c32BitFF, c32BitFF, g16FirstFBlock, g16TotalFBlock, cBopSrchMin|
                               cBopSrchSkip|cBopLwordMo|cBopWait);
            }
            else
            {
                u16FBlk=
                    bopSrchRam((LWORD)g32arCacheBlkVpCnt, u32DiffVPC, c32BitFF, g16FirstFBlock, g16TotalFBlock, cBopSrchMax|
                               cBopSrchSkip|cBopLwordMo|cBopWait);
            }
#else
            rmSetSrchLorBound(c32Bit30+1);

            if(gsGcInfo.uGcSrcBlkCnt==1)
            {
                u16FBlk=
                    bopSrchRam((LWORD)g32arCacheBlkVpCnt, (c32Bit31-1), c32BitFF, g16FirstFBlock, g16TotalFBlock, cBopSrchMin|
                               cBopLwordMo|cBopWait);
            }
            else
            {
                u16FBlk=
                    bopSrchRam((LWORD)g32arCacheBlkVpCnt, (c32Bit30+u32DiffVPC), c32BitFF, g16FirstFBlock, g16TotalFBlock, cBopSrchMax|
                               cBopLwordMo|cBopWait);
            }
#endif/* if _EN_VPC_SWAP */
        }

        rmSetSrchLorBound(0);

        if(u16FBlk==cInvldFBlk)
        {
            return;
        }

        gsGcInfo.u16GcSrcBlock[uNowGcSrcBlkIdx]=u16FBlk;
        gsGcInfo.u32GcSrcBlkVpc[uNowGcSrcBlkIdx]=mGetCacheBlkVpCnt(u16FBlk);
        gsGcInfo.u32TotalSrcBlkVpc+=mGetCacheBlkVpCnt(u16FBlk);

        if(!mChkSkipGcSrch(u16FBlk))
        {
            mSetSkipGcSrch(u16FBlk);
        }

        if(!mChkGcSrcBlkBmap(u16FBlk))
        {
            mSetGcSrcBlkBmap(u16FBlk);
        }

        // if(mGetGcFlow!=cGcFlowT2T)
        // {
        if(gsGcInfo.uGcSkipPopSrcBlockCnt<cMaxSkipGcSrcBlkNum)
        {
            gsGcInfo.u16arGcSkipPopSrcBlock[gsGcInfo.uGcSkipPopSrcBlockCnt]=u16FBlk;
            gsGcInfo.uGcSkipPopSrcBlockCnt++;
        }

        // }

        gsGcInfo.uGcSrcBlkCnt++;
#if 0    // _EN_FW_DEBUG_UART //Chief_Disable Log_20181123
        NLOG(cLogGC, GCCORE1_C, 1, "Add One SourceBlk, again; GcSrcBlkCnt: 0x%04X ", gsGcInfo.uGcSrcBlkCnt);
        NLOG(cLogGC, GCCORE1_C, 1, "GC source block: 0x%04X ", u16FBlk);
        NLOG(cLogGC, GCCORE1_C, 2, "GC source VPC: 0x%08X ", mGetCacheBlkVpCnt(u16FBlk)>>16, mGetCacheBlkVpCnt(u16FBlk));
#endif
    }
}    /* getGcSrcBlk */

#endif/* if _EN_VPC_SWAP */

#if (_EN_GCPWR&&(!_EN_RAID_GC))
void chkPWREccFail(BYTE uCh)
{
    BYTE uPageSelCmd=1;

    // setFLActCh(uCh); //set in chkOpIdxAccCnt
    if(!rmChkCmdFifoBz&&rmChkUNC)
    {
        if(rmGetOpIdxCntInFifo!=0)
        {
            gUncFifoPtr=getUNCOpIdx(uCh, rmGetOpIndex+1);

            if(gUncFifoPtr==cNoUECCSrc)
            {
                while(gUncFifoPtr)
                    ;
            }
            else
            {
                LWORD u32NoUpdateFPage;
                BYTE uPlane;

                for(uPlane=0; uPlane<gPlaneNum; uPlane++)
                {
                    if(rFLCtrl[rcEccResultSts]&cb32BitTab[uPlane])
                    {
                        break;
                    }
                }

                while(uPlane==gPlaneNum)
                    ;// debug

                if(mChkMlcMoBit(garSrcAddrInfo[gUncFifoPtr].u16FBlock))
                {
                    uPageSelCmd=mGetPageSelCmdS(garSrcAddrInfo[gUncFifoPtr]);    // garSrcAddrInfo[gUncFifoPtr].uPageSelCmd;
                }

                u32NoUpdateFPage=
                    (LWORD)(garSrcAddrInfo[gUncFifoPtr].u16FPage*gsGcInfo.uGCDesPagePerWL+(uPageSelCmd-1))*
                    gTotalIntlvChPlaneNum+garSrcAddrInfo[gUncFifoPtr].uIntlvAddr*
                    gTotalChPlaneNum+garSrcAddrInfo[gUncFifoPtr].uCh*gPlaneNum+uPlane;

                // set bit mapa
                mSetInvalidGcDesPage(u32NoUpdateFPage);
                ctrlAuxQue(cIntoAuxQue);
                ctrlAuxQue(cOutAuxQue);
            }
        }
    }
}    /* chkPWREccFail */

void chkPWROpIdxTail(BYTE uCh)
{
    if(gsRwCtrl.uOpIdxAccCntR[uCh]||gsRwCtrl.uOpIdxAccCntW[uCh])
    {
        chkOpIdxAccCnt(uCh);
#if _EN_PROGFAILLOG
        chkStatusFail(uCh);
#endif
    }

    if(gEnableLdpcPipe)
    {
        chkLdpcResult(cLdpcPwr);
    }
    else
    {
        chkPWREccFail(uCh);
    }
}    /* chkPWROpIdxTail */

void trigGcFlCmdFfStep1()
{
    BYTE uCh;

    trigFlCmdFfStep3();    // cMaxIntlvWay);

    if(gEnableLdpcPipe)
    {
        if(g16LdpcDmaIdCnt&&rmChkLdpcInfoFifoReady)
        {
            chkLdpcResult(cLdpcPwr);
        }
    }
    else if(gsRwCtrl.uAllOpIdxCntR)
    {
        for(uCh=0; uCh<gTotalChNum; uCh++)
        {
            chkPWROpIdxTail(uCh);
        }
    }
}    /* trigGcFlCmdFfStep1 */

void chkPostReadFifo4Gc()    // rand
{
    WORD u16Trig;
    ADDRINFO *upAddrInfo;

    u16Trig=gsRwCtrl.usSrcCmdList.u16Trig;

    while(u16Trig!=cNull)
    {
        upAddrInfo=&garSrcAddrInfo[u16Trig];

        if(upAddrInfo->uOpTyp<cHdmaDummy)    // cPwrOnGc
        {
            chkPostPreReadFifo(u16Trig, upAddrInfo->uCh, upAddrInfo->uIntlvAddr);

            u16Trig=gsRwCtrl.uarSrcCmdLink[u16Trig].uNext;

            while(gsRwCtrl.uChPreFifoCnt[upAddrInfo->uCh]>(cMaxCeFifoRDepth-2))    // while(gsRwCtrl.uChPreFifoCnt[uCh]>(cMaxCeFifoRDepth-2))
            {
                // trigFlCmdFfStep2();
                trigGcFlCmdFfStep1();
            }
        }
    }

    gsRwCtrl.usSrcCmdList.u16Trig=u16Trig;
}    /* chkPostReadFifo3 */

#endif/* if (_EN_GCPWR&&(!_EN_RAID_GC)) */

void chkPWRCore1(BYTE uChkBank)
{
#if (_EN_GCPWR&&(!_EN_RAID_GC))
    WORD u16EofFPage, u16NowNodeIdx;
    BYTE uChIntlvAddr;    // uConstSectorH;

    //////copy from SM2258 CBC
    // setSelMulFL(1);
    // rmDisUNCStop;
    // rmDisOnesCntStop;
    // rmSetDataStopCnt(50);// 50bit is requested by Sandisk
    // resetECC();
    // setSelMulFL(0);
    ///////

    // set retry table to default
    gPSWstate=1;
    u16EofFPage=((uChkBank+1)*gsGcInfo.u16GCDesTotalPgPerF2hTab)/gTotalIntlvChPlaneNum/g4kNumPerPlane;

    while((gsGcInfo.u16PwrStrPage<u16EofFPage)&&(gsGcInfo.uGcBrkPwr==0))    // (getBrkBgdGcFCore1()!=cTrue))
    {
        if(gsRwCtrl.usSrcCmdList.u16Cnt<(cReadFifoDpt-gTotalIntlvChNum))
        {
            for(uChIntlvAddr=0; uChIntlvAddr<gTotalIntlvChNum; uChIntlvAddr++)
            {
                // asign Check Status
                u16NowNodeIdx=gsRwCtrl.uarFreeSrcQue[gsRwCtrl.u32FreeSrcFifoHead];
                gpFlashAddrInfo=&garSrcAddrInfo[u16NowNodeIdx];
                gpFlashAddrInfo->uTsb4kIdx=0xFF;
                gSrcIdx=u16NowNodeIdx;
                g16AbstrFBlock=g16FBlock=gsGcInfo.u16GcDesBlock;
                g16FPage=gsGcInfo.u16PwrStrPage;
                gIntlvAddr=uChIntlvAddr/gTotalChNum;
                gCh=uChIntlvAddr%gTotalChNum;
                gCe=mGetCEAddr(gIntlvAddr);
                gDieAddr=mGetDieAddr(gIntlvAddr);

                if(mChkMlcMoBit(g16FBlock))
                {
                    setPageSelCmd(gpFlashAddrInfo, (g16FPage%gsGcInfo.uGCDesPagePerWL)+1);
                }
                else
                {
                    setPageSelCmd(gpFlashAddrInfo, cSlcCmd);
                }

                g16FPage=(g16FPage/gsGcInfo.uGCDesPagePerWL);

                gPlaneAddr=0;
                gSectorH=0;

                mSetFRwParam(0, gSectorPerPageH, c16Bit0|c16Bit4|c16Bit7|c16Bit13|c16Bit15, cPwrOnGc);

                gsRwCtrl.u32FreeSrcFifoHead=(gsRwCtrl.u32FreeSrcFifoHead+1)&(cReadFifoDpt-1);
            }

            gsGcInfo.u16PwrStrPage++;

            if(gsRwCtrl.u32FreeSrcFifoTrig!=gsRwCtrl.u32FreeSrcFifoHead)
            {
                insSrcCmdList();
            }
        }

        if(gsRwCtrl.usSrcCmdList.u16Cnt)
        {
            chkPostReadFifo4Gc();
            trigGcFlCmdFfStep1();
        }

#if _GREYBOX
        chkGreyBoxGc(4);
#endif
    }

    while(gsRwCtrl.usSrcCmdList.u16Cnt)
    {
        chkPostReadFifo4Gc();
        trigGcFlCmdFfStep1();
    }
    gPSWstate=0;
#endif/* if (_EN_GCPWR&&(!_EN_RAID_GC)) */
}    /* chkPWRCore1 */

void modifyH2FtabCore1()
{
    WORD u16EndPtr, u16ModifyTabPtr, u16OrgFblk, u16PrevOrgFblk, u16PrevOrgFblkVpc;
    volatile WORD *u16pSortRamH2fPage;
    volatile LWORD *u32pSortRamRslOfst;
    LWORD *u32pH2fTab, *u32pUpdH2fTab;
    volatile SORTF2HTAB *upSortF2hTab=(SORTF2HTAB *)(cTsb0Addr);

    if(gsCacheInfo.u32FluModifidHBlkNum>=upSortF2hTab->u32LoadHBlkNum)
    {
        while(gsCacheInfo.u32FluModifidHBlkNum>upSortF2hTab->u32LoadHBlkNum)
            ;

        return;
    }

    /*
       * else
       * if(!rm32BufStatus((upSortF2hTab->u16H2fTableBufPtr[upSortF2hTab->uH2FRamPtr[gsCacheInfo.u32FluModifidHBlkNum]]+g16H2fTabSctrSize/2-1)/
       *                     32)||
       *
       *
       *  !rm32BufStatus((upSortF2hTab->u16H2fTableBufPtr[upSortF2hTab->uH2FRamPtr[gsCacheInfo.u32FluModifidHBlkNum]]+g16H2fTabSctrSize-1)/32))
       * {
       *  return;
       * }
       */

    while(gsCacheInfo.u32ModifyH2fPtrHead<gsCacheInfo.u32ModifyH2fPtrTail)
        ;

    u32pH2fTab=(UCLWORD *)upSortF2hTab->u32H2fTableAddr[upSortF2hTab->uH2FRamPtr[gsCacheInfo.u32FluModifidHBlkNum]];
    u16EndPtr=upSortF2hTab->u16HBlockStartOft[gsCacheInfo.u32FluModifidHBlkNum+1];

    if(u16EndPtr>gsCacheInfo.u32ModifyH2fPtrHead)
    {
        u16EndPtr=gsCacheInfo.u32ModifyH2fPtrHead;
    }

    u16ModifyTabPtr=gsCacheInfo.u32ModifyH2fPtrTail;
    u32pSortRamRslOfst=&upSortF2hTab->u32arRslOfst[u16ModifyTabPtr];
    u16pSortRamH2fPage=&upSortF2hTab->u16arH2fPage[u16ModifyTabPtr];

    u16PrevOrgFblkVpc=0;

    while(u16ModifyTabPtr!=u16EndPtr)
    {
        u32pUpdH2fTab=u32pH2fTab+*u16pSortRamH2fPage++;
        u16ModifyTabPtr++;
        u16OrgFblk=mGetSrcFBlkAddr(*u32pUpdH2fTab);
        *u32pUpdH2fTab=*u32pSortRamRslOfst++;

        if(u16OrgFblk!=c16FBlockInitValue)
        {
            u16PrevOrgFblk=u16OrgFblk;
            u16PrevOrgFblkVpc++;
            break;
        }
    }

    while(u16ModifyTabPtr!=u16EndPtr)
    {
        u32pUpdH2fTab=u32pH2fTab+*u16pSortRamH2fPage++;
        u16ModifyTabPtr++;
        u16OrgFblk=mGetSrcFBlkAddr(*u32pUpdH2fTab);
        *u32pUpdH2fTab=*u32pSortRamRslOfst++;

        if(u16OrgFblk!=c16FBlockInitValue)
        {
            if(u16OrgFblk!=u16PrevOrgFblk)
            {
                // if(u16PrevOrgFblkVpc)
                // {
#if _EN_DEBUGDECVPC
                while(mGetCacheBlkVpCnt(u16PrevOrgFblk)<u16PrevOrgFblkVpc)
                    ;
#endif
                g32arCacheBlkVpCnt[u16PrevOrgFblk]-=u16PrevOrgFblkVpc;
                mDecTotalVpcN(u16PrevOrgFblk, u16PrevOrgFblkVpc);

                if(!mGetCacheBlkVpCnt(u16PrevOrgFblk))
                {
                    setZeroVpcBlock(u16PrevOrgFblk);
                }

                // }

                u16PrevOrgFblk=u16OrgFblk;
                u16PrevOrgFblkVpc=1;
            }
            else
            {
                u16PrevOrgFblkVpc++;
            }
        }
    }

    if(u16PrevOrgFblkVpc)
    {
#if _EN_DEBUGDECVPC
        while(mGetCacheBlkVpCnt(u16PrevOrgFblk)<u16PrevOrgFblkVpc)
            ;
#endif
        g32arCacheBlkVpCnt[u16PrevOrgFblk]-=u16PrevOrgFblkVpc;
        mDecTotalVpcN(u16PrevOrgFblk, u16PrevOrgFblkVpc);

        if(!mGetCacheBlkVpCnt(u16PrevOrgFblk))
        {
            setZeroVpcBlock(u16PrevOrgFblk);
        }
    }

    if(gsCacheInfo.u32ModifyH2fPtrTail!=u16ModifyTabPtr)
    {
        // mSetCacheInfoFlag(cH2fChg);
        gsCacheInfo.u32ModifyH2fPtrTail=u16ModifyTabPtr;
    }

    // if((u16ModifyTabPtr==u16EndPtr)&&(u16ModifyTabPtr==upSortF2hTab->u16HBlockStartOft[gsCacheInfo.u32FluModifidHBlkNum+1]))
    if(u16ModifyTabPtr==upSortF2hTab->u16HBlockStartOft[gsCacheInfo.u32FluModifidHBlkNum+1])
    {
        mSetCacheInfoChangeFlag(cH2fChg);
        gsCacheInfo.u32FluModifidHBlkNum++;
    }
}    /* modifyH2FtabCore1 */







