







void trigNxtVPCmdAle(WORD u16Fblock, WORD u16Fpage, BYTE uIntlvAddr, BYTE uDieAddr, ADDRINFO *upTmpAddrInfo)
{
    BYTE uCh;

    for(uCh=0; uCh<gTotalChNum; uCh++)
    {
        upTmpAddrInfo->u16FBlock=u16Fblock;
        // upTmpAddrInfo->ubLsbOnly=0;
        // tranCeNum(upTmpAddrInfo);
        upTmpAddrInfo->u16FPage=u16Fpage;
        upTmpAddrInfo->uCh=uCh;
        upTmpAddrInfo->uIntlvAddr=uIntlvAddr;
        upTmpAddrInfo->uDieAddr=uDieAddr;
        upTmpAddrInfo->uCe=mGetCEAddr(upTmpAddrInfo->uIntlvAddr);
        setFLAddrActCh(uCh, upTmpAddrInfo);
        // mWaitCmdFifoBz;

        if(mChkMlcMoBit(g16FBlock))
        {
            setPageSelCmd(gpFlashAddrInfo, (u16Fpage%cProgCntPerWL)+1);
            g16FPage=(g16FPage/cProgCntPerWL);
        }
        else
        {
            setPageSelCmd(gpFlashAddrInfo, cSlcCmd);
        }

        // for (uPlaneAddr=0; uPlaneAddr<gPlaneNum; uPlaneAddr++)
        // {
        gPlaneAddr=0;
        gSectorH=0;
        mSetFRwParam(0, 0, (c16Bit0|c16Bit15), cReadCmdAle);
        waitChCeBz(uCh, uIntlvAddr, 0);
        flashReadPage();
        // gsRwCtrl.uWaitFlag[uCh][gActiveCe][uIntlvAddr]=cReadCmdAle;
        setBzInfo(cReadCmdAle, uCh, uIntlvAddr);
        gsRwCtrl.usWaitInfo[uCh][uIntlvAddr].uStatusErrStop=0;

        upTmpAddrInfo++;
        // }
    }
}    /* trigNxtVPCmdAle */

/*
   * uBuildOpt : Only support cGcSrcBlock
   */
void buildValidCachePage(WORD u16Fblock, WORD u16SrcBlkAddr)
{
    ADDRINFO usTmpAddrInfo[cMaxChNum];
    BLKSPRINFO usBlkSprInfo;
    WORD *u16pBlkSprPtr;
    BYTE uIntlvAddr, uDieAddr, uPlaneAddr, uCh, u4kPtr, uValidF, uSkipRebu=cFalse;
    F2HTABLE *upSrcF2hTab;
    WORD u16GcSrcEndPagePtr, u16TotalPgPerF2hTab;
    WORD u16EmptyPageCnt=0;
    WORD u16MtPageCnt=0;
    WORD u16Fpage;

    if(mGetGcFlow!=cGcFlowT2T)
    {
        u16TotalPgPerF2hTab=g16TotalPgPerF2hTab;
    }
    else
    {
        u16TotalPgPerF2hTab=g16TotalTlcPgPerF2hTab;
    }

    // gsGcInfo.u16buildF2h++;
    // gsGcInfo.uReBldSrcBlk++;
    u16Fpage=div(gsGcInfo.uGcSrcF2hTabBank*u16TotalPgPerF2hTab, gTotalIntlvChNum*g4kNumPerPage);
    u16GcSrcEndPagePtr=div((gsGcInfo.uGcSrcF2hTabBank+1)*u16TotalPgPerF2hTab, gTotalIntlvChNum*g4kNumPerPage);
    upSrcF2hTab=(F2HTABLE *)garTsb0[u16SrcBlkAddr]+(u16TotalPgPerF2hTab-1);

    for(uIntlvAddr=0; uIntlvAddr<gIntlvWay; uIntlvAddr++)
    {
        trigNxtVPCmdAle(u16Fblock, u16Fpage, uIntlvAddr, mGetDieAddr(uIntlvAddr), &usTmpAddrInfo[0]);
    }

    while(u16Fpage<u16GcSrcEndPagePtr)
    {
        if((u16MtPageCnt<=gTotalIntlvChPlaneNum)&&(uSkipRebu==cFalse))
        {
            for(uIntlvAddr=0; uIntlvAddr<gIntlvWay; uIntlvAddr++)
            {
                uDieAddr=mGetDieAddr(uIntlvAddr);

                for(uCh=0; uCh<gTotalChNum; uCh++)
                {
                    usTmpAddrInfo[uCh].u16FPage=u16Fpage;
                    usTmpAddrInfo[uCh].uIntlvAddr=uIntlvAddr;
                    usTmpAddrInfo[uCh].uCe=mGetCEAddr(usTmpAddrInfo[uCh].uIntlvAddr);
                    usTmpAddrInfo[uCh].uDieAddr=uDieAddr;
                    usTmpAddrInfo[uCh].uCh=uCh;
                    setFLAddrActCh(uCh, &usTmpAddrInfo[uCh]);

                    if(mChkMlcMoBit(g16FBlock))
                    {
                        setPageSelCmd(gpFlashAddrInfo, (g16FPage%cProgCntPerWL)+1);
                        g16FPage=(g16FPage/cProgCntPerWL);
                    }
                    else
                    {
                        setPageSelCmd(gpFlashAddrInfo, cSlcCmd);
                    }

                    mSetFRwParam(0, 0, (c16Bit0|c16Bit2|c16Bit5|c16Bit10|c16Bit15), cReadData);
                    waitChCeBz(uCh, uIntlvAddr, 0);

                    for(uPlaneAddr=0; uPlaneAddr<gPlaneNum; uPlaneAddr++)
                    {
                        {
                            usTmpAddrInfo[uCh].uPlaneAddr=uPlaneAddr;
                            flashReadPage();
                        }
                    }

                    setBzInfo(cReadData, uCh, uIntlvAddr);
                    gsRwCtrl.usWaitInfo[uCh][uIntlvAddr].uStatusErrStop=0;
                }

                for(uCh=0; uCh<gTotalChNum; uCh++)
                {
                    setFLActCh(uCh);
                    jdgReadRetry(&usTmpAddrInfo[uCh], 0);

                    if(gbOnesCntFail)
                    {
                        u16EmptyPageCnt++;

                        if(u16EmptyPageCnt>=gTotalIntlvChPlaneNum)
                        {
                            uSkipRebu=cTrue;
                        }
                    }
                }

                if((u16Fpage+1)<u16GcSrcEndPagePtr)
                {
                    trigNxtVPCmdAle(u16Fblock, u16Fpage+1, uIntlvAddr, uDieAddr, &usTmpAddrInfo[0]);
                }

                for(uCh=0; uCh<gTotalChNum; uCh++)
                {
                    setFLActCh(uCh);

                    for(uPlaneAddr=0; uPlaneAddr<gPlaneNum; uPlaneAddr++)
                    {
                        getSprByte(&usBlkSprInfo, uPlaneAddr);

                        uValidF=cFalse;

                        if(uSkipRebu==cTrue)
                        {}
                        else if(mChkBitMask(gPlaneUNCSts[uCh], uPlaneAddr))
                        {
                            u16MtPageCnt=0;
                        }
                        else if(mGetSprId==0xFF)
                        {
                            u16MtPageCnt++;
                        }
                        else if((mGetSprId==cCacheBlockID)||(mGetSprId==cGcDesBlockID))
                        {
                            u16pBlkSprPtr=&usBlkSprInfo.u16Spr0.u16all;
                            uValidF=cTrue;
                            u16MtPageCnt=0;
                        }

                        for(u4kPtr=0; u4kPtr<g4kNumPerPlane; u4kPtr++)
                        {
                            if(uValidF==cTrue)
                            {
                                if(*(u16pBlkSprPtr+1)!=0xFFFF)
                                {
                                    upSrcF2hTab->u16HBlock=*(u16pBlkSprPtr+1);
                                    upSrcF2hTab->u16HPage=*u16pBlkSprPtr;

                                    while(upSrcF2hTab->u16HBlock>=g16TotalHBlock)
                                        ;// debug Spare byte not correct

                                    while(upSrcF2hTab->u16HPage>=g16PagePerH2fTab)
                                        ;// debug Spare byte not correct
                                }
                                else
                                {
                                    upSrcF2hTab->u16HBlock=0xFFFF;
                                    upSrcF2hTab->u16HPage=0xFFFF;
                                }

                                u16pBlkSprPtr+=2;
                            }
                            else
                            {
                                upSrcF2hTab->u16HBlock=0xFFFF;
                                upSrcF2hTab->u16HPage=0xFFFF;
                            }

                            upSrcF2hTab--;
                        }
                    }
                }
            }
        }
        else
        {
            for(uIntlvAddr=0; uIntlvAddr<gIntlvWay; uIntlvAddr++)
            {
                for(uCh=0; uCh<gTotalChNum; uCh++)
                {
                    for(uPlaneAddr=0; uPlaneAddr<gPlaneNum; uPlaneAddr++)
                    {
                        for(u4kPtr=0; u4kPtr<g4kNumPerPlane; u4kPtr++)
                        {
                            upSrcF2hTab->u16HBlock=0xFFFF;
                            upSrcF2hTab->u16HPage=0xFFFF;
                            upSrcF2hTab--;
                        }
                    }
                }
            }
        }

        u16Fpage++;
    }
}    /* buildValidCachePage */







