







void saveRaidCmd(WORD u16TsbIdx, WORD u16XfrSctrCnt, WORD u16RaidOpts, WORD u16PgIdx, BYTE uSctrIdx)
{
    HDMAQUEUE *upHdmaQuePtr;

    upHdmaQuePtr=&gsHdmaCtrl.uarHdmaQue[gsHdmaCtrl.uHdmaQueHead];
    upHdmaQuePtr->u16TsbIdx=u16TsbIdx;
    upHdmaQuePtr->u16XfrSctrCnt=u16XfrSctrCnt;

    // Raid Action
    upHdmaQuePtr->u16RaidOpts=u16RaidOpts;
    upHdmaQuePtr->u16RaidStEncPgIdx=u16PgIdx;
    upHdmaQuePtr->uRaidStEncSctrIdx=uSctrIdx;

    gsHdmaCtrl.uHdmaQueHead=(gsHdmaCtrl.uHdmaQueHead+1)&(cHdmaQueDptFW-1);
}

void trigRaidEngInit(BYTE uEngIdx, BYTE uWait)
{
    rmChkHdmaFree;

    rmRstHdmaParam;
    rmRstHdmaInt;
    rmClrHdmaRaidCmd;
    rmHdmaDisAutoAes;

    // rmSetHdmaDesAddr(0);
    // rmSetHdmaSrcAddr(0);
    // rmSetHdmaXfrLen(0);
    // rmSetHdmaDataDir(cHdmaTsb2Tsb);

    // rmSetRaidResmPgIdx(0);
    // rmSetRaidResmSctrIdx(0);
    rmSetRaidEngineSel(uEngIdx);

    rmRaidCmdClr;

    rmTrigHdmaRaidCmd(0);

#if 1
    saveRaidCmd(0,
                0,
                ((WORD)uEngIdx<<8)|cRaidActEngInitialize,
                0,
                0);
#endif/* if 1 */

    if(uWait&cHdmaWait)
    {
        rmChkHdmaDone;
    }
}    /* trigRaidEngInit */

////////////////////////////////////////////////
// Updated by Kane, 20161226
//
// 1. uEngIdx: 0 ~ 11
//
// 2. uRaidType: (cRaidTotalType=3) cRaidDataBlk, cRaidGcBlk, cRaidHTabBlk
//
////////////////////////////////////////////////
void trigRaidSetKVal(BYTE uEngIdx, BYTE uRaidType, BYTE uWait)
{
    WORD u16KVal=gsRaidInfo.uarRaidTotalType[uRaidType].u16KVal;
    BYTE uSctrNum=gsRaidInfo.uarRaidTotalType[uRaidType].uSctrNum;

    rmChkHdmaFree;

    rmRstHdmaParam;
    rmRstHdmaInt;
    rmClrHdmaRaidCmd;
    rmHdmaDisAutoAes;

    rmSetHdmaDesAddr((LWORD)u16KVal);
    // rmSetHdmaSrcAddr(0);
    // rmSetHdmaXfrLen(0);
    // rmSetHdmaDataDir(cHdmaTsb2Tsb);

    // rmSetRaidResmPgIdx(0);
    // rmSetRaidResmSctrIdx(0);
    rmSetRaidEngineSel(uEngIdx);

    rmSetRaidSctrNum(uSctrNum-1);
    rmEnRaidKValue;

    rmTrigHdmaRaidCmd(0);

#if 1
    saveRaidCmd(0,
                0,
                (uRaidType<<12)|(uEngIdx<<8)|cRaidActFGEngSetKVal,
                0,
                0);
#endif/* if 0 */

    if(uWait&cHdmaWait)
    {
        rmChkHdmaDone;
    }
}    /* trigRaidSetKVal */

////////////////////////////////////////////////
// Updated by Kane, 20161224
//
// 1. "cHdmaTsb2Bvci" & "RaidEncOnly", so uXfrDir and u16DesTsbIdx are removed.
//
// 2. u16SrcTsbIdx - units: sect addr, not byte addr
//
// 3. u16XfrSctrCnt - should be followed the HW rule, unit: 2 chunk (min u16XfrSctrCnt = 4)
//
// 4. uSrcFlag: 0x0 - Non,
//                   0x4 - Ref Buf Flag, (INVALID in this case!!!!)
//                   0x8 - Ref Raid Flag w/o flipping Buf flag,
//                   0xC - Ref Raid Flag w flipping Buf flag
//
// 5. uEngIdx: 0 ~ 11
//
// 6. uRaidType: (cRaidTotalType=3) cRaidDataBlk, cRaidGcBlk, cRaidHTabBlk
//
// 7. u16StPgIdx: 0 ~ K-1
//
// 8. uStSctrIdx: 0 ~ 7, unit: 2chunks or 2KB
//
////////////////////////////////////////////////
void trigRaidDataEnc(WORD u16SrcTsbIdx,
                     WORD u16XfrSctrCnt,
                     BYTE uSrcFlag,
                     BYTE uEngIdx,
                     BYTE uRaidType,
                     WORD u16StPgIdx,
                     BYTE uStSctrIdx,
                     BYTE uRaidActOpts,
                     BYTE uWait)
{
    WORD u16KVal=gsRaidInfo.uarRaidTotalType[uRaidType].u16KVal;
    BYTE uSctrNum=gsRaidInfo.uarRaidTotalType[uRaidType].uSctrNum;

    rmChkHdmaFree;

    rmRstHdmaParam;
    rmRstHdmaInt;
    rmClrHdmaRaidCmd;
    rmHdmaDisAutoAes;

    rmSetHdmaDesAddr(0);
    rmSetHdmaSrcAddr((LWORD)u16SrcTsbIdx<<9);
    rmSetHdmaXfrLen((LWORD)u16XfrSctrCnt<<9);

    // (Kane_20161222) Pattern Mode
    // if(u16SrcTsbIdx!=c16Null)
    {
        rmSetHdmaDataDir(cHdmaTsb2Bvci);
    }
    // else
    // {
    //    rmSetHdmaDataDir(cHdmaBvci2Tsb);
    //    rmSetHdmaFillMo;
    //    rmSetHdmaPat(0);
    // }

    rmSetRaidResmPgIdx(u16StPgIdx);
    rmSetRaidResmSctrIdx(uStSctrIdx);
    rmSetRaidEngineSel(uEngIdx);

    rmSetRaidSctrNum(uSctrNum-1);
    rmSetRaidKValue(u16KVal);    // Set K val into Reg directly
    rmSetRaidCmd(cRaidCmdData);
    rmRaidEncOnly;

    // (Kane_20161222) Set Src Flag (Buf Flag or Raid Flag)
    if(uSrcFlag&cHdmaSrcFlagMsk)
    {
        rmDisHdmaRdBypass;

        if(uSrcFlag&c16Bit7)    // Raid Flag Only
        {
            rmEnHdmaRaidFlagSrc;

            if(uSrcFlag&c16Bit6)    // Buffer Raid Flags
            {
                rmEnHdmaBufRaidFlag;
            }
        }
    }
    else
    {
        rmEnHdmaRdBypass;
    }

    rmTrigHdmaRaidCmd(0);

#if 1
    saveRaidCmd(u16SrcTsbIdx,
                u16XfrSctrCnt,
                (uRaidType<<12)|(uEngIdx<<8)|cRaidActDataEnc,
                u16StPgIdx,
                uStSctrIdx);
#endif/* if 0 */

    if(uWait&cHdmaWait)
    {
        rmChkHdmaDone;
    }
}    /* trigRaidDataEnc */

////////////////////////////////////////////////
// Updated by Kane, 20161226
//
// 1. uDesFlag: 0x0 - Non,
//                    0x1 - Set Buf Flag,
//                    0x2 - Set Raid Flag
//
// 2. uRaidType: (cRaidTotalType=3) cRaidDataBlk, cRaidGcBlk, cRaidHTabBlk
//
// 3. uRaidActOpts:
//     a. cRaidActOptPtyClr
//
////////////////////////////////////////////////
void trigRaidPtyOut(WORD u16DesTsbIdx, BYTE uDesFlag, BYTE uEngIdx, BYTE uRaidType, BYTE uRaidActOpts, BYTE uWait)
{
    WORD u16KVal=gsRaidInfo.uarRaidTotalType[uRaidType].u16KVal;
    BYTE uSctrNum=gsRaidInfo.uarRaidTotalType[uRaidType].uSctrNum;

    rmChkHdmaFree;

    rmRstHdmaParam;
    rmRstHdmaInt;
    rmClrHdmaRaidCmd;
    rmHdmaDisAutoAes;

    rmSetHdmaDesAddr((LWORD)u16DesTsbIdx<<9);
    rmSetHdmaSrcAddr(0);
    rmSetHdmaXfrLen((LWORD)uSctrNum<<(cRaidUnitChgShiftBit+9));
    rmSetHdmaDataDir(cHdmaBvci2Tsb);    // cHdmaTsb2Tsb);

    rmSetRaidResmPgIdx(u16KVal);
    rmSetRaidResmSctrIdx(0);
    rmSetRaidEngineSel(uEngIdx);

    rmSetRaidKValue(u16KVal);
    rmSetRaidCmd(cRaidCmdPty);

    if(uRaidActOpts&cRaidActOptPtyClr)
    {
        rmRaidPtyClr;
    }

    // (Kane_20161222) Set Des Flag (Buf Flag or Raid Flag)
    if(uDesFlag&cHdmaDesFlagMsk)
    {
        rmDisHdmaWrBypass;

        if(uDesFlag&cHdmaDesRaidFlag)
        {
            rmEnHdmaRaidFlagDes;
        }
    }
    else
    {
        rmEnHdmaWrBypass;
    }

    rmTrigHdmaRaidCmd(0);

#if 1
    saveRaidCmd(u16DesTsbIdx,
                (uSctrNum<<cRaidUnitChgShiftBit),
                (uRaidType<<12)|(uEngIdx<<8)|cRaidActPtyOut,
                u16KVal,
                0);
#endif/* if 0 */

    if(uWait&cHdmaWait)
    {
        rmChkHdmaDone;
    }
}    /* trigRaidPtyOut */

////////////////////////////////////////////////
// Updated by Kane, 20161229
//
// 1. u16DesTsbIdx: The TSB address that keeps the temp Raid parity
//
// 2. uDesFlag: 0x0 - Non,
//                    0x1 - Set Buf Flag,
//                    0x2 - Set Raid Flag
//
// 3. uRaidType: (cRaidTotalType=3) cRaidDataBlk, cRaidGcBlk, cRaidHTabBlk
//
////////////////////////////////////////////////
void trigRaidHdmaTerm(WORD u16DesTsbIdx, BYTE uDesFlag, BYTE uEngIdx, BYTE uRaidType, BYTE uRaidActOpts, BYTE uWait)
{
    BYTE uSctrNum=gsRaidInfo.uarRaidTotalType[uRaidType].uSctrNum;

    rmChkHdmaFree;

    rmRstHdmaParam;
    rmRstHdmaInt;
    rmClrHdmaRaidCmd;
    rmHdmaDisAutoAes;

    rmSetHdmaDesAddr((LWORD)u16DesTsbIdx<<9);
    rmSetHdmaSrcAddr(0);
    rmSetHdmaXfrLen((LWORD)uSctrNum<<(cRaidUnitChgShiftBit+9));
    rmSetHdmaDataDir(cHdmaTsb2Tsb);    // cHdmaBvci2Tsb ??

    rmSetRaidResmPgIdx(0);
    rmSetRaidResmSctrIdx(0);
    rmSetRaidEngineSel(uEngIdx);

    rmSetRaidCmd(cRaidCmdTerm);

    // (Kane_20161222) Set Des Flag (Buf Flag or Raid Flag)
    if(uDesFlag&cHdmaDesFlagMsk)
    {
        rmDisHdmaWrBypass;

        if(uDesFlag&cHdmaDesRaidFlag)
        {
            rmEnHdmaRaidFlagDes;
        }
    }
    else
    {
        rmEnHdmaWrBypass;
    }

    rmTrigHdmaRaidCmd(0);

#if 1
    saveRaidCmd(u16DesTsbIdx,
                (uSctrNum<<cRaidUnitChgShiftBit),
                (uRaidType<<12)|(uEngIdx<<8)|cRaidActHdmaTerm,
                gsRaidInfo.u16arRaidEngPgIdx[uEngIdx],
                gsRaidInfo.uarRaidEngSctrIdx[uEngIdx]);
#endif/* if 0 */

    if(uWait&cHdmaWait)
    {
        rmChkHdmaDone;
    }

    gsRaidInfo.uarRaidTermQue[uEngIdx].u16RaidTermInfo=(uRaidType<<12)|c16Bit0;
    gsRaidInfo.uarRaidTermQue[uEngIdx].u16DesTsbIdx=u16DesTsbIdx;
    gsRaidInfo.uarRaidTermQue[uEngIdx].u16TermPgIdx=gsRaidInfo.u16arRaidEngPgIdx[uEngIdx];    // rmChkRaidTermPgIdx;
    gsRaidInfo.uarRaidTermQue[uEngIdx].uTermSctrIdx=gsRaidInfo.uarRaidEngSctrIdx[uEngIdx];    // rmChkRaidTermSctrIdx;
}    /* trigRaidHdmaTerm */

void trigRaidHdmaResm(BYTE uEngIdx, BYTE uSrcFlag)
{
    WORD u16KVal;
    BYTE uSctrNum, uRaidType;    // , uBGEn;

    // (Kane_20161229) Chk the uRaidTermFlag of the "uEngIdx". This bit is set if the uEngIdx is terminated.
    if(gsRaidInfo.uarRaidTermQue[uEngIdx].u16RaidTermInfo&c16Bit0)
    {
        uRaidType=((gsRaidInfo.uarRaidTermQue[uEngIdx].u16RaidTermInfo&cRaidTypeMsk)>>12);
        u16KVal=gsRaidInfo.uarRaidTotalType[uRaidType].u16KVal;
        uSctrNum=gsRaidInfo.uarRaidTotalType[uRaidType].uSctrNum;

        rmChkHdmaFree;

        rmRstHdmaParam;
        rmRstHdmaInt;
        rmClrHdmaRaidCmd;
        rmHdmaDisAutoAes;

        rmSetHdmaDesAddr(0);
        rmSetHdmaSrcAddr((LWORD)(gsRaidInfo.uarRaidTermQue[uEngIdx].u16DesTsbIdx)<<9);
        rmSetHdmaXfrLen((LWORD)uSctrNum<<(cRaidUnitChgShiftBit+9));
        rmSetHdmaDataDir(cHdmaTsb2Tsb);    // cHdmaBvci2Tsb ??

        rmSetRaidResmPgIdx(gsRaidInfo.uarRaidTermQue[uEngIdx].u16TermPgIdx);
        rmSetRaidResmSctrIdx(gsRaidInfo.uarRaidTermQue[uEngIdx].uTermSctrIdx);
        rmSetRaidEngineSel(uEngIdx);

        rmSetRaidSctrNum(uSctrNum-1);
        rmSetRaidKValue(u16KVal);
        rmSetRaidCmd(cRaidCmdResm);

        // (Kane_20161222) Set Src Flag (Buf Flag or Raid Flag)
        if(uSrcFlag&cHdmaSrcFlagMsk)
        {
            rmDisHdmaRdBypass;

            if(uSrcFlag&c16Bit7)    // Raid Flag Only
            {
                rmEnHdmaRaidFlagSrc;

                if(uSrcFlag&c16Bit6)    // Buffer Raid Flags
                {
                    rmEnHdmaBufRaidFlag;
                }
            }
        }
        else
        {
            rmEnHdmaRdBypass;
        }

        rmTrigHdmaRaidCmd(0);

#if 1
        saveRaidCmd(gsRaidInfo.uarRaidTermQue[uEngIdx].u16DesTsbIdx,
                    (gsRaidInfo.uarRaidTotalType[uRaidType].uSctrNum<<cRaidUnitChgShiftBit),
                    (uRaidType<<12)|(uEngIdx<<8)|cRaidActHdmaResm,
                    gsRaidInfo.uarRaidTermQue[uEngIdx].u16TermPgIdx,
                    gsRaidInfo.uarRaidTermQue[uEngIdx].uTermSctrIdx);
#endif/* if 1 */

        rmChkHdmaDone;

        gsRaidInfo.uarRaidTermQue[uEngIdx].u16RaidTermInfo=0;
        gsRaidInfo.uarRaidTermQue[uEngIdx].u16DesTsbIdx=0;
        gsRaidInfo.uarRaidTermQue[uEngIdx].u16TermPgIdx=0;
        gsRaidInfo.uarRaidTermQue[uEngIdx].uTermSctrIdx=0;
    }
}    /* trigRaidHdmaResm */

void setRaidEngBitMap(BYTE uEngIdx)
{
    if(!mChkRaidEngBmap(uEngIdx))
    {
        mSetRaidEngBmap(uEngIdx);
    }
}

void clrRaidEngBitMap(BYTE uEngIdx)
{
    if(mChkRaidEngBmap(uEngIdx))
    {
        mClrRaidEngBmap(uEngIdx);
    }
}

void setRaidEngPtyBitMap(BYTE uEngIdx)
{
    if(!mChkRaidEngPtyBmap(uEngIdx))
    {
        mSetRaidEngPtyBmap(uEngIdx);
    }
}

void clrRaidEngPtyBitMap(BYTE uEngIdx)
{
    if(mChkRaidEngPtyBmap(uEngIdx))
    {
        mClrRaidEngPtyBmap(uEngIdx);
    }
}

#if 0
BYTE chkRaidFlag(WORD u16SctrIdx, WORD u16SctrCnt, BYTE uWait1)
{
    LWORD u32Pattern;
    WORD u16TsbCtrlIdx, u16TotalSctrCnt;
    BYTE uStarSctr;
    BYTE uPatSctrCnt;
    BYTE uResult=1;

    u16TotalSctrCnt=u16SctrCnt;
    u16TsbCtrlIdx=u16SctrIdx>>5;    // (Kane_20170222) Chk Raid flag every 16K bytes
    uStarSctr=u16SctrIdx&0x1F;    // Use to shit the pattern to the start sector
    uPatSctrCnt=32-uStarSctr;    // Predict the sector cnt needed to be chk-ed (Start from the "start sctr" in a 16K byte)

    while(u16TotalSctrCnt)
    {
        if(u16TotalSctrCnt<uPatSctrCnt)
        {
            uPatSctrCnt=u16TotalSctrCnt;    // If the sector cnt needed to be chk-ed (input sector cnt: u16SctrCnt) is smaller than the
                                            // predicted value (uPatSctrCnt), the predicted value is updated.
        }

        u32Pattern=cb32BitNumTab[uPatSctrCnt];    // Load the pattern based on the bit number required to be chk-ed
        u32Pattern=u32Pattern<<uStarSctr;    // Shift the pattern to the start sector

        if(uWait1)
        {
            while((rm32BufRaidStatus(u16TsbCtrlIdx)&u32Pattern)!=u32Pattern)
                ;// Check the Raid flags of these bits in the defined pattern
        }
        else
        {
            if((rm32BufRaidStatus(u16TsbCtrlIdx)&u32Pattern)!=u32Pattern)
            {
                uResult=0;
                break;
            }
        }

        u16TotalSctrCnt-=uPatSctrCnt;
        u16TsbCtrlIdx++;

        if(u16TsbCtrlIdx==(cTsb0Size>>5))
        {
            u16TsbCtrlIdx=0;
        }

        uStarSctr=0;
        uPatSctrCnt=32;
    }

    return uResult;
}    /* chkRaidFlag */

#endif/* if 0 */

BYTE chkTailFifoOffset()
{
    BYTE uPtrOffset;

    if(gsRwCtrl.u32ProgFifoTrig>=gsRwCtrl.u32ProgFifoTail)
    {
        uPtrOffset=gsRwCtrl.u32ProgFifoTrig-gsRwCtrl.u32ProgFifoTail;
    }
    else
    {
        uPtrOffset=gsRwCtrl.u32ProgFifoTrig+cWriteFifoDpt-gsRwCtrl.u32ProgFifoTail;
    }

    if(mChkGcFlag(cUnderBgdGc|cUnderFgdGc)&&(!mChkGcFlag(cUnderGcH2fTab)))
    {
        // return uPtrOffset<((gsGcInfo.u32Prog4kCntPerChPg*gsGcInfo.uGCDesPagePerWL<<cSctrTo4kShift)/(g4kNumPerPage<<cSctrTo4kShift)));
        return uPtrOffset<(gTotalChNum*gsGcInfo.uGCDesPagePerWL);
    }
    else
    {
        return uPtrOffset<((c16WriteBufSize/(g4kNumPerPage<<cSctrTo4kShift))-1);
    }
}    /* chkTailFifoOffset */

////////////////////////////////////////////////
// Updated by Kane, 20161223
//
// 1. uRaidType: (cRaidTotalType=3) cRaidDataBlk, cRaidGcBlk, cRaidHTabBlk
//
// 2. u16KVal: 16bits
//
// 3. uSctrNum: 5bits (For SM2263, one sector is 2 chunks or 1KB. Thus, the total sect num in one page is 16KB, and the max sect num is 8)
//
// 4. uPtyNum = 1 for SM2263
//
////////////////////////////////////////////////
void defineRaidType(BYTE uRaidType, WORD u16KVal, BYTE uSctrNum)
{
    gsRaidInfo.uarRaidTotalType[uRaidType].u16KVal=u16KVal;
    gsRaidInfo.uarRaidTotalType[uRaidType].uSctrNum=(0x1F&(uSctrNum>>cRaidUnitChgShiftBit));
}

void initRaidEngine()
{
    BYTE uIdx, uIdx2;
    WORD u16RaidSKVal, u16RaidTKVal;

    for(uIdx=0; uIdx<cRaidTotalEng; uIdx++)
    {
        rmSetRaidCurEngineSel(uIdx);
        rmRaidCodecClr;

        clrRaidEngBitMap(uIdx);
        clrRaidEngPtyBitMap(uIdx);
        gsRaidInfo.u16arRaidEngPgIdx[uIdx]=0;
        gsRaidInfo.uarRaidEngSctrIdx[uIdx]=0;
    }

    for(uIdx=0; uIdx<cRaidParityNum; uIdx++)
    {
        for(uIdx2=0; uIdx2<(cRaidTotalType-1); uIdx2++)
        {
            gsRaidInfo.u16arRaidFPage[uIdx2][uIdx]=c16Null;
            gsRaidInfo.uarRaidEngIdx[uIdx2][uIdx]=cNull;
        }
    }

    gsRaidInfo.uRaidPopEngCnt=0;
    gsRaidInfo.u16RaidLdpcPgIdx=0;
    gsRaidInfo.uRaidDecQueCnt=0;
    gsRaidInfo.uRaidDecFifoHead=0;
    gsRaidInfo.uRaidDecFifoTail=0;
    gsRaidInfo.uRaidDecodeF=0;

    u16RaidSKVal=(g16SlcPartialParityNum>>cRaidStringShiftBit)+1;
    u16RaidTKVal=(g16TlcPartialParityNum>>cRaidStringShiftBit)+1;

    defineRaidType(cRaidDataBlk, cRaidDataKVal*u16RaidSKVal-1, cRaidDataSctrNum);
    defineRaidType(cRaidGcBlk, cRaidDataKVal, cRaidDataSctrNum);
    defineRaidType(cRaidHTabBlk, cRaidHTabKVal, cRaidHTabSctrNum);
    defineRaidType(cRaidPtySBlk, u16RaidSKVal, cRaidDataSctrNum);
    defineRaidType(cRaidPtyTBlk, u16RaidTKVal, cRaidDataSctrNum);
    defineRaidType(cRaidEngTemp, 1, cRaidDataSctrNum);

    rmSetParityNum(1);
    rmEnOccpRaidSel;    // let hdma and host check raid flag instead of buffer flag.
}    /* initRaidEngine */

void initRaidEngineResumePS3()
{
    BYTE uIdx;

    for(uIdx=0; uIdx<cRaidTotalEng; uIdx++)
    {
        rmSetRaidCurEngineSel(uIdx);
        rmRaidCodecClr;
    }

    rmSetParityNum(1);
    rmEnOccpRaidSel;    // Occupy flag to block hdma and host raid flags instead of buffer flags.
}

void rstRaidEngVar(BYTE uRaidType)
{
    BYTE uIdx, uRaidEngIdx, uRaidBlkIdx, uProgCntPerWL;
    WORD u16PtyIdx, u16RaidPty;

    for(uIdx=0; uIdx<cRaidParityNum; uIdx++)
    {
        if(gsRaidInfo.uarRaidEngIdx[uRaidType][uIdx]!=cNull)
        {
            uRaidEngIdx=gsRaidInfo.uarRaidEngIdx[uRaidType][uIdx];

            if(mChkRaidEngBmap(uRaidEngIdx))
            {
                rmSetRaidCurEngineSel(uRaidEngIdx);
                rmRaidCodecClr;
                clrRaidEngBitMap(uRaidEngIdx);
                clrRaidEngPtyBitMap(uRaidEngIdx);
                gsRaidInfo.u16arRaidEngPgIdx[uRaidEngIdx]=0;
                gsRaidInfo.uarRaidEngSctrIdx[uRaidEngIdx]=0;
                gsRaidInfo.u16arRaidFPage[uRaidType][uIdx]=c16Null;
                gsRaidInfo.uarRaidEngIdx[uRaidType][uIdx]=cNull;
                gsRaidInfo.uRaidPopEngCnt--;
            }
        }
    }

    if(uRaidType==cRaidDataBlk)
    {
        gsCacheInfo.u16RaidPtyFreePagePtr=c16BitFF;
    }
    else
    {
        if(gsGcInfo.u16GcDesBlock!=c16FBlockInitValue)
        {
            gsCacheInfo.u16RaidGcPtyFreePagePtr=c16BitFF;

            uProgCntPerWL=mChkMlcMoBit(gsGcInfo.u16GcDesBlock)?cProgCntPerWL:1;

            for(u16PtyIdx=0; u16PtyIdx<(cRaidParityPageNum/uProgCntPerWL); u16PtyIdx++)
            {
                for(uIdx=0; uIdx<uProgCntPerWL; uIdx++)
                {
                    u16RaidPty=u16PtyIdx*uProgCntPerWL+uIdx;

                    if(g16arRaidParityPtr[u16RaidPty]!=c16RaidPtrInitValue)
                    {
                        uRaidBlkIdx=mGetRaidPtyBlkIndex(u16RaidPty);

                        while(!g16arRaidPtyBlkVpCnt[uRaidBlkIdx])
                            ;

                        g16arRaidPtyBlkVpCnt[uRaidBlkIdx]--;

                        if((!g16arRaidPtyBlkVpCnt[uRaidBlkIdx])&&(uRaidBlkIdx!=gsCacheInfo.uRaidGcPtyBlkIdx))
                        {
                            pushRaidPtyBlk(uRaidBlkIdx);
                        }

                        g16arRaidParityPtr[u16RaidPty]=c16RaidPtrInitValue;
                    }
                }
            }
        }
    }
}    /* rstRaidEngVar */

BYTE getFreeRaidEngIdx(BYTE uRaidType)
{
    BYTE uEngIdx;

    for(uEngIdx=0; uEngIdx<cRaidTotalEng; uEngIdx++)
    {
        if(!mChkRaidEngBmap(uEngIdx))
        {
            setRaidEngBitMap(uEngIdx);
            trigRaidEngInit(uEngIdx, cHdmaNotWait);
            trigRaidSetKVal(uEngIdx, uRaidType, cHdmaNotWait);
            break;
        }
    }

    while(uEngIdx==cRaidTotalEng)
        ;// No Free Raid Eng !!

    return uEngIdx;
}    /* getFreeRaidEngIdx */

/*
   * void setRaidEncode(WORD u16SbufPtr, WORD u16TotalSctrCnt, WORD u16FPage, WORD u16Opt, BYTE uRaidOpt, BYTE uPageType)
   * {
   *  // BYTE uPageOfst;
   *
   *  // for(uPageOfst=0; uPageOfst<uPageType; uPageOfst++)
   *  // {
   *  hdmaEncRam(u16SbufPtr, u16TotalSctrCnt, u16FPage, u16Opt, uRaidOpt, uPageType);
   *  //    u16SbufPtr=addWriteBufPtr(u16SbufPtr, gSectorPerPageH);
   *  // }
   * }
   *
   * void getRaidParity(WORD u16SbufPtr, WORD u16Opt, BYTE uRaidOpt, WORD u16FPage, BYTE uPageType)
   * {
   *  // BYTE uPageOfst;
   *
   *  // for(uPageOfst=0; uPageOfst<uPageType; uPageOfst++)
   *  // {
   *  hdmaGetRaidPty(u16SbufPtr, u16Opt, cRaidPtyClr|uRaidOpt, u16FPage, uPageType);
   *  //    u16SbufPtr=addWriteBufPtr(u16SbufPtr, gSectorPerPageH);
   *  // }
   * }
   */
void initRaidPtyFblock(BYTE uRaidPtyBlkIdx, WORD u16RaidPtyFreePagePtr, BYTE uRaidType)
{
    BYTE uIdx;

    if(u16RaidPtyFreePagePtr>=gsCacheInfo.u16RaidPtyPagePerBlk3)
    {
        if(!g16arRaidPtyBlkVpCnt[uRaidPtyBlkIdx])
        {
            pushRaidPtyBlk(uRaidPtyBlkIdx);
        }

        for(uIdx=0; uIdx<cRaidParityBlockNum; uIdx++)
        {
            if(g16arRaidParityBlk[uIdx]==c16BitFF)
            {
                uRaidPtyBlkIdx=uIdx;
                break;
            }
        }

        while(uIdx==cRaidParityBlockNum)
            ;

        g16arRaidParityBlk[uRaidPtyBlkIdx]=popSpareBlock(cPopMinErsCnt|cPopSlcBlock);
        gsCacheInfo.uRaidPtyBlockCnt++;
        g16arRaidPtyBlkVpCnt[uRaidPtyBlkIdx]=0;

        if(uRaidType==cRaidDataPty)
        {
            gsCacheInfo.u16RaidPtyFreePagePtr=0;
            gsCacheInfo.uRaidPtyBlkIdx=uRaidPtyBlkIdx;
        }
        else if(uRaidType==cRaidGcPty)
        {
            gsCacheInfo.u16RaidGcPtyFreePagePtr=0;
            gsCacheInfo.uRaidGcPtyBlkIdx=uRaidPtyBlkIdx;
        }

        while(gsCacheInfo.uRaidPtyBlockCnt>cRaidParityBlockNum)
            ;
    }
}    /* initRaidPtyFblock */

void pushRaidPtyBlk(BYTE uRaidBlkIdx)
{
    if(g16arRaidParityBlk[uRaidBlkIdx]!=0xFFFF)
    {
        pushSpareBlock(g16arRaidParityBlk[uRaidBlkIdx], cPushNotErase);
        gsCacheInfo.uRaidPtyBlockCnt--;
        g16arRaidParityBlk[uRaidBlkIdx]=0xFFFF;
    }
}

void setRaidPtyPagePtr(WORD u16RaidPty, BYTE uRaidPtyBlkIdx, WORD u16RaidPtyPagePtr)
{
    BYTE uOrgRaidPtyBlkIdx;

    if(uRaidPtyBlkIdx!=0xFF)
    {
        g16arRaidPtyBlkVpCnt[uRaidPtyBlkIdx]++;
    }

    if(g16arRaidParityPtr[u16RaidPty]!=c16RaidPtrInitValue)
    {
        uOrgRaidPtyBlkIdx=mGetRaidPtyBlkIndex(u16RaidPty);

        while(!g16arRaidPtyBlkVpCnt[uOrgRaidPtyBlkIdx])
            ;

        g16arRaidPtyBlkVpCnt[uOrgRaidPtyBlkIdx]--;

        if((!g16arRaidPtyBlkVpCnt[uOrgRaidPtyBlkIdx])&&(uOrgRaidPtyBlkIdx!=uRaidPtyBlkIdx))
        {
            pushRaidPtyBlk(uOrgRaidPtyBlkIdx);
        }
    }

    if(uRaidPtyBlkIdx!=0xFF)
    {
        mSetRaidPtyEntry(u16RaidPty, uRaidPtyBlkIdx, u16RaidPtyPagePtr);
    }
    else
    {
        g16arRaidParityPtr[u16RaidPty]=c16RaidPtrInitValue;
    }
}    /* setRaidPtyPagePtr */

void progPartialRaidParity(WORD u16SbufPtr, WORD u16ParityPtr, BYTE uRaidType, BYTE uPageSel)
{
    ADDRINFO usTmpAddrInfo;
    BYTE uProgCntPerWL, uDesTyp, uRaidPtyBlkIdx, uBzBitMap=0;
    WORD u16RwOpt, u16RaidPtyPtr;

    if(uRaidType==cRaidDataPty)
    {
        uProgCntPerWL=mChkMlcMoBit(gsCacheInfo.u16ActiveCacheBlock)?cProgCntPerWL:1;
        u16RaidPtyPtr=u16ParityPtr*uProgCntPerWL+uPageSel;
        uDesTyp=cWriteRaid;
        initRaidPtyFblock(gsCacheInfo.uRaidPtyBlkIdx, gsCacheInfo.u16RaidPtyFreePagePtr, uRaidType);
        setRaidPtyPagePtr(u16RaidPtyPtr, gsCacheInfo.uRaidPtyBlkIdx, gsCacheInfo.u16RaidPtyFreePagePtr);
        uRaidPtyBlkIdx=gsCacheInfo.uRaidPtyBlkIdx;
    }
    else if(uRaidType==cRaidGcPty)
    {
        uProgCntPerWL=mChkMlcMoBit(gsGcInfo.u16GcDesBlock)?cProgCntPerWL:1;
        u16RaidPtyPtr=u16ParityPtr*uProgCntPerWL+uPageSel;
        uDesTyp=cWriteRaidGc;
        initRaidPtyFblock(gsCacheInfo.uRaidGcPtyBlkIdx, gsCacheInfo.u16RaidGcPtyFreePagePtr, uRaidType);
        setRaidPtyPagePtr(u16RaidPtyPtr, gsCacheInfo.uRaidGcPtyBlkIdx, gsCacheInfo.u16RaidGcPtyFreePagePtr);
        uRaidPtyBlkIdx=gsCacheInfo.uRaidGcPtyBlkIdx;
    }

    setWriteDes(0, &usTmpAddrInfo, uDesTyp);
    setFLAddrActCh(usTmpAddrInfo.uCh, &usTmpAddrInfo);
    gSectorH=0;

    gpFlashAddrInfo->uPlaneCnt=1;    // gPlaneNum;

    if(!mChkBitMask(uBzBitMap, garChMapTable[gActiveCh]))
    {
        mSetBitMask(uBzBitMap, garChMapTable[gActiveCh]);
    }

    if(mChkFLOption(cEnCacheProg)&&(g16FPage!=(g16PagePerBlock1_SLC-1)))
    {
        u16RwOpt=c16Bit0|c16Bit1|c16Bit2|c16Bit3;
    }
    else
    {
        u16RwOpt=c16Bit0|c16Bit1|c16Bit2;
    }

    mSetFRwParam(u16SbufPtr,
                 gpFlashAddrInfo->uPlaneCnt*gSectorPerPlaneH,
                 u16RwOpt,
                 cProgData);
    mSetTabSpr(gpFlashAddrInfo, cBit5);    // gpFlashAddrInfo->uTabSpar=1;
    mClrSprUseCnt(gpFlashAddrInfo);    // gpFlashAddrInfo->uSparUseCnt=0;

    // for(uPlaneAddr=0; uPlaneAddr<gPlaneNum; uPlaneAddr++)
    {
        setSprByteOfTabBlk(cRaidParityID,
                           u16RaidPtyPtr,
                           uRaidType,
                           uRaidPtyBlkIdx,
                           0,
                           gPlaneAddr,
                           0);
    }

    waitChCeBz(gActiveCh, gIntlvAddr, gsRwCtrl.uRdyTyp[gActiveCh][gIntlvAddr]);
    flashProgPage(mGetWriteBuf, mGetProgSctrCnt, mGetWriteOpt);

    if((u16RwOpt&c16Bit3)&&mChkFLOption(cEnCacheProg))
    {
        gsRwCtrl.uRdyTyp[gActiveCh][gIntlvAddr]=cRdyTypSlcCacheW;
        setBzInfo(cCacheProgData, gActiveCh, gIntlvAddr);
    }
    else
    {
        setBzInfo(gOpTyp, gActiveCh, gIntlvAddr);
    }

    gsRwCtrl.usWaitInfo[gActiveCh][gIntlvAddr].uStatusErrStop=1;

    if(uRaidType==cRaidDataPty)
    {
        gsCacheInfo.u16RaidPtyFreePagePtr++;
        u16RaidPtyPtr=gsCacheInfo.u16RaidPtyFreePagePtr;
    }
    else if(uRaidType==cRaidGcPty)
    {
        gsCacheInfo.u16RaidGcPtyFreePagePtr++;
        u16RaidPtyPtr=gsCacheInfo.u16RaidGcPtyFreePagePtr;
    }

    if(u16RaidPtyPtr>=gsCacheInfo.u16RaidPtyPagePerBlk3)
    {
        waitChCeBz(gActiveCh, gIntlvAddr, 0);
        waitCmdFifoDpt(gActiveCh, gpFlashAddrInfo);
    }

    /*if((gsCacheInfo.u16RaidPtyFreePagePtr==gsCacheInfo.u16RaidPtyPagePerBlk3)||
       * (gsCacheInfo.u16RaidGcPtyFreePagePtr==gsCacheInfo.u16RaidPtyPagePerBlk3))
       * {
       *  progCacheInfoTab();
       * }*/
}    /* progPartialRaidParity */

void chkAddHmbPtyQue(WORD u16BufPtr, WORD u16PtyIdx, BYTE uPagePerWL, BYTE uPageSel, BYTE uXfrDir)
{
    gsHmbPtyInfo.uarHmbPtyQ[gsHmbPtyInfo.u32HmbPtyHead].u16BufPtr=u16BufPtr;
    gsHmbPtyInfo.uarHmbPtyQ[gsHmbPtyInfo.u32HmbPtyHead].u16PtyIdx=u16PtyIdx;
    gsHmbPtyInfo.uarHmbPtyQ[gsHmbPtyInfo.u32HmbPtyHead].uPagePerWL=uPagePerWL;
    gsHmbPtyInfo.uarHmbPtyQ[gsHmbPtyInfo.u32HmbPtyHead].uPageSel=uPageSel;
    gsHmbPtyInfo.uarHmbPtyQ[gsHmbPtyInfo.u32HmbPtyHead].uXfrDir=uXfrDir;

    gsHmbPtyInfo.u32HmbPtyHead=addPtrBy1(gsHmbPtyInfo.u32HmbPtyHead, cHmbPtyQueDpt);

    while(gsHmbPtyInfo.u32HmbPtyTail==addPtrBy1(gsHmbPtyInfo.u32HmbPtyHead, cHmbPtyQueDpt))
        ;
}

void savePartialParityGc(WORD u16BufPtr, WORD u16FPage, BYTE uPageSel)
{
    BYTE uProgCntPerWL;
    WORD u16ParityIdx;

    if(gsCacheInfo.u16PartialParityPtrGc<gsCacheInfo.u16PartialParityNumGc)
    {
        u16ParityIdx=u16FPage%(gsCacheInfo.u16PartialParityNumGc+cRaidParityNum);

        if(uPageSel==cSLC)
        {
            uProgCntPerWL=1;
            uPageSel=0;
        }
        else
        {
            uProgCntPerWL=cProgCntPerWL;
        }

        if(gsGcInfo.uHmbEnPtCache)
        {
            chkAddHmbPtyQue(u16BufPtr, u16ParityIdx, uProgCntPerWL, uPageSel, cWriteHmbPty);
        }
        else
        {
            progPartialRaidParity(u16BufPtr, u16ParityIdx, cRaidGcPty, uPageSel);
        }

        if((uProgCntPerWL==1)||(uPageSel==(cProgCntPerWL-1)))
        {
            gsCacheInfo.u16PartialParityPtrGc++;
        }
    }
}    /* savePartialParityGc */

void handleGcRaidParity(WORD u16BufIdx, WORD u16FPage, BYTE uPageSel)
{
    WORD u16SbufPtr, u16PtyIdx, u16NowNodeIdx;
    BYTE uTotalPtyCnt, uProgCntPerWL, uRaidType, uPageIdx, uPtyPtr=0;

    if(uPageSel==cSLC)
    {
        uProgCntPerWL=1;
        uRaidType=cRaidPtySBlk;
        uPageIdx=0;
        uTotalPtyCnt=(BYTE)(g16SlcPartialParityNum>>cRaidStringShiftBit);
    }
    else
    {
        uProgCntPerWL=cProgCntPerWL;
        uRaidType=cRaidPtyTBlk;
        uPageIdx=uPageSel;
        uTotalPtyCnt=(BYTE)(g16TlcPartialParityNum>>cRaidStringShiftBit);
    }

    u16SbufPtr=c16GcParitySIdx;
    hdmaGetRaidPty(u16SbufPtr, cHdmaWait|cHdmaTsbFlag, cRaidPtyClr|cRaidGcBlk, u16FPage, uPageSel);
    hdmaEncRam(u16SbufPtr, cRaidDataSctrNum, 0, cHdmaNotWait|cHdmaTsbFlag, uRaidType, uPageSel);

    while(uPtyPtr<uTotalPtyCnt)
    {
        u16PtyIdx=gsCacheInfo.uRaidPtrGc+(uPtyPtr<<cRaidStringShiftBit);

        if(gsGcInfo.uHmbEnPtCache)
        {
            chkAddHmbPtyQue(u16SbufPtr, u16PtyIdx, uProgCntPerWL, uPageIdx, cReadHmbPty);
        }
        else
        {
            u16NowNodeIdx=gsRwCtrl.uarFreeSrcQue[gsRwCtrl.u32FreeSrcFifoHead];
            gpFlashAddrInfo=&garSrcAddrInfo[u16NowNodeIdx];
            g16FBlock=g16arRaidParityBlk[mGetRaidPtyBlkIndex(u16PtyIdx*uProgCntPerWL+uPageIdx)];
            g32FPageNoTran=mTranRaidPtyAddr(mGetRaidPtyPagePtr(u16PtyIdx*uProgCntPerWL+uPageIdx));
            gpFlashAddrInfo->uTsb4kIdx=0xFF;
            gpFlashAddrInfo->uSrcIdx=u16NowNodeIdx;
            tranAddrInfo(gpFlashAddrInfo);
            // tranCeNum(gpFlashAddrInfo);
            gSectorH=0;
            mSetFRwParam(u16SbufPtr, cRaidDataSctrNum, c16Bit1|c16Bit4, cReadRaidParity);
            gsRwCtrl.u32FreeSrcFifoHead=(gsRwCtrl.u32FreeSrcFifoHead+1)&(cReadFifoDpt-1);

            // if(gsRwCtrl.u32FreeSrcFifoTrig!=gsRwCtrl.u32FreeSrcFifoHead)
            // {
            insSrcCmdList();
            // }
            chkPostReadFifo3();

            while(gsRwCtrl.usSrcCmdList.u16Cnt)
            {
                trigFlCmdFfStep2();
            }
        }

        hdmaEncRam(u16SbufPtr, cRaidDataSctrNum, 0, cHdmaNotWait|cHdmaTsbFlag, uRaidType, uPageSel);
        uPtyPtr++;
    }

    hdmaGetRaidPty(u16BufIdx, cHdmaWait|cHdmaTsbFlag, cRaidPtyClr|uRaidType, 0, uPageSel);

    if((uProgCntPerWL==1)||(uPageIdx==cProgCntPerWL-1))
    {
        gsCacheInfo.uRaidPtrGc++;

        if(gsCacheInfo.uRaidPtrGc>=cRaidParityNum)
        {
            gsCacheInfo.u16PartialParityPtrGc=0;
            gsCacheInfo.uRaidPtrGc=0;
            gsCacheInfo.uRaidF2HBankGc++;
        }
    }
}    /* handleGcRaidParity */

void trigHdmaEncData(ADDRINFO *upAddrInfo)
{
    BYTE uSecNumPadF2h, uSecNumPadF2h_1, uSecNumPadF2h_2;
    WORD u16BufIdx, u16F2hPadStartAddr_1, u16F2hPadStartAddr_2;

    gpFlashAddrInfo=upAddrInfo;

    if(g32Core1State==cCore1BootState_Finished)
    {
        if(gBlkId==cCacheBlockID)
        {
            hdmaEncRam(mGetWriteBuf, mGetProgSctrCnt, g16FPage, cHdmaNotWait|cHdmaTsbFlag|cHdmaRaidFlag, cRaidDataBlk, cSLC);

            if(g16RwOpt&(cProg16kF2H|cProg32kF2H))
            {
                // if(gbLsbOnly)
                // {
                uSecNumPadF2h_1=gSlcSecNumPadF2h_1;
                uSecNumPadF2h_2=gSlcSecNumPadF2h_2;
                u16F2hPadStartAddr_1=g16SlcF2hPadStartAddr_1;
                u16F2hPadStartAddr_2=g16SlcF2hPadStartAddr_2;
                // }
                // else
                // {
                //     uSecNumPadF2h_1=gTlcSecNumPadF2h_1;
                //     uSecNumPadF2h_2=gTlcSecNumPadF2h_2;
                //     u16F2hPadStartAddr_1=g16TlcF2hPadStartAddr_1;
                //     u16F2hPadStartAddr_2=g16TlcF2hPadStartAddr_2;
                // }

                if(g16RwOpt&cProg16kF2H)
                {
                    uSecNumPadF2h=uSecNumPadF2h_1;
                    u16BufIdx=u16F2hPadStartAddr_1;
                }
                else if(g16RwOpt&cProg32kF2H)
                {
                    uSecNumPadF2h=uSecNumPadF2h_2;
                    u16BufIdx=u16F2hPadStartAddr_2;

                    if(g16RwOpt&cProgPlaneRaid)
                    {
                        u16BufIdx=u16F2hPadStartAddr_2+gSectorPerPageH;
                        uSecNumPadF2h-=cRaidDataSctrNum;
                    }
                }

                hdmaEncRam(u16BufIdx, uSecNumPadF2h, g16FPage, cHdmaNotWait, cRaidDataBlk, cSLC);    // F2h
            }

            if(g32ParityOut&cRaidDataPty)
            {
                rstH2F1KInfo2(0);
                hdmaGetRaidPty(c16ParitySIdx, cHdmaNotWait|cHdmaTsbFlag, cRaidPtyClr|cRaidDataBlk, g16FPage, cSLC);
            }
        }

#if _EN_RAID_GC
        else if(gBlkId==cGcDesBlockID)
        {
            BYTE uPageType=mChkMlcMoBit(g16FBlock)?(mGetPageSelCmd(gpFlashAddrInfo)-1):cSLC;

            if(g16RwOpt&cProgPlaneRaid)
            {
                hdmaEncRam(mGetWriteBuf, gSectorPerPlaneH, g16FPage, cHdmaNotWait|cHdmaTsbFlag|cHdmaRaidFlag, cRaidGcBlk, uPageType);

                u16BufIdx=mGetWriteBuf+cRaidDataSctrNum;

                if(gSecurityOption&cEnE2e)
                {
                    hdmaClrRam((LWORD)(c32TsbCrcAddr+(u16BufIdx<<3)),
                               cRaidDataSctrNum<<3,
                               (LWORD)0x00000000,
                               cClrTsb|cHdmaNotWait);
                }

                hdmaEncRam(u16BufIdx, cRaidDataSctrNum, g16FPage, cHdmaNotWait|cHdmaSrcRaidFlagOnly, cRaidGcBlk, uPageType);
                handleGcRaidParity(u16BufIdx, g16FPage, uPageType);
            }
            else
            {
                hdmaEncRam(mGetWriteBuf, mGetProgSctrCnt, g16FPage, cHdmaNotWait|cHdmaTsbFlag|cHdmaRaidFlag, cRaidGcBlk, uPageType);

                if(g32ParityOut&cRaidGcPty)
                {
                    hdmaGetRaidPty(c16GcParitySIdx, cHdmaNotWait|cHdmaTsbFlag, cRaidPtyClr|cRaidGcBlk, g16FPage, uPageType);
                    savePartialParityGc(c16GcParitySIdx, g16FPage, uPageType);
                }
            }
        }
#endif/* if _EN_RAID_GC */
    }

#if _EN_RAID_UGSD
    else if((g32Core1State>=cCore1BootState_4)&&(gOpTyp==cBootMoveCache))
    {
        hdmaEncRam(mGetWriteBuf, mGetProgSctrCnt, g16FPage, cHdmaWait, cRaidDataBlk, cSLC);

        if(g16RwOpt&cProg32kF2H)
        {
            uSecNumPadF2h_1=gSlcSecNumPadF2h_1;
            uSecNumPadF2h_2=gSlcSecNumPadF2h_2;
            u16F2hPadStartAddr_1=g16SlcF2hPadStartAddr_1;
            u16F2hPadStartAddr_2=g16SlcF2hPadStartAddr_2;
            uSecNumPadF2h=uSecNumPadF2h_2;
            u16BufIdx=u16F2hPadStartAddr_2;

            if(g16RwOpt&cProgPlaneRaid)
            {
                uSecNumPadF2h-=cRaidDataSctrNum;
            }

            hdmaEncRam(u16BufIdx, uSecNumPadF2h, g16FPage, cHdmaWait, cRaidDataBlk, cSLC);    // F2h
        }

        if(g32ParityOut&cRaidDataPty)
        {
            hdmaGetRaidPty(c16ParitySIdx, cHdmaWait|cHdmaTsbFlag, cRaidPtyClr|cRaidDataBlk, g16FPage, cSLC);
        }
    }
#endif/* if _EN_RAID_UGSD */
}    /* trigHdmaEncData */

#if _EN_RAID_GSD
void termRaidAllEngForQB()
{
    BYTE uRaidEngCnt, uIdx, uRaidEngIdx;

    // Raid Term only if there are active engines.
    if(gsRaidInfo.u16RaidEngBitMap&cRaidEngFull)
    {
        uRaidEngCnt=gsRaidInfo.uRaidPopEngCnt;

        for(uIdx=0; uIdx<cRaidParityNum; uIdx++)
        {
            if(gsRaidInfo.u16arRaidFPage[cRaidDataBlk][uIdx]!=c16Null)
            {
                uRaidEngIdx=gsRaidInfo.uarRaidEngIdx[cRaidDataBlk][uIdx];

                if(mChkRaidEngBmap(uRaidEngIdx)&&(!mChkRaidEngPtyBmap(uRaidEngIdx)))
                {
                    trigRaidHdmaTerm((((LWORD)garTsb0[gsQBootInfo.u16QBVarPgSectorCnt+cCacheF2hSctrSize+c16CacheInfoTabSize]+uRaidEngIdx*
                                       c32QBRaidPtySize)>>9),
                                     cHdmaDesNonFlag,
                                     uRaidEngIdx,
                                     cRaidDataBlk,
                                     cRaidActOptNon,
                                     cHdmaWait);

                    uRaidEngCnt--;
                }
                else
                {
                    gsFtlDbg.u16DummyFailType=cTermRaidAllEngForQB;
                    debugWhile();
                }
            }
        }

        while(uRaidEngCnt)
            ;// DeBug ....
    }
}    /* termRaidAllEngForQB */

void resmRaidAllEngForQB()
{
    BYTE uRaidEngIdx;

    for(uRaidEngIdx=0; uRaidEngIdx<cRaidTotalEng; uRaidEngIdx++)
    {
        trigRaidHdmaResm(uRaidEngIdx, cHdmaSrcNonFlag);
    }
}

#endif/* if _EN_RAID_GSD */







