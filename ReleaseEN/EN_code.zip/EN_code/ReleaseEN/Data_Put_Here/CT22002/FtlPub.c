







#include "inc/ProType.h"
// #include "inc/FlashCtrl.h"
#include "inc/GlobVar0.h"
#include "inc/GlobVarS.h"
#include "inc/GlobVarT.h"
#include "inc/Reg.h"
#include "inc/Mac.h"

// #include "FakeScript.c"
#include "inc/FtlCtrl.h"

#if (!_ICE_LOAD_ALL)
#pragma default_function_attributes = @ ".FTL_PUB"
#endif
/*
   * #if (_CPUID!=1)
   * void readH2fTable(WORD u16SbufPtr, WORD u16Hblock, WORD u16RwOpt)
   * {
   *  WORD u16FBlock, u16FPage, u16NowNodeIdx;
   *  BYTE uRead4kCnt;
   *
   *  u16FBlock=g16arH2fTabBlk[mGetH2fTabBlkIndex(u16Hblock)];
   *  u16FPage=(mGetH2fTabPagePtr(u16Hblock))*cPage4kPerH2fTab;
   *  uRead4kCnt=cPage4kPerH2fTab;
   *
   *  while(uRead4kCnt!=0)
   *  {
   * #if (_ENABLE_SRC_LINK_LIST)
   *      u16NowNodeIdx=gsRwCtrl.uarFreeSrcQue[gsRwCtrl.u32FreeSrcFifoHead];
   *      gpFlashAddrInfo=&garSrcAddrInfo[u16NowNodeIdx];
   * #else
   *      gpFlashAddrInfo=&garSrcAddrInfo[gsRwCtrl.uReadFifoHead];
   * #endif
   *      g16FBlock=u16FBlock;
   *      g32FPageNoTran=u16FPage;
   *      // g16FPage=g32FPageNoTran;
   *      tranAddrInfo(gpFlashAddrInfo);
   *      // tranCeNum(gpFlashAddrInfo);
   *      gSectorH=0;
   *      mSetFRwParam(u16SbufPtr, g4kNumPerPage*cSctrPer4k, u16RwOpt, cH2fReadTab);
   *      // gsCacheInfo.ubPrep++;
   *
   * #if (_ENABLE_SRC_LINK_LIST)
   *      // insertTaskToSrcAddrInfo(uNowSrcAddrIdx);
   *      // upInsLlInfo=&gsRwCtrl.usSrcCmdList;
   *      // mInsNode(u16PrevNodeIdx, upInsLlInfo, u16NextNodeIdx, gsRwCtrl.uarSrcCmdLink, u16NowNodeIdx);
   *      gsRwCtrl.u32FreeSrcFifoHead=(gsRwCtrl.u32FreeSrcFifoHead+1)&(cReadFifoDpt-1);
   *
   *      while(gsRwCtrl.u32FreeSrcFifoTail!=gsRwCtrl.u32FreeSrcFifoHead)
   * #else
   *      chkAddReadFifoHead();
   *
   *      while(gsRwCtrl.uSrcCmdFifoCnt!=0)
   * #endif
   *      {
   * #if !_Enable_Core1
   *          trigFlashCmdFifoR(0);
   * #endif
   *      }
   *
   *      u16FPage+=g4kNumPerPage;
   *      u16SbufPtr+=g4kNumPerPage*cSctrPer4k;
   *      uRead4kCnt-=g4kNumPerPage;
   *  }
   * }
   *
   * void swapH2fTable(WORD u16Hblock, WORD u16SbufPtr)
   * {
   *  LWORD u32H2fAddr;
   *
   * #if (_RunDram)
   *  outCS("CS. swapH2fTable");
   *  outString("u16Hblock =@", u16Hblock);
   *  outString("g16arH2fTabPtr[(u16Hblock)] =@", g16arH2fTabPtr[(u16Hblock)]);
   * #endif
   *
   *  if(g16arH2fTabPtr[u16Hblock]!=0xFFFF)
   *  {
   *      if(mChkHmbLink(u16Hblock))
   *      {
   *          // remHmbLink(u16Hblock);    // add read hmb 64k table later
   *      }
   *
   *      // else
   *      // {
   *      readH2fTable(u16SbufPtr, u16Hblock, c16Bit0|c16Bit4|c16Bit15);
   *      // }
   *  }
   *  else
   *  {
   *      u32H2fAddr=c32Tsb0SAddr+u16SbufPtr*0x200;
   *      hdmaClrRam((LWORD)u32H2fAddr, c32H2fTabRamSize, (LWORD)0xFFFFFFFF, cClrTsb|cHdmaNotWait);
   *  }
   *
   *  // gsCacheInfo.u15ActiveH2fTab=u16Hblock;
   * }
   * #endif
   */

void progCacheInfoTab()
{
    if(mChkDummyWrite)
    {
        return;
    }

    while(mChkCacheInfoChangeFlag(cH2fChg))
        ;// debug????????????????

    // u16OrgFblock=gsCacheInfo.u16CacheInfoBlk;
    // gsCacheInfo.ubCacheInfoProgFail=0;

    g16BkActiveCacheBlock=gsCacheInfo.u16ActiveCacheBlock;
    g16BkFluCacheBlock=gsCacheInfo.u16FluCacheBlock;
    g16BkPrePopCacheBlock=gsCacheInfo.u16PrePopCacheBlock;

    g32BkCacheBlkSerial=gsCacheInfo.u32CacheBlkSerial;
    g32BkFluBlkSerial=gsCacheInfo.u32FluBlkSerial;
    g32BkH2fTabBlkSerial=gsCacheInfo.u32H2fTabBlkSerial;

    g16BkActiveGcDesBlock=gsGcInfo.u16GcDesBlock;

    if(gsGcInfo.u32GcDesSerial==c32InitSerialVal)
    {
        g32BkGcDesSerial=gsCacheInfo.u32CacheBlkSerial;
    }
    else
    {
        g32BkGcDesSerial=gsGcInfo.u32GcDesSerial;
    }

    g32BkTotalSlcVpc=gsGcInfo.u32TotalSlcVpc;
    g32BkTotalTlcVpc=gsGcInfo.u32TotalTlcVpc;

    g16BkGcDesSlcBlock=gsGcInfo.u16GcDesSLCBlock;
    g16BkGcDesTlcBlock=gsGcInfo.u16GcDesTLCBlock;

    if(gsCacheInfo.uH2fTabBlockCnt!=0)
    {
        g16BkActH2fTabFblk=g16arH2fTabBlk[gsCacheInfo.uActH2fTabBlkIdx];
        g16BkH2fTabFreePagePtr=gsCacheInfo.u16H2fTabFreePagePtr;
    }
    else
    {
        g16BkActH2fTabFblk=c16BitFF;
        g16BkH2fTabFreePagePtr=c16BitFF;
    }

    gBkFidBlock=gsFwDlInfo.uSysRsvFwDlImageBlk;

    g32TotalEraseCnt=gsCacheInfo.u32TotalEraseCnt;
    g32DynamicTotalEraseCnt=gsCacheInfo.u32DynamicTotalEraseCnt;
    g32SLCTotalEraseCnt=gsCacheInfo.u32SLCTotalEraseCnt;
    // g16TLCGcWLCnt=gsFtlDbg.u16TLCGcWLCnt;
    // g16SLCReclaimCnt=gsFtlDbg.u16SLCReclaimCnt;
    // g16ReclaimCnt=gsFtlDbg.u16ReclaimCnt;
#if _EN_SLCOpenBlkReadScrub
    // g16SLCFlushCnt=gsFtlDbg.u16SLCFlushCnt;
    // g16H2FReadScrubCnt=gsFtlDbg.u16H2FScrubCnt;
#endif

    g32MaxS2TGCtime=gsGcInfo.u32GcMaxS2TProcTime;
    g32MaxT2TGCtime=gsGcInfo.u32GcMaxT2TProcTime;

    // program Cache info table should not do swap WPRO, swap WPRO will use TSB 0 as read write buffer
#if (_CPUID==1)
    waitAllChCeBz();

#if _ENABLE_SECAPI
    if(gInSecApi)
    {
        progWproPage(cWproCacheInfo, cSecurityAlgorithmStartBufIdx|c16Bit15);
    }
    else
#endif
    {
        progWproPage(cWproCacheInfo, c16CacheInfoTabSIdx|c16Bit15);
    }
#else
    waitAllChCeBzCore0();
#if _ENABLE_SECAPI
    if(gInSecApi)
    {
        progWproPageCore0(cWproCacheInfo, cSecurityAlgorithmStartBufIdx|c16Bit15);
    }
    else
#endif
    {
        progWproPageCore0(cWproCacheInfo, c16CacheInfoTabSIdx|c16Bit15);
    }
#endif/* if (_CPUID==1) */
    rstH2F1KInfo();

    if(gsRdlinkInfo.ubSaveCacheInfo)
    {
        gsRdlinkInfo.ubSaveCacheInfo=0;
    }
}    /* progCacheInfoTab */

void pushH2fBlk(BYTE uTabBlkIdx)
{
    if(g16arH2fTabBlk[uTabBlkIdx]==gsRdlinkInfo.u16LastH2fTabFblk)    // 20190117_Louis
    {
        NLOG(cLogTempDebug, FTLPUB_C, 2, " PushH2fBlk return! Blk=0x%04x, uTabBlkIdx=0x%04x", (WORD)gsRdlinkInfo.u16LastH2fTabFblk, uTabBlkIdx);
        return;
    }

#if (_CPUID==1)
    pushSpareBlock(g16arH2fTabBlk[uTabBlkIdx], cPushNotErase);
#else
    pushSpareBlockCore0(g16arH2fTabBlk[uTabBlkIdx], cPushNotErase);
#endif

    while(!gsCacheInfo.uH2fTabBlockCnt)
        ;

    gsCacheInfo.uH2fTabBlockCnt--;

    if(mChkGcQue(cGcTypH2fTab)&&(gsCacheInfo.uH2fTabBlockCnt<=gsGcInfo.uGcH2fTabbLoThr))
    {
        mPopGcQue(cGcTypH2fTab);
    }

#if _EN_SLCOpenBlkReadScrub
    if(g16arH2fTabBlk[uTabBlkIdx]==gsGcInfo.u16H2FReclaimBlk)
    {
        gsGcInfo.u16H2FReclaimBlk=c16FBlockInitValue;
        mClrGcFlag(cReadScrubH2F);
    }
#endif

    g16arH2fTabBlk[uTabBlkIdx]=0xFFFF;
    g32arH2fTabBlkSn[uTabBlkIdx]=c32InitSerialVal;
}    /* pushH2fBlk */

void setH2fTabPagePtr(WORD u16Hblock, BYTE uTabBlkIdx, WORD u16TabPagePtr)
{
    BYTE uOrgTabBlkIdx;    // =mGetH2fTabBlkIndex(u16Hblock);
    WORD u16HblkPtr;

    if(uTabBlkIdx!=0xFF)
    {
        g16arH2fTabBlkVpCnt[uTabBlkIdx]++;
    }

    if(mChkHmbLink(u16Hblock))
    {
        u16HblkPtr=g16TotalHBlock+mGetHmbLink(u16Hblock);
    }
    else
    {
        u16HblkPtr=u16Hblock;
    }

    if(g16arH2fTabPtr[u16HblkPtr]!=c16H2FTabInitValue)    // !mChkH2fTabNullF(u16Hblock))
    {
        uOrgTabBlkIdx=mGetH2fTabBlkIndex(u16HblkPtr);

        while(!g16arH2fTabBlkVpCnt[uOrgTabBlkIdx])
            ;

        g16arH2fTabBlkVpCnt[uOrgTabBlkIdx]--;

        if(!g16arH2fTabBlkVpCnt[uOrgTabBlkIdx]&&(uOrgTabBlkIdx!=gsCacheInfo.uActH2fTabBlkIdx))
        {
            while(!gsCacheInfo.uH2fTabBlockCnt)
                ;

            pushH2fBlk(uOrgTabBlkIdx);
        }
    }

    // garH2fTabBlkIndex[u16Hblock]=uTabBlkIdx;
    // g16arH2fTabPagePtr[u16Hblock]=u16TabPagePtr;

    if(uTabBlkIdx!=0xFF)
    {
        mSetH2fTabEntry(u16HblkPtr, uTabBlkIdx, u16TabPagePtr);
        // if(mChkH2fTabNullF(u16Hblock))
        // {
        //    mClrH2fTabNullF(u16Hblock);
        // }
    }
    else
    {
        g16arH2fTabPtr[u16Hblock]=c16H2FTabInitValue;
        // mSetH2fTabNullF(u16Hblock);

        if(gsGcInfo.u16GcIncompleteSrchHblk==u16Hblock)
        {
            gsGcInfo.u16GcIncompleteSrchFblk=cInvldFBlk;
            gsGcInfo.u16GcIncompleteSrchHblk=cInvldHBlk;
            gsGcInfo.u16GcIncompleteSrchHpg=0xFFFF;
            gsGcInfo.uGcIncompleteSrchSrcBlkPtr=0xFF;
        }
    }
}    /* setH2fTabPagePtr */

/**************/
// all project
/**************/
void tranAddrInfo(ADDRINFO *upAddrInfo)
{
    LWORD u32TempFPageNoTran;

    u32TempFPageNoTran=upAddrInfo->u32FPageNoTran;
    upAddrInfo->u16AbstractFBlock=upAddrInfo->u16FBlock;
    upAddrInfo->uDieAddr=(BYTE)((u32TempFPageNoTran>>gDieAddrBitShiftCnt2)&g32DieAddrBitMask);
    upAddrInfo->uCe=(BYTE)((u32TempFPageNoTran>>gCeAddrBitShiftCnt)&g32CeAddrBitMask);
    upAddrInfo->uIntlvAddr=(upAddrInfo->uCe<<gDieBitCnt)+(upAddrInfo->uDieAddr);
    upAddrInfo->uCh=(BYTE)((u32TempFPageNoTran>>gChAddrBitShiftCnt)&g32ChAddrBitMask);
    upAddrInfo->uPlaneAddr=(BYTE)((u32TempFPageNoTran>>gPlaneAddrBitShiftCnt)&g32PlaneAddrBitMask);
    upAddrInfo->u16FPage=(WORD)((u32TempFPageNoTran>>gPhyPageAddrBitShiftCnt)&g32PhyPageAddrMask);

    if((upAddrInfo->u16FBlock>=g16TotalFBlock)&&(upAddrInfo->u16FBlock<c16FBlockInitValue))
    {
        gsFtlDbg.u16DummyFailType=cTranAddrInfo;
        debugWhile();
    }

    if(!mChkMlcMoBit(upAddrInfo->u16FBlock))
    {
        // upAddrInfo->ubLargePg=0;
        setPageSelCmd(upAddrInfo, cSlcCmd);    // upAddrInfo->uPageSelCmd=cSlcCmd;
    }
    else
    {
        // upAddrInfo->ubLargePg=1;
        u32TempFPageNoTran=upAddrInfo->u16FPage;
        upAddrInfo->u16FPage=u32TempFPageNoTran/cProgCntPerWL;
        // upAddrInfo->uPageSelCmd=(u32TempFPageNoTran-(upAddrInfo->u16FPage*cProgCntPerWL))+1;
        setPageSelCmd(upAddrInfo, (u32TempFPageNoTran-(upAddrInfo->u16FPage*cProgCntPerWL))+1);
    }

    /* if(mChkMlcMoBit(upAddrInfo->u16FBlock))
       * {
       *   u32Total4kNum=cProgCntPerWL*gTotalIntlvChPlaneNum*g4kNumPerPlane;
       *   upAddrInfo->ubLargePg=1;
       *   upAddrInfo->u16FPage=u32TempFPageNoTran/u32Total4kNum;
       *   u32TempFPageNoTran=u32TempFPageNoTran-(upAddrInfo->u16FPage*u32Total4kNum);
       *   u32Total4kNum=cProgCntPerWL*gTotalChPlaneNum*g4kNumPerPlane;
       *
       *   uIntlvAddr=0;
       *
       *   while(u32TempFPageNoTran>=u32Total4kNum)
       *   {
       *       u32TempFPageNoTran-=u32Total4kNum;
       *       uIntlvAddr++;
       *   }
       *
       *   upAddrInfo->uIntlvAddr=uIntlvAddr;
       *   upAddrInfo->uDieAddr=(BYTE)(uIntlvAddr>>gCeBitCnt);    // &g32DieAddrBitMask);
       *   upAddrInfo->uCe=(BYTE)(uIntlvAddr&g32CeAddrBitMask);
       *
       *   uPageSelCmd=1;
       *   u32Total4kNum=gTotalChPlaneNum*g4kNumPerPlane;
       *
       *   while(u32TempFPageNoTran>=u32Total4kNum)
       *   {
       *       uPageSelCmd++;
       *       u32TempFPageNoTran-=u32Total4kNum;
       *   }
       *
       *   // u32TempFPageNoTran=u32TempFPageNoTran-((uPageSelCmd-1)*u32Total4kNum);
       *   upAddrInfo->uPageSelCmd=uPageSelCmd;
       *   upAddrInfo->uCh=(BYTE)((u32TempFPageNoTran>>gChAddrBitShiftCnt)&g32ChAddrBitMask);
       *   upAddrInfo->uPlaneAddr=(BYTE)((u32TempFPageNoTran>>gPlaneAddrBitShiftCnt)&g32PlaneAddrBitMask);
       * }
       * else
       * {
       *   upAddrInfo->ubLargePg=0;
       *   upAddrInfo->uDieAddr=(BYTE)((u32TempFPageNoTran>>gDieAddrBitShiftCnt2)&g32DieAddrBitMask);
       *   upAddrInfo->uCe=(BYTE)((u32TempFPageNoTran>>gCeAddrBitShiftCnt)&g32CeAddrBitMask);
       *   upAddrInfo->uIntlvAddr=upAddrInfo->uCe+(upAddrInfo->uDieAddr<<gDieBitCnt);
       *   upAddrInfo->uCh=(BYTE)((u32TempFPageNoTran>>gChAddrBitShiftCnt)&g32ChAddrBitMask);
       *   upAddrInfo->uPlaneAddr=(BYTE)((u32TempFPageNoTran>>gPlaneAddrBitShiftCnt)&g32PlaneAddrBitMask);
       *   upAddrInfo->u16FPage=(WORD)((u32TempFPageNoTran>>gPhyPageAddrBitShiftCnt)&g32PhyPageAddrMask);
       *   upAddrInfo->uPageSelCmd=0xA2;
       * }*/
}    /* tranAddrInfo */

void tranAddrInfoTo2Ch(ADDRINFO *upAddrInfo)
{
    WORD u16Rem;
    WORD u16PagePerCh=gTotalChNum/cWriteChNum;

    u16Rem=upAddrInfo->u16FPage%(gTotalIntlvChPlaneNum/cWriteChNum)    /*(gIntlvWay*gPlaneNum*u16PagePerCh)*/;
    upAddrInfo->u16FPage=upAddrInfo->u16FPage/(gTotalIntlvChPlaneNum/cWriteChNum)    /*(gIntlvWay*gPlaneNum*u16PagePerCh)*/;
    upAddrInfo->uIntlvAddr=u16Rem/(gTotalChPlaneNum/cWriteChNum)    /*(gPlaneNum*u16PagePerCh)*/;
    u16Rem=u16Rem%(gTotalChPlaneNum/cWriteChNum)    /*(gPlaneNum*u16PagePerCh)*/;
    upAddrInfo->uCh=u16Rem/gPlaneNum;
    upAddrInfo->uCh*=u16PagePerCh;
    upAddrInfo->uPlaneAddr=u16Rem%gPlaneNum;
    upAddrInfo->uCe=(BYTE)mGetCEAddr(upAddrInfo->uIntlvAddr);
    upAddrInfo->uDieAddr=mGetDieAddr(upAddrInfo->uIntlvAddr);
    mClrMlcMoBit(upAddrInfo->u16FBlock);
}

BYTE chkBgdClnCacheBlk()    // BYTE uCaller)
{
    BYTE uSts;

#if (_EN_IOMTRIG&&_EN_VPC_SWAP)
    if((gsIomInfo.u8Status==cIoMeterTrig)||(gsIomInfo1Thr.u8Status==cIoMeterTrig))
    {
        if(gsGcInfo.u32TotalSlcVpc+gsGcInfo.u32TotalTlcVpc<0xF00000)    // 60G
        {
            g16MaxSlcBlkQ=cIOMeterMaxSlcBlkQ-(gsCacheInfo.u16TLCFullCacheBlockCnt*3)-30;
        }
        else
        {
            InitIoMeter();
            InitIoMeter1Thr();
        }
    }
#endif/* if _EN_IOMTRIG */

    if(gsCacheInfo.u16DynamicSpareCnt<=cSprbCnt2ExitGc)
    {
        mSetGcFlag(cGcSpareNotEnough);
        uSts=cTrue;
    }

#if (_EN_IOMTRIG&&_EN_VPC_SWAP)
    else if((gsIomInfo.u8Status==cIoMeterTrig)||(gsIomInfo1Thr.u8Status==cIoMeterTrig))
    {
        if(gsCacheInfo.u16FullCacheBlockCnt<g16MaxSlcBlkQ)
        {
            uSts=cFalse;
        }
    }
#endif
#if _EN_RWEND_NOGC    // 20190508_ChrisSu_02
    else if(gGCOpt&gbRWEndGC)
    {
        NLOG(cLogTempDebug, FTLPUB_C, 0, " RW END No GC!");
        uSts=cFalse;
    }
#endif
    else if(mNvmeChkShn)
    {
        uSts=cFalse;
    }
    else if(gsGcInfo.uGCSLCReclaimPtr||gsGcInfo.uGcPrioTlcBlkNumPtr)
    {
        uSts=cTrue;
    }
    else if((mChkGcFlag(cUnderBgdGc))&&(mGetGcState==cGcStateIdle)&&
            (((gsGcInfo.u32TotalSlcVpc<=g32VpcPerSlcBlk)&&(gsCacheInfo.u16FullCacheBlockCnt<=gsGcInfo.uRsvSLCBlkInBgdCln))
             &&(gsCacheInfo.u16TLCFullCacheBlockCnt<g16TlcFullCachebGcThr)))
    {
#if _EN_BgdT2tClnCdm    // ChrisSu_20190329  sync SMI S0322B
        if(gsCacheInfo.u16SpareBlockCnt<cDirtyCdmRsvSprThr)
        {
            if(((gsGcInfo.u32TotalTlcVpc+g32VpcPerTlcBlk)/g32VpcPerTlcBlk)>(gsCacheInfo.u16TLCFullCacheBlockCnt/10*9))
            {
                uSts=cFalse;
                mSetGcFlag(cStopBgdClean);
            }
            else
            {
                uSts=cTrue;
            }
        }
        else
#endif
        {
            uSts=cFalse;
            mSetGcFlag(cStopBgdClean);
        }
    }
    else if((mChkGcFlag(cUnderBgdGc))&&(mGetGcState==cGcStateIdle)&&(!gsCacheInfo.u16FullCacheBlockCnt))
    {
#if _EN_BgdT2tClnCdm    // ChrisSu_20190329  sync SMI S0322B
        if(gsCacheInfo.u16SpareBlockCnt<cDirtyCdmRsvSprThr)
        {
            if(((gsGcInfo.u32TotalTlcVpc+g32VpcPerTlcBlk)/g32VpcPerTlcBlk)>(gsCacheInfo.u16TLCFullCacheBlockCnt/10*9))
            {
                uSts=cFalse;
                mSetGcFlag(cStopBgdClean);
            }
            else
            {
                uSts=cTrue;
            }
        }
        else
#endif
        {
            uSts=cFalse;
            mSetGcFlag(cStopBgdClean);
        }
    }

#if (!_EN_Dynamic_Fix_Boundary)
    else if((gsCacheInfo.u16SpareBlockCnt>=gsGcInfo.u16GcCachebActThr)&&(!(mChkGcFlag(cUnderBgdGc))))
    {
        uSts=cFalse;
    }
#else
#if _EN_VPC_SWAP
    else if((!mChkGcFlag(cUnderBgdGc))&&(gsFtlDbg.uStaticMode!=cEndStaticMode)&&(gsCacheInfo.u16SpareBlockCnt>=gsGcInfo.u16GcCachebActThr)&&
            (g16SlcSortQCnt<=(g16MaxSlcBlkQ*2/3)))    // 20190521_Louis
#else
    else if((!mChkGcFlag(cUnderBgdGc))&&(gsFtlDbg.uStaticMode!=cEndStaticMode)&&(gsCacheInfo.u16SpareBlockCnt>=gsGcInfo.u16GcCachebActThr)&&
            (g16SlcSortQCnt<=(cMaxSlcBlkQ*2/3)))    // 20181223_Bruce
#endif
    {
        uSts=cFalse;
    }
#endif/* if (!_EN_Dynamic_Fix_Boundary) */
    else if(mChkGcFlag(cUnderBgdGc)&&mNvmeChkCcEnOn)
    {
        uSts=cFalse;
    }

#if _GREYBOX
    else
    {
        uSts=cTrue;
    }
    return uSts;
#else
/*
   *  else if(gsCacheInfo.u16FullCacheBlockCnt>=10)
   *  {
   *      uSts=cTrue;
   *  }
   *  else
   *  {
   *      uSts=cFalse;
   *  }
   */
    else
    {
        uSts=cTrue;
    }
    /*
       * if(uSts==cTrue)
       * {
       *    return uSts;
       * }
       */
    // test end
    return uSts;
#endif/* if _GREYBOX */
}    /* chkBgdClnCacheBlk */

void rstWrpoInHmb()
{
    WORD u16WproIdx;

    for(u16WproIdx=cWproQBootPg; u16WproIdx<cMaxWproPageType; u16WproIdx++)
    {
        if(mChkGcInfoHmbLink(u16WproIdx))
        {
            gsWproInfo.u16arWproIdxPagePtr[u16WproIdx]=mGetWproPagePtr(u16WproIdx);
        }
    }
}

void rstH2F1KInfo(void)
{
    BYTE uTabCnt;

    gsCacheInfo.uH2f1kTabCnt=0;

    for(uTabCnt=0; uTabCnt<cMaxRH2fTabNum; uTabCnt++)
    {
#if _ENABLE_HMB_FLUSH
        while(mChkRH2fTabDirty(uTabCnt))
            ;
#endif
        g32arH2f1kTabSgmt[uTabCnt]=0xFFFFFFFF;
        rmSetSrchTgt(uTabCnt, 0xFFFFFFFF);
        // garH2f1kTabSgmtIdx[uTabCnt]=uTabCnt;
    }
}

void rstH2F1KInfo2(BYTE uRstTgt)
{
    BYTE uTabCnt;

    // gsCacheInfo.uH2f1kTabCnt=0;

    for(uTabCnt=cHalfRH2fTabNum; uTabCnt<cMaxRH2fTabNum; uTabCnt++)
    {
#if _ENABLE_HMB_FLUSH
        while(mChkRH2fTabDirty(uTabCnt))
            ;
#endif
        g32arH2f1kTabSgmt[uTabCnt]=0xFFFFFFFF;

        if(uRstTgt)
        {
            rmSetSrchTgt(uTabCnt, 0xFFFFFFFF);
        }

        // garH2f1kTabSgmtIdx[uTabCnt]=uTabCnt;
    }
}    /* rstH2F1KInfo2 */

void setFwPreOccuFlag(WORD u16BufPtr)
{
    // SM2263 Hw Bug
    LWORD u32BufInvBit=0;
    volatile LWORD *u32Result;

    mSetBitMask(u32BufInvBit, (u16BufPtr/cSctrPer4k)&0x1F);

    u16BufPtr=u16BufPtr>>8;
    u32Result=&(g32arFwPreOccuFlag[(u16BufPtr)]);

    while((*u32Result)&u32BufInvBit)
        ;// for hw bug, wait pre occupied flag is done

    setLock(&gsOccuMutexInfo);
    mSetFwBufOcc32Sts(u16BufPtr, u32BufInvBit);
    clrLock(&gsOccuMutexInfo);
}    /* setFwPreOccuFlag */

void clrFwPreOccuFlag(WORD u16BufPtr)
{
    // SM2263 Hw Bug
    LWORD u32BufInvBit=0;

    mSetBitMask(u32BufInvBit, (u16BufPtr/cSctrPer4k)&0x1F);

    setLock(&gsOccuMutexInfo);

    // if(!mChkFwBufOcc32Sts(u16BufPtr>>8, u32BufInvBit))
    // {
    mClrFwBufOcc32Sts(u16BufPtr>>8, u32BufInvBit);

    // }

    clrLock(&gsOccuMutexInfo);
}

void setPageSelCmd(ADDRINFO *upTmpAddrInfo, BYTE uPageSelCmd)
{
    upTmpAddrInfo->uSprOpt=(upTmpAddrInfo->uSprOpt&0xF8)|uPageSelCmd;
}

// put here temporarily
#if (_CPUID==0)

void restoreCacheBlockFull()
{
    if(gsCacheInfo.uF2hTabBank)
    {
        mClrCacheInfoFlag(cCacheBlockFull);
        gsCacheInfo.u16CacheBlockCnt++;
        gsCacheInfo.u16ActiveCacheBlock=gsCacheInfo.u16FluCacheBlock;    // MIKEY:reset after progCacheInfoTab for rebuild
        gsCacheInfo.u16FluCacheBlock=gsPcieErrInfo.u16BkFluCacheBlock;
        gsCacheInfo.uFlushCacheBlkBank=gsPcieErrInfo.uBkFlushCacheBlkBank;
        gsCacheInfo.u32SrchF4kBaseFlu=gsPcieErrInfo.u32BkSrchF4kBaseFlu;
        gsCacheInfo.u32FluBlkSerial=gsPcieErrInfo.u32BkFluBlkSerial;
        gsCacheInfo.uMaxFlushBankNum=gsPcieErrInfo.uBkMaxFlushBankNum;

        if((gsCacheInfo.uF2hTabBank!=gsCacheInfo.uMaxBankNum))
        {
            gsCacheInfo.u32SrchF4kBase-=gsCacheInfo.u16TotalPgPerF2hTab;
        }

        gsCacheInfo.uF2hTabBank--;
    }
}    /* restoreCacheBlockFull */

void recovPcieErrW2(BYTE uKeepLast4kCnt)
{
    BYTE uPlaneCnt;
    WORD u16CacheF2hTabFreePtr;
    LWORD u32ProgFifoTail;
    volatile LWORD *u32pF2h;

    u32ProgFifoTail=gsPcieErrInfo.uLastPreProgFifoTail;

#if _EN_FW_DEBUG_UART
    NLOG_PCIeErr(cLogPcieErr, FTLPUB_C, 4, " PCIe Wr: Prog Head=0x%04X, Tail=0x%04X, Trig=0x%04X, F2h=0x%04X",
                 gsPcieErrInfo.uLastProgFifoHead, gsPcieErrInfo.uLastProgFifoTail, gsPcieErrInfo.uLastProgFifoTrig, gsCacheInfo.uChkF2hRegion);
#endif

    if(u32ProgFifoTail!=gsRwCtrl.u32ProgFifoHead)
    {
        u16CacheF2hTabFreePtr=gsCacheInfo.u16TotalPgPerF2hTab-(gsCacheInfo.u32CacheFreePagePtr%gsCacheInfo.u16TotalPgPerF2hTab)-1;

        if((gsCacheInfo.u16CacheF2hTabFreePtr==(gsCacheInfo.u16TotalPgPerF2hTab-1))&&(u16CacheF2hTabFreePtr!=gsCacheInfo.u16CacheF2hTabFreePtr))
        {
            restoreCacheBlockFull();
        }

#if _EN_PCIE_PATH_REC
        mRecPcieErrPath(cErrRollbackF2hPtr);
#endif

        u32pF2h=(LWORD *)(&garCacheF2hTab[((gsCacheInfo.u16CacheF2hTabFreePtr+1)%gsCacheInfo.u16TotalPgPerF2hTab)]);
        gsCacheInfo.u16CacheF2hTabFreePtr=u16CacheF2hTabFreePtr;

        while(u32ProgFifoTail!=gsRwCtrl.u32ProgFifoHead)
        {
            // from head recover F2h to Tail
            uPlaneCnt=g4kNumPerPage;

            u32ProgFifoTail=addWrFfPtrBy1(u32ProgFifoTail);    // here is only for counting number.

            while(uPlaneCnt)
            {
                if(gsRwCtrl.u16MskRptF2hBasePtr)
                {
                    gsRwCtrl.u16MskRptF2hBasePtr--;
                }
                else
                {
                    gsRwCtrl.u16MskRptF2hBasePtr=c16MskRptF2hOfstDpt-1;
                }

                if((u32ProgFifoTail==gsRwCtrl.u32ProgFifoHead)&&(uKeepLast4kCnt>=uPlaneCnt))
                {
                    gsPcieErrInfo.uLastWrKeep4kCnt++;    // debug
                }
                else if(*u32pF2h!=cInvalid32Bit)
                {
                    if(g16arMskRptF2hOfst[gsRwCtrl.u16MskRptF2hBasePtr]!=c16BitFF)
                    {
                        *(LWORD *)(&garCacheF2hTab[g16arMskRptF2hOfst[gsRwCtrl.u16MskRptF2hBasePtr]])=*u32pF2h;
                    }

                    *u32pF2h=cInvalid32Bit;
                }

                uPlaneCnt--;
                u32pF2h++;
            }
        }
    }

    gsPcieErrInfo.u16LastNewCacheF2hTabFreePtr=gsCacheInfo.u16CacheF2hTabFreePtr;
    gsPcieErrInfo.u32LastNewCacheFreePagePtr=gsCacheInfo.u32CacheFreePagePtr;

    gsRwCtrl.u16MskRptF2hBasePtr=0;
    gsRwCtrl.uMaskTgtPtr=0;
    gsRwCtrl.uCachePtr=0;
    gsRwCtrl.uCacheStartSctr=0;
    gsRwCtrl.uCacheEndSctr=cSctrPer4k;
    gsRwCtrl.u16CacheInBuf=0;
    mSetNewDesF;
    // mSetCalWriteSctr2ChgBlk;
    // getWriteSctr2ChgBlk();
    g16WriteBufPtr=g16FlashWBufPtr=c16WriteSIdx;
    gsRwCtrl.ubDelayTrigHost=0;

#if _EN_FW_DEBUG_UART
    NLOG_PCIeErr(cLogPcieErr, FTLPUB_C, 3,
                 " PCIe Wr: F2h=0x%04X, GcTyp=0x%04X, Last4kCnt=0x%04X", gsCacheInfo.uChkF2hRegion, gsGcInfo.uGcTypBit, uKeepLast4kCnt);
#endif
}    /* recovPcieErrW2 */

#endif/* if (_CPUID==0) */

#if (_EN_IOMTRIG&&_EN_VPC_SWAP)
void InitIoMeter()
{
    // NLOG(cLogTempDebug, FTLPUB_C, 0, " InitIoMeter! ");

    gsIomInfo.u32TrigTimer=0;
    gsIomInfo.u8Status=cIoMeterNon;

    gsIomInfo.u32SeqLba=0xFFFFFFFF;
    gsIomInfo.u32SeqLen=0;
    gsIomInfo.u32RanCmdCnt=0;
    gsIomInfo.u32SeqCmdCnt=0;
    gsIomInfo.u8ThrdCnt=0;
    g16MaxSlcBlkQ=cMaxSlcBlkQ;
}

void InitIoMeter1Thr()
{
    // NLOG(cLogTempDebug, FTLPUB_C, 0, " InitIoMeter! ");

    gsIomInfo1Thr.u32TrigTimer=0;
    gsIomInfo1Thr.u8Status=cIoMeterNon;
    gsIomInfo1Thr.u32ReadCmdCnt=0;
    gsIomInfo1Thr.u32SeqLba=0xFFFFFFFF;
    gsIomInfo1Thr.u32SeqLen=0;
    gsIomInfo1Thr.u32RanCmdCnt=0;
    gsIomInfo1Thr.u32SeqCmdCnt=0;
    gsIomInfo1Thr.u8ThrdCnt=0;
    g16MaxSlcBlkQ=cMaxSlcBlkQ;
}

#endif/* if _EN_IOMTRIG */

#if _EN_Lenovo_RecoveryChk
void InitIoMeter_RecoveryChk()
{
    // NLOG(cLogTempDebug, FTLPUB_C, 0, " InitIoMeter_RecoveryChk! ");

    gsIomInfo_RecoveryCheck.u32TrigTimer=0;
    gsIomInfo_RecoveryCheck.u8Status=cIoMeterNon;

    gsIomInfo_RecoveryCheck.u32SeqLen=0;
    gsIomInfo_RecoveryCheck.u32RanCmdCnt=0;
    gsIomInfo_RecoveryCheck.u32SeqCmdCnt=0;
}

#endif

#if (!_ICE_LOAD_ALL)
#pragma default_function_attributes =
#endif







