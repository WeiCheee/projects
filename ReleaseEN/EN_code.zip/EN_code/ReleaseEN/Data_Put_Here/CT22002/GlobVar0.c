







#include "inc/Option.h"
#include "inc/TypeDef.h"
#include "inc/Const.h"
#include "inc/NvmeCtrl.h"
#include "Common/Model.h"

// -----------------Domain0----------------//
#pragma default_variable_attributes = @ ".R8_SysCtrl0"
volatile BYTE rSysCtrl0[0x400];
#pragma default_variable_attributes =

#pragma default_variable_attributes = @ ".R16_SysCtrl0"
volatile WORD r16SysCtrl0[0x200];
#pragma default_variable_attributes =

#pragma default_variable_attributes = @ ".R32_SysCtrl0"
volatile LWORD r32SysCtrl0[0x100];
#pragma default_variable_attributes =

#pragma default_variable_attributes = @ ".R8_EfuseCtrl"
volatile BYTE rEfuseCtrl[0x200];
#pragma default_variable_attributes =

#pragma default_variable_attributes = @ ".R16_EfuseCtrl"
volatile WORD r16EfuseCtrl[0x100];
#pragma default_variable_attributes =

#pragma default_variable_attributes = @ ".R32_EfuseCtrl"
volatile LWORD r32EfuseCtrl[0x80];
#pragma default_variable_attributes =

#pragma default_variable_attributes = @ ".R8_Tsb4Ctrl"
volatile BYTE rTsb4Ctrl[0x100];
#pragma default_variable_attributes =

#pragma default_variable_attributes = @ ".R16_Tsb4Ctrl"
volatile WORD r16Tsb4Ctrl[0x80];
#pragma default_variable_attributes =

#pragma default_variable_attributes = @ ".R32_Tsb4Ctrl"
volatile LWORD r32Tsb4Ctrl[0x40];
#pragma default_variable_attributes =

#pragma default_variable_attributes = @ ".R8_PCIe"
volatile BYTE rPcie[0x2000];
#pragma default_variable_attributes =

#pragma default_variable_attributes = @ ".R16_PCIe"
volatile WORD r16Pcie[0x1000];
#pragma default_variable_attributes =

#pragma default_variable_attributes = @ ".R32_PCIe"
volatile LWORD r32Pcie[0x800];
#pragma default_variable_attributes =

#pragma default_variable_attributes = @ ".R8_NVMe0"
volatile BYTE rNvme0[0x2000];
#pragma default_variable_attributes =

#pragma default_variable_attributes = @ ".R16_NVMe0"
volatile WORD r16Nvme0[0x1000];
#pragma default_variable_attributes =

#pragma default_variable_attributes = @ ".R32_NVMe0"
volatile LWORD r32Nvme0[0x800];
#pragma default_variable_attributes =

// -----------------Domain2----------------//
#pragma default_variable_attributes = @ ".R8_BvacCtrl"
volatile BYTE rBvacCtrl[0x100];
#pragma default_variable_attributes =

#pragma default_variable_attributes = @ ".R16_BvacCtrl"
volatile WORD r16BvacCtrl[0x80];
#pragma default_variable_attributes =

#pragma default_variable_attributes = @ ".R32_BvacCtrl"
volatile LWORD r32BvacCtrl[0x40];
#pragma default_variable_attributes =

#pragma default_variable_attributes = @ ".R8_VIC0"
volatile BYTE rSvic0[0x1000];
#pragma default_variable_attributes =

#pragma default_variable_attributes = @ ".R16_VIC0"
volatile WORD r16Svic0[0x800];
#pragma default_variable_attributes =

#pragma default_variable_attributes = @ ".R32_VIC0"
volatile LWORD r32Svic0[0x400];
#pragma default_variable_attributes =

#pragma default_variable_attributes = @ ".R64_VIC0"
volatile QWORD r64Svic0[0x200];
#pragma default_variable_attributes =

#pragma default_variable_attributes = @ ".R8_VIC1"
volatile BYTE rSvic1[0x1000];
#pragma default_variable_attributes =

#pragma default_variable_attributes = @ ".R16_VIC1"
volatile WORD r16Svic1[0x800];
#pragma default_variable_attributes =

#pragma default_variable_attributes = @ ".R32_VIC1"
volatile LWORD r32Svic1[0x400];
#pragma default_variable_attributes =

#pragma default_variable_attributes = @ ".R64_VIC1"
volatile QWORD r64Svic1[0x200];
#pragma default_variable_attributes =

#pragma default_variable_attributes = @ ".R8_AUX"
volatile BYTE rAux[0x1000];
#pragma default_variable_attributes =

#pragma default_variable_attributes = @ ".R16_AUX"
volatile WORD r16Aux[0x800];
#pragma default_variable_attributes =

#pragma default_variable_attributes = @ ".R32_AUX"
volatile LWORD r32Aux[0x400];
#pragma default_variable_attributes =

#pragma default_variable_attributes = @ ".R8_COH"
volatile BYTE rCoh[0x1000];
#pragma default_variable_attributes =

#pragma default_variable_attributes = @ ".R16_COH"
volatile WORD r16Coh[0x800];
#pragma default_variable_attributes =

#pragma default_variable_attributes = @ ".R32_COH"
volatile LWORD r32Coh[0x400];
#pragma default_variable_attributes =

#pragma default_variable_attributes = @ ".R8_DramCtrl"
volatile BYTE rDramCtrl[0x2000];
#pragma default_variable_attributes =

#pragma default_variable_attributes = @ ".R16_DramCtrl"
volatile WORD r16DramCtrl[0x1000];
#pragma default_variable_attributes =

#pragma default_variable_attributes = @ ".R32_DramCtrl"
volatile LWORD r32DramCtrl[0x800];
#pragma default_variable_attributes =

#pragma default_variable_attributes = @ ".APB_REG"
volatile BYTE rAPB[0x100000];
#pragma default_variable_attributes =

// -----------------Domain1----------------//
#pragma default_variable_attributes = @ ".R8_SysCtrl1"
volatile BYTE rSysCtrl1[0x100];
#pragma default_variable_attributes =

#pragma default_variable_attributes = @ ".R16_SysCtrl1"
volatile WORD r16SysCtrl1[0x80];
#pragma default_variable_attributes =

#pragma default_variable_attributes = @ ".R32_SysCtrl1"
volatile LWORD r32SysCtrl1[0x40];
#pragma default_variable_attributes =

#pragma default_variable_attributes = @ ".R8_BvaCtrl"
volatile BYTE rBvaCtrl[0x100];
#pragma default_variable_attributes =

#pragma default_variable_attributes = @ ".R16_BvaCtrl"
volatile WORD r16BvaCtrl[0x80];
#pragma default_variable_attributes =

#pragma default_variable_attributes = @ ".R32_BvaCtrl"
volatile LWORD r32BvaCtrl[0x40];
#pragma default_variable_attributes =

#pragma default_variable_attributes = @ ".R8_RsaCtrl"
volatile BYTE rRsaCtrl[0x200];
#pragma default_variable_attributes =

#pragma default_variable_attributes = @ ".R16_RsaCtrl"
volatile WORD r16RsaCtrl[0x100];
#pragma default_variable_attributes =

#pragma default_variable_attributes = @ ".R32_RsaCtrl"
volatile LWORD r32RsaCtrl[0x80];
#pragma default_variable_attributes =

#pragma default_variable_attributes = @ ".R8_I2cCtrl"
volatile BYTE rI2cCtrl[0x40];
#pragma default_variable_attributes =

#pragma default_variable_attributes = @ ".R16_I2cCtrl"
volatile WORD r16I2cCtrl[0x20];
#pragma default_variable_attributes =

#pragma default_variable_attributes = @ ".R32_I2cCtrl"
volatile LWORD r32I2cCtrl[0x10];
#pragma default_variable_attributes =

#pragma default_variable_attributes = @ ".R8_TsbCtrl"
volatile BYTE rTsbCtrl[0x800];
#pragma default_variable_attributes =

#pragma default_variable_attributes = @ ".R16_TsbCtrl"
volatile WORD r16TsbCtrl[0x400];
#pragma default_variable_attributes =

#pragma default_variable_attributes = @ ".R32_TsbCtrl"
volatile LWORD r32TsbCtrl[0x200];
#pragma default_variable_attributes =

#pragma default_variable_attributes = @ ".R8_ShaCtrl"
volatile BYTE rShaCtrl[0x80];
#pragma default_variable_attributes =

#pragma default_variable_attributes = @ ".R16_ShaCtrl"
volatile WORD r16ShaCtrl[0x40];
#pragma default_variable_attributes =

#pragma default_variable_attributes = @ ".R32_ShaCtrl"
volatile LWORD r32ShaCtrl[0x20];
#pragma default_variable_attributes =

#pragma default_variable_attributes = @ ".R8_TrngCtrl"
volatile BYTE rTrngCtrl[0x100];
#pragma default_variable_attributes =

#pragma default_variable_attributes = @ ".R16_TrngCtrl"
volatile WORD r16TrngCtrl[0x80];
#pragma default_variable_attributes =

#pragma default_variable_attributes = @ ".R32_TrngCtrl"
volatile LWORD r32TrngCtrl[0x40];
#pragma default_variable_attributes =

#pragma default_variable_attributes = @ ".R8_UartCtrl"
volatile BYTE rUartCtrl[0x100];
#pragma default_variable_attributes =

#pragma default_variable_attributes = @ ".R16_UartCtrl"
volatile WORD r16UartCtrl[0x80];
#pragma default_variable_attributes =

#pragma default_variable_attributes = @ ".R32_UartCtrl"
volatile LWORD r32UartCtrl[0x40];
#pragma default_variable_attributes =

#pragma default_variable_attributes = @ ".R8_EccDec"
volatile BYTE rEccDec[0x100];
#pragma default_variable_attributes =

#pragma default_variable_attributes = @ ".R16_EccDec"
volatile WORD r16EccDec[0x80];
#pragma default_variable_attributes =

#pragma default_variable_attributes = @ ".R32_EccDec"
volatile LWORD r32EccDec[0x40];
#pragma default_variable_attributes =

#pragma default_variable_attributes = @ ".R8_NBS"
volatile BYTE rNbs[0x200];
#pragma default_variable_attributes =

#pragma default_variable_attributes = @ ".R16_NBS"
volatile WORD r16Nbs[0x100];
#pragma default_variable_attributes =

#pragma default_variable_attributes = @ ".R32_NBS"
volatile LWORD r32Nbs[0x80];
#pragma default_variable_attributes =

#pragma default_variable_attributes = @ ".R8_BopCtrl"
volatile BYTE rBopCtrl[0x200];
#pragma default_variable_attributes =

#pragma default_variable_attributes = @ ".R16_BopCtrl"
volatile WORD r16BopCtrl[0x100];
#pragma default_variable_attributes =

#pragma default_variable_attributes = @ ".R32_BopCtrl"
volatile LWORD r32BopCtrl[0x80];
#pragma default_variable_attributes =

#pragma default_variable_attributes = @ ".R8_HdmaCtrl"
volatile BYTE rHdmaCtrl[0x200];
#pragma default_variable_attributes =

#pragma default_variable_attributes = @ ".R16_HdmaCtrl"
volatile WORD r16HdmaCtrl[0x100];
#pragma default_variable_attributes =

#pragma default_variable_attributes = @ ".R32_HdmaCtrl"
volatile LWORD r32HdmaCtrl[0x80];
#pragma default_variable_attributes =

#pragma default_variable_attributes = @ ".R8_LbaChk"
volatile BYTE rLbaChk[0x100];
#pragma default_variable_attributes =

#pragma default_variable_attributes = @ ".R16_LbaChk"
volatile WORD r16LbaChk[0x80];
#pragma default_variable_attributes =

#pragma default_variable_attributes = @ ".R32_LbaChk"
volatile LWORD r32LbaChk[0x40];
#pragma default_variable_attributes =

#pragma default_variable_attributes = @ ".R8_AesCtrl"
volatile BYTE rAesCtrl[0x800];
#pragma default_variable_attributes =

#pragma default_variable_attributes = @ ".R16_AesCtrl"
volatile WORD r16AesCtrl[0x400];
#pragma default_variable_attributes =

#pragma default_variable_attributes = @ ".R32_AesCtrl"
volatile LWORD r32AesCtrl[0x200];
#pragma default_variable_attributes =

#pragma default_variable_attributes = @ ".R8_SkipRam"
volatile BYTE rSkipRam[0x1000];
#pragma default_variable_attributes =

#pragma default_variable_attributes = @ ".R16_SkipRam"
volatile WORD r16SkipRam[0x800];
#pragma default_variable_attributes =

#pragma default_variable_attributes = @ ".R32_SkipRam"
volatile LWORD r32SkipRam[0x400];
#pragma default_variable_attributes =

#pragma default_variable_attributes = @ ".R8_FwAes"
volatile BYTE rFwAes[0x800];
#pragma default_variable_attributes =

#pragma default_variable_attributes = @ ".R16_FwAes"
volatile WORD r16FwAes[0x400];
#pragma default_variable_attributes =

#pragma default_variable_attributes = @ ".R32_FwAes"
volatile LWORD r32FwAes[0x200];
#pragma default_variable_attributes =

#pragma default_variable_attributes = @ ".R8_FakeCtrl"
volatile BYTE rFakeCtrl[0x1000];
#pragma default_variable_attributes =

#pragma default_variable_attributes = @ ".R16_FakeCtrl"
volatile WORD r16FakeCtrl[0x800];
#pragma default_variable_attributes =

#pragma default_variable_attributes = @ ".R32_FakeCtrl"
volatile LWORD r32FakeCtrl[0x400];
#pragma default_variable_attributes =

#pragma default_variable_attributes = @ ".R8_BvfORam"
volatile BYTE rBvfORam[0x4000];
#pragma default_variable_attributes =

#pragma default_variable_attributes = @ ".R16_BvfORam"
volatile WORD r16BvfORam[0x2000];
#pragma default_variable_attributes =

#pragma default_variable_attributes = @ ".R32_BvfORam"
volatile LWORD r32BvfORam[0x1000];
#pragma default_variable_attributes =

#pragma default_variable_attributes = @ ".R8_BvfBRam"
volatile BYTE rBvfBRam[0x4000];
#pragma default_variable_attributes =

#pragma default_variable_attributes = @ ".R16_BvfBRam"
volatile WORD r16BvfBRam[0x2000];
#pragma default_variable_attributes =

#pragma default_variable_attributes = @ ".R32_BvfBRam"
volatile LWORD r32BvfBRam[0x1000];
#pragma default_variable_attributes =

#pragma default_variable_attributes = @ ".R8_NVMe1"
volatile BYTE rNvme1[0x2800];
#pragma default_variable_attributes =

#pragma default_variable_attributes = @ ".R16_NVMe1"
volatile WORD r16Nvme1[0x1400];
#pragma default_variable_attributes =

#pragma default_variable_attributes = @ ".R32_NVMe1"
volatile LWORD r32Nvme1[0xA00];
#pragma default_variable_attributes =

#pragma default_variable_attributes = @ ".R8_NVMePrd"
volatile BYTE rNvmePrd[64][32];
#pragma default_variable_attributes =

#pragma default_variable_attributes = @ ".R16_NVMePrd"
volatile WORD r16NvmePrd[64][16];
#pragma default_variable_attributes =

#pragma default_variable_attributes = @ ".R32_NVMePrd"
volatile LWORD r32NvmePrd[64][8];
#pragma default_variable_attributes =

#pragma default_variable_attributes = @ ".R8_NVMeDesc"
volatile BYTE rNvmeDesc[64][32];
#pragma default_variable_attributes =

#pragma default_variable_attributes = @ ".R16_NVMeDesc"
volatile WORD r16NvmeDesc[64][16];
#pragma default_variable_attributes =

#pragma default_variable_attributes = @ ".R32_NVMeDesc"
volatile LWORD r32NvmeDesc[64][8];
#pragma default_variable_attributes =

#pragma default_variable_attributes = @ ".R8_NVMeHMB"
volatile BYTE rNvmeHmb[0xC000];
#pragma default_variable_attributes =

#pragma default_variable_attributes = @ ".R16_NVMeHMB"
volatile WORD r16NvmeHmb[0x6000];
#pragma default_variable_attributes =

#pragma default_variable_attributes = @ ".R32_NVMeHMB"
volatile LWORD r32NvmeHmb[0x3000];
#pragma default_variable_attributes =

#pragma default_variable_attributes = @ ".R8_FSHA"
volatile BYTE rFSHA[9][0x2000];
#pragma default_variable_attributes =

#pragma default_variable_attributes = @ ".R16_FSHA"
volatile WORD r16FSHA[9][0x1000];
#pragma default_variable_attributes =

#pragma default_variable_attributes = @ ".R32_FSHA"
volatile LWORD r32FSHA[9][0x800];
#pragma default_variable_attributes =

#pragma default_variable_attributes = @ ".R8_LDPcDsp"
volatile BYTE rLdpcDspCtrl[0x100000];
#pragma default_variable_attributes =

#pragma default_variable_attributes = @ ".R16_LDPcDsp"
volatile WORD r16LdpcDspCtrl[0x80000];
#pragma default_variable_attributes =

#pragma default_variable_attributes = @ ".R32_LDPcDsp"
volatile LWORD r32LdpcDspCtrl[0x40000];
#pragma default_variable_attributes =

#pragma default_variable_attributes = @ ".R8_LDPcDec"
volatile BYTE rLdpcDec[0x20000];
#pragma default_variable_attributes =

#pragma default_variable_attributes = @ ".R16_LDPcDec"
volatile WORD r16LdpcDec[0x10000];
#pragma default_variable_attributes =

#pragma default_variable_attributes = @ ".R32_LDPcDec"
volatile LWORD r32LdpcDec[0x8000];
#pragma default_variable_attributes =

// *********** For PS4 backup used ****************

MPINFO gsMPInfo @cGsMpInfoAddr;    // size: 0x60
ERRORINFO garErrorLog[cMaxErrLogEntryCnt]   @cGarErrorLogAddr;    // size: 0x1000
SMARTATTRIBUTE gsSmart @cGsSmartAddr;    // size: 0x48
POWERSTATE gsPowerState @cGsPowerStateAddr;    // size: 0x18
APSTTABLE garApstCurrent[4] @cGarApstCurrtentAddr;    // size: 0x20
NVMEAERSTR gsNvmeAer @cGsNvmeAer;
LWORD g32ApstEnable @cGps4ValAddr+0x00;
LWORD g32RtcStartTime1s @cGps4ValAddr+0x04;
BYTE gSupportL12 @cGps4ValAddr+0x08;
BYTE gMt1In @cGps4ValAddr+0x09;
BYTE gMt2In @cGps4ValAddr+0x0A;
BYTE gMt3In @cGps4ValAddr+0x0B;
BYTE gMtSdIn @cGps4ValAddr+0x0C;
BYTE gMt1Out @cGps4ValAddr+0x0D;
BYTE gMt2Out @cGps4ValAddr+0x0E;
BYTE gMt3Out @cGps4ValAddr+0x0F;
BYTE gAsicMt3In @cGps4ValAddr+0x10;
BYTE gAsicMtSdIn @cGps4ValAddr+0x11;
BYTE gAsicMt1Out @cGps4ValAddr+0x12;
BYTE gBgdGCWakeUp @ cGps4ValAddr+0x13;
LWORD g32IdleGcDelayTime @ cGps4ValAddr+0x14;

// 20181210_SamHu_01
WORD g16ValidSqBitmap @ cGps4ValAddr+0x18;
WORD g16ValidCqBitmap @ cGps4ValAddr+0x1A;
WORD g16Cq2SqidBitmap[cMaxIoSqCqCnt] @ cGps4ValAddr+0x1C;
BYTE gbsNvmeOpt1 @ cGps4ValAddr+0x2C;
BYTE gMasterState @ cGps4ValAddr+0x2D;
BYTE gXadmldle @ cGps4ValAddr+0x2E;
#if _EN_Delay_Dis_LTSSM
BYTE gGCRestFlg @ cGps4ValAddr+0x2F;
BYTE IORestFlg @ cGps4ValAddr+0x30;
#endif

#pragma default_variable_attributes = @ ".CORE0_NVME_VAR"

// =============================================PCIe/NVMe/System USE
volatile BYTE gLtssmIntr0;
volatile BYTE gLtssmIntr1;
volatile BYTE gLtssmIntr2;

// volatile BYTE gLastInt;

QWORD g64LastTime;
// NVMe Get Log Page Cmd
LWORD g32ErrorCountL;
LWORD g32ErrorCountH;
INVALIDDBINFO gsInvalidDbInfo;
BYTE gErrLogPtr;
LWORD g32GrtPeCycle;

// NVMe Abort cmd
// BYTE gAbortCnt;
// ABORTQUEUE garAbortInfo[cMaxAbortCnt];

// BYTE garAvailableAbortSlot[cMaxAbortCnt];
// BYTE garBusyAbortSlot[cMaxAbortCnt];

// BYTE gAvailableAbortHead;
// BYTE gAvailableAbortTail;
// BYTE gAvailableAbortCnt;

// LWORD g32PowerOnDphy7Cnt;
LWORD g32HostTotalDataSectorCnt;    // logic range host can access
// LWORD g32arLbaSectors[cMaxPartition];

// Host Memory Buffer  //move to Wpro
// LWORD g32HmbSize;
// LWORD g32HmbDescListAddrLow;
// LWORD g32HmbDescListAddrHigh;
// LWORD g32HmbDescListEntryCnt;
// LWORD g32HmbDescEntryAddrLow;
// LWORD g32HmbDescEntryAddrHigh;
// LWORD g32HmbDescEntrySize;

LWORD g32MaxDataXfrSec;

BYTE gLpbkSt;

// BYTE garSerialNumber[20];
// BYTE garModelNumber[40];

// BYTE gFuaWrSta;
// BYTE gWritePrdCnt;

BYTE gbsCrlcBit;

// BYTE gHandlePcieRstInIsr;
BYTE gHostJustL1En;
BYTE gHostNoSetLtrEn;
BYTE gLtrEnabled;
BYTE gChgtoD0;
BYTE gL1TimeOutEnabled;
// BYTE gChkPerstF;

LWORD g32IntSrc;

// volatile BYTE garDbgTrace[32];

// void (*dbPatch)(void);

LWORD g32LtrValue0;
LWORD g32LtrValue2;

// WORD g16ValidSqBitmap;
// WORD g16ValidCqBitmap;
// WORD g16Cq2SqidBitmap[cMaxIoSqCqCnt];

LWORD gar32BkMsixTab[64];

BYTE gUART_RxTrigger;    // gUartRxTrig  for security crypto library.

BYTE gDdrValue;
BYTE gGpio0PuBk;
BYTE gGpio0PdBk;
BYTE gGpio1PuBk;
BYTE gGpio1PdBk;
BYTE gGpio2PuBk;
BYTE gGpio2PdBk;

WORD g16SysClkPll;
BYTE gFlashAutoGate;
BYTE gDdrValue;
// BYTE gFlashPdTimer;  //unless
// LWORD g32BackgroundTime;
// LWORD g32PsStepDebug;  //for debug trace
// BYTE gLastInt;  //for debug trace

SANITIZE gsSanitizeInfo;

// =============================================Power Management and APST use
volatile LWORD g32PsStepDebug;
BYTE gLowPowerStateRetryCnt;
BYTE gApstRetryCnt;
BYTE gApstPs3ToPs4;
BYTE gApstOngoing;
BYTE gApstOperationToPs3;

BYTE gMsixTableFlag;
BYTE gLaneNumAcceptTimeoutCnt;

// BYTE gChkTemperature;
// BYTE gIdleThermalLogCnt;

WORD g16Code85;
WORD g16Code30;

#if APST_Timer
LWORD g32APSTTimeGap;    // 20190604_LeverYu_APST timing
#endif

LWORD g32ThermalMT1TransitionCount;
LWORD g32ThermalMT2TransitionCount;
LWORD g32ThermalMT3TransitionCount;
LWORD g32AsicThermalMT3TransitionCount;

BYTE gThermalThrottlingReason;

BYTE gThsor0Temperature;
// BYTE gThsor0TemperatureBk;
BYTE gThsor1Temperature;
BYTE gThermalOffset;

// BYTE gDebugStandbyMoF;
DEBUGINFO gsDebugInfo;

// BYTE gkeepSerialModelNumFlag;
BYTE gFwResetCpuForSec;    // FW Commit to Trig ResetCPU
BYTE gHashOffsetBk[32];

// =============================================Device Selt-Test
// NVMEDSTLOG gsNvmeDst;
DSTRESULT gsCurrDstResult;
// LWORD g32NvmeDstStartTimeMs;  //Move to Wpro

// =============================================System USE
LWORD g32arRWTickCnt[8];
LWORD g32RtcStartTimeMs;
LWORD g32RtcStartTime2s;
LWORD g32RtcStandbyEntryTime;
LWORD g32RtcStandbyExitTime;
LWORD g32RtcStandbyEntryTimeBk;
LWORD g32RtcStandbyExitTimeBk;
LWORD g32BackgroundTimeMs;
LWORD g32SleepStartTime1s;
BYTE gSensorPollingInterval;
BYTE gChkTemperature;
BYTE gCpu0TOFlag;
// BYTE gSysTmrOn;
BYTE gRWTickCntPtr;
BYTE gSmartBackup;

// ============================================Security
#if 1    // _ENABLE_SECAPI
// --- Not only used in Security (from ".SecurityAPI_Var_BaseFW") ---//
// =====Need to be initialized for Power-cycle and DevSlp=======
BYTE gMBRShadow;
BYTE gLockingStatus;
BYTE gTcgNviSpLockingLifeCycleState;
BYTE gMbrRangeHit;
BYTE gMbrReturnZero;
BYTE gMbrRedirectPassAes;
BYTE gMbrDummyReturn;
LWORD g32SessionTimerStart;
LWORD g32MaxSessionTimeout;

// =====Don't need to be initialized for Power-cycle and DevSlp=======
LWORD g32ReceivedXfrByte;
LWORD g32ReceivedXfrCnt;
// ------------------------------------------------------//

WORD g16SecTrimPtr;
// LWORD g32SecTrimLba[16];
// LWORD g32SecTrimXfrCnt[16];

// --- Not only used in Security (from ".SecurityVar") ---//
/* Used in MemoryAllocate() */
LWORD g16TempRamPtr;
LWORD g16TempRamStackPtr;
// --------------------------------------------//
WORD g16BackupWriteBufPtr;

LWORD g32TempBufFlag[24];    // 384KB / 4KB (1B flag means 4KB)

#endif/* if _ENABLE_SECAPI */

PCIEERRLOGINFO gsPcieErrInfo;
#if (_EN_PERST_WAKEINLOWPOWER)
BYTE gHandlePerstInIsrForLowPower;
#endif
#pragma default_variable_attributes =

#pragma default_variable_attributes = @ ".CORE0_LS_VAR"    // LightSwitch 384K
LIGHTSWITCH gsLightSwitch;
#pragma default_variable_attributes =

#pragma default_variable_attributes = @ ".CORE0_FL_VAR"
LWORD g32ISPBlockSerial[4];
// =============================================FTL/CTL USE
volatile BYTE *rFLCtrl;
volatile WORD *r16FLCtrl;
volatile LWORD *r32FLCtrl;

volatile BYTE *rLdpcDsp;    // 0x51200000
volatile WORD *r16LdpcDsp;
volatile LWORD *r32LdpcDsp;

// LWORD gCPUCycleCnt[23];
ADDRINFO *gpFlashAddrInfo;
HADDRINFO gsWriteHAddrInfo;
HADDRINFO gsReadHAddrInfo[cPrdDepth];
HMBINFO gsHmbInfo;
// F2HINFO garDesF2hInfo[cWriteFifoDpt];

HADDRINFO *gpHostAddrInfo;

WORD g16WriteBufPtr;
WORD g16FlashWBufPtr;

// WORD g16NowH2fTabFAddr;
// LWORD g32NowSrcFAddr;

LWORD g32SectorPerHBlock;
// LWORD g32SectorPerFBlock;
LWORD g32MaxCachePageNum;
// BYTE gReadDummySrc;
// BYTE gChgBlock;

LWORD g32LastLbaW;
LWORD g32LastLbaR;
// BYTE gbSeqAccess;
// BYTE gbChgBlock;
// BYTE gbCacheInBuf;
BYTE gLastTrigPrdTaskType;
WORD g16SrchSrcTabFreePtr;
// _Uncached H2FTABLE garSrchSrcTab[cMaxQDept*4];//512b
UCLWORD garSrchSrcTab[cSrchSrcNum];    // 1KB
UCLWORD g32arSrcInCacheFlag[c16MaxH2fTabNum/32];    // 1kb

BYTE garH2f1kTabSgmtExpire[cMaxRH2fTabNum];    // 32b
// BYTE garH2f1kTabSgmtIdx[cMaxRH2fTabNum];    // 32b
// LWORD g32arH2f1kTabSgmt[cMaxRH2fTabNum];    // 128b

// WORD g16FakeCmdPtr;

// LWORD g32DramWrPtr;
// LWORD g32DramRdF2hHitPtr;

// WORD g16DRAMPLL;

// LWORD g32TempCachePtr;
BYTE gReadFlag;
BYTE gActiveCe;

// WORD g16arCurrSysBlkEsCnt[cRsvSysBlkNum];    // current system block erased count
WORD g16TotalPlaneOfISP[4];
// WORD g16DgFifoFullCnt;
// WORD g16IdxBlkFreePagePtr;

// flashprogpage use, should in share

// RAID related
WORD g16GcDesF2hPadStartAddr;
WORD g16PadF2hTabPgStr;
WORD g16PadF2hTabPgEnd;
WORD g16ProgF2hTabStr;
WORD g16ProgF2hTabEnd;
WORD g16SlcPadF2hTabPgStr;
WORD g16SlcPadF2hTabPgEnd;
WORD g16SlcProgF2hTabStr;
WORD g16SlcProgF2hTabEnd;
WORD g16ChkFlushSize;
WORD g16FlushStr4K;
WORD g16FlushRem4K;
WORD g16FlushChkStart;
WORD g16SlcF2hChkStart;
WORD g16SlcF2hChkSize;
WORD g16TlcF2hChkStart;
WORD g16TlcF2hChkSize;
WORD g16TlcProgRaidChStr4K;
WORD g16SlcProgRaidChStr4K;
WORD g16ProgRaidUnit;
WORD g16Raid4KStrInPage;
WORD g16PartialRaidUnit;
// LWORD* g32arGlobEraseCnt; //2kb

BYTE gSlc4KNumToPadF2h;
BYTE gSlcProgF2HRem4KNum;
BYTE gTlc4KNumToPadF2h;
BYTE gTlcProgF2HRem4KNum;
BYTE gFWShnFlag;
LWORD g32BgdGCSkipResetCnt;
// BYTE gRsvCacheF2h;
// WORD g16F2hTabHitPtr;

WORD g16WriteHMBH2FTable[cHmbRacingFreeCnt];
BYTE gWriteHMBIndex;
BYTE gSecuEfuse[128];
// WORD g16GCOneShot4kCnt;
// BYTE gGc4kNumPerMaxProgUnit;
LWORD g32arHmbTabDirty[c16HmbMaxTableNumAlign/32];    // if set 1, mean the H2f tab on HMB is modified and not sync to NAND flash

SORTF2HTAB *gpSortF2hTab;
WORD g16VPCTrimStartIdx;

BYTE gOpRomRead;
WORD g16arMskRptF2hOfst[c16MskRptF2hOfstDpt];
volatile PS4BACKUP *gpBkPS4Data;

LWORD *gp32WriteRangeStart;    // 9 elements
LWORD *gp32WriteRangeEnd;    // 9 elements
LWORD *gp32ReadRangeStart;    // 9 elements
LWORD *gp32ReadRangeEnd;    // 9 elements
BYTE *gpMBRValidBitMap;    // 4416 elements

LWORD g32arWriteRangeStart[9];    // 9 elements
LWORD g32arWriteRangeEnd[9];    // 9 elements
LWORD g32arReadRangeStart[9];    // 9 elements
LWORD g32arReadRangeEnd[9];    // 9 elements
BYTE garMBRValidBitMap[4416];    // 4416 elements
#if _EN_WUNCTable    // WUNCTable Chief_21081121
WUNCInfo gsWUNCInfo;
#endif
#if _EN_WriteZeroNonAlign    // WUNCTable Chief_21081121
WZNonAlginInfo gsWZInfo[C_MaxNonAlginCnt];
WORD gsWZCnt;
#endif
LWORD g32BaseFwShaTotalSize;    // 20181226_SamHu_01 sync Dennis code for R/W command insert DownloadFW
#if _EN_FWCommit_Protect
BYTE gJustReturnPass;
#endif
BYTE gDLFWFail;
#if (OEM==LENOVO)    // 20190108_SamHu_01 add for Lenovo 1.26 Spec Log DFh
BYTE garLenovoLogDFhSN[30];
BYTE garLenovoLogDFhNewSN[30];
#endif
BYTE i2cSetPS4CoreIndex[2];    // 2019_0315 LeverYu CorePower Learning
#if _EN_CmdDelayBGC
LWORD g32CmdNoGC1s;
#endif
#pragma default_variable_attributes =







