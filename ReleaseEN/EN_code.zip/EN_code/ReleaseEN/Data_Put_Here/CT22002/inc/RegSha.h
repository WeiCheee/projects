







#ifndef __REG_SHA_H__
#define __REG_SHA_H__

// SHA register
#define rcShaContrl                              0x00
#define rmShaReset                               (r32ShaCtrl[rcShaContrl]|=c32Bit0)
#define rmShaStart                               (r32ShaCtrl[rcShaContrl]|=c32Bit1)
#define rmShaBusy                                (r32ShaCtrl[rcShaContrl]&c32Bit7)

#define rmHashHiEndian                           (r32ShaCtrl[rcShaContrl]|=c32Bit8)
#define rmHashLoEndian                           (r32ShaCtrl[rcShaContrl]&=(~c32Bit8))

#define rcShaHash0                               0x20
#define rcShaHash1                               0x24
#define rcShaHash2                               0x28
#define rcShaHash3                               0x2C
#define rcShaHash4                               0x30
#define rcShaHash5                               0x34
#define rcShaHash6                               0x38
#define rcShaHash7                               0x3C

#define rcShaData0                               0x40
#define rcShaData1                               0x44
#define rcShaData2                               0x48
#define rcShaData3                               0x4C
#define rcShaData4                               0x50
#define rcShaData5                               0x54
#define rcShaData6                               0x58
#define rcShaData7                               0x5C
#define rcShaData8                               0x60
#define rcShaData9                               0x64
#define rcShaDataA                               0x68
#define rcShaDataB                               0x6C
#define rcShaDataC                               0x70
#define rcShaDataD                               0x74
#define rcShaDataE                               0x78
#define rcShaDataF                               0x7C

#endif    // ifndef __REG_SHA_H__







