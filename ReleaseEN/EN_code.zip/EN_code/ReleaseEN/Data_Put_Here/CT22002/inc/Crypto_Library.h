







#ifndef __CRYPTO_LIBRARY_H__
#define __CRYPTO_LIBRARY_H__

// 20181226_SamHu_01 sync Dennis code for R/W command insert DownloadFW
#pragma default_variable_attributes = @ ".CryptoLibraryVar2"    // exist in SHIMMPISP, MPISP and ISP
#pragma data_alignment=16
extern BYTE garSHABuffer[1024+64];
extern LWORD g32SHATotalSize;
extern BYTE gShimMPISP;
#pragma default_variable_attributes =

typedef enum
{
    CRYPTO_SUCCESS,
    CRYPTO_ERROR
}cryptoStatus_e;

extern CBYTE T_CRYP_LIB_VERSION[16];

extern void Init_CryptoLib(BYTE u8mode);
extern BYTE Src2BVCI(LWORD Src_Addr);
extern void SHA_Encryption_DMA_Sub(BYTE *SrcPtr, LWORD u32Size, BYTE *DesPtr, BYTE u8Mode);
extern void SHA_Encryption_DMA(BYTE *SrcPtr, LWORD u32Size, BYTE *DesPtr, BYTE u8Mode);
extern void HMAC_DMA(BYTE *KeyPtr, BYTE KeyInLength, BYTE *DataOutPtr, BYTE *DataInPtr, LWORD DataInLength);
extern void KDF_Counter_Mode(BYTE *upInputKey,
                             BYTE u8InputKeylength,
                             BYTE *upLabel,
                             LWORD u32LabelLength,
                             BYTE *upContext,
                             LWORD u32ContextLength,
                             BYTE *upOutputString,
                             LWORD u32OutputLength,
                             LWORD MemoryAddr,
                             BYTE uMemoryInitial);
extern void PBKDF(BYTE *upInputPassword,
                  BYTE u8InputPasswordLength,
                  BYTE *upSalt,
                  BYTE u8SaltLength,
                  LWORD u32IterationCount,
                  BYTE *upOutputString,
                  LWORD u32OutputLength,
                  LWORD MemoryAddr,
                  BYTE uMemoryInitial);
extern void KeyWraping_W(BYTE *upInputKey,
                         BYTE u8InputKeylength,
                         BYTE *upInputString,
                         BYTE u8InputStringLength,
                         BYTE *upOutputString,
                         LWORD MemoryAddr);
extern void KeyWraping_W_Inverse(BYTE *upInputKey,
                                 BYTE u8InputKeylength,
                                 BYTE *upInputString,
                                 BYTE u8InputStringLength,
                                 BYTE *upOutputString,
                                 LWORD MemoryAddr);
extern void KeyWraping_AE(BYTE *upInputKey,
                          BYTE u8InputKeylength,
                          BYTE *upInputString,
                          BYTE u8InputStringLength,
                          BYTE *upOutputString,
                          LWORD MemoryAddr);
extern BYTE KeyWraping_AD(BYTE *upInputKey,
                          BYTE u8InputKeylength,
                          BYTE *upInputString,
                          BYTE u8InputStringLength,
                          BYTE *upOutputString,
                          LWORD MemoryAddr);
extern BYTE adaptive_proportion_test(BYTE *upBuffer, LWORD u32length);
extern BYTE repetition_count_test(BYTE *upBuffer, LWORD u32length);
extern BYTE GetNoise(LWORD *up32Buffer, LWORD u32length);
extern BYTE GetEntropy(LWORD *up32Buffer, LWORD u32length);
extern BYTE GetEntropyInput(BYTE mode);
extern BYTE HDRBG_Hash_df(BYTE *INPUT_STRING, LWORD INPUT_LENGTH, LWORD No_of_bits_to_return, BYTE *OUTPUT_STRING);
extern BYTE HDRBG_Instantiate_Algorithm(BYTE *INPUT_STRING, WORD INPUT_LENGTH);
extern BYTE HDRBG_Instantiate(WORD REQ_INST_SEC_STRENGTH, BYTE *ENTROPY_INPUT, WORD ENTOPY_LENGTH);
extern BYTE HDRBG_Reseed_Algorithm(BYTE *INPUT_STRING, WORD INPUT_LENGTH);
extern BYTE HDRBG_Reseed(BYTE *INPUT_STRING, WORD INPUT_LENGTH);
extern BYTE HDRBG_HashGen(LWORD REQ_NO_OF_BITS, BYTE *INTPUT_STRING, WORD INPUT_LENGTH, BYTE *OUTPUT_STRING);
extern BYTE HDRBG_Generate_Algorithm(LWORD REQ_NO_OF_BITS, BYTE *OUTPUT_STRING);
extern BYTE HDRBG_Generate(LWORD REQ_NO_OF_BITS, BYTE *INPUT_STRING, WORD INPUT_LENGTH, BYTE *OUTPUT_STRING, BYTE PREDICTIONRESISTANCE_REQUEST);
extern BYTE HDRBG_Uninstantiate();
extern void TranslateToRegister(LWORD *u32InputPtr, LWORD men_addr, WORD u16Length);
extern void StoreToMemory(LWORD *u32OutputPtr, LWORD men_addr, WORD u16Length);
extern void module_mm(LWORD DI0_addr, LWORD DI1_addr, LWORD DI2_addr, LWORD ANS_addr, LWORD LEN);
extern void module_rdmod(LWORD DI0_addr0, LWORD DI0_addr1, LWORD DI1_addr, LWORD R_addr, LWORD LEN);
extern void module_pow2(LWORD DI0_addr, LWORD ANS_addr0, LWORD ANS_addr1, LWORD LEN);
extern void module_ClearPara(LWORD Para_addr, LWORD LEN);
extern void module_ClearAllMemory();
extern void module_CopyMemory(LWORD Source_addr, LWORD Des_addr, LWORD LEN);
extern LWORD mm_rr_mod_n(BYTE *N, BYTE *R2, LWORD LEN);
extern LWORD mm_pow_0x10001_mod_n(BYTE *A, BYTE *N, BYTE *R2, BYTE *ANS, LWORD LEN);
extern LWORD rsa_ssa_verify(BYTE *public_key_n, BYTE *result_idx, BYTE *signature_idx);
extern BYTE CompareSignature(BYTE *SHA, BYTE *RSA, BYTE Len);
extern cryptoStatus_e Crypto_GenerateNDRBG(BYTE *pBuffer, LWORD length);
extern cryptoStatus_e Crypto_GenerateDRBG(BYTE *pBuffer, LWORD length, BYTE predictionResistance);
extern cryptoStatus_e Crypto_ReSeedDRBG(BYTE *pSeed, LWORD length);
extern cryptoStatus_e Crypto_InstantiateDRBG(BYTE *pNonce, LWORD nonceLen, BYTE *pSeed, LWORD seedLen);

#endif    // ifndef __CRYPTO_LIBRARY_H__







