







#define _En_OnesCnt 0
#define _IM_3D_MLC 0

#define gSnglPlaneCmdThr                         garCmdFifoDpt[0]
#define gHalfCmdThr                              garCmdFifoDpt[1]
#define gFullCmdThr                              garCmdFifoDpt[2]

#define cMaxSlcMtPageCnt                         1
#define c16MaxErrBlkNum                          32
#define cMaxRebuRertryCnt                        3
#define c16RdlinkLogSize                         1024

#define mGetMetaBlockId(x)                       x.u16Spr8.us2BYTE.LowByte    // x.uBlkId
#define mSetMetaBlockId(x, y)                    ((x.u16Spr8.us2BYTE.LowByte)=y)
#define mGetMetaOpTyp(x)                         x.u16Spr8.us2BYTE.HighByte    // x.uOpTyp
#define mGetMetaWord0(x)                         x.u16Spr0.u16all    // x.u16Spr0
#define mGetMetaWord1(x)                         x.u16Spr1.u16all    // x.u16Spr1
#define mGetMetaWord2(x)                         x.u16Spr2.u16all    // x.u16Spr2
#define mGetMetaWord3(x)                         x.u16Spr3.u16all    // x.u16Spr3
#define mGetMetaWord4(x)                         x.u16Spr4.u16all    // x.u16Spr4
#define mGetMetaWord5(x)                         x.u16Spr5.u16all    // x.u16Spr5
#define mGetMetaWord6(x)                         x.u16Spr6.u16all    // x.u16Spr6
#define mGetMetaWord7(x)                         x.u16Spr7.u16all    // x.u16Spr7
#define mGetMetaEraseCnt(x)                      x.u16Spr11.u16all    // x.u16EraseCnt
#define mGetMetaBlkSn(x)                         x.u32Spr9and10.u32all    // x.u32Serial

// index block spare
#define mGetBadInfoFBlk0(usIdxBlkSprInfo)       (usIdxBlkSprInfo).u16Spr4.u16all&cBadInfoFblkMask
#define mGetBadInfoFBlk1(usIdxBlkSprInfo)       (usIdxBlkSprInfo).u16Spr5.u16all&cBadInfoFblkMask
#define mGetBadInfoFPage(usIdxBlkSprInfo)       (usIdxBlkSprInfo).u16Spr6.u16all&cBadInfoFblkMask
#define mGetBadInfoCh(usIdxBlkSprInfo)          (usIdxBlkSprInfo).u16Spr4.u16all>>cBadInfoFblkShift
#define mGetBadInfoPlane(usIdxBlkSprInfo)       (usIdxBlkSprInfo).u16Spr5.u16all>>cBadInfoFblkShift
#define mGetBadInfoIntlv(usIdxBlkSprInfo)       (usIdxBlkSprInfo).u16Spr6.u16all>>cBadInfoFblkShift

// Set bad info FAddr into the spare 4,5,6 of index block
#define mSetIdxBlkSpr4(usIdxBlkSprInfo, usAddrInfo)\
    (usIdxBlkSprInfo).u16Spr4.u16all=((WORD)(usAddrInfo).uCh<<cBadInfoFblkShift)|\
                                      getDiffAddr((usAddrInfo).u16FBlock,\
                                                  (usAddrInfo).uCh,\
                                                  (usAddrInfo).uIntlvAddr,\
                                                  (usAddrInfo).uPlaneAddr)

#define mSetIdxBlkSpr5(usIdxBlkSprInfo, usAddrInfo)\
    (usIdxBlkSprInfo).u16Spr5.u16all=((WORD)(usAddrInfo).uPlaneAddr<<cBadInfoFblkShift)|\
                                      getDiffAddr((usAddrInfo).u16FBlock,\
                                                  (usAddrInfo).uCh+1,\
                                                  (usAddrInfo).uIntlvAddr,\
                                                  (usAddrInfo).uPlaneAddr)

#define mSetIdxBlkSpr6(usIdxBlkSprInfo, usAddrInfo)\
    (usIdxBlkSprInfo).u16Spr6.u16all=((WORD)(usAddrInfo).uIntlvAddr<<cBadInfoFblkShift)|\
                                      (usAddrInfo).u16FPage

#define mGetMetaH2fPgPtr(x)                      x.u16Spr1.u16all    // x.u16Spr1
#define mGetMetaH2fIdx(x)                        x.u16Spr2.u16all    // x.u16Spr2
#define mGetMetaActH2fTabFb(x)                   x.u16Spr1.u16all    // x.u16Spr1
#define mGetMetaH2fTabbFptr(x)                   x.u16Spr2.u16all    // x.u16Spr2

// #define mGetMetaCardOpNum(x)                     x.uCardOpNum
#define mGetMetaTabIdx(x)                        x.u16Spr0.u16all    // x.u16Spr0
#define mGetMetaSysBlkSn(x)                      x.u32Spr9and10.u32all    // x.u32Serial
#define mGetMetaWproPgOfst(x)                    x.u16Spr1.u16all    // x.u16Spr1
#define mGetMetaWproIdxPg(x)                     x.u16Spr2.u16all    // x.u16Spr2
#define mGetMetaSeed(x)                          x.u16Seed

#define mGetMetaBlockIdPtr(x)                    x->u16Spr8->us2BYTE.LowByte    // x->uBlkId
#define mGetMetaTabIdxPtr(x)                     x->u16Spr0.u16all    // x->u16Spr0
#define mGetMetaOpTypPtr(x)                      x->u16Spr8.us2BYTE.HighByte    // x->uOpTyp
#define mGetMetaH2fIdxPtr(x)                     x->u16Spr2.u16all    // x->u16Spr2

// #define mGetMetaWord2Ptr(x)                    x->u16Spr2
// #define mGetMetaWord3Ptr(x)                    x->u16Spr3
// #define mGetMetaWord4Ptr(x)                    x->u16Spr4
// #define mGetMetaWord5Ptr(x)                    x->u16Spr5
#define mGetMetaEraseCntPtr(x)                   x->u16Spr11.u16all    // x->u16EraseCnt
// #define mGetMetaFpageNumPtr(x)                 x->u16Spr7
// #define mGetMetaHblockPtr(x)                   x->u16Spr2
// #define mGetMetaHpagePtr(x)                    x->u16Spr3

#define mDebugLoop\
    do\
    {\
        volatile BYTE uStop;uStop=1;\
        while(uStop)\
            ;\
    }\
    while(0)

#define mChkBlkIdCorrect                         ((mGetSprId==cCacheBlockID)||(mGetSprId==cGcDesBlockID)||(mGetSprId==cF2hTableID))
#define cUnacceptableSporVth                     0xC8
#define mChkSporRetryVth(x, y)                   ((gReadLinkRetrySlcVth[x][y]<cUnacceptableSporVth)&&(gReadLinkRetrySlcVth[x][y]&cBit7))

#define _DEBUG_PWRCYL                            1
#if _DEBUG_PWRCYL
#define debugRdlinkDeadLock()\
    while(1)
#else
#define debugRdlinkDeadLock()
#endif
extern WORD g16arTempGlobEraseCnt[c16MaxBlockNum];
extern LWORD g32arPopDeniedFlag[c16MaxBlockNum/32];
extern WORD g16FoundCachebCnt;

extern BYTE garFoundWproIdx[cMaxWproBlkCnt];
extern FOUNDWPRO garFoundWproQ[cMaxWproBlkCnt];
extern WORD g16arWproBlkEraseCnt[cMaxWproBlkCnt];
extern WORD g16arFoundCacheIdx[cMaxFoundCacheFBlockNum];
extern FOUNDQINFO garFoundCacheQ[cMaxFoundCacheFBlockNum];

extern RLH2FTABQINFO garH2fTabQ[c16MaxH2fTabBlkNum];
extern BYTE garH2fTabQIndex[c16MaxH2fTabBlkNum];
extern RLERRBLKINFO garErrBlock[c16MaxErrBlkNum];
extern WORD g16arTempDiffType2Offset[cMaxDiffType2Num];    // 128B
extern DIFFTYPE2ADDRINFO gsDiffTyp2AddrInfo;

// add for not exit F2H table SLC block
extern WORD g16CopyFblockCnt;
extern WORD g16arCopyFblockIdx[cMaxCopyBlockNum];    // only record index of FoundCacheQ
extern WORD g16arRdlinkLog[c16RdlinkLogSize/2];
extern WORD g16RdlinkLogUpdPtr;
extern LWORD g32arRdLkSrcVaildF2h[c16CacheF2hSize/32];    // 1k
extern LWORD g32arRdLkKeepRWBitmap[5];    // 32*5=160

extern BYTE getPageInfo(WORD u16FBlock, WORD u16Fpage, BYTE uMode, BLKSPRINFO *upBlkSprInfo);







