







#ifndef __REG_RSA_H__
#define __REG_RSA_H__

#define cRsaAllocate                             0
#define cRsaResetTempMemory                      cBit0
#define cRsaSetMemoryClrPoint                    cBit1
#define cRsaStackStartOffset                     32767

// RSA register   @0x5100 0500
#define rmRsaCtrl                                r32RsaCtrl[0x000]
#define rmRsaIrqCtrl                             r32RsaCtrl[0x004/4]
#define rmRsaModuleId                            r32RsaCtrl[0x00c/4]
#define rmRsaModuleConfig                        r32RsaCtrl[0x010/4]
#define rmRsaModuleResult                        r32RsaCtrl[0x014/4]

#define rmModuleResult                           rRsaCtrl[0x014]

#define rmRsaMemAddr                             r32RsaCtrl[0x030/4]

#define rmRsaParamAddr7                          r32RsaCtrl[0x040/4]
#define rmRsaParamAddr6                          r32RsaCtrl[0x044/4]
#define rmRsaParamAddr5                          r32RsaCtrl[0x048/4]
#define rmRsaParamAddr4                          r32RsaCtrl[0x04C/4]
#define rmRsaParamAddr3                          r32RsaCtrl[0x050/4]
#define rmRsaParamAddr2                          r32RsaCtrl[0x054/4]
#define rmRsaParamAddr1                          r32RsaCtrl[0x058/4]
#define rmRsaParamAddr0                          r32RsaCtrl[0x05C/4]

#define rmRsaMem1(x)                             r32RsaCtrl[(0x0FC/4)-x]

#define rmRsaMem11F                              r32RsaCtrl[0x080/4]
#define rmRsaMem11E                              r32RsaCtrl[0x084/4]
#define rmRsaMem11D                              r32RsaCtrl[0x088/4]
#define rmRsaMem11C                              r32RsaCtrl[0x08C/4]
#define rmRsaMem11B                              r32RsaCtrl[0x090/4]
#define rmRsaMem11A                              r32RsaCtrl[0x094/4]
#define rmRsaMem119                              r32RsaCtrl[0x098/4]
#define rmRsaMem118                              r32RsaCtrl[0x09C/4]
#define rmRsaMem117                              r32RsaCtrl[0x0A0/4]
#define rmRsaMem116                              r32RsaCtrl[0x0A4/4]
#define rmRsaMem115                              r32RsaCtrl[0x0A8/4]
#define rmRsaMem114                              r32RsaCtrl[0x0AC/4]
#define rmRsaMem113                              r32RsaCtrl[0x0B0/4]
#define rmRsaMem112                              r32RsaCtrl[0x0B4/4]
#define rmRsaMem111                              r32RsaCtrl[0x0B8/4]
#define rmRsaMem110                              r32RsaCtrl[0x0BC/4]
#define rmRsaMem10F                              r32RsaCtrl[0x0C0/4]
#define rmRsaMem10E                              r32RsaCtrl[0x0C4/4]
#define rmRsaMem10D                              r32RsaCtrl[0x0C8/4]
#define rmRsaMem10C                              r32RsaCtrl[0x0CC/4]
#define rmRsaMem10B                              r32RsaCtrl[0x0D0/4]
#define rmRsaMem10A                              r32RsaCtrl[0x0D4/4]
#define rmRsaMem109                              r32RsaCtrl[0x0D8/4]
#define rmRsaMem108                              r32RsaCtrl[0x0DC/4]
#define rmRsaMem107                              r32RsaCtrl[0x0E0/4]
#define rmRsaMem106                              r32RsaCtrl[0x0E4/4]
#define rmRsaMem105                              r32RsaCtrl[0x0E8/4]
#define rmRsaMem104                              r32RsaCtrl[0x0EC/4]
#define rmRsaMem103                              r32RsaCtrl[0x0F0/4]
#define rmRsaMem102                              r32RsaCtrl[0x0F4/4]
#define rmRsaMem101                              r32RsaCtrl[0x0F8/4]
#define rmRsaMem100                              r32RsaCtrl[0x0FC/4]

#define rmRsaMem0(x)                             rRsaCtrl[(0x17C-4*(x/4)+(x&0x3))]
#define rm32RsaMem0(x)                           r32RsaCtrl[(0x17C/4)-x]

#define rmRsaMem01F                              r32RsaCtrl[0x100/4]
#define rmRsaMem01E                              r32RsaCtrl[0x104/4]
#define rmRsaMem01D                              r32RsaCtrl[0x108/4]
#define rmRsaMem01C                              r32RsaCtrl[0x10C/4]
#define rmRsaMem01B                              r32RsaCtrl[0x110/4]
#define rmRsaMem01A                              r32RsaCtrl[0x114/4]
#define rmRsaMem019                              r32RsaCtrl[0x118/4]
#define rmRsaMem018                              r32RsaCtrl[0x11C/4]
#define rmRsaMem017                              r32RsaCtrl[0x120/4]
#define rmRsaMem016                              r32RsaCtrl[0x124/4]
#define rmRsaMem015                              r32RsaCtrl[0x128/4]
#define rmRsaMem014                              r32RsaCtrl[0x12C/4]
#define rmRsaMem013                              r32RsaCtrl[0x130/4]
#define rmRsaMem012                              r32RsaCtrl[0x134/4]
#define rmRsaMem011                              r32RsaCtrl[0x138/4]
#define rmRsaMem010                              r32RsaCtrl[0x13C/4]
#define rmRsaMem00F                              r32RsaCtrl[0x140/4]
#define rmRsaMem00E                              r32RsaCtrl[0x144/4]
#define rmRsaMem00D                              r32RsaCtrl[0x148/4]
#define rmRsaMem00C                              r32RsaCtrl[0x14C/4]
#define rmRsaMem00B                              r32RsaCtrl[0x150/4]
#define rmRsaMem00A                              r32RsaCtrl[0x154/4]
#define rmRsaMem009                              r32RsaCtrl[0x158/4]
#define rmRsaMem008                              r32RsaCtrl[0x15C/4]
#define rmRsaMem007                              r32RsaCtrl[0x160/4]
#define rmRsaMem006                              r32RsaCtrl[0x164/4]
#define rmRsaMem005                              r32RsaCtrl[0x168/4]
#define rmRsaMem004                              r32RsaCtrl[0x16C/4]
#define rmRsaMem003                              r32RsaCtrl[0x170/4]
#define rmRsaMem002                              r32RsaCtrl[0x174/4]
#define rmRsaMem001                              r32RsaCtrl[0x178/4]
#define rmRsaMem000                              r32RsaCtrl[0x17C/4]

#endif    // ifndef __REG_RSA_H__







