







#ifndef __REG_CPU_H__
#define __REG_CPU_H__

// Please note, when you access "write register_A then read register_B" in this file defination range
// and "the (u)register_A and (u)register_B at the same DWORD <ex.O8_SpiOutBuf and O8_SpiCtl1>" or
// "the (U32)register_A and (U32)register_B are continuous"
// You need to add "dummy register access" or "chnage (u)register_B to DWORD access" to avoid HW optimize.
// (HW will optimize to send "write register_A" and "read register_B" at the same T)

// CPU Auxiliary Register @ 0x0002 9000
#define  rcCpuAuxClt00                           0x00
#define  rmChkPor1                               (rAux[rcCpuAuxClt00]&cBit5)
// Low Power State
#if (_GREYBOX)
// #define  rmAuxChkAllIdle                         ((r32Aux[rcCpuAuxClt00/4]&0x00FFDB00)==0x00FFDB00)    // 2262 DRAM Controller is busy in
#define  rmAuxChkAllIdle                         ((r32Aux[rcCpuAuxClt00/4]&0x000FF900)==0x000FF900)    // 2263
// #define  rmAuxChkAllIdleWoUart                   ((r32Aux[rcCpuAuxClt00/4]&0x00FFBB00)==0x00FFBB00)    // 2262 DRAM Controller is busy in
#define  rmAuxChkAllIdleWoUart                   ((r32Aux[rcCpuAuxClt00/4]&0x000FB900)==0x000FB900)    // 2263
#else
// #define  rmAuxChkAllIdle                         ((r32Aux[rcCpuAuxClt00/4]&0x00FFDB00)==0x00FFDB00)    // 2262 DRAM Controller is busy in
#define  rmAuxChkAllIdle                         ((r32Aux[rcCpuAuxClt00/4]&0x000FFB00)==0x000FFB00)    // 2263
// #define  rmAuxChkAllIdleWoUart                   ((r32Aux[rcCpuAuxClt00/4]&0x00FFBB00)==0x00FFBB00)    // 2262 DRAM Controller is busy in
#define  rmAuxChkAllIdleWoUart                   ((r32Aux[rcCpuAuxClt00/4]&0x000FBB00)==0x000FBB00)    // 2263
#endif

#define rcCpuAuxClt01                            0x01
#define rmAuxChkBvaIdle                          (rAux[rcCpuAuxClt01]&cBit0)
#define rmAuxChkBvbIdle                          (rAux[rcCpuAuxClt01]&cBit1)
#define rmAuxChkDramIdle                         (!(rAux[rcCpuAuxClt01]&cBit2))    // DRAM Controller is busy in Low Power State
#define rmAuxChkHdmaIdle                         (rAux[rcCpuAuxClt01]&cBit3)
#define rmAuxChkBopIdle                          (rAux[rcCpuAuxClt01]&cBit4)
#define rmAuxChkI2cIdle                          (rAux[rcCpuAuxClt01]&cBit5)
#define rmAuxChkUartIdle                         (rAux[rcCpuAuxClt01]&cBit6)
#define rmAuxChkLdpcIdle                         (rAux[rcCpuAuxClt01]&cBit7)
// #define rmSysIdle                                (rAux[rcCpuAuxClt01]&(~cBit2))==(~cBit2))
#define rmSysIdle                                (rAux[rcCpuAuxClt01]&(~cBit2))

#define  rcCpuAuxClt02                           0x02
#define  rcCpuAuxClt03                           0x03
#define  rcCpuAuxClt04                           0x04
#define  rmChkAuxNvmeIdle                        (rAux[rcCpuAuxClt03]&cBit1)
#define  rmChkPwrDomain1Rst                      (rAux[rcCpuAuxClt04]&cBit0)

#define  rcCpuAuxClt05                           0x05
#define  rcCpuAuxClt06                           0x06
#define  rcCpuAuxClt07                           0x07
#define  rmChkPwrSw1Off                          (!(rAux[rcCpuAuxClt07]&cBit6))
#define  rmChkPwrSw2Off                          (!(rAux[rcCpuAuxClt07]&cBit7))

#define  rcCpuAuxClt10                           0x08
#define  rmChkLinkCurState                       (rAux[rcCpuAuxClt10]&0x3F)    // 0x2901F must be 0xE8 first
#define  rmChkTsWithPad                          (rAux[rcCpuAuxClt10+3]&cBit3)    // 0x2901F must be 0xE8 first
#define  rmChkPmIsNotActive                      ((rAux[rcCpuAuxClt10]&0x0F)!=0x02)

#define  rcCpuAuxClt11                           0x09
#define  rmChkMacPhyTxElectrical                 (rAux[rcCpuAuxClt11]&0x3C)
// Check L1 substate current state machine
#define  rmL1SubInWait4ClkReq                    ((rAux[rcCpuAuxClt11]&0x70)==0x30)
#define  rmL1SubInL1N                            ((rAux[rcCpuAuxClt11]&0x70)==0x50)
#define  rmL1SubInL1U                            ((rAux[rcCpuAuxClt11]&0x70)==0x00)

#define  rcCpuAuxClt12                           0x0A
#define  rmGetXadmldle                           (rAux[rcCpuAuxClt12]&0x01)
#define  rcCpuAuxClt13                           0x0B
#define  rmGetMasterState                        (rAux[rcCpuAuxClt13]&0x1F)

#if 0    // for SM2262
#define  rcCpuAuxClt14                           0x0C
#define  rmChkRcvdTs2                            (rAux[rcCpuAuxClt14]&cBit1)

#define  rcCpuAuxClt15                           0x0D
#define  rcCpuAuxClt16                           0x0E
#define  rmChkPclkOff                            (rAux[rcCpuAuxClt16]&cBit6)

#define  rcCpuAuxClt17                           0x0F
#define  rmChkEletricalIdleDetect                (rAux[rcCpuAuxClt17]&0xF0)
#else    // for SM2263
#define  rcCpuAuxClt14                           0x08
#define  rmChkRcvdTs2                            (rAux[rcCpuAuxClt14]&cBit1)

#define  rcCpuAuxClt15                           0x09
#define  rcCpuAuxClt16                           0x0A
#define  rmChkPclkOff                            (rAux[rcCpuAuxClt16]&cBit6)

#define  rcCpuAuxClt17                           0x0B
#define  rmGetNoTlpPending                       (rAux[rcCpuAuxClt17]&0x10)    // LeverYu_20190926
#define  rmChkEletricalIdleDetect                (rAux[rcCpuAuxClt17]&0xF0)
#endif    // if 0

// ==============================================================
#define rcCpuCfgToMaskLh                         0x10
// defualt : '1' : cfg timeout interrupt mechanism turn off.
//          '0' : cfg timeout interrupt mechanism turn on.
#define rmDisCpuCfgToMaskLow                    (r32Aux[rcCpuCfgToMaskLh/4]=0x00000000)

#define rcCpuCfgToMaskUh                         0x14
#define rmDisCpuCfgToMaskHighWoAhci              (r16Aux[rcCpuCfgToMaskUh]=c16Bit6)    // disable AHCI, because we don't enable AHCI clk except
// fake engine

#define rcCpuCfgDummyMaskLh                      0x28
// defualt : '1' : cfg timeout interrupt mechanism turn off.
//          '0' : cfg timeout interrupt mechanism turn on.
#define rmDisCpuCfgDummyMaskLow                  (r32Aux[rcCpuCfgDummyMaskLh]=0x00000000)

#define rcCpuCfgDummyMaskUh                      0x2C
#define rmDisCpuCfgDummyMaskHighWoAhci           (r16Aux[rcCpuCfgDummyMaskUh]=c16Bit6)    // disable AHCI, because we don't enable AHCI clk
// except fake engine
// ==============================================================

#define  rcCpuAuxClt20                           0x18
#define  rcCpuAuxClt21                           0x19
#define  rcCpuAuxClt22                           0x1A
#define  rmAuxEnCpu1Wr                           (rAux[rcCpuAuxClt20]|=cBit0)
#define  rmAuxDisCpu1Wr                          (rAux[rcCpuAuxClt20]&=(~cBit0))
#define  rmpw2EnDramClkGate                      (rAux[rcCpuAuxClt22]|=cBit0)
#define  rmpw2DisDramClkGate                     (rAux[rcCpuAuxClt22]&=(~cBit0))

#define  rcCpuAuxClt23                           0x1B
#define  rmChkSpiLoadDone\
    while(!((rAux[rcCpuAuxClt23]&cBit0)))

#define  rcCpuAuxClt24                           0x1C
#define  rmSetFwDebugSelect                      (rAux[rcCpuAuxClt24]|=cBit0)
#define  rmClrFwDebugSelect                      (rAux[rcCpuAuxClt24]&=(~cBit0))
#define  rmGetFwDebugSelect                     (rAux[rcCpuAuxClt24]&cBit0)

#define  rcCpuAuxClt25                           0x1D
#define  rcCpuAuxClt26                           0x1E
#define  rcCpuAuxClt27                           0x1F
#define  rmAuxEnDebug                            (rAux[rcCpuAuxClt27]|=cBit7)
#define  rmAuxDisDebug                           (rAux[rcCpuAuxClt27]&=(~cBit7))
#define  rmSetAuxToPcieDebug                     (rAux[rcCpuAuxClt27]=0xE8)    // 0xE8: Pcie
#define  rmGetAuxToPcieDebug                     rAux[rcCpuAuxClt27]
#define  rmSetAuxToPipe0Debug                    (rAux[rcCpuAuxClt27]=0xF6)
#define  rmSetAuxToPipeDebug                     (rAux[rcCpuAuxClt27]=0xF8)    // 0xF8: Pcie PIPE interface
#define  rmClrAuxDebug                           (rAux[rcCpuAuxClt27]=0x00)
#define  rmSetAuxToAspmDebug                     (rAux[rcCpuAuxClt27]=0xEA)
#define  rmSetAuxToPmDebug                       (rAux[rcCpuAuxClt27]=0xEB)

#define  rcCpuErrFlag                            0x20
#define  rmClrCpuErr                             (rAux[rcCpuErrFlag]|=cBit0)
#define  rmChkCpuErr                             (rAux[rcCpuErrFlag]&cBit0)

#define  rcCpuErrAddr                            0x24
#define  rmGetCfgErrAddr                         r32Aux[rcCpuErrAddr/4]

// CPU Coherence Register @ 0x0002 A000
#define  rcCpuCohClt00                           0x00
#define  rcCpuCohClt01                           0x01
#define  rcCpuCohClt02                           0x02
#define  rcCpuCohClt03                           0x03
#define  rcCpuCohClt04                           0x04
#define  rcCpuCohClt05                           0x05
#define  rcCpuCohClt06                           0x06
#define  rcCpuCohClt07                           0x07

#define  rcCpuCohClt10                           0x08
#define  rcCpuCohClt11                           0x09
#define  rcCpuCohClt12                           0x0A
#define  rcCpuCohClt13                           0x0B
#define  rcCpuCohClt14                           0x0C
#define  rcCpuCohClt15                           0x0D
#define  rcCpuCohClt16                           0x0E
#define  rcCpuCohClt17                           0x0F

#define  rcCpuCohStatus0                         0x10
#define  rcCpuCohStatus1                         0x11
#define  rcCpuCohStatus2                         0x12
#define  rcCpuCohStatus3                         0x13
#define  rcCpuCohStatus4                         0x14
#define  rcCpuCohStatus5                         0x15
#define  rcCpuCohStatus6                         0x16
#define  rcCpuCohStatus7                         0x17

#define  rmCohEnCpu1                             (rCoh[rcCpuCohClt00]|=cBit0)
#define  rmCohDisCpu1                            (rCoh[rcCpuCohClt00]&=(~cBit0))
#define  rmCohCpu1ResetStart                     (rCoh[rcCpuCohClt01]|=cBit0)
#define  rmCohCpu1ResetEnd                       (rCoh[rcCpuCohClt01]&=(~cBit0))
#define  rmCohEnRegion0                          (rCoh[rcCpuCohClt03]|=cBit4)
#define  rmCohEnRegion1                          (rCoh[rcCpuCohClt03]|=cBit5)
#define  rmCohEnRegion2                          (rCoh[rcCpuCohClt03]|=cBit6)
#define  rmCohEnRegion3                          (rCoh[rcCpuCohClt03]|=cBit7)
#define  rmCohDisAllRegion                       (rCoh[rcCpuCohClt03]&=0x0F)
#define  rmCohMsbRegion0                         rCoh[rcCpuCohClt04]
#define  rmCohMsbRegion1                         rCoh[rcCpuCohClt05]
#define  rmCohMsbRegion2                         rCoh[rcCpuCohClt06]
#define  rmCohMsbRegion3                         rCoh[rcCpuCohClt07]

#define  rmCohMaskRegion0                        rCoh[rcCpuCohClt14]
#define  rmCohMaskRegion1                        rCoh[rcCpuCohClt15]
#define  rmCohMaskRegion2                        rCoh[rcCpuCohClt16]
#define  rmCohMaskRegion3                        rCoh[rcCpuCohClt17]

#define  cCpuEccCorItagOffset                    cBit0
#define  cCpuEccCorIdataOffset                   cBit1
#define  cCpuEccCorDtagOffset                    cBit2
#define  cCpuEccCorDdataOffset                   cBit3
#define  cCpuEccCorDtcmOffset                    cBit4
#define  cCpuEccCorItcmOffset                    cBit5
#define  cCpuEccCorAxiOffset                     cBit6

#define  rmCohEccCorFail                         rCoh[rcCpuCohStatus2]
#define  rmCohEccCorItag                         (rCoh[rcCpuCohStatus2]&cBit0)
#define  rmCohEccCorIdata                        (rCoh[rcCpuCohStatus2]&cBit1)
#define  rmCohEccCorDtag                         (rCoh[rcCpuCohStatus2]&cBit2)
#define  rmCohEccCorDdata                        (rCoh[rcCpuCohStatus2]&cBit3)
#define  rmCohEccCorDtcm                         (rCoh[rcCpuCohStatus2]&cBit4)
#define  rmCohEccCorItcm                         (rCoh[rcCpuCohStatus2]&cBit5)
#define  rmCohEccCorAxi                          (rCoh[rcCpuCohStatus2]&cBit6)

#define  cCpuEccErrItcmOffset                    cBit0
#define  cCpuEccErrDtcmOffset                    cBit1
#define  cCpuEccErrDdataOffset                   cBit2
#define  cCpuEccErrDtagOffset                    cBit3
#define  cCpuEccErrAxiOffset                     cBit4
#define  cCpuEccErrLivelockOffset                cBit5

#define  rmCohEccErrFail                         rCoh[rcCpuCohStatus3]
#define  rmCohEccErrItcm                         (rCoh[rcCpuCohStatus3]&cBit0)
#define  rmCohEccErrDtcm                         (rCoh[rcCpuCohStatus3]&cBit1)
#define  rmCohEccErrDdata                        (rCoh[rcCpuCohStatus3]&cBit2)
#define  rmCohEccErrDtag                         (rCoh[rcCpuCohStatus3]&cBit3)
#define  rmCohEccErrAxi                          (rCoh[rcCpuCohStatus3]&cBit4)
#define  rmCohEccErrLivelock                     (rCoh[rcCpuCohStatus3]&cBit5)

#endif    // ifndef __REG_CPU_H__







