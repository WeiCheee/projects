







#ifndef __REG_EFUSE_H__
#define __REG_EFUSE_H__

// EFUSE register   @0x5000 0400
#define  rcA0Csb                                 0x00
#define  rcA0Strobe                              0x04
#define  rcA0PgEnb                               0x08
#define  rcA0Load                                0x0C
#define  rcA0Pd                                  0x10
#define  rcA0Ps                                  0x14
#define  rcA0Qout                                0x18
#define  rmEfuseSetA0Csb                         (rEfuseCtrl[rcA0Csb]=0x01)
#define  rmEfuseClrA0Csb                         (rEfuseCtrl[rcA0Csb]=0x00)
#define  rmEfuseSetA0Strobe                      (rEfuseCtrl[rcA0Strobe]=0x01)
#define  rmEfuseClrA0Strobe                      (rEfuseCtrl[rcA0Strobe]=0x00)
#define  rmEfuseSetA0PgEnb                       (rEfuseCtrl[rcA0PgEnb]=0x01)
#define  rmEfuseClrA0PgEnb                       (rEfuseCtrl[rcA0PgEnb]=0x00)
#define  rmEfuseSetA0Load                        (rEfuseCtrl[rcA0Load]=0x01)
#define  rmEfuseClrA0Load                        (rEfuseCtrl[rcA0Load]=0x00)
#define  rmEfuseSetA0Pd                          (rEfuseCtrl[rcA0Pd]=0x01)
#define  rmEfuseClrA0Pd                          (rEfuseCtrl[rcA0Pd]=0x00)
#define  rmEfuseSetA0Ps                          (rEfuseCtrl[rcA0Ps]=0x01)
#define  rmEfuseClrA0Ps                          (rEfuseCtrl[rcA0Ps]=0x00)
#define  rmEfuseReadA0Dtat                       (rEfuseCtrl[rcA0Qout])

#define  rcByteAddr                              0x3C
#define  rmEfuseSetByteAddr(uByte)               (rEfuseCtrl[rcByteAddr]=uByte)

#define  rcBitAddr                               0x3D
#define  rmEfuseSetBitAddr(uBit)                 (rEfuseCtrl[rcBitAddr]=uBit)

#define  rcB0Csb                                 0x40
#define  rcB0Sclk                                0x44
#define  rcB0Pgm                                 0x48
#define  rcB0Din                                 0x4C
#define  rcB0Qout                                0x50
#define  rcB0DouTout                             0x54
#define  rmEfuseSetB0Csb                         (rEfuseCtrl[rcB0Csb]=0x01)
#define  rmEfuseClrB0Csb                         (rEfuseCtrl[rcB0Csb]=0x00)
#define  rmEfuseSetB0Sclk                        (rEfuseCtrl[rcB0Sclk]=0x01)
#define  rmEfuseClrB0Sclk                        (rEfuseCtrl[rcB0Sclk]=0x00)
#define  rmEfuseSetB0Pgm                         (rEfuseCtrl[rcB0Pgm]=0x01)
#define  rmEfuseClrB0Pgm                         (rEfuseCtrl[rcB0Pgm]=0x00)
#define  rmEfuseSetB0Din                         (rEfuseCtrl[rcB0Din]=0x01)
#define  rmEfuseClrB0Din                         (rEfuseCtrl[rcB0Din]=0x00)

#define  rcDebugFlagBus                          0x70
#define  rmEfuseDisJtag                          (r32EfuseCtrl[rcDebugFlagBus/4]=0x00000000)
#define  rmEfuseEnJtag                           (r32EfuseCtrl[rcDebugFlagBus/4]=0xAAAAAAAA)

#define  rcEfuseProgCntL                         0x74
#define  rcEfuseProgCntH                         0x75
#define  rmEfuseSetProgCnt(u16Cnt)               {rEfuseCtrl[rcEfuseProgCntL]=(u16Cnt&0x00FF);rEfuseCtrl[rcEfuseProgCntH]=(u16Cnt>>8);}

#define  rcEfuseEctl0                            0x78
#define  rmEfuseSetProgCntTrig                   (rEfuseCtrl[rcEfuseEctl0]|=cBit0)
#define  rmEfuseClrProgCntTrig                   (rEfuseCtrl[rcEfuseEctl0]&=(~cBit0))
#define  rmEfuseChkProgCntTrig                   (rEfuseCtrl[rcEfuseEctl0]&cBit0)

#define  rcEfuseCtl1                             0x7C
// #define  rmEfuseSetProdFlag                      (rEfuseCtrl[rcEfuseCtl1]|=cBit1)
// #define  rmEfuseClrProdFlag                      (rEfuseCtrl[rcEfuseCtl1]&=(~cBit1))
#define  rmEfuseChkProdFlag                      (rEfuseCtrl[rcEfuseCtl1]&cBit1)
// #define  rmEfuseSetSpiFlag                       (rEfuseCtrl[rcEfuseCtl1]|=cBit2)
// #define  rmEfuseClrSpiFlag                       (rEfuseCtrl[rcEfuseCtl1]&=(~cBit2))
#define  rmEfuseChkSpiFlag                       (rEfuseCtrl[rcEfuseCtl1]&cBit2)
#define  rmEfuseSetBgTrimDebug                   (rEfuseCtrl[rcEfuseCtl1]|=cBit3)
#define  rmEfuseClrBgTrimDebug                   (rEfuseCtrl[rcEfuseCtl1]&=(~cBit3))
#define  rmEfuseSetLoadA0A127                    (rEfuseCtrl[rcEfuseCtl1]|=cBit4)
#define  rmEfuseClrLoadA0A127                    (rEfuseCtrl[rcEfuseCtl1]&=(~cBit4))
#define  rmEfuseSetBgTrimEn                      (rEfuseCtrl[rcEfuseCtl1]|=cBit5)
#define  rmEfuseSetBgTrimDis                     (rEfuseCtrl[rcEfuseCtl1]&=(~cBit5))

#define  rcCurFllTrimVal                         0x7E
#define  rmCurFllTrimVal(x)                      (rEfuseCtrl[rcCurFllTrimVal]=(x&0x7F))
#define  rmGetCurFllTrimVal                      rEfuseCtrl[rcCurFllTrimVal]

#define  rcFllTrimDone                           0x7F
#define  rmChkFllTrimDone                        (rEfuseCtrl[rcFllTrimDone]&cBit0)

#define rcEfuseReg3B                             0x1EC
#define rmEfuse85Code                            ((r32EfuseCtrl[rcEfuseReg3B/4]>>6)&0x1FF)
#define rmEfuse30Code                            ((r32EfuseCtrl[rcEfuseReg3B/4]>>15)&0x1FF)
#endif    // ifndef __REG_EFUSE_H__







