







#ifndef __NVMECTRL_H__
#define __NVMECTRL_H__

#include "inc/TypeDef.h"
#include "inc/Option.h"
#include "inc/GlobVar0.h"
#include "inc/GlobVarS.h"
#include "Common/Model.h"

// Io cmd
#define cNvmeCmdFlush                            0x00
#define cNvmeCmdWrite                            0x01
#define cNvmeCmdRead                             0x02
#define cNvmeCmdWriteUnc                         0x04
#define cNvmeCmdCompare                          0x05
#define cNvmeCmdWriteZero                        0x08
#define cNvmeCmdDataSetMgm                       0x09

// Admin cmd
#define cNvmeCmdDeleteSq                         0x00
#define cNvmeCmdCreateSq                         0x01
#define cNvmeCmdGetLogPage                       0x02
#define cNvmeCmdInvalidOpCode                    0x03
#define cNvmeCmdDeleteCq                         0x04
#define cNvmeCmdCreateCq                         0x05
#define cNvmeCmdIdentify                         0x06
#define cNvmeCmdAbortCmd                         0x08
#define cNvmeCmdSetFeatures                      0x09
#define cNvmeCmdGetFeatures                      0x0A
#define cNvmeCmdAsyncEvent                       0x0C
#define cNvmeCmdNamespaceManagement              0x0D
#define cNvmeCmdActivateFw                       0x10
#define cNvmeCmdDownloadFw                       0x11
#define cNvmeCmdDst                              0x14
#define cNvmeCmdNamespaceAttachment              0x15
#define cNvmeCmdKeepAlive                        0x18
#define cNvmeCmdDirectiveSend                    0x19
#define cNvmeCmdDirectiveRecv                    0x1A
#define cNvmeCmdVirtualManagement                0x1C
#define cNvmeCmdNvmeMiSend                       0x1D
#define cNvmeCmdNvmeMiRecv                       0x1E
#define cNvmeCmdGap1                             0x1F

#define cNvmeDoorbellBuffConfig                  0x7C
#define cNvmeFabrics                             0x7F
#define cNvmeCmdFormat                           0x80
#define cNvmeCmdSecuritySend                     0x81
#define cNvmeCmdSecurityRecv                     0x82
#define cNvmeCmdSanitize                         0x84
#define cNvmeCmdGap2                             (cNvmeCmdGap1+0x09)    // include invalidcmd

#define cNvmeCmdVendorNonData                    0xC0
#define cNvmeCmdVendorDataOut                    0xC1
#define cNvmeCmdVendorDataIn                     0xC2
#define cNvmeCmdGap3                             (cNvmeCmdGap2+0x03)

#define cNvmeCmdLiteonVendorNonData              0xFC
#define cNvmeCmdLiteonVendorDataOut              0xFD
#define cNvmeCmdLiteonVendorDataIn               0xFE
#define cNvmeCmdGap4                             (cNvmeCmdGap3+0x03)
#if 0    // Hynix Vu
// DataIn Vu Cmd
#define cDataInVuCmdIdLba2Pba                    0x7010
#define cDataInVuCmdIdPba2Lba                    0x7011
#define cDataInVuCmdIdGetNandParam               0x7030
#define cDataInVuCmdIdGetOtpWaferInfo            0x8000
#define cDataInVuCmdIdSweepVth                   0x9000
#define cDataIntVuCmdIdReadPg                    0x6000
#define cDataIntVuCmdIdGetEraseCnt               0x7050
#define cDataIntVuCmdIdSmartRead                 0x17000
#define cDataInVuCmdIdChkVuMod                   0x7100
#define cDataInVuCmdIdGetFwParam                 0x7040
#define cDataInVuCmdIdGetThermalVal              0x16000
#define cDataInVuCmdIdGetExtFwVer                0x18000
#define cDataInVuCmdIdGetIntFwVer                0x18010
#define cDataInVuCmdIdGetSerNum                  0x18020
#define cDataInVuCmdIdGetModleNum                0x18030
#define cDataInVuCmdIdGetEui64                   0x18040
#define cDataInVuCmdIdReadFlashID                0x18070

// DataOut Vu Cmd
#define cDataOutVuCmdIdSetExtFwVer               0x1C000
#define cDataOutVuCmdIdSetIntFwVer               0x1C010
#define cDataOutVuCmdIdSetSerNum                 0x1C020
#define cDataOutVuCmdIdSetModelNum               0x1C030
#define cDataOutVuCmdIdSetEui64                  0x1C040
// NonData Vu Cmd
#define cNonDataVuCmdIdEraseBlock                0x2000
#define cNonDataVuCmdIdSetNandParam              0x3000
#define cNonDataVuCmdIdTmPgmErr                  0x5000
#define cNonDataVuCmdIdSetEraseCnt               0x3010
#define cNonDataVuCmdIdEraseAllBlock             0x2001
#define cNonDataVuCmdIdDeepEraseAllBlock         0x2002
#define cNonDataVuCmdIdSetFeatures               0x13010
#define cNonDataVuCmdIdClearAttribute            0x12000
#define cNonDataVuCmdIdEnSmartUpdate             0x12010
#define cNonDataVuCmdIdSetTempThreshold          0x11000
#define cNonDataVuCmdIdActivateFw                0x13000
#define cNonDataVuCmdIdEnableAes                 0x15000
#define cNonDataVuCmdIdDisableAes                0x15001
#define cNonDataVuCmdIdSmartGetWaiInfo           0x17010
#define cNonDataVuCmdIdGetAesKey                 0x18060
#define cNonDataVuCmdIdSmartWrite                0x1B000
#define cNonDataVuCmdIdSwitchCellMode            0x1002

#define cNvmeVuCmdNonData                        0xF0
#define cNvmeVuCmdDataOut                        0xF1
#define cNvmeVuCmdDataIn                         0xF2

#if 0
#define cNvmeCmdVendorPpNonData                  0xD0    // Outdated?
#define cNvmeCmdVendorPpDataOut                  0xD1
#define cNvmeCmdVendorPpDataIn                   0xD2
#endif

#define cNvmeCmdGap4                             (cNvmeCmdGap3+0x03)    // (cNvmeCmdGap3+0x02)
#endif    // if 0
// Smi Vu
#if 1
// DataIn Vendor Cmd
#define cDataInVendorCmdIdReadFlashId            0x40
#define cDataInVendorCmdIdReadPhysicalPage       0x4E
#define cDataInVendorCmdIdReadRam                0x52
#define cDataInVendorCmdIdReadGlobEraseCnt       0x53
#define cDataInVendorCmdIdReadGlobReadCnt        0x54
#define cDataInVendorCmdIdReadLog                0x57
#define cDataInVendorCmdIdReadMpInfo             0x58
#define cDataInVendorCmdIdReadWproPage           0x5B
#define cDataInVendorCmdIdReadDistribution       0x77
#define cDataInVendorCmdIdLba2Pba                0x78
#define cDataInVendorCmdIdFlashConnectivityTest  0x80
#define cDataInVendorCmdIdReadDriveInfo          0x87
#define cDataInVendorCmdIdReadVendorCmdDebugInfo 0x88
#define cDataInVendorCmdIdReadHmbInfo            0x8D
#define cDataInVendorCmdIddoVtDistribution       0x8E
#define cDataInVendorCmdIdReadPcieCfg            0x90
#define cDataInVendorCmdIdReadEfuseReg           0x92
#define cDataInVendorCmdIdReadCr                 0xA1
#define cDataInVendorCmdIdWdPhyErase             0xF0
#define cDataInVendorCmdIdWdPhyRead              0xF2
#define cDataInVendorCmdIdWdCheckSts             0xF3

// DataOut Vendor Cmd
#define cDataOutVendorCmdIdWriteRam              0x80
#define cDataOutVendorCmdIdWritePhysicalPage     0x83
#define cDataOutVendorCmdIdSetCardMode           0x90
#define cDataOutVendorCmdIdWriteMPInfo           0x95
#define cDataOutVendorCmdIdWdPhyProgram          0xF1
#define cDataOutVuCmdIdWritePg                   0xB000
#define cDataOutVendorCmdPsidAndMsid             0xCC    // Used for Set PSID and MSID

// NonData Vendor Cmd
#define cNonDataVendorCmdIdResetCpu              0x01
#define cNonDataVendorCmdIdJumpCode              0x02
#define cNonDataVendorCmdIdErasePhysicalBlock    0x03
#define cNonDataVendorCmdIdClearSmart            0x0E
#define cNonDataVendorCmdIdAtaPassthroughErase   0x10
#define cNonDataVendorCmdIdVthSet                0xFC
#define cNonDataVendorCmdIdWDTest                0xFE

#define cDataInVendorCmdIdGreyBoxPre             0xC1
#define cDataInVendorCmdIdGreyBoxTrig            0xC2
#define cDataInVendorCmdIdGreyBoxDone            0xC3
#define cDataInVendorCmdIdGreyBoxInit            0xC5
#define cDataInVendorCmdIdDeepErase              0xC6
#define cDataInVendorCmdIdGreyBoxModifyEraseCnt  0xC7
#define cDataInVendorCmdIdGreyBoxMarkBadBlock    0xC8
#define cDataInVendorCmdIdGreyBoxSecurityRW      0xC9
#define cDataInVendorCmdGreyBoxReadH2fTab        0xCF

#define cDataOutVendorCmdIdGreyBoxTrig           0xC4

#define cDataInVendorCmdIdGreyBoxFwUniTestOut    0xCB
#define cDataOutVendorCmdIdGreyBoxFwUniTestIn    0xCA
#define cDataInVendorCmdGreyBoxGetFwDefPara      0xCD
#define cDataInVendorCmdGreyBoxSaveQBInfo        0xCE
// --VSC Function--
#define cVscFunction_DeviceHWCheck                             0x10
#define cVscFunction_DeviceFWCheck                             0x11
#define cVscFunction_EEPROMOperation                           0x12
#define cVscFunction_PurageOperation                           0x13
#define cVscFunction_AgingOnlyOperation                        0x14
#define cVscFunction_FTLRelatedOperation                       0x15
#define cVscFunction_InternalTableOperation                    0x16
#define cVscFunction_DebugOperation                            0x17
#define cVscFunction_SMIVU                                     0x80

// --VSC Mode--
// Vsc_DeviceHWCheck
#define cVscMode_READ_FLASHID                              0x00    // R
#define cVscMode_READ_NORFLASHID                           0x01    // NS R
#define cVscMode_PCIE_CONFIG                               0x10    // R
#define cVscMode_READ_DID_VID                              0x11    // R
#define cVscMode_CHECK_PLP                                 0x20    // NS R
#define cVscMode_READ_SOC_TYPE                             0x40    // NS R
#define cVscMode_VPD_INIT                                  0x50    // NS Non
#define cVscMode_VPD_WRITE                                 0x58    // NS W
#define cVscMode_VPD_RAED                                  0x59    // NS R
#define cVscMode_READ_DRAM_DLL                             0x60    // Check R
#define cVscMode_NOR_TEST                                  0x61    // NS
#define cVscMode_NAND_TEST                                 0x62    // NS
#define cVscMode_READ_DRAM_VENDOR                          0x63    // R

// Vsc_DeviceFWCheck
#define cVscMode_READ_FW_CONFIG                            0x00    // R
#define cVscMode_READ_FW_VERSION                           0x40    // R
#define cVscMode_READ_BOOT_VERSION                         0x80    // R
#define cVscMode_READ_HEALTH_CHECK                         0x81    // Check R
#define cVscMode_READ_FW_HISTORY                           0xFF    // R

// Vsc_EEPROMOperation
#define cVscMode_EEPROM_READ                               0x00    // R
#define cVscMode_EEPROM_WRITE                              0x01    // W

// Vsc_PurageOperation
#define cVscMode_MP_PREFORMAT                              0x00    // Non
#define cVscMode_FOB_PREFORMAT                             0x01    // Non
#define cVscMode_CorePower_Learning                        0x02    // Non
// Vsc_AgingOnlyOperation

// Vsc_FTLRelatedOperation
#define cVscMode_DISK_LOCK                                 0x00    // NS Non
#define cVscMode_NAND_FLUSH_CNT                            0x08    // R
#define cVscMode_ECC_INSERT                                0x10    // NS Non
#define cVscMode_ECC_DELETE                                0x11    // NS Non
#define cVscMode_ECC_RESET                                 0x12    // NS Non

// Vsc_InternalTableOperation
#define cVscMode_READ_ERASE_CNT                            0x00    // R
#define cVscMode_READ_VAILD_CNT                            0x01    // R
#define cVscMode_READ_GLIST                                0x02    // R
#define cVscMode_READ_ECC                                  0x03    // R
#define cVscMode_READ_SCP_CNT                              0x04    // R
#define cVscMode_CLEAR_GLIST                               0x10    // Non

// Vsc_DebugOperation

// Vsc_Function_SMIVU
#define cVscMode_GetPciePara                               0x00

#else    // if 1
#define cNvmeSubCmdResetCpu                      0x01
#define cNvmeSubCmdJumpCode                      0x02
#define cNvmeSubCmdEraseFlashPhyical             0x03
#define cNvmeSubCmdEraseFlashAuto                0x04
#define cNvmeSubCmdEraseAllBlock                 0x05
#define cNvmeSubCmdManualMarkBad                 0x06
#define cNvmeSubCmdWriteProductFlag              0x07
// #define cNvmeSubCmdSmiFwActive                 0x08
#define cNvmeSubCmdDestroySuperLightswitch       0x09
#define cNvmeSubCmdSmiPreTestActive              0x0A
#define cNvmeSubCmdWriteSPIOverrideFlag          0x0B
#define cNvmeSubCmdWriteEfuseKey                 0x0C
#define cNvmeSubCmdEraseSysBlock                 0x0D
#define cNvmeSubCmdClearSmart                    0x0E
#define cNvmeSubCmdClearAssert                   0x0F
#define cNvmeSubCmdTriStateMode                  0x10
#define cNvmeSubCmdForceAssert                   0x11
#define cNvmeSubCmdEnablePost                    0x12
#define cNvmeSubCmdCrlcSetting                   0x13

#define cNvmeSubCmdReadFlashId                   0x40
// #define cNvmeSubCmdDumpFw                      0x41
// #define cNvmeSubCmdReadVUStatus                0x42
// #define cNvmeSubCmdReadVUPara                  0x43
// #define cNvmeSubCmdReadBadTable                0x44
#define cNvmeSubCmdGetBadBlockInfo               0x41
#define cNvmeSubCmdGetRdtResult                  0x45
#define cNvmeSubCmdGetRdtEraseCnt                0x46
// #define cNvmeSubCmdReadRuntimeBad              0x47
#define cNvmeSubCmdDumpEraseCnt                  0x48
#define cNvmeSubCmdDumpH2f                       0x49
// #define cNvmeSubCmdReadOPTInfo                 0x4A
#define cNvmeSubCmdChunkEccPhysical              0x4B
#define cNvmeSubCmdChunkEccAuto                  0x4C
#define cNvmeSubCmdReadFlashAuto                 0x4D
#define cNvmeSubCmdReadFlashPhysical             0x4E
#define cNvmeSubCmdL2pMapping                    0x4F
#define cNvmeSubCmdP2lMapping                    0x50
// #define cNvmeSubCmdReadWPROPage                0x4F
// #define cNvmeSubCmdDumpStrongPage              0x50
#define cNvmeSubCmdDumpLinkTable                 0x51
#define cNvmeSubCmdReadDram                      0x52
#define cNvmeSubCmdGetDiagInfo                   0x53
#define cNvmeSubCmdGetHashOfRom                  0x54
#define cNvmeSubCmdGetRandomNum                  0x55
#define cNvmeSubCmdReadNandUid                   0x56
#define cNvmeSubCmdReadLog                       0x57
#define cNvmeSubCmdReadLightswitch               0x58
#define cNvmeSubCmdGetBlockInfo                  0x59
#define cNvmeSubCmdGetMarkBadInfo                0x5A
#define cNvmeSubCmdGetSysBlockInfo               0x60
#define cNvmeSubCmdPhyI2cRead                    0x61

#define cNvmeSubCmdDumpFwImage                   0x70

#define cNvmeSubCmdWriteDram                     0x80
#define cNvmeSubCmdRestoreOrgBad                 0x81
// #define cNvmeSubCmdSetRetryTable               0x82
#define cNvmeSubCmdWriteFlashPhysical            0x83
#define cNvmeSubCmdAsymDiagUnlock                0x84
#define cNvmeSubCmdDownloadEfuseKey              0x85
#define cNvmeSubCmdDownloadCid                   0x86
#define cNvmeSubCmdWritePsidAndNandKey           0x87
#define cNvmeSubCmdSmiFwImageProgram             0x88
#define cNvmeSubCmdWriteEraseCnt                 0x89
#define cNvmeSubCmdProgSPI                       0x8A
#define cNvmeSubCmdPhyI2cWrite                   0x8B

// Nvme PP sub-OP code define
#define cNvmeSubCmdPpReadCycle                   0xA0
#define cNvmeSubCmdPpWriteCycle                  0xA0
#define cNvmeSubCmdPpGenNandCmd                  0xA1
#define cPPTestMode                              0x00
#define cPPSetChannel                            0x01

#define cNvmeSubCmdMicron                        0xFA
#endif    // if 1

// H/W PRD queqe used
#define cLastPrd                                 c32Bit16
#define cTsb                                     c32Bit15
#define cDram                                    c32Bit14
#define cSetTsbOccFlag                           c32Bit13
#define cSetBvciOccFlag                          c32Bit12
#define cEnTsbRunTimeOcc                         c32Bit11
#define cEnBvciRunTimeOcc                        c32Bit10
#define cAes                                     c32Bit9
#define cAutoRaidFlag                            c32Bit2
#define cAutoBufflag                             c32Bit1    // 2263 need to set this bit to invert buffer flag.
#if _ENABLE_E2E_PROTECTION
#define cCrcCheckEn                              ((gSecurityOption&cEnE2e)?c32Bit0:0)
#else
#define cCrcCheckEn                              0
#endif

// Manual completion used
#define cRwCmd                                   0x00
#define cAbortCmd                                0x01
#define cAsyncCmd                                0x02
#define cDeleteQCmd                              0x04
#define cNoRwCmd                                 0x05
#define cCreateQCmd                              0x06

// For function's parameters used
#define cNvmeRead                                0x02
#define cNvmeWrite                               0x01

// #define cToFromTSB                               cNvmeRead
// #define cToFromDRAM                              cNvmeWrite
#define cBypassAes                               0x00
#define cThroughAes                              cBit0
#define cNonLastPrd                              cBit1
#define cDirectTrig                              0x01    // Trig read cmd when receiving cmd
#define cNotTrig                                 0x00    // Trig read cmd when all data ready on TSB //Temp method
#define cAutoCq                                  0x00    // Auto return completion queqe
#define cManualCq                                cBit0    // Manual return completion queqe
#define cHmbDescList                             cBit1
#define cMultiPrd                                cBit2
#define cMultiPrdForFd                           cBit3
#define c32AutoDmaTrigR                          0x0000012D
#define c32AutoDmaTrigW                          0x00000925
#define c32AutoHmbTrigR                          0x0000010D
#define c32AutoHmbTrigW                          0x00000905
#define c32ManualDmaTrigR                        0x0000010D
#define c32ManualDmaTrigW                        0x00000905

#define cNvmeFeatureNotReady                     0x00

#define cAbortSuccess                            0x00
#define cAbortFail                               0x01

// Get Log Page part
#define cEntrySizeErrLog                         64
#define cTotalErrLogEntry                        64
#define cMaxErrLogEnryIdx                        (cTotalErrLogEntry-1)
#define cLogPageSizeErrInfo                      (cTotalErrLogEntry*cEntrySizeErrLog)
#define cLogPageSizeSmart                        512
#define cLogPageSizeFWSlot                       512
#define cLogPageSizeCmdEffect                    4096
#define cLogPageSizeExtSmart                     512
#define cLogPageSizeManufactInfo                 512
#define cLogPageSecCntErrInfo                    (cLogPageSizeErrInfo>>9)
#define cLogPageSecCntSmart                      (cLogPageSizeSmart>>9)
#define cLogPageSecCntFWSlot                     (cLogPageSizeFWSlot>>9)
#define cLogPageSecCntCmdEffect                  (cLogPageSizeCmdEffect>>9)
#define cLogPageSecCntExtSmart                   (cLogPageSizeExtSmart>>9)
#define cLogPageSecCntManufactInfo               (cLogPageSizeManufactInfo>>9)

#define cTotalTemperatureSensor                  8

#define cWarnAvailableSpare                      1
#define cWarnTemperature                         (1<<1)
#define cWarnReliability                         (1<<2)
#define cWarnReadOnly                            (1<<3)
#define cWarnBackup                              (1<<4)

#define cDefaultTempThreshold                    0xFE
#define cDefaultWce                              0
#define cDefaultAsync                            (cWarnAvailableSpare|cWarnTemperature)

// error log
#define cOtherError                              0x00
#define cIoCommandError                          0x01
#define cAdminCommandError                       0x02
#define cInvalidDbError                          0x03

#define cNotReadWpro                             0x00
#define cReadWpro                                cBit1
#define cUpdateFrs                               cBit2
#define cUpdateSlotInfo                          cBit3
#define cUpdateFrsInit                           cBit4

#define cNoneSpecificCmdId                       0xFFFF
#define cNoneIoCmdLba                            0x0000
#define cParaErrLocationOor                      40
#define cParaErrLocationDxe                      40

// firmware slot
#define cFirmwareSlotAfi                         0x00
#define cFirmwareSlot1                           0x01
#define cFirmwareSlot2                           0x02
#define cFirmwareSlot3                           0x03
#define cFirmwareSlot4                           0x04
#define cFirmwareSlot5                           0x05
#define cFirmwareSlot6                           0x06
#define cFirmwareSlot7                           0x07

#define cNoNextActiveFirmwareSlot                0xFF
#define cNextActiveFirmwareSlot1                 0x01
#define cNextActiveFirmwareSlot2                 0x02
#define cNextActiveFirmwareSlot3                 0x03
#define cNextActiveFirmwareSlot4                 0x04
#define cNextActiveFirmwareSlot5                 0x05
#define cNextActiveFirmwareSlot6                 0x06
#define cNextActiveFirmwareSlot7                 0x07

// command effect
#define cLogPageCmdEffCsupp                      c32Bit0    // Command Supported
#define cLogPageCmdEffLbcc                       c32Bit1    // Logical Block Content Change
#define cLogPageCmdEffNcc                        c32Bit2    // Namespace Capability Change
#define cLogPageCmdEffNic                        c32Bit3    // Namespace Inventory Change
#define cLogPageCmdEffCcc                        c32Bit4    // Controller Capability Change
#define cLogPageCmdEffCseSameNs                  c32Bit16    // Command Submission and Execution Value=001b
#define cLogPageCmdEffCseAnyNs                   c32Bit17    // Command Submission and Execution Value=010b

// For Nvme Set/Get Features
// For LBA Range Type feature
#define cLbaRangeEntrySize                       (0x40/4)
#define cLbaRangeSlbaOffset                      (0x10/4)
#define cLbaRangeNlbOffset                       (0x18/4)

enum
{
    cPcieLinkDownReset=0x00,
    cPciePerstReset=0x01,
};

#define cPs0                                     0
#define cPs1                                     1
#define cPs2                                     2
#define cPs3                                     3
#define cPs4                                     4
#define cPsShutdown                              5
#if OEM==HP    // add new PS for Urgent shutdown hang F.J. Kuo 20190401
#define cPsUrgentShutdown                                                6
#endif

// PCIe Link state
#define cLtssmDetQuiet            0x00    // 6 bits
#define cLtssmDetAct              0x01    // 6 bits
#define cLtssmPollActive          0x02    // 6 bits
#define cLtssmPollCompliance      0x03    // 6 bits
#define cLtssmPollConfig          0x04    // 6 bits
#define cLtssmPreDetQuiet         0x05    // 6 bits
#define cLtssmDetWait             0x06    // 6 bits
#define cLtssmCfgLinkWdStart      0x07    // 6 bits
#define cLtssmCfgLinkWdAcept      0x08    // 6 bits
#define cLtssmCfgLaneNumWait      0x09    // 6 bits
#define cLtssmCfgLaneNumAcept     0x0A    // 6 bits
#define cLtssmCfgComplete         0x0B    // 6 bits
#define cLtssmCfgIdle             0x0C    // 6 bits
#define cLtssmRcvryLock           0x0D    // 6 bits
#define cLtssmRcvrySpd            0x0E    // 6 bits
#define cLtssmRcvryRcvrCfg        0x0F    // 6 bits
#define cLtssmRcvryIdle           0x10    // 6 bits

#define cLtssmL0                  0x11    // 6 bits
#define cLtssmL0s                 0x12    // 6 bits
#define cLtssmL123SendEidle       0x13    // 6 bits
#define cLtssmL1Idle              0x14    // 6 bits
#define cLtssmL2Idle              0x15    // 6 bits
#define cLtssmL2Wake              0x16    // 6 bits
#define cLtssmDisabledEntry       0x17    // 6 bits
#define cLtssmDisabledIdle        0x18    // 6 bits
#define cLtssmDisabled            0x19    // 6 bits
#define cLtssmLpbkEntry           0x1A    // 6 bits
#define cLtssmLpbkActive          0x1B    // 6 bits
#define cLtssmLpbkExit            0x1C    // 6 bits
#define cLtssmLpbkExitTimeout     0x1D    // 6 bits
#define cLtssmHotResetEntry       0x1E    // 6 bits
#define cLtssmHotReset            0x1F    // 6 bits

#define cLtssmRcvryEq0            0x20    // 6 bits
#define cLtssmRcvryEq1            0x21    // 6 bits
#define cLtssmRcvryEq2            0x22    // 6 bits
#define cLtssmRcvryEq3            0x23    // 6 bits

#define cLtssmStateEn             (cEnabled<<6)    // 0x40

#define cAspmL0s                  0x01
#define cAspmL1                   0x02

#define cSleepFlow                               0
#define cWakeupFlow                              1

// event from FW flow
// #define mPSChgSetThrottlingInRw                  (gsPowerState.uPsChg|=cBit3)
#define mPSChgSetLink12                          (gsPowerState.uPsChg|=cBit2)
#define mPSChgSetPs34                            (gsPowerState.uPsChg|=cBit1)
#define mPSChgSetThrottling                      (gsPowerState.uPsChg|=cBit0)

// #define mPSChgChkThrottlingInRw                  (gsPowerState.uPsChg&cBit3)
#define mPSChgChkLink12                          (gsPowerState.uPsChg&cBit2)
#define mPSChgChkPs34                            (gsPowerState.uPsChg&cBit1)
#define mPSChgChkThrottling                      (gsPowerState.uPsChg&cBit0)

// #define mPSChgClrThrottlingInRw                  (gsPowerState.uPsChg&=~cBit3)
#define mPSChgClrLink12                          (gsPowerState.uPsChg&=~cBit2)
#define mPSChgClrPs34                            (gsPowerState.uPsChg&=~cBit1)
#define mPSChgClrThrottling                      (gsPowerState.uPsChg&=~cBit0)

// FW power state contrl flow
#define mChkPs4St                                (gsPowerState.uPwrState&cBit2)
#define mChkPs3St                                (gsPowerState.uPwrState&cBit1)
#define mChkStandbySt                            (gsPowerState.uPwrState&cBit0)
#define mChkAllPs                                (gsPowerState.uPwrState&0x07)

#define mSetPs4St                                (gsPowerState.uPwrState|=cBit2)
#define mSetPs3St                                (gsPowerState.uPwrState|=cBit1)
#define mSetStandbySt                            (gsPowerState.uPwrState|=cBit0)

#define mClrPs4St                                (gsPowerState.uPwrState&=~(cBit2))
#define mClrPs3St                                (gsPowerState.uPwrState&=~(cBit1))
#define mClrStandbySt                            (gsPowerState.uPwrState&=~(cBit0))

#define cPowerStateMask                          (0x1F)
#define cPowerStateMaskClr                       (0xFFFFFFE0)
#define cWorkLoadHintMast                        (0xE0)

// event from ISR
#define mNvmeSetD0                               (g32NvmeCondition|=c32Bit18)    // D0
#define mNvmeSetD3                               (g32NvmeCondition|=c32Bit17)    // D3
#define mNvmeSetFeatureRst                       (g32NvmeCondition|=c32Bit16)
#define mNvmeSetNssr                             (g32NvmeCondition|=c32Bit15)    // NSSR reset
#define mPcieSetPerst                            (g32NvmeCondition|=c32Bit14)    // from p11
#define mNvmeSetShn                              (g32NvmeCondition|=c32Bit13)
#define mPcieSetRst                              (g32NvmeCondition|=c32Bit12)    // link down
#define mPcieSetFlr                              (g32NvmeCondition|=c32Bit11)    // FLR
#define mNvmeSetRst                              (g32NvmeCondition|=c32Bit10)    // CCEN 1->0
#define mPcieSetLinkDis                          (g32NvmeCondition|=c32Bit9)    // 2263 was removed, Host Disable Link
#define mSetFwActivate                           (g32NvmeCondition|=c32Bit8)
#define mNvmeSetCcEnOn                           (g32NvmeCondition|=c32Bit5)    // CCEN 0->1

#define mNvmeChkD0                               (g32NvmeCondition&c32Bit18)    // D0
#define mNvmeChkD3                               (g32NvmeCondition&c32Bit17)    // D3
#define mNvmeChkFeatureRst                       (g32NvmeCondition&c32Bit16)
#define mNvmeChkNssr                             (g32NvmeCondition&c32Bit15)    // NSSR reset
#define mPcieChkPerst                            (g32NvmeCondition&c32Bit14)    // from p11
#define mNvmeChkShn                              (g32NvmeCondition&c32Bit13)
#define mPcieChkRst                              (g32NvmeCondition&c32Bit12)    // link down
#define mPcieChkFlr                              (g32NvmeCondition&c32Bit11)    // FLR
#define mNvmeChkRst                              (g32NvmeCondition&c32Bit10)    // CCEN 1->0
#define mPcieChkLinkDis                          (g32NvmeCondition&c32Bit9)    // 2263 was removed,
#define mChkFwActivate                           (g32NvmeCondition&c32Bit8)
#define mNvmeChkCcEnOn                           (g32NvmeCondition&c32Bit5)    // CCEN 0->1

#define mNvmeClrD0                               (g32NvmeCondition&=~c32Bit18)    // D0
#define mNvmeClrD3                               (g32NvmeCondition&=~c32Bit17)    // D3
#define mNvmeClrFeatureRst                       (g32NvmeCondition&=~c32Bit16)
#define mNvmeClrNssr                             (g32NvmeCondition&=~c32Bit15)    // NSSR reset
#define mPcieClrPerst                            (g32NvmeCondition&=~c32Bit14)    // from p11
#define mNvmeClrShn                              (g32NvmeCondition&=~c32Bit13)
#define mPcieClrRst                              (g32NvmeCondition&=~c32Bit12)    // link down
#define mPcieClrFlr                              (g32NvmeCondition&=~c32Bit11)    // FLR
#define mNvmeClrRst                              (g32NvmeCondition&=~c32Bit10)    // CCEN 1->0
#define mPcieClrLinkDis                          (g32NvmeCondition&=~c32Bit9)
#define mClrFwActivate                           (g32NvmeCondition&=~c32Bit8)
#define mNvmeClrCcEnOn                           (g32NvmeCondition&=~c32Bit5)    // CCEN 0->1

// #define mNvmeChkPcieErr                          (g32NvmeCondition&0x0000F620)    // ????

#define mSetStartThrottlingSt                    (g32PcieRstOrErrEvent|=c32Bit17)
#define mChkStartThrottlingSt                    (g32PcieRstOrErrEvent&c32Bit17)
#define mClrStartThrottlingSt                    (g32PcieRstOrErrEvent&=(~c32Bit17))

#define mNvmeSetShnEntry                         (g32PcieRstOrErrEvent|=c32Bit16)
#define mNvmeChkShnEntry                         (g32PcieRstOrErrEvent&c32Bit16)
#define mNvmeClrShnEntry                         (g32PcieRstOrErrEvent&=(~c32Bit16))

// PCIe reset or error event
#define mSetDesFullOnPcieWErrF                   (g32PcieRstOrErrEvent|=c32Bit3)
#define mChkDesFullOnPcieWErrF                   (g32PcieRstOrErrEvent&c32Bit3)
#define mClrDesFullOnPcieWErrF                   (g32PcieRstOrErrEvent&=(~c32Bit3))

#define mSetToDoHdlPcieWErrF                     (g32PcieRstOrErrEvent|=c32Bit2)
#define mChkToDoHdlPcieWErrF                     (g32PcieRstOrErrEvent&c32Bit2)
#define mClrToDoHdlPcieWErrF                     (g32PcieRstOrErrEvent&=(~c32Bit2))

#define mSetHandlePcieErrF                       (g32PcieRstOrErrEvent|=c32Bit1)
#define mChkHandlePcieErrF                       (g32PcieRstOrErrEvent&c32Bit1)
#define mClrHandlePcieErrF                       (g32PcieRstOrErrEvent&=(~c32Bit1))

#define mSetHandlePcieRstF                       (g32PcieRstOrErrEvent|=c32Bit0)
#define mChkHandlePcieRstF                       (g32PcieRstOrErrEvent&c32Bit0)
#define mClrHandlePcieRstF                       (g32PcieRstOrErrEvent&=(~c32Bit0))

// Nvme Status Code Type
#define cStatusDoNotRetry                        c16Bit14
#define cStatusMore                              c16Bit13

#define cStatusGeneric                           0x00
#define cStatusCommandSpecific                   0x01
#define cStatusMediaErr                          0x02
#define cStatusVendorSpecific                    0x07

// Status Code Generic Type

#define cStatusSuccess                           ((cStatusGeneric<<8)|0x00)
#define cStatusInvalidOpCode                     ((cStatusGeneric<<8)|0x01)
#define cStatusInvalidField                      ((cStatusGeneric<<8)|0x02)
#define cStatusCmdIdConflict                     ((cStatusGeneric<<8)|0x03)
#define cStatusDataXfrErr                        ((cStatusGeneric<<8)|0x04)
#define cStatusCmdAbortPwrLoss                   ((cStatusGeneric<<8)|0x05)
#define cStatusDeviceErr                         ((cStatusGeneric<<8)|0x06)
#define cStatusCmdAbortRq                        ((cStatusGeneric<<8)|0x07)
#define cStatusCmdAbortSqDel                     ((cStatusGeneric<<8)|0x08)
#define cStatusCmdAbortFusedFail                 ((cStatusGeneric<<8)|0x09)
#define cStatusCmdAbortFusedMissing              ((cStatusGeneric<<8)|0x0A)
#define cStatusInvalidNsFormat                   ((cStatusGeneric<<8)|0x0B)
#define cStatusCmdSequenceErr                    ((cStatusGeneric<<8)|0x0C)
#define cStatusInvalidSglLsd                     ((cStatusGeneric<<8)|0x0D)
#define cStatusInvalidNumSgl                     ((cStatusGeneric<<8)|0x0E)
#define cStatusInvalidDataSglLen                 ((cStatusGeneric<<8)|0x0F)
#define cStatusInvalidMetaSglLen                 ((cStatusGeneric<<8)|0x10)
#define cStatusInvalidSglDesType                 ((cStatusGeneric<<8)|0x11)
#define cStatusInvalidCtrlMemBuf                 ((cStatusGeneric<<8)|0x12)
#define cStatusInvalidPrpOffset                  ((cStatusGeneric<<8)|0x13)
#define cStatusAtoWriteUintExceeded              ((cStatusGeneric<<8)|0x14)
#define cStatusOperationDenied                   ((cStatusGeneric<<8)|0x15)
#define cStatusSglOffesetInvalid                 ((cStatusGeneric<<8)|0x16)
#define cStatusHostIdInconsistentFormat          ((cStatusGeneric<<8)|0x18)
#define cStatusKeepAliveTimeoutExpired           ((cStatusGeneric<<8)|0x19)
#define cStatusKeepAliveTimeoutInvalid           ((cStatusGeneric<<8)|0x1A)
#define cStatusCmdAbortPreempt                   ((cStatusGeneric<<8)|0x1B)
#define cStatusSanitizeFailed                    ((cStatusGeneric<<8)|0x1C)
#define cStatusSanitizeInProgress                ((cStatusGeneric<<8)|0x1D)
#define cStatusSglDataBlkGranularityInvalid      ((cStatusGeneric<<8)|0x1E)
#define cStatusCmdNotSupportedforQueueinCmb      ((cStatusGeneric<<8)|0x1F)

// Status Code Generic -Nvme Command Set

#define cStatusLbaOutofRange                     ((cStatusGeneric<<8)|0x80)
#define cStatusCapExceeded                       ((cStatusGeneric<<8)|0x81)
#define cStatusNsNotReady                        ((cStatusGeneric<<8)|0x82)
#define cStatusReservationConflict               ((cStatusGeneric<<8)|0x83)
#define cStatusFormatInProgress                  ((cStatusGeneric<<8)|0x84)

// Status Code Generic -Vendor Specific for micron vendor command
#define cStatusMicronCommunicateFail             ((cStatusGeneric<<8)|0xC0)
#define cStatusMicronInvalidCmdField             ((cStatusGeneric<<8)|0xC1)
#define cStatusMicronVuLock                      ((cStatusGeneric<<8)|0xC2)
#define cStatusMicronInvalidInputDataPayload     ((cStatusGeneric<<8)|0xC3)    // L2PTrans, L2PTrans

// Status Code Command Specific

#define cStatusInvalidCq                         ((cStatusCommandSpecific<<8)|0x00)    // Create IO SQ
#define cStatusInvalidQid                        ((cStatusCommandSpecific<<8)|0x01)    // Create/delete IO SQ/CQ
#define cStatusMaxQueExceeded                    ((cStatusCommandSpecific<<8)|0x02)    // Create IO SQ/CQ
#define cStatusAbortCmdExceeded                  ((cStatusCommandSpecific<<8)|0x03)    // Abort
#define cStatusAsyncEventExceeded                ((cStatusCommandSpecific<<8)|0x05)    // Async Event Request
#define cStatusInvalidFwSlot                     ((cStatusCommandSpecific<<8)|0x06)    // Firmware Activate
#define cStatusInvalidFwImage                    ((cStatusCommandSpecific<<8)|0x07)    // Firmware Activate
#define cStatusInvalidIntVector                  ((cStatusCommandSpecific<<8)|0x08)    // Create IO CQ
#define cStatusInvalidLogPage                    ((cStatusCommandSpecific<<8)|0x09)    // Get Log Page
#define cStatusInvalidFormat                     ((cStatusCommandSpecific<<8)|0x0A)    // Format NVM
#define cStatusFwReqCreset                       ((cStatusCommandSpecific<<8)|0x0B)    // Firmware Activate
#define cStatusInvalidQueDeletion                ((cStatusCommandSpecific<<8)|0x0C)    // Delete IO CQ
#define cStatusFeatureIdUnSavable                ((cStatusCommandSpecific<<8)|0x0D)    // Set Features
#define cStatusFeatureUnChangable                ((cStatusCommandSpecific<<8)|0x0E)    // Set Features
#define cStatusFeatureNotNsSpecific              ((cStatusCommandSpecific<<8)|0x0F)    // Set Features
#define cStatusFwReqSReset                       ((cStatusCommandSpecific<<8)|0x10)    // Firmware Activate
#define cStatusFwReqReset                        ((cStatusCommandSpecific<<8)|0x11)    // Firmware Activate
#define cStatusFwReqMaxTimeViolation             ((cStatusCommandSpecific<<8)|0x12)    // Firmware Activate
#define cStatusFwProhibited                      ((cStatusCommandSpecific<<8)|0x13)    // Firmware Activate
#define cStatusOverlappingRange                  ((cStatusCommandSpecific<<8)|0x14)    // Firmware Download & Firmware Activate
#define cStatusNsInsuffCap                       ((cStatusCommandSpecific<<8)|0x15)    // Namespace Management
#define cStatusNsIdUnavailable                   ((cStatusCommandSpecific<<8)|0x16)    // Namespace Management
#define cStatusNsAlrdyAttached                   ((cStatusCommandSpecific<<8)|0x18)    // Namespace Attachment
#define cStatusNsIsProvate                       ((cStatusCommandSpecific<<8)|0x19)    // Namespace Attachment
#define cStatusNsNotAttached                     ((cStatusCommandSpecific<<8)|0x1A)    // Namespace Attachment
#define cStatusNotSupportThinProvisioning        ((cStatusCommandSpecific<<8)|0x1B)    // Namespace Management
#define cStatusInvalidCtrlList                   ((cStatusCommandSpecific<<8)|0x1C)    // Namespace Attachment
#define cStatusDstInProgress                     ((cStatusCommandSpecific<<8)|0x1D)    // Device Self-Test
#define cStatusBootPartitionWrProhibited         ((cStatusCommandSpecific<<8)|0x1E)    // Firmware Commit
#define cStatusInvalidCtrllerId                  ((cStatusCommandSpecific<<8)|0x1F)    // Virtualization Management
#define cStatusInvalid2ndCtrllerState            ((cStatusCommandSpecific<<8)|0x20)    // Virtualization Management
#define cStatusInvalidNumberCtrllerResource      ((cStatusCommandSpecific<<8)|0x21)    // Virtualization Management
#define cStatusInvalidResourceId                 ((cStatusCommandSpecific<<8)|0x22)    // Virtualization Management

// Status Code Command Specific  -Nvme Command Set

#define cStatusConflictAttrb                     ((cStatusCommandSpecific<<8)|0x80)
#define cStatusInvalidPi                         ((cStatusCommandSpecific<<8)|0x81)
#define cStatusWr2RdOnlyRange                    ((cStatusCommandSpecific<<8)|0x82)

// Ststus Code Media Errors - NVM Command Set

#define cStatusWrFault                           ((cStatusMediaErr<<8)|0x80)
#define cStatusUnrecoveredRdErr                  ((cStatusMediaErr<<8)|0x81)
#define cStatusE2eGuardErr                       ((cStatusMediaErr<<8)|0x82)
#define cStatusE2eAppTagErr                      ((cStatusMediaErr<<8)|0x83)
#define cStatusE2eRefTagErr                      ((cStatusMediaErr<<8)|0x84)
#define cStatusCompareFailure                    ((cStatusMediaErr<<8)|0x85)
#define cStatusAccessDenied                      ((cStatusMediaErr<<8)|0x86)
#define cStatusDealloUnwrLogicalBlk              ((cStatusMediaErr<<8)|0x87)

// Status for Intel Peek Poke
#define cStatusIntelPeekPoke                     ((cStatusVendorSpecific<<8)|0xC0)
#define cStatusVuCmdFail                         ((cStatusVendorSpecific<<8)|0xC4)

// Nvme Status Code Definitions End

// Nvme Admin Cmd Prototype Defines Start
extern void(*const NvmeCmdGrp[]) ();

#define cNamespaceAll                            0xFFFFFFFF
// #define cNamespaceCurrId                         0x00000001
#define cNamespaceNotSpecific                    0x00000000

#define cControllerNumber                        0x0001
#define cControllerCurrId                        0x0001

// Nvme Identify subcommand
#define cNvmeIdenActiveNsData                    0x00
#define cNvmeIdenControllerData                  0x01
#define cNvmeIdenActiveNsIds                     0x02
#define cNvmeIdenActiveNsIdenDesc                0x03

#define cNvmeIdenAllocatedNsIds                  0x10
#define cNvmeIdenAllocatedNsdata                 0x11
#define cNvmeIdenAttachedCtrllerIds              0x12
#define cNvmeIdenAllCtrllerIds                   0x13
#define cNvmeIdenPrimaryCtrllerCap               0x14
#define cNvmeIdenSencondaryCtrllerIds            0x15

#define cIgnoreInIdNamespace                     cBit0
#define cIgnoreInIdController                    cBit1

#define cNidtEui64                               0x01
#define cNidtNguId                               0x02
#define cNidtNuuId                               0x03

#define cNidlEui64                               0x08
#define cNidlNguId                               0x10
#define cNidlNuuId                               0x10

// Nvme Features subcommmand
#define cNvmeFeatArbitration                     0x01
#define cNvmeFeatPowerMgmt                       0x02
#define cNvmeFeatLbaRange                        0x03
#define cNvmeFeatTempThresh                      0x04
#define cNvmeFeatErrRecovery                     0x05
#define cNvmeFeatVolatileWc                      0x06
#define cNvmeFeatNumQueues                       0x07
#define cNvmeFeatIrqCoalesce                     0x08
#define cNvmeFeatIrqConfig                       0x09
#define cNvmeFeatWriteAtomic                     0x0A
#define cNvmeFeatAsyncEvent                      0x0B
#define cNvmeFeatAutoPst                         0x0C
#define cNvmeFeatHostMemBuff                     0x0D
#define cNvmeFeatTimerStamp                      0x0E
#define cNvmeFeatKeepAliveTimer                  0x0F
#define cNvmeFeatHostThermalPwrMgmt              0x10
#define cNvmeFeatNonOpPwrStateConfig             0x11
#define cNvmeFeatSwProgress                      0x80
#define cNvmeFeatHostIdentifier                  0x81
#define cNvmeFeatReservationNoticeMask           0x82
#define cNvmeFeatPeservationPersistance          0x83
#ifdef _SUPPORT_FEATURE_DITM    // 20181010_Jesse_01, Add for Dell spec "ENG0013785_A01"
#define cNvmeFeatHdDITM                          0xD4
#endif
#if _ENABLE_SCP_PLP
#define cNvmeFeatScp                             0xD8
#endif
#define cNvmeFeatPlp                             0xF0    // Power lose protection

// Nvme Get Feature Select Field
#define cNvmeGetFeatSelCurrent                   0x00
#define cNvmeGetFeatSelDefault                   0x01
#define cNvmeGetFeatSelSaved                     0x02
#define cNvmeGetFeatSelSc                        0x03    // Supported capabilities

// Nvme Set Feature
#define cNvmeSetFeatSv                           0x80
// Feature Identifier 04h
#define cNumOfTempSensor                         1    // Max 9 Sensors
#define cNumOfTypeSensor                         2
#define cOverTempTh                              0
#define cUnderTempTh                             1
#define cCompositeTempSensor                     0x00
#define cTempSensor1                             0x01
#define cTempSensor2                             0x02
#define cTempSensor3                             0x03
#define cTempSensor4                             0x04
#define cTempSensor5                             0x05
#define cTempSensor6                             0x06
#define cTempSensor7                             0x07
#define cTempSensor8                             0x08
#define cTempAllSensor                           0x0F
#define cOverTempDefault                         0xFFFF
#define cUnderTempDefault                        0x0000

// Timestamp
#define cInitializedByReset                      0
#define cInitializedBySetFeature                 cBit4
#define cSynchNonContinuous                      cBit0
#define cTimestampMax                            0xFFFFFFFFFFFF

// Error Recovery
#define cDulbeEnable                             0x10000

// ===Nvme Get Log==
#define cLogErrInfo                              0x01
#define cLogSmartInfo                            0x02
#define cLogFwSlotInfo                           0x03
#define cLogChangedNsList                        0x04
#define cLogCmdEffect                            0x05
#define cLogSelfTest                             0x06
#define cLogTelemetryHost                        0x07
#define cLogTelemetryController                  0x08
#define cLogDiscovery                            0x70
#define cRsrvNotification                        0x80
#define cLogSanitize                             0x81
#define cLogExtendSmart                          0xCA
#define cLogVendorTelemetry                      0xC6
#define cLogWorkload                             0xD6
#define cLogManufacturingInfo                    0xDF
#define cLogLenovoPageDFh                        0xDF
#define cLogDebug                                0xE6
#define cLogPLPStatistics                        0xF0
#define cLogPowerState                           0xFF

// HMB
#define cHmbPrdLB                                c32Bit16
#define cHmbTsbPath                              c32Bit15
#define cHmbTsbPreOccu                           c32Bit13
#define cHmbAes                                  c32Bit9
#define cHmbReadDir                              c32Bit8
#define cHmbBufflagChk                           c32Bit7
#define cHmbE2EChk                               c32Bit6
#define cHmbByPass                               c32Bit5
#define cHmbBufflagInv                           c32Bit4

#define c32Hmb4bMo                               (c32Bit31|1)

#define cHmbMaxDescEntryCnt                      0x100

#define cMpsSizeSecBased                         0x08
#define c1MSize4kBased                           0x100
#define c2MSize4kBased                           0x200
#define c4MSize4kBased                           0x400
#define c8MSize4kBased                           0x800
#define cSectorSize                              0x200

#define cSetFixGroup1MSize                       0x00
#define cSetFixGroup2MSize                       0x01
#define cSetFixGroup4MSize                       0x02
#define cSetFixGroup8MSize                       0x03
#define cSetFixGroupLLMSize                      0x04

// Firmware Image Download/Commit
#define cImageUpdateNotActivate                  0
#define cImageUpdateActivateNextRst              1
#define cSpecFwSlotActivateNextRst               2
#define cImageUpdateActivateImm                  3
#define cImageReplaceBootPartition               6
#define cBootPartitionActivate                   7

#define cFwCommitSuccess                         cBit0
#define cFidUnderProcess                         cBit1
#define cFidReset                                cBit2
#define cMftaExceed                              cBit3
#define cActivateFail                            cBit4
#define cJudgeSwapIsp                            cBit5
#define cFwSlotMaxNum                            7

/*
   *   Total 17 code bank
   |--------------------------|--
   |  core1 64K*2             | 2
   |--------------------------|--
   |  core0 64K*7             | 7
   |--------------------------|--
   |  Core1 Swap 16K*4        | 1
   |--------------------------|--
   |  UART Swap 64K           | 1
   |--------------------------|--
   |  Security bank 64K*4     | 4
   |--------------------------|--
   |  PS4 resume BootIsp 64K  | 1
   |--------------------------|--
   |  Lightswitch bank 64K    | 1
   |--------------------------|--
   |
   */

#define cTotalIspCodeSize\
    (cCore1IspCodeSize+cCore0IspCodeSize+cCore1SwapCodeSize+\
     cUartTsbCodeSize+cSecurityCodeSize+cDevSlpIspCodeSize+cLsCodeSize)
#define cCore1IspCodeSize                        0x100    // Sector base, 128K
#define cCore0IspCodeSize                        0x380    // Sector base, 448K
#define cCore0IspMainCodeSize                    0x80    // Sector base
#define cCore1SwapCodeSize                       0x80    // Sector base, 64K
#define cUartTsbCodeSize                         0x80    // Sector base, 64K
#define cSecurityCodeSize                        0x200    // Sector base, 256K
#define cDevSlpIspCodeSize                       0x80    // Sector base, 64K
#define cLsCodeSize                              0x80    // Sector base, 64K
#if _EN_AUTHENTICATION
#define cSignatureSize                           0x20    // Sector base, 16K
#else
#define cSignatureSize                           0
#endif
#define cLsCodeAddr (cTotalIspCodeSize-cLsCodeSize)
#define cSSDBinInfoSecAddr (cCore1IspCodeSize+cCore0IspMainCodeSize-gSectorPerPlaneH)    // Sector base

#define cTotalPlaneOfIsp                         (cTotalIspCodeSize/gSectorPerPlaneH)
#define cTotalFwSlotNum                          ((gsLightSwitch.usNvmeLs.usFrmw&0x0F)>>1)

#define cFwUpdateRdLink                          0xFE

#define cReadIspSuccess                          0x00
#define cReadIspUnc                              0x01
#define cReadIspBlkIdMismatch                    0x02
#define cReadIspFail                             0xFF

#define mChkFwCommitSuccess                      (gsFwDlInfo.uFidStatus&cFwCommitSuccess)
#define mSetFwCommitSuccess                      (gsFwDlInfo.uFidStatus|=cFwCommitSuccess)
#define mClrFwCommitSuccess                      (gsFwDlInfo.uFidStatus&=(~cFwCommitSuccess))

#define mChkFidUnderProcess                      (gsFwDlInfo.uFidStatus&cFidUnderProcess)
#define mSetFidUnderProcess                      (gsFwDlInfo.uFidStatus|=cFidUnderProcess)
#define mClrFidUnderProcess                      (gsFwDlInfo.uFidStatus&=(~cFidUnderProcess))

#define mChkFidReset                             (gsFwDlInfo.uFidStatus&cFidReset)
#define mSetFidReset                             (gsFwDlInfo.uFidStatus|=cFidReset)
#define mClrFidReset                             (gsFwDlInfo.uFidStatus&=(~cFidReset))

#define mChkMftaExceed                           (gsFwDlInfo.uFidStatus&cMftaExceed)
#define mSetMftaExceed                           (gsFwDlInfo.uFidStatus|=cMftaExceed)
#define mClrMftaExceed                           (gsFwDlInfo.uFidStatus&=(~cMftaExceed))

#define mChkActivateFail                         (gsFwDlInfo.uFidStatus&cActivateFail)
#define mSetActivateFail                         (gsFwDlInfo.uFidStatus|=cActivateFail)
#define mClrActivateFail                         (gsFwDlInfo.uFidStatus&=(~cActivateFail))

#define mChkJudgeSwapIsp                         (gsFwDlInfo.uFidStatus&cJudgeSwapIsp)
#define mSetJudgeSwapIsp                         (gsFwDlInfo.uFidStatus|=cJudgeSwapIsp)
#define mClrJudgeSwapIsp                         (gsFwDlInfo.uFidStatus&=(~cJudgeSwapIsp))

// Async Event Types
enum
{
    cErrorStatus,
    cSmartHealthStatus,
    cNotice,
    cIoCommandSetSpecificStatus=0x06,
    cVendorSpecific
};

// Async Event Info - Error Status
enum
{
    cWriteToInvalidDoorBellReg,
    cInvalidDoorbellWriteVal,
    cDiagnosticFailure,
    cPersistentInternalErr,
    cTransientInternalErr,
    cFwImageLoadErr,
};

// Async Event Info - SMART/Health Status
enum
{
    cNvmSubssytemReliability,
    cTemperatureThreshold,
    cSpareBelowThreshold,
};

// Async Event Info - Notice
enum
{
    cNamespaceAttributeChanged,
    cFwActivationStarting,
    cTelemetryLogChanged,
};

// Async Event Info - NVM Command Set Specific Status
enum
{
    cReservationLogPageAvailable,
    cSanitizeLogPageAvailable,
};

// g32AsyncEventNotification bit map

// ***********Error Status Type bit 0 ~ 7 **************************
// bit 0  Write to Invalid Doorbell Register
// bit 1  Invalid Doorbell Write Value
// bit 2  Diagnostic Failure
// bit 3  Persistent Internal Error
// bit 4  Transient Internal Error
// bit 5  Firmware Image Load Error

// **********SMART / Health Status Type bit 8 ~ 15 *******************
// bit 8  Spare Below Threshold
// bit 9  Temperature Threshold
// bit 10 NVM subsystem Reliability
// bit 11 Read only
// bit 12 Memory fail

// ********Notice Type bit 16 ~ 23 ******************************
// bit 16 Namespace Attribute Changed
// bit 17 Firmware Activation Starting
// bit 18 Telemetry Log Changed

// ********I/O Command Set specific status Type bit 24 ~ 25**************

// ********Vendor specific Type bit 26 ~ 31 ***************
// separate 32 bit into 5 AER
#define mChkErrorType                            (gsNvmeAer.u32AerEvent&gsNvmeAer.u32AerMask&0x000000FF)
#define mChkSmartType                            (gsNvmeAer.u32AerEvent&gsNvmeAer.u32AerMask&0x0000FF00)
#define mChkNoticeType                           (gsNvmeAer.u32AerEvent&gsNvmeAer.u32AerMask&0x00FF0000)
#define mChkIoType                               (gsNvmeAer.u32AerEvent&gsNvmeAer.u32AerMask&0x03000000)
#define mChkVendorType                           (gsNvmeAer.u32AerEvent&gsNvmeAer.u32AerMask&0xFC000000)
#define mChkAerAllType                           (gsNvmeAer.u32AerEvent&gsNvmeAer.u32AerMask)

#define mClrErrorType                            (gsNvmeAer.u32AerEvent&=0xFFFFFF00)
#define mClrSmartType                            (gsNvmeAer.u32AerEvent&=0xFFFF00FF)
#define mClrNoticeType                           (gsNvmeAer.u32AerEvent&=0xFF00FFFF)
#define mClrIoType                               (gsNvmeAer.u32AerEvent&=0xFCFFFFFF)
#define mClrVendorType                           (gsNvmeAer.u32AerEvent&=0x03FFFFFF)

#define mSetAerErrorTypeMask                     (gsNvmeAer.u32AerMask&=0xFFFFFF00)
#define mSetAerSmartTypeMask                     (gsNvmeAer.u32AerMask&=0xFFFF00FF)
#define mSetAerNoticeTypeMask                    (gsNvmeAer.u32AerMask&=0xFF00FFFF)
#define mSetAerIoTypeMask                        (gsNvmeAer.u32AerMask&=0xFCFFFFFF)
#define mSetAerVendorTypeMask                    (gsNvmeAer.u32AerMask&=0x03FFFFFF)

#define mClrAerErrorTypeMask                     (gsNvmeAer.u32AerMask|=0x000000FF)
#define mClrAerSmartTypeMask                     (gsNvmeAer.u32AerMask|=0x0000FF00)
#define mClrAerNoticeTypeMask                    (gsNvmeAer.u32AerMask|=0x00FF0000)
#define mClrAerIoTypeMask                        (gsNvmeAer.u32AerMask|=0x03000000)
#define mClrAerVendorTypeMask                    (gsNvmeAer.u32AerMask|=0xFC000000)

#define mChkAerWriteInvalidDbReg                 (gsNvmeAer.u32AerEvent&gsNvmeAer.u32AerMask&c32Bit0)
#define mSetAerWriteInvalidDbReg                 (gsNvmeAer.u32AerEvent|=c32Bit0)
#define mClrAerWriteInvalidDbReg                 (gsNvmeAer.u32AerEvent&=~c32Bit0)

#define mChkAerInvalidDbWrite                    (gsNvmeAer.u32AerEvent&gsNvmeAer.u32AerMask&c32Bit1)
#define mSetAerInvalidDbWrite                    (gsNvmeAer.u32AerEvent|=c32Bit1)
#define mClrAerInvalidDbWrite                    (gsNvmeAer.u32AerEvent&=(~c32Bit1))

#define mChkAerDiagnosticFailure                 (gsNvmeAer.u32AerEvent&gsNvmeAer.u32AerMask&c32Bit2)
#define mSetAerDiagnosticFailure                 (gsNvmeAer.u32AerEvent|=c32Bit2)
#define mClrAerDiagnosticFailure                 (gsNvmeAer.u32AerEvent&=(~c32Bit2))

#define mChkAerPersistentInternalErr              (gsNvmeAer.u32AerEvent&gsNvmeAer.u32AerMask&c32Bit3)
#define mSetAerPersistentInternalErr              (gsNvmeAer.u32AerEvent|=c32Bit3)
#define mClrAerPersistentInternalErr              (gsNvmeAer.u32AerEvent&=(~c32Bit3))

#define mChkAerTransientInternalErr              (gsNvmeAer.u32AerEvent&gsNvmeAer.u32AerMask&c32Bit4)
#define mSetAerTransientInternalErr              (gsNvmeAer.u32AerEvent|=c32Bit4)
#define mClrAerTransientInternalErr              (gsNvmeAer.u32AerEvent&=(~c32Bit4))

#define mChkAerSpare                             (gsNvmeAer.u32AerEvent&gsNvmeAer.u32AerMask&c32Bit8)
#define mSetAerSpare                             (gsNvmeAer.u32AerEvent|=c32Bit8)
#define mClrAerSpare                             (gsNvmeAer.u32AerEvent&=(~c32Bit8))

#define mChkAerTemp                              (gsNvmeAer.u32AerEvent&gsNvmeAer.u32AerMask&c32Bit9)
#define mSetAerTemp                              (gsNvmeAer.u32AerEvent|=c32Bit9)
#define mClrAerTemp                              (gsNvmeAer.u32AerEvent&=(~c32Bit9))

#define mChkAerReliability                       (gsNvmeAer.u32AerEvent&gsNvmeAer.u32AerMask&c32Bit10)
#define mSetAerReliability                       (gsNvmeAer.u32AerEvent|=c32Bit10)
#define mClrAerReliability                       (gsNvmeAer.u32AerEvent&=(~c32Bit10))

#define mChkAerReadOnly                          (gsNvmeAer.u32AerEvent&gsNvmeAer.u32AerMask&c32Bit11)
#define mSetAerReadOnly                          (gsNvmeAer.u32AerEvent|=c32Bit11)
#define mClrAerReadOnly                          (gsNvmeAer.u32AerEvent&=(~c32Bit11))

#define mChkAerMemoryFail                        (gsNvmeAer.u32AerEvent&gsNvmeAer.u32AerMask&c32Bit12)
#define mSetAerMemoryFail                        (gsNvmeAer.u32AerEvent|=c32Bit12)
#define mClrAerMemoryFail                        (gsNvmeAer.u32AerEvent&=(~c32Bit12))

#define mChkAerFwActive                          (gsNvmeAer.u32AerEvent&gsNvmeAer.u32AerMask&c32Bit16)
#define mSetAerFwActive                          (gsNvmeAer.u32AerEvent|=c32Bit16)
#define mClrAerFwActive                          (gsNvmeAer.u32AerEvent&=(~c32Bit16))

#define mChkAerTelemetryLog                      (gsNvmeAer.u32AerEvent&gsNvmeAer.u32AerMask&c32Bit18)
#define mSetAerTelemetryLog                      (gsNvmeAer.u32AerEvent|=c32Bit18)
#define mClrAerTelemetryLog                      (gsNvmeAer.u32AerEvent&=(~c32Bit18))

#define mChkAerSanitizeOperation                 (gsNvmeAer.u32AerEvent&gsNvmeAer.u32AerMask&c32Bit25)
#define mSetAerSanitizeOperation                 (gsNvmeAer.u32AerEvent|=c32Bit25)
#define mClrAerSanitizeOperation                 (gsNvmeAer.u32AerEvent&=(~c32Bit25))

// ******** Warning enable by set feature ***************
#define mChkAerSpareWarningEn                    (gsNvmeAer.u32AerCriticalWarning&c32Bit0)
#define mChkAerTempWarningEn                     (gsNvmeAer.u32AerCriticalWarning&c32Bit1)
#define mChkAerReliabilityWarningEn              (gsNvmeAer.u32AerCriticalWarning&c32Bit2)
#define mChkAerReadOnlyWarningEn                 (gsNvmeAer.u32AerCriticalWarning&c32Bit3)
#define mChkAerMemoryFailWarningEn               (gsNvmeAer.u32AerCriticalWarning&c32Bit4)
#define mChkAerNamespaceAttributeNoticeEn        (gsNvmeAer.u32AerCriticalWarning&c32Bit8)
#define mChkAerFwActivationNoticeEn              (gsNvmeAer.u32AerCriticalWarning&c32Bit9)
#define mChkAerTelemtryLogNoticeEn               (gsNvmeAer.u32AerCriticalWarning&c32Bit10)

#define mChgKelvintoCelsius(x)                   ((x)-273)
#define mChgCelsiustoKelvin(x)                   ((x)+273)

#define mChkIsrStateEnable(x)                    (!(x&c32Bit7))

#define mChkTelemetryCtlrInfoLoaded              (gTelemetryCtlrInfo&cBit7)
#define mSetTelemetryCtlrInfoLoaded              (gTelemetryCtlrInfo|=cBit7)
#define mClrTelemetryCtlrInfoLoaded              (gTelemetryCtlrInfo&=(~cBit7))

#define mChkTelemetryCtlrInfoAvail               (gTelemetryCtlrInfo&cBit0)
#define mSetTelemetryCtlrInfoAvail               (gTelemetryCtlrInfo|=cBit0)
#define mClrTelemetryCtlrInfoAvail               (gTelemetryCtlrInfo&=(~cBit0))

// NVMe Self-test
enum
{
    cNvmeShortDst=0x01,
    cNvmeExtendedDst,
    cNvmeVendorSpecific=0x0E,
    cNvmeAbortDst,
};

enum
{
    cOperationNoDstInProgress=0x0,
    cOperationShortDstInProgress,
    cOperationExtendedDstInProgress,
    cOperationVendorSpecific=0xE,
};

enum
{
    cSegment0Initial=0,
    cSegment1RamCheck,
    cSegment2SmartCheck,
    cSegment3VolatileMemoryBackup,
    cSegment4MetadataValidation,
    cSegment5NvmIntegrity,
    cSegment6DataIntegrity,
    cSegment7MediaCheck,
    cSegment8DriveLife,
    cSegment9SmartCheck,
    cSegmentAllDone,
};

// Result for NVMe Device Selt-Test Operation
enum
{
    cOperationComletedNoError=0x00,
    cOperationAbortDstCmd,
    cOperationAbortControllerLevelReset,
    cOperationAbortRemovalNamespace,
    cOperationAbortFormatNvmeCmd,
    cOperationFatalError,
    cOperationCompletedUnknowSegmentFailed,
    cOperationCompletedKnowSegmentFailed,
    cOperationAbortUnknowReson,
    cOperationAbortSanitize,
    cOperationEntryNotUsed=0x0F,
};

#define cSegment1RamCheckFail           cBit0
#define cSegment2SmartCheckFail         cBit1
#define cSegment3VolatileMemBackupFail  cBit2
#define cSegment5NvmIntegrityFail       cBit3
#define cSegment6DataIntegrityFail      cBit4
#define cSegment7MediaCheckFail         cBit5
#define cSegment8DriveLifeFail          cBit6
#define cSegment9SmartCheckFail         cBit7

// 20181206_SamHu_02
#define cDstExtendedTimeReportInMin_256     2    // 2min
#define cDstExtendedTimeReportInMin_512     4    // 4min
#define cDstExtendedTimeReportInMin_1024    8    // 8min

#define cDstShortTime                       30    // 30sec
#define cDstExtendedTime_256                (cDstExtendedTimeReportInMin_256*60-5)    // 2min
#define cDstExtendedTime_512                (cDstExtendedTimeReportInMin_512*60-10)    // 4min
#define cDstExtendedTime_1024               (cDstExtendedTimeReportInMin_1024*60-20)    // 8min

#define cDstLogResultUpdate                         1
#define cDstLogProgressUpdate                       0

// For chkThrottlingPowerState
#define cOutputLog                                  cBit0
#define cIsr1s                                      cBit1

// For Over Temp Check
#define cOverWcTemp                                 cBit0
#define cOverCcTemp                                 cBit1

// For validPrp
#define cValidPrp4kData                             0x01
#define cValidPrpGetLog                             0x02
#define cValidPrpFwImageDl                          0x03
#define cValidPrpCreateQueue                        0x04
#define cValidPrpApst                               0x05

// For Namespace Attachment
#define cNamespaceAttach                            0x00
#define cNamespaceDetach                            0x01

// For Namespace Management
#define cNamespaceCreate                            0x00
#define cNamespaceDelete                            0x01

// For Sanitize
enum
{
    cSanitizeReserved=0,
    cSanitizeExitFailureMode,
    cSanitizeBlockErase,
    cSanitizeOverwrite,
    cSanitizeCryptoErase,
};

enum
{
    cSanitizeNeverStart=0,
    cSanitizeCompleted,
    cSanitizeInProgress,
    cSanitizeFailed,
};

enum
{
    cSanitizeGlobalDataNotErased=0,
    cSanitizeGlobalDataErased,
};

enum
{
    cEraseBlock=0,
    cEraseProgram,
    cEraseVerifyData,
};

#define c32SanitizeAllowCmdBitmap                   0x01001777
#define cSanitizeAbort                              0x02

#define mChkSanitizeState                           (gsSanitizeInfo.uState)
#define mClrSanitizeState                           (gsSanitizeInfo.uState=0)
#define mChkSanitizeInProgress                      (gsSanitizeInfo.uState==cSanitizeInProgress)
#define mSetSanitizeInProgress                      (gsSanitizeInfo.uState=cSanitizeInProgress)
#define mChkSanitizeCompletedNoError                (gsSanitizeInfo.uState==cSanitizeCompleted)
#define mSetSanitizeCompletedNoError                (gsSanitizeInfo.uState=cSanitizeCompleted)
#define mChkSanitizeCommandErr                      (gsSanitizeInfo.uState==cSanitizeFailed)
#define mSetSanitizeCommandErr                      (gsSanitizeInfo.uState=cSanitizeFailed)
#define mChkSanitizeCommandAbort                    (gsSanitizeInfo.uState&cSanitizeAbort)

// For Directive
#define cDirectiveStream                            0x01

#endif    // ifndef __NVMECTRL_H__







