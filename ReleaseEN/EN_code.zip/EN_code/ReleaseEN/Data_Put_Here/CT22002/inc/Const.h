







#ifndef __CONST_H__
#define __CONST_H__

#include "inc/Option.h"

// Common use phrases

#define cLoNibble                                0x0F
#define cHiNibble                                0xF0

#define cBit7                                    0x80
#define cBit6                                    0x40
#define cBit5                                    0x20
#define cBit4                                    0x10
#define cBit3                                    0x08
#define cBit2                                    0x04
#define cBit1                                    0x02
#define cBit0                                    0x01
#define cBit7F                                   0x7F
#define cBitFF                                   0xFF

#define c12BitFF                                 0x0FFF
#define c15BitFF                                 0x7FFF
#define c16BitFF                                 0xFFFF
#define c16Bit15                                 0x8000
#define c16Bit14                                 0x4000
#define c16Bit13                                 0x2000
#define c16Bit12                                 0x1000
#define c16Bit11                                 0x0800
#define c16Bit10                                 0x0400
#define c16Bit9                                  0x0200
#define c16Bit8                                  0x0100
#define c16Bit7                                  0x0080
#define c16Bit6                                  0x0040
#define c16Bit5                                  0x0020
#define c16Bit4                                  0x0010
#define c16Bit3                                  0x0008
#define c16Bit2                                  0x0004
#define c16Bit1                                  0x0002
#define c16Bit0                                  0x0001
#define c16DropH2fTab                            c16Bit15

#define c31BitFF                                 0x7FFFFFFF
#define c32BitFF                                 0xFFFFFFFF
#define c32Bit31                                 0x80000000
#define c32Bit30                                 0x40000000
#define c32Bit29                                 0x20000000
#define c32Bit28                                 0x10000000
#define c32Bit27                                 0x08000000
#define c32Bit26                                 0x04000000
#define c32Bit25                                 0x02000000
#define c32Bit24                                 0x01000000
#define c32Bit23                                 0x00800000
#define c32Bit22                                 0x00400000
#define c32Bit21                                 0x00200000
#define c32Bit20                                 0x00100000
#define c32Bit19                                 0x00080000
#define c32Bit18                                 0x00040000
#define c32Bit17                                 0x00020000
#define c32Bit16                                 0x00010000
#define c32Bit15                                 0x00008000
#define c32Bit14                                 0x00004000
#define c32Bit13                                 0x00002000
#define c32Bit12                                 0x00001000
#define c32Bit11                                 0x00000800
#define c32Bit10                                 0x00000400
#define c32Bit9                                  0x00000200
#define c32Bit8                                  0x00000100
#define c32Bit7                                  0x00000080
#define c32Bit6                                  0x00000040
#define c32Bit5                                  0x00000020
#define c32Bit4                                  0x00000010
#define c32Bit3                                  0x00000008
#define c32Bit2                                  0x00000004
#define c32Bit1                                  0x00000002
#define c32Bit0                                  0x00000001

#define c64BitFF                                 0xFFFFFFFFFFFFFFFF

#define cSuccess                                 1
#define cFail                                    0

#define cSupported                               1
#define cNotSupported                            0

#define cEnabled                                 1
#define cDisabled                                0

#define cMaxFormFactor                           3    // 0(EVB) / 1(2.5inch) / 2(M.2)

#define cInvalid8Bit                             0xFF
#define cInvalid16Bit                            0xFFFF
#define cInvalid32Bit                            0xFFFFFFFF
#define cInvalid64Bit                            0xFFFFFFFFFFFFFFFF

#define cZero                                    0x00

#define cSingleSectorByte                        512
#define cSingleSectorShift                       9
#define cSingleSector                            1

#define cEventLogSize                            2048    // 8192 //for core 0
#define cCore1EventLogSize                       512    // for core 1
#define cLinkLogSize                             512    // for Link issue
#define cCmdListLogSize                          512
#define cFrontEndLogSize                         512
#define cBackEndLogSize                          512
#define cFTLLogSize                              512
#define cEventLogGcInfo                          1024
#define cEventLogCacheInfo                       512
#define cEventLogBadInfo                         512
#define cLogVariableSize                         3072    // 3KB for Event log
#define c32FrontEndVarLogPageAddr               ((cEventLogSize+cLinkLogSize+cCmdListLogSize+cCore1EventLogSize+cBackEndLogSize+cFTLLogSize)*2)
#define c32GcInfoVarLogPageAddr                 ((cEventLogSize+cCore1EventLogSize+cLinkLogSize+cCmdListLogSize)*2+cLogVariableSize)
#define c32CacheInfoVarLogPageAddr              ((cEventLogSize+cCore1EventLogSize+cLinkLogSize+cCmdListLogSize)*2+cLogVariableSize+0x400)
#define c32BadInfoVarLogPageAddr                ((cEventLogSize+cCore1EventLogSize+cLinkLogSize+cCmdListLogSize)*2+cLogVariableSize+0x400+0x200)
#define cRebootDebugSize                         256    // for Link issue with JTAG
#define cCmdHistorySize                          32    // 64x4x4B = 1KB
#define cCrcDataBufferSize                       (1024)
// #define cMaxEventLogPage                         8

#define cCore1EventLogSAddr                      0x00026C00    // 0x00028000 - 5K, start from last 5K of core1 dtcm

#define cLogGC                                   0x80
#define cLogFTL                                  0x81
#define cLogECC                                  0x82
#define cLogBuild                                0x83
#define cLogHost                                 0x84
#define cLogPS                                   0x85
#define cLogRAID                                 0x86
#define cLogAdmin                                0x87
#define cLogError                                0x88
#define cLogRdt                                  0x89
#define cLogThermlPS                             0x8A
#define cLogSYS                                  0x8B
#define cLogPcieErr                              0x8C
#define cLogComErr                               0x8D
#define cLogBaseFW                               0x90
#define cLogCore1                                0xA0
#define cLogTempDebug                            0xAA
#define cLogSecApiDebug                          0xC0
#define cLogSecApiBaseFw                         0xC1
#define cLogSecApiSecurityFw                     0xC2

//  Debug Log priority
#define C_Debug_P1      cBit0
#define C_Debug_P2      cBit1
#define C_Debug_P3      cBit2
#define C_Debug_P4      cBit3
#define C_Log_FTL       cBit4
#define C_Log_GC        cBit5
#define C_Log_Core      cBit6
#define C_Log_IF        cBit7
#define C_Log_SaveMask  0xF3

// Event Save ID
#define CBuildLinkFinish                         1
#define CKeepSaveEventLog                        2

#define cSaveIdSafeShutdown                      1
#define cSaveIdUnsafeShutdown                    2
#define cSaveIdReadEccFail                       3
#define cSaveIdProgramFail                       4
#define cSaveIdEraseFail                         5
#define cSaveIdMarkBad                           6
#define cSaveIdFlushCmd                          7
#define cSaveIdPcieInit                          8
#define cSaveIdCommandError                      9
#define cSaveIdPRPError                          10
#define cSaveIdPeekPokeInt                       11
#define cSaveIdDeviceActiveReset                 12
#define cSaveIdVendorTrig                        14
#define cSaveIdUnsupportCmd                      15
#define cSaveIdReturnFail                        16
#define cSaveIdPSChange                          22
#define cSaveIdPhyErr                            23
#define cSaveIdCore1LogOverflow                  25
#define cSaveIdInvalidDoorbell                   28

#define cSaveIdCPLTimeOut                        47
#define cSaveIdMalformTLP                        48
#define cSaveIdSecurity                          52

#define cSaveIdPhyError                          23
#define cSaveIdReadOnlyMode                      35
#define cSaveIdMemFail                           36
#define cSaveIdNvmeResetDone                     38
#define cSaveIdVdt23Fsh1Fail                     130
#define cSaveIdVdt27Fsh2Fail                     131
#define cSaveIdVdt12FioFail                      132
#define cSaveIdUartRxTrig                        133
#define cSaveIdDmaError                          135
#define cSaveIdTsbBusTimeout                     138
#define cSaveIdCpuBusTimeout                     139
#define cSaveIdPcieAxiWTimeout                   140
#define cSaveIdPcieAxiRTimeout                   141
#define cSaveIdAes2TsbWTimeout                   142
#define cSaveIdAes2TsbRDramTimeout               143
#define cSaveIdAes2TsbRSramTimeout               144
#define cSaveIdTsbEccErr                         146
#define cSaveIdUndefinedErr                      148
#define cSaveIdAbortErr                          149
#define cSaveIdPrefetchErr                       150
#define cSaveIdWdt                               151

#define cTsb0                                    0
#define cTsb1                                    1
#define cCache0                                  2
#define cCache1                                  3
#define cTsbFull                                 4
#define cCacheFull                               5

#define cItcmAddr                                0x00000000
#define cItcmSize                                0x20000    // Itcm-128K
#define cDtcmAddr                                0x00020000
#define cDtcmSize                                0x8000    // DTCM-32K
#define cParaAddr                                0x00030000
#define cParaSize                                0x100    // PARA-256B
#define cStcmAddr                                0x00030100
#define cStcmSize                                0x7F00    // STCM-31.75K

#define cStcmSaveMapInfo                         0x00030800
#define cStcmSsdInfo                             0x00030900
#define cStcmFifo                                0x00031700
#define cFlashDBAddr                             0x8003A300
#define c32GreyBoxBuf                            0x80310000
#define cGreyBoxBufSize                          0x60000
#define cParaTabCnt                              0x100
#define cParaStrongPageOffset                    0xA00    // strong table in Parameter page offset 0xA00
#define cParaWeakPageeOffset                     0xE80    // weak table in Parameter page offset 0xE80
#define cParaRetryTableOffset                    0x1300    // retry table in Parameter page offset 0x1300

#define cDramCacheBias                           (64*2*1024)    // 64M = 128k sector
#define cDataCache0Size                          (2*2*1024)    // default 2MB
#define cDataCache1Size                          (2*2*1024)    // default 2MB
#define cPcieOpromSize                           (2*256)    // 512 sectors; 256KB

#define cMaxCacheUnitSize                        8192    // 8192*4k=32MB

#define cCache0MaxSize                           (30*2*1024)    // sector base-> 30MB (must be 2's power)
#define cCache1MaxSize                           (2*2*1024)    // sector base-> 2MB     for clean & trim

#define cTsbSize                                 1024    // total TSB size
#define cTsbMask                                 (cTsbSize-1)    // 0x3FF

// TSB0
#define cTsb0Addr                                0x40000000    // @0KB
#define cTsb0StartBufIdx                         0
#define cTsb0Size                                768    // 384KB
#define cTsb0Mask                                (cTsb0Size-1)    // 0x1FF

// TSB1
#define cTsb1Addr                                0x40060000    // @384KB
#define cTsb1StartBufIdx                         cTsb0Size
#define cTsb1Size                                256    // 128KB
#define cTsb1Mask                                (cTsb0Size-1)    // 0x1FF

// TSB2
#define cTsb2Addr                                0x40080000    // @512kB
#define cTsb2StartBufIdx                         (cTsb0Size+cTsb1Size)
#define cTsb2Size                                512    // 256KB

// TSB3
#define cTsb3Addr                                0x400C0000    // @768kB
#define cTsb3StartBufIdx                         (cTsb0Size+cTsb1Size+cTsb2Size)
#define cTsb3Size                                512    // 256KB

// TSB4
#define cTsb4Addr                                0x40100000    // @1032kB
#define cTsb4StartBufIdx                         (cTsb0Size+cTsb1Size+cTsb2Size+cTsb3Size)
#define cTsb4Size                                16    // 8K

// TSB5
#define cTsb5Addr                                0x40180000    // 1032kB
#define cTsb5StartBufIdx                         0xC00    // Dont't support NAND DMA data!!!
#define cTsb5Size                                64    // 32K

#define c32DramAddr                              0x80000000
#define c32GreyBoxCore0CodeAddr                  0x80000000
#define c32Core0MainTagDramAddr                  0x8003FFF0
#define c32GreyBoxCodeDramAddr                   0x80180000
#define c32MainCodeDramAddr                      0x801D0000
#define c32GreyBoxCode1CodeAddr                  0x80200000
#define c32Core1ErrHdlTagDramAddr                0x802ffff0
#define c32GreyBoxCore1EndSize                   (((cCore1SmiVu+1)*cSwapCodeSize)+cGreyBoxSwapCodeSize1+cIspCodeEnd)

#define cMainTagSize                             0x10
#define cMaxLdpcLevel                            3    // 1:152B   2:228B  3:248B

#define cMaxHdmaDepth                            32
#define cMaxBopDepth                             4

#define cMaxHDMACnt                              (cFlashSlotFifoDepthR*2)

#define cMaxSPKeepCnt                            7
#define cMaxBKCnt                                (cMaxChNum*cMaxIntlvWay*cMaxSPKeepCnt)

#define cSearchSkipAddr                          0x51004000
// System design

#define cChunkSize                               2048

#define cMaxPlaneNum                             4

#define cMaxPhyChNum                             4

#define cMaxChNum                                4

#define cCePin                                   4
#define cMaxIntlvWayROM                          8
#define cMaxDieNum                               8

#define cMaxIntlvWay                             8    // decrease DCCM size

// Boot
#define cMaxSrchParaLoop                         2
#define cRsv4BootLdr                             1
#define cSizeOfBootLdr                           4    // 2K
#define cSizeOfParaPageId                        10
#define cMaxParaBlkAddr                          3    // 40
#define cParaIncPageNum                          64
#define cSizeOfParaTab                           0x100    // 176
#define c32StpgTabSAddr                          (c32Tsb2SAddr+0x0100)
#define c16SizeOfStpgTab                         0x0400    // 1024
#define cSizeOfOptByte                           128
#define cInfoIdStartPage                         2

#define cMaxPgInDes                              3    // B16: small page - 1; large page - 2.
// #define cMaxPgInDesMask                          0x01
#define cLastPgInDes                             (cMaxPgInDes-1)

// Setting
#define cMaxTotalFBlock                          2048
#define cSlowClock                               50
#define cBlockPerBank                            512
#define cBlockPerBankLog2                        9
#define cMaxBank                                 (cMaxTotalFBlock/cBlockPerBank)
#define cMaxIDNum                                8
#define cMaxZoneNum                              (16/cSbPerUbNum)

// #define cSectorPerUnit2N                         3
#define cSectorPerUnitMask                       0xfffffff8

#define cMaxPagePerBlock                         512

#define cMaxSpareBlkNum                          cMaxTotalFBlock

// useless now
#define cMaxPartition                            4

#define cTaskDepth                               0x10
#define cTaskDepMsk                              0x0F
// NCQ
#define cNCQDepthEC                              32    // 1~32   //10  //how many queue

// #define cHwPrdDepth                            64

// #define cClsDepth                              32
#define cHwPrdDepth                              64    // HW PRD depth
#define cRdHaddrDepth                            cHwPrdDepth
#define cHwPrdEntryCnt                           8

#define cPrdDepth                                128    // Nvme porting (C_ClsDepth*12)           //   32prd =  0.5k
#define cPrdWrSafetyGap                          32
#define cWrStarvationThr                         (cPrdDepth-cPrdWrSafetyGap)
#define cSeqPrdDepth                             128    // 64    // 32
#define cMaxAbortCnt                             5    // Abort cmd limit
#define cMaxIoSqCqCnt                            8    // IO SQ limit 20181126_SamHu Jira135&142
// #define cTotalSqCqCnt                            (cMaxIoSqCqCnt+1)    // Admin=1, IOSQ=CQ=cMaxIoSqCqCnt
#define cMaxErrLogEntryCnt                       64

#define cMaxUnsavedFBlockCnt2                    8
#define cMaxActMode                              2
#define cMaxSkipFBlockCnt                        cMaxTotalFBlock

enum
{
    cReadFlowStsOK=0,
    cReadFlowNoFifoPause
};

enum
{
    cWriteFlowStsOK=0,
    cWriteFlowNoFifoPause,
    cWriteFlowWaitCln,
};

// write HMB
enum
{
    cHmbSkipSetBufFlag=cBit1,
    cHmbDirtyH2f=cBit2,
};

// read F2h of flush cache block
enum
{
    cRdFcbStsSuccess=0,
    cRdFcbStsDummy,
    cRdFcbStsUnc,
    cRdFcbStsWrongId
};

enum
{
    cNormalRead=0,
    cExtraRead,
#if _ENABLE_SECAPI
    cTcgReadOrigin,    // for using RW command to obtain MBR
    cTcgReadUpdated,    // for using Security_Send/Receive
#endif
};

// c16Bit15
#define cClosePrd                                c16Bit14    // => read fifo is closed, then prd fifo can close. (step3)
#define cBigCmd                                  c16Bit13
#define cTrimPrd                                 c16Bit12
// c16Bit11
#define cFlashTrig                               c16Bit10    // read
// c16Bit9
#define cNonCache                                c16Bit8    // write => FUA
#define cUNCCmd                                  c16Bit7    // read
#define cWritePrd                                c16Bit6    // write(1)   read(0)
#define cPrdDone                                 c16Bit5    // write      read            => PRD trig (step1)
#define cPrdFinish                               c16Bit4    // write      read            => PRD complete (step2)
#define cNoReadTail                              c16Bit3    // write
#define cExtraReadPrd                            c16Bit2    // read
#define cSetOccFlg                               c16Bit1    // write
#define cNoReadHead                              c16Bit0    // write

// FUA write flow step
#define cFUACmdReset                             0x00
#define cFUACmdIn                                0x01

#define cFakeWriteCmd                            0x80
#define cFakeReadCmd                             0x40

#define cTrue                                    1
#define cFalse                                   0
#define cSpExit                                  0xFF    // special exit path
#define c16Null                                  0xFFFF
#define cNull                                    0xFF

#define cFuaQueueSize                            64

// swapH2F Setting
#define cWaitReadDone                            cBit0
#define cSetBufferFlag                           cBit1
#define cSetRaidFlag                             cBit2

// FTL Related Constant
#define c32F2hBufSize                            (48*1024)
#define c32CacheF2hRamSize                       (48*1024)
#define c32RaidBufRamSize                        (16*1024)
#define c32RdLinkVarRamSize                      (16*1024)
#define c32H2fTabRamSize                         (64*1024)
#define c32HalfH2fTabRamSize                     (32*1024)
#if _SANDISK_3D_GEN2

#define c16MaxBlockNum                           2048    // 8192  //MIKEY

#define c16FBlockInitValue                       0x7FF    // 2047
#define c32SrcFPageAddrMask                      0x0007FFFF
#define c32SrcFPageAddrBitNum                    19    // 2^19=80000

#define c16MaxH2fTabBlkNum                       32    // 128    // 256
#define c16MaxWLNum                              192
#define cSubBlockNum                             4
#define cHdlOpWLNum                              2

#elif _SANDISK_3D_GEN3

#define c16MaxBlockNum                           1536    // 8192  //MIKEY

#define c16FBlockInitValue                       0x7FF    // 2047
#define c32SrcFPageAddrMask                      0x0007FFFF
#define c32SrcFPageAddrBitNum                    19    // 2^19=80000

#define c16MaxH2fTabBlkNum                       32    // 128    // 256
#define c16MaxWLNum                              256
#define cSubBlockNum                             4
#define cHdlOpWLNum                              2

#elif _TSB_BiCS4
#if _EN_VPC_SWAP
#define c16MaxBlockNum                           2048
#else
#define c16MaxBlockNum                           1024
#endif
#define c16FBlockInitValue                       0x7FF    // 2047
#define c32SrcFPageAddrMask                      0x0007FFFF
#define c32SrcFPageAddrBitNum                    19    // 2^19=80000
#define c16MaxH2fTabBlkNum                       32    // 128    // 256
#define c16MaxWLNum                              384
#define cSubBlockNum                             4
#define cHdlOpWLNum                              2

#elif _TSB_BiCS3

#define c16MaxBlockNum                           2048    // 8192  //MIKEY

#define c16FBlockInitValue                       0x7FF    // 2047
#define c32SrcFPageAddrMask                      0x0007FFFF
#define c32SrcFPageAddrBitNum                    19    // 2^19=80000

#define c16MaxH2fTabBlkNum                       32    // 128    // 256
#define c16MaxWLNum                              256
#define cSubBlockNum                             4
#define cHdlOpWLNum                              2

#else    // if _SANDISK_3D_GEN2

#define c16MaxBlockNum                           1024    // 8192  //MIKEY

#define c16FBlockInitValue                       0x3FF    // 1023
#define c32SrcFPageAddrMask                      0x000FFFFF
#define c32SrcFPageAddrBitNum                    20    // 2^20=100000

#define c16MaxH2fTabBlkNum                       8    // 128    // 256
#define c16MaxWLNum                              384
#define cSubBlockNum                             4
#define cHdlOpWLNum                              2

#endif    // if _TSB_BiCS3

// #define c16HmbMaxGcInfoTableNum                  9
#define c32GcInfoTabSize                         (c32CacheF2hRamSize*2)
#define c32GcInfoTabSctrCnt                      (c32GcInfoTabSize/512)
#define c32HmbTotalGcInfoTableSize               (c32GcInfoTabSize*(cWproGcInfoPage-cWproGcDesF2hTab00+1))    // c16HmbMaxGcInfoTableNum)

// #define c16HmbFlag                            c16Bit15
// #define cHmbReqDept                           64
#define c16HmbPrefSize                           16384
#define c16HmbMinSize                            8192
#define cHmbHwPrdDepth                           32
#define cHmbRacingFreeCnt                        8

#define c32RH2fTabRamSize                        (64*1024)
#define c32RDLinkVarSize                         (48*1024)
#define c32EraseCntTabRamSize                    (c16MaxBlockNum*2)
#define c16BlkNumPerMu                           2048
#define c16MaxSprBlkNum                          1024
#define c16CacheF2hSize                          (c32CacheF2hRamSize/4)    // (64*1024)/4
#define c16RaidBufSize                           (c32RaidBufRamSize/4)
#define c16RdlinkVarBufSize                      c16RaidBufSize
#define c16MaxH2fTabNum                          9216    // 8192    // MIKEY
// #define c16MaxCacheBlkNumInF2hTab                64    // 128//256//(c32CacheF2hRamSize/(128*4))//suppose min block size is 128 page
#define c32CacheF2hStartAddr                     c32Tsb1SAddr
#define c32CacheInfoTabRamSize                   0x8000
// #define c32RdLinkVarStartAddr                    (c32Tsb1SAddr+(c32CacheF2hRamSize)+(c32F2hRsvRamSize)+c32CacheInfoTabRamSize)
#define c32RdLinkVarStartAddr                    (c32Tsb1SAddr+(c32CacheF2hRamSize))
#define c16EraseCntUnitTotalLen                  (c32EraseCntTabRamSize/2)
#define c16CacheF2hTabSIdx                       c16Tsb1SIdx
#define c16RdLinkVarSIdx                         c16Tsb1SIdx
#define c16RaidBufSIdx                           (c16Tsb1SIdx+(c32CacheF2hRamSize/512))
#define c16RH2fTabSIdx                           (c16Tsb1SIdx+(c32CacheF2hRamSize/512)+(c32RaidBufRamSize/512))
#define c16ParitySIdx                            (c16RH2fTabSIdx+((c32RH2fTabRamSize/512)/2))
#define c16GcParitySIdx                          (c16RaidBufSIdx)    // (c16CacheF2hTabSIdx)
// #define c16GcParitySize                          (cCacheF2hTabSctrSize)
#define c16H2fTabSIdx                            (c16Tsb1SIdx+(c32CacheF2hRamSize/512)+(c32RaidBufRamSize/512))
#define c16CacheInfoTabSIdx                      (c16H2fTabSIdx)    // Because of TSB5 can't accessed by flash directly, moving cache info to
// H2F table buffer before programing cache info.
#define c16CacheInfoTabSize                      64    // 32kb, fixed
#define c16CacheInfoVPCSize                      (c16MaxBlockNum>>7)
#define c16CacheInfoRECntSize                ((c32ProgCacheInfo_EraseCntSize+c32ProgCacheInfo_ReadCntSize)>>9)
#define c16CacheInfoAnotherSize              ((c32ProgCacheInfo_PushReclaimQSize+c32ProgCacheInfo_SlcQSize)>>9)

// == for program cacheinfo using ==
#if _EN_VPC_SWAP
#define c32ProgCacheInfo_CacheBlkVpCntStAddr      0    // (cTsb0Addr+((LWORD)c16CacheInfoTabSIdx*0x200))
#define c32ProgCacheInfo_CacheBlkVpCntSize        (c16MaxBlockNum*4)
#define c32ProgCacheInfo_CacheInfoTabStAddr      (c32ProgCacheInfo_CacheBlkVpCntStAddr+c32ProgCacheInfo_CacheBlkVpCntSize)    // (cTsb0Addr+((LWORD)c16CacheInfoTabSIdx*0x200))
#else
#define c32ProgCacheInfo_CacheInfoTabStAddr      0    // (cTsb0Addr+((LWORD)c16CacheInfoTabSIdx*0x200))
#endif
#define c32ProgCacheInfo_CacheInfoTabSize        (c16CacheInfoTabSize*0x200)
#define c32ProgCacheInfo_EraseCntStAddr          (c32ProgCacheInfo_CacheInfoTabStAddr+c32ProgCacheInfo_CacheInfoTabSize)
#define c32ProgCacheInfo_EraseCntSize            sizeof(g16arGlobEraseCnt)
#define c32ProgCacheInfo_ReadCntStAddr           (c32ProgCacheInfo_EraseCntStAddr+c32ProgCacheInfo_EraseCntSize)
#if _EN_VPC_SWAP
#define c32ProgCacheInfo_ReadCntSize             (sizeof(g16arGlobReadCnt)+sizeof(garGlobReadCntHighByte))
#define c32ProgCacheInfo_LowReadCntSize        (sizeof(g16arGlobReadCnt))
#define c32ProgCacheInfo_HighReadCntSize        (sizeof(garGlobReadCntHighByte))
#else
#define c32ProgCacheInfo_ReadCntSize             sizeof(g32arGlobReadCnt)
#endif
#define c32ProgCacheInfo_PushReclaimQStAddr      (c32ProgCacheInfo_ReadCntStAddr+c32ProgCacheInfo_ReadCntSize)
#define c32ProgCacheInfo_PushReclaimQSize        (0x200)    // sizeof(g32arPushReclaimQ) 256B
#define c32ProgCacheInfo_SlcQStAddr              (c32ProgCacheInfo_PushReclaimQStAddr+c32ProgCacheInfo_PushReclaimQSize)
#define c32ProgCacheInfo_SlcQSize                c32SlcQRamSize
// ==							  ==

#define c16GcF2hTabSize                          (8*1024/4)    // c16H2fTabSize
// #define cF2hTabSctrSize                        16
#define cCacheF2hTabSctrSize                     (c32CacheF2hRamSize/512)
#define cGCF2HTableSctrSize                      (c32F2hBufSize/512)

// #define cMinSprBlkCnt                          5//decided by opt
#define c16MaxPushSprbNum                        426
#define cMaxDivPairPageNum                       4    // 7
#define cPredefPairPageGap                       3    // shall be loaded by mp tool
// #define c16RH2fTabSIdx                           (c16Tsb1SIdx+(c32CacheF2hRamSize/512)+(c32H2fTabRamSize/512))

// #define cRH2fTabNum                            64
#define cSprbCnt2ExitGc                          2    // 3
#define cMinGCSprCnt                             16
#define cSprbCnt2ExitGcTab                       1
#define cGcHeadSrcBlk                            0x0000
#define c16GcInfoSize                            (96+96)
#define c16GcSrcBlk0F2hSIdx                      (c16WriteSIdx+c16GcInfoSize)    // 0x0000
// #define cH4kShiftCnt                             3
#define cUncTypeMask                             0x3FFFFFFF
// #define c16GCInfoTabGap                          32
#define c16GcMoveDesAddrIdx                      c16H2fTabSIdx
// #define c16GcMoveSrcFaddrIdx                     (c16H2fTabSIdx+c16GCInfoTabGap)
// #define c16GcMoveSrcAddr                         (c32Tsb0SAddr+c16GcMoveSrcFaddrIdx*512)
#define c16GcMoveDesAddr                         (c32Tsb0SAddr+c16GcMoveDesAddrIdx*512)
#define c16GcFlushF2hIdx                         (c16Tsb1SIdx-(c32CacheF2hRamSize/512))
#define c16GcFlushF2hAddr                        (c32Tsb0SAddr+c16GcFlushF2hIdx*512)

// #define c16LoadPartTabSize                       (8192)
#define c16LoadPartTabSize                       (16384)
#define c16LoadPartTabStcrCnt                    (c16LoadPartTabSize/512)

// #define c4KNumOf8KTab                            2048
// #define cSrcDesPlaneCnt                          (c32CacheF2hRamSize*2/c16LoadPartTabSize)
// #define cDesF2hPlaneCnt                          (c32CacheF2hRamSize/c16LoadPartTabSize)
#if (1)    // _ENABLE_2K_SEGMENT)
#define cMaxRH2fTabNum                           32    // cRH2fTabNum
#define cSctrPerRH2fTab                          (2048/512)

#define c16RH2fTabRamSize                        (2048)
#define c16RH2fTabSize                           (c16RH2fTabRamSize/4)

#define cSeparaeH2fBound                         (16)
#else
#define cMaxRH2fTabNum                           64
#define cSctrPerRH2fTab                          (1024/512)
#define c16RH2fTabSize                           (1024/4)
#define cSeparaeH2fBound                         (32)
#endif

#define c16GcPartialDesF2hRamSize                (16*1024)
#define c16GcPartialTlcPgPerF2hTab               (c16GcPartialDesF2hRamSize>>2)
#define c16FlushGcDesF2hSctrSize                 (256*2)

#define cSctrPer4k                               8
#define c16BufPtrAlign4k                         0xFFF8
#define c16SctrPerRH2fTab                        (c16RH2fTabSize*cSctrPer4k)
#define c4KPerRH2fTab                            (c16SctrPerRH2fTab/cSctrPer4k)
#define cSctrTo4kShift                           (3)
#define cSctrToEccUShift                         (2)

#define cSeqReadCmdThr                           6
#define cSeqReadAheadThr                         3
#define c16SeqWriteSizeThr                       32768
#define cDiffCacheSize                           8
#define c16MaxPwrOnRefreshPageNum                2048    // 4ch*4way*4plane*7pgs*4*2blk
// #define cHPageShiftCnt                           3
#define cMaxF2hPBitTabNum                        5    // 8kb
#define c32FBlockInitValue                       0x3FF00000

#define c32FBlockUncBit                          0x80000000

#define c16MaxGcPagePerBank                      0x4000
#define cInvaildCh                               0xFF
#define cWearLevelThr                            200
#define cWearLevelBound                          (cWearLevelThr/2)
#define c16MaxH2fTabShiftNum                     4

enum
{
    cWriteFunc,
    cReadFunc,
    cMainFunc,
    cDlyRetSts,
};

enum
{
    cWriteChild,
    cWriteCache,
    cWriteNewMother,
    cWriteH2fTab,
    cWriteCacheInfoTab,
    cWriteLinkTab,
    cWriteWpro,
    cWriteGcDes,
    cWriteGcInfo,
    cWriteGcTLCDes,
    cWriteRaid,
    cWriteRaidGc,
};

enum
{
    cCacheF2hTab,
    cChildF2hTab,
};

// Pcie Error

enum
{
    cErrPostRwTaskToPrdInfo=c32Bit0,
    cErrChkWriteDataDone=c32Bit1,
    cErrInitNewFblkProc=c32Bit2,
    cErrActiveCacheBlockInvaild=c32Bit3,
    cErrRebuLostF2h=c32Bit4,
    cErrRecovLastHInfo=c32Bit5,
    cErrReCalcuFlushF2hSize=c32Bit6,
    cErrDelayTrigHost=c32Bit7,
    cErrChkChgBlock=c32Bit8,
    cErrBrkWaitF2h=c32Bit9,
    cErrBrkFindSrcReadH2f=c32Bit10,
    cErrBrkReadNopCopyHead=c32Bit11,
    cErrBrkReadNopCopyTail=c32Bit12,
    cErrBrkReadNopHead=c32Bit13,
    cErrBrkReadNopTail=c32Bit14,
    cErrBrkReadNopBfPostWr=c32Bit15,
    cErrBrkAddNewDesHead=c32Bit16,
    cErrBrkWaitflushCache=c32Bit17,
    cErrRollbackF2hPtr=c32Bit20,
    cErrCancelPartWork=c32Bit21,
    cErrTrigFlushF2h=c32Bit22,
    cErrFlushF2h=c32Bit23,
    cErrReCalPartWork=c32Bit24,
    cErrInPCIeIsrEvent=c32Bit29,
    cErrInPCIEWrtie=c32Bit30,
    cErrInPCIERead=c32Bit31,
};

// Glob Constant
#define cMaxCePinNum                             8
// #define cMaxChNum                              4
// #define cMaxIntlvWay                           4//cMaxCePinNum
#define cMaxPlaneNum                             4
#define cMax4kNum                                8    // B0KB 32KB (2 planes per page)
#define cRsvSysBlkNum                            8
#define cRsvInfoIspBlkNum                        2
#define cSprByteNum                              24
#define cSprSpace                                32
#define cExtSprByteNum                           (cSprByteNum+2)
#define cClsDepth                                cHwPrdDepth
// #define cPrdDepth                                (64+4)
#define cReadFifoDpt                             128
#define cReadSafetyFifoDpt                       (cReadFifoDpt-6)
#define c16MskRptF2hOfstDpt                      (128*cMax4kNum)    // cWriteFifoDpt<128
#define cWriteFifoDpt                            64
#define cMaxChFifoDepth                          (cMaxIntlvWay*4)
#define cMaxChFifoRDepth                         32
#define cMaxCeFifoRDepth                         cMaxChFifoRDepth
#define cMaxQDept                                cClsDepth
#define cSrchSrcNum                              (cMaxQDept*8)
#define cHdmaFifoDpt                             32
#define cMaxReadRgnNum                           256
#define cSizeOfSkipRam                           4096
// #define cMaxFreeHSgmtNum                         cMaxRH2fTabNum
#define cMaxPfHdlNum                             16
#define cMaxHdmaQNum                             64

// #define cMaxRsvSpareBlkNum                      64
#define cScrubQueDepth                           4

// #define cMaxUnitPerPageH                       8   // 4unit per page
#define cMaxUnitPerPageH                         16    // 16K 4Plane
#define cMaxCleanDepth                           32
#define cMaxPartitionPerPage                     (cMaxUnitPerPageH/2)

#define cPageSerialTh                            256    // 256 (whole byte)

// #define cDmaTsb2Tsb                              0
// #define cDmaTsb2Bvci                             1
// #define cDmaBvci2Tsb                             2
// #define cDmaBvci2Bvci                            3
// #define cDmaTsb2Dccm                             4
// #define cDmaDccm2Tsb                             5
// #define cDmaICCM2Tsb                             6
// #define cDmaTsb2Iccm                             7
// #define cDmaTsb2Stcm                             8
// #define cDmaStcm2Tsb                             9
// #define cDmaPattern2Bvci                         10 //(KT) - New add for Dram Ecc program pattern
// #define cDmaPattern2Tsb                          11 //(KT) - New add for Dram Ecc program pattern
// #define cDmaTsb2Cpu1Dccm                         12
// #define cDmaCpu1Dccm2Tsb                         13
// #define cDmaCpu1Iccm2Tsb                         14
// #define cDmaTsb2Cpu1Iccm                         15
// #define cCmpTsb2Bvci                             16

// #define cPauseEn                                 1
// #define cPauseDis                                0

// #define cHdmaParity2Tsb                          0x20
// #define cHdmaParity2Bvci                         0x30

// #define cMinMode                                 0x00
// #define cMaxMode                                 0x01
// #define cEqualMode                               0x02
// #define cStatisticsMode                          0x03

// #define cByteMode                                0x00
// #define cWordMode                                0x04
// #define cLWordMode                               0x08

// #define cReturnOffset                            0x00
// #define cReturnValue                             0x01
// #endif

// Spr Block
#define cIdle                                    0
#define cPopMaxErsCnt                            cBit0
#define cPopMinErsCnt                            cBit1
#define cPopSlcBlock                             cBit2
#define cPopSkipChkSts                           cBit3
#define cPopDataBlock                            cBit4
#define cPopSkipErsCmd                           cBit5
#define cPopLargeErsCnt                          cBit6
#define cPopActCacheBlk                          cBit7    // for read count
#define cPushNotErase                            cBit0
#define cPushWithErase                           cBit1
#define cPushDataBlock                           cBit2
#define cPushSlcBlock                            cPopSlcBlock
#define cPushJudgeMaxSlc                         cBit3
#define cPushDecMaxSlc                           cBit4

// MarkBad
#define cBadInfoBufSctrCnt                       (g4kNumPerPlane<<3)
// last 512 store gsWproInfo
#define cBadInfoRamSize                          (((cBadInfoBufSctrCnt-10)*512)-32)
#define cBadBlockMapOffset                       (((cBadInfoBufSctrCnt-2)*512)/4)
#define cNandQueueWordOffset                     ((((cBadInfoBufSctrCnt-10)*512)-32)/2)

#define cMarkBadCntOfst                          0
#define cMarkBadBufOfst                          4
#define cMarkBadVerOfst                          15
#define cMarkBadStart                            16
#define cMarkBadSize                             16
#define cEccFailQuedpth                          16
#define cEraseFailQueDpth                        4
#define cEraseFailID                             cBit7
#define cRdEccFailID                             0
#define cMarkBadID_Filter                        0xF0
#define cS2TPWRFailID                            0xF1
#define cReclaimReadFailID                       0xF2
#define cGcMoveDataReadFailID                    0xF3
#define cGcFingerFailID                          0xF4
#define cTLCRdEccFailID                          0xFE
#define cProgFailHighID                          0xE0
#define cProgFailSLCID                           0xE0
#define cProgFailReProgID                        0xE1
#define cProgFailH2fID                           0xE2
#define cProgFailGcDesID                         0xE3
#define cProgFailWproID                          0xE4
#define cProgFailParityID                        0xE5
#define cProgFailOtherID                         0xEE
#define cDgIspTsb0Offset                         0x38000

// wpro
#if 1

/* TSB0
   *                -----------------------
   * 0x00000000 | gsCacheInfo, size : 0x100
   *                -----------------------
   * 0x00000100 | gsGcInfo, size : 0x400
   *                -----------------------
   * 0x00000500 | gsWproInfo, size : 0x200
   *                -----------------------
   * 0x00000700 | gsRwCtrl, size : 0x1400
   *                -----------------------
   * 0x00001B00 | gsHMBInfo, size : 0x1000
   *                -----------------------
   * 0x00002B00 | skip ram, size : 0x1000
   *                -----------------------
   * 0x00003B00 | erase count & g32arPushReclaimQ, size : 0x1000
   *                -----------------------
   * 0x00004B00 | g32arSrcInCacheFlag, size: 0x800
   *                -----------------------
   * 0x00005300 | read count, size : 0x2400
   *              -----------------------
   * 0x00007700 | g32arGcSrcBlkBitMap, size : 0x100
   *              -----------------------
   * 0x00007800 |Gc Invalid Page Bit Map, size : 0x4000
   *              -------------------------
   * 0x0000B800 | SlcQ,       size : 0x1000
   *
   * 0x0000C800 | gsRaidInfo, size : 0x800
   *              ------------------------
   * //// 0x0000BF00 | gsRdCntCtrl, size 0x80
   *              ------------------------
   * 0x0000D000 | g32arHmbCrc, size 0x800
   *              ------------------------
   * 0x0000D800 | g32arGcDataCrc, size 0x600
   *              ------------------------
   * 0x0000DE00 | g32arGcInfoCrc, size 0x200
   *              ------------------------
   * 0x0000E000 | g32arGcPtyCrc, size 0xC00
   *              ------------------------
   * 0x0000EC00 | cCacheF2hTab, size 0xC000
   *              ------------------------
   * 0x0001AC00 | cCacheInfoTab, size 0x8000
   *              ------------------------
   * 0x00022C00 | Raid Eng0 Pty, size 0x4000
   *              ------------------------
   * 0x00026C00 | Raid Eng1 Pty, size 0x4000
   *              ------------------------
   * 0x0002AC00 | Raid Eng2 Pty, size 0x4000
   *              ------------------------
   * 0x0002EC00 | Raid Eng3 Pty, size 0x4000
   *              ------------------------
   * 0x00032C00 | Raid Eng4 Pty, size 0x4000
   *              ------------------------
   * 0x00036C00 | Raid Eng5 Pty, size 0x4000
   *              ------------------------
   * 0x0003AC00 | Raid Eng6 Pty, size 0x4000
   *              ------------------------
   * 0x0003EC00 | Raid Eng7 Pty, size 0x4000
   *              ------------------------
   * 0x00042C00 | Raid Eng8 Pty, size 0x4000
   *              ------------------------
   * 0x00046C00 | Raid Eng9 Pty, size 0x4000
   *              ------------------------
   * 0x0004AC00 | Raid Eng10 Pty, size 0x4000
   *              ------------------------
   * 0x0004EC00 | Raid Eng11 Pty, size 0x4000
   *
   * 0x00052C00 | End
   */

#define c32DccmSAddr                             0x20000
#define c32CacheInfoVarAddr                      0x00000000
#define c32CacheInfoVarSize                      0x100    // 0xb8
#define c32GcInfoVarAddr                         (c32CacheInfoVarAddr+c32CacheInfoVarSize)
#define c32GcInfoVarSize                         0x00000400    // 0x2b4
#define c32WproInfoVarAddr                       (c32GcInfoVarAddr+c32GcInfoVarSize)
#define c32WproInfoVarSize                       0x00000200    // 0x16c
#define c32RwCtrlVarAddr                         (c32WproInfoVarAddr+c32WproInfoVarSize)
#define c32RwCtrlVarSize                         0x00001400    // 0x106c
#define c32HMBInfoVarAddr                        (c32RwCtrlVarAddr+c32RwCtrlVarSize)
#define c32HMBInfoVarSize                        0x00001000    // 0x0888   // but can't copy from core0 dtcm
#define c32SkipRamVarAddr                        (c32HMBInfoVarAddr+c32HMBInfoVarSize)
#define c32SkipRamVarSize                        0x00001000    // 0x1000
#define c16SkipRamVarSctrAddr                    (c32SkipRamVarAddr>>9)
#define c32EraseCntVarAddr                       (c32SkipRamVarAddr+c32SkipRamVarSize)
#define c32EraseCntVarSize                       0x00001000    // 0x1000
#define c32SrcInCacheFlagAddr                    (c32EraseCntVarAddr+c32EraseCntVarSize)
#define c32SrcInCacheFlagVarSize                 0x00000800    // 0x480
#define c32ReadCntVarAddr                        (c32SrcInCacheFlagAddr+c32SrcInCacheFlagVarSize)
#if _EN_VPC_SWAP
#define c32LowReadCntVarSize                        0x00001000    // 0x2000 + 0x100 //
#define c32HighReadCntVarSize                        0x00000800    // 0x2000 + 0x100 //
#define c32ReadCntVarSize                        0x00002400    // 0x2000 + 0x100 //
#else
#define c32ReadCntVarSize                        0x00002400    // 0x2000 + 0x100 //
#endif
#define c32GcSrcBlkBitMapAddr                    (c32ReadCntVarAddr+c32ReadCntVarSize)
#define c32GcSrcBlkBitMapSize                    0x00000100    // 0x100
#if _EN_VPC_SWAP
#define c32SlcQStAddr                            (c32GcSrcBlkBitMapAddr+c32GcSrcBlkBitMapSize)    // (c32GcInvalidPageBitMapAddr+c32GcInvalidPageBitMapSize)
#else
#define c32GcInvalidPageBitMapAddr               (c32GcSrcBlkBitMapAddr+c32GcSrcBlkBitMapSize)
#define c32GcInvalidPageBitMapSize               0x00004000    // 0x4000
#define c32SlcQStAddr                            (c32GcInvalidPageBitMapAddr+c32GcInvalidPageBitMapSize)
#endif
#define c32SlcQRamSize                           0x00001000    // 0x1000
#define c32RaidInfoAddr                          (c32SlcQStAddr+c32SlcQRamSize)
#define c32RaidInfoSize                          0x00000800    // 0x420
// #define c32RdCntCtrlAddr                         (c32RaidInfoAddr+c32RaidInfoSize)
// #define c32RdCntCtrlSize                         0x00000080
#define c32HmbH2fCrcAddr                         (c32RaidInfoAddr+c32RaidInfoSize)
#define c32HmbH2fCrcSize                         0x00000800    // 0x800
#define c32HmbGcDataCrcAddr                      (c32HmbH2fCrcAddr+c32HmbH2fCrcSize)
#define c32HmbGcDataCrcSize                      0x00000600    // 0x600
#define c32HmbGcInfoCrcAddr                      (c32HmbGcDataCrcAddr+c32HmbGcDataCrcSize)
#define c32HmbGcInfoCrcSize                      0x00000200    // 0x198
#define c32HmbGcPtCrcAddr                        (c32HmbGcInfoCrcAddr+c32HmbGcInfoCrcSize)
#define c32HmbGcPtCrcSize                        0x00000c00    // 0xbc0
#if _EN_VPC_SWAP
#define c32GcInvalidPageBitMapAddr               (c32HmbGcPtCrcAddr+c32HmbGcPtCrcSize)
#define c32GcInvalidPageBitMapSize               0x00004000    // 0x4000
#if (_EN_GCPWR&&(!_EN_RAID_GC))
#define c32QBVarSize                             0x00011000    // 0x0000EC00    // 0x0000D000
#else
#define c32QBVarSize                             0x0000D000    // 0x0000D000
#endif
#else
#define c32QBVarSize                             0x0000EC00    // 0x0000D000
#endif
#define c32QBVarSctrSize                         (c32QBVarSize>>9)
#define c32QBRaidStAddr                          (c32QBVarSize+c32CacheF2hRamSize+c32CacheInfoTabRamSize)
#define c32QBRaidPtySize                         0x00004000
#define cWriteChNum                              2

#define c32SlcQRamAddr                           0x00021000

#else    // if 1
/* TSB0
   *                -----------------------
   * 0x00000000 | gsCacheInfo, size : 0x400
   *                -----------------------
   * 0x00000400 | gsGcInfo, size : 0x400
   *                -----------------------
   * 0x00000800 | gsWproInfo, size : 0x400
   *                -----------------------
   * 0x00000C00 | gsRwCtrl, size : 0x1000
   *                -----------------------
   * 0x00001C00 | gsHMBInfo, size : 0x2000
   *                -----------------------
   * 0x00003C00 | skip ram, size : 0x1000
   *                -----------------------
   * 0x00004C00 | erase count, size : 0x1000
   *                -----------------------
   * 0x00005C00 | g32arSrcInCacheFlag, size: 0x800
   *                -----------------------
   * 0x00006400 | read count, size : 0x4000
   *                -----------------------
   * 0x0000A400
   */

#define c32DccmSAddr                             0x20000
#define c32CacheInfoVarAddr                      0x00000000
#define c32CacheInfoVarSize                      0x400
#define c32GcInfoVarAddr                         (c32CacheInfoVarAddr+c32CacheInfoVarSize)
#define c32GcInfoVarSize                         0x00000400
#define c32WproInfoVarAddr                       (c32GcInfoVarAddr+c32GcInfoVarSize)
#define c32WproInfoVarSize                       0x00000400
#define c32RwCtrlVarAddr                         (c32WproInfoVarAddr+c32WproInfoVarSize)
#define c32RwCtrlVarSize                         0x00001000
#define c32HMBInfoVarAddr                        (c32RwCtrlVarAddr+c32RwCtrlVarSize)
#define c32HMBInfoVarSize                        0x00002000
#define c32SkipRamVarAddr                        (c32HMBInfoVarAddr+c32HMBInfoVarSize)
#define c32SkipRamVarSize                        0x00001000
#define c16SkipRamVarSctrAddr                    (c32SkipRamVarAddr>>9)
#define c32EraseCntVarAddr                       (c32SkipRamVarAddr+c32SkipRamVarSize)

#define c32EraseCntVarSize                       0x00001000    // c16MaxBlockNum*2
#define c32SrcInCacheFlagAddr                    (c32EraseCntVarAddr+c32EraseCntVarSize)
#define c32SrcInCacheFlagVarSize                 0x00000800
#define c32ReadCntVarAddr                        (c32SrcInCacheFlagAddr+c32SrcInCacheFlagVarSize)
#define c32ReadCntVarSize                        0x00004000

#define c32QBVarSize                             0x0000A000
#define c32QBVarSctrSize                         (c32QBVarSize>>9)
#define cWriteChNum                              2
#endif    // if 1

// For PS4 backup used, (Core0 DCCM)
#define cPs4Core0DccmBkSize                      (5120)    // 5KB, size fix in icf
#define cGsMpInfoAddr                            (c32DccmSAddr+0x00)
#define cGarErrorLogAddr                         (cGsMpInfoAddr+sizeof(MPINFO))
#define cGsSmartAddr                             (cGarErrorLogAddr+(sizeof(ERRORINFO)*cMaxErrLogEntryCnt))
#define cGsPowerStateAddr                        (cGsSmartAddr+sizeof(SMARTATTRIBUTE))
#define cGarApstCurrtentAddr                     (cGsPowerStateAddr+sizeof(POWERSTATE))
#define cGsNvmeAer                               (cGarApstCurrtentAddr+(sizeof(APSTTABLE)*4))
#define cGps4ValAddr                             (cGsNvmeAer+(sizeof(NVMEAERSTR)))

// For PS4 backup used, (STCM)
#define cPs4StcmBkSize                           (512)    // 512B, size fix in icf
#define cGsWproInfoAddr                          (cParaAddr+cSizeOfParaTab+0x00)
#define cG16arCurrSysBlkEsCntAddr                (cGsWproInfoAddr+sizeof(WPROINFO))
#define cGps4StcmValAddr                         (cG16arCurrSysBlkEsCntAddr+(sizeof(WORD)*cRsvSysBlkNum))

// System Related Constant

#define c32IccmSAddr0                            0x01000000    // 0x01800000
#define c32DccmSAddr0                            (0x01800000-0x20000)    // (0x01820000-0x20000)
#define c32StcmSAddr0                            (0x01810000-0x30000)    // (0x01000000-0x30000)
#define c32IccmSAddr1                            0x03000000    // 0x03800000
#define c32DccmSAddr1                            (0x03800000-0x20000)    // (0x03820000-0x20000)
#define c32StcmSAddr1                            (0x03810000-0x30000)    // (0x03000000-0x30000)
#define c32Tsb0SAddr                             0x40000000
#define c32Tsb1SAddr                             0x40060000
#define c32Tsb2SAddr                             0x40180000
#define c32RaidBufSAddr                          0x4006C000
#define c32CacheInfoSAddr                        0x40180000
#define c32H2f0SAddr                             0x40070000
#define c32TsbTempCrcAddr                        0x40100800
#define c32TsbCrcAddr                            0x40140000
// #define c32H2f1SAddr                             c32Tsb2SAddr
#define c32TsbCore1SwapAddr                      c32RaidBufSAddr    // 0x40040000

#define c32CopySAddr                             c32Tsb0SAddr

#define c32IccmSizeByte                          0x00020000
#define c16DccmSizeByte                          0x8000
#define c32Tsb0SizeByte                          0x00060000
#define c32Tsb1SizeByte                          0x00020000
#define c16Tsb2SizeByte                          0x8000
#define c16StackSizeByte                         0x0A00    // 0x0800//0x0400
#define c16RomVarSize                            (1200+64)    // 0x0570//0x0270(ROMVar+ParaPage)
#define c16SeedTableSize                         0x0600
#define c32Tsb2ParaAddr                          (c32Tsb2SAddr+0x6800)
#define c32Tsb2SeedAddr                          (c32Tsb2SAddr+0x6800+cSizeOfParaTab)
#define c32Ps4BootIspCodeSize                    0x4800    // 18KB //0x1000 // 4KB
#define c32Tsb2Ps4BkAddr                         (c32Tsb2SAddr+c32Ps4BootIspCodeSize)

#define c16Tsb0Size                              0x0300    // ??
#define c16Tsb1Size                              0x0100    // ??
// #define cTsb2Size                                0x10  //??
#define c16Tsb0SIdx                              0x0000    // ??
#define c16Tsb1SIdx                              0x0300    // ??
#define c16Tsb2SIdx                              0x0C00    // ??
#define c16TsbTempCrcIdx                         0x0804
#define c16TsbCore1SIdx                          c16RaidBufSIdx    // 0x0200

#define cSkipRamSize                             0x08    // ??
#define cCacheF2hSctrSize                        (c32CacheF2hRamSize>>9)
#define cCacheInfoTabSctrSize                    (c16CacheInfoTabSize)
#define cDccmSctrSize                            (c16DccmSizeByte>>9)

#define c16WriteBufSize                          0x0300
#define c16ReadBufSize                           0x0300
#define c16GcH2fBufSize                          0x0300

#define c16ReadBufSize4K                         (c16ReadBufSize/8)
#define c16WriteSIdx                             0x0000
#define c16ReadSIdx                              c16WriteSIdx
#define c16CopySIdx                              c16ReadSIdx
#define c16CopyBufSize                           (c16WriteBufSize/2)
#define c16GcDesF2hSIdx                          (c16Tsb0SIdx)
#define c16GcSrcF2hSIdx                          (c16Tsb0SIdx+cCacheF2hSctrSize)
#define c16GcBuSrcH2fIdx                         (c16Tsb0SIdx+cCacheF2hSctrSize*3)    // 64K
#define c16GcBuSrcH2fAddr                        (c32Tsb0SAddr+c16GcBuSrcH2fIdx*512)
#define c512KBytes                               0x80000
// Flash Related Constant
#define cSprGrpOffset                            0x1C
#define cPollMaskNor                             0x60
#define c16DefTempRegVal                         0x0000    // 0xFFFF

// Block ID
// #define cInfoBlockID                             0xE1
// #define cDMDesBlockID                            cProgBlockID

// #define cBopSrchDept                           (cMaxQDept+8)
#define cPostTabDept                             cPrdDepth
#define cPostSrcDept                             cPrdDepth
#define cH2fSgmtRdyDept                          (cMaxRH2fTabNum*2)
#define cSrchQDepth                              128
#define cSrchEnginDepth                          32

// rebu
#define cMaxMigrateBlkNum                        2
enum
{
    cCacheBlockID,    // 0
    cF2hTableID,    // 1
    cCacheInfoTableID,    // 2
    cH2fTableID,    // 3
    cWPROBlockID,    // 4
    cRaidParityID,    // cIndexBlockID, //5
    cBadInfoBlockID,    // 6
    cGcDesBlockID,    // 7
    cLogInfoBlockID,    // 8
    cDummyDataID,    // 9
    cQBootBlockID,    // 10
    cProgBlockID,    // 11
    cSanitizeOwID,    // 12
    cRDT_BlockID=0x44,
};

#define cGreyBoxBlockID         0xAA

enum
{
    cGreyBoxH2f,
    cGreyBoxDtcmCore0,
    cGreyBoxDtcmCore1,
    cGreyBoxStcm,
    cGreyBoxCachInfo,
    cGreyBoxF2h,
    cGreyBoxGbInfo,
    cGreyBoxAddrInfo,
    cGreyBoxDummy,
};

enum
{
    cSysBlock1stInfo,
    cSysBlock2ndInfo,
    cSysBlockMPInfo,
    cSysBlockIsp,    // 3
    cSysBlockLog,    // 4
    cSysBlockIdx,    // 5
    cSysBlockSpare0,
    cSysBlockSpare1,
    cSysBlockSpare2,
    cSysBlockSpare3,
    cSysBlockSpare4,
    cSysBlockSpare5,
    cSysBlockSpare6,
};

/*
   * enum
   * {
   *  c1stInfo, //0
   *  c2ndInfo, //1
   *  c3rdInfo, //2
   *  c4thInfo, //3
   *  c1stIsp, //4
   *  c2ndIsp, //5
   *  c3rdIsp, //6
   *  c4thIsp, //7
   *  cIdxBlk, //8
   *  cBadInfo, //9
   *  cMPInfoBlk, //A
   *  cLogBlk, //B
   * };
   */

enum
{
    cPostReadTab,    // 0
    cTrigReadTab,    // 1
    cSrchSrcTab,    // 2
    cSrchSrcTabOk,    // 3
    cReadTabOk,    // 4
    cReadDataHold,    // 5
};

enum
{
    cInBoot=cBit0,
    cInBootWaitAllDie=cBit1,
    cBypassWaitChDone=cBit7,
};

#define cSrcAllDummy                0xFE
#define cSrcAllInOpen               0xF1
#define cSrcMixMode                 0xF2
#define cSrcAllInSgmt               0xF3

enum
{
    cLSB,    // 0
    cCSB,    // 1
    cMSB,    // 2
    cSLC,    // 3
    cAllWL,    // 4
};

#define c16H2FTabInitValue          (0xFFFF)
#define c16RaidPtrInitValue         (0xFFFF)

// ==========================================================================

// #define cMaxCmdIdx                             32
// #define cMaxCmdHistory                         1024

#define cPrpNoErr                                0
#define cPrpOverlap                              1
#define cPrpNotAlign                             2
#define cPrpNot4KAlign                           3
#define cPrp1Empty                               4
#define cPrpLessThanPayload                      5
#define cPrp2LessThanList                        6
#define cPrp2Empty                               7

#if _ENABLE_BUS_ERR_HANDLE
#define cBusTimeout                              0x1F
#endif

// ==========================================================================
// Vendor Command
// ==========================================================================
#define cVendorCmdDebugInfoByte                  512

enum
{
    cRom,
    cMpisp,
    cIsp,
    cRomDebug,
};

#define cVendorCmdErrCodeUnknownCmdOpCode        0xFF

// #define cHmbStAddrNum                            7
#define cMaxHmbGcCacheNum                        32    // 8    // 4
#define cHmbChunkSctrSize                        128

#define c16HmbMaxTableNumAlign                   512
#define c16HmbMaxTableNum                        (c32HmbH2fTabSize/c32H2fTabRamSize)
#define c32HmbTotalH2fTableSize                  (32*1024*1024)
#define c32HmbH2fTabSize                         (c32HmbTotalH2fTableSize-cHmbTsbCacheSize)    // 32MB - TsbCache data+crc
#define cHmbTsbCacheSize                         (0x70000)    // 384K data + 6K Crc, align to 64K
#define cHmbWrCacheSize                          (512*1024)    // 512k
#define cHmbRdCacheSize                          (512*1024)    // 512k
#define cHmbGcCacheSize                          ((cMaxHmbGcCacheNum*c16WriteBufSize)<<9)    // 1536k
// #define cHmbDataCrcCacheSize                     ((cHmbGcCacheSize+cHmbGcPtCacheSize)>>6)    // 40k, 512 byte data : 8 byte CRC
#define cHmbDataCrcCacheSize                     ((cHmbGcCacheSize)>>6)    // 40k, 512 byte data : 8 byte C
// #define cHmbF2hCacheSize                         c32CacheF2hRamSize    // 48k
// #define cHmbPtCacheSize                          ((c16MaxWLNum-cRaidParityNum)*(32*1024))    // 12032k, SLC
#define cPartialParityNum                        (c16MaxWLNum-cRaidParityNum)
#define cHmbGcPtCacheSize                        (cPartialParityNum*(cRaidDataSctrNum*512))    // 8832k, TLC

#define cHmbWrCmdBit                             0x80
#define cDisHmbMaxThr                            20    // 20190807_Bruce_DisHMB
#define cPcieD3State                             cBit0
#define cPcieSHNState                            cBit1
#define cEnableFakeHMB                           cBit2

enum
{
    cHmbRead2kTab,    // 0
    cHmbReadData,    // 1
    cHmbReadH2fTab,    // 2
    cHmbReadWpro,    // 3
    cHmbReadCrcData,    // 4
    cHmbRead4bTab,    // 5

    cHmbWriteH2fTab=0x80,    // 128, Write hmb command use the highest bit to verify
    cHmbWriteData,    // 129
    cHmbWriteWpro,    // 130
    cHmbWriteCrcData,    // 131
    cHmbWrite2kTab,    // 132
};

enum
{
    // cXXXX,    // 0
    // cHmbWrCache,    // 0
    // cHmbRdCache,    // 1
    cHmbTsbCache,    // 0 currently for AES and SecurityF/W.
    cHmbGcCache,    // 1
    cHmbCrcCache,    // 2
    cHmbGcPtCache,    // 3
    cHmbPtCrcCache,    // 4
    cHmbStAddrNum
};

// For DRAM
enum
{
    cDram0,    // CS0, low 16bit
    cDram1,    // CS0, high 16bit
    cDram01,    // CS0, 32 bit
    cDram02,    // CS0+1, low 16 bit
    cDram13,    // CS0+1, high 16 bit
    cDram0123,    // CS0+1, 32 bit
};

// Dram Freq
enum
{
    cDramFreq350Mhz=0x0238,
    cDramFreq375Mhz=0x023c,
    cDramFreq400Mhz=0x0120,
    cDramFreq450Mhz=0x0124,
    cDramFreq500Mhz=0x0128,
    cDramFreq525Mhz=0x012A,
    cDramFreq550Mhz=0x012c,
    cDramFreq600Mhz=0x0130,
};

// Dram Type
enum
{
    cDramSettingDdr2,
    cDramSettingDdr3,
    cDramSettingLPDdr2,
    cDramSettingLPDdr3,
    cDramSettingDdr3L,
};

// Dram size
enum
{
    cDramSetting1Gb=3,
    cDramSetting2Gb=4,
    cDramSetting4Gb=5,
    cDramSetting8Gb=6,
};

enum
{
    cDramVndrNanya=0,
    cDramVndrWinBond=1,
    cDramVndrSamsung=2,
    cDramVndrHynix=3,
    cDramVndrElpida=4
};

#if cTrue
enum    // 800 Mhz
{
    c32RegDramMR0=0x00000C70,
    c32RegDramMR1=0x00000040,
    c32RegDramMR2=0x00000098,
    c32RegDramMR3=0x00000000,
};

enum
{
    c32RegDramDptr0=0x081E0C06,
    c32RegDramDptr1=0x28280006,
    c32RegDramDptr2=0x000500F8,
    c32RegDramDptr3=0x01800802,
    c32RegDramDptr4=0x00F00805,
    c32RegDramDptr5=0x002A0C06,
};

enum
{
    c32RegDramDsgcr=0x006C401b,
    c32RegDramDtcr0=0x8000B0C1,
    c32RegDramDtcr1=0x00010237,
    c32RegDramPir=0x0002FF81,
    c32RegDramPgcr1=0x02004620,
    c32RegDramPgcr2=0x000036a0,
};

#else    // 400 Mhz
enum
{
    c32RegDramMR0=0x00000420,
    c32RegDramMR1=0x00000040,
    c32RegDramMR2=0x00000080,
    c32RegDramMR3=0x00000000,
};

enum
{
    // Only for Dram 512 MB @400Mhz
    c32RegDramDptr0=0x040f0604,
    c32RegDramDptr1=0x28140006,
    c32RegDramDptr2=0x0003007c,
    c32RegDramDptr3=0x01800301,
    c32RegDramDptr4=0x00780803,
    c32RegDramDptr5=0x00150604,
};

enum
{
    c32RegDramDsgcr=0x006C401b,
    c32RegDramDtcr0=0x8000B0C1,
    c32RegDramDtcr1=0x00010237,
    c32RegDramPir=0x0002FF81,    // 0x0000FF81,
    c32RegDramPgcr1=0x02004620,
    c32RegDramPgcr2=0x000036a0,
};

#endif    // if cTrue
enum
{
    cTskPopBlk,
    cTskPushBlk,
    cTskWaitAllBz,
    cTskChkEsSts,
    cTskProgWpro,
    cTskReadWpro,
    cTskProgH2f,
    cTskMarkBad,
    cTskSwapCore0,
    cTskInvalidateCore1DCache,
    cTskCore1SetGlobEraseCnt,
    cTskCore0GetGlobEraseCnt,
    cTskCore0GetDiffType2Offset,
    cTskSaveIndexBlockCore0,

    // cTskPrePopBlkErase,
    cTskPrePopBlkChkStatus,
    cTskVendorOp,
    cTskChkPushSpareQ,
    cTskSetDiffType2AddrInfo,
    cTskRstAllFlash,
    cTskRstAllFshInHdPCIeErr,
    cTskRstCtlVar,
    cTskCore0GetRndSeed,
    cTskBuildF2h,
    cTskEraseUnitProc,
    cTskEnableLdpcPipe,
    cTskDisableLdpcPipe,
    cTskChkPostWriteRead,
    cTskCore1SetGlobEraseCnt1Blk,
    cTskProgFwDlTempIspblock,
    cTskActivateIsp,
    cTskJudgeSwapIsp,
    cTskChkIspBlock,
    cTskSwapFwSlotIsp,
    cTskLoadIspPage,
    cTskCore1Sleep,
    cTskCore1ClrLastRGrp,
#if _ENABLE_RAID
    // cTskSetRaidEncode,
    // cTskGetRaidParity,
    cTskProgPartialRaidParity,
    cTskPushRaidPtyBlk,
    cTskInitRaidEngine,
    cTskRstRaidEngVar,
#endif
    cTskChangeFlashClock,
    cTskWaitProgH2fTxData,
    cTskRstUNCSts,
    cTskRstUNCSts1Plane,
    cTskInvPlaneBufFlag,
    cTskGetGlobEraseCntOfSpecFblock,
    cTskCore1ResumePs3,
    cTskRemWproPage,
    cTskGetDifferAddr,
    cTskSwapWproBlk,
    cTskInsSlcSortQ,
    cTskGetGcSrcBlk,
    cTskInitSlcQ,
    cTskRestoreSlcQ,
    cTskSetSlcEndurPara,
    cTskSetGcInfoHmbLink,
    cTskFlashWriteCmd,
    cTskLoadDiffTab,
    cTskSaveWproBadInfo,
    cTskCore1SwapNvmeBank,

    // cTskPopReadScrubQ,
    // cTskResetGCFlag,
    cTskReadRdCnt,
#if _EN_SLCOpenBlkReadScrub
    cTskPushWLReadReclaimQ,
#endif
    cTskinitGcProc,
    cTskgcDesBlkFullSetting,
    cTskdeleteGcSrcBlk,
#if _ENABLE_RAID
    cTskRstRaidPara,
#endif
    cTskLoadTelemetryCtlrLog,
    cTskEraseUnitStart,
    cTskEraseUnitContinue,
    cTskCore1SwapIspBank,

#if _EN_CHK_FINGER_FAIL
    cTskChkFingerFail,
#endif

    cTskGetAvgECCore0,

    // cTskHandleCntForSanitize,
    cTskMarkEraseBad,
#if (_ENABLE_RAID&&_EN_VPC_SWAP)
    cTskpushVPCtoRaid,
    cTskpopVPCfromRaid,
#endif
    cTskInitEraseCnt,
};

enum
{
    cVendorCore1ReadFlash,
    cVendorCore1ProgFlash,
    cVendorCore1EraseFlash,
    cVendorCore1DeepErase,
    cVendorCore1ReadGlobEraseCnt,
    cVendorCore1ReadGlobReadCnt,
    cVendorCore1ReadFlashId,
    cVendorCore1SetFeature,
    cVendorCore1doVtDistribution,
    cVendorCore1ReadInfoPg,
    cVendorCore1ModifyEraseCnt,
    cVendorCore1MarkBadBlock,
    cVendorCore1WdPhyErase,
    cVendorCore1WdPhyProgram,
    cVendorCore1WdPhyRead,
    cVendorCore1WdCheckSts,
    cVendorCore1ReadOrgBadCnt,
    cVendorCore1ReadOrgBadTable,
    cVendorCore1WriteMPInfo,
    cVendorCore1LiteOnVU_ReadFlashId,
    cVendorCore1LiteOnVU_ReadGlobEraseCnt
};

#define cSM2260EvbDramType                       cDramSettingDdr3
#define cSM2260EvbDramSize                       cDramSetting4Gb
#define cSM2260EvbDramClk                        cDramFreq350Mhz
#define cSM2260EvbDramVndr                       cDramVndrNanya
#define cSM2260EvbDramMap                        cDram01
#define cSM2263EvbDramMap                        cDram0
#define cSM2260EvbDramZprog                      0x7B
#define c32DramPattern                           0xA5A5A5A5

// GreyBox - Uart
enum
{
    cGbHqInfo,
    cGbPbaInfo,
    cGbGcInfo,
    cGbVerifyInfo,
    cGvMarkBadInfo,
    cGbRwCtrl,
    cGbHmbInfo,
    cGbTrigInfo,
    cGbH2fInfo
};

// Inject error
#define     cInjectRF               cBit6
#define     cInjectPF               cBit1
#define     cInjectEF               cBit2

#define   rmNewLine  {rmUartTxByte(0x0d);rmUartTxByte(0x0a);}
#define   cAsciiTo0     '0'
#define   cAsciiToA     'A'
#define   cCharAt       '@'

#define cVHqInfo        "[ Host Que Info ]"
#define cVPbaInfo       "[ PBA Info ]"
#define cVPbGcInfo      "[ GC Info ]"
#define cVVerifyInfo    "[ Verify Info ]"
#define cVMarkBadInfo   "[ Mark Bad Info ]"
#define cVRwCtrl        "[ RW Ctrl Info ]"
#define cVHmbInfo       "[ HMB Info ]"
#define cVTrigInfo      "[ Be Triged Info ]"
#define cVH2fInfo       "[ H2f Info ]"
// GreyBox - Validation
enum
{
    cVaryfyIdle=0x00,
    cGreyboxPreConditionID=0x01,

    /* Error Handle */
    cErrHdlReadFailID=0x20,
    cErrHdlWriteFailID=0x21,
    cErrHdlEraseFailID=0x22,

    /* UGSD*/
    cUGSDProgCacheSlcID=0x10,
    cUGSDProgIndxBlkID=0x11,
    cUGSDHmbID=0x12,
    cUGSDProgH2fTableID=0x13,
    cUGSDProgS2SID=0x14,
    cUGSDS2TID=0x15,
    cUGSDProgT2SID=0x16,
    cUGSDProgWPROID=0x17,
    cUGSDProgBadInfoBlkID=0x18,
    cUGSDSecureEraseID=0x19,
    cUGSDT2TID=0x1A,
    cUGSDGcH2fTableID=0x1B,
    cUGSDSwapWproID=0x1C,
    cUGSDReclaimID=0x1D,
    cUGSDonSeqHostWID=0x1E,
    cUGSDS2SID=0x1F,

    cErrHdlE2EHostData=0x20,

    /* Error Handle for program fail*/
    cErrHdlProgCacheBlk=0x30,
    cErrHdlProgCacheBlkID=0x31,
    cErrHdlProgF2hTabID=0x32,
    cErrHdlProgCacheInfoTableID=0x33,
    cErrHdlProgH2fTableID=0x34,
    cErrHdlProgS2TGcDesID=0x35,
    cErrHdlProgT2TGcDesID=0x36,
    cErrHdlProgS2SGcDesID=0x37,
    cErrHdlProgWPROID=0x38,
    cErrHdlProgBadInfoBlkID=0x39,
    cErrHdlProgLBAID=0x3A,
    cErrHdlProgGcH2FID=0x3B,
    cErrHdlEraseFID=0x3F,

    /* Error Handle for read UNC */
    cErrHdlReadUnc=0x40,
    cErrHdlReadUncCacheBlkID=0x41,
    cErrHdlReadUncF2hTabID=0x42,
    cErrHdlReadUncS2tSorBlkID=0x43,
    cErrHdlReadUncS2tDesBlkID=0x44,
    cErrHdlReadUncS2sSorBlkID=0x45,
    cErrHdlReadUncT2sSorBlkID=0x46,
    cErrHdlReadRetry=0x4A,
    cReadRetryDecodeTestID=0x4B,
    cErrHdlReadUncInSlcDataID=0x4C,
    cErrHdlReadUncInTlcDataID=0x4D,
    cErrHdlGcFingerFailTestID=0x4E,

    /* Table Handle */
    cTabHdlH2fOnHmb=0x50,
    cTabHdlGcH2f=0x51,
    cHmbErrHandle=0x52,
    cHmbHandle=0x53,

    /* */
    cHostRwReadAhead=0x6C,

    /*GC Handle*/
    cGCS2TThree2OneFull=0x80,
    cGCS2TSixteen2OneFull=0x81,
    cGCS2TSixteen2OneNotFull=0x82,
    cGCT2TX2OneNotFull=0x83,
    cGCT2TSixteen2OneMoreFull=0x84,
    cGCT2TX2OneFull=0x85,
    cGCT2TSixteenFull2OneMoreFull=0x86,
    cGCPartialS2Tfour2OneFull=0x87,
    cGCS2SThirtytwo2OneNotFull=0x88,

    /*Ftl Rule*/
    cFtlRuleReadReclaimID=0x90,
    cRetryReclaimID=0x91,
    cWearleveingRule=0x9A,

    /*RAID*/
    cRAIDEncOnH2fTab=0xA0,
    cRAIDEncOnData=0xA1,
    cRAIDEncOnGc=0xA2,
    cRAIDDecOnH2fTab=0xA3,
    cRAIDDecOnH2f1kTab=0xA4,
    cRAIDDecOnNormData=0xA5,
    cRAIDDecOnOpenData=0xA6,
    cRAIDDecOnPreReadData=0xA7,
    cRAIDDecOnLastReadData=0xA8,
    cRAIDDecOnMoveReadData=0xA9,

    cSysRegOnBoot=0xB0,
    cUGSDonEraseFail=0xB1,
    cUGSDonProgFail=0xB2,
    cUGSDonReadFail=0xB3,
    cUGSDonSanitize=0xB4,
    cUGSDonTrim=0xB5,
    cUGSDonE2E=0xB6,
    cUGSDonWearleveling=0xB7,
    cSecurityRW=0xC0,

    /*Thread*/
    cTreadPatternRandWrite=0xFD,
    cTreadPatternSeqWrite=0xFE,
};

enum
{
    /* Op Type */
    cVOpNormal=0x01,
    cVOpProgFirstPage=0x20,
    cVOpProgIntPage=0x21,
    cVOpProgEndPage=0x22,
    cVOpProgF2H=0x23,
    cVOpSpConfig=0x24,
    cVOpAllConfig=0x25,
    cVOpFirstConfig=0x26,
    cVOpLastConfig=0x27,
    cVOpBeforePushSpareQ=0x30,
    cVOpAfterPushSpareQ=0x31,
    cVOpEnHmbWithMr=0x50,
    cVOpEnHmbNonMr=0x51,
    cVOpErasing=0x60,
    cVOpProgCacheLast6Page=0x61,
    cVOpProgCacheLast3Page=0x62,
    cVOpProgLastF2HDone=0x63,
    cVOpProgH2fonHmb=0x70,
    cVOpProgH2fxHmb=0x71,
    cVOpProgFristF2H=0x72,
    cVOpProgLastF2H=0x73,
    cVOpProgQboot=0x74,
    cVOpSetFeature=0X75,
    cVOpProgCacheInfoInitCache=0x76,
    cVOpProgCacheInfoH2fFull=0x77,
    cVOpProgCacheInfoInitCacheDone=0x78,
    cVOpProgCacheInfoH2fFullDone=0x79,
    cVOpProgWproGcInfo=0x7A,
    cVOpProgCacheInfoBefEraseAll=0x7B,
    cVOpProgCacheInfoAfEraseAll=0x7C,
    cVOpProgCacheInfoDoneAfEraseAll=0x7D,
    cVOpProgIndxBlkDone=0x80,
    cVOpWriteH2fOnHmb=0x81,
    cVOpProgPause=0x82,
    cVOpE2EReadDummyError=0x90,
    cVOpE2EWriteNopError=0x91,
    cVOpE2EReadErrConti=0x92,
    cVOpE2EReadErrOnce=0x93,
    cVOpE2EBopGenChkErr=0x9C,
    cVOpE2EBopReadChkErr=0x9E,
    cVOpCrc=0xA0,

    cVOpPcieErrByReadtrgHotPdTakR3=0xA2,
    cVOpPcieErrByReadpstRdH2fSgtTab1=0xA3,
    cVOpPcieErrByReadtemFlshOpR1=0xA4,

    cVOpSecurityW=0xB0,
    cVOpSecurityR=0xB1,
    cVOpSecurityGC=0xB2,
    cVOpSecurityRAID=0xB3,

    cVOpPopCacheSlcBfErase=0xC0,
    cVOpPopCacheSlcAfErase=0xC1,
    cVOpPopH2fTableBfErase=0xC2,
    cVOpPopH2fTableAfErase=0xC3,
    cVOpPopWPROIDBfErase=0xC4,
    cVOpPopWPROIDAfErase=0xC5,

    cVopProgFailDiffBlkSta=0xE0,
    cVopProgFailSetSta=0xE1,
    cVopProgFailSetS2TGc=0xE2,
    cVopProgFailResetS2TGc=0xE3,
    cVopProgFailSetT2TGc=0xE4,
    cVopProgFailResetT2TGc=0xE5,
    cVopProgFailGetGcStageIdle=0xE6,
};

// AWGN Leave
enum
{
    cAWGNNon,
    cAWGNUNC,
    cAWGN0P3,
    cAWGN0P6,
    cAWGN1P4,
};

// RV Read Threshold
enum
{
    cRv1SlcTh=0x00,
    cRv1TlcTh=0x01,

    // cRv2TlcTh=0x02,
    // cRv3TlcTh=0x03,
    // cRv4TlcTh=0x04,
    // cRv5TlcTh=0x05,
    // cRv6TlcTh=0x06,
    // cRv7TlcTh=0x07,
    // cRv1FwSlcTh=0xE1,
};

// #define     cRv1SlcTh   0x00
// #define     cRv1TlcTh   0x01
enum
{
    /* varify status */
    cVsIdl,
    cVsTriggered,
    cVsDone,
};

enum
{
    /* verify op for read */
    cVOpAwgnUnc,
    cVOpSoftRead,
};

enum
{
    /* verify status for RAID */
    cVsInit,
    cVsSkipRaidDec,
    cVsRaidHTabKVal,
    cVsRaidDecH2fFailCnt,
};

// Distribution
#define cLDPC0to1H                  0xC4
#define cLDPC0to1L                  0xC5

#define cLDPC1to0H                  0xC2
#define cLDPC1to0L                  0xC3

// IM MLBi register define
enum
{
    /* For TLC page word line group specific register */
    cTrimRegWLG2=0x08AC,
    cTrimRegWLG3=0X08E4,
    cTrimRegWLG4=0X091C,
    cTrimRegWLG5=0x0954,
    cTrimRegWLG6=0x098C,

    cTrimReg73=0x0073,
    cTrimReg7F=0x007F,
    cTrimReg66=0x0066,

    /* sweep parameter for TLC page */
    cTrimRegSlcSweepL=0x0AFA,
    cTrimRegSlcSweepH=0x0AFB,

    /* sweep parameter for MLC page */
    cTrimRegMlcSweepL=0x0804,
    cTrimRegMlcSweepH=0x0805,

    /* sweep parameter for SLC page */
    cTrimRegTlcSweepL=0x080E,
    cTrimRegTlcSweepH=0x080F,
};

// Flash Feature Register
enum
{
    /* Randomizer */
    cFaRandomizer=0x92,

    /* Lower Page Pre-Read Functionality */
    cFaLpPreRead=0xDF,
};

enum
{
    cReserve,    // 0
    cH2fDecodeFail,    // 1
    cChkBlockMapping,    // 2
    cChkBlockMapping1,    // 3
    cModifyH2FtabBoot1,    // 4
    cModifyH2FtabBoot2,    // 5
    cFlushCacheHmbTab,    // 6
    cFlashProgPage,    // 7
    cChkLdpcResult,    // 8
    cChkOpIdxAccCnt,    // 9
    cChkOpIdxAccCntW,    // 10
    cWaitCmdFifoDpt,    // 11
    cSetSprByteOfDataBlk,    // 12
    cReleaseBtSrcAddrInfo,    // 13
    cReleaseBtDesAddrInfo,    // 14
    cReadH2fTable,    // 15
    cSwapH2fTable,    // 16
    cSetWriteDes1,    // 17
    cDummyFuncCore1,    // 18
    cDummyFunc2Core1,    // 19
    cDummyFunc3Core1,    // 20
    cDummyFunc4Core1,    // 21
    cDummyFunc5Core1,    // 22
    cBgdClnCacheblkProc1,    // 23
    cBgdClnCacheblkProc2,    // 24
    cSrchGcSrcF2hTab,    // 25
    cInitGcDesFblkProc,    // 26
    cGetGcSrcBlk1,    // 27
    cGetGcSrcBlk2,    // 28
    cBgdClnH2fTabblkProc,    // 29
    cHdmaEncRam1,    // 30
    cHdmaEncRam2,    // 31
    cHdmaGetRaidPty,    // 32
    cWriteHmbData,    // 33
    cReadHmbData,    // 34
    cReleaseHmbHwPrd,    // 35
    cSetDramCtl,    // 36
    cSetDramSize,    // 37
    cInitDramSetting1,    // 38
    cInitDramSetting2,    // 39
    cGoCore0DramCode,    // 40
    cGoCore1DramCode,    // 41
    cSetWriteDes2,    // 42
    cLoadIspCode,    // 43
    cRemSlcSortQ,    // 44
    cManualCompletion,    // 45
    cTrigNonRWCmd,    // 46
    cSetMarkPfFblock1,    // 47
    cSetMarkPfFblock2,    // 48
    cTermRaidEngTask,    // 49
    cResmRaidEngTask,    // 50
    cDoRaidDecode,    // 51
    cPostFlashAddrInfoR,    // 52
    cPostFAddrInfoSeqR,    // 53
    cRecovPcieErrW1,    // 54
    cRecovPcieErrW2,    // 55
    cFlushOpenBlock,    // 56
    cVerifySha,    // 57
    cVerifyKeyWrapping,    // 58
    cVerifyPbkdf,    // 59
    cVerifyKdfCountMode,    // 60
    cPostSecToPrdInfo,    // 61
    cTrigSecPrdTaskW,    // 62
    cSecurityWrite,    // 63
    cEraseBlockProc1,    // 64
    cEraseBlockProc2,    // 65
    cPopSpareBlock1,    // 66
    cPopSpareBlock2,    // 67
    cPopSpareBlock3,    // 68
    cSetFlashClock,    // 69
    cHandleTcgTrustedSend,    // 70
    cTrigFLCmdFifoWtab,    // 71
    cEnAllChStop,    // 72
    cDisAllChStop,    // 73
    cCtrlScrbBothAndEcc,    // 74
    cFlashReadPage,    // 75
    cFlashProgPage1,    // 76
    cFlashErase,    // 77
    cSetSprByteforTest,    // 78
    cTranDieIdx2Pba,    // 79
    cPopDiffType2SpareBlock,    // 80
    cGetFreeWproBlkIdx,    // 81
    cChkPushSpareQ,    // 82
    cInsSrcCmdList,    // 83
    cTermRaidAllEngForQB,    // 84
    cTranAddrInfo,    // 85
    cRdlinkStep3_1,    // 86
    cRdlinkStep3_2,    // 87
    cRdlinkStep3_3,    // 88
    cRdlinkStep3_4,    // 89
    cRebuCacheF2hTable1,    // 90
    cRebuCacheF2hTable2,    // 91
    cRebuH2fTableInfo1,    // 92
    cRebuH2fTableInfo2,    // 93
    cRebuH2fTableInfo3,    // 94
    cAddRefreshH2f,    // 95
    cAddReBuCacheBlock,    // 96
    cAddRdlinkReBuCacheBlock,    // 97
    cAddBlock2CacheQ,    // 98
    cSetBlkSerial,    // 99
    cRebuSpareFblock,    // 100
    cSetErrorBlock,    // 101
    cChkWproPageIsGood,    // 102
    cChkSkipGcSrchFail1,    // 103
    cChkSkipGcSrchFail2,    // 104
    cChkSkipGcSrchFail3,    // 105
    cUpdateH2fTabWindowFail1,    // 106
    cUpdateH2fTabWindowFail2,    // 107
    cUpdateH2fTabWindowFail3,    // 108
    cUpdateH2fTabWindowFail4,    // 109
    cUpdateH2fTabWindowFail5,    // 110
    cCalWproBlkCntFail1,    // 111
    cRebuCacheBlkVpCnt1,    // 112
    cRebuCacheBlkVpCnt2,    // 113
    cRebuCacheBlkVpCnt3,    // 114
    cRebuCacheBlkVpCnt4,    // 115
    cRebuCacheBlkVpCnt5,    // 116
    cRebuCacheBlkVpCnt6,    // 117
    cRebuWproInfo1,    // 118
    cRebuWproInfo2,    // 119
    cRebuWproInfo3,    // 120
    cChkVpCnt1,    // 121
    cChkVpCnt2,    // 122
    cChkVpCnt3,    // 123
    cChkVpCnt4,    // 124
    cChkPwrOnByQBootInfo1,    // 125
    cRdlinkStep1,    // 126
    cMoveRiskyPage1,    // 127
    cMoveRiskyPage2,    // 128
    cFlushCacheF2hInRdlink1,    // 129
    cGetH2fTabBlkPageInfo1,    // 130
    cReFreshH2f1,    // 131
    cGetWproPageInfo1,    // 132
    cGetWproFreePage1,    // 133
    cChkLastWproIsQBoot1,    // 134
    cChkWproPageIsGood1,    // 135
    cGetRsvPageInfo1,    // 136
    cGetRsvLastPageInfo1,    // 137
    c32VpcOverMaxTlcBlk,    // 138
    c32VpcMismatch,    // 139
    cRebuInfoBlk,    // 140
};

#if _TSB_BiCS3_EVB_Ch0xF
#define cCardMode                                (cIntlvMo|cMultiDie)
#define cFLParam                                 (cTlc|cWithRlibMo|cMPlaneMo|cWithPrimaryCmd|cLsbPlanebit)
#define cFLOption                                (cEnMPlaneRead|cEnMPlaneProg|cBpcOpCoCmd)

#define cChMap                                   0x0F    // 0x03;
#define cCeMap                                   0x01
#define cTotalChNum                              4
#define cTotalCeNum                              1    // 2;
#define cSprECCLevel                             0x02    // Temp use gSprEccLevel
#define cDataECCLevel                            0x02    // Temp use gDataEccLevel
#define cTotalIntlvChNum                         (cTotalChNum*cIntlvWay)
#define cTotalDiePerCe                           0x01
#define cIntlvWay                                (cTotalDiePerCe*cTotalCeNum)
#define cPlaneNum                                2
#define cPageNumReg                              2    // 000:64pages   001:128pages    010:256pages    011:512pages   100:1024pages
#define cBlockNumReg                             2    // 0x00: 512 bocks, 0x01: 1024 blocks, 0x02: 2048 blocks, 0x03: 4096 blocks, 0x04: 8096
// blocks
#define cPlaneNumReg                             1
// #define cTotalCeNum2
#define cTotalIntlvChPlaneNum                    (cTotalChNum*cIntlvWay*cPlaneNum)
#define cTotalChPlaneNum                         (cTotalChNum*cPlaneNum)
// 0x020:
// #define carSysBlock[cRsvSysBlkNum]
// #define c16First16BlkBitmap
// #define carSpareRegion[2]

// 0x030
#define c16FirstFBlock                           0x1    // 1
#define c16TotalFBlock                           1478
#define c16TotalHBlock                           0x7FD    // c16TotalFBlock-60
#define c16FBlockPerCe                           1478
#define c16FBlockPerDie                          1478
// #define c16OrgSpareBlockCnt
// #define c16OrgBadBlockCnt
// #define c16LaterBadBlockCnt

// 0x040
#define cSectorPerPlaneF                         16    // phyPage size for 1K num
#define cSectorPerPlaneH                         32    // phyPage size for sector num
#define cSectorPerPageF                          cSectorPerPlaneF*cPlaneNum
#define cSectorPerPageH                          cSectorPerPlaneH*cPlaneNum

#define c16PagePerBlock1                         768    // the number of page in one plane
#define c16PagePerBlock1_SLC                     (c16PagePerBlock1/3)
#define c16PagePerBlock3_SLC                     (c16PagePerBlock1_SLC*cTotalIntlvChPlaneNum)
#define c16PagePerTLC                            (c16PagePerBlock1)
#define c16PagePerSLC                            (c16PagePerBlock1/3)

// #define cRsv2[2]
#define c16PagePerBlock3                         (c16PagePerBlock1/3*cTotalChNum*cIntlvWay*cPlaneNum)    // the number of page in one SLC super
// block
#define cDieAddrBitShiftCnt                      0
// #define cFlashOverDrive
#define c32SectorPerBlockH                       0x1C000    // H2fTab 56K //0x20000    // H2fTab 128K
// 0x050
// #define carFLCmdSetTab[16]
#define cCacheReadCmd                            0x31
#define cLastPageCacheReadCmd                    0x3F
#define cCacheProgCmd                            0x15
#define cRandomInCmd                             0x85
#define cRandomOut1Cmd                           0x05
#define cRandomOut2Cmd                           0xE0
#define cReadStatusCmd                           0x70
#define cReadStatusEnhCmd                        0x78
#define cSlcMoAccessCmd                          0xA2
#define cSlcMoAbortCmd                           0xFF
#define cMulPlaneRead1Cmd                        0x00
#define cMulPlaneRead2Cmd                        0x32
#define cMulPlaneProg1Cmd                        0x11
#define cMulPlaneProg2Cmd                        0x81
#define cPlaneRead2Cmd                           0x30

#define cSyncResetCmd                            0xFF
#define cPriBlockErase2Cmd                       0xD1
// 0x060
#define c32TotalDatSector                        0xDFA000

#define cIntlvPlaneNum                           (cIntlvWay*cPlaneNum)

// #define cRtcSel
// #define cPretStatus

//
#define cF2hTabSize                              96    // 48KB
#define cTotalEntryOfF2h                         0x3000
#define cCacheInfoTabSize                        128    // 64KB
#define cH2fTabSize                              128    // 64KB
// 0x070
#define c16ValidTlcPgPerF2hTab                   (cTotalEntryOfF2h-cF2hTabSize/8)

// 0x80
#define c16ValidPgPerF2hTab                      (cTotalEntryOfF2h-cF2hTabSize/8)
#define c16PagePerH2fTab                         0x4000
#define c16TotalPgPerF2hTab                      0x3000
#define c16MaxCachePageNum                       cTotalEntryOfF2h
#define c16TotalTlcPgPerF2hTab                   cTotalEntryOfF2h
#define cTotalPlaneOfH2fTab                      (cH2fTabSize/cSectorPerPlaneH)
#define cTotal4kNumOfF2hTab                      (cF2hTabSize/8)
#define cTotalPlaneOfCacheInfoTab                (cCacheInfoTabSize/cSectorPerPlaneH)
#define cTotalBankOfF2hTab                       1
#define c4kNumPerPlane                           (cSectorPerPlaneH/8)
#define c4kNumPerPage                            (cSectorPerPageH/8)

#define cPlaneSizeBitCnt                         2
#define cPlaneBitCnt                             1
#define cChBitCnt                                2
#define cCeBitCnt                                0
#define cDieBitCnt                               0
#define cPlaneAddrBitShiftCnt                    (cPlaneSizeBitCnt)
#define cChAddrBitShiftCnt                       (cPlaneSizeBitCnt+cPlaneBitCnt)
#define cCeAddrBitShiftCnt                       (cPlaneSizeBitCnt+cPlaneBitCnt+cChBitCnt)
#define cDieAddrBitShiftCnt2                     (cPlaneSizeBitCnt+cPlaneBitCnt+cChBitCnt+cCeBitCnt)
#define cPhyPageAddrBitShiftCnt                  (cPlaneSizeBitCnt+cPlaneBitCnt+cChBitCnt+cCeBitCnt+cDieBitCnt)
#define cSlcMaxBank                               0

// 0xB0
#define c32VpcPerTlcBlk                          0x00008FDC
#define c16MaxDualMoPeThr                        0x03E7
#define c16TlcFullCachebGcThr                    0x0193
#define c32VpcPerSlcBlk                          0x00002FF4
#define cTotalTlcBankOfF2hTab                    3
#define cPhyDiePerPackage                        1

// 0xC0
#define c32PagePerBlock2                         0x00004800
#define c32PagePerBlock2By4k                     (c32PagePerBlock2*(cSectorPerPlaneH/8))
#define c32PagePerBlock2_SLCBy4k                 (c32PagePerBlock2By4k/3)

// 0x0F0
#define cFlashId_0                               0x98
#define cFlashId_1                               0x3C
#define cFlashId_2                               0x98
#define cFlashId_3                               0xB3
#define cFlashId_4                               0x76
#define cFlashId_5                               0xF2
#define cFlashId_6                               0x00
#define cFlashId_7                               0x00
#define cCeDieMap_0                              0x01
#define cCeDieMap_1                              0x00
#define cCeDieMap_2                              0x00
#define cCeDieMap_3                              0x00
#define cCeDieMap_4                              0x00
#define cCeDieMap_5                              0x00
#define cCeDieMap_6                              0x00
#define cCeDieMap_7                              0x00

#endif    // if _TSB_BiCS3_EVB_Ch0xF

#if _SANDISK_3D_GEN2_Ch0xF
#define cCardMode                                (cIntlvMo|cMultiDie)
#define cFLParam                                 (cTlc|cWithRlibMo|cMPlaneMo|cWithPrimaryCmd|cLsbPlanebit)
#define cFLOption                                (cEnMPlaneRead|cEnMPlaneProg|cBpcOpCoCmd)

#define cChMap                                   0x0F    // 0x03;
#define cCeMap                                   0x01
#define cTotalChNum                              4
#define cTotalCeNum                              1    // 2;
#define cSprECCLevel                             0x02    // Temp use gSprEccLevel
#define cDataECCLevel                            0x02    // Temp use gDataEccLevel
#define cTotalIntlvChNum                         (cTotalChNum*cIntlvWay)
#define cTotalDiePerCe                           0x01
#define cIntlvWay                                (cTotalDiePerCe*cTotalCeNum)
#define cPlaneNum                                2
#define cPageNumReg                              2    // 000:64pages   001:128pages    010:256pages    011:512pages   100:1024pages
#define cBlockNumReg                             2    // 0x00: 512 bocks, 0x01: 1024 blocks, 0x02: 2048 blocks, 0x03: 4096 blocks, 0x04: 8096
// blocks
#define cPlaneNumReg                             1
// #define cTotalCeNum2
#define cTotalIntlvChPlaneNum                    (cTotalChNum*cIntlvWay*cPlaneNum)
#define cTotalChPlaneNum                         (cTotalChNum*cPlaneNum)
// 0x020:
// #define carSysBlock[cRsvSysBlkNum]
// #define c16First16BlkBitmap
// #define carSpareRegion[2]

// 0x030
#define c16FirstFBlock                           0x1    // 1
#define c16TotalFBlock                           1478
#define c16TotalHBlock                           0x7FD    // c16TotalFBlock-60
#define c16FBlockPerCe                           1478
#define c16FBlockPerDie                          1478
// #define c16OrgSpareBlockCnt
// #define c16OrgBadBlockCnt
// #define c16LaterBadBlockCnt

// 0x040
#define cSectorPerPlaneF                         16    // phyPage size for 1K num
#define cSectorPerPlaneH                         32    // phyPage size for sector num
#define cSectorPerPageF                          cSectorPerPlaneF*cPlaneNum
#define cSectorPerPageH                          cSectorPerPlaneH*cPlaneNum

#define c16PagePerBlock1                         576    // the number of page in one plane
#define c16PagePerBlock1_SLC                     (c16PagePerBlock1/3)
#define c16PagePerBlock3_SLC                     (c16PagePerBlock1_SLC*cTotalIntlvChPlaneNum)
#define c16PagePerTLC                            (c16PagePerBlock1)
#define c16PagePerSLC                            (c16PagePerBlock1/3)

// #define cRsv2[2]
#define c16PagePerBlock3                         (c16PagePerBlock1/3*cTotalChNum*cIntlvWay*cPlaneNum)    // the number of page in one SLC super
// block
#define cDieAddrBitShiftCnt                      0
// #define cFlashOverDrive
#define c32SectorPerBlockH                       0x1C000    // H2fTab 56K //0x20000    // H2fTab 128K
// 0x050
// #define carFLCmdSetTab[16]
#define cCacheReadCmd                            0x31
#define cLastPageCacheReadCmd                    0x3F
#define cCacheProgCmd                            0x15
#define cRandomInCmd                             0x85
#define cRandomOut1Cmd                           0x05
#define cRandomOut2Cmd                           0xE0
#define cReadStatusCmd                           0x70
#define cReadStatusEnhCmd                        0x78
#define cSlcMoAccessCmd                          0xA2
#define cSlcMoAbortCmd                           0xFF
#define cMulPlaneRead1Cmd                        0x00
#define cMulPlaneRead2Cmd                        0x32
#define cMulPlaneProg1Cmd                        0x11
#define cMulPlaneProg2Cmd                        0x81
#define cPlaneRead2Cmd                           0x30

#define cSyncResetCmd                            0xFF
#define cPriBlockErase2Cmd                       0xD1
// 0x060
#define c32TotalDatSector                        0xDFA000

#define cIntlvPlaneNum                           (cIntlvWay*cPlaneNum)

// #define cRtcSel
// #define cPretStatus

//
#define cF2hTabSize                              96    // 48KB
#define cTotalEntryOfF2h                         0x3000
#define cCacheInfoTabSize                        128    // 64KB
#define cH2fTabSize                              128    // 64KB
// 0x070
#define c16ValidTlcPgPerF2hTab                   (cTotalEntryOfF2h-cF2hTabSize/8)

// 0x80
#define c16ValidPgPerF2hTab                      (cTotalEntryOfF2h-cF2hTabSize/8)
#define c16PagePerH2fTab                         0x4000
#define c16TotalPgPerF2hTab                      0x3000
#define c16MaxCachePageNum                       cTotalEntryOfF2h
#define c16TotalTlcPgPerF2hTab                   cTotalEntryOfF2h
#define cTotalPlaneOfH2fTab                      (cH2fTabSize/cSectorPerPlaneH)
#define cTotal4kNumOfF2hTab                      (cF2hTabSize/8)
#define cTotalPlaneOfCacheInfoTab                (cCacheInfoTabSize/cSectorPerPlaneH)
#define cTotalBankOfF2hTab                       1
#define c4kNumPerPlane                           (cSectorPerPlaneH/8)
#define c4kNumPerPage                            (cSectorPerPageH/8)

#define cPlaneSizeBitCnt                         2
#define cPlaneBitCnt                             1
#define cChBitCnt                                2
#define cCeBitCnt                                0
#define cDieBitCnt                               0
#define cPlaneAddrBitShiftCnt                    (cPlaneSizeBitCnt)
#define cChAddrBitShiftCnt                       (cPlaneSizeBitCnt+cPlaneBitCnt)
#define cCeAddrBitShiftCnt                       (cPlaneSizeBitCnt+cPlaneBitCnt+cChBitCnt)
#define cDieAddrBitShiftCnt2                     (cPlaneSizeBitCnt+cPlaneBitCnt+cChBitCnt+cCeBitCnt)
#define cPhyPageAddrBitShiftCnt                  (cPlaneSizeBitCnt+cPlaneBitCnt+cChBitCnt+cCeBitCnt+cDieBitCnt)
#define cSlcMaxBank                               0

// 0xB0
#define c32VpcPerTlcBlk                          0x00008FDC
#define c16MaxDualMoPeThr                        0x03E7
#define c16TlcFullCachebGcThr                    0x0193
#define c32VpcPerSlcBlk                          0x00002FF4
#define cTotalTlcBankOfF2hTab                    3
#define cPhyDiePerPackage                        1

// 0xC0
#define c32PagePerBlock2                         0x00004800
#define c32PagePerBlock2By4k                     (c32PagePerBlock2*(cSectorPerPlaneH/8))
#define c32PagePerBlock2_SLCBy4k                 (c32PagePerBlock2By4k/3)

// 0x0F0
#define cFlashId_0                               0x45
#define cFlashId_1                               0x3C
#define cFlashId_2                               0x98
#define cFlashId_3                               0xB3
#define cFlashId_4                               0x76
#define cFlashId_5                               0x79
#define cFlashId_6                               0x00
#define cFlashId_7                               0x00
#define cCeDieMap_0                              0x01
#define cCeDieMap_1                              0x00
#define cCeDieMap_2                              0x00
#define cCeDieMap_3                              0x00
#define cCeDieMap_4                              0x00
#define cCeDieMap_5                              0x00
#define cCeDieMap_6                              0x00
#define cCeDieMap_7                              0x00

#endif    // if (_SANDISK_3D_GEN2_Ch0xF)

// cmdQ length and auxQ length
#define cNorQStrAddr            0x0000
#define cNorQLen                0x0600
#define cNorQEndAddr            cNorQStrAddr+cNorQLen-1    // 0x05FF
#define cAuxQStrAddr            0x0000+cNorQLen
#define cAuxQLen                0x0800-cNorQLen
#define cAuxQEndAddr            cAuxQStrAddr+cAuxQLen-1    // 0x07FF

#define cFullNorCmdDepth        cNorQLen
// >>> merge 58xt IM3D

#define cInvldFBlk              0xFFFF
#define cInvldHBlk              0xFFFF
#define cSrchNotFound           0xFFFF

#define cMaxReBuBankNum             2
#define cMaxReBuCacheBlockNum       8
#define cMaxReBuH2fBlockNum         8
#define cMaxCopyBlockNum            8
#define cMaxFoundCacheFBlockNum     256
#define cMaxUpdateH2fCnt            6    // 384KB/64KB=6

#define cMaxRsvSpareBlkNum          256

// Diff Address Used
#define cTotalDiffAddrTableSize     (16*1024)
#define cMaxDiffType2Num            64
#define cDiffMixTableHalfKb         (cTotalDiffAddrTableSize/512)

// Diff Pool
#define cTotalRTDiffPoolSize        (32*1024)
#define cTotalRTDiffPoolHalfKb      (cTotalRTDiffPoolSize/512)

// Block ID
#define cInfoBlockID                0xE1
#define cIspBlockID                 0xE4
#define cMPInfoBlockID              0xE7
#define cIndexBlockID               0xE5
#define cLogBlockID                 0xE9
#define cTmpBlockID                 0xEA
#define cFwDlDesBlockID             cProgBlockID

#define cRsvSysBlkShiftBit          4

// serial-related
#define c32MaxCacheSerial           0x80000000
#define c32InitSerialVal            0xFFFFFFFF
#define c32CacheSerialTH            ((c32MaxCacheSerial/2)-1)

// MIKEY define for GC, Max Gc Src Blk Number.
#define cMaxGcSrcBlkNum             16
#define cMaxSkipGcSrcBlkNum         (cMaxGcSrcBlkNum*4)    // 72
#define cMinGcTlcSprBlkNum          5

#define cMaxCacheInfoTabCntOnce     4
#define cMaxGcInfoTabCntOnce        8
#define cMaxH2fTabCntOnce           16

#define cNoAnyMode                  0
#define cUseSlcMode                 cBit0
#define cReadRtyResetVth            cBit1
#define cReadSprOnly                cBit2
#define cMultiCopies                cBit3
#define cReadOnePage                cBit4
#define cReadWithoutRetry           cBit5
#define cReadLastPage               cBit6
#define cReadSprData                cBit7

#define cAsignEofPgToRdData         cBit5
#define cBuildF2hInCacheF2h         cBit6
#define cBuildF2hInGcSrcF2h         cBit7

#define cMaxWproBlkCnt              4
#define cWproGcThr                  4

// index block spare
#define cBadInfoFblkMask            0x3FFF
#define cBadInfoFblkShift           14

enum
{
    cWproQBootPg,    // 00
    cWproInvQBootPg,    // 01
    cWproCacheInfo,    // 02
    cWproBadInfo,    // 03
    cWproEventLog,    // 04
    cWproFeaturePg,    // 05
    cWproGetLogPg,    // 06
    cWproSecurityId,    // 07
    cWproTcgIeee1667InfoId,    // 08
    cWproTcgInfoId,    // 09
    cWproTcgInfoDevslpId,    // 10
    cWproTcgIeee1667InfoDevslpId,    // 11
    cWproTcgIeee1667InfoTransDevslpId,    // 12
    cWproTcgRecvbuf1DevslpId,    // 13
    cWproTcgRecvbuf2DevslpId,    // 14
    cWproTcgRecvbuf3DevslpId,    // 15
    cWproTcgRecvbuf4DevslpId,    // 16
    cWproWriteUNC,    // 17
#if _EN_KEEP_RW_ON_ERROR
    cWproErrorInfo,    // 18
#else
    cWproLiteonNoUse1,    // 18
#endif
    cWproLiteonNoUse2,    // 19
    cWproLiteonNoUse3,    // 20
    cWproLiteonNoUse4,    // 21
    cWproRpmbInfoId,    // 22
    cWproSecurityBackupAllTsb,    // 23 Don't rebuild
    // cWproGcBakF2hTab,    // 24
    cWproGcDesF2hTab00,    // 24
    cWproGcDesF2hTab01,
    cWproGcDesF2hTab02,
    cWproGcDesF2hTab03,
    cWproGcDesF2hTab04,
    cWproGcDesF2hTab05,
    cWproGcDesF2hTab06,
    cWproGcDesF2hTab07,
    cWproGcDesF2hTab08,
    cWproGcDesF2hTab09,
    cWproGcDesF2hTab0A,
    cWproGcDesF2hTab0B,
    cWproGcDesF2hTab0C,
    cWproGcDesF2hTab0D,
    cWproGcDesF2hTab0E,
    cWproGcDesF2hTab0F,    // 39
    // cWproGcDesF2hTab10,
    // cWproGcDesF2hTab11,
    // cWproGcDesF2hTab12,
    // cWproGcDesF2hTab13,
    // cWproGcDesF2hTab14,
    // cWproGcDesF2hTab15,
    // cWproGcDesF2hTab16,
    // cWproGcDesF2hTab17,
    // cWproGcDesF2hTab18,
    // cWproGcDesF2hTab19,
    // cWproGcDesF2hTab1A,
    // cWproGcDesF2hTab1B,
    // cWproGcDesF2hTab1C,
    // cWproGcDesF2hTab1D,
    // cWproGcDesF2hTab1E,
    // cWproGcDesF2hTab1F,
    // cWproGcDesF2hTab20,
    // cWproGcDesF2hTab21,
    // cWproGcDesF2hTab22,
    // cWproGcDesF2hTab23,
    // cWproGcDesF2hTab24,
    // cWproGcDesF2hTab25,
    // cWproGcDesF2hTab26,
    // cWproGcDesF2hTab27,
    // cWproGcDesF2hTab28,
    // cWproGcDesF2hTab29,
    // cWproGcDesF2hTab2A,
    // cWproGcDesF2hTab2B,
    // cWproGcDesF2hTab2C,
    // cWproGcDesF2hTab2D,
    // cWproGcDesF2hTab2E,
    // cWproGcDesF2hTab2F,
    // cWproGcDesF2hTab30,
    // cWproGcDesF2hTab31,
    // cWproGcDesF2hTab32,
    // cWproGcDesF2hTab33,
    // cWproGcDesF2hTab34,
    // cWproGcDesF2hTab35,
    // cWproGcDesF2hTab36,
    // cWproGcDesF2hTab37,
    // cWproGcDesF2hTab38,
    // cWproGcDesF2hTab39,
    // cWproGcDesF2hTab3A,
    // cWproGcDesF2hTab3B,
    // cWproGcDesF2hTab3C,
    // cWproGcDesF2hTab3D,
    // cWproGcDesF2hTab3E,
    // cWproGcDesF2hTab3F,
    // cWproGcDesF2hTab40,
    // cWproGcDesF2hTab41,
    // cWproGcDesF2hTab42,
    // cWproGcDesF2hTab43,
    // cWproGcDesF2hTab44,
    // cWproGcDesF2hTab45,
    // cWproGcDesF2hTab46,
    // cWproGcDesF2hTab47,
    // cWproGcDesF2hTab48,
    // cWproGcDesF2hTab49,
    // cWproGcDesF2hTab4A,
    // cWproGcDesF2hTab4B,
    // cWproGcDesF2hTab4C,
    // cWproGcDesF2hTab4D,
    // cWproGcDesF2hTab4E,
    // cWproGcDesF2hTab4F,
    // cWproGcDesF2hTab50,
    // cWproGcDesF2hTab51,
    // cWproGcDesF2hTab52,
    // cWproGcDesF2hTab53,
    // cWproGcDesF2hTab54,
    // cWproGcDesF2hTab55,
    // cWproGcDesF2hTab56,
    // cWproGcDesF2hTab57,
    // cWproGcDesF2hTab58,
    // cWproGcDesF2hTab59,
    // cWproGcDesF2hTab5A,
    // cWproGcDesF2hTab5B,
    // cWproGcDesF2hTab5C,
    // cWproGcDesF2hTab5D,
    // cWproGcDesF2hTab5E,
    // cWproGcDesF2hTab5F,    // 126
    cWproGcInfoPage,    // 40
    cWproQBWithDumyW,    // 41
#if _EN_VPC_SWAP
    cWproCacheBlkVpCnt,    // 38
#endif
    cMaxWproPageType,    // 42
};

enum
{
    cEnSprOnesCntSetting=0,
    cDisSprOnesCntSetting,
};

enum
{
    cSerialEqual,    // 0
    cSerialSmaller,    // 1
    cSerialLarger,    // 2
};

enum
{
    cSysSprStart,
    cSysSprEnd,
};

enum
{
    cFoundCache,    // 0
    cFoundGcDes,    // 1
};

enum
{
    cInnvmeWriteUnc_00=0x0000,
    cInnvmeWriteUnc_01=0x0001,
    cInupdateF2hTable_00=0x0100,
    cInflushTlcF2hTab_00=0x0200,
    cInflushCacheF2hTab_00=0x0300,
    cInbgdClnCacheblkProc_00=0x0400,
    cInupdSeqLinkBrk_00=0x0500,
    cInupdSeqLinkBrk_01=0x0501,
    cInupdSeqLinkBrk_02=0x0502,
    cInupdSeqLinkBrk_03=0x0503,
    cInupdSeqLinkBrk_04=0x0504,
    cInflushOpenDesBlkH2fTab_00=0x0600,
    cInbgdReadReclaimProc_00=0x0700,
    cInsetActiveH2fBlk_00=0x0800,
    cInchkTrimH2fChg_00=0x0900,
    cInchkTrimH2fChg_01=0x0901,
    cInhdlNvmeWriteErr_00=0x0A00,
    cInhdlNvmeWriteErr_01=0x0A01,
    cInbgdClnH2fTabblkProc_00=0x0B00,
    cInflushF2hTableInRdlink_00=0x0C00,
    cInupdateH2fTabWindow_00=0x0D00,
    cInreFreshH2f_00=0x0E00,
    cInnvmeFwCommit_00=0x1000,
    cInnvmeFwCommit_01=0x1001,
    cInnvmeFwImageDl_00=0x1100,
    cInrstFwDlInfo_00=0x1200,
    cInfuncTskEraseUnitProc_00=0x1300,
    cInfuncTskEraseUnitProc_01=0x1301,
    cInfuncTskEraseUnitProc_02=0x1302,
    cInfuncTskProgFwDlTempIspBlock_00=0x1400,
    cInhandleNamespace_00=0x1E00,
    cInhandleProgramFail_00=0x1F00,
    cInhandlePcieWrErr_00=0x8000,
    cInhandlePcieRdErr_00=0x8100,
    cInhandlePcieOthErr_00=0x8300,
    cInfuncTskEraseUnitStart_00=0x2000,
    cIneraseUnitContinue_00=0x2100,
    cIneraseUnitContinue_01=0x2101,
    cInSecApiTcg_00=0x1F00,
    cInSecApiTcg_01=0x1F01,
};

enum
{
    cLogIDICCM,
    cLogIDDCCM,
    cLogIDHWReg,
    cLogIDTSB1,
    cLogIDTSB2,
    cMPInfo=cMPInfoBlockID,
};

enum
{
    c1stInfoInFLBit,    // 0
    cAllInfoInFLBit,    // 1
    c1stProgInFLBit,    // 2
    cAllProgInFLBit,    // 3
    cIndexInFLBit,    // 4
    cBadInfoInFLBit,    // 5
    cMPInfoInFLBit,    // 6
    cLogInfoInFLBit,    // 7
};

enum
{
#if (_GREYBOX)
    cDramMain,
    cBootIsp,
    cBoot2Isp,
    cRwIsp,
    cNvmeIsp,
    cSmiVuIsp,
    cSecTsbBank,
    cGreyBox,
    cCore1Main,
    cCore1Isp,
    cCore1Nvme,
    cCore1SmiVu,
    cCore1ErrHdl,
#else
    cBootIsp,    // 0
    cBoot2Isp,    // 1
    cRwIsp,    // 2
    cNvmeIsp,    // 3
    cSmiVuIsp,    // 4
    cVendorVuIsp,    // 5
    cCore1Start,    // 6
    cUartTsbBank,    // 7
    cSecTsbBank,    // 8
    cSecTsbBank1,    // 9
    cSecTsbBank2,    // 10
    cSecTsbBank3,    // 11
    cPs4ExitBootIsp,    // 12
    cLightswitchBank,    // 13
#endif    // if ((_INITDRAM)||(_GREYBOX))
};

enum    // core1 code bank
{
#if (_INITDRAM||_GREYBOX)
    cBootIsp1,    // 0
    cRwIsp1,    // 0
    cNvmeIsp1,    // 1
    cSmiVuIsp1,    // 2
    cErrHdlIsp1,    // 3
#else
    cRwIsp1,    // 0
    cNvmeIsp1,    // 1
    cSmiVuIsp1,    // 2
    cErrHdlIsp1,    // 3
#endif
};

enum
{
    cTLCData,    // 0
    cSLCData,
};

// <<<  merge 58xt IM3D

// for check Core1 state
enum
{
    cCore1SupendState=0,    // 0
    cCore1ReadyState,    // 1
    cCore1SleepState,    // 2
    cCore1BootState_0,    // 3
    cCore1BootState_1,    // 4
    cCore1BootState_2,    // 5
    cCore1BootState_3,    // 6
    cCore1BootState_4,    // 7
    cCore1BootState_SwapCPU1Rw,    // 8
    cCore1BootState_Finished,    // 9
};

// ISP Code position (nth 512byte-Sector) and Length
#if (_INITDRAM||_GREYBOX)
#define cSwapCodeSize                            0x200    // 256K
#define cSwapCodeSize1                           0x20    // 16K
#define cGreyBoxSwapCodeSize1                    0x80    // 64K
#define cGbMaxSwapCodeSize                       0x80
#define cSwapCore1CodeSize                       0xB00    // 0x100
#define cIspCodeEnd                              (0x80*4)
enum
{
    cGreyBoxBootItcmLoadCode,
    cGreyBoxBootCore0Ready,
    cGreyBoxBootCore1Ready,
};

#else
#define cSwapCodeSize                            0x80
#define cSwapCodeSize1                           0x20
#endif

#define cUartTsbSwapCodeSize                     0x3
#define cUartTsbStartBufIdx                      704    // start from 352KB, last 32KB of TSB0
#define cUartTsbCodeAddr                         0x40058000    // last 32KB of Tsb0
#define cUartTsbCmdOffset                        0x20000    // 128KB

#define csecBaseSwapCodeSize                     0x40
#define cSecApiSwapCodeSize                      0x100    // Security API bin size is 120KB

#define cMainCode                                0x00
#define cBoot1Code                               (cMainCode+cSwapCodeSize)
#define cBoot2Code                               (cBoot1Code+cSwapCodeSize)
#define cRwCode                                  (cBoot2Code+cSwapCodeSize)
#define cNVMeCode                                (cRwCode+cSwapCodeSize)
#define cSmiVuCode                               (cNVMeCode+cSwapCodeSize)
#define cHynixVuCode                             (cSmiVuCode+cSwapCodeSize)

// for function pointer
enum
{
    cfuncBootFunc1,
    cfuncBootFunc2,

    // cfuncPostRwTaskToPrdInfo,
    cfuncServRwCmdQue,    // cfuncHdlRwTaskInPrdInfo,
    // cfuncTermFlashOperRw,
    // cfuncTrigFlashCmdFifoW,
    cfuncNvmeDeleteSubQueue,
    cfuncNvmeCreateSubQueue,
    cfuncNvmeDeleteCmplQueue,
    cfuncNvmeCreateCmplQueue,
    cfuncNvmeGetLogPage,
    cfuncNvmeIdentify,
    cfuncNvmeAbort,
    cfuncNvmeSetFeature,
    cfuncNvmeGetFeature,
    cfuncNvmeAsynEvent,
    cfuncNvmeFwCommit,
    cfuncNvmeFwImageDl,
    cfuncNvmeFormat,
    cfuncNvmeNsManagemet,
    cfuncNvmeNsAttachment,
    cfuncVendorNonData,
    cfuncVendorDataOut,
    cfuncVendorDataIn,
    cfuncNvmeVuCmdNonData,
    cfuncNvmeVuCmdDataOut,
    cfuncNvmeVuCmdDataIn,
    cfuncBgdClnBlk,
    cfuncNvmeFlush,
    cfuncNvmeWriteUnc,
    cfuncNvmeCompare,
    cfuncNvmeWriteZero,
    cfuncNvmeDataSetMgm,
    cfuncNvmeDst,
    cfuncHandleDst,
    cfuncHandleAsyncEvent,
    cfuncSaveParity,
    cfuncRestoParity,
    cfuncSecApiTrustedSend,
    cfuncSecApiTrustedReceive,
    cfuncNvmeDirectiveSend,
    cfuncNvmeDirectiveReceive,
    cfuncNvmeSanitize,
    cfuncSanitizeContinueOp,
    cfuncLiteonVendorNonData,
    cfuncLiteonVendorDataOut,
    cfuncLiteonVendorDataIn,
    cfuncChkVPc,
};

// codeFuncPtrCore1
enum
{
    ccore1Boot,
    cmodifyH2FtabBootCore1,
    cchkPostReadFifo,
    cmarkBadBlock,
    cmodifyH2FtabCore1,
    cgetGcSrcBlk,
    csaveWproBadInfo,

    // cdoRaidDecode,
};

// codeFuncPtr2Core1
enum
{
    cfuncTskVendorOp,
    cfuncTskEraseUnitProc,
    cfuncTskProgFwDlTempIspBlock,
    cfuncTskActivateIsp,
    cfuncTskJudgeSwapIsp,
    cfuncTskChkIspBlock,
    cfuncTskSwapFwSlotIsp,
    cfuncTskLoadIspPage,
    cchkPfFblock,
    cchkPWRCore1,
    cfuncTskLoadTelemetryCtlrLog,
    cfuncTskEraseUnitStart,
    cfuncTskEraseUnitContinue,
    cfuncTskHandleCntForSanitize,
};

// codeFuncPtr3Core1
enum
{
    cfuncgetLastPageInv,
};

// codeFuncPtr4Core1
enum
{
    crecoverFlashReg,
};

// codeFuncPtr5Core1
enum
{
    cbuildValidCachePage,
};

enum
{
    // cfuncTrigFlashCmdFifoR,
    cfuncTermFlashOperRw,
    cfuncProcessTrim,
    cfuncResetCpu,
};

// enum
// {
// cfuncGetCurrentTemp,
// };

// enum
// {
//    cfuncAddErrorLog,
// };

// enum
// {
//    cfuncProgWpro,
// };

// enum
// {
//    cfuncSetZeroVpcBlock,
// };

#define  cFreq12p5Mhz                            0x0520

#define  cFreq25Mhz                              0x0420
#define  cFreq37p5Mhz                            0x0430

#define  cFreq50Mhz                              0x0320
#define  cFreq62p5Mhz                            0x0328
#define  cFreq75Mhz                              0x0330
#define  cFreq87p5Mhz                            0x0338

#define  cFreq100Mhz                             0x0220
#define  cFreq112p5Mhz                           0x0224
#define  cFreq125Mhz                             0x0228
#define  cFreq137p5Mhz                           0x022C
#define  cFreq150Mhz                             0x0230
#define  cFreq162p5Mhz                           0x0234
#define  cFreq175Mhz                             0x0238
#define  cFreq187p5Mhz                           0x023C

#define  cFreq200Mhz                             0x0120
#define  cFreq212p5Mhz                           0x0122
#define  cFreq225Mhz                             0x0124
#define  cFreq237p5Mhz                           0x0126
#define  cFreq250Mhz                             0x0128
#define  cFreq262p5Mhz                           0x012A
#define  cFreq275Mhz                             0x012C
#define  cFreq287p5Mhz                           0x012E
#define  cFreq300Mhz                             0x0130

#define  cFreq312p5Mhz                           0x0132
#define  cFreq325Mhz                             0x0134
#define  cFreq331p25Mhz                          0x0135
#define  cFreq337p5Mhz                           0x0136
#define  cFreq350Mhz                             0x0138
#define  cFreq362p5Mhz                           0x013A
#define  cFreq375Mhz                             0x013C
#define  cFreq387p5Mhz                           0x013E

#define  cFreq400Mhz                             0x0020

#define  cFreq500Mhz                             0x0028
#define  cFreq512p5Mhz                           0x0029
#define  cFreq525Mhz                             0x002a
#define  cFreq537p5Mhz                           0x002b
#define  cFreq550Mhz                             0x002c
#define  cFreq562p5Mhz                           0x002d
#define  cFreq575Mhz                             0x002e
#define  cFreq587p5Mhz                           0x002f
#define  cFreq600Mhz                             0x0030

#define cSetSlcMode                              0
#define cSetMlcMode                              2
#define cSetTlcMode                              4
#define cBpcFeatureAddr                          0x91
#define cNopT_CWAW                               0x10    // CMD0x85, wait 300ns , ALE-5

#define mChkSataWriteAbort                       0
#define cSrchLword0                              cBit0
#define cSrchLword1                              cBit1
#define cSrchLword2                              cBit2
#define cSrchLword3                              cBit3
#define c32BootFlushVarSAddr                     cTsb0Addr
#define c32FlushVarSAddr                         (cTsb0Addr+0x40000)
// #define c2UncTypeMask                            0x3FFFFFFF
#if _EN_VPC_SWAP
#define cSortF2HTabSise                          0x1E000
#else
#define cSortF2HTabSise                          0x20000
#endif
#define cSortH2FBufSize                          0x200
#define cSortOccSegSize                          0x100
#define cSortOccSegNum                           (cTsb0Size/cSortOccSegSize)

#if (_TSB_BiCS3||_SANDISK_3D_GEN2||_SANDISK_3D_GEN3||_TSB_BiCS4)
#define cProgCntPerWL                            3
#define cTLCProgCmd1                             0x1A
#define cTLCProgCmd2                             0x10
#define cSlcCmd                                  0x05    // 0xA2
#define cMsbPreFixCmd                            0x03
#if _EnSpareFunc
#define cMultiplaneInSprSet                      0
#define cPlaneNumInSprSet                        1
#define cPlaneShiftOfSprSet                      0
#define cFillSpareSizeOfSprSet                   1
#define cSprGrpMask                              3
#define cSpareUseOfSLC                           2
#define cSpareUseOfTLC                           6
#define cSpareUseOfH2F                           1
#define cSpareRegisterCnt                        8
#endif

#endif    // if (_TSB_BiCS3||_SANDISK_3D_GEN2)

#define cProdTyp                                 0x00
#define cPhyCapacity                             0x01
#define cLogiCapacity                            0x02
#define cTotalDieNum                             0x03
#define cFtlCoreNum                              0x04
#define cChPerCoreNum                            0x05
#define cCePerCh                                 0x06
#define cDiePerCe                                0x07
#define cLbaSize                                 0x08
#define cNandType                                0x0a
#define cPlanePerDie                             0x0b
#define cBlkPerPlane                             0x0c
#define cPagePerBlk                              0x0d
#define cLogiPageSize                            0x0e
#define cPageSize                                0x0f
#define cSpareSize                               0x10
#define cActiveBlk                               0x28
#define cActivePage                              0x29
#define cGcActiveBlk                             0x2b
#define cGcActivePage                            0x2c
#define cRefreshBlk                              0x2e
#define cRefreshPage                             0x2f
#define cCurCellMo                               0x31
#define cBgmsState                               0x32

enum
{
    cRamDisk,
    cS36_128Gb_MLC,
    cS48_256Gb_TLC,
};

#define cMPInfoDriveSNStrAddr                    0x10
#define cMPInfoWWNStrAddr                        0x50
#define cMPInfoModelNameStrAddr                  0x70
#define cMPInfoFwVerStrAddr                      0x100

#define cMPInfoDataStOfst                        0x1200

#define cModelNameLength                         40
#define cDriveSerialNumberLength                 20
#define cFwVerLength                             8

#define cProg16kF2H                              c16Bit9
#define cProg32kF2H                              c16Bit10
#define cProgPlaneRaid                           c16Bit11

/* Gc Flow */
enum
{
    cGcFlowIdl,    // 0

    cGcFlowS2S,    // 1
    // cGcFlowM2M,
    cGcFlowS2T,    // 2
    // cGcFlowT2S,    // cGcFlowMlc2Mlc,
    // cGcFlowS2M,
    cGcFlowT2T,    // 3

    // cGcFlowRsv,
};

// MIKEY define for GC, Max Gc Src Blk Number.
#define cMaxGcPrioBlkNum            16
#define cMaxGcSrcBlkNum             16    // 32
#define cMaxSkipGcSrcBlkNum         (cMaxGcSrcBlkNum*4)    // 72
#define cMinGcTlcSprBlkNum          5
#define cMinS2SSrcBlkNum            3

/* Slc Gc State. */
enum
{
    cGcStateIdle,    // 0
    cGcBuildSrc,    // 1
    cGcMoveData,    // 2
    // cGcDesBankChg,    // 3
    // cGcPostWR,    // 4
    cGcPostWriteRead,
    cGcChkFingerFail,
    cGcFlushH2F,    // 5
};

enum
{
    cWaitTrigRCnt=cBit0,
    cWaitTrigWCnt=cBit1,
    cWaitCmdBz=cBit7,
};

enum
{
    cVthLow,
    cVthUp,
};

#if _EN_SLCOpenBlkReadScrub
enum
{
    cFlushIdle,    // 0
    cWriteDummy,    // 1
    cFlushActive,    // 2
};

#endif

enum
{
    cGetSlcBlockInital,    // 0
    cGetSlcBlockStep1,    // 1
    cGetSlcBlockStep2,    // 2
};

#define cLDPCSeparateTrack          cBit4
#define cSeparateFR                 cBit0
#define cRetryRegDelayCnt           0xA0
#define cCSBVthTrackDiv_Low         4    // Ecc Team

#define cMaxRecordRetrySet          0x20

#define cNoGetIdxOfRetryRec         0xFF

#define cDgRetryCntEntrySize        4    // 32bit
#define cDgRetryLvCntType           3    // LSB, CSB, MSB,
// #define cDgRetryLvSetNum            48    // fomer, retry table set , N4, N6, N8, Fail
#define cDgRetryLvSetNum            8    // fomer, retry table set , N4, N6, N8, Fail
#define cDgRetryLvCntbyDie          8

// #define cMaxRetryRecCnt             64    // ch*Intlv  4Ch 16Way
#define cMaxRetryRecCnt             16    // ch*Intlv  4Ch 16Way

// #define cDgSoftRecordCnt            176    // N2:2bytes, N4:8bytes, N6:8bytes, N8:80bytes.
#define cDgSoftRecordCnt            496    // N2:2bytes, N4:8bytes, N6:8bytes, N8:80bytes.
#define cDgRetryFailCntRamSize      512-cDgSoftRecordCnt
#define cDgRetryFailCnt             ((cDgRetryFailCntRamSize)/8)

enum    // for debug recode even retry set
{
    cFormerVth=0,
    cRetryTable1st=1,
    cLDPCN4SoftDecode=cDgRetryLvSetNum-4,    // 44
    cLDPCN6SoftDecode=cDgRetryLvSetNum-3,    // 45
    cLDPCN8SoftDecode=cDgRetryLvSetNum-2,    // 46
    cRetryFail=cDgRetryLvSetNum-1,    // 47
};

enum
{
    cRetryTable=0x10,
    cRetryLDPC=0x20,
};

enum
{
    cNormalMode,
    cCalAR,
    cCalSLCR
};

#define cVuCmdVthEnable             cBit0
#define cVuCmdRetryEnable           cBit1

#define cVuWdEmptyFail              0xEF

#define cRetryDat                   (cBit0|cBit7)
#define cRetrySpr                   (cBit2|cBit6)

#define cRetryTypMsk                0x0F
#define cRetryModMsk                0xF0

#define cRetryRegNum                8
#define cRetryRegNumTLC             7
#define cRetryRegNumSLC             1
#define cLDPCN8LoopCnt              15    // BICS4 15 N8
#define cLDPCSoftLoopPerDecStep     4

#define cRetryForceSpr              cBit5    // just isn't cRetryDat and cRetrySpr
#define cRetryAutoBuf               cBit1

#define cRetryRegAddrOfst           0x20
#define cRetryTabTypAddrOfst        0x10
#if _ENABLE_RETRY_TSB_BiCS4_256Gb
#define cRetryVerAddrOfst           0x160
#define cLvVerAddrOfst              0x20
#else
#define cRetryVerAddrOfst           0
#define cLvVerAddrOfst              0
#endif
#define cLSBLvAddrOfst              0x11
#define cCSBLvAddrOfst              0x12
#define cMSBLvAddrOfst              0x13
#define cRetrySlcLvAddrOfst         0x14
#define cRetryMaxShiftRStep         0x7F
#define cRetryMaxShiftLStep         0x80

#define cRetryValAddrOfst           0x40

// #define c16SlcRetryRegAddrOfst      0x200
#define cRetryTabOptOfst            0x200
#define c16SlcRetryLvAddrOfst       0x201
#define c16SlcRetryRegCntAddrOfst   0x202
#define c16SlcRetryHalfLvAddrOfst   0x203
#define c16SlcRetryRegAddrOfst      0x210
#define c16SlcRetryValAddrOfst      0x230

#define cSlcRRTabEnable             cBit0
#define cSndkSlcModeRRCmd           cBit1

#if 1    // normal flow this value should be set in retry table
// temporary setting, need set in retry table and check this value with vendor or ECC team
#define c32SlcClosedBlkVpcThr         (0x990000)    // 10027008
#define c32TLCBlkRCBolThr             (2000000)    // 20190805_Bruce
#define c32TLCBlkRCEolThr             (500000)
#define c32SLCCloseBlkRCBolThr        (9000000)    // 20190121_Bruce_for STD IOMeter performance
#define c32SLCCloseBlkRCEolThr        (3000000)    // 20190121_Bruce_for STD IOMeter performance
#define c32SLCOpenBlkRCThr            (9000000)    // 9000000  20190723_SamKe_for STD iometer Randread
#define c16TLCBoltoEolECThr           (150)
#define c16SLCBoltoEolECThr           (5000)
#else
// debug Read Count Flow
#define c64SlcOpenBlkVpcThr           (0x0000000000000800)
#define c64SlcClosedBlkVpcThr         (0x0000000000001000)
#define c64SlcActiveThrOffset         (c64SlcClosedBlkVpcThr-c64SlcOpenBlkVpcThr)
#define c64TlcOpenBlkVpcThr           (0x0000000000000080)
#define c64TlcClosedBlkVpcThr         (0x0000000000000800)
#define c64TlcActiveThrOffset         (c64TlcClosedBlkVpcThr-c64TlcOpenBlkVpcThr)
#define c16ChkRdCntFreq               0x40    // 0x4000

#endif    // if 1
// let all TLC Read count shift some offset, then fw only need to check one value
#define c64DiffOfTlcNSlcThr           (c64SlcClosedBlkVpcThr-c64TlcClosedBlkVpcThr)    // SLC > TLC

#define c64ChgReadCntBit              (0x8000000000000000)

#define cChkRdCntLoop                 20
#define cChkRdCntRatio                5
enum
{
    cTouchRdCntThr=1,
    cDoSoftRetry=2,
    cDoRetryButFail=3,
    cDoWearLeveling=4,
};

#if (_TSB_BiCS3)

enum
{
    cAR,
    cCR,
    cER,
    cGR,
    cBR,
    cDR,
    cFR,
    cSLCR,
};

#define cRetryFeatureAddrTLC        0x89
#define cRetryFeatureAddrSLC        0x8B

#define cLDPCSoftStep               10
#define cLDPCSlcMoSoftStep          16
#define cMaxRetryRegisterCnt        8
#define c16LDPCBaseCnt              4096
#define cLDPCBasePageSize           16    // Unit:SectorH
#define c32LDPCOverHillCount        500
#define cLDPCTrackStepCnt_SLC       6
#define cLDPCTrackStepCnt           6

#define cTrackingPosiBoundary       0x20    // +32
#define cTrackingPosiBoundary_SLC   0x28    // +40
#define cTrackingNegiBoundary       0xE0    // -32
#define cTrackingNegiBoundary_SLC   0x28    // -40
#define cTrackingNegiBoundary_AR    0xF6
#endif    // if (_TSB_BiCS3)

#if (_TSB_BiCS4)

enum
{
    cAR,
    cCR,
    cER,
    cGR,
    cBR,
    cDR,
    cFR,
    cSLCR,
};

#define cRetryFeatureAddrTLC        0x89
#define cRetryFeatureAddrSLC        0x8B

#define cLDPCSoftStep               10
#define cLDPCSlcMoSoftStep          16
#define cMaxRetryRegisterCnt        8
#define c16LDPCBaseCnt              4096
#define cLDPCBasePageSize           16    // Unit:SectorH
#define c32LDPCOverHillCount        500
#define cLDPCTrackStepCnt_SLC       6
#define cLDPCTrackStepCnt           6

#define cTrackingPosiBoundary       0x20    // +32
#define cTrackingPosiBoundary_SLC   0x28    // +40
#define cTrackingNegiBoundary       0xE0    // -32
#define cTrackingNegiBoundary_SLC   0x28    // -40
#define cTrackingNegiBoundary_AR    0xF6

#if _EN_Fake_ProgramFail_Check
#define cFakeProgramFailRetryTableCheckIndex       0x01
#define cFakeProgramFailRetryEccBitTh              0x50
#else
#define cFakeProgramFailRetryTableCheckIndex       0x17
#define cFakeProgramFailRetryEccBitTh              0xD0
#endif

#endif    // if (_TSB_BiCS4)

#if _SANDISK_3D_GEN2

enum
{
    cAR,
    cCR,
    cER,
    cGR,
    cBR,
    cDR,
    cFR,
    cSLCR,
};

#define cRetryFeatureAddrTLC        0x12
#define cRetryFeatureAddrSLC        0x14

#define cLDPCSoftStep               10
#define cLDPCSlcMoSoftStep          16
#define cMaxRetryRegisterCnt        8
#define c16LDPCBaseCnt              4096
#define cLDPCBasePageSize           16    // Unit:SectorH
#define c32LDPCOverHillCount        500
#define cLDPCTrackStepCnt_SLC       6
#define cLDPCTrackStepCnt           6

#define cTrackingPosiBoundary       0x20    // +32
#define cTrackingPosiBoundary_SLC   0x28    // +40
#define cTrackingNegiBoundary       0xE0    // -32
#define cTrackingNegiBoundary_SLC   0x28    // -40
#define cTrackingNegiBoundary_AR    0xF6
#endif    // if (_SANDISK_3D_GEN2)

#if _SANDISK_3D_GEN3

enum
{
    cAR,
    cCR,
    cER,
    cGR,
    cBR,
    cDR,
    cFR,
    cSLCR,
};

#define cRetryFeatureAddrTLC        0x12
#define cRetryFeatureAddrSLC        0x14

#define cLDPCSoftStep               10
#define cLDPCSlcMoSoftStep          16
#define cMaxRetryRegisterCnt        8
#define c16LDPCBaseCnt              4096
#define cLDPCBasePageSize           16    // Unit:SectorH
#define c32LDPCOverHillCount        500
#define cLDPCTrackStepCnt_SLC       6
#define cLDPCTrackStepCnt           6

#define cTrackingPosiBoundary       0x20    // +32
#define cTrackingPosiBoundary_SLC   0x28    // +40
#define cTrackingNegiBoundary       0xE0    // -32
#define cTrackingNegiBoundary_SLC   0x28    // -40
#define cTrackingNegiBoundary_AR    0xF6
#endif    // if (_SANDISK_3D_GEN3)

// RAID-related Constant
enum
{
    cRaidDataBlk,
    cRaidGcBlk,
    cRaidPtySBlk,
    cRaidPtyTBlk,
    cRaidEngTemp,
    cRaidHTabBlk,
};    // TotalRaidType

enum
{
    cRaidActNon,
    cRaidActEngInitialize,
    cRaidActFGEngSetKVal,
    cRaidActBGEngSetKVal,
    cRaidActDataEnc,
    cRaidActPtyOut,
    cRaidActHdmaTerm,
    cRaidActHdmaResm,
};    // Other RAID Actions

enum
{
    cRaidCmdData,
    cRaidCmdPty,
    cRaidCmdTerm,
    cRaidCmdResm,
    cRaidCmdDecIn,
    cRaidCmdDecOut,
};    // RAID Cmds for HW Reg

enum
{
    cRaidEng0,
    cRaidEng1,
    cRaidEng2,
    cRaidEng3,
    cRaidEng4,
    cRaidEng5,
    cRaidEng6,
    cRaidEng7,
    cRaidEng8,
    cRaidEng9,
    cRaidEng10,
    cRaidEng11,
};    // Raid Engines

enum
{
    cWriteHmbPty,
    cReadHmbPty,
};

enum
{
    cRaidParaRst4PcieErr,
    cRaidParaRst4ProgFail,
};    // Reset Raid parameter

#define cRaidParityNum                           8
#define cRaidEngineBuf4KSize                     4
#define cRaidTotalEng                            12
#define cRaidTotalEngGrp                         (cRaidTotalEng>>1)
#define cRaidEngPerGrp                           2
#define cRaidTotalType                           (cRaidHTabBlk+1)
#define cRaidMinSctrCnt                          4    // (Kane_20170316) 2KB or 4Sectors
#define cRaidUnitChgShiftBit                     2    // (Kane_20170116) Change unit from "2 chunks" to "1 sector"
#define cRaidParityBlockNum                      2
#define cRaidParityPageNum                       (c16MaxWLNum)

#define cRaidEngFull                             c12BitFF
#define cRaidDecQueDepth                         (cMaxChNum*cMaxIntlvWay)
#define cRaidStringShiftBit                      3
#define cRaidStringPerGrp                        (1<<cRaidStringShiftBit)
#if _ENABLE_RAID
#define c4kNumPerRaidPty                         cRaidEngineBuf4KSize
#else
#define c4kNumPerRaidPty                         0
#endif
#define cReadGcDesF2h                            c16Bit11
#define cHalfRH2fTabNum                          (cMaxRH2fTabNum/2)
#define cHmbPtyQueDpt                            8

#define cRaidDataKVal                            gTotalIntlvChPlaneNum
#define cRaidDataSctrNum                         (cRaidEngineBuf4KSize*cSctrPer4k)
#define cRaidHTabKVal                            (gTotalPlaneOfH2fTab-1)
#define cRaidHTabSctrNum                         gSectorPerPlaneH
#define cRaidHTabTotalSctrCnt                    (cRaidHTabKVal*cRaidHTabSctrNum)

#define cRaidPtyClr                              cBit5
#define cRaid4KPty                               cBit6

#define cRaidActOptNon                           0x0000
#define cRaidActOptEncOnly                       0x0010
#define cRaidActOptPtyClr                        0x0020
#define cRaidActOptBGEnc                         0x0040
#define cRaidActOptMerge                         0x0080

#define cRaidTypeMsk                             0xF000
#define cRaidFGEngMsk                            0x0F00
#define cRaidActMsk                              0x000F

#define cRaidEnableDecode                        cBit0
#define cRaidUnderDecode                         cBit1
#define cRaidDecodeMode                          cBit2
// #define cRaidDecData                             cBit4
// #define cRaidDecH2fTab                           cBit5
// #define cRaidDecH2f1kTab                         cBit6
#define cRaidDecOptMsk                           cLoNibble
#define cRaidDecTypMsk                           cHiNibble

#define cRaidHmbEn                               cBit0
#define cRaidDataPty                             cBit6
#define cRaidGcPty                               cBit7

// Hdma Related Constant
enum
{
    cHdmaCrcOp,
    cHdmaSrchOp,
    cHdmaDmaOp,
    cHdmaOFlagOp,
};

// Hdma Parameter
enum
{
    cHdmaTsb2Tsb,
    cHdmaTsb2Bvci,
    cHdmaBvci2Tsb,
    cHdmaBvci2Bvci,
};

enum
{
    cCDM_Non,
    cCDM_PrePare,
    cCDM_Triger,
};

enum
{
    cCCT_OFF,
    cCCT_ON,
};

enum
{
    cIoMeterNon,
    cIoMeterChk,
    cIoMeterTrig,
    cRecoverychkTrig,
};

#define cHdmaWait                                c16Bit4
#define cHdmaNotWait                             0x00
#define cHdmaTsbFlag                             c16Bit5
#define cHdmaTsbWriteFlag                        c16Bit6
#define cHdmaRaidFlag                            c16Bit7
#define cHdmaEnCrc                               c16Bit8
#define cHdmaGenCrc                              c16Bit9
#define cHdmaCmpCrc                              c16Bit10
#define cHdmaEnFwAes                             c16Bit11

#define cHdmaQueDptFW                            (cMaxHdmaDepth)

#define cHdmaPattenMode                          c16Bit9
/*
   #define cDmaTsb2Tsb                              0
   #define cDmaTsb2Bvci                             1
   #define cDmaBvci2Tsb                             2
   #define cDmaBvci2Bvci                            3
   #define cDmaTsb2Dccm                             4
   #define cDmaDccm2Tsb                             5
   #define cDmaIccM2Tsb                             6
   #define cDmaTsb2Iccm                             7
   #define cDmaTsb2Stcm                             8
   #define cDmaStcm2Tsb                             9
   #define cDmaPattern2Bvci                         10    // (KT) - New add for Dram Ecc program pattern
   #define cDmaPattern2Tsb                          11    // (KT) - New add for Dram Ecc program pattern
   #define cDmaTsb2Cpu1Dccm                         12
   #define cDmaCpu1Dccm2Tsb                         13
   #define cDmaCpu1Iccm2Tsb                         14
   #define cDmaTsb2Cpu1Iccm                         15
   */
#define cHdmaSrcNonFlag                          0x0000
#define cHdmaSrcBufFlag                          0x0040
#define cHdmaSrcRaidFlagOnly                     0x0080
#define cHdmaSrcRaidBufFlag                      0x00C0
#define cHdmaSrcFlagMsk                          0x00C0
#define cHdmaDesNonFlag                          0x0000
#define cHdmaDesBufFlag                          0x0010
#define cHdmaDesRaidFlag                         0x0020
#define cHdmaDesFlagMsk                          0x0030
#define cHdmaXfrDirMsk                           0x000F

// Bop Related Constant
enum
{
    cDisBopPause,
    cEnBopPause,
};

enum
{
    cBopCrcOp,
    cBopSrchOp,
    cBopDmaOp,
    cBopOFlagOp,
};

enum
{
    cBopTsb2Tsb,
    cBopTsb2Bvci,
    cBopBvci2Tsb,
    cBopBvci2Bvci,
};

// BOP CLEAR RAM OPTION

enum
{
    cClrCore0Iccm,
    cClrCore0Dccm,
    cClrCore1Iccm,
    cClrCore1Dccm,
    cClrStcm,
    cClrTsb,
    cClrDram
};

// BOP COPY RAM OPTION

enum
{
    cCopyTsb2Tsb,

    cCopyTsb2Dram,
    cCopyDram2Tsb,
    cCopyDram2Dram,
    cCopyTsb2Dccm,
    cCopyDccm2Tsb,
    cCopyIccm2Tsb,
    cCopyTsb2Iccm,
    cCopyTsb2Stcm,
    cCopyStcm2Tsb,
    cCopyTsb2Cpu1Dccm,
    cCopyCpu1Dccm2Tsb,
    cCopyCpu1Iccm2Tsb,
    cCopyTsb2Cpu1Iccm,
    cCopyPattern2Tsb,
};

#define cBopSrcAutoBuf                           cBit6
#define cBopDesAutoBuf                           cBit7

#define cBopSrchMin                              0x00
#define cBopSrchMax                              cBit0
#define cBopSrchDat                              cBit1
#define cBopSrchStat                             (cBit0|cBit1)

#define cBopByteMo                               0x00
#define cBopWordMo                               cBit2
#define cBopLwordMo                              cBit3
// enum
// {
//    cBopMultiByteMo,
//    cBopMultiWordMo,
//    cBopMultiLwordMo,
// };

#define cBopNotWait                              0x00
#define cBopWait                                 c16Bit4
#define cBopTsbFlag                              c16Bit5
#define cBopRaidFlag                             c16Bit6
#define cBopNotRstFlag                           c16Bit5
#define cBopSrchDccm                             c16Bit6
#define cBopSrchSkip                             c16Bit7
#define cBopEnCrc                                c16Bit8
#define cBopGenCrc                               c16Bit9
#define cBopCmpCrc                               c16Bit10
#define cBopSrchIccm                             c16Bit11
#define cBopSrchStcm                             c16Bit12

#define cBopSrcNonFlag                           0x00
#define cBopSrcBufFlag                           0x40
#define cBopSrcRaidFlag                          0x80
#define cBopSrcFlagMsk                           0xC0
#define cBopDesNonFlag                           0x00
#define cBopDesBufFlag                           0x10
#define cBopDesRaidFlag                          0x20
#define cBopDesFlagMsk                           0x30

#define cInvBufFlag                              cBit0
#define cInvOccFlag                              cBit1

enum
{
    cUGSD=0,
    cGSD,    // HMB data will lost
    cDevicePs3,
    cDevicePs4,
    cOnPcieErr,
    cDevicePsD3,
};

enum
{
    c16FuncRdlinkStep3=0x0100,
};

enum
{
    cLdpcNormalErr,
    cLdpcPwr
};

// TrimCmd.c
#define cTrimLBAInfoStBuf                        (8)
#define cTrimLenInfoStBuf                        (12)
#define c16TrimH2fTabStBuf                       (256)

#define cEnE2e                                   cBit0
#define cEnCpuEcc                                cBit1
#define cEnTsbEcc                                cBit2
// #define cEnNitroRaid                             cBit3

#define cEnTcg                                   cBit0
#define cEnIeee1667                              cBit1
#define cEnSessionTimer                          cBit2
#define cEnPyrite                                cBit3
#define cEnOpalite                               cBit4
#define cEnAtaPassThrough                        cBit5

// form factor
enum
{
    cInch25=0,
    cEV_Board,
    cmSATA,
    cNGFF,
    cCFast,
    cHalfSlim,
    cBGA,
    cM_2
};

// SramEcc.c
typedef enum
{
    cTsbCor=0,
    cTsbCorRmw,
    cTsbErr,
    cTsbErrRmw
}TsbDackType;

typedef enum
{
    cCpuCorAll=0,
    cCpuCorItag,
    cCpuCorIdata,
    cCpuCorDtag,
    cCpuCorData,
    cCpuCorDtcm,
    cCpuCorItcm,
    cCpuCorAxi,
    cCpuErrAll,
    cCpuErrItcm,
    cCpuErrDtcm,
    cCpuErrDdata,
    cCpuErrDtag,
    cCpuErrAxi,
    cCpuErrLivelock
}CpuEccFailType;

// E2e.c
typedef enum
{
    cE2eUserDataBlk=0,
    cE2eH2fBlk,
    cE2eH2f1kBlk,
    cE2eIndexBlk,    // No read data case.
    cE2eInfoBlk,
    cE2eWproBlk,
    cE2eMpInfoBlk,    // No read data case.
    cE2eUserData,    // For compare command
    cE2eMaxType
}E2eInternalData;

// Enabled VDT flag
#define cEnVdt18Dram                             cBit0
#define cEnVdtEnUnDefB1                          cBit1
#define cEnVdtFshVcc                             cBit2
#define cEnVdtFshFio                             cBit3
#define cEnVdtEnUnDefB4                          cBit4
#define cEnVdtEnUnDefB5                          cBit5
#define cEnVdtEnUnDefB6                          cBit6
#define cEnVdtEnUnDefB7                          cBit7

#define cHdlNvmeFlush                            cBit0    // 20190417_ChrisSu
#define cHdl1RestSctr                            cBit1
#define cDelayComplect                           cBit2
#define cDelayPrdDone                            cBit3

enum
{
    cNotUnderRw=0,
    cFreeToResetPcie=0,
    cUnderRWHdlErr=1,
    cUnderRWNoHdlErr=2,
    cUnderAlreadyHdlErr=3,
};

#define cMaxApstSize                             4

#define cHwVerSM2263AA                           0x00
#define cHwVerSM2263AB                           0x01

// --(Sam)--for L1 in-band issue--//
#define cForceWake                               1
#define cReleasePd                               0

#define cDynamicMode                             0
#define cStartStaticMode                         cBit0
#define cEndStaticMode                           cBit1

#define cResetCpuSrst                            0
#define cResetCpuAll                             1

// SLCQ use
#if _EN_VPC_SWAP
#define cMaxSlcBlkQ                             300    // 1958//990*2
#define cIOMeterMaxSlcBlkQ                      1800    // 1958//990*2
#else
#define cMaxSlcBlkQ                              150
#endif
#define cDirtyCdmRsvSprThr                      123    // 20190329_ChrisSu  sync SMI solution
enum
{
    cFromQBoot,
    cFromCacheInfo,
};

enum
{
    cRwBrkIdle=0,
    cRwBrkTimeout=1,    // PSchagne also use it
    cRwBrkNoPrdToDo=2,    // PSchagne also use it
    cRwBrkPcieErr=87,
};

#define cDebugRwDigit                            0xE0
#define cNamespaceMax                            1    // 4, WD don't request support multi namespace now

// Prog fail
#define cPopPfFBlkCnt                            4
#define cRecovPfPage                             2

#define c16PfRecovPreSIdx                        (c16RH2fTabSIdx)
#define c16PfRecovCurSIdx                        (c16PfRecovPreSIdx+64)
#define c16PfMoveDataSIdx                        (c16RaidBufSIdx)

#define cPfSprActive                             0
#define cPfSprRecovCur                           1
#define cPfSprRecovPre                           (cPfSprRecovCur+cMaxPlaneNum)
#define cPfSprAll                                (cPfSprRecovPre+cMaxPlaneNum)

enum
{
    cCurrPage,
    cPrevPage,
};

enum
{
    cBakParity,
    cResParity,
};

enum
{
    cPreCacheBlkIdx=0,
    cFluCacheBlkIdx,
    cActCacheBlkIdx,
    cCacheBlkNum,
};

#define cGequ                                    1
#define cLequ                                    2

// Cache info (32k) offset
#if _EN_VPC_SWAP
#define cg32arMlcMoBit                    (c32Tsb2SAddr+0x00)
#define cg32arSkipGcSrch                    (cg32arMlcMoBit+(c16MaxBlockNum/8))
#define cg32arVPCntValid                    (cg32arSkipGcSrch+(c16MaxBlockNum/8))
#define cg32arPopBit                             (cg32arVPCntValid+(c16MaxBlockNum/8))    // (cg32arCacheBlkVpCnt+c16MaxBlockNum*4)
#else
#define cg32arCacheBlkVpCnt                      (c32Tsb2SAddr+0x00)
#define cg32arPopBit                             (cg32arCacheBlkVpCnt+c16MaxBlockNum*4)
#endif
#define cg32arH2fTabBlkSn                        (cg32arPopBit+c16MaxBlockNum/32*4)
#define cg16arH2fTabBlk                          (cg32arH2fTabBlkSn+c16MaxH2fTabBlkNum*4)
#define cg16arH2fTabBlkVpCnt                     (cg16arH2fTabBlk+c16MaxH2fTabBlkNum*2)
#define cg16arH2fTabPtr                          (cg16arH2fTabBlkVpCnt+c16MaxH2fTabBlkNum*2)
#define cg16arH2fBackup                          (cg16arH2fTabPtr+(c16MaxH2fTabNum+c16HmbMaxTableNumAlign)*2)    // keep alignment

#define cg32GcSkipSrcHblkSrch                    (cg16arH2fBackup+c16HmbMaxTableNumAlign*2)    // keep alignment

#define cg16arRaidParityBlk                      (cg32GcSkipSrcHblkSrch+c16MaxH2fTabNum/32*4)
#define cg16arRaidParityPtr                      (cg16arRaidParityBlk+cRaidParityBlockNum*2)
#define cg16arRaidPtyBlkVpCnt                    (cg16arRaidParityPtr+cRaidParityPageNum*2)

#define cgarPushSpareQ                           (cg16arRaidPtyBlkVpCnt+cRaidParityBlockNum*2)
#define cg16PushSpareCnt                         (cgarPushSpareQ+sizeof(PUSHSPRINFO)*c16MaxPushSprbNum)
#define cg16PushSpareTail                        (cg16PushSpareCnt+4)
#define cg16PushSpareHead                        (cg16PushSpareTail+4)

#define cg16MaxSlcCacheBlockThr                  (cg16PushSpareHead+4)
#define cg16CurrSlcCacheBlockThr                 (cg16MaxSlcCacheBlockThr+2)
#define cg32WearLevelCnt                         (cg16CurrSlcCacheBlockThr+2)

// #define cg32BkRdCacheBlkSerial (cg32WearLevelCnt+4)
#define cg32BkRdActCBlkSerial                    (cg32WearLevelCnt+4)
// #define cg32BkRdCacheFreePagePtr (cg32BkRdCacheBlkSerial+4)
#define cg32BkRdCacheFreePagePtr                 (cg32BkRdActCBlkSerial+4)

#define cg32BkCacheBlkSerial                     (cg32BkRdCacheFreePagePtr+4)
#define cg32BkFluBlkSerial                       (cg32BkCacheBlkSerial+4)
#define cg32BkGcDesSerial                        (cg32BkFluBlkSerial+4)
#define cg32BkH2fTabBlkSerial                    (cg32BkGcDesSerial+4)

#define cg32BkTotalSlcVpc                        (cg32BkH2fTabBlkSerial+4)
#define cg32BkTotalTlcVpc                        (cg32BkTotalSlcVpc+4)
#define cg16BkCacheF2hTabFreePtr                 (cg32BkTotalTlcVpc+4)
#define cg16BkRdActiveCacheBlock                 (cg16BkCacheF2hTabFreePtr+2)
#define cg16BkGcDesSlcBlock                      (cg16BkRdActiveCacheBlock+2)
#define cg16BkGcDesTlcBlock                      (cg16BkGcDesSlcBlock+2)
#define cg16BkFluCacheBlock                      (cg16BkGcDesTlcBlock+2)
#define cg16BkPrePopCacheBlock                   (cg16BkFluCacheBlock+2)
#define cg16BkActH2fTabFblk                      (cg16BkPrePopCacheBlock+2)
#define cg16BkH2fTabFreePagePtr                  (cg16BkActH2fTabFblk+2)

#define cg32TotalEraseCnt                        (cg16BkH2fTabFreePagePtr+2)
#define cg32DynamicTotalEraseCnt                 (cg32TotalEraseCnt+4)
#define cg32SLCTotalEraseCnt                     (cg32DynamicTotalEraseCnt+4)

#define cg32SlcMaxEraseCnt                       (cg32SLCTotalEraseCnt+4)
#define cg32TlcMaxEraseCnt                       (cg32SlcMaxEraseCnt+4)

#define cg16TLCGcWLCnt                           (cg32TlcMaxEraseCnt+4)
#define cg16SLCReclaimCnt                        (cg16TLCGcWLCnt+2)
#define cg16ReclaimCnt                           (cg16SLCReclaimCnt+2)
#define cg16WLCheckBlk                           (cg16ReclaimCnt+2)

#define cg16SLCFlushCnt                          (cg16WLCheckBlk+2)
#define cg16H2FReadScrubCnt                      (cg16SLCFlushCnt+2)

#define cgBkFidBlock                             (cg16H2FReadScrubCnt+2)
// #define cgBkF2hTabBank (cgBkFidBlock+1)
#define cgBkRdActF2hTabBank                      (cgBkFidBlock+1)

/*****************/
// #define cg16BkActiveCacheBlock (cgBkF2hTabBank+1)
#define cg16BkActiveCacheBlock                   (cgBkRdActF2hTabBank+1)

#define cg16BkCacheActWindow                     (cg16BkActiveCacheBlock+2)
#define cg16BkCacheWindowGrp                     (cg16BkCacheActWindow+2)
#define cg16BkActiveGcDesBlock                   (cg16BkCacheWindowGrp+2)
#define cg16BkGcDesActWindow                     (cg16BkActiveGcDesBlock+2)
#define cg16BkGcDesWindowGrp                     (cg16BkGcDesActWindow+2)

#define cg16TotalProgFailCnt                     (cg16BkGcDesWindowGrp+2)

#define cg32SpecFuncFlag                         (cg16TotalProgFailCnt+2)

#define cg16BkWriteBufPtr                        (cg32SpecFuncFlag+4)
#define cg16BkFlashWBufPtr                       (cg16BkWriteBufPtr+2)
#define cg32MaxRebuTime                          (cg16BkFlashWBufPtr+2)

#define cg32MaxS2TGCtime                         (cg32MaxRebuTime+4)
#define cg32MaxT2TGCtime                         (cg32MaxS2TGCtime+4)
#define cg32E2eDetectCnt                         (cg32MaxT2TGCtime+4)

#define cg64HostWrCmdCnt                         (cg32E2eDetectCnt+4)
#define cg64HostRdCmdCnt                         (cg64HostWrCmdCnt+8)
#define cg64TotalHostRdSecCnt                    (cg64HostRdCmdCnt+8)
#define cg64NandSlcTotalWriteSecCnt              (cg64TotalHostRdSecCnt+8)
#define cg64NandTlcTotalWriteSecCnt              (cg64NandSlcTotalWriteSecCnt+8)
#define cg64NandSlcTotalReadSecCnt               (cg64NandTlcTotalWriteSecCnt+8)
#define cg64NandTlcTotalReadSecCnt               (cg64NandSlcTotalReadSecCnt+8)

#define cg16RaidDecTotalCnt                      (cg64NandTlcTotalReadSecCnt+8)
#define cg16RaidDecSkipCnt                       (cg16RaidDecTotalCnt+2)
#define cgRaidMaxPopEngCnt                       (cg16RaidDecSkipCnt+2)
#define cgPowerDownMode                          (cgRaidMaxPopEngCnt+1)

#define cg16StaticBound                          (cgPowerDownMode+1)

#define cgsBkPcieErrCacheInfo                    (cg16StaticBound+2)

#define cgsNamespace                             (cgsBkPcieErrCacheInfo+sizeof(CACHEINFO))
#define cg16SramOneBitErrCnt                     (cgsNamespace+sizeof(NAMESPACEINFO))
#define cg16SramTwoBitErrCnt                     (cg16SramOneBitErrCnt+2)
#define cg32InternalDataPath                     (cg16SramTwoBitErrCnt+2)
#define cg32PrdCommandRetryCnt                   (cg32InternalDataPath+4)

#define cg32Vdt27FailCnt                         (cg32PrdCommandRetryCnt+4)
#define cg32ThermalMT1TranCnt                    (cg32Vdt27FailCnt+4)
#define cg32ThermalMT2TranCnt                    (cg32ThermalMT1TranCnt+4)
#define cg32PwrOnAbortPs3Cnt                     (cg32ThermalMT2TranCnt+4)
#define cg32PwrOnAbortPs4Cnt                     (cg32PwrOnAbortPs3Cnt+4)
#define cg32TotalPcieRdErrCnt                    (cg32PwrOnAbortPs4Cnt+4)

#define cg64PwrOnPs3Cnt                          (cg32TotalPcieRdErrCnt+4)
#define cg64PwrOnPs4Cnt                          (cg64PwrOnPs3Cnt+8)
#define cg32TotalPcieWrErrCnt                    (cg64PwrOnPs4Cnt+8)
#define cg32TotalPcieOthErrCnt                   (cg32TotalPcieWrErrCnt+4)

#define cg32BkRdFlsCBlkSerial                    (cg32TotalPcieOthErrCnt+4)
#define cg16BkRdFlushCacheBlock                  (cg32BkRdFlsCBlkSerial+4)
#define cgBkRdFlsF2hTabBank                      (cg16BkRdFlushCacheBlock+2)
#define cg32ThermalMT3TranCnt                    (cgBkRdFlsF2hTabBank+2)
#define cg32AsicThermalMT3TranCnt                (cg32ThermalMT3TranCnt+4)

#define cg32arCacheBlkSerial                     (cg32AsicThermalMT3TranCnt+4)
#define cg16arCacheBlock                         (cg32arCacheBlkSerial+4*cCacheBlkNum)
#define cgarCacheBlkF2hTabBank                   (cg16arCacheBlock+2*cCacheBlkNum)

#define cg32StaticSLCTotalEC                     (cgarCacheBlkF2hTabBank+2*cCacheBlkNum)
#define cg32DynamicSLCTotalEC                    (cg32StaticSLCTotalEC+4)

#define cg32DummyQBAnalysis                      (cg32DynamicSLCTotalEC+4)
#if _EN_VPC_SWAP
#define cg16arGlobReadCnt                    (cg32DummyQBAnalysis+8)
#define cgarGlobReadCntHighByte                    (cg16arGlobReadCnt+(c16MaxBlockNum*2))
#endif

#define cTelemetryArea1DataSecCnt                (64)
#define cTelemetryArea2DataSecCnt                (128)
#define cTelemetryArea3DataSecCnt                (128)
#define cTelemetryCtlrDataPageCnt                (cTelemetryArea3DataSecCnt/gSectorPerPlaneH)

#define cTelemetryGlobReadCntStrOfst             (c16Tsb0SIdx+gSectorPerPlaneH+1)
#define cTelemetryBadInfoStrOfst                 (c16Tsb0SIdx+(0x8200>>cSingleSectorShift))
#define cTelemetryOrgBadCntStrOfst               (cTelemetryBadInfoStrOfst+gSectorPerPlaneH)
#define cTelemetryOrgBadTabStrOfst               (cTelemetryOrgBadCntStrOfst+gSectorPerPlaneH)
#define cBgdGcSkipNum                            20
#define cIdleGCDelayTime                         7000
#define cBgdGcResetSctr                          32767
#define cBgdGcWakeupTime                         (0x10000-(14))    // 7s*2Hz=14
#define cEarlyGcWakeupTime                       (0x10000-(14))
#define cEarlyGCTime                             100

#define cSlcEraseCntThr                          30000
#define cTlcEraseCntThr                          3000
#define cChkLayersOfFinger                       3
#define cFingersPerBlock                         4
#define cPagesPerLayer                           12

#define cFlushCacheVarStrAddr                  cTsb0Addr

#define cCacheBlkVpCntBootStrAddr        0x40070000
#define cCacheBlkVpCntBootStrIdx        0x380
#define cCacheBlkVpCntRebuH2FStrAddr        0x40040000
#define cCacheBlkVpCntRebuH2FStrIdx        0x200
#define cCacheBlkVpCntEndRebuH2FStrAddr        0x40000000
#define cCacheBlkVpCntEndRebuH2FStrIdx        0x0
#define cCacheBlkVpCntRdlinkEndStrAddr        (0x40000000+c32ProgCacheInfo_CacheBlkVpCntStAddr+(c16CacheInfoTabSIdx<<9))
#define cCacheBlkVpCntRdlinkEndStrIdx        (c16CacheInfoTabSIdx+(c32ProgCacheInfo_CacheBlkVpCntStAddr>>9))
#define cCacheBlkVpCntRWStrAddr        0x4006C000
#define cCacheBlkVpCntRWStrIdx        0x360
#define cCacheBlkVpCntFlushStrAddr        (cFlushCacheVarStrAddr+cSortF2HTabSise)
#define cCacheBlkVpCntFlushStrIdx        0xF0
#define cCacheBlkVpCntGetGCSrcStrAddr        0x40000000
#define cCacheBlkVpCntGetGCSrcStrIdx        0x0
#define cCacheBlkVpCntGCFlushStrAddr        0x40040000
#define cCacheBlkVpCntGCFlushStrIdx        0x200
#define cCacheBlkVpCntEndGCFlushStrAddr        0x40000000
#define cCacheBlkVpCntEndGCFlushStrIdx        0x0
#define cCacheBlkVpCntTrimStrAddr        0x40004000
#define cCacheBlkVpCntTrimStrIdx        0x20
#define cCacheBlkVpCntSecuritySendStrAddr        0x40058000
#define cCacheBlkVpCntSecuritySendStrIdx        0x2C0
#define cCacheBlkVpCntHdlEraseStrAddr        0x40000000
#define cCacheBlkVpCntHdlEraseStrIdx        0x0
#if (_EN_GCPWR&&(!_EN_RAID_GC))
#define cCacheBlkVpCntQBootStrAddr        0x4000F000
#define cCacheBlkVpCntQBootStrIdx        0x78
#else
#define cCacheBlkVpCntQBootStrAddr        0x4000B000
#define cCacheBlkVpCntQBootStrIdx        0x58
#endif

#define c32CacheBlkVpCntVarSize                      (c16MaxBlockNum*4)    // 0x2000

// VPCnt
#define cVPCntBufValid    c32Bit0
#define cVPCntInBoot    c32Bit1
#define cVPCntCacheInfoValid    cBit2
#define cVPCntQbootDumValid    cBit3

enum
{
    cRdyTypNorm,
    cRdyTypSlcCacheW,
    cRdyTypTlcCacheW,
};

#if _EN_WUNCTable    // WUNCTable Chief_21081121
#define C_MaxWUNCLAACnt    2
#endif
#if _EN_WriteZeroNonAlign    // WUNCTable Chief_21081121
#define C_MaxNonAlginCnt   2
#endif
#if _EN_PopBlk0    // Chief_20190104
#define C_BlkEmergencyTh   3
#endif
#endif    // ifndef __CONST_H__

#define cBootH2FGC          cBit0
#define cBootSLCQGC         cBit1
#define cWproNeedSwap       cBit2
#define cVpcNeedRebuild     cBit3

#if (OEM==VERIFY)
#define cSLCQ_ExtraGcThrd     15
#define cSLCQ_ForceCleanThrd     10
#else
#define cSLCQ_ExtraGcThrd     30
#define cSLCQ_ForceCleanThrd     20
#endif

#define IM_Chk_Size    4*0x40000    // 4* 1GB (4K_Base)

#define cCDM750M     0x177000    // sector Base
#define cCDM1200M    0x258000
#define cCDM5G       0xA00000

#define cScnt500M    0xFA000
#define cMaxFWHistoryNum      0xEF







