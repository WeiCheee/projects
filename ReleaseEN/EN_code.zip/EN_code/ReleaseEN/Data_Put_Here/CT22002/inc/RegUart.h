







#ifndef __REG_UART_H__
#define __REG_UART_H__

// UART Register @0x5100_1200

#define rcUartRxByte                             0x00
#define rmUartRxByte                             rUartCtrl[rcUartRxByte]

#define rcUartRxPop                              0x01
#define rmUartRxPop                              (rUartCtrl[rcUartRxPop]|=cBit0)

#define rcUartIsr                                0x02
#define rmChkTxFull                              (rUartCtrl[rcUartIsr]&cBit7)
#define rmChkRxFull                              (rUartCtrl[rcUartIsr]&cBit6)
#define rmChkPtyErr                              (rUartCtrl[rcUartIsr]&cBit4)
#define rmChkStartErr                            (rUartCtrl[rcUartIsr]&cBit3)
#define rmChkEndErr                              (rUartCtrl[rcUartIsr]&cBit2)
#define rmChkTxOK                                (rUartCtrl[rcUartIsr]&cBit1)
#define rmChkRxOK                                (rUartCtrl[rcUartIsr]&cBit0)
#define rmUartClrAllInt                          (rUartCtrl[rcUartIsr]=rUartCtrl[rcUartIsr])

#define rcUartImr                                0x03
#define rmSetUartIntrMask(x)                     rUartCtrl[rcUartImr]=((x)&0x0F)

#define rcUartCtrl                               0x04
#define rmUartPtyEn                              (rUartCtrl[rcUartCtrl]|=cBit2)
#define rmUartEvenParity                         (rUartCtrl[rcUartCtrl]|=cBit1)
#define rmUartOddParity                          (rUartCtrl[rcUartCtrl]&=(~cBit1))
#define rmUart2StopBit                           (rUartCtrl[rcUartCtrl]|=cBit0)
#define rmUart1StopBit                           (rUartCtrl[rcUartCtrl]&=(~cBit0))

#define rcUartReset                              0x05
#define rmUartReset                              (rUartCtrl[rcUartReset]=0xFF)

#define rcUartSts                                0x06
#define rmUartChkTxFull                          (rUartCtrl[rcUartSts]&cBit7)
#define rmUartChkTxBusy                          (rUartCtrl[rcUartSts]&cBit1)
#define rmWaitUartBusy\
    while(rmUartChkTxBusy)

#define rcUartBaudRate                           0x08
#define rmUartBaudRate                           r32UartCtrl[rcUartBaudRate/4]

#define rcUartTxWord                             0x0C
#if (_ENABLE_NAND_UART_DEBUG==0)
#define rmUartTxLword(Pattern)                   (r32UartCtrl[rcUartTxWord/4]=Pattern)
#define rmUartTxWord(Pattern)                    (r16UartCtrl[rcUartTxWord/2]=Pattern)
#define rmUartTxByte(Pattern)                    (rUartCtrl[rcUartTxWord]=Pattern)
#else
#define rmUartTxLword(Pattern)\
    {while(rmUartChkTxBusy)\
         ;\
     r32UartCtrl[rcUartTxWord/4]=Pattern;\
     while(rmUartChkTxBusy)\
         ;\
    }
#define rmUartTxWord(Pattern)\
    {while(rmUartChkTxBusy)\
         ;\
     r16UartCtrl[rcUartTxWord/2]=Pattern;\
     while(rmUartChkTxBusy)\
         ;\
    }
#define rmUartTxByte(Pattern)\
    {while(rmUartChkTxBusy)\
         ;\
     rUartCtrl[rcUartTxWord]=Pattern;\
     while(rmUartChkTxBusy)\
         ;\
    }
#endif    // if (_ENABLE_NAND_UART_DEBUG==0)
#endif    // ifndef __REG_UART_H__







