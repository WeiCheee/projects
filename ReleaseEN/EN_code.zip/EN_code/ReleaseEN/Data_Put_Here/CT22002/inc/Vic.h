







#ifndef __VIC_H__
#define __VIC_H__

#include "inc/TypeDef.h"
#include "inc/Option.h"

#define cEnPcieClkReqIrq                         c32Bit0    // IRQ0

#define cIrqVdt18                                c32Bit1
#define cIrqVdt23                                c32Bit2
#define cIrqVdt27Wdt                             c32Bit3
#define cIrqVdt40Vdt10                           c32Bit4

#define cIrqThermalTh                            c32Bit7    // IRQ7
#define cIrqEnJtag                               c32Bit8    // IRQ8

#define cIrqGpioAll                              c32Bit9    // IRQ9
#define cIrqVdtFio                               c32Bit10    // IRQ10
#define cIrqTimerAll                             c32Bit11    // IRQ11

#define cIrqEnUart                               c32Bit14    // IRQ14
#define cIrqNvmeCmdRdy                           c32Bit16    // IRQ16
#define cIrqNvmeDmaDone                          c32Bit17    // IRQ17
#define cIrqNvmeRst                              c32Bit18    // IRQ18
#define cIrqNvmeErr                              c32Bit19    // IRQ19, Invalid Doorbell, DMA xfr internal error
#define cIrqPcie0                                c32Bit20    // IRQ20
#define cIrqPcie1                                c32Bit21    // IRQ21, FWRQ_Ready
#define cIrqPcie2                                c32Bit22    // IRQ22, Expansion Rom
#define cIrqPcie3                                c32Bit23    // IRQ23
#define cIrqBusErr                               c32Bit24    // IRQ24

#define cIrqDramEccErr                           c32Bit26    // IRQ26, Dram ecc fail
#define cIrqFakeEngFail                          c32Bit26
#define cIrqFlashCmdFifoFullErr                  c32Bit27    // IRQ26, Dram ecc fail
#define cIrqFlashInt                             c32Bit28    // IRQ26, Dram ecc fail

#define cIrqSev                                  c32Bit31

#endif    // ifndef __VIC_H__







