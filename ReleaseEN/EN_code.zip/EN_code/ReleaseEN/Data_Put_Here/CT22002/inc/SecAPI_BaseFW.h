







#ifndef __SECAPI_BASEFW_H__
#define __SECAPI_BASEFW_H__

#include "inc/Option.h"
#include "inc/TypeDef.h"

#if _ENABLE_SECAPI
#include "SecAPI_BaseFW_Type.h"

#if _ENABLE_ATA_PASSTHROUGH
void SecAPI_InitATASecurityFuncPtr_BaseFW();
void SecAPI_InitATASecurity(BYTE uMode);
void SecAPI_NoticeModifyMEKs_Request(BYTE *upMEK);
void SecIntf_EraseUserArea(BYTE uDoNotChangeSecurityState);
void SecIntf_UpdateATASecurityStatus(BYTE uMode, BYTE *uSecurityStatus);
void SecIntf_SYS_DCache_Invalidte();
#endif

// ------------SecAPI------------------
void SecAPI_ChkSessionTimeout();
void SecAPI_InitSecAPIFuncPtr_BaseFW();
void SecAPI_InitSecAPI(BYTE uMode);
void SecAPI_ChkHitRange(LWORD u32LBAStart, LWORD u32XfrCnt, BYTE uIsRCmd, BYTE uExcludeMBR);
void SecAPI_ChkStackOverFlow();
void SecAPI_InitParameter_BaseFW();
void SecAPI_Resume(BYTE uAction);
void SecAPI_NoticeSecCodeSwap(BYTE uAction);
BYTE SecAPI_HandleFWupdate(LWORD u32SecurityState);
void SecAPI_Trusted_Send();
void SecAPI_Trusted_Receive();

// ------------SecAPI_---_Request------------------
BYTE SecAPI_SetCPin_Request();
BYTE SecAPI_Crypto_UpdateGlobalRangeKey_Request(BYTE *upMEK);
void SecAPI_Crypto_RestoreAESHWInfo_Request();
LWORD SecAPI_GetReadGHP_Request(BYTE uMode, LWORD u32GHP);
void SecAPI_NoticeBackupResume_Request(BYTE uAction);
void SecAPI_NoticeReset_Request(BYTE uType);
void SecAPI_UpdateSecurityFWParameter_Request();

// ------------SecIntf------------------
void SecIntf_Crypto_LoadKey(BYTE *upRangeKey, BYTE uRangeID);
void SecIntf_Crypto_SetRangePartitionRegister(BYTE uAction, LWORD u32LBAStart, LWORD u32LBAEnd, BYTE uRangeID);
void SecIntf_Crypto_KeyWrapping(BYTE uAction,
                                BYTE *upInputKey,
                                BYTE uInputKeylength,
                                BYTE *upInputString,
                                BYTE uInputStringLength,
                                BYTE *upOutputString,
                                LWORD MemoryAddr,
                                BYTE *upStatus);
void SecIntf_Crypto_SP800_108(BYTE *upInputKey,
                              BYTE uInputKeylength,
                              BYTE *upLabel,
                              LWORD u32LabelLength,
                              BYTE *upContext,
                              LWORD u32ContextLength,
                              BYTE *upOutputString,
                              LWORD u32OutputLength,
                              LWORD MemoryAddr);
void SecIntf_Crypto_SP800_132(BYTE *upInputPassword,
                              BYTE uInputPasswordLength,
                              BYTE *upSalt,
                              BYTE uSaltLength,
                              LWORD u32IterationCount,
                              BYTE *upOutputString,
                              LWORD u32OutputLength,
                              LWORD MemoryAddr);
void SecIntf_Crypto_GetRootKey(LWORD MemoryAddr, BYTE *upRootKey);
void SecIntf_Crypto_GenerateRandomNum(BYTE uByteLen, BYTE *uRandomNum);
BYTE SecIntf_JudgeWrittenGHP(LWORD uGHP);
void SecIntf_SetSecurityWProMode();
LWORD SecIntf_GetCurrentMs(void);
void SecIntf_TimerWaitMs(LWORD time);
void SecIntf_SetSessionTimeout(BYTE uAtion, LWORD u32SessionTimerStart, LWORD u32MaxSessionTimeout);
void SecIntf_MOVE_MEM2MEM(LWORD Src_Addr, LWORD Des_Addr, LWORD len);
BYTE SecIntf_MemoryCompare(LWORD Src_Addr, LWORD Des_Addr, LWORD len);
void SecIntf_ResetMemory(BYTE *ptr, LWORD size, LWORD u32Val);
void SecIntf_ResetTSB(UCBYTE *ptr, LWORD size, LWORD u32Val);
LWORD SecIntf_MemoryUsage(BYTE uUsage, BYTE uMode, WORD u16Length, LWORD u32BaseAddr);
void SecIntf_DebugLog(BYTE uPriority, BYTE uIdx, BYTE uParaCnt, WORD u16para0, WORD u16para1, WORD u16para2, WORD u16para3, WORD u16SaveLogID);
void SecIntf_SaveWProPage(BYTE uPageIdx);
BYTE SecIntf_LoadWProPage(BYTE uPageIdx);
BYTE SecIntf_CheckWProPageExist(BYTE uPageIdx);
void SecIntf_SaveLinkMap(BYTE uSaveMapID, BYTE uPartialMap);
void SecIntf_AddTrimEntry(LWORD u32TrimStartLBA, LWORD u32XfrCnt);
void handleSecTrim(void);
void SecIntf_RangePolicyUpdate(BYTE uAction, lba_policy_st *RangePolicy);
BYTE SecIntf_TCG_Write(BYTE uMode);
BYTE SecIntf_TCG_Read(BYTE uMode);
void SecIntf_UpdateBaseFWParameter(pointer_sec_st *POINTER_SEC);
void initSecurityParameter();
void updateLbaRangeMbrBitmap();
void bootInitSecurity();

#endif    // if _ENABLE_SECAPI
#endif    // ifndef __SECAPI_BASEFW_H__
// =========SecAPI_BaseFW.c==========







