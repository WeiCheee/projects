







#ifndef __FLASHCTRL_H__
#define __FLASHCTRL_H__

#include "inc/TypeDef.h"
#include "inc/Option.h"
#include "inc/Reg.h"
#define cSamsungID                  0xEC
#define cToshibaID                  0x98
#define cInfineonID                 0xC1
#define cSandiskID                  0x45
#define cHynixID                    0xAD
#define cMicronID                   0x2C
#define cSTID                       0x20
#define cIntelID                    0x89

// #define gbLargePg                   gpFlashAddrInfo->ubLargePg
#define g16FBlock                   gpFlashAddrInfo->u16FBlock
#define g16FPage                    gpFlashAddrInfo->u16FPage
#define gSectorH                    gpFlashAddrInfo->uSectorH
#define gPlaneAddr                  gpFlashAddrInfo->uPlaneAddr
#define gIntlvAddr                  gpFlashAddrInfo->uIntlvAddr
#define gbLsbOnly                   (!(mChkMlcMoBit(g16FBlock)))
#define gbLsbOnlyCurActCBlk         (!(mChkMlcMoBit(gsCacheInfo.u16ActiveCacheBlock)))
#define g16AbstrFBlock              gpFlashAddrInfo->u16AbstractFBlock
#define g32FPageNoTran              gpFlashAddrInfo->u32FPageNoTran
// #define gOrgSectorH                 gpFlashAddrInfo->uOrgSectorH
#define gStartPlaneAddr             gpFlashAddrInfo->uStartPlaneAddr
#define gDieAddr                    gpFlashAddrInfo->uDieAddr
#define gCh                         gpFlashAddrInfo->uCh
#define gCe                         gpFlashAddrInfo->uCe
#define mGetReadOpt                 gpFlashAddrInfo->u16RwOpt
#define mGetReadBuf                 gpFlashAddrInfo->u16BufPtr
#define mGetReadSctrCnt             gpFlashAddrInfo->uRwHalfKb
#define mGetReadOpTyp               gpFlashAddrInfo->uOpTyp
#define gOpTyp                      gpFlashAddrInfo->uOpTyp
#define g16RwOpt                    gpFlashAddrInfo->u16RwOpt
#define gPlaneCnt                   gpFlashAddrInfo->uPlaneCnt
#define gAddrOpt                    gpFlashAddrInfo->uAddrOpt
#define gBlkId                      (gpFlashAddrInfo->uAddrOpt&0x0F)    // gpFlashAddrInfo->uBlkId
#define mSetBlkId(x)                gpFlashAddrInfo->uAddrOpt=(gpFlashAddrInfo->uAddrOpt&0xF0)|x

#define mGetWriteOpt                gpFlashAddrInfo->u16RwOpt
#define mGetWriteBuf                gpFlashAddrInfo->u16BufPtr
#define mGetProgSctrCnt             gpFlashAddrInfo->uRwHalfKb
// #define gPageSelCmd                 gpFlashAddrInfo->uPageSelCmd
// #define gSparUseCnt                 gpFlashAddrInfo->uSparUseCnt
// #define gTabSpare                   gpFlashAddrInfo->uTabSpar
#define gSrcIdx                     gpFlashAddrInfo->uSrcIdx

#define mSetSprSetDone(a)           (a->uSprOpt|=cBit7)
#define mClrSprSetDone(a)           (a->uSprOpt&=~cBit7)
#define mChkSprSetDone(a)           (a->uSprOpt&cBit7)
#define mSetTabSpr(a, b)            (a->uSprOpt=(a->uSprOpt&~(cBit5|cBit6))|(b))
#define mClrTabSpr(a)               (a->uSprOpt&=~(cBit5|cBit6))
#define mChkTabSpr(a, b)            (a->uSprOpt&(b))
#define mSetSprUseCnt(a, b)         (a->uSprOpt=(a->uSprOpt&~(cBit3|cBit4))|((b)<<3))
#define mClrSprUseCnt(a)            (a->uSprOpt&=~(cBit3|cBit4))
#define mGetSprUseCnt(a)            ((a->uSprOpt&(cBit3|cBit4))>>3)
#define mGetPageSelCmd(a)           (a->uSprOpt&0x07)
#define mGetPageSelCmdS(a)          (a.uSprOpt&0x07)

#define mClrDmaCnt(a)               (a->uDmaCnt&=cBit7)
#define mGetDmaCnt(a)               (a->uDmaCnt&~cBit7)
#define mSetQRead(a)                (a->uDmaCnt|=cBit7)
#define mClrQRead(a)                (a->uDmaCnt&=~cBit7)
#define mChkQRead(a)                (a->uDmaCnt&cBit7)

#if _EN_VPC_SWAP
#define mSetMlcMoBit(x)             mSetBitMask(g32arMlcMoBit[x>>5], x&0x1F)    // (g32arCacheBlkVpCnt[x]|=c32Bit30)
#define mChkMlcMoBit(x)             mChkBitMask(g32arMlcMoBit[x>>5], x&0x1F)    // (g32arCacheBlkVpCnt[x]&c32Bit30)
#define mClrMlcMoBit(x)             mClrBitMask(g32arMlcMoBit[x>>5], x&0x1F)    // (g32arCacheBlkVpCnt[x]&=~c32Bit30)
#else
#define mSetMlcMoBit(x)             (g32arCacheBlkVpCnt[x]|=c32Bit30)
#define mChkMlcMoBit(x)             (g32arCacheBlkVpCnt[x]&c32Bit30)
#define mClrMlcMoBit(x)             (g32arCacheBlkVpCnt[x]&=~c32Bit30)
#endif

#define rmGetCe0CurrentQueAddr                   (0x51101000+(garChMapTable[gActiveCh]*0x00010000)+(rmGetCe0QueReadIndex*2)-2)
#define rmGetAUXCurrentQueAddr                   (0x51101000+(garChMapTable[gActiveCh]*0x00010000)+(rmGetAUXQueReadIndex*2)-2)

#define getDiffAddrOffset(x)        (g16arDiffOffset[x]&=~c16Bit15)

// OpType
#define cNoOp                                    0
#define cBootProgData                            1
#define cBootMoveGcDes                           2
#define cBootMoveCache                           3
#define cFlushData                               4
#define cCache3FCmd                              5    // cWrErrData                               5
#define cReProgData                              6    // cCacheMoveData 6
#define cCacheProgData                           7
#define cMoveProgData                            8
#define cReclaimProgData                         9
#define cEraseBlk                                10
#define cErrHdlDummyProg                         11
#define cPwrOnDummyProg                          12
#define cReadCmdAle                              13
#define cCacheRCmd                               14
#define cCacheRCmd1                              15
#define cProgData                                16
#define cReadData                                17
#define cPreReadData                             18
#define cLastReadData                            19
#define cHostReadData                            20
// #define cRndOut                                  21
#define cReadScrubData                         21
#define cF2hReadTab                              22
#define cMoveReadData                            23
#define cReclaimReadData                         24
// #define cReadDummy                               23
#define cH2fReadTab                              25
#define cH2fRead1kTab                            26
#define cPwrOnGc                                 27
#define cSecReadData                             28
#define cReadRaidParity                          29
#define cHdmaDummy                               30
#define cGcHdmaDummy                             31
#define cHmbWrCacheData                          32
#define cRefreshH2f                              33
#define cSecReadDummy                            34
#define cMbrReadDummy                            35
#define cRaidDecRead                             36
#define cChkFingerFail                           37
// #define cH2fProgTab                              27
// #define cRdy                                     28
// #define cManualPasteRead                         31
// #define cDmaDone                                 32
// #define cNoWaitReadCmdAle                        33
#define cChkFakeSlcProgramFail                   239
#define cVenderWdErase                           240
#define cVenderWdProgram                         241
#define cVenderWdRead                            242
#define cVenderWdChkSts                          243
#define cVenderErase                             253
#define cVenderRead                              254
#define cVenderWrite                             255

// //waitChCeDieBz(BYTE uCh,BYTE uCe,BYTE Die,BYTE uRdyTyp,BYTE uForceWait)
#define cNoWait                                  0x00
#define cForceWait                               0x01

#define cChFiFoRegBusy                           0x00
#define cChNandReady                             0x01
#define cChNandProgramFail                       0x02
#define cChNandEraseFail                         0x03
#define cChDmaDone                               0x04

// //tranSrcFifo(BYTE uMode)
#define cTranForNormal                           0x00
#define cTranForAllFifo                          0x01

// //trigSrcFifo(BYTE uMode)
#define cDmaForNormal                            0x00
#define cDmaForAllFifo                           0x01

#define cErrInjectWriteMode                      0x01
#define cErrInjectReadMode                       0x00

// //readRetry(BYTE uPlaneOffsetNum, TRANDMAINFO usTranDmaInfo,BYTE uType)

#define cHynixParaAddrCnt                        0x08
#define cRetryData                               0x00
#define cRetrySprData                            0x01

#define cIntoAuxQue                              0x01
#define cOutAuxQue                               0x00

#define cIntelNand                               0x89
#define cSanDiskNand                             0x45

#define cWordLineTypeMask                        0xF0
#define cPageTypeMask                            0x0F
#define cSlcWordLineType                         0x10
#define cMlcWordLineType                         0x20
#define cTlcWordLineType                         0x30
#define cLpPageType                              0x01
#define cUpPageType                              0x02
#define cXpPageType                              0x03

#define cTranProgramType                         0x00
#define cTranReadType                            0x01
#define cStartStep                               0x00
#define cTranAddInfoStep                         0x01
#define cCheckBusyDoneStep                       0x02
#define cReadCmdAleStep                          0x03
#define cProgramStep                             0x04
#define cDataOutStep                             0x05
#define cCheckStep                               0xC0
#define cEndStep                                 0xFF

#define cTestEccTh                               44

#define cNoUECCSrc                               0xFF
#define cNullSrc                                 0xFF

#define cNoPlaneIndex                            0xFF
#define cLdpcPipeLineDisableMode                 0x00
#define cLdpcPipeLineEnableMode                  cBit0

#if 0
#define FFREQ                                    250
#define cTwhr                                   ((WORD)(500/(1000/FFREQ)))
#endif

#if _TSB_BiCS3
#define FFREQ                                   266
#define cTrc                                    (1000/FFREQ)    // 5ns
#define cTwhr                                   ((WORD)(100/cTrc))    // Twhr 150ns
#define cTwhr2                                  ((WORD)((300/cTrc)-cTwhr))    // Twhr2 320ns
#endif

#if (_TSB_BiCS4||_TSB_BiCS4_WR)
#define FFREQ                                   333
#define cTrc                                    (1000/FFREQ)    // 5ns
#define cTwhr                                   ((WORD)(100/cTrc))    // Twhr 150ns
#define cTwhr2                                  ((WORD)((300/cTrc)-cTwhr))    // Twhr2 320ns
#endif
#if (_SANDISK_3D_GEN2||_SANDISK_3D_GEN3)
#define FFREQ                                   266
#define cTrc                                    (1000/FFREQ)    // 4ns
#define cTwhr                                   ((WORD)(100/cTrc))    // Twhr 150ns
#define cTwhr2                                  ((WORD)((300/cTrc)-cTwhr))    // Twhr2 320ns
#endif

#define cUncBeforeTrig                           0x01
#define cUncAfterTrig                            0x02
// #define cWUncTrig                                0x03    // WUNCTable Chief_21081121

#define Div(A, B)                                div(A, B)
#define Mod(A, B)                                mod(A, B)

#define gByteCntOfLogNandQueue                   (sizeof(g32arLogNandQueue))
#define gWordCntOfLogNandQueue                   (gByteCntOfLogNandQueue/2)
#define gDwordCntOfLogNandQueue                  (gByteCntOfLogNandQueue/4)

#endif    // ifndef __FLASHCTRL_H__

// This is for ARM ICE DEBUG, you can "Ctrl + C" and "Ctrl + V"//
// Check DMA Data Address :
// (512*(gpFlashAddrInfo->u16BufPtr)+0x40000000)
// (512*(gpFlashAddrInfo->u16OneShotBufPtr[0])+0x40000000)
// (512*(gpFlashAddrInfo->u16OneShotBufPtr[1])+0x40000000)
// (512*(gpFlashAddrInfo->u16OneShotBufPtr[2])+0x40000000)
// Check CMD Que :
// (0x51101000+(garChMapTable[gActiveCh]*0x00010000)+((r16FLCtrl[0x0214/2])*2)-2)
// Check AUX CMD Que :
// (0x51101000+(garChMapTable[gActiveCh]*0x00010000)+((r16FLCtrl[0x021C/2])*2)-2)
// Check DMA Cnt :
// (gpFlashAddrInfo->uRwHalfKb)
// Check for Phy NAND Address :
// (gpFlashAddrInfo)
// (gpFlashAddrInfo->u32FPageNoTran)
// Check SharePageBitMap :
// (cbSharePageBitMap[(gpFlashAddrInfo->u16FPage)>>3])
// Check SharePageBit :
// ((gpFlashAddrInfo->u16FPage)-8*((gpFlashAddrInfo->u16FPage)>>3))
// Check buf flg :
// 0x51000800
// Start Byte:(0x51000800+((gpFlashAddrInfo->u16BufPtr)/8))
// Start Bit :((gpFlashAddrInfo->u16BufPtr)%8)
// End Byte  :(0x51000800+((gpFlashAddrInfo->u16BufPtr+gpFlashAddrInfo->uRwHalfKb)/8))
// End Bit   :((gpFlashAddrInfo->uRwHalfKb)%8)







