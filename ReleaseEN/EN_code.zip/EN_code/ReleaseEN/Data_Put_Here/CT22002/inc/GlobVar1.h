







#ifndef __GLOBVAR1_H__
#define __GLOBVAR1_H__

#include "inc/TypeDef.h"
#include "inc/Const.h"
#include "inc/table.h"

// -----------------Domain0----------------//
// #pragma default_variable_attributes = @ ".R8_SysCtrl0"
extern volatile BYTE rSysCtrl0[0x400];
// #pragma default_variable_attributes =

// #pragma default_variable_attributes = @ ".R16_SysCtrl0"
extern volatile WORD r16SysCtrl0[0x200];
// #pragma default_variable_attributes =

// #pragma default_variable_attributes = @ ".R32_SysCtrl0"
extern volatile LWORD r32SysCtrl0[0x100];
// #pragma default_variable_attributes =

// #pragma default_variable_attributes = @ ".R8_EfuseCtrl"
extern volatile BYTE rEfuseCtrl[0x200];
// #pragma default_variable_attributes =

// #pragma default_variable_attributes = @ ".R16_EfuseCtrl"
extern volatile WORD r16EfuseCtrl[0x100];
// #pragma default_variable_attributes =

// #pragma default_variable_attributes = @ ".R32_EfuseCtrl"
extern volatile LWORD r32EfuseCtrl[0x80];
// #pragma default_variable_attributes =

// #pragma default_variable_attributes = @ ".R8_Tsb4Ctrl"
extern volatile BYTE rTsb4Ctrl[0x100];
// #pragma default_variable_attributes =

// #pragma default_variable_attributes = @ ".R16_Tsb4Ctrl"
extern volatile WORD r16Tsb4Ctrl[0x80];
// #pragma default_variable_attributes =

// #pragma default_variable_attributes = @ ".R32_Tsb4Ctrl"
extern volatile LWORD r32Tsb4Ctrl[0x40];
// #pragma default_variable_attributes =

// #pragma default_variable_attributes = @ ".R8_PCIe"
extern volatile BYTE rPcie[0x2000];
// #pragma default_variable_attributes =

// #pragma default_variable_attributes = @ ".R16_PCIe"
extern volatile WORD r16Pcie[0x1000];
// #pragma default_variable_attributes =

// #pragma default_variable_attributes = @ ".R32_PCIe"
extern volatile LWORD r32Pcie[0x800];
// #pragma default_variable_attributes =

// #pragma default_variable_attributes = @ ".R8_NVMe0"
extern volatile BYTE rNvme0[0x2000];
// #pragma default_variable_attributes =

// #pragma default_variable_attributes = @ ".R16_NVMe0"
extern volatile WORD r16Nvme0[0x1000];
// #pragma default_variable_attributes =

// #pragma default_variable_attributes = @ ".R32_NVMe0"
extern volatile LWORD r32Nvme0[0x800];
// #pragma default_variable_attributes =

// -----------------Domain2----------------//
// #pragma default_variable_attributes = @ ".R8_BvacCtrl"
extern volatile BYTE rBvacCtrl[0x100];
// #pragma default_variable_attributes =

// #pragma default_variable_attributes = @ ".R16_BvacCtrl"
extern volatile WORD r16BvacCtrl[0x80];
// #pragma default_variable_attributes =

// #pragma default_variable_attributes = @ ".R32_BvacCtrl"
extern volatile LWORD r32BvacCtrl[0x40];
// #pragma default_variable_attributes =

// #pragma default_variable_attributes = @ ".R8_VIC0"
extern volatile BYTE rSvic0[0x1000];
// #pragma default_variable_attributes =

// #pragma default_variable_attributes = @ ".R16_VIC0"
extern volatile WORD r16Svic0[0x800];
// #pragma default_variable_attributes =

// #pragma default_variable_attributes = @ ".R32_VIC0"
extern volatile LWORD r32Svic0[0x400];
// #pragma default_variable_attributes =

// #pragma default_variable_attributes = @ ".R64_VIC0"
extern volatile QWORD r64Svic0[0x200];
// #pragma default_variable_attributes =

// #pragma default_variable_attributes = @ ".R8_VIC1"
extern volatile BYTE rSvic1[0x1000];
// #pragma default_variable_attributes =

// #pragma default_variable_attributes = @ ".R16_VIC1"
extern volatile WORD r16Svic1[0x800];
// #pragma default_variable_attributes =

// #pragma default_variable_attributes = @ ".R32_VIC1"
extern volatile LWORD r32Svic1[0x400];
// #pragma default_variable_attributes =

// #pragma default_variable_attributes = @ ".R64_VIC1"
extern volatile QWORD r64Svic1[0x200];
// #pragma default_variable_attributes =

// #pragma default_variable_attributes = @ ".R8_AUX"
extern volatile BYTE rAux[0x1000];
// #pragma default_variable_attributes =

// #pragma default_variable_attributes = @ ".R16_AUX"
extern volatile WORD r16Aux[0x800];
// #pragma default_variable_attributes =

// #pragma default_variable_attributes = @ ".R32_AUX"
extern volatile LWORD r32Aux[0x400];
// #pragma default_variable_attributes =

// #pragma default_variable_attributes = @ ".R8_COH"
extern volatile BYTE rCoh[0x1000];
// #pragma default_variable_attributes =

// #pragma default_variable_attributes = @ ".R16_COH"
extern volatile WORD r16Coh[0x800];
// #pragma default_variable_attributes =

// #pragma default_variable_attributes = @ ".R32_COH"
extern volatile LWORD r32Coh[0x400];
// #pragma default_variable_attributes =

// #pragma default_variable_attributes = @ ".R8_DramCtrl"
extern volatile BYTE rDramCtrl[0x2000];
// #pragma default_variable_attributes =

// #pragma default_variable_attributes = @ ".R16_DramCtrl"
extern volatile WORD r16DramCtrl[0x1000];
// #pragma default_variable_attributes =

// #pragma default_variable_attributes = @ ".R32_DramCtrl"
extern volatile LWORD r32DramCtrl[0x800];
// #pragma default_variable_attributes =

// #pragma default_variable_attributes = @ ".APB_REG"
extern volatile BYTE rAPB[0x100000];
// #pragma default_variable_attributes =

// -----------------Domain1----------------//
// #pragma default_variable_attributes = @ ".R8_SysCtrl1"
extern volatile BYTE rSysCtrl1[0x100];
// #pragma default_variable_attributes =

// #pragma default_variable_attributes = @ ".R16_SysCtrl1"
extern volatile WORD r16SysCtrl1[0x80];
// #pragma default_variable_attributes =

// #pragma default_variable_attributes = @ ".R32_SysCtrl1"
extern volatile LWORD r32SysCtrl1[0x40];
// #pragma default_variable_attributes =

// #pragma default_variable_attributes = @ ".R8_BvaCtrl"
extern volatile BYTE rBvaCtrl[0x100];
// #pragma default_variable_attributes =

// #pragma default_variable_attributes = @ ".R16_BvaCtrl"
extern volatile WORD r16BvaCtrl[0x80];
// #pragma default_variable_attributes =

// #pragma default_variable_attributes = @ ".R32_BvaCtrl"
extern volatile LWORD r32BvaCtrl[0x40];
// #pragma default_variable_attributes =

// #pragma default_variable_attributes = @ ".R8_RsaCtrl"
extern volatile BYTE rRsaCtrl[0x200];
// #pragma default_variable_attributes =

// #pragma default_variable_attributes = @ ".R16_RsaCtrl"
extern volatile WORD r16RsaCtrl[0x100];
// #pragma default_variable_attributes =

// #pragma default_variable_attributes = @ ".R32_RsaCtrl"
extern volatile LWORD r32RsaCtrl[0x80];
// #pragma default_variable_attributes =

// #pragma default_variable_attributes = @ ".R8_I2cCtrl"
extern volatile BYTE rI2cCtrl[0x40];
// #pragma default_variable_attributes =

// #pragma default_variable_attributes = @ ".R16_I2cCtrl"
extern volatile WORD r16I2cCtrl[0x20];
// #pragma default_variable_attributes =

// #pragma default_variable_attributes = @ ".R32_I2cCtrl"
extern volatile LWORD r32I2cCtrl[0x10];
// #pragma default_variable_attributes =

// #pragma default_variable_attributes = @ ".R8_TsbCtrl"
extern volatile BYTE rTsbCtrl[0x800];
// #pragma default_variable_attributes =

// #pragma default_variable_attributes = @ ".R16_TsbCtrl"
extern volatile WORD r16TsbCtrl[0x400];
// #pragma default_variable_attributes =

// #pragma default_variable_attributes = @ ".R32_TsbCtrl"
extern volatile LWORD r32TsbCtrl[0x200];
// #pragma default_variable_attributes =

// #pragma default_variable_attributes = @ ".R8_ShaCtrl"
extern volatile BYTE rShaCtrl[0x80];
// #pragma default_variable_attributes =

// #pragma default_variable_attributes = @ ".R16_ShaCtrl"
extern volatile WORD r16ShaCtrl[0x40];
// #pragma default_variable_attributes =

// #pragma default_variable_attributes = @ ".R32_ShaCtrl"
extern volatile LWORD r32ShaCtrl[0x20];
// #pragma default_variable_attributes =

// #pragma default_variable_attributes = @ ".R8_TrngCtrl"
extern volatile BYTE rTrngCtrl[0x100];
// #pragma default_variable_attributes =

// #pragma default_variable_attributes = @ ".R16_TrngCtrl"
extern volatile WORD r16TrngCtrl[0x80];
// #pragma default_variable_attributes =

// #pragma default_variable_attributes = @ ".R32_TrngCtrl"
extern volatile LWORD r32TrngCtrl[0x40];
// #pragma default_variable_attributes =

// #pragma default_variable_attributes = @ ".R8_UartCtrl"
extern volatile BYTE rUartCtrl[0x100];
// #pragma default_variable_attributes =

// #pragma default_variable_attributes = @ ".R16_UartCtrl"
extern volatile WORD r16UartCtrl[0x80];
// #pragma default_variable_attributes =

// #pragma default_variable_attributes = @ ".R32_UartCtrl"
extern volatile LWORD r32UartCtrl[0x40];
// #pragma default_variable_attributes =

// #pragma default_variable_attributes = @ ".R8_EccDec"
extern volatile BYTE rEccDec[0x100];
// #pragma default_variable_attributes =

// #pragma default_variable_attributes = @ ".R16_EccDec"
extern volatile WORD r16EccDec[0x80];
// #pragma default_variable_attributes =

// #pragma default_variable_attributes = @ ".R32_EccDec"
extern volatile LWORD r32EccDec[0x40];
// #pragma default_variable_attributes =

// #pragma default_variable_attributes = @ ".R8_NBS"
extern volatile BYTE rNbs[0x200];
// #pragma default_variable_attributes =

// #pragma default_variable_attributes = @ ".R16_NBS"
extern volatile WORD r16Nbs[0x100];
// #pragma default_variable_attributes =

// #pragma default_variable_attributes = @ ".R32_NBS"
extern volatile LWORD r32Nbs[0x80];
// #pragma default_variable_attributes =

// #pragma default_variable_attributes = @ ".R8_BopCtrl"
extern volatile BYTE rBopCtrl[0x200];
// #pragma default_variable_attributes =

// #pragma default_variable_attributes = @ ".R16_BopCtrl"
extern volatile WORD r16BopCtrl[0x100];
// #pragma default_variable_attributes =

// #pragma default_variable_attributes = @ ".R32_BopCtrl"
extern volatile LWORD r32BopCtrl[0x80];
// #pragma default_variable_attributes =

// #pragma default_variable_attributes = @ ".R8_HdmaCtrl"
extern volatile BYTE rHdmaCtrl[0x200];
// #pragma default_variable_attributes =

// #pragma default_variable_attributes = @ ".R16_HdmaCtrl"
extern volatile WORD r16HdmaCtrl[0x100];
// #pragma default_variable_attributes =

// #pragma default_variable_attributes = @ ".R32_HdmaCtrl"
extern volatile LWORD r32HdmaCtrl[0x80];
// #pragma default_variable_attributes =

// #pragma default_variable_attributes = @ ".R8_LbaChk"
extern volatile BYTE rLbaChk[0x100];
// #pragma default_variable_attributes =

// #pragma default_variable_attributes = @ ".R16_LbaChk"
extern volatile WORD r16LbaChk[0x80];
// #pragma default_variable_attributes =

// #pragma default_variable_attributes = @ ".R32_LbaChk"
extern volatile LWORD r32LbaChk[0x40];
// #pragma default_variable_attributes =

// #pragma default_variable_attributes = @ ".R8_AesCtrl"
extern volatile BYTE rAesCtrl[0x800];
// #pragma default_variable_attributes =

// #pragma default_variable_attributes = @ ".R16_AesCtrl"
extern volatile WORD r16AesCtrl[0x400];
// #pragma default_variable_attributes =

// #pragma default_variable_attributes = @ ".R32_AesCtrl"
extern volatile LWORD r32AesCtrl[0x200];
// #pragma default_variable_attributes =

// #pragma default_variable_attributes = @ ".R8_SkipRam"
extern volatile BYTE rSkipRam[0x1000];
// #pragma default_variable_attributes =

// #pragma default_variable_attributes = @ ".R16_SkipRam"
extern volatile WORD r16SkipRam[0x800];
// #pragma default_variable_attributes =

// #pragma default_variable_attributes = @ ".R32_SkipRam"
extern volatile LWORD r32SkipRam[0x400];
// #pragma default_variable_attributes =

// #pragma default_variable_attributes = @ ".R8_FwAes"
extern volatile BYTE rFwAes[0x800];
// #pragma default_variable_attributes =

// #pragma default_variable_attributes = @ ".R16_FwAes"
extern volatile WORD r16FwAes[0x400];
// #pragma default_variable_attributes =

// #pragma default_variable_attributes = @ ".R32_FwAes"
extern volatile LWORD r32FwAes[0x200];
// #pragma default_variable_attributes =

// #pragma default_variable_attributes = @ ".R8_FakeCtrl"
extern volatile BYTE rFakeCtrl[0x1000];
// #pragma default_variable_attributes =

// #pragma default_variable_attributes = @ ".R16_FakeCtrl"
extern volatile WORD r16FakeCtrl[0x800];
// #pragma default_variable_attributes =

// #pragma default_variable_attributes = @ ".R32_FakeCtrl"
extern volatile LWORD r32FakeCtrl[0x400];
// #pragma default_variable_attributes =

// #pragma default_variable_attributes = @ ".R8_BvfORam"
extern volatile BYTE rBvfORam[0x4000];
// #pragma default_variable_attributes =

// #pragma default_variable_attributes = @ ".R16_BvfORam"
extern volatile WORD r16BvfORam[0x2000];
// #pragma default_variable_attributes =

// #pragma default_variable_attributes = @ ".R32_BvfORam"
extern volatile LWORD r32BvfORam[0x1000];
// #pragma default_variable_attributes =

// #pragma default_variable_attributes = @ ".R8_BvfBRam"
extern volatile BYTE rBvfBRam[0x4000];
// #pragma default_variable_attributes =

// #pragma default_variable_attributes = @ ".R16_BvfBRam"
extern volatile WORD r16BvfBRam[0x2000];
// #pragma default_variable_attributes =

// #pragma default_variable_attributes = @ ".R32_BvfBRam"
extern volatile LWORD r32BvfBRam[0x1000];
// #pragma default_variable_attributes =

// #pragma default_variable_attributes = @ ".R8_NVMe1"
extern volatile BYTE rNvme1[0x2800];
// #pragma default_variable_attributes =

// #pragma default_variable_attributes = @ ".R16_NVMe1"
extern volatile WORD r16Nvme1[0x1400];
// #pragma default_variable_attributes =

// #pragma default_variable_attributes = @ ".R32_NVMe1"
extern volatile LWORD r32Nvme1[0xA00];
// #pragma default_variable_attributes =

// #pragma default_variable_attributes = @ ".R8_NVMePrd"
extern volatile BYTE rNvmePrd[64][32];
// #pragma default_variable_attributes =

// #pragma default_variable_attributes = @ ".R16_NVMePrd"
extern volatile WORD r16NvmePrd[64][16];
// #pragma default_variable_attributes =

// #pragma default_variable_attributes = @ ".R32_NVMePrd"
extern volatile LWORD r32NvmePrd[64][8];
// #pragma default_variable_attributes =

// #pragma default_variable_attributes = @ ".R8_NVMeDesc"
extern volatile BYTE rNvmeDesc[64][32];
// #pragma default_variable_attributes =

// #pragma default_variable_attributes = @ ".R16_NVMeDesc"
extern volatile WORD r16NvmeDesc[64][16];
// #pragma default_variable_attributes =

// #pragma default_variable_attributes = @ ".R32_NVMeDesc"
extern volatile LWORD r32NvmeDesc[64][8];
// #pragma default_variable_attributes =

// #pragma default_variable_attributes = @ ".R8_NVMeHMB"
extern volatile BYTE rNvmeHmb[0xC000];
// #pragma default_variable_attributes =

// #pragma default_variable_attributes = @ ".R16_NVMeHMB"
extern volatile WORD r16NvmeHmb[0x6000];
// #pragma default_variable_attributes =

// #pragma default_variable_attributes = @ ".R32_NVMeHMB"
extern volatile LWORD r32NvmeHmb[0x3000];
// #pragma default_variable_attributes =

// #pragma default_variable_attributes = @ ".R8_FSHA"
extern volatile BYTE rFSHA[9][0x2000];
// #pragma default_variable_attributes =

// #pragma default_variable_attributes = @ ".R16_FSHA"
extern volatile WORD r16FSHA[9][0x1000];
// #pragma default_variable_attributes =

// #pragma default_variable_attributes = @ ".R32_FSHA"
extern volatile LWORD r32FSHA[9][0x800];
// #pragma default_variable_attributes =

// #pragma default_variable_attributes = @ ".R8_LDPcDsp"
extern volatile BYTE rLdpcDspCtrl[0x100000];
// #pragma default_variable_attributes =

// #pragma default_variable_attributes = @ ".R16_LDPcDsp"
extern volatile WORD r16LdpcDspCtrl[0x80000];
// #pragma default_variable_attributes =

// #pragma default_variable_attributes = @ ".R32_LDPcDsp"
extern volatile LWORD r32LdpcDspCtrl[0x40000];
// #pragma default_variable_attributes =

// #pragma default_variable_attributes = @ ".R8_LDPcDec"
extern volatile BYTE rLdpcDec[0x20000];
// #pragma default_variable_attributes =

// #pragma default_variable_attributes = @ ".R16_LDPcDec"
extern volatile WORD r16LdpcDec[0x10000];
// #pragma default_variable_attributes =

// #pragma default_variable_attributes = @ ".R32_LDPcDec"
extern volatile LWORD r32LdpcDec[0x8000];
// #pragma default_variable_attributes =

// #pragma default_variable_attributes = @ ".DIFFADDR_TAB1"
extern WORD g16arTotalDiffAddr[cTotalDiffAddrTableSize/2];    // 16K
// #pragma default_variable_attributes =

// #pragma default_variable_attributes = @ ".SLC_queue"
#if _EN_VPC_SWAP
extern LWORD g32DataBlockBitmap[64];    // 256/4
extern WORD g16GcSLCStartBlk;
extern WORD g16GcTLCStartBlk;
extern WORD g16DataBlkCnt;
#else
extern WORD g16SlcSortQFBlk[cMaxSlcBlkQ];
extern BYTE gSlcSortQIdx[c16MaxBlockNum];
extern LINKNODE garSlcSortQLink[cMaxSlcBlkQ];    // 1
extern volatile LINKINFO gsSlcSortQList;
extern BYTE garFreeSlcSortQ[cMaxSlcBlkQ];
extern LWORD g32FreeSlcSortQHead;
extern LWORD g32FreeSlcSortQTail;
#endif
// #pragma default_variable_attributes =

// #pragma default_variable_attributes = @ "RDCNT"
// extern LWORD g32arGlobReadCnt[c16MaxBlockNum];    // 8kb
// extern LWORD g32arPushReclaimQ[c16MaxBlockNum/32];    // 256b
// #pragma default_variable_attributes =

// #pragma default_variable_attributes = @ ".ERASECNT"
#if (!_EN_VPC_SWAP)
extern WORD g16arGlobEraseCnt[c16MaxBlockNum];    // 2kb
#endif
// #pragma default_variable_attributes =

// #pragma default_variable_attributes = @ ".EVENTLOGBUF"
extern volatile WORD g16arCore1EventLog[cCore1EventLogSize];
// #pragma default_variable_attributes =

// #pragma default_variable_attributes = @ ".SEED_TAB"
extern WORD g16arSeedTable[c16SeedTableSize];

// #pragma default_variable_attributes = @ ".CORE1_VAR"
extern volatile BYTE *rFLCtrl;
extern volatile WORD *r16FLCtrl;
extern volatile LWORD *r32FLCtrl;
extern volatile BYTE *rLdpcDsp;    // 0x51200000
extern volatile WORD *r16LdpcDsp;
extern volatile LWORD *r32LdpcDsp;
// extern volatile LWORD *g32arEraseFlag;
// extern volatile LWORD *r32SkipRam2;
extern WPROINFO gsWproInfo;
extern SYSRSVINFO gsSysRsvInfo;
extern ADDRINFO *gpFlashAddrInfo;
extern BYTE gActiveCe;
extern BYTE garSprSel[cMaxChNum];
// extern WORD g16arCurrSysBlkEsCnt[cRsvSysBlkNum];    // current system block erased count
// extern WORD g16IdxBlkFreePagePtr;
extern BYTE gErrInjectFlag;    // Bit 0: Read;Bit 1: Write
// extern WORD g16LastRdCntFBlock[cMaxChNum][cMaxIntlvWay];
extern BYTE gSysOpC1Flag;
extern WORD g16LastRdCntFBlock;
extern WORD g16LastRdCntFPage;

extern RETRYINFO gsReadRetryInfo;
extern WORD g16RCCnt;    // Cwh, For Debug, can be removed.
extern WORD g16DebugLastFailChunkBitMap;
extern WORD g16DebugEnterFailChunkBitMap;
extern BYTE garVthOffsetValue[cMaxRetryRegisterCnt];
extern BYTE garTrackVthCenter[cMaxRetryRegisterCnt];
extern BYTE gRetryTablePassIndex[cMaxChNum][cMaxIntlvWay][2];    // [CH][Intlv][SLC/TLC]  4*32*2=256
extern BYTE garLastPassVthCenter[cMaxChNum][cMaxIntlvWay][cMaxRetryRegisterCnt];
extern BYTE gCore1SeqFlag;
// extern BYTE garReadBufOccpyFlag[c16ReadBufSize4K];
extern BYTE garReadBufOrderHead[c16ReadBufSize4K];
extern BYTE garReadBufOrderTail[c16ReadBufSize4K];
extern RETRYINFO gsTestReadRetryInfo;
extern WORD *g16arDiffOffset;
extern WORD *g16arDiffAddr;
extern WORD *g16arDiffType2Offset;
extern BYTE *garRtDiffPoolPtr;
extern WORD g16LdpcDmaIdCnt;
extern BYTE gEnableLdpcPipe;
extern WORD g16DebugDoubleLockCnt;
extern BYTE gNandVersion;

extern BYTE gPSWstate;

// RAID related
extern HDMAINFO gsHdmaCtrl;
extern RAIDINFO gsRaidInfo;

extern Tracking TrackingPara[cMaxChNum];
extern BYTE u8VthLowerShiftStep;
extern BYTE u8VthUpperShiftStep;
extern BYTE u8LowerShiftLeft;
extern BYTE u8UpperShiftLeft;
extern BYTE u8TLClimit;
extern BYTE u8ARlimit;
extern BYTE u8SLClimit;
extern BYTE u8GRlimit;
extern BYTE SetSpeciailRR;

extern LWORD g32PreCmdAleDebugCnt[3];
extern LWORD g32Cpu1CycleCnt0;
extern LWORD g32Cpu1CycleCnt1;

extern LWORD g32RetryTime;
extern LWORD g32RaidTime;

extern WORD g16EccFailNormalQueIndex;
extern WORD g16EccFailAuxQueIndex;
extern WORD g16EccFailChAndCe;
extern WORD g16EccFailDieAndPlane;
extern WORD g16EccFailBlkAddr;
extern WORD g16EccFailPageAddr;
extern WORD g16EccFailRegInfo;    // 0x118 & 0x11D
extern WORD g16EccFailChunkBitMap;    // g16DebugLastFailChunkBitMap
extern WORD g16WdVuEraseProgramSts;
extern PROGFAILINFO gsProgFailInfo;
extern LWORD g32arPushReclaimQ[c16MaxBlockNum/32];    // 256b
extern WORD g16MaxECInSpare;    // test by yhlin

#endif    // ifndef __GLOBVAR1_H__







