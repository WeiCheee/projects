







// #include "inc/Const.h"
// #include "intrinsics.h"
// #include "inc/Option.h"
// #include "inc/TypeDef.h"

#pragma pack(1)
// ====CID Light Switch=== Start
typedef struct _CIDLS    // 0x1000~0x117F
{
    BYTE uarNameStr0[8];    // not use
    BYTE uarIspRev[8];    // fw revision
    BYTE uarRsvd0[144];
    BYTE uarNameStr1[8];    // not use
    BYTE uarLsRev[8];    // lightswitch revision
    BYTE uarNameStr2[16];    // not use
    BYTE uarVendorSpec[64];    //
    BYTE uarNameStr3[12];    // not use
    BYTE uarSerialNum[20];    //
    BYTE uarNameStr4[8];    // not use
    BYTE uarModelNum[40];    //
    BYTE uarRsvd1[48];
}CIDLS;
// ====CID Light Switch=== End

// ====Legacy Light Switch=== Start
typedef struct _LEGACYLS
{
    BYTE uarOpt0[80];    // not use
    WORD u16FixModeThresold;    // 0x50,0x051
    BYTE uEnMagOpt;    // 0x52 Channel default=0, Nitro default=1
    BYTE uEnNitroOpt;    // 0x53
    WORD u16PeCycle;    // 0x54,0x55
    BYTE uarOpt1[42];    // not use
}LEGACYLS;
// ====Legacy Light Switch=== End

// ====NVMe Light Switch=== Start
typedef union _NVMECONTROLLERCAPABILITYLOWER
{
    LWORD u32All;

    // struct
    // {
    // LWORD ubMaximumQueueEntriesSupported    : 16;
    // LWORD ubContiguousQueuesRequired        : 1;//CQR
    // LWORD ubArbitrationMechanismSupported   : 2;//CFS and AMS
    // LWORD ubRsvd2                           : 5;
    // LWORD ubTimeout                         : 8;
    // };
}NVMECONTROLLERCAPABILITYLOWER;

typedef union _NVMECONTROLLERCAPABILITYUPPER
{
    LWORD u32All;

    // struct
    // {
    // LWORD ubRsvd1                       : 4;
    // LWORD ubNVMSubsystemResetSupported  : 1;//NSSRS
    // LWORD ubRsvd2                       : 11;
    // LWORD ubMemoryPaageSzieMinimum      : 4;
    // LWORD ubMemoryPaageSzieMaximum      : 4;
    // LWORD ubRsvd3                       : 8;
    // };
}NVMECONTROLLERCAPABILITYUPPER;

typedef union _NVMEAUTONOMOUSPOWERSTATETRANSITION
{
    LWORD u32All;

    // struct
    // {
    // LWORD ubRsvd                            : 8;
    // LWORD ubIdleTime                        : 24;
    // };
}NVMEAUTONOMOUSPOWERSTATETRANSITION;

// OPTIONALADMINCOMMANDSUPPORT
#define cSecuritySendReceiveCmd         c16Bit0
#define cFormatCmd                      c16Bit1
#define cFWCommitImageDlCmd             c16Bit2
#define cNamespaceManageAttachCmd       c16Bit3
#define cDeviseSelfTestCmd              c16Bit4
#define cDirectivesCmd                  c16Bit5
#define cNvmeMiCmd                      c16Bit6
#define cVirtualizationManaCmd          c16Bit7
#define cDoorbellBufConfigCmd           c16Bit8

// FIRMWAREUPDATES
#define cFwSlot1ReadOnly                cBit0
#define cNumberOfFwSlot                 (cBit1|cBit2|cBit3)
#define cFwActivationWoReset            cBit4

// OPTIONALNVMCOMMANDSUPPORT
#define cCompareCommand                 cBit0
#define cWriteUncCommand                cBit1
#define cDatasetManagementCommand       cBit2
#define cWriteZeroesCommand             cBit3
#define cSaveFieldAndTheSelectField     cBit4
#define cReservations                   cBit5
#define cTimeStampFeat                  cBit6

// VOLATILEWRITECACHE
#define cVolatileWriteCacheEn           cBit0

#define cFlushBcNsidNotIndicated            0
#define cFlushBcNsidNotSupport              2
#define cFlushBcNsidSupport                 3

// FUSEDOPERATIONSUPPORT
#define cFuseSupport                    cBit0

typedef union _INGORENSID
{
    BYTE uAll;

    // struct
    // {
    // BYTE ubIgnoreInIDNamespace         : 1;
    // BYTE ubIgnoreInIDController        : 1;
    // BYTE ubRsvd                        : 6;
    // };
}INGORENSID;

#define cNvme13      cBit0
#define cIol70a      cBit2
#define cPcie30      cBit0

typedef union _COMPLIANCETEST
{
    BYTE uAll;

    // struct
    // {
    //    BYTE    bNVMe_1_3        :1; // default is 1.3
    //    BYTE    bIOL_7_0_a       :1; // default is disable (for some compilance test fail (Reserved items))
    //    BYTE    bPCIe_3_0        :1; // default is 3.0
    //    BYTE    Reserved         :5;
    // }
}COMPLIANCETEST;

// For FeatOption
#define cDisableHmb         cBit0
#define cEnableNamespace    cBit1

// FNA
#define cFnaFormatForAllNamespaces      cBit0
#define cFnaSecureEraseForAllNamespaces cBit1
#define cFnaCryptographicEraseSupported cBit2

typedef struct _NVMELS    // 0x1240~0x12BF
{
    WORD u16Oacs;    // Optional Admin Command Support
    BYTE uAcl;    // Abort Command Limit
    BYTE uAerl;    // Asynchronous Event Request Limit
    BYTE usFrmw;    // Firmware Updates
    BYTE uLpa;    // Log Page Attributes
    BYTE uElpe;    // Error Log Page Entries
    BYTE uNpss;    // Number of Power States Support
    BYTE uApsta;    // Autonomous Power State Transition Attributes
    BYTE uOncs;    // Optional NVM Command Support
    WORD u16WcTemp;    // Warning Composite Temperature Threshold
    WORD u16CcTemp;    // Critical Composite Temperature Threshold
    BYTE uRsvd0;
    BYTE uRsvd1;
    NVMECONTROLLERCAPABILITYLOWER usControllerCapLo;    // 0x10
    NVMECONTROLLERCAPABILITYUPPER usControllerCapHi;    // 0x14
    NVMEAUTONOMOUSPOWERSTATETRANSITION usPs3ApstTimer;    // 0x18
    NVMEAUTONOMOUSPOWERSTATETRANSITION usPs4ApstTimer;    // 0x1C
    NVMEAUTONOMOUSPOWERSTATETRANSITION usApstPs2;    // 0x20
    NVMEAUTONOMOUSPOWERSTATETRANSITION usApstPs3;    // 0x24
    BYTE uVwc;    // 0x28, Volatile Write Cache
    BYTE uRab;    // 0x29, Recommended Abritration Burst
    WORD u16Vid;    // 0x2A
    WORD u16Ssvid;    // 0x2C
    BYTE uMdts;    // 0x2E, Maximum Data Transfer Size
    BYTE uFna;    // 0x2F, Format NVM Attributes
    LWORD u32Ver;    // 0x30, Version
    LWORD u32Rtd3R;    // 0x34, RTD3 Resume Latency
    LWORD u32Rtd3E;    // 0x38, RTD3 Entry Latency
    WORD uFuses;    // 0x3C, Fused Operation Support, not use
    WORD u16Mtfa;    // 0x3E, Maximum Time for Firmware Activation
    BYTE uApst2Ps34;    // 0x40, not use
    BYTE uForceApst;    // not use
    BYTE uPdTimer;    // 0x42, Set programmable timer for DRAM/NAND turn off time guarantee on PS4
    INGORENSID usIgnoreNsId;    // 0x43,default 0
    WORD u16MnTmt;    // 0x44
    WORD u16MxTmt;    // 0x46
    BYTE uComplianceTest;    // uDoorBellPatch;    // 0x48
    BYTE uAsynConfig;    // 0x49
    WORD u16Ps3StayTime;    // 0x4A~0x4B
    BYTE uRsvd2;    // 0x4C
    BYTE uarIeee[3];    // 0x4D~0x4F
    BYTE uarNguid[16];    // 0x50~0x5F
    BYTE uarEui64[8];    // 0x60~0x67
    WORD u16Ps4Mp;    // 0x68
    BYTE uPs4Mxps;    // 0x6A
    BYTE uRsvd3;    // 0x6B
    LWORD u32Ps4EnLat;    // 0x6C~0x6F
    LWORD u32Ps4ExLat;    // 0x70~0x73
    BYTE uShortDstRegionNum;    // 0x74
    BYTE uExtndDstRegionNum;    // 0x75
    BYTE uPreCR;    // 0x76
    BYTE uFeatOption;    // 0x77
    BYTE uarRsvd3[8];    // 0x78~0x7F
}NVMELS;
// ====NVMe Light Switch=== End

// ====PCIe Light Switch=== Start

// Offset 0xC38
typedef union _LTRENTRY
{
    LWORD u32All;

    // struct
    // {
    // LWORD ubMaxSnoopLatencyValue         :   10;
    // LWORD ubMaxSnoopLatencyScale         :   3;
    // LWORD ubRsvd1                        :   2;
    // LWORD ubSnoopLatencyRequirement      :   1;
    // LWORD ubMaxNoSnoopLatencyValue       :   10;
    // LWORD ubMaxNoSnoopLatencyScale       :   3;
    // LWORD ubRsvd2                        :   2;
    // LWORD ubNoSnoopLatencyRequirement    :   1;
    // };
}LTRENTRY;

typedef union _REFCLKANDOROM
{
    BYTE uAll;

    // struct
    // {
    // BYTE ubUefiOrom               :1; // 0 = enable, 1 = disable
    // BYTE ubPcieIntRefclkSelect    :2;
    // BYTE ubSpreadSpectrum         :1;
    // BYTE ubTimer0                 :1;
    // BYTE ubTimer1                 :1;
    // BYTE ubRsvd                   :2;
    // };
}REFCLKANDOROM;

typedef union _MSIMESSAGECONTROL
{
    BYTE uAll;

    // struct
    // {
    // BYTE ubRsvd1                   :1;
    // BYTE ubMultipleMessageCapable  :3;
    // BYTE ubRsvd2                   :4;
    // };
}MSIMESSAGECONTROL;

typedef union _DEVICECAPLS
{
    WORD u16All;

    // struct
    // {
    // WORD ubMaxPayloadSizeSupported      :3;
    // WORD ubRsvd1                        :3;
    // WORD ubEndpointL0sAcceptableLatency :3;
    // WORD ubEndpointL1AcceptableLatency  :3;
    // WORD ubRsvd2                        :4;
    // };
}DEVICECAPLS;

typedef union _PCIELINKCAPABILITIESREGISTER
{
    LWORD u32All;

    // struct
    // {
    // LWORD ubMaximumLinkSpeed                     :4;
    // LWORD ubMaximumLinkWidth                     :6;
    // LWORD ubActiveStatePmSupport                 :2;
    // LWORD ubL0sExitLatency                       :3;
    // LWORD ubL1ExitLatency                        :3;
    // LWORD ubClockPowerManagement                 :1;
    // LWORD ubSurpriseDownErrorReportingCapable    :1;
    // LWORD ubDataLinkLayerActiveReportingCapable  :1;
    // LWORD ubLinkBandwidthNotificationCapability  :1;
    // LWORD ubASPMOptionalityCompliance            :1;
    // LWORD ubRsvd                                 :1;
    // LWORD ubPortNumber                           :8;
    // };
}PCIELINKCAPABILITIESREGISTER;

typedef union _PCIEDEVICECAPABILITIES2REGISTER
{
    LWORD u32All;

    // struct
    // {
    // LWORD ubCompletionTimeoutRangesSupported   :4;
    // LWORD ubCompletionTimeoutDisableSupported  :1;
    // LWORD ubARIForwardingSupported             :1;
    // LWORD ubAtomicOpRoutingSupported           :1;
    // LWORD ubAtomicOpCompleterSupported32Bit    :1;
    // LWORD ubAtomicOpCompleterSupported64Bit    :1;
    // LWORD ubCASCompleterSupported128Bit        :1;
    // LWORD ubNoROEnabledPRPRPassing             :1;
    // LWORD ubLtrMechanismSupported              :1;
    // LWORD ubTPHCompleterSupported              :2;
    // LWORD ubRsvd1                              :4;
    // LWORD ubOBFFSupported                      :2;
    // LWORD ubExtendedFmtFiledSupported          :1;
    // LWORD ubEnd2EndTLPPrefixSupported          :1;
    // LWORD ubMaxEnd2EndTLPPrefixes              :2;
    // LWORD ubRsvd2                              :8;
    // };
}PCIEDEVICECAPABILITIES2REGISTER;

typedef union _PCIEMSIXMESSAGECONTROL
{
    WORD u16All;

    // struct
    // {
    // WORD ubTableSize     :11;
    // WORD ubRsvd          :3;
    // WORD ubFunctionMask  :1;
    // WORD ubMSIXEnable    :1;
    // };
}PCIEMSIXMESSAGECONTROL;

typedef union _LINKCAP2LS
{
    BYTE uAll;

    // struct
    // {
    // BYTE ubRsvd                       :1;
    // BYTE ubSupportedLinkSpeedsVector  :7;
    // };
}LINKCAP2LS;

typedef union _AERCAPLS
{
    BYTE uAll;

    // struct
    // {
    // BYTE ubRsvd1              :5;
    // BYTE ubEcrcGenerationCap  :1;
    // BYTE ubRsvd2              :1;
    // BYTE ubEcrcCheckCap       :1;
    // };
}AERCAPLS;

typedef union _L1SUBEXTCAP
{
    LWORD u32All;

    // struct
    // {
    // LWORD ubApsmL1xOnOperationPS    :1;
    // LWORD ubRsvd1                   :1;
    // LWORD ubAspmL12Supported        :1;
    // LWORD ubAspmL11Supported        :1;
    // LWORD ubL1PmSubstatesSupported  :1;
    // LWORD ubRsvd2                   :3;
    // LWORD ubRsvd3                   :24;
    // };
}L1SUBEXTCAP;

typedef union _LINKSTATEENTRANCEIDLETIME
{
    LWORD u32All;

    // struct
    // {
    // LWORD ubL12EnternaceIdleTime :16;
    // LWORD ubResvd1623            :8;
    // LWORD ubL0sEnternaceIdleTime :3;
    // LWORD ubL1EnternaceIdleTime  :3;
    // LWORD ubResvd3031            :2;
    // };
}LINKSTATEENTRANCEIDLETIME;

// Offset 0xC30
typedef union _LTRMSGTIMER
{
    LWORD u32All;

    // struct
    // {
    // LWORD   ubTimer0 : 16; //L1
    // LWORD   ubTimer1 : 16; //L12
    // };
}LTRMSGTIMER;

typedef struct _PCIELS    // 0x1200~0x123F
{
    WORD u16PcieVidLs;    // 0x00
    WORD u16PcieDidLs;    // 0x02
    LTRENTRY usLtrL0EntryLs;    // 0x04, LWORD
    LTRENTRY usLtrL1EntryLs;    // 0x08, LWORD
    LTRENTRY usLtrL12EntryLs;    // 0x0C, LWORD
    REFCLKANDOROM usRefClkAndOROM;    // 0x10, BYTE
    MSIMESSAGECONTROL usMultipleMesgCap;    // 0x11, BYTE
    DEVICECAPLS usDeviceCapLs;    // 0x12, WORD
    PCIELINKCAPABILITIESREGISTER usLinkCapLs;    // 0x14, LWORD
    PCIEDEVICECAPABILITIES2REGISTER usDeviceCap2Ls;    // 0x18, LWORD
    PCIEMSIXMESSAGECONTROL usMessageCtrlLs;    // 0x1C, WORD
    LINKCAP2LS usLinkCap2Ls;    // 0x1E, BYTE
    AERCAPLS usAerCapLS;    // 0x1F, BYTE
    L1SUBEXTCAP uL1SubExtCapLs;    // 0x20, LWORD ;offset 0x21,0x22,0x23 not use
    LINKSTATEENTRANCEIDLETIME usLinkStateEntranceIdleTime;    // 0x24, LWORD
    LTRMSGTIMER usLtrTimer;    // 0x28, LWORD
    LWORD u32Rsvd2;    // 0x2C
    WORD u16PcieSsvidLs;    // 0x30
    WORD u16PcieSsidLs;    // 0x32
    BYTE uarRsvd3[12];    // 0x34~0x3F
}PCIELS;

// ====PCIe Light Switch=== End

// ====PHY Light Switch=== Start

#define cG2DphyManual             cBit0
#define cG1DphyManual             cBit1
#define cDeemphManual             cBit4    // ADDR 0x3C~0x3F, OFFSET 0x18[4]     D

typedef union _DPHYMANUALENABLE
{
    BYTE uAll;

    // struct
    // {
    // BYTE ubG2DphyManual :1;
    // BYTE ubG1DphyManual :1;
    // BYTE ubRsvd1        :2;
    // BYTE ubDeemphManual :1; //ADDR 0x3C~0x3F, OFFSET 0x18[4]     D
    // BYTE ubRsvd2        :3;
    // };
}DPHYMANUALENABLE;

#define cKDmanual                 cBit0    // 0
#define cKPmanual                 cBit1    // 1
#define cKImanual                 cBit2    // 2
#define cEQRmanual                cBit3    // 3
#define cEQCmanual                cBit4    // 4
#define cTAP1manual               cBit5    // 5
#define cTAP2manual               cBit6    // 6
#define cTAP3manual               cBit7    // 7

typedef union _APHYMANUALENABLE
{
    BYTE uAll;

    // struct
    // {
    // BYTE ubKDmanual   :1;   //0
    // BYTE ubKPmanual   :1;   //1
    // BYTE ubKImanual   :1;   //2
    // BYTE ubEQRmanual  :1;   //3
    // BYTE ubEQCmanual  :1;   //4
    // BYTE ubTAP1manual :1;   //5
    // BYTE ubTAP2manual :1;   //6
    // BYTE ubTAP3manual :1;   //7
    // };
}APHYMANUALENABLE;

#if 0    // 2260

#define cPresetValueEQphase2En     cBit0
#define cEarlyPCIeResetEn          cBit1

typedef union _CUSTOMIZEFLAG
{
    BYTE uAll;

    // struct
    // {
    // BYTE ubPresetValueEQphase2En  :1;
    // BYTE ubEarlyPcieResetEn       :1;
    // BYTE ubRsvd                   :6;
    // };
}CUSTOMIZEFLAG;

#else    // 2263

#define cEQphase2PresetValueP0     c16Bit0
#define cEQphase2PresetValueP1     c16Bit1
#define cEQphase2PresetValueP2     c16Bit2
#define cEQphase2PresetValueP3     c16Bit3
#define cEQphase2PresetValueP4     c16Bit4
#define cEQphase2PresetValueP5     c16Bit5
#define cEQphase2PresetValueP6     c16Bit6
#define cEQphase2PresetValueP7     c16Bit7
#define cEQphase2PresetValueP8     c16Bit8
#define cEQphase2PresetValueP9     c16Bit9
#define cEQphase2PresetValueP10    c16Bit10

#define cEarlyPCIeResetEn          c16Bit15

typedef union _CUSTOMIZEFLAG
{
    WORD u16All;

    // struct
    // {
    // WORD ubEQphase2PresetValueP0  :1;
    // WORD ubEQphase2PresetValueP1  :1;
    // WORD ubEQphase2PresetValueP2  :1;
    // WORD ubEQphase2PresetValueP3  :1;
    // WORD ubEQphase2PresetValueP4  :1;
    // WORD ubEQphase2PresetValueP5  :1;
    // WORD ubEQphase2PresetValueP6  :1;
    // WORD ubEQphase2PresetValueP7  :1;
    // WORD ubEQphase2PresetValueP8  :1;
    // WORD ubEQphase2PresetValueP9  :1;
    // WORD ubEQphase2PresetValueP10 :1;
    // WORD ubRsvd                   :4;
    // WORD ubEarlyPCIeResetEn       :1;
    // };
}CUSTOMIZEFLAG;
#endif    // if 0

typedef struct _PHYLS    // address                         type      // 0x12C0~0x12FF
{
    BYTE uG3SrisSrnsStep;    // sys
    BYTE uG3SrisSrnsSmin;    // ADDR 0x3C, OFFSET 0x20[5:0]	    D
    BYTE uG3SrisSrnsSmax;    // ADDR 0x3C, OFFSET 0x22[5:0]	    D
    BYTE uG1G2SrisSrnsStep;    // sys
    BYTE uG1G2SrisSrnsSmin;    // ADDR 0x3C, OFFSET 0x1B[5:0]   D
    BYTE uG1G2SrisSrnsSmax;    // ADDR 0x3C, OFFSET 0x1D[5:0]   D
    BYTE uG3NormalTxSwing;    // ADDR 0x3C, OFFSET 0x11[4:0]    D
    BYTE uG2NormalTxSwing;    // ADDR 0x3C, OFFSET 0x7B[4:0]    D
    BYTE uG1NormalTxSwing;    // ADDR 0x3C, OFFSET 0x77[4:0]	D
    BYTE uDphyManual;    // DPHYMANUALENABLE
    BYTE uG3Dm0;    // ADDR 0x3C~0x3F, OFFSET 0x26[3:0]	D
    BYTE uG3Dm1;    // ADDR 0x3C~0x3F, OFFSET 0x27[4:0]	D
    BYTE uG3Dm2;    // ADDR 0x3C~0x3F, OFFSET 0x28[4:0]	D
    BYTE uG2Dm0;    // ADDR 0x3C~0x3F, OFFSET 0x23[3:0]	D
    BYTE uG2Dm1;    // ADDR 0x3C~0x3F, OFFSET 0x24[4:0]	D
    BYTE uG2Dm2;    // ADDR 0x3C~0x3F, OFFSET 0x25[4:0]	D
    BYTE uG1Dm0;    // ADDR 0x3C~0x3F, OFFSET 0x18[3:0]	D
    BYTE uG1Dm1;    // ADDR 0x3C~0x3F, OFFSET 0x19[4:0]	D
    BYTE uG1Dm2;    // ADDR 0x3C~0x3F, OFFSET 0x1A[4:0]	D
    BYTE uG3Kd;    // ADDR 0x3C~0x3F, OFFSET 0x02[3:0]	D
    BYTE uG3Kp;    // ADDR 0x3C~0x3F, OFFSET 0x03[7:0]	D
    BYTE uG3Ki;    // ADDR 0x3C~0x3F, OFFSET 0x05[7:0]	D
    BYTE uG2Kd;    // ADDR 0x3C~0x3F, OFFSET 0x48[3:0]	D
    BYTE uG2Kp;    // ADDR 0x3C~0x3F, OFFSET 0x49[7:0]	D
    BYTE uG2Ki;    // ADDR 0x3C~0x3F, OFFSET 0x4A[7:0]	D
    BYTE uG1Kd;    // ADDR 0x3C~0x3F, OFFSET 0x43[3:0]	D
    BYTE uG1Kp;    // ADDR 0x3C~0x3F, OFFSET 0x44[7:0]	D
    BYTE uG1Ki;    // ADDR 0x3C~0x3F, OFFSET 0x45[7:0]	D
    BYTE uManualUseRxCoef;    // ADDR 0x3C~0x3F, OFFSET 0xF5[5:1]	D
    BYTE uG3Eqr;    // ADDR 0x3C~0x3F, OFFSET 0xD7[4:0]	D
    BYTE uG3Eqc;    // ADDR 0x3C~0x3F, OFFSET 0xDA[3:0]	D
    BYTE uG3Tap1;    // ADDR 0x3C~0x3F, OFFSET 0xDD[5:0]	D
    BYTE uG3Tap2;    // ADDR 0x3C~0x3F, OFFSET 0xE0[4:0]	D
    BYTE uG3Tap3;    // ADDR 0x3C~0x3F, OFFSET 0xE3[4:0]	D
    BYTE uG2Eqr;    // ADDR 0x3C~0x3F, OFFSET 0xEA[4:0]	D
    BYTE uG2Eqc;    // ADDR 0x3C~0x3F, OFFSET 0xE9[3:0]	D
    BYTE uG2Tap1;    // ADDR 0x3C~0x3F, OFFSET 0xEC[5:0]	D
    BYTE uG2Tap2;    // ADDR 0x3C~0x3F, OFFSET 0xED[4:0]	D
    BYTE uG2Tap3;    // ADDR 0x3C~0x3F, OFFSET 0xEE[4:0]	D
    BYTE uG1Eqr;    // ADDR 0x3C~0x3F, OFFSET 0xF7[4:0]	D
    BYTE uG1Eqc;    // ADDR 0x3C~0x3F, OFFSET 0xF6[3:0]	D
    BYTE uG1Tap1;    // ADDR 0x3C~0x3F, OFFSET 0xF8[5:0]	D
    BYTE uG1Tap2;    // ADDR 0x3C~0x3F, OFFSET 0xF9[4:0]	D
    BYTE uG1Tap3;    // ADDR 0x3C~0x3F, OFFSET 0xFA[4:0]	D
    BYTE uNormalModeMax;    // ADDR 0x3C~0x3F, OFFSET 0x00[3:0]	D
    BYTE uSrisSrnsMax;    // ADDR 0x3C~0x3F, OFFSET 0x01[3:0]	D
    BYTE uSqaOffSet;    // ADDR 0x3C~0x3F, OFFSET 0x04[5:1]	D
    BYTE uPllVvco;    // ADDR 0x21, OFFSET 0x06[5:2]	    A
    BYTE uAPhyManual;    // APHYMANUALENABLE
    BYTE uKd;
    BYTE uKp;
    BYTE uKpG3LoopBack;
    BYTE uKi;
    BYTE uEqr;
    BYTE uEqc;
    BYTE uTap1;
    BYTE uTap2;
    BYTE uTap3;    // 0x39
    WORD u16CustomizeF;    // 0x3A,0x3B, CUSTOMIZEFLAG //BYTE uLenovo;
    BYTE uReadbackFailHang;    // 0x3C
    BYTE uDelayCnt;    // 0x3D
    BYTE uRsvd;    // 0x3E
    BYTE uL0SRxOff;    // 0x3F
}PHYLS;

// ====PHY Light Switch=== End

// ====Sec Light Switch=== Start
#define c32Tcg                  c32Bit0
#define c32Ieee1667             c32Bit1
#define c32Pyrite               c32Bit2
#define c32OpalLite             c32Bit3
#define c32AtaPassThrough       c32Bit4
// ReservedBit		c32Bit5
// ReservedBit		c32Bit6
#define c32AutoFreezeLock       c32Bit7
#define c32Rpmb                 c32Bit8
#define c32SecFeatAll           0x0000007F

typedef struct _SECLS    // 0x1300~0x137F
{
    LWORD u32SecFeature;    // 0x300~0x303
    BYTE uAes;    // 0x304
    BYTE uHpAuthen;    // 0x305
    BYTE uRpmbTargetNum;    // 0x306
    BYTE uRpmbTargetSize;    // 0x307
    BYTE uEnAtaPassword;    // 0x308
    BYTE Rsvd0[87];
    BYTE uAtaPassword[32];
}SECLS;
// ====Sec Light Switch=== End

// ====Gen Light Switch=== Start
typedef struct _GENLS    // 0x1380~0x138F
{
    BYTE uCeExtend;
    BYTE uarRsvd0[15];
}GENLS;
// ====Gen Light Switch=== End

// ====Thermal Throttling Light Switch=== Start
// Thermal Ctrl
#define cEnThrottle         cBit0
#define cEnSleep            cBit1
#define cEnShutDownHang     cBit2
#define cEnKeepLs           cBit3

// Sensor Sel
#define cAsicSensor0             cBit0
#define cAsicSensor1             cBit1
#define cExternalSensor          cBit2
#define cNandSensor              cBit3
#define cNormalization           cBit4
#define cAsicSensor01            0x03
// #define mGetNormalizedSensor(x)  ((x<<5)&0x60)

// NAND Sel
#define mGetTempSelCh(x)    (x&0x0F)
#define mGetTempSelCe(x)    ((x&0xF0)>>4)

#define cSmartTempModeDefault   0x00
#define cSmartTempModeFix       0x01
#define cSmartTempModeClamp     0x02

typedef struct _PSPARAMETER
{
    WORD u16SysClock;
    WORD u16LdpcClock;
    WORD u16FlashClock;
    WORD u16Rsvd;
}PSPARAMETER;

typedef struct _THERMALCALC
{
    BYTE uShiftBit;
    BYTE uThetaJc;
}THERMALCALC;

typedef struct _NORMALIZATION
{
    THERMALCALC usThermalCalc[6];
    BYTE uSmartReportMode;    // 0x0C
    BYTE uSmartReportTemp;    // 0x0D
    BYTE uRsvd[4];

    // WORD u16ParaA1;
    // WORD u16ParaB1;
    // WORD u16ParaA2;
    // WORD u16ParaB2;
    // WORD u16ParaA3;
    // WORD u16ParaB3;
    // BYTE uSignB1;    // 0 : minus(-), 1: plus(+)
    // BYTE uSignB2;    // 0 : minus(-), 1: plus(+)
    // BYTE uSignB3;    // 0 : minus(-), 1: plus(+)
    // BYTE uTempCut1;
    // BYTE uTempCut2;
    // BYTE uRsvd0;    // for WORD alignment
}NORMALIZATION;

typedef struct _THERMALLS    // 0x1390~0x13DF
{
    BYTE uThermalCtrl;    // 0x00
    BYTE uSensorSel;    // 0x01
    BYTE uNandSensorSelect;    // 0x02, reserved for NAND sensor selection
    BYTE uMt1;    // 0x03
    BYTE uMt1FallDelta;    // 0x04
    BYTE uMt2;    // 0x05
    BYTE uMt2FallDelta;    // 0x06
    BYTE uMt3;    // 0x07
    BYTE uMt3FallDelta;    // 0x08
    BYTE uSensorPollingThres;    // 0x09
    BYTE uCode85Unused;    // 0x0A
    BYTE uCode30Unused;    // 0x0B
    BYTE uTrimValue;    // 0x0C
    BYTE uIdleThermalLogThres;    // 0x0D
    BYTE uSleepIdleThres;    // 0x0E
    BYTE uUndefined;    // 0x0F
    PSPARAMETER usPs0;    // 0x10
    PSPARAMETER usPs1;    // 0x18
    PSPARAMETER usPs2;    // 0x20
    PSPARAMETER usPsShutdown;    // 0x28
    NORMALIZATION usNormalization;    // 0x30
    WORD u16PS2WriteDelayCnt;    // 0x42
    WORD u16PS2ReadDelayCnt;    // 0x44
    BYTE uFeatureF1;    // 0x46
    BYTE uThermalOffset;    // 0x47
    WORD u16EraseDelayUs;    // 0x48
    BYTE uStagerredEraseDieThres;    // 0x4A
    BYTE uUndefined5B;    // 0x4B
    WORD u16Code85;    // 0x4C
    WORD u16Code30;    // 0x4E
}THERMALLS;
// ====Thermal Throttling Light Switch=== End

// ====Algo Light Switch=== Start
typedef struct _ALGOLS    // 0x13E0~0x13FF
{
    BYTE uMaxLatForClean;    // 0x00
    BYTE uSHNTimeOutSec;    // 0x01
    BYTE uLimitedCleanSrcCnt;    // 0x02
    BYTE uCmdNumForBuildGroup;    // 0x03
    LWORD u32MBPerEntry;    // 0x04
    LWORD u32TrimTimeOutTH;    // 0x08
    LWORD u32IdleTrimTimeOutTH;    // 0x0C
    BYTE uarRsvd[16];    // 0x10~0x1F
}ALGOLS;
// ====Algo Light Switch=== End

// ====Smart Light Switch=== Start
// SMARTWarn
#define cSmartWarnAvaliableSpare     cBit0
#define cSmartWarnTemperature        cBit1
#define cSmartWarnReliability        cBit2
#define cSmartWarnReadOnly           cBit3
#define cSmartWarnVolatileMemFail    cBit4

typedef struct _SMARTLS    // 0x1400~0x147F
{
    BYTE uReAssignedSectorCntThres;    // 0x00
    BYTE uProgramFailCntTotalThres;    // 0x01
    BYTE uEraseFailCountTotalThres;    // 0x02
    BYTE uWearLevelingCntThres;    // 0x03
    BYTE uUsedRsrvdBlockCntTotalThres;    // 0x04
    BYTE uarRsvd0[11];    // 0x05
    BYTE uAvaliableSpareThres;    // 0x10
    BYTE uWarning;    // 0x11
    BYTE uarRsvd1[110];
}SMARTLS;
// ====Smart Light Switch=== End

// ====Self Test Light Switch=== Start
typedef struct _SELFTESTLS    // 0x1480~0x14BF
{
    BYTE uRdtLoop;
    WORD u16RDTErrCntThres;
    BYTE uRdtEccFailCntThres;
    BYTE uRdtEraseFailCntThres;
    BYTE uRdtProgFailCntThres;
    BYTE uRdtReadRetry;
    BYTE uChkUPageReadBackCorrEcc;
    BYTE uWarning;
    BYTE uTestStrategy;
    BYTE uTestDelayTime;
    BYTE uExtraProgramTest;
    BYTE uarRsvd[52];
}SELFTESTLS;
// ====Self Test Light Switch=== End

// ====VUID Light Switch=== Start
typedef struct _VUIDLS    // 0x14C0~0x14FF
{
    BYTE uarEppId[0x20];
    WORD u16NominalFormFactor;    // 0x20
    BYTE uRsvd22h;    // 0x22
    BYTE uRsvd23h;    // 0x23
    WORD u16IntelProFeatureIdentifier;    // 0x24
    BYTE uarWWN[8];    // 0x26
    BYTE uOemId;    // 0x2E
    BYTE uarRsvd[17];    // 0x2F~0x3F
}VUIDLS;
// ====VUID Light Switch=== End

// ====VDT Light Switch=== Start
#define cVdt18Dram                 cBit0
#define cUndefined1                cBit1
#define cVdt2XFsh                  cBit2
#define cVdt12Fio                  cBit3
#define cUndefined4                cBit4
#define cUndefined5                cBit5
#define cUndefined6                cBit6
#define cUndefined7                cBit7

typedef struct _VDTLS    // 0x1500~0x150F
{
    BYTE VdtEnableBit;
    BYTE Vdt27Fsh2Level;
    BYTE Vdt23Fsh1Level;
    BYTE Vdt18DramLevel;
    BYTE Vdt12FioLevel;
    BYTE uarRsvd[11];    //
}VDTLS;
// ====VDT Light Switch=== End

// ====OEM3 Light Switch=== Start
#define cFtlBgdGc                  cBit0
#define cFtlCacheRead              cBit1
#define cFtlCacheProg              cBit2
#define cFtlReadScrub              cBit3

typedef struct _OEM3LS    // 0x1510~0x15FF
{
    BYTE uarCapitalCaseChars[3];    // Capital Case Characters: "LEN"
    BYTE uarRsrvdFutureUse[17];    // Reserved for Future Use, fill with 20h (Blanks)
    BYTE uarOriManufBarCodeInfo[30];    // Original manufacturing 8S bar-code information.1 This field is left-justified with right-padding of
                                        // blanks (20h)
    BYTE uarOriManufSupplierMN[30];    // Original manufacturing Supplier Model Number. This field is left-justified with right-padding of
                                       // blanks (20h)
    BYTE uarOriManufSupplierSN[30];    // Original manufacturing Supplier Serial Number. This field is left-justified with right-padding of
                                       // blanks(20h)
    BYTE uarLabelChange[30];    // Current 8S label as a result of any field change. 1,2 This field is left-justified with right-padding of
                                // blanks (20h)
    BYTE uEnWdt;
    BYTE uPs3EnPwrDomain1;    // Enable Power Domain 1 at PS3
    BYTE uFtlCtrl;
    BYTE uarRsrvd0;
    BYTE uNandMt3;
    BYTE uNandMt3FallDelta;
    BYTE uNandMtSd;
    BYTE uAsicMt3;
    BYTE uAsicMt3FallDelta;
    BYTE uAsicMtSd;
    BYTE uarRsrvd[90];
}OEM3LS;
// ====OEM3 Light Switch=== End

// ====NVMe 2 Light Switch=== Start
#define c32CryptoErase          c32Bit0
#define c32BlockErase           c32Bit1
#define c32Overwrite            c32Bit2

typedef struct _NVME2LS    // 0x1600~0x16FF
{
    BYTE uarNamespaceUUID[16];    // 0x00~0x0F
    LWORD u32SaniCap;    // 0x10~0x13
    LWORD u32Ps0EnLat;    // 0x14
    LWORD u32Ps0ExLat;    // 0x18
    LWORD u32Ps1EnLat;    // 0x1C
    LWORD u32Ps1ExLat;    // 0x20
    LWORD u32Ps2EnLat;    // 0x24
    LWORD u32Ps2ExLat;    // 0x28
    LWORD u32Ps3EnLat;    // 0x2C
    LWORD u32Ps3ExLat;    // 0x30
    WORD u16Ps0Mp;    // 0x34
    BYTE uPs0Mxps;    // 0x36
    BYTE uRsverd0;
    WORD u16Ps1Mp;    // 0x38
    BYTE uPs1Mxps;    // 0x3A
    BYTE uRsverd1;
    WORD u16Ps2Mp;    // 0x3C
    BYTE uPs2Mxps;    // 0x3E
    BYTE uRsverd2;
    WORD u16Ps3Mp;    // 0x40
    BYTE uPs3Mxps;    // 0x42
    BYTE uRsverd3;
    BYTE uarRsrvd4[12];
    WORD u16Ps0Idlp;    // 0x50
    BYTE uPs0Ips;    // 0x52
    BYTE uRsverd5;    //
    WORD u16Ps0Actp;    // 0x54
    BYTE uPs0ApwAps;    // 0x56
    BYTE uRsverd6;    // 0x57
    LWORD u32NamespaceNum;    // 0x58
    BYTE uarRsrvd7[164];
}NVME2LS;
// ====NVMe 2 Light Switch=== End

#define cLightSwitchTotalSize       0x1000
#define cLightSwitchCidHeaderSize   0x0180
#define cLightSwitchLegacySize      0x0080
#define cLightSwitchPcieSize        0x0040
#define cLightSwitchNvmeSize        0x0080
#define cLightSwitchPhySize         0x0040
#define cLightSwitchSecSize         0x0080
#define cLightSwitchGenSize         0x0080
#define cLightSwitchSmartSize       0x0080

// Temp
#define cLightSwitchOffset          0x1000
#define cLightSwitchCidHeaderOffset 0x0000
#define cLightSwitchLegacyOffset    0x0180
#define cLightSwitchPcieOffset      0x0200
#define cLightSwitchNvmeOffset      0x0240
#define cLightSwitchPhyOffset       0x02C0
#define cLightSwitchSecOffset       0x0300
#define cLightSwitchGenOffset       0x0380
#define cLightSwitchSmartOffset     0x0400

// LigthSwitch location at DTCM 0x23800
typedef struct _LIGHTSWITCH
{
    CIDLS usCidHeader;    // 0x000~0x17F
    LEGACYLS usLegacy;    // 0x180~0x1FF, 2263xt not use
    PCIELS usPcieLs;    // 0x200~0x23F
    NVMELS usNvmeLs;    // 0x240~0x2BF
    PHYLS usPhyLs;    // 0x2C0~0x2FF
    SECLS usSecLs;    // 0x300~0x37F
    GENLS usGenLs;    // 0x380~0x38F
    THERMALLS usThermalLs;    // 0x390~0x3DF
    ALGOLS usAlgoLs;    // 0x3E0~0x3FF
    SMARTLS usSmartLs;    // 0x400~0x47F
    SELFTESTLS usSelfTestLs;    // 0x480~0x4BF
    VUIDLS usVuIdLs;    // 0x4C0~0x4FF
    VDTLS usVdtLs;    // 0x500~0x50F
    OEM3LS usOem3Ls;    // 0x510~0x5FF
    NVME2LS usNvme2Ls;    // 0x600~0x6FF
    BYTE uarRsrvd[0x600];    // 0x700~0xCFF
    BYTE uarHashOffSetTable[256];    // 0xD00~0xDFF
    BYTE uarRdtOpt[256];    // 0xE00~0xFFF
}LIGHTSWITCH;

#pragma pack()







