







#ifndef __FTLCTRL_H__
#define __FTLCTRL_H__

#include "inc/Const.h"
#include "inc/Option.h"
#include "inc/Table.h"

extern const WORD g16FakeCmdTyp[];
extern const LWORD g32FakeCmdLba[];
extern const LWORD g32FakeCmdLen[];

#endif







