







/*  Parameter  */
#define cAes128                                 128
#define cAes192                                 192
#define cAes256                                 256

#define cBsAesEcb                               0x1
#define cBsAesCbc                               0x2
#define cBsAesXts                               0x3

#define cAesEncryption                          0x00
#define cAesDecryption                          0x01

#define cAesBlockLength                         16

#define cRootKeyLabelSize                       7
#define cIcvSize                                8
#define cRootKeyContextSize                     16
#define cPasswordSize                           32
#define cKekSize                                32
#define cRootKeySize                            32
#define cSaltSize                               32
#define cSp800_38fEncryptedSize                 40
#define cMekSize                                64
#define cSp800_38fEncryptedMekSize              72

#define cRandomKey                              0x00
#define cPtrInputKey                            0x01

#define cTcgMaxRange                            0x08

#define cHmacOutputLegnth                       32

#define cDmaLocal2Tsb                           0xAA

/*  C_WPRO_SECURITY_ID  */
#define cEncryptedRootKeyPtr                     0x20
#define cEncryptedOriginalKekPtr                (cEncryptedRootKeyPtr+cSp800_38fEncryptedSize)
#define cEncryptedMekPtr                        (cEncryptedOriginalKekPtr+cSp800_38fEncryptedSize)

/*  Status code  */
#define cAesSuccess                             0
#define cAesFailure                             1

#define cKeyHierarchySuccess                    0
#define cKeyHierarchyFail                       1

// ===================================================================================//
//////=====================//////
//////===== FW AES Register 0x5100_5000=====//////
//////=====================//////
#define rcFwAesThrough                           0x03
#define rmFwAesMode                              (rFwAes[rcFwAesThrough]=0x00)
#define rmFwAesNormalMode                        (rFwAes[rcFwAesThrough]=0x01)
#define rmChkAesOnFw                             (!(rFwAes[rcFwAesThrough]&cBit0))

#define rcFwAesReset                             0x07
#define rmAesResetFw                             (rFwAes[rcFwAesReset]=0x80)

#define rcFwAesDir                               0x0B
#define rmAesEncodeFw                            (rFwAes[rcFwAesDir]=0x00)    // Encryption
#define rmAesDecodeFw                            (rFwAes[rcFwAesDir]=0x01)    // Decryption

#define rcFwAesKeyLength                         0x0F
#define rmAesKey128bFw                           (rFwAes[rcFwAesKeyLength]=0x00)
#define rmAesKey192bFw                           (rFwAes[rcFwAesKeyLength]=0x01)
#define rmAesKey256bFw                           (rFwAes[rcFwAesKeyLength]=0x02)

#define rcFwAesCurLba                            0x10

#define rcFwAesSetLba                            0x18
#define rmAesSetLbaFw(lba)                       (r32FwAes[rcFwAesSetLba/4]=lba)
#define rmAesSetLbaExtFw(lba)                    (r32FwAes[rcFwAesSetLba/4+1]=lba)

#define rcFwAesLbaPad1                           0x24
#define rcFwAesLbaPad2                           0x28
#define rcFwAesLbaPad3                           0x2C

#define rcFwAesPEn                               0x30
#define rmEnAesPartitionAllFw                    (rFwAes[rcFwAesPEn]=0xFF)

#define rcFwAesFwCtrl                            0x3C
#define rmAesFwResetFw                           (r32FwAes[rcFwAesFwCtrl/4]=0x00000080)
#define rmAesXtsStartFw                          (r32FwAes[rcFwAesFwCtrl/4]=0x00000002)
#define rmAesEcbStartFw                          (r32FwAes[rcFwAesFwCtrl/4]=0x00000001)
#define rmAesBusyFw                              (r32FwAes[rcFwAesFwCtrl/4]&c32Bit24)

#define rcFwAesFwData0                           0x40
#define rmAesData0Fw                             r32FwAes[rcFwAesFwData0/4]

#define rcFwAesFwData1                           0x44
#define rmAesData1Fw                             r32FwAes[rcFwAesFwData1/4]

#define rcFwAesFwData2                           0x48
#define rmAesData2Fw                             r32FwAes[rcFwAesFwData2/4]

#define rcFwAesFwData3                           0x4C
#define rmAesData3Fw                             r32FwAes[rcFwAesFwData3/4]
#define rmAesDataFw(i)                           r32FwAes[(rcFwAesFwData3/4)+i]
// ---

// == FW Manual AES ===//      //Note: 32-bit Access Only
#define rcFwAesManualCtrl                        0x50
// Enable FW Aes manual mode, and wait for Aes engine ready (may BOP/HDMA using)
#define rmEnManualAesFw\
    {r32FwAes[rcFwAesManualCtrl/4]=0x00000080;\
     while(!(r32FwAes[rcFwAesManualCtrl/4]&c32Bit8))\
         ;\
    }
#define rmDisManualAesFw\
    {r32FwAes[rcFwAesManualCtrl/4]=0x00000000;\
     while(r32FwAes[rcFwAesManualCtrl/4]&c32Bit8)\
         ;\
    }
#define rmFwAesEcb                               (r32FwAes[rcFwAesManualCtrl/4]=((r32FwAes[rcFwAesManualCtrl/4]&c32Bit7)|c32Bit1))
#define rmFwAesCbc                               (r32FwAes[rcFwAesManualCtrl/4]=((r32FwAes[rcFwAesManualCtrl/4]&c32Bit7)|c32Bit2))
#define rmFwAesXts                               (r32FwAes[rcFwAesManualCtrl/4]=((r32FwAes[rcFwAesManualCtrl/4]&c32Bit7)|c32Bit3))
#define rmFwAesFxts                              (r32FwAes[rcFwAesManualCtrl/4]=((r32FwAes[rcFwAesManualCtrl/4]&c32Bit7)|c32Bit3|c32Bit5))
// Mode
#define cFwEcb                                   0x00000002
#define cFwCbc                                   0x00000004
#define cFwXts                                   0x00000008
#define cFwFxts                                  0x00000028

#define rcFwAesCbciv0                            0x54
#define rmSetFwCbciv0(x)                         (r32FwAes[rcFwAesCbciv0/4]=x)

#define rcFwAesCbciv1                            0x58
#define rmSetFwCbciv1(x)                         (r32FwAes[rcFwAesCbciv1/4]=x)

#define rcFwAesCbciv2                            0x5C
#define rmSetFwCbciv2(x)                         (r32FwAes[rcFwAesCbciv2/4]=x)

#define rcFwAesCbciv3                            0x60
#define rmSetFwCbciv3(x)                         (r32FwAes[rcFwAesCbciv3/4]=x)
#define rmSetFwCbciv(i)                          r32FwAes[(rcFwAesCbciv3/4)+i]

// HW AES Register Address 0x5100_1800
#define cDfKeySel                                0
#define cFwKeySel                                1
#define cP0KeySel                                4
#define cP1KeySel                                5
#define cP2KeySel                                6
#define cP3KeySel                                7
#define cP4KeySel                                8
#define cP5KeySel                                9
#define cP6KeySel                                10
#define cP7KeySel                                11

#define rcAesThrough                             0x03
#define rmAesMode                                (rAesCtrl[rcAesThrough]=0x00)
#define rmAesNormalMode                          (rAesCtrl[rcAesThrough]=0x01)
#define rmChkAesOn                               ((rAesCtrl[rcAesThrough]&cBit0)==0)

#define rcAesReset                               0x07
#define rmAesReset                               (rAesCtrl[rcAesReset]=0x80)

#define rcAesDir                                 0x0B
#define rmAesWrite                               (rAesCtrl[rcAesDir]=0x00)    // Encryption
#define rmAesRead                                (rAesCtrl[rcAesDir]=0x01)    // Decryption

#define rcAesKeyLength                           0x0F
#define rmAesKey128b                             (rAesCtrl[rcAesKeyLength]=0x00)
#define rmAesKey192b                             (rAesCtrl[rcAesKeyLength]=0x01)
#define rmAesKey256b                             (rAesCtrl[rcAesKeyLength]=0x02)

#define rcAesCurLba                              0x10

#define rcAesSetLba                              0x18
#define rmAesSetLba(lba)                         (r32AesCtrl[rcAesSetLba/4]=lba)
#define rmAesSetLbaExt(lba)                      (r32AesCtrl[rcAesSetLba/4+1]=lba)

#define rcAesLbaPad1                             0x24
#define rcAesLbaPad2                             0x28
#define rcAesLbaPad3                             0x2C

#define rcAesPEn                                 0x30
#define rmAesPEnAll                              (r16AesCtrl[rcAesPEn/2]=0xFFFF)
#define rmAesPDisAll                             r16AesCtrl[rcAesPEn/2]=0
#define rmAesPEnRange1                           r16AesCtrl[rcAesPEn/2]|=cBit0
#define rmAesPEnRange2                           r16AesCtrl[rcAesPEn/2]|=cBit1
#define rmAesPEnRange3                           r16AesCtrl[rcAesPEn/2]|=cBit2
#define rmAesPEnRange4                           r16AesCtrl[rcAesPEn/2]|=cBit3
#define rmAesPEnRange5                           r16AesCtrl[rcAesPEn/2]|=cBit4
#define rmAesPEnRange6                           r16AesCtrl[rcAesPEn/2]|=cBit5
#define rmAesPEnRange7                           r16AesCtrl[rcAesPEn/2]|=cBit6
#define rmAesPEnRange8                           r16AesCtrl[rcAesPEn/2]|=cBit7

#define rcAesFwCtrl                              0x3C
#define rmAesFwReset                             (r32AesCtrl[rcAesFwCtrl/4]=0x00000080)
#define rmAesXtsStart                            (r32AesCtrl[rcAesFwCtrl/4]=0x00000002)

#define cAesXts                                  0x00000002

#define rmAesEcbStart                            (r32AesCtrl[rcAesFwCtrl/4]=0x00000001)

#define cAesEcb                                  0x00000001

#define rmAesBusy                                (r32AesCtrl[rcAesFwCtrl/4]&c32Bit24)

#define rcAesFwData0                             0x40
#define rcAesFwData1                             0x44
#define rcAesFwData2                             0x48
#define rcAesFwData3                             0x4C
#define rmAesFwData(i)                           r32AesCtrl[(rcAesFwData0/4)+i]

#define rcAesFwP0LbaStart                        0x80
#define rcAesFwP0LbaEnd                          0x88
#define rcAesFwP1LbaStart                        0x90
#define rcAesFwP1LbaEnd                          0x98
#define rcAesFwP2LbaStart                        0xA0
#define rcAesFwP2LbaEnd                          0xA8
#define rcAesFwP3LbaStart                        0xB0
#define rcAesFwP3LbaEnd                          0xB8
#define rcAesFwP4LbaStart                        0xC0
#define rcAesFwP4LbaEnd                          0xC8
#define rcAesFwP5LbaStart                        0xD0
#define rcAesFwP5LbaEnd                          0xD8
#define rcAesFwP6LbaStart                        0xE0
#define rcAesFwP6LbaEnd                          0xE8
#define rcAesFwP7LbaStart                        0xF0
#define rcAesFwP7LbaEnd                          0xF8
// ========2262 add===========
#define rcAesFwP8LbaStart                        0x600
#define rcAesFwP8LbaEnd                          0x608
#define rcAesFwP9LbaStart                        0x610
#define rcAesFwP9LbaEnd                          0x618
#define rcAesFwP10LbaStart                       0x620
#define rcAesFwP10LbaEnd                         0x628
#define rcAesFwP11LbaStart                       0x630
#define rcAesFwP11LbaEnd                         0x638
#define rcAesFwP12LbaStart                       0x640
#define rcAesFwP12LbaEnd                         0x648
#define rcAesFwP13LbaStart                       0x650
#define rcAesFwP13LbaEnd                         0x658
#define rcAesFwP14LbaStart                       0x660
#define rcAesFwP14LbaEnd                         0x668
#define rcAesFwP15LbaStart                       0x670
#define rcAesFwP15LbaEnd                         0x678

#define rcAesDefaultKey00                        0x100
#define rcAesDefaultKey01                        0x104
#define rcAesDefaultKey02                        0x108
#define rcAesDefaultKey03                        0x10C
#define rcAesDefaultKey04                        0x110
#define rcAesDefaultKey05                        0x114
#define rcAesDefaultKey06                        0x118
#define rcAesDefaultKey07                        0x11C
#define rcAesDefaultKey10                        0x120
#define rcAesDefaultKey11                        0x124
#define rcAesDefaultKey12                        0x128
#define rcAesDefaultKey13                        0x12C
#define rcAesDefaultKey14                        0x130
#define rcAesDefaultKey15                        0x134
#define rcAesDefaultKey16                        0x138
#define rcAesDefaultKey17                        0x13C

#define rcAesFwKey00                             0x140
#define rcAesFwKey01                             0x144
#define rcAesFwKey02                             0x148
#define rcAesFwKey03                             0x14C
#define rcAesFwKey04                             0x150
#define rcAesFwKey05                             0x154
#define rcAesFwKey06                             0x158
#define rcAesFwKey07                             0x15C
#define rcAesFwKey10                             0x160
#define rcAesFwKey11                             0x164
#define rcAesFwKey12                             0x168
#define rcAesFwKey13                             0x16C
#define rcAesFwKey14                             0x170
#define rcAesFwKey15                             0x174
#define rcAesFwKey16                             0x178
#define rcAesFwKey17                             0x17C

#define rcAesP0Key00                             0x200
#define rcAesP0Key01                             0x204
#define rcAesP0Key02                             0x208
#define rcAesP0Key03                             0x20C
#define rcAesP0Key04                             0x210
#define rcAesP0Key05                             0x214
#define rcAesP0Key06                             0x218
#define rcAesP0Key07                             0x21C
#define rcAesP0Key10                             0x220
#define rcAesP0Key11                             0x224
#define rcAesP0Key12                             0x228
#define rcAesP0Key13                             0x22C
#define rcAesP0Key14                             0x230
#define rcAesP0Key15                             0x234
#define rcAesP0Key16                             0x238
#define rcAesP0Key17                             0x23C

#define rcAesP1Key00                             0x240
#define rcAesP1Key01                             0x244
#define rcAesP1Key02                             0x248
#define rcAesP1Key03                             0x24C
#define rcAesP1Key04                             0x250
#define rcAesP1Key05                             0x254
#define rcAesP1Key06                             0x258
#define rcAesP1Key07                             0x25C
#define rcAesP1Key10                             0x260
#define rcAesP1Key11                             0x264
#define rcAesP1Key12                             0x268
#define rcAesP1Key13                             0x26C
#define rcAesP1Key14                             0x270
#define rcAesP1Key15                             0x274
#define rcAesP1Key16                             0x278
#define rcAesP1Key17                             0x27C

#define rcAesP2Key00                             0x280
#define rcAesP2Key01                             0x284
#define rcAesP2Key02                             0x288
#define rcAesP2Key03                             0x28C
#define rcAesP2Key04                             0x290
#define rcAesP2Key05                             0x294
#define rcAesP2Key06                             0x298
#define rcAesP2Key07                             0x29C
#define rcAesP2Key10                             0x2A0
#define rcAesP2Key11                             0x2A4
#define rcAesP2Key12                             0x2A8
#define rcAesP2Key13                             0x2AC
#define rcAesP2Key14                             0x2B0
#define rcAesP2Key15                             0x2B4
#define rcAesP2Key16                             0x2B8
#define rcAesP2Key17                             0x2BC

#define rcAesP3Key00                             0x2C0
#define rcAesP3Key01                             0x2C4
#define rcAesP3Key02                             0x2C8
#define rcAesP3Key03                             0x2CC
#define rcAesP3Key04                             0x2D0
#define rcAesP3Key05                             0x2D4
#define rcAesP3Key06                             0x2D8
#define rcAesP3Key07                             0x2DC
#define rcAesP3Key10                             0x2E0
#define rcAesP3Key11                             0x2E4
#define rcAesP3Key12                             0x2E8
#define rcAesP3Key13                             0x2EC
#define rcAesP3Key14                             0x2F0
#define rcAesP3Key15                             0x2F4
#define rcAesP3Key16                             0x2F8
#define rcAesP3Key17                             0x2FC

#define rcAesP4Key00                             0x300
#define rcAesP4Key01                             0x304
#define rcAesP4Key02                             0x308
#define rcAesP4Key03                             0x30C
#define rcAesP4Key04                             0x310
#define rcAesP4Key05                             0x314
#define rcAesP4Key06                             0x318
#define rcAesP4Key07                             0x31C
#define rcAesP4Key10                             0x320
#define rcAesP4Key11                             0x324
#define rcAesP4Key12                             0x328
#define rcAesP4Key13                             0x32C
#define rcAesP4Key14                             0x330
#define rcAesP4Key15                             0x334
#define rcAesP4Key16                             0x338
#define rcAesP4Key17                             0x33C

#define rcAesP5Key00                             0x340
#define rcAesP5Key01                             0x344
#define rcAesP5Key02                             0x348
#define rcAesP5Key03                             0x34C
#define rcAesP5Key04                             0x350
#define rcAesP5Key05                             0x354
#define rcAesP5Key06                             0x358
#define rcAesP5Key07                             0x35C
#define rcAesP5Key10                             0x360
#define rcAesP5Key11                             0x364
#define rcAesP5Key12                             0x368
#define rcAesP5Key13                             0x36C
#define rcAesP5Key14                             0x370
#define rcAesP5Key15                             0x374
#define rcAesP5Key16                             0x378
#define rcAesP5Key17                             0x37C

#define rcAesP6Key00                             0x380
#define rcAesP6Key01                             0x384
#define rcAesP6Key02                             0x388
#define rcAesP6Key03                             0x38C
#define rcAesP6Key04                             0x390
#define rcAesP6Key05                             0x394
#define rcAesP6Key06                             0x398
#define rcAesP6Key07                             0x39C
#define rcAesP6Key10                             0x3A0
#define rcAesP6Key11                             0x3A4
#define rcAesP6Key12                             0x3A8
#define rcAesP6Key13                             0x3AC
#define rcAesP6Key14                             0x3B0
#define rcAesP6Key15                             0x3B4
#define rcAesP6Key16                             0x3B8
#define rcAesP6Key17                             0x3BC

#define rcAesP7Key00                             0x3C0
#define rcAesP7Key01                             0x3C4
#define rcAesP7Key02                             0x3C8
#define rcAesP7Key03                             0x3CC
#define rcAesP7Key04                             0x3D0
#define rcAesP7Key05                             0x3D4
#define rcAesP7Key06                             0x3D8
#define rcAesP7Key07                             0x3DC
#define rcAesP7Key10                             0x3E0
#define rcAesP7Key11                             0x3E4
#define rcAesP7Key12                             0x3E8
#define rcAesP7Key13                             0x3EC
#define rcAesP7Key14                             0x3F0
#define rcAesP7Key15                             0x3F4
#define rcAesP7Key16                             0x3F8
#define rcAesP7Key17                             0x3FC

// ========2262 add===============
#define O8_AES_P8_Key0_0                0x400
#define O32_AES_P8_Key0_0               0x400/4
#define O32_AES_P8_Key0_1               0x404/4
#define O32_AES_P8_Key0_2               0x408/4
#define O32_AES_P8_Key0_3               0x40C/4
#define O32_AES_P8_Key0_4               0x410/4
#define O32_AES_P8_Key0_5               0x414/4
#define O32_AES_P8_Key0_6               0x418/4
#define O32_AES_P8_Key0_7               0x41C/4
#define O8_AES_P8_Key1_0                0x420
#define O32_AES_P8_Key1_0               0x420/4
#define O32_AES_P8_Key1_1               0x424/4
#define O32_AES_P8_Key1_2               0x428/4
#define O32_AES_P8_Key1_3               0x42C/4
#define O32_AES_P8_Key1_4               0x430/4
#define O32_AES_P8_Key1_5               0x434/4
#define O32_AES_P8_Key1_6               0x438/4
#define O32_AES_P8_Key1_7               0x43C/4

#define O8_AES_P9_Key0_0                0x440
#define O32_AES_P9_Key0_0               0x440/4
#define O32_AES_P9_Key0_1               0x444/4
#define O32_AES_P9_Key0_2               0x448/4
#define O32_AES_P9_Key0_3               0x44C/4
#define O32_AES_P9_Key0_4               0x450/4
#define O32_AES_P9_Key0_5               0x454/4
#define O32_AES_P9_Key0_6               0x458/4
#define O32_AES_P9_Key0_7               0x45C/4
#define O8_AES_P9_Key1_0                0x460
#define O32_AES_P9_Key1_0               0x460/4
#define O32_AES_P9_Key1_1               0x464/4
#define O32_AES_P9_Key1_2               0x468/4
#define O32_AES_P9_Key1_3               0x46C/4
#define O32_AES_P9_Key1_4               0x470/4
#define O32_AES_P9_Key1_5               0x474/4
#define O32_AES_P9_Key1_6               0x478/4
#define O32_AES_P9_Key1_7               0x47C/4

#define O8_AES_P10_Key0_0               0x480
#define O32_AES_P10_Key0_0              0x480/4
#define O32_AES_P10_Key0_1              0x484/4
#define O32_AES_P10_Key0_2              0x488/4
#define O32_AES_P10_Key0_3              0x48C/4
#define O32_AES_P10_Key0_4              0x490/4
#define O32_AES_P10_Key0_5              0x494/4
#define O32_AES_P10_Key0_6              0x498/4
#define O32_AES_P10_Key0_7              0x49C/4
#define O8_AES_P10_Key1_0               0x4A0
#define O32_AES_P10_Key1_0              0x4A0/4
#define O32_AES_P10_Key1_1              0x4A4/4
#define O32_AES_P10_Key1_2              0x4A8/4
#define O32_AES_P10_Key1_3              0x4AC/4
#define O32_AES_P10_Key1_4              0x4B0/4
#define O32_AES_P10_Key1_5              0x4B4/4
#define O32_AES_P10_Key1_6              0x4B8/4
#define O32_AES_P10_Key1_7              0x4BC/4

#define O8_AES_P11_Key0_0               0x4C0
#define O32_AES_P11_Key0_0              0x4C0/4
#define O32_AES_P11_Key0_1              0x4C4/4
#define O32_AES_P11_Key0_2              0x4C8/4
#define O32_AES_P11_Key0_3              0x4CC/4
#define O32_AES_P11_Key0_4              0x4D0/4
#define O32_AES_P11_Key0_5              0x4D4/4
#define O32_AES_P11_Key0_6              0x4D8/4
#define O32_AES_P11_Key0_7              0x4DC/4
#define O8_AES_P11_Key1_0               0x4E0
#define O32_AES_P11_Key1_0              0x4E0/4
#define O32_AES_P11_Key1_1              0x4E4/4
#define O32_AES_P11_Key1_2              0x4E8/4
#define O32_AES_P11_Key1_3              0x4EC/4
#define O32_AES_P11_Key1_4              0x4F0/4
#define O32_AES_P11_Key1_5              0x4F4/4
#define O32_AES_P11_Key1_6              0x4F8/4
#define O32_AES_P11_Key1_7              0x4FC/4

#define O8_AES_P12_Key0_0               0x500
#define O32_AES_P12_Key0_0              0x500/4
#define O32_AES_P12_Key0_1              0x504/4
#define O32_AES_P12_Key0_2              0x508/4
#define O32_AES_P12_Key0_3              0x50C/4
#define O32_AES_P12_Key0_4              0x510/4
#define O32_AES_P12_Key0_5              0x514/4
#define O32_AES_P12_Key0_6              0x518/4
#define O32_AES_P12_Key0_7              0x51C/4
#define O8_AES_P12_Key1_0               0x520
#define O32_AES_P12_Key1_0              0x520/4
#define O32_AES_P12_Key1_1              0x524/4
#define O32_AES_P12_Key1_2              0x528/4
#define O32_AES_P12_Key1_3              0x52C/4
#define O32_AES_P12_Key1_4              0x530/4
#define O32_AES_P12_Key1_5              0x534/4
#define O32_AES_P12_Key1_6              0x538/4
#define O32_AES_P12_Key1_7              0x53C/4

#define O8_AES_P13_Key0_0               0x540
#define O32_AES_P13_Key0_0              0x540/4
#define O32_AES_P13_Key0_1              0x544/4
#define O32_AES_P13_Key0_2              0x548/4
#define O32_AES_P13_Key0_3              0x54C/4
#define O32_AES_P13_Key0_4              0x550/4
#define O32_AES_P13_Key0_5              0x554/4
#define O32_AES_P13_Key0_6              0x558/4
#define O32_AES_P13_Key0_7              0x55C/4
#define O8_AES_P13_Key1_0               0x560
#define O32_AES_P13_Key1_0              0x560/4
#define O32_AES_P13_Key1_1              0x564/4
#define O32_AES_P13_Key1_2              0x568/4
#define O32_AES_P13_Key1_3              0x56C/4
#define O32_AES_P13_Key1_4              0x570/4
#define O32_AES_P13_Key1_5              0x574/4
#define O32_AES_P13_Key1_6              0x578/4
#define O32_AES_P13_Key1_7              0x57C/4

#define O8_AES_P14_Key0_0               0x580
#define O32_AES_P14_Key0_0              0x580/4
#define O32_AES_P14_Key0_1              0x584/4
#define O32_AES_P14_Key0_2              0x588/4
#define O32_AES_P14_Key0_3              0x58C/4
#define O32_AES_P14_Key0_4              0x590/4
#define O32_AES_P14_Key0_5              0x594/4
#define O32_AES_P14_Key0_6              0x598/4
#define O32_AES_P14_Key0_7              0x59C/4
#define O8_AES_P14_Key1_0               0x5A0
#define O32_AES_P14_Key1_0              0x5A0/4
#define O32_AES_P14_Key1_1              0x5A4/4
#define O32_AES_P14_Key1_2              0x5A8/4
#define O32_AES_P14_Key1_3              0x5AC/4
#define O32_AES_P14_Key1_4              0x5B0/4
#define O32_AES_P14_Key1_5              0x5B4/4
#define O32_AES_P14_Key1_6              0x5B8/4
#define O32_AES_P14_Key1_7              0x5BC/4

#define O8_AES_P15_Key0_0               0x5C0
#define O32_AES_P15_Key0_0              0x5C0/4
#define O32_AES_P15_Key0_1              0x5C4/4
#define O32_AES_P15_Key0_2              0x5C8/4
#define O32_AES_P15_Key0_3              0x5CC/4
#define O32_AES_P15_Key0_4              0x5D0/4
#define O32_AES_P15_Key0_5              0x5D4/4
#define O32_AES_P15_Key0_6              0x5D8/4
#define O32_AES_P15_Key0_7              0x5DC/4
#define O8_AES_P15_Key1_0               0x5E0
#define O32_AES_P15_Key1_0              0x5E0/4
#define O32_AES_P15_Key1_1              0x5E4/4
#define O32_AES_P15_Key1_2              0x5E8/4
#define O32_AES_P15_Key1_3              0x5EC/4
#define O32_AES_P15_Key1_4              0x5F0/4
#define O32_AES_P15_Key1_5              0x5F4/4
#define O32_AES_P15_Key1_6              0x5F8/4
#define O32_AES_P15_Key1_7              0x5FC/4







