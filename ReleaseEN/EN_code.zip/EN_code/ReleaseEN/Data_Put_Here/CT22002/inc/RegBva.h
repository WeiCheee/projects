







#ifndef __REG_BVA_H__
#define __REG_BVA_H__

// BVAC (Dram CPU Arbitator)   @0x5080_0400
#define  rcBvacTmCtl                             0x00
#define  rcBvacCtl1                              0x02

#define  rcSpiCtl                                0x04
#define  rmChkSpiBusy                            (r32BvacCtrl[rcSpiCtl/4]&c32Bit8)    // avoid HW optimize need to use 32bit access

#define  rmSpiClkDiv2                            (rBvacCtrl[rcSpiCtl]=0)
#define  rmSpiClkDiv4                            (rBvacCtrl[rcSpiCtl]=1)
#define  rmSpiClkDiv6                            (rBvacCtrl[rcSpiCtl]=2)
#define  rmSpiClkDiv8                            (rBvacCtrl[rcSpiCtl]=3)
#define  rmSpiClkDiv10                           (rBvacCtrl[rcSpiCtl]=4)
#define  rmSpiClkDiv12                           (rBvacCtrl[rcSpiCtl]=5)
#define  rmSpiClkDiv14                           (rBvacCtrl[rcSpiCtl]=6)
#define  rmSpiClkDiv16                           (rBvacCtrl[rcSpiCtl]=7)

#define  rcSpiCtl1                               0x05
#define  rmSpiEn                                 (rBvacCtrl[rcSpiCtl1]&=(~cBit4))
#define  rmSpiDis                                (rBvacCtrl[rcSpiCtl1]|=cBit4)

#define  rcSpiOutBuf                             0x06
#define  rmSpiWrite(x)\
    {rBvacCtrl[rcSpiOutBuf]=x;\
     while(rmChkSpiBusy)\
         ;\
    }

#define  rcSpiInData                             0x07
#define  rmSpiRead(x)\
    {rBvacCtrl[rcSpiInData]=x;\
     while(rmChkSpiBusy)\
         ;\
    }

// BVA CPU Error handle
#define rcBvacmsel                               0x8c
#define rcBvacErrFlag                            0x8e
#define rcBvacDebugPlen                          0x90
#define rcBvacErrTimerIntVal                     0x92
#define rcBvacDebugAddress                       0x94
#define rmChkBvaCpuErr                           (rBvacCtrl[rcBvacErrFlag]!=0x00)
#define rmClrBvaCpuErr                           (rBvacCtrl[rcBvacErrFlag]|=cBit7)
#define rmGetBvaCpuErrBitMap                     (rBvacCtrl[rcBvacErrFlag])
#define rmChkBvaCpuAxwm0Err                      (rBvacCtrl[rcBvacErrFlag]&cBit3)
#define rmSetBvacpuMsel(x)                       (rBvacCtrl[rcBvacmsel]=x)
#define rmSetBvaCpuErrTimerIntVal(x)             (r16BvacCtrl[rcBvacErrTimerIntVal/2]=x)
#define rmGetBvaCpuDebugAddress                  (r32BvacCtrl[rcBvacDebugAddress/4])
#define rmGetBvaCpuDebugPlen                     (r16BvacCtrl[rcBvacDebugPlen/2])

// BVAD (Dram DMA Arbitator)   @0x5100_0400
#define  rcBvadTmCtl                             0x00
#define  rcBvadCtl1                              0x02

#define  rcBvfCtl                                0x80
#define  rcBvfCtl1                               0x81
#define  rmEnPcieRdRefBvfOcu                     (rBvaCtrl[rcBvfCtl]|=cBit4)
#define  rmDisPcieRdRefBvfOcu                    (rBvaCtrl[rcBvfCtl]&=(~cBit4))
#define  rmEnPcieRdRefBvfBuf                     (rBvaCtrl[rcBvfCtl]|=cBit3)
#define  rmDisPcieRdRefBvfBuf                    (rBvaCtrl[rcBvfCtl]&=(~cBit3))
#define  rmEnHdmaRefBvfBuf                       (rBvaCtrl[rcBvfCtl]|=cBit2)
#define  rmDisHdmaRefBvfBuf                      (rBvaCtrl[rcBvfCtl]&=(~cBit2))
#define  rmEnPcieWrRefBvfOcu                     (rBvaCtrl[rcBvfCtl]|=cBit1)
#define  rmDisPcieWrRefBVFOcu                    (rBvaCtrl[rcBvfCtl]&=(~cBit1))
#define  rmEnPcieWrRefBvfBuf                     (rBvaCtrl[rcBvfCtl]|=cBit0)
#define  rmDisPcieWrRefBvfBuf                    (rBvaCtrl[rcBvfCtl]&=(~cBit0))

#define  rcBvfStartaddr                          0x84
#define  rcBvfEndaddr                            0x88

#define  rmSetBvfStartAddr(x)                    (r16BvaCtrl[rcBvfStartaddr/2]=x)
#define  rmSetBvfEndAddr(x)                      // (r16BvacCtrl[rcBvfEndaddr/2]=x)

// BVCI Arbitrator setting
#define rcWtCntIntVal                            0x88
#define rcRdCntIntVal                            0x89
#define rcTimeoutRdCntIntVal                     0x8A
#define rcTimeoutWtCntIntVal                     0x8B
#define rcRdMeetIntVal                           0x8D

#define rmSetWtCntIntVal(x)                      (rBvaCtrl[rcWtCntIntVal]=0x0F&x)
#define rmSetRdCntIntVal(x)                      (rBvaCtrl[rcRdCntIntVal]=0x0F&x)
#define rmSetTimeoutRdCntIntVal(x)               (rBvaCtrl[rcTimeoutRdCntIntVal]=x)
#define rmSetTimeoutWtCntIntVal(x)               (rBvaCtrl[rcTimeoutWtCntIntVal]=x)
#define rmSetRdMeetIntVal(x)                     (rBvaCtrl[rcRdMeetIntVal]=x)

// BVA DMA Error handle
#define rcBvadmsel                               0x8C
#define rcBvadErrFlag                            0x8E
#define rcBvadDebugPlen                          0x90
#define rcBvadErrTimerIntVal                     0x92
#define rcBvadDebugAddress                       0x94

#define rmChkBvaDmaErr                           (rBvaCtrl[rcBvadErrFlag]!=0x00)
#define rmClrBvaDmaErr                           (rBvaCtrl[rcBvadErrFlag]|=cBit7)
#define rmGetBvaDmaErrBitMap                     (rBvaCtrl[rcBvadErrFlag])
#define rmChkBvaDmaHdaErr                        (rBvaCtrl[rcBvadErrFlag]&cBit1)
#define rmSetBvaDmaMsel(x)                       (rBvaCtrl[rcBvadmsel]=x)
#define rmSetBvaDmaErrTimerIntVal(x)             (r16BvaCtrl[rcBvadErrTimerIntVal/2]=x)
#define rmGetBvaDmaDebugAddress                  (r32BvaCtrl[rcBvadDebugAddress/4])
#define rmGetBvaDmaDebugPlen                     (r16BvaCtrl[rcBvadDebugPlen/2])

#endif    // ifndef __REG_BVA_H__







