







#ifndef __DEBUGLOG_H__
#define __DEBUGLOG_H__

#include "inc/Option.h"

#define SMILOG_TAG2(fileNumber, line)   (NLOG_##fileNumber##_##line)
#define SMILOG_TAG(fileNumber, line)    SMILOG_TAG2(fileNumber, line)

#define SMILOG_MSGID(tag)       ((tag)&0xff)

#if _DEBUG_LOG
#define NLOG(func_type, src_file, cnt, str, ...)\
    debugLog(func_type, SMILOG_MSGID(SMILOG_TAG(src_file, __LINE__)), cnt,##__VA_ARGS__)

#define NLOG_SAVE(func_type, src_file, cnt, saveid, str, ...)\
    debugLogSave(func_type, SMILOG_MSGID(SMILOG_TAG(src_file, __LINE__)), cnt, saveid,##__VA_ARGS__)

#define LLOG(func_type, src_file, cnt, str, ...)\
    debugLink(func_type, SMILOG_MSGID(SMILOG_TAG(src_file, __LINE__)), cnt,##__VA_ARGS__)

#define LLOG_SAVE(func_type, src_file, cnt, saveid, str, ...)\
    debugLinkSave(func_type, SMILOG_MSGID(SMILOG_TAG(src_file, __LINE__)), cnt, saveid,##__VA_ARGS__)
#else
#define NLOG(...)
#define NLOG_SAVE(...)
#define LLOG(...)
#define LLOG_SAVE(...)
#endif

#if _DEBUG_LOGEXPCIE
#define NLOG_PCIeErr(func_type, src_file, cnt, str, ...)\
    debugLog(func_type, SMILOG_MSGID(SMILOG_TAG(src_file, __LINE__)), cnt,##__VA_ARGS__)
#else
#define NLOG_PCIeErr(...)
#endif

#endif    // ifndef __DEBUGLOG_H__







