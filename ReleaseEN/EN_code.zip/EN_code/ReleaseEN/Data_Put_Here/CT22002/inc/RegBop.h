







#ifndef __REG_BOP_H__
#define __REG_BOP_H__

// #include "inc/GlobVar0.h"

// Nbs Control register  @ 0x5100_1400
#define rcNbsSrchTgt0L                          (0x00/4)
#define rcNbsSrchTgt0H                          (0x04/4)
#define rmSetNbsSrchTgt(x, y)                   (r32Nbs[rcNbsSrchTgt0L+(x<<1)]=(y))
#define rmGetNbsHitRgn(x)                       (BYTE)((r32Nbs[rcNbsSrchTgt0H+(x<<1)]>>16)&3)
#define rmGetNbsHitOfst(x)                      (WORD)(r32Nbs[rcNbsSrchTgt0H+(x<<1)])    // &c16BitFF)
#define rmClrNbsHitOfst(x)                      (WORD)(r32Nbs[rcNbsSrchTgt0H+(x<<1)]&0xFFFF0000)

#define rcNbsActBit                             (0x100/4)
#define rmSetNbsActBitVal(x)                    (r32Nbs[rcNbsActBit]=(x))
#define rmSetNbsActBit(x)                       (r32Nbs[rcNbsActBit]=cb32BitTab[x])

#define rcNbsEnBit                              (0x104/4)
#define rmSetNbsEnBit                           (r32Nbs[rcNbsEnBit]=c32BitFF)

#define rcNbsSrchRgnAddr0                       (0x10C/4)
#define rmSetSrchRgnAddr0(x)                    (r32Nbs[rcNbsSrchRgnAddr0]=x)
#define rcNbsSrchRgnLen0                        (0x110/4)
#define rmSetSrchRgnLen0(x)                     (r32Nbs[rcNbsSrchRgnLen0]=x)

#define rcNbsSrchRgnAddr1                       (0x114/4)
#define rcNbsSrchRgnLen1                        (0x118/4)
#define rcNbsSrchRgnAddr2                       (0x11C/4)
#define rcNbsSrchRgnLen2                        (0x120/4)
#define rcNbsMaskL                              (0x124/4)
#define rcNbsMaskH                              (0x128/4)
#define rmSetNbsMaskHiVal(x)                    (r32Nbs[rcNbsMaskH]=x)

#define rcNbsHitBit                             (0x130/4)
#define rmChkNbsHitBit(x)                       (r32Nbs[rcNbsHitBit]&cb32BitTab[x])

#define rcNbsSrchDir                            0x138
#define cSrchTsb                                0
#define cSrchDram                               2
#define cSrchCcm                                3
#define rmSetSrchDir(x, y, z)                   (rNbs[rcNbsSrchDir]=(x|(y<<2)|(z<<4)))

#define rcNbsSrchQue                            0x13C
#define rmPopNbsQue                             (rNbs[rcNbsSrchQue]|=cBit0)

#define rcNbsSrchRsl                            0x13D
#define rmChkNbsQueMt                           (rNbs[rcNbsSrchRsl]&cBit7)
#define rmGetNbsQueIdx                          (rNbs[rcNbsSrchRsl]&0x3F)

// BOP Control register  @ 0x5100_1C00

// BOP Trig
#define rcBopTrigOperation                      0x00
#define rmTrigBopOp(enpause, op)                (rBopCtrl[rcBopTrigOperation]=((enpause<<2)|op))
#define rmTrigBopCrcOp(enpause)                 (rBopCtrl[rcBopTrigOperation]=((enpause<<2)|cBopCrcOp))
#define rmTrigBopSrchOp(enpause)                (rBopCtrl[rcBopTrigOperation]=((enpause<<2)|cBopSrchOp))
#define rmTrigBopDmaOp(enpause)                 (rBopCtrl[rcBopTrigOperation]=((enpause<<2)|cBopDmaOp))
#define rmTrigBopOFlagOp(enpause)               (rBopCtrl[rcBopTrigOperation]=((enpause<<2)|cBopOFlagOp))
#define rmTrigBopOpWoPause(op)                  (rBopCtrl[rcBopTrigOperation]=op)
#define rmTrigBopRaidCmd(enpause)               (rBopCtrl[rcBopTrigOperation]=((enpause<<2)|cBopDmaOp|cBit5))    // For BOP RAID

// BOP Parameter
#define rcBopParr                               0x01
#define rmSetBopCcm                             (rBopCtrl[rcBopParr]|=cBit0)
#define rmSetBopDram                            (rBopCtrl[rcBopParr]&=(~cBit0))
#define rmSetBopScrbMo                          (rBopCtrl[rcBopParr]|=cBit1)
#define rmSetBopCompMo                          (rBopCtrl[rcBopParr]|=cBit2)
#define rmClrBopCompMo                          (rBopCtrl[rcBopParr]&=(~cBit2))
#define rmChkBopCompMo                          (rBopCtrl[rcBopParr]&cBit2)
#define rmSetBopFillMo                          (rBopCtrl[rcBopParr]|=cBit3)

#define rmSetBopTsb2Tsb                         (rBopCtrl[rcBopParr]&=0xCF)
#define rmSetBopTsb2Bvci                        (rBopCtrl[rcBopParr]=((rBopCtrl[rcBopParr]&(~cBit5))|cBit4))
#define rmSetBopBvci2Tsb                        (rBopCtrl[rcBopParr]=((rBopCtrl[rcBopParr]&(~cBit4))|cBit5))
#define rmSetBopBvci2Bvci                       (rBopCtrl[rcBopParr]|=(cBit5|cBit4))
#define rmSetBopDataDir(x)                      (rBopCtrl[rcBopParr]=(rBopCtrl[rcBopParr]&0xCF)|(x<<4))

#define rmBopBypassSrc                          (rBopCtrl[rcBopParr]|=cBit7)
#define rmBopBypassDes                          (rBopCtrl[rcBopParr]|=cBit6)
#define rmBopAutoFlagSrc                        (rBopCtrl[rcBopParr]&=(~cBit7))
#define rmBopAutoFlagDes                        (rBopCtrl[rcBopParr]&=(~cBit6))
#define rmRstBopParam                           {rBopCtrl[rcBopParr]=0xC0;rBopCtrl[rcEnBopInt]=0x80;}
#define rmRstBopwithCompMo                      (rBopCtrl[rcBopParr]=0xC4)

#define rcBopDmaLen                             0x04
#define rmSetBopXfrLen(Unit)                    (r32BopCtrl[rcBopDmaLen/4]=Unit)

#define rcBopDesAddr                            0x08
#define rmSetBopDesAddr(DesAddr)                (r32BopCtrl[rcBopDesAddr/4]=DesAddr)

#define rcBopSrcAddr                            0x0C
#define rmSetBopSrcAddr(SrcAddr)                (r32BopCtrl[rcBopSrcAddr/4]=SrcAddr)

// BOP Current Cmd Status
#define rcBopCmdFifoDpt                         0x20
#define rmChkBopCmdFifoFull                     (rBopCtrl[rcBopCmdFifoDpt]==0)
#define rmChkBopCmdFifoDpt                      rBopCtrl[rcBopCmdFifoDpt]
#define rmGetBopTrigCmdCnt                      (cMaxBopDepth-rBopCtrl[rcBopCmdFifoDpt])
#define rmChkBopBz                              (rBopCtrl[rcBopCmdFifoDpt]!=cMaxBopDepth)
#define rmChkBopDone\
    while(rBopCtrl[rcBopCmdFifoDpt]!=cMaxBopDepth)
#define rmChkBopFree\
    while(!rBopCtrl[rcBopCmdFifoDpt])

#define rcBopStatus                             0x25
#define rmChkBopBusy                            (rBopCtrl[rcBopStatus])

#define rcEnBopInt                              0x26
#define rmEnBopInterrupt                        (rBopCtrl[rcEnBopInt]|=cBit0)
#define rmDisMultiCr                            (rBopCtrl[rcEnBopInt]|=cBit1)
#define rmEnBopRaidFlagDes                      (rBopCtrl[rcEnBopInt]|=cBit3)
#define rmDisBopRaidFlagDes                     (rBopCtrl[rcEnBopInt]&=~cBit3)
#define rmEnBopRaidFlagSrc                      (rBopCtrl[rcEnBopInt]|=cBit4)
#define rmDisBopRaidFlagSrc                     (rBopCtrl[rcEnBopInt]&=~cBit4)
#define rmBopCrcCompareEnable                   {(rBopCtrl[rcEnBopInt]|=cBit5);asm ("DSB");}

#define rmBopCrcCompareDisable                  {(rBopCtrl[rcEnBopInt]&=~cBit5);asm ("DSB");}
#define rmBopCrcGenEnable                       {(rBopCtrl[rcEnBopInt]|=cBit6);asm ("DSB");}
#define rmBopCrcGenDisable                      {(rBopCtrl[rcEnBopInt]&=~cBit6);asm ("DSB");}
#define rmForceDisCrcfun                        {(rBopCtrl[rcEnBopInt]|=cBit7);asm ("DSB");}
#define rmForceEnCrcfun                         {(rBopCtrl[rcEnBopInt]&=(~cBit7));asm ("DSB");}
#define rmRstBopRaidFlag                        (rBopCtrl[rcEnBopInt]&=0xE7)

#define rcBopResume                             0x27
#define rmBopResume                             (rBopCtrl[rcBopResume]=1)

#define rcDmaCfg                                0x28
#define rmBopDrmManualTrigSize512B              (rBopCtrl[rcDmaCfg]=((rBopCtrl[rcDmaCfg]&(~cBit1))&(~cBit0)))
#define rmBopDrmManualTrigSize1K                (rBopCtrl[rcDmaCfg]=((rBopCtrl[rcDmaCfg]&(~cBit1))|cBit0))
#define rmBopDrmManualTrigSize2K                (rBopCtrl[rcDmaCfg]=((rBopCtrl[rcDmaCfg]|cBit1)&(~cBit0)))
#define rmBopDrmManualTrigSize4K                (rBopCtrl[rcDmaCfg]=((rBopCtrl[rcDmaCfg]|cBit1)|cBit0))
#define rmBopEnDrmManualFlag                    (rBopCtrl[rcDmaCfg]|=cBit2)
#define rmBopDisDrmManualFlag                   (rBopCtrl[rcDmaCfg]&=(~cBit2))
#define rmBopTsbManualTrigSize512B              (rBopCtrl[rcDmaCfg]=((rBopCtrl[rcDmaCfg]&(~cBit4))&(~cBit3)))
#define rmBopTsbManualTrigSize1K                (rBopCtrl[rcDmaCfg]=((rBopCtrl[rcDmaCfg]&(~cBit4))|cBit3))
#define rmBopTsbManualTrigSize2K                (rBopCtrl[rcDmaCfg]=((rBopCtrl[rcDmaCfg]|cBit4)&(~cBit3)))
#define rmBopTsbManualTrigSize4K                (rBopCtrl[rcDmaCfg]=((rBopCtrl[rcDmaCfg]|cBit4)|cBit3))
#define rmBopEnTsbManualFlag                    (rBopCtrl[rcDmaCfg]|=cBit5)
#define rmBopDisTsbManualFlag                   (rBopCtrl[rcDmaCfg]&=(~cBit5))
#define rmEnSearchWrp                           (rBopCtrl[rcDmaCfg]|=cBit6)
#define rmDisSearchWrp                          (rBopCtrl[rcDmaCfg]&=(~cBit6))
#define rmBopSoftReset                          {rBopCtrl[rcDmaCfg]|=cBit7;rBopCtrl[rcDmaCfg]&=(~cBit7);}

#define rcDmaCompOk                             0x29
#define rmChkDmaComp                            (rBopCtrl[rcDmaCompOk]&cBit0)
#define  rmGetBopCrcFailCnt                     (rBopCtrl[rcDmaCompOk]&0x06)

#define rcDmaDramPackLen                        0x2A
#define rmSetDramDmaPackLen(len)                (r16BopCtrl[rcDmaDramPackLen/2]=len)

#define rcDmaTsbPackLen                         0x2E
#define rmSetTsbDmaPackLen(len)                 (r16BopCtrl[rcDmaTsbPackLen/2]=len)

#define rcDmaSeed0                              0x30
#define rmSetDmaScrbSeed0(seed)                 (rBopCtrl[rcDmaSeed0]=seed)

#define rcDmaSeed1                              0x31
#define rmSetDmaScrbSeed1(seed)                 (rBopCtrl[rcDmaSeed1]=seed)

// BOP-based decode flow
#define rcDecErrMap                             0x32
#define rmSetDecErrMap(errbitmap)               (r16BopCtrl[rcDecErrMap/2]=errbitmap)
#define rmClrDecErrMap                          (r16BopCtrl[rcDecErrMap/2]=0x0000)

// BOP CRC Status
#define rcCrcOk                                 0x34
#define rmChkCrcOk                              (rBopCtrl[rcCrcOk]&cBit0)

#define rcBopRaidTermSctrIdx                    0x35
#define rmChkBopRaidTermSctrIdx                 rBopCtrl[rcBopRaidTermSctrIdx]
#define rmClrBopRaidTermSctrIdx                 (rBopCtrl[rcBopRaidTermSctrIdx]=0x00)

#define rcBopRaidTermPgIdx                      0x36
#define rmChkBopRaidTermPgIdx                   r16BopCtrl[rcBopRaidTermPgIdx/2]
#define rmClrBopRaidTermPgIdxReset              (r16BopCtrl[rcBopRaidTermPgIdx/2]=0x0000)

// DMA Wrapping Control
#define rcDmaTsbHead0                           0x38
#define rmSetDmaTsbHead0(head)                  (r16BopCtrl[rcDmaTsbHead0/2]=head)

#define rcDmaTsbTail0                           0x3A
#define rmSetDmaTsbTail0(tail)                  (r16BopCtrl[rcDmaTsbTail0/2]=tail)

#define rcDmaTsbHead1                           0x3C
#define rmSetDmaTsbHead1(head)                  (r16BopCtrl[rcDmaTsbHead1/2]=head)

#define rcDmaTsbTail1                           0x3E
#define rmSetDmaTsbTail1(tail)                  (r16BopCtrl[rcDmaTsbTail1/2]=tail)

#define rcDmaTsbHead2                           0x40
#define rmSetDmaTsbHead2(head)                  (r16BopCtrl[rcDmaTsbHead2/2]=head)

#define rcDmaTsbTail2                           0x42
#define rmSetDmaTsbTail2(tail)                  (r16BopCtrl[rcDmaTsbTail2/2]=tail)

#define rcDmaDramHead0                          0x44
#define rmSetDmaDramHead0(head)                 (r32BopCtrl[rcDmaDramHead0/4]=head)

#define rcDmaDramTail0                          0x48
#define rmSetDmaDramTail0(tail)                 (r32BopCtrl[rcDmaDramTail0/4]=tail)

#define rcDmaDramHead1                          0x4C
#define rmSetDmaDramHead1(head)                 (r32BopCtrl[rcDmaDramHead1/4]=head)

#define rcDmaDramTail1                          0x50
#define rmSetDmaDramTail1(tail)                 (r32BopCtrl[rcDmaDramTail1/4]=tail)

#define rcDramCacheBias                         0x54
#define rmSetDmaDramCacheBias(bias)             (r16BopCtrl[rcDramCacheBias/2]=bias)

#define rcBvciThreshold                         0x56
#define rmSetBvciThreshold(len)                 (r16BopCtrl[rcBvciThreshold/2]=len)

#define rcBopRaidCmd                            0x58
#define rmSetBopRaidCmd(cmd)                    (rBopCtrl[rcBopRaidCmd]=(rBopCtrl[rcBopRaidCmd]&0x8F)|(cmd<<4))
#define rmClrBopRaidCmd                         (rBopCtrl[rcBopRaidCmd]=0x00)

#define rcBopRaidResmSctrIdx                    0x59
#define rmSetBopRaidResmSctrIdx(index)          (rBopCtrl[rcBopRaidResmSctrIdx]=index)
#define rmClrBopRaidResmSctrIdx                 (rBopCtrl[rcBopRaidResmSctrIdx]=0x00)

#define rcBopRaidResmPgIdx                      0x5A
#define rmSetBopRaidResmPgIdx(index)            (r16BopCtrl[rcBopRaidResmPgIdx/2]=index)
#define rmClrBopRaidResmPgIdx                   (r16BopCtrl[rcBopRaidResmPgIdx/2]=0x0000)

#define rcSEngineCfg0                           0x5C
#define rmEnSrchSkip                            (rBopCtrl[rcSEngineCfg0]|=cBit4)
#define rmDisSrchSkip                           (rBopCtrl[rcSEngineCfg0]&=(~cBit4))
#define rmEnSearchInBound                       (rBopCtrl[rcSEngineCfg0]|=cBit5)
#define rmDisSearchInBound                      (rBopCtrl[rcSEngineCfg0]&=(~cBit5))
#define rmSetSrchMode(x)                        (rBopCtrl[rcSEngineCfg0]=(rBopCtrl[rcSEngineCfg0]&0xF0)|x)
// #define rmSetSrchDefault
//                        {rBopCtrl[rcSEngineCfg0]=(rBopCtrl[rcSEngineCfg0]&0xA0)|cBopSrchDat|cBopLwordMo|cBit6;rmRstSrchMsk;}
#define rmSetSrchDefault                        {rBopCtrl[rcSEngineCfg0]=(rBopCtrl[rcSEngineCfg0]&0xA0)|cBopSrchDat|cBopLwordMo;rmRstSrchMsk;}
#define rmEnQuickSrch                           (rBopCtrl[rcSEngineCfg0]|=cBit6)
#define rmDisQuickSrch                          (rBopCtrl[rcSEngineCfg0]&=~cBit6)

#define rcClrSkipRam                            0x5D
#define rmAutoClrSkipRam\
    {rBopCtrl[rcClrSkipRam]|=cBit0;\
     while(rmChkClrSkipRam)\
         ;\
     rBopCtrl[rcClrSkipRam]&=(~cBit0);}
#define rmChkClrSkipRam                         (!(rBopCtrl[rcClrSkipRam]&cBit4))

#define rcSEngineFindResVal                     0x5E
#define rmChkSrchValFind                        (rBopCtrl[rcSEngineFindResVal]&cBit0)

#define rcSEngineThValue                        0x60
#define rmSetSrchThVal(x)                       (r32BopCtrl[rcSEngineThValue/4]=x)

#define rcSEngineLowerBound                     0x64
#define rmSetSrchLorBound(x)                    (r32BopCtrl[rcSEngineLowerBound/4]=x)

#define rcSEngineResOffset                      0x68
#define rmGetSrchRslOfst                        (r16BopCtrl[rcSEngineResOffset/2])

#define rcSEngineResEquCnt                      0x6A
#define rmGetSrhResEquCnt                       (r16BopCtrl[rcSEngineResEquCnt/2])

#define rcSEngineResLessCnt                     0x6C
#define rmGetSrhResLessCnt                      (r16BopCtrl[rcSEngineResLessCnt/2])

#define rcSEngineResGreatCnt                    0x6E
#define rmGetSrhResMoreCnt                      (r16BopCtrl[rcSEngineResGreatCnt/2])

#define rcSEngineResSumCnt                      0x70
#define rmGetSrhResSumCnt                       (r32BopCtrl[rcSEngineResSumCnt/4])

#define rcSEngineResVal                         0x74
#define rmGetSrhResVal                          (r32BopCtrl[rcSEngineResVal/4])

#define rcSrhMsk                                0x7C
#define rmSetSrchMsk(x)                         (r32BopCtrl[rcSrhMsk/4]=(x))
#define rmRstSrchMsk                            (r32BopCtrl[rcSrhMsk/4]=0xFFFFFFFF)

#define rcSrchBitMap                            0x78
#define rcSrhTgt0                               0x80
#define cQuickSrchSize                          32
// #define rmSetSrchRslVal(x, val)                 {r32BopCtrl[rcSrchBitMap]|=cb32BitTab[x];r32BopCtrl[(rcSrhTgt0/4)+x]=val;}
#define rmSetSrchTgt(x, y)                      (r32BopCtrl[(rcSrhTgt0/4)+(x)]=(y))
#define rmGetSrchTgt(x)                         (r32BopCtrl[(rcSrhTgt0/4)+(x)])
#define rmChkSrchTgt32Vld                       (r32BopCtrl[rcSrchBitMap/4])
#define rmChkSrchTgt16Vld(x)                    (r16BopCtrl[(rcSrchBitMap/2)+x])
#define rmChkSrchTgt8Vld(x)                     (rBopCtrl[rcSrchBitMap+x])
#define rmClrSrchRslVal                         (r32BopCtrl[rcSrchBitMap/4]=0)

#define rcRaidDecErrMap                         0x100
#define rmBopRaidDecErrMap                      (r16BopCtrl[rcRaidDecErrMap/2])

#define rcDmaFillPattern                        0x108
#define rmSetDmaPatn(pattern)                   (r32BopCtrl[rcDmaFillPattern/4]=pattern)    // New address of pattern registers in SM2260

#define rcTsbThreshold                          0x10C
#define rmSetTsbThreshold(len)                  (r16BopCtrl[rcTsbThreshold/2]=len)

// BOP SHA Control
#define rcBopDmaShaEn                           0x10E
#define rmEnBopDmaSha                           (rBopCtrl[rcBopDmaShaEn]|=cBit0)
#define rmDisBopDmaSha                          (rBopCtrl[rcBopDmaShaEn]&=(~cBit0))

// BOP DMA for AES Cmd
#define rcBopAesCmd                             0x110
#define rmBopAesCmd                             rBopCtrl[rcBopAesCmd]

#define rmBopAutoAesEnc                         (rBopCtrl[rcBopAesCmd]=((rBopCtrl[rcBopAesCmd]&(~cBit0))|cBit7))
#define rmBopAutoAesDec                         (rBopCtrl[rcBopAesCmd]|=(cBit7|cBit0))

#define rmBopAutoAesXts                         (rBopCtrl[rcBopAesCmd]=(rBopCtrl[rcBopAesCmd]&0x81)|cBit3)
#define rmBopAutoAesCbc                         (rBopCtrl[rcBopAesCmd]=(rBopCtrl[rcBopAesCmd]&0x81)|cBit2)
#define rmBopAutoAesCbcIv                       (rBopCtrl[rcBopAesCmd]=(rBopCtrl[rcBopAesCmd]&0x81)|cBit2|cBit6)    // reload the cbc intial
// vector
#define rmBopAutoAesEcb                         (rBopCtrl[rcBopAesCmd]=(rBopCtrl[rcBopAesCmd]&0x81)|cBit1)
#define rmBopAutoAesFxts                        (rBopCtrl[rcBopAesCmd]=(rBopCtrl[rcBopAesCmd]&0x81)|cBit3|cBit5)    // using fw_key on xts_mode
#define rmBopDisAutoAes                         (rBopCtrl[rcBopAesCmd]=0x00)

#define rcBopAesLba                             0x114
#define rmBopAutoAesLba(lba)                    (r32BopCtrl[rcBopAesLba/4]=lba)

#define rcBopAesExtLba                          0x118
#define rmBopAutoAesExtLba(extLba)              (r16BopCtrl[rcBopAesExtLba/2]=extLba)

#define rcBopCrcFailSector                       0x11C
#define rmGetBopCrcFailSector                    r32BopCtrl[rcBopCrcFailSector/4]

#define rcBopDebug2                             0x13C
#define rmChkBopNbsBz                           (rBopCtrl[rcBopDebug2+1]&(cBit4|cBit5|cBit6))

#endif    // ifndef __REG_BOP_H__







