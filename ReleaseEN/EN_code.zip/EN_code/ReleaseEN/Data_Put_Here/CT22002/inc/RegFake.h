







#ifndef __REG_FAKE_H__
#define __REG_FAKE_H__

// Advanced Host Controller Interface @ 0x5100_7000h

#define rcTsbSaddr0                              0x104
#define rcTsbDaddr0                              0x106

#define rcTsbSaddr1                              0x108
#define rcTsbDaddr1                              0x10A

#define rcTsbSaddr2                              0x10C
#define rcTsbDaddr2                              0x10E
// rAHCI

#define rmSetAhciTsbWrapSaddr0(x)                (r16FakeCtrl[rcTsbSaddr0/2]=x)
#define rmSetAhciTsbWrapDaddr0(x)                (r16FakeCtrl[rcTsbDaddr0/2]=x)

#define rmSetAhciTsbWrapSaddr1(x)                (r16FakeCtrl[rcTsbSaddr1/2]=x)
#define rmSetAhciTsbWrapDaddr1(x)                (r16FakeCtrl[rcTsbDaddr1/2]=x)

#define rmSetAhciTsbWrapSaddr2(x)                (r16FakeCtrl[rcTsbSaddr2/2]=x)
#define rmSetAhciTsbWrapDaddr2(x)                (r16FakeCtrl[rcTsbDaddr2/2]=x)

#if 0
// Fake Data Engine @ 0x5100_7500

#define  rcFakeCtrl0                             0x500
#define  rmTrigFake                              (rFakeCtrl[rcFakeCtrl0]|=cBit7)
#define  rmFakeWrite                             (rFakeCtrl[rcFakeCtrl0]|=cBit6)
#define  rmFakeRead                              (rFakeCtrl[rcFakeCtrl0]&=(~cBit6))
#define  rmFakeScrbEn                            (rFakeCtrl[rcFakeCtrl0]|=cBit5)
#define  rmFakeScrbDis                           (rFakeCtrl[rcFakeCtrl0]&=(~cBit5))
#define  rmChkFakeFail                           (rFakeCtrl[rcFakeCtrl0]&cBit2)
#define  rmFakeBusy                              (!(rFakeCtrl[rcFakeCtrl0]&cBit1))
#define  rmResetFake                             (rFakeCtrl[rcFakeCtrl0]|=cBit1)
#define  rmEnFake                                (rFakeCtrl[rcFakeCtrl0]|=cBit0)
#define  rmDisFake                               (rFakeCtrl[rcFakeCtrl0]&=(~cBit0))

#define  rcFakeCtrl1                             0x501
#define  rmClrFakeFail                           (rFakeCtrl[rcFakeCtrl1]|=cBit7)
#define  rmEnFakeCompare                         (rFakeCtrl[rcFakeCtrl1]|=cBit3)
#define  rmDisFakeCompare                        (rFakeCtrl[rcFakeCtrl1]&=(~cBit3))
#define  rmEnFakeRunTimeOccFlg                   (rFakeCtrl[rcFakeCtrl1]|=cBit2)    // BVCI
#define  rmEnFakeBufFlg                          (rFakeCtrl[rcFakeCtrl1]|=cBit1)
#define  rmEnFakePreOccFlg                       (rFakeCtrl[rcFakeCtrl1]|=cBit0)    // BVCI
#define  rmEnFakeOccFlg                          (rFakeCtrl[rcFakeCtrl1]|=(cBit0|cBit2))

#define  rmDisFakeRunTimeOccFlg                  (rFakeCtrl[rcFakeCtrl1]&=(~cBit2))
#define  rmDisFakeBufFlg                         (rFakeCtrl[rcFakeCtrl1]&=(~cBit1))
#define  rmDisFakePreOccFlg                      (rFakeCtrl[rcFakeCtrl1]&=(~cBit0))
#define  rmDisFakeOccFlg                         (rFakeCtrl[rcFakeCtrl1]&=(~(cBit0|cBit2)))
// #define  rmEnFakeWrBufFlg                      (rFakeCtrl[rcFakeCtrl1]=((rFakeCtrl[rcFakeCtrl1]&0xF3)|cBit2))
// #define  rmEnFakeRdBufFlg                      (rFakeCtrl[rcFakeCtrl1]=((rFakeCtrl[rcFakeCtrl1]&0xF3)|cBit3))

#define  rcFakeLen                               0x502
#define  rmSetFakeLen(len)                       (r16FakeCtrl[rcFakeLen/2]=len)

#define  rcFakeScrambleSeed                      0x504
#define  rmSetFakeScrambleSeed(val)              (rFakeCtrl[rcFakeScrambleSeed]=val)

#define  rcFakeLBA                               0x508
#define  rmSetFakeLBA(val)                       (r32FakeCtrl[rcFakeLBA/4]=val)

#define  rcFakeTsbAddr                           0x50C
#define  rmEnFakeTsb                             (r32FakeCtrl[rcFakeTsbAddr/4]|=c32Bit31)
#define  rmDisFakeTsb                            (r32FakeCtrl[rcFakeTsbAddr/4]=0)
#define  rmSetFakeRdAddr(addr)                   (r32FakeCtrl[rcFakeTsbAddr/4]=(addr)<<8)

#define  rcFakeTsbPreOccuSec                     0x510
#define  rmSetFakeTsbOccSec(bufidx)              {r16FakeCtrl[rcFakeTsbPreOccuSec/2]=bufidx;}    // BVCI

#define  rcFakeBvciPreOccuSec                    0x512
#define  rmSetFakeBvciOccSec(bufidx)             {rmEnFakeOccFlg;r16FakeCtrl[rcFakeBvciPreOccuSec/2]=bufidx;}    // BVCI

#define  rcFakeBvciAddr                          0x514
#define  rmEnFakeBvci                            (r32FakeCtrl[rcFakeBvciAddr/4]|=c32Bit31)
#define  rmDisFakeBvci                           (r32FakeCtrl[rcFakeBvciAddr/4]=0)
#define  rmSetFakeWrAddr(addr)                   (r32FakeCtrl[rcFakeBvciAddr/4]=(addr))

#define  rcFakeBvciBias                          0x518

#endif    // if 0

#endif    // ifndef __REG_FAKE_H__







