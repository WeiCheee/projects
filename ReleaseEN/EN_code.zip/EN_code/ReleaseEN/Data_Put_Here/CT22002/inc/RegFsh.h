







#ifndef __REG_FSH_H__
#define __REG_FSH_H__

// FlashController Register

#define rcMiscControl                            0x0024
#define rmAddOPIndex                             (rFLCtrl[rcMiscControl]=0xFF)
#define rmCmdTimerTrig                           (rFLCtrl[rcMiscControl]=0xFE)
#define rmCmdPause                               (rFLCtrl[rcMiscControl]=0xFD)
#define rmCmdInt                                 (rFLCtrl[rcMiscControl]=0xFC)
#define rmCmdEnCeMsk                             (rFLCtrl[rcMiscControl]=0xFB)
#define rmCmdDisCeMsk                            (rFLCtrl[rcMiscControl]=0xFA)
#define rmCmdRwSelTempReg                        (rFLCtrl[rcMiscControl]=0xF9)
#define rmCmdRwSelNormalSource                   (rFLCtrl[rcMiscControl]=0xF8)
#define rmCmdEnBvciBackup                        (rFLCtrl[rcMiscControl]=0xF7)
#define rmCmdClrOccFlag                          (rFLCtrl[rcMiscControl]=0xF6)    // ref to 0x4A ,0x92, 0x96
#define rmCmdMaskCleAleEnable                    (rFLCtrl[rcMiscControl]=0xF5)    // Mask Flash command(cle, ale) enable
#define rmCmdMaskCleAleDisable                   (rFLCtrl[rcMiscControl]=0xF4)    // Mask Flash command(cle, ale) disable
#define rmCmdEnMaskWrTSB                         (rFLCtrl[rcMiscControl]=0xF3)
#define rmCmdDisMaskWrTSB                        (rFLCtrl[rcMiscControl]=0xF2)
#define rmAddRaidMergeClrCnt                     (rFLCtrl[rcMiscControl]=0xF0)
#define rmCmdFlashErrInjectEn                    (rFLCtrl[rcMiscControl]=0xEF)
#define rmCmdFlashErrInjectDis                   (rFLCtrl[rcMiscControl]=0xEE)
#if _FLASH_TRIG_HOST
#define rmCmdChHostTrig                          (rFLCtrl[rcMiscControl]=0xF1)
#endif

#define rcRwMode                                 0x0048
#define rmSelRd                                  (rFLCtrl[rcRwMode]&=(~cBit0))
#define rmSelWr                                  (rFLCtrl[rcRwMode]|=cBit0)
#define rmSelData                                (rFLCtrl[rcRwMode]&=(~cBit1))
#define rmSelSpr                                 (rFLCtrl[rcRwMode]|=cBit1)
#define rmAutoBuf                                (rFLCtrl[rcRwMode]&=(~cBit2))
#define rmDisAutoBuf                             (rFLCtrl[rcRwMode]|=cBit2)
#define rmEnWaitDMADone                          (rFLCtrl[rcRwMode]&=(~cBit3))
#define rmDisWaitDMADone                         (rFLCtrl[rcRwMode]|=cBit3)    // for Ldpc retry

#define rmRdDataAutoBuf                          (rFLCtrl[rcRwMode]=0x00|(rFLCtrl[rcRwMode]&cBit3))    // keep the WaitDMADone setting
#define rmWrDataAutoBuf                          (rFLCtrl[rcRwMode]=0x01|(rFLCtrl[rcRwMode]&cBit3))
// #define rmWrDataAutoBuf                          (rFLCtrl[rcRwMode]=0x01)
#define rmRdDataDisBuf                           (rFLCtrl[rcRwMode]=0x04|(rFLCtrl[rcRwMode]&cBit3))    // keep the WaitDMADone setting
#define rmWrDataDisBuf                           (rFLCtrl[rcRwMode]=0x05|(rFLCtrl[rcRwMode]&cBit3))
#define rmRdSprB                                 (rFLCtrl[rcRwMode]=0x06|(rFLCtrl[rcRwMode]&cBit3))
#define rmWrSprB                                 (rFLCtrl[rcRwMode]=0x07|(rFLCtrl[rcRwMode]&cBit3))
// #define rmWrDataDisBuf                           (rFLCtrl[rcRwMode]=0x05)
// #define rmRdSprB                                 (rFLCtrl[rcRwMode]=0x06)
// #define rmWrSprB                                 (rFLCtrl[rcRwMode]=0x07)

#define rcStartSector                            0x0049
#define rmSetStartSector(halfkb)                 (rFLCtrl[rcStartSector]=halfkb)

#define rcDataSeed                               0x004C
#define rmSetSeed(x)                             (r16FLCtrl[rcDataSeed/2]=x)

#define rcFshRaidFlag                            0x004E
#define rmChkFshRaidFlag                         (rFLCtrl[rcFshRaidFlag]&cBit0)
#define rmEnFshRaidFlag                          (rFLCtrl[rcFshRaidFlag]|=cBit0)
#define rmDisFshRaidFlag                         (rFLCtrl[rcFshRaidFlag]&=~cBit0)

#define rcWrSprSel                               0x0054    // for WrSpr
#define rmSetWrSprSel                            (rFLCtrl[rcWrSprSel]=rFLCtrl[rcSpareGpSel])

#define rcRd0                                    0x0104    // for manual Data
#define rcRd1                                    0x0105
#define rcRd2                                    0x0106
#define rcRd3                                    0x0107
#define rcRd4                                    0x0108
#define rcRd5                                    0x0109
#define rcRd6                                    0x010A
#define rcRd7                                    0x010B

#define rcPlaneSel                               0x010C
#define rmEnAutoPlane                            (rFLCtrl[rcPlaneSel]|=cBit7)
#define rmDisAutoPlane                           (rFLCtrl[rcPlaneSel]&=(~cBit7))
#define rmSetPlaneBit(plane)                     (rFLCtrl[rcPlaneSel]=(((rFLCtrl[rcPlaneSel]&0xFC)|plane)|cBit7))
#define rmSetDieBit(die)                         (rFLCtrl[rcPlaneSel]=(((rFLCtrl[rcPlaneSel]&0x8F)|die<<4)|cBit7))
#define rmGetDieBit()                            ((rFLCtrl[rcPlaneSel]&0x70)>>4)
#define rmSetDiePlane(die, plane)                (rFLCtrl[rcPlaneSel]=(((rFLCtrl[rcPlaneSel]&0x8C)|die<<4|plane)|cBit7))

#define rcSec                                    0x010D
#define rcPage                                   0x010E
#define rcBlock                                  0x0110
#define rcALE0                                   rcSec    // for manual ALE
#define rcALE1                                   (rcSec+1)
#define rcALE2                                   (rcSec+2)
#define rcALE3                                   (rcSec+3)
#define rcALE4                                   (rcSec+4)
#define rmSetSctrAddr(addr)                      (rFLCtrl[rcSec]=addr)    // Sector address , ALE column address
#define rmSetPageAddr(addr)                      (r16FLCtrl[rcPage/2]=addr)    // Page address
#define rmSetBlkAddr(addr)                       (r16FLCtrl[rcBlock/2]=addr)    // block address

#define rcCeOn                                   0x0000
#define rcCeOff                                  0x0004
#define rcCLE                                    0x0008
#define rcALE                                    0x000C
#define rcALEmanual                              0x0010    // manual ALE
#define rcDataDMA                                0x0014
#define rcDataManual                             0x0018
#define rcRdUntilValue                           0x001C
#define rcNop                                    0x0020
#define rcMiscControl                            0x0024
#define rmClrOccFlag                             (rFLCtrl[rcMiscControl]=0xF6)

#define rcWaitRBHigh                             0x0028

#define rcOccClrSel                              0x004A
#define rmClrTSBOcc                              (rFLCtrl[rcOccClrSel]=0)
#define rmClrBVCIOcc                             (rFLCtrl[rcOccClrSel]=1)

#define rcSelBadColumTable                       0x0050
#define rcPollMask                               0x0051
#define rcStsFailMask                            0x0052

#define rmAllCeOn                                (rFLCtrl[rcCeOn]=0xFF)
#define rmAllCeOff                               (rFLCtrl[rcCeOff]=0xFF)
#define rmCeOn(idx)                              {rmAllCeOff;rFLCtrl[rcCeOn]=garCeMapTable[idx];}
#define rmCeOff(idx)                             (rFLCtrl[rcCeOff]=garCeMapTable[idx])
#define rmDirCeOn(idx)                           {rmAllCeOff;rFLCtrl[rcCeOn]=idx;}
#define rmDirCeOff(idx)                          (rFLCtrl[rcCeOff]=idx)
#define rmCle(cmd)                               (rFLCtrl[rcCLE]=cmd)
#define rmAle2                                   (rFLCtrl[rcALE]=2)
#define rmAle3                                   (rFLCtrl[rcALE]=3)
#define rmAle5                                   (rFLCtrl[rcALE]=5)
#define rmAle6                                   (rFLCtrl[rcALE]=6)
#define rmManAle(num)                            (rFLCtrl[rcALEmanual]=num)
#define rmAle(addr)                              {rFLCtrl[rcSec]=addr;rFLCtrl[rcALEmanual]=1;}
#define rmManRd(num)                             {rmSelRd;rFLCtrl[rcDataManual]=num;}
#define rmManWr(num)                             {rmSelWr;rFLCtrl[rcDataManual]=num;}
#define rmWriteByte(x)                           {rmCmdMaskCleAleEnable;rmCle(x);rmCmdMaskCleAleDisable;}
// #define mSetIntlvCe(x)                           (x>>gsCacheInfo.uDiePerCeShift)    // ???
#if 1    // test for HW TWHR time
#define rmRdData(halfkb)                         {rFLCtrl[rcDataDMA]=halfkb;}
#define rmWrData(halfkb)                         {rFLCtrl[rcDataDMA]=halfkb;}
#define rmWrSpr                                  {rmSetWrSprSel;rmWrSprB;rFLCtrl[rcDataDMA]=1;rmSelData;}
#if (!_HwPlane2SprIssue)
#define rmRdSpr                                  {rmSelSprGroup(0);rmRdSprB;rFLCtrl[rcDataDMA]=1;rmSelData;}
#else
#define rmRdSpr                                  {rmSelSprGroup(0);rmSetPlaneBit(gPlaneAddr%2);rmRdSprB;rFLCtrl[rcDataDMA]=1;rmSelData;}
#endif
#else
#define rmRdData(halfkb)                         {rmNop(cTwhr2);rFLCtrl[rcDataDMA]=halfkb;}
#define rmWrData(halfkb)                         {rmNop(cTwhr2);rFLCtrl[rcDataDMA]=halfkb;}
#define rmWrSpr                                  {rmSetWrSprSel;rmWrSprB;rmNop(11);rFLCtrl[rcDataDMA]=1;rmSelData;}
// only use plane 0 & 1, 2263 HW issue, get wrong plane 2 spare
#if (!_HwPlane2SprIssue)
#define rmRdSpr                                  {rmSelSprGroup(0);rmRdSprB;rmNop(11);rFLCtrl[rcDataDMA]=1;rmSelData;}
#else
#define rmRdSpr\
    {rmSelSprGroup(0);rmSetPlaneBit(gPlaneAddr%2);rmRdSprB;rmNop(11);rFLCtrl[rcDataDMA]=1;\
     rmSelData;}
#endif
#endif    // if 1
#define rmSprAle2                                {rmSelSpr;rmAle2;rmSelData;}
#define rmSprAle5                                {rmSelSpr;rmAle5;rmSelData;}
#define rmDataAle5                               {rmSelData;rmAle5;}
// #define rmRdStatus(x)                            {rmNop(cTwhr);rFLCtrl[rcPollMask]=x;rFLCtrl[rcRdUntilValue]=0xE0;}
#define rmRdStatus(x)                            {rFLCtrl[rcPollMask]=x;rFLCtrl[rcRdUntilValue]=0xE0;}
#define rmNop(num)                               (rFLCtrl[rcNop]=num)
#define rmNop2(num)                              {rmNop(num);rmNop(num);}
#define rmNop3(num)                              {rmNop(num);rmNop(num);rmNop(num);}
#define rmStsFailMask(x)                         (rFLCtrl[rcStsFailMask]=x)

#define rcBufStartAddr                           0x0054
#define rmSetBufSAddr(saddr)                     (r16FLCtrl[rcBufStartAddr/2]=saddr)
#define rmGetBufSAddr                            r16FLCtrl[rcBufStartAddr/2]
#define rcDmaId                                  0x0056
#define rmSetDmaId(DmaId, planeIdx)              {r16FLCtrl[rcDmaId/2]=((((WORD)DmaId)|(((WORD)planeIdx)<<7))|c16Bit9);g16LdpcDmaIdCnt++;}
#define rmSetDmaIdSpare                          (r16FLCtrl[rcDmaId/2]=c16Bit9)

#define rcSetLdpcPageType                        0x0058
#define rmSetLdpcPageType(Type)                  (rFLCtrl[rcSetLdpcPageType]=Type)

#define rcSetLdpcSoftMode                        0x0059
#define rmSetLdpcSoftMode(Mode)                  (rFLCtrl[rcSetLdpcSoftMode]=Mode)

#define rcSetLdpcSoftIdx                         0x005A
#define rmSetLdpcSoftIdx(SofIdx)                 (rFLCtrl[rcSetLdpcSoftIdx]=SofIdx)

#define rcLdpcCtl                                0x005B
#define rmSetEccFailForceXfr                     (rFLCtrl[rcLdpcCtl]|=cBit0)
#define rmClrEccFailForceXfr                     (rFLCtrl[rcLdpcCtl]&=(~cBit0))
#define rmChkEccFailForceXfr                     (rFLCtrl[rcLdpcCtl]&cBit0)

#define rmSetDecModeBypass                       (rFLCtrl[rcLdpcCtl]|=cBit1)
#define rmClrDecModeBypass                       (rFLCtrl[rcLdpcCtl]&=(~cBit1))

#define rmSetDecModeRaid                         (rFLCtrl[rcLdpcCtl]|=cBit2)
#define rmClrDecModeRaid                         (rFLCtrl[rcLdpcCtl]&=(~cBit2))
#define rmChkDecModeRaid                         (rFLCtrl[rcLdpcCtl]&cBit2)

#define rcLdpcPageIdx                            0x005C
#define rmSetLdpcPageIdx(PgIdx)                  (r16FLCtrl[rcLdpcPageIdx/2]=PgIdx)

#define rcErrInjectCtl                           0x0060
#define rmErrInjectRWSel(x)                      (rFLCtrl[rcErrInjectCtl]=(0x01&x))

#define rcErrInjectChunk                         0x0061
#define rmErrInjectChunk(uChunkBitMap)           (rFLCtrl[rcErrInjectChunk]=uChunkBitMap)

#define rcDmaLen                                 0x0080
#define rmSetDmaLen(len)                         (r16FLCtrl[rcDmaLen/2]=len)
#define rmSetDmaLen2K                            (r16FLCtrl[rcDmaLen/2]=0x0800)    // 2260 only use 2K
#define rmSetDmaLen1K                            (r16FLCtrl[rcDmaLen/2]=0x0400)
#define rmSetDmaLen512                           (r16FLCtrl[rcDmaLen/2]=0x0200)

#define rcEccPtyLen                              0x0083
#define rmSetEccParity(x)                        (rFLCtrl[rcEccPtyLen]=x)

#define rcCtrl0                                  0x0084
#define rmEnONFI2Mo                              (rFLCtrl[rcCtrl0]=(rFLCtrl[rcCtrl0]&0x1F)|cBit7)
#define rmChkOnfi2Mo                             (rFLCtrl[rcCtrl0]&cBit7)
#define rmEnToggleMo                             (rFLCtrl[rcCtrl0]=(rFLCtrl[rcCtrl0]&0x1F)|cBit6)
#define rmChkToggleMo                            (rFLCtrl[rcCtrl0]&cBit6)
#define rmEnBusEDOMo                             (rFLCtrl[rcCtrl0]=(rFLCtrl[rcCtrl0]&0x1F)|cBit5)
#define rmEnAsyncMo                              (rFLCtrl[rcCtrl0]=(rFLCtrl[rcCtrl0]&0x1F))
#define rmSetPageNum(x)                          (rFLCtrl[rcCtrl0]=(rFLCtrl[rcCtrl0]&0xE3)|(x<<2))
#define rm64Page                                 (rFLCtrl[rcCtrl0]&=0xE3)
#define rm128Page                                (rFLCtrl[rcCtrl0]=(rFLCtrl[rcCtrl0]&0xE3)|0x04)
#define rm256Page                                (rFLCtrl[rcCtrl0]=(rFLCtrl[rcCtrl0]&0xE3)|0x08)
#define rm512Page                                (rFLCtrl[rcCtrl0]=(rFLCtrl[rcCtrl0]&0xE3)|0x0C)
#define rm1024Page                               (rFLCtrl[rcCtrl0]=(rFLCtrl[rcCtrl0]&0xE3)|0x10)
#define rm2048Page                               (rFLCtrl[rcCtrl0]=(rFLCtrl[rcCtrl0]&0xE3)|0x14)
#define rm4096Page                               (rFLCtrl[rcCtrl0]=(rFLCtrl[rcCtrl0]&0xE3)|0x18)
#define rm8192Page                               (rFLCtrl[rcCtrl0]=(rFLCtrl[rcCtrl0]&0xE3)|0x1C)
#define rmSetBlkSizeREG(x)                       (rFLCtrl[rcCtrl0]=(rFLCtrl[rcCtrl0]&0xE0)|(0x1F&x))
#define rmChk64Page                              (rFLCtrl[rcCtrl0]&0x1C)==0)
#define rmChk128Page                             (rFLCtrl[rcCtrl0]&0x1C)==0x04)
#define rmChk256Page                             (rFLCtrl[rcCtrl0]&0x1C)==0x08)
#define rmChk512Page                             (rFLCtrl[rcCtrl0]&0x1C)==0x0C)
#define rmChk1024Page                            (rFLCtrl[rcCtrl0]&0x1C)==0x10)
#define rmChk2048Page                            (rFLCtrl[rcCtrl0]&0x1C)==0x14
#define rmSetPlaneNum(x)                         (rFLCtrl[rcCtrl0]=(rFLCtrl[rcCtrl0]&0xFC)|(x))
#define  rmEn1Plane                              (rFLCtrl[rcCtrl0]=(rFLCtrl[rcCtrl0]&0xFC))
#define  rmEn2Plane                              (rFLCtrl[rcCtrl0]=(rFLCtrl[rcCtrl0]&0xFC)|0x01)
#define  rmEn4Plane                              (rFLCtrl[rcCtrl0]=(rFLCtrl[rcCtrl0]&0xFC)|0x02)

#define  rcCtrl1                                 0x0085
#define  rmEnAleCleDoubleCycle                   (rFLCtrl[rcCtrl1]|=cBit7)
#define  rmDisAleCleDoubleCycle                  (rFLCtrl[rcCtrl1]&=(~cBit7))
#define  rmSpare20bEcc                           (rFLCtrl[rcCtrl1]|=cBit5)
#define  rmSpare24bEcc                           (rFLCtrl[rcCtrl1]&=(~cBit5))
#define  rmSpareLen16B                           {rFLCtrl[rcCtrl1]&=(~cBit6);rmSpare24bEcc;}    // 16BYTE+26 BYTE parity =42BYTE
#define  rmSpareLen26B                           {rFLCtrl[rcCtrl1]|=cBit6;rmSpare20bEcc;}    // 26BYTE+22 BYTE parity =48BYTE
#define  rmChkSpare26B                           (rFLCtrl[rcCtrl1]&cBit6)
// 16B:   24b
// 26B:   24or20b            (24bEcc only for 26B Spare)
#define  rmSpareLen26BS                          {rFLCtrl[rcCtrl1]|=cBit6;rmSpare24bEcc;}    // 26BYTE+26 BYTE parity =52BYTE

#define  rmEnACle2Cycle                          (rFLCtrl[rcCtrl1]|=cBit4)
#define  rmEnACle1Cycle                          (rFLCtrl[rcCtrl1]&=(~cBit4))
#define  rmSetBlockNum(x)                        (rFLCtrl[rcCtrl1]=((rFLCtrl[rcCtrl1]&0xF1)|(x<<1)))
#define  rmMsbPlaneBit                           (rFLCtrl[rcCtrl1]|=cBit0)
#define  rmLsbPlaneBit                           (rFLCtrl[rcCtrl1]&=~cBit0)

#define  rcCtrl2                                 0x0086
#define  rmEnStsFailStop                         (rFLCtrl[rcCtrl2]|=cBit7)    // Program or Erase Fail Stop
#define  rmDisStsFailStop                        (rFLCtrl[rcCtrl2]&=(~cBit7))
#define  rmChkStsFailStop                        (rFLCtrl[rcCtrl2]&0x80)
#define  rmEnSeedInc                             (rFLCtrl[rcCtrl2]|=cBit3)
#define  rmDisSeedInc                            (rFLCtrl[rcCtrl2]&=(~cBit3))
#define  rmEnChkEccOnly                          (rFLCtrl[rcCtrl2]|=cBit2)
#define  rmEnEFNandMode                          {rFLCtrl[rcCtrl2]|=cBit1;rmDisEccEngine;}    // error free mode
#define  rmEnRawFshMode                          {rFLCtrl[rcCtrl2]&=(~cBit1);rmEnEccEngine;}
#define  rmEnEccEngine                           (rFLCtrl[rcCtrl2]|=cBit0)
#define  rmDisEccEngine                          (rFLCtrl[rcCtrl2]&=(~cBit0))
#define rmEnEcc                                  {rmClrDecModeBypass;rmClrLdpcDebugMode;r16EccDec[rcDebugDmaLenH/2]=0;}
#define rmDisEcc                                 {rmSetDecModeBypass;rmSetLdpcDebugMode;r16EccDec[rcDebugDmaLenH/2]=0x0400;}
#define  rmChkEccEnable                          ((rFLCtrl[rcCtrl2]&0x01)!=0x00)

#define  rcCtrl3                                 0x0087
#define  rmSelChunkMem                           (rFLCtrl[rcCtrl3]|=cBit7)
#define  rmSelBadColMem                          (rFLCtrl[rcCtrl3]&=(~cBit7))
#define  rmAccessFlash                           (rFLCtrl[rcCtrl3]&=(~cBit6))
#define  rmAccessBadColMem                       (rFLCtrl[rcCtrl3]|=cBit6)
#define  rmEnBadCol                              (rFLCtrl[rcCtrl3]|=cBit5)
#define  rmDisBadCol                             (rFLCtrl[rcCtrl3]&=(~cBit5))
#define  rmChkBadCol                             (rFLCtrl[rcCtrl3]&cBit5)
#define  rmEnPollStsToggle                       (rFLCtrl[rcCtrl3]|=cBit4)
#define  rmDisPollStsToggle                      (rFLCtrl[rcCtrl3]&=(~cBit4))

#define  rmDataSeedFromSpare                     (rFLCtrl[rcCtrl3]|=cBit2)    // Data Seed from spare seed
#define  rmDataSeedFromQue                       (rFLCtrl[rcCtrl3]&=(~cBit2))
#define  rmEnScrbSpare                           (rFLCtrl[rcCtrl3]|=cBit1)
#define  rmDisScrbSpare                          (rFLCtrl[rcCtrl3]&=(~cBit1))    // En Spare Scrb
#define  rmGetScrbSpare                          (rFLCtrl[rcCtrl3]&=cBit1)
#define  rmEnScrbData                            (rFLCtrl[rcCtrl3]|=cBit0)
#define  rmDisScrbData                           (rFLCtrl[rcCtrl3]&=(~cBit0))    // En Data Scrb
#define  rmGetScrbData                           (rFLCtrl[rcCtrl3]&=cBit0)    // ???
#define  rmEnScrbBoth                            (rFLCtrl[rcCtrl3]|=0x03)
#define  rmDisScrbBoth                           (rFLCtrl[rcCtrl3]&=0xFC)
#define  rmChkScrbBothEnable                     ((rFLCtrl[rcCtrl3]&0x03)!=0x00)

#define  rcCtrl4                                 0x0088
#define  rmMultiCeQueEn                          (rFLCtrl[rcCtrl4]|=cBit4)
#define  rmMultiCeQueDis                         (rFLCtrl[rcCtrl4]&=(~cBit4))
#define  rmExpandCeModeEn                        (rFLCtrl[rcCtrl4]|=cBit3)
#define  rmExpandCeModeDis                       (rFLCtrl[rcCtrl4]&=(~cBit3))
#define  rmAleDriveDqsHigh                       (rFLCtrl[rcCtrl4]|=cBit2)
#define  rmAleDriveDqsLow                        (rFLCtrl[rcCtrl4]&=(~cBit2))
#define  rmAleDriveDQSVal(x)                     (rFLCtrl[rcCtrl4]=((rFLCtrl[rcCtrl4]&(~cBit2))|x<<2))    // KT0724 - 1: drives high; 0: drives
// low
#define  rmAleDriveDQSEn                         (rFLCtrl[rcCtrl4]|=cBit1)
#define  rmAleDriveDQSDis                        (rFLCtrl[rcCtrl4]&=(~cBit1))
#define  rmAleExtendEn                           (rFLCtrl[rcCtrl4]|=cBit0)
#define  rmAleExtendDis                          (rFLCtrl[rcCtrl4]&=(~cBit0))

#define  rcCtrl5                                 0x0089
#define  rmEnAuxCmdQue                           (rFLCtrl[rcCtrl5]|=cBit7)
#define  rmDisAuxCmdQue                          (rFLCtrl[rcCtrl5]&=(~cBit7))
#define  rmChkAuxCmdQue                          (rFLCtrl[rcCtrl5]&cBit7)

#define  rmEnCorrOverStop                        (rFLCtrl[rcCtrl5]|=cBit6)
#define  rmDisCorrOverStop                       (rFLCtrl[rcCtrl5]&=(~cBit6))

#define  rmEnUnCorrErrStop                       (rFLCtrl[rcCtrl5]|=cBit5)    // Read Ecc Fail Stop
#define  rmDisUnCorrErrStop                      (rFLCtrl[rcCtrl5]&=(~cBit5))
#define  rmChkUnCorrErrStop                      (rFLCtrl[rcCtrl5]&(cBit5)>0)

#define  rmDisErrStop                            (rFLCtrl[rcCtrl5]&=0x9F)
#define  rmChkErrStop                            (rFLCtrl[rcCtrl5]&0x60)

#define  rmEnPlaneRetry                          (rFLCtrl[rcCtrl5]|=cBit4)
#define  rmDisPlaneRetry                         (rFLCtrl[rcCtrl5]&=(~cBit4))

#define  rmEnDmaPipe                             (rFLCtrl[rcCtrl5]|=cBit3)
#define  rmDisDmaPipe                            (rFLCtrl[rcCtrl5]&=(~cBit3))
#define  rmEnReadRetry                           (rFLCtrl[rcCtrl5]|=cBit2)
#define  rmDisReadRetry                          (rFLCtrl[rcCtrl5]&=(~cBit2))
#define  rmEnSprSeed                             (rFLCtrl[rcCtrl5]|=cBit1)    // prog seed from cmd queue
#define  rmDisSprSeed                            (rFLCtrl[rcCtrl5]&=(~cBit1))    // prog seed from spr register

#define  rcCtrl6                                 0x008A
#define  rmClrPause                              (rFLCtrl[rcCtrl6]=cBit7)
#define  rmCmdQueResume                          (rFLCtrl[rcCtrl6]=cBit6)
#define  rmSetCmdQueForceStop                    (rFLCtrl[rcCtrl6]=cBit5)
#define  rmClrCmdQueForceStop                    (rFLCtrl[rcCtrl6]=0x00)
#define  rmChSoftReset\
    do\
    {\
        rFLCtrl[rcCtrl6]|=cBit0;\
        setChunkAddr(1);    /* HW bug*/\
    }\
    while(0)

#define  rcCtrl7                                 0x008B
#define  rmEnAleOverInt                          (rFLCtrl[rcCtrl7]|=cBit5)
#define  rmDisAleOverInt                         (rFLCtrl[rcCtrl7]&=(~cBit5))
#define  rmEnCmdFifoFullInt                      (rFLCtrl[rcCtrl7]|=cBit3)
#define  rmDisCmdFifoFullInt                     (rFLCtrl[rcCtrl7]&=(~cBit3))
#define  rmEnTimeOutInt                          (rFLCtrl[rcCtrl7]|=cBit2)
#define  rmDisTimeOutInt                         (rFLCtrl[rcCtrl7]&=(~cBit2))
#define  rmEnCmdInt                              (rFLCtrl[rcCtrl7]|=cBit1)
#define  rmDisCmdInt                             (rFLCtrl[rcCtrl7]&=(~cBit1))
#define  rmEnContrllerInt                        (rFLCtrl[rcCtrl7]|=cBit0)
#define  rmDisContrllerInt                       (rFLCtrl[rcCtrl7]&=(~cBit0))

#define  rcCtrl8                                 0x008C
#define  rmEnOnesCntStop                         (rFLCtrl[rcCtrl8]|=cBit7)
#define  rmDisOnesCntStop                        (rFLCtrl[rcCtrl8]&=(~cBit7))
#define  rmChkOnesCntStop                        (rFLCtrl[rcCtrl8]&0x80)

#define  rcPollStsCnt                            0x008D
#define  rmSetPollStsCnt(Value)                  (rFLCtrl[rcPollStsCnt]=Value)

#define  rcMskCeCnt                              0x008E
#define  rmSetMskCeCnt(Value)                    (rFLCtrl[rcMskCeCnt]=Value)

#define  rcTwhr2                                 0x008F
#define  rmSetTwhr2(Value)                       (rFLCtrl[rcTwhr2]=Value)
#define  rmGetTwhr2                              rFLCtrl[rcTwhr2]

#define  rcDataStopCnt                           0x0090
#define  rmSetDataStopCnt(bits)                  (rFLCtrl[rcDataStopCnt]=bits)

#define  rcSprStopCnt                            0x0091
#define  rmSetSprStopCnt(bits)                   (rFLCtrl[rcSprStopCnt]=bits)

#define  rcOccFlagClrLen                         0x0092
#define  rmSetOccFlagClrLen(Len)                 (rFLCtrl[rcOccFlagClrLen]=Len)
#define  rmErrInjectLength(Len)                  (rFLCtrl[rcOccFlagClrLen]=Len)
#define rmSetRaidMergeEngGrp(Idx)                (rFLCtrl[rcOccFlagClrLen]=Idx)

#define rcOccStartAddr                           0x0094
#define rmOccStartAddr(bufidx)                   (r16FLCtrl[rcOccStartAddr/2]=bufidx)

#define  rcMiscRegister                          0x0094
#define  rmSetMiscReg(x)                         (r16FLCtrl[rcMiscRegister/2]=x)

#define  rcErrInjectPatternL                     0x0096
#define  rcErrInjectPatternH                     0x0097
#define  rmSetErrInjectPattern(x)                (r16FLCtrl[rcErrInjectPatternL/2]=x)

#define  rcFlashTsbWrap0Saddr                    0x00B4
#define  rcFlashTsbWrap0Daddr                    0x00B6
#define  rmSetFlashTsbHead0(head)                (r16FLCtrl[rcFlashTsbWrap0Saddr/2]=head)
#define  rmSetFlashTsbTail0(tail)                (r16FLCtrl[rcFlashTsbWrap0Daddr/2]=tail)

#define  rcFlashTsbWrap1Saddr                    0x00B8
#define  rcFlashTsbWrap1Daddr                    0x00BA
#define  rmSetFlashTsbHead1(head)                (r16FLCtrl[rcFlashTsbWrap1Saddr/2]=head)
#define  rmSetFlashTsbTail1(tail)                (r16FLCtrl[rcFlashTsbWrap1Daddr/2]=tail)

#define  rcFlashTsbWrap2Saddr                    0x00BC
#define  rcFlashTsbWrap2Daddr                    0x00BE
#define  rmSetFlashTsbHead2(head)                (r16FLCtrl[rcFlashTsbWrap2Saddr/2]=head)
#define  rmSetFlashTsbTail2(tail)                (r16FLCtrl[rcFlashTsbWrap2Daddr/2]=tail)

#define  rcTPRE                                  0x00C1
#define  rmSetTpre(value)                        (rFLCtrl[rcTPRE]=value)
#define  rmGetTpre                               rFLCtrl[rcTPRE]
#define  rcDqsTimeOut                            0x00C2
#define  rmDisDqsTimeOut                         (rFLCtrl[rcDqsTimeOut]=0x00)
#define  rcDqsPreamble                           0x00C3
#define  rmSetDqsPreamble(Val)                   (rFLCtrl[rcDqsPreamble]=Val)

#define  rcSprOnesCntThre                        0x00D8
#define  rmDisSprOnesCnt                         (r16FLCtrl[rcSprOnesCntThre/2]=0xFFFF)
#define  rmSetSprOnesCntTh(value)                (r16FLCtrl[rcSprOnesCntThre/2]=value)

#define  rOpIndex                                0x00E1
#define  rmGetOpIndex                            rFLCtrl[rOpIndex]
#define  rmSetOpIndex(value)                     (rFLCtrl[rOpIndex]=value)
#define  rcCmdFifoSts                            0x00E2
#define  rmChkCmdFifoPause                       (rFLCtrl[rcCmdFifoSts]&cBit7)
#define  rmChkCmdFifoStsBusyAbnor                (rFLCtrl[rcCmdFifoSts]&cBit2)
#define  rmChkCmdFifoStsBusy                     (rFLCtrl[rcCmdFifoSts]&cBit1)
#define  rmChkCmdFifoStsFull                     (rFLCtrl[rcCmdFifoSts]&cBit0)
#define  rmClrCmdFifoStsFull                     (rFLCtrl[rcCmdFifoSts]&=~cBit0)

#define  rcEmptyBusy                             0x00E3
#define  mWaitCmdFifoBz\
    while(rFLCtrl[rcEmptyBusy])
#define  rmChkCmdFifoBz                          (rFLCtrl[rcEmptyBusy])

#define  rcCmdQueFull                            0x00EB
#define  rmClrCmdQueFull                         (rFLCtrl[rcCmdQueFull]&=~cBit5)
#define  rmChkCmdQueFull                         (rFLCtrl[rcCmdQueFull]&cBit5)

#define rcCmdFifoDepth                           0x00EC
#define rmChkCmdFifoDpt(x)                       ((r16FLCtrl[rcCmdFifoDepth/2]>x)||!rmChkCmdFifoBz)
#define rmGetCmdFifoDpt                          r16FLCtrl[rcCmdFifoDepth/2]

#define  rcOpIdxCnt                              0x00EE
#define  rmChkIncompleIdxCnt(x)                  (rFLCtrl[rcOpIdxCnt]>x)
#define  rmGetOpIdxCntInFifo                     (rFLCtrl[rcOpIdxCnt])

#define  rcDirectRb                              0x00F4
#define  rmGetDirectRb                           (rFLCtrl[rcDirectRb])

#define  rcDatMaxErrCnt                          0x0114
#define  rcSpareMaxErrCnt                        0x0115
#define  rmGetSprEcc                             rFLCtrl[rcSpareMaxErrCnt]
#define  rcTsbAddr                               0x0116
#define  rmGetFshTsbAddr                         r16FLCtrl[rcTsbAddr/2]
#define  rcEccResultSts                          0x0118
#define  rmGetEccResultSts                       rFLCtrl[rcEccResultSts]
#define  rmResetEccSts                           (r32FLCtrl[rcEccResultSts/4]=0)
#define  rmChkP0EccSts                           (rFLCtrl[rcEccResultSts]&cBit0)
#define  rmChkP1EccSts                           (rFLCtrl[rcEccResultSts]&cBit1)
#define  rmChkP2EccSts                           (rFLCtrl[rcEccResultSts]&cBit2)
#define  rmChkP3EccSts                           (rFLCtrl[rcEccResultSts]&cBit3)
#define  rmChkP0SprEccSts                        (rFLCtrl[rcEccResultSts]&cBit4)
#define  rmChkP1SprEccSts                        (rFLCtrl[rcEccResultSts]&cBit5)
#define  rmChkP2SprEccSts                        (rFLCtrl[rcEccResultSts]&cBit6)
#define  rmChkP3SprEccSts                        (rFLCtrl[rcEccResultSts]&cBit7)
#define  rmSetUNC                                rFLCtrl[rcEccResultSts]|=(0x01<<gPlaneNum-1)
#define  rmSetSprUNC                             rFLCtrl[rcEccResultSts]|=((0x01<<gPlaneNum-1)<<4)
#define  rmGetPlaneUNCBit                        ((rFLCtrl[rcEccResultSts]&0x0F)|((rFLCtrl[rcEccResultSts]&0xF0)>>4))

#define  rcEccCorrectableSts                     0x0119
#define  rmGetEccCorrectableSts                  rFLCtrl[rcEccCorrectableSts]

#define  rcOPResultFlag                          0x011A    // ever status
#define  rmGetOPResultFlag                       rFLCtrl[rcOPResultFlag]
#define  rmChkCorrectableEcc                     (rFLCtrl[rcOPResultFlag]&cBit4)
#define  rmChkStatusFail                         (rFLCtrl[rcOPResultFlag]&cBit3)    // for prog fail & erase fail ref. to 0x52
#define  rmChkSprEccFail                         (rFLCtrl[rcOPResultFlag]&cBit2)    // spare ecc fail
#define  rmChkDataOverTh                         (rFLCtrl[rcOPResultFlag]&cBit1)    // ref. to 0x90
#define  rmChkDataEccFail                        (rFLCtrl[rcOPResultFlag]&cBit0)    // data ecc fail  (#include B2)
#define  rmChkEccFail                            (rFLCtrl[rcOPResultFlag]&(cBit0|cBit2))    // data or spare ecc fail  (#include B2)
#define  rmChkSprOnesCntFail                     (rFLCtrl[rcOPResultFlag]&cBit6)
#define  rmChkOnesCntFail                        (rFLCtrl[rcOPResultFlag]&(cBit6|cBit7))
#define  rmChkDataOnesCntFail                    (rFLCtrl[rcOPResultFlag]&cBit7)
#define  rmChkUNC                                (rFLCtrl[rcOPResultFlag]&(cBit0|cBit2|cBit6|cBit7))
#define  rmSprUNC                                (rFLCtrl[rcOPResultFlag]&(cBit6|cBit2))
#define  rmResetResultFlag                       (r32FLCtrl[rcEccResultSts/4]=0)

#define  rcCurrentStatus                         0x011B    // current status  (ProgFail & erase fail  check this)
#define  rmChkCorrectable                        (rFLCtrl[rcCurrentStatus]&cBit4)
#define  rmChkCurrentStsFail                     (rFLCtrl[rcCurrentStatus]&cBit3)
#define  rmChkUnCorrectable                      (rFLCtrl[rcCurrentStatus]&cBit0)

#define  rcOnceCntstatus                         0x011D
#define  rmResetOnesCnt                          (rFLCtrl[rcOnceCntstatus]=0)
#define  rmGetPlnDataOverOnesCnt                 ((rFLCtrl[rcOnceCntstatus]&0x0F)|((rFLCtrl[rcOnceCntstatus]&0xF0)>>4))

#define  rcDLLAdj                                0x011F
#define  rmSetDllAdjVal(x)                       (rFLCtrl[rcDLLAdj]=x)

#define  rcSpareGpSel                            0x0124    // cpu access  which spare group
#define  rmSelSprGroup(x)                        (rFLCtrl[rcSpareGpSel]=x)

#define  rcLdpcEccErrCntLB                       0x0126
#define  rcLdpcEccErrCntHB                       0x0127
#define  rmGetLdpcEccBit                         r16FLCtrl[rcLdpcEccErrCntLB/2]

#define  rcChunkStartAddr                        0x0128    // new added in SM2260, instead of chunk memory in elder project
#define  rcSparStartAddr                         0x0138
#define  rmSetChunkStartAddr(x, y)               (r16FLCtrl[(rcChunkStartAddr/2)+x]=y)
#define  rmSetSprStartAddr(x)                    (r16FLCtrl[rcSparStartAddr/2]=x)

#define  cSprByteNum                             24
#define  cSprPlaneOffset                         0x001C

#define  rcP0SprSeed                             0x0140
#define  rcSpr0                                  0x0142
#define  rcSpr1                                  0x0143
#define  rcSpr2                                  0x0144
#define  rcSpr3                                  0x0145
#define  rcSpr4                                  0x0146
#define  rcSpr5                                  0x0147
#define  rcSpr6                                  0x0148
#define  rcSpr7                                  0x0149
#define  rcSpr8                                  0x014A
#define  rcSpr9                                  0x014B
#define  rcSpr10                                 0x014C
#define  rcSpr11                                 0x014D
#define  rcSpr12                                 0x014E
#define  rcSpr13                                 0x014F
#define  rcSpr14                                 0x0150
#define  rcSpr15                                 0x0151
#define  rcSpr16                                 0x0152
#define  rcSpr17                                 0x0153
#define  rcSpr18                                 0x0154
#define  rcSpr19                                 0x0155
#define  rcSpr20                                 0x0156
#define  rcSpr21                                 0x0157
#define  rcSpr22                                 0x0158
#define  rcSpr23                                 0x0159

#define  rcP1SprSeed                             0x015C
#define  rcP1Spr0                                0x015E
#define  rcP1Spr1                                0x015F
#define  rcP1Spr2                                0x0160
#define  rcP1Spr3                                0x0161
#define  rcP1Spr4                                0x0162
#define  rcP1Spr5                                0x0163
#define  rcP1Spr6                                0x0164
#define  rcP1Spr7                                0x0165
#define  rcP1Spr8                                0x0166
#define  rcP1Spr9                                0x0167
#define  rcP1Spr10                               0x0168
#define  rcP1Spr11                               0x0169
#define  rcP1Spr12                               0x016A
#define  rcP1Spr13                               0x016B
#define  rcP1Spr14                               0x016C
#define  rcP1Spr15                               0x016D
#define  rcP1Spr16                               0x016E
#define  rcP1Spr17                               0x016F
#define  rcP1Spr18                               0x0170
#define  rcP1Spr19                               0x0171
#define  rcP1Spr20                               0x0172
#define  rcP1Spr21                               0x0173
#define  rcP1Spr22                               0x0174
#define  rcP1Spr23                               0x0175

#define  rcP2SprSeed                             0x0178
#define  rcP2Spr0                                0x017A
#define  rcP2Spr1                                0x017B
#define  rcP2Spr2                                0x017C
#define  rcP2Spr3                                0x017D
#define  rcP2Spr4                                0x017E
#define  rcP2Spr5                                0x017F
#define  rcP2Spr6                                0x0180
#define  rcP2Spr7                                0x0181
#define  rcP2Spr8                                0x0182
#define  rcP2Spr9                                0x0183
#define  rcP2Spr10                               0x0184
#define  rcP2Spr11                               0x0185
#define  rcP2Spr12                               0x0186
#define  rcP2Spr13                               0x0187
#define  rcP2Spr14                               0x0188
#define  rcP2Spr15                               0x0189
#define  rcP2Spr16                               0x018A
#define  rcP2Spr17                               0x018B
#define  rcP2Spr18                               0x018C
#define  rcP2Spr19                               0x018D
#define  rcP2Spr20                               0x018E
#define  rcP2Spr21                               0x018F
#define  rcP2Spr22                               0x0190
#define  rcP2Spr23                               0x0191

#define  rcP3SprSeed                             0x0194
#define  rcP3Spr0                                0x0196
#define  rcP3Spr1                                0x0197
#define  rcP3Spr2                                0x0198
#define  rcP3Spr3                                0x0199
#define  rcP3Spr4                                0x019A
#define  rcP3Spr5                                0x019B
#define  rcP3Spr6                                0x019C
#define  rcP3Spr7                                0x019D
#define  rcP3Spr8                                0x019E
#define  rcP3Spr9                                0x019F
#define  rcP3Spr10                               0x01A0
#define  rcP3Spr11                               0x01A1
#define  rcP3Spr12                               0x01A2
#define  rcP3Spr13                               0x01A3
#define  rcP3Spr14                               0x01A4
#define  rcP3Spr15                               0x01A5
#define  rcP3Spr16                               0x01A6
#define  rcP3Spr17                               0x01A7
#define  rcP3Spr18                               0x01A8
#define  rcP3Spr19                               0x01A9
#define  rcP3Spr20                               0x01AA
#define  rcP3Spr21                               0x01AB
#define  rcP3Spr22                               0x01AC
#define  rcP3Spr23                               0x01AD

#define  cAleFifoCnt                             0x20
#define  rcAleReadPtr                            0x01B0
#define  rcAleReadIdx                            0x01B1
#define  rcAleQSctrAddr                          0x01B4
#define  rcAleQPgAddrLo                          0x01B5
#define  rcAleQPgAddrHi                          0x01B6
#define  rcAleQBlkAddrLo                         0x01B7
#define  rcAleQBlkAddrHi                         0x01B8
#define  rcAleQPlaneAddr                         0x01B9

#define  rcChunkEccStsMap                        0x01C0
#define  rmGetChunkEccStsMap                     r16FLCtrl[rcChunkEccStsMap/2]
#define  rmSetChunkEccStsMap(x)                  (r16FLCtrl[rcChunkEccStsMap/2]=x)
#define  rcChunkEccStsCurrentMap                 0x01C2
#define  rmGetChunkEccStsCurrentMap              r16FLCtrl[rcChunkEccStsCurrentMap/2]

#define  rcChunkEccStsUpdateFlag                 0x01C7
#define  rmGetChunkEccStsUpdateFlag              (rFLCtrl[rcChunkEccStsUpdateFlag]&cBit1)

#define rcChunkPtyExtLen                         0x01D8
#define rmSetChunkPtyExtLen(x, y)                (rFLCtrl[rcChunkPtyExtLen+x]=y)

// 2260 Only Use CeQue0 !!
#define  rcCe0QueSAddr                           0x0200
#define  rcCe0QueEAddr                           0x0202
#define  rcCe1QueSAddr                           0x0204
#define  rcCe1QueEAddr                           0x0206
#define  rcCe2QueSAddr                           0x0208
#define  rcCe2QueEAddr                           0x020A
#define  rcCe3QueSAddr                           0x020C
#define  rcCe3QueEAddr                           0x020E
#define  rcAuxQueSAddr                           0x0210
#define  rcAuxQueEAddr                           0x0212

#define  rmSetCe0SAddr(x)                        (r16FLCtrl[rcCe0QueSAddr/2]=x)
#define  rmSetCe0EAddr(x)                        (r16FLCtrl[rcCe0QueEAddr/2]=x)

#define  rmSetCe1SAddr(x)                        (r16FLCtrl[rcCe1QueSAddr/2]=x)
#define  rmSetCe1EAddr(x)                        (r16FLCtrl[rcCe1QueEAddr/2]=x)

#define  rmSetCe2SAddr(x)                        (r16FLCtrl[rcCe2QueSAddr/2]=x)
#define  rmSetCe2EAddr(x)                        (r16FLCtrl[rcCe2QueEAddr/2]=x)

#define  rmSetCe3SAddr(x)                        (r16FLCtrl[rcCe3QueSAddr/2]=x)
#define  rmSetCe3EAddr(x)                        (r16FLCtrl[rcCe3QueEAddr/2]=x)

#define  rmSetAuxSAddr(x)                        (r16FLCtrl[rcAuxQueSAddr/2]=x)
#define  rmSetAuxEAddr(x)                        (r16FLCtrl[rcAuxQueEAddr/2]=x)

#define  rcFDebug                                0x0239
#define  rmChkFFsmStop                           ((rFLCtrl[rcFDebug]&0xF8)==0xF8)
#define  rmChkFFsmIdle                           ((rFLCtrl[rcFDebug]&0xF8)==0x08)

#define cNopTcwaw                                0x10    // CMD0x85, wait 300ns , ALE-5

#define rcDebugQueRdAddr                         0x0214
#define rmGetCe0QueReadIndex                     r16FLCtrl[rcDebugQueRdAddr/2]

#define rcDebugAUXQueRdAddr                      0x021C
#define rmGetAUXQueReadIndex                     r16FLCtrl[rcDebugAUXQueRdAddr/2]

#endif    // ifndef __REG_FSH_H__

// ECC Address @ 0x5100_1300

// #define  rcLdpcXbusEnale                         0x0000
// #define  rmChkXbusCmdReady                       (rEccDec[rcLdpcXbusEnale]&cBit2)
// #define  rcLdpcXbusCmdBank                       0x0001
// #define  rcLdpcXbusAddr                          0x0004
// #define  rcLdpcXbusReadData                      0x000C
#define  rcDebugDmaLenL                          0x0012
#define  rcDebugDmaLenH                          0x0013

#define  rcLdpcMiscCtl                           0x0014
#define  rmEnLdpcClearDSP                        (rEccDec[rcLdpcMiscCtl]|=cBit1)
#define  rmDisLdpcClearDSP                       (rEccDec[rcLdpcMiscCtl]&=(~cBit1))
#define  rmEnDataOnesCnt                         (rEccDec[rcLdpcMiscCtl]|=cBit3)
#define  rmDisDataOnesCnt                        (rEccDec[rcLdpcMiscCtl]&=(~cBit3))
#define  rmChkDataOnesCnt                        (rEccDec[rcLdpcMiscCtl]&cBit3)
#define  rmEnLdpcSoftRest                        (rEccDec[rcLdpcMiscCtl]|=cBit4)
#define  rmDisLdpcSoftRest                       (rEccDec[rcLdpcMiscCtl]&=(~cBit4))
#define  rmDisLdpcFastDone                       (rEccDec[rcLdpcMiscCtl]&=(~cBit0))
#define  rmEnLdpcFastDone                        (rEccDec[rcLdpcMiscCtl]|=cBit0)
#define  rmLdpcSoftRest                          {rmEnLdpcSoftRest;rmDisLdpcSoftRest;}

#define  rcLdpcMode                              0x0015
#define  rmSetLdpcMode(value)                    (rEccDec[rcLdpcMode]=value)

#define  rcLdpcMiscCtl2                          0x0017
#define  rmChkLdpcReady                          (rEccDec[rcLdpcMiscCtl2]&(cBit3|cBit7))

#define  rcEccTsbWrap0Sadr                       0x0018
#define  rcEccTsbWrap0Dadr                       0x001C
#define  rmSetEccTsbHead0(head)                  (r16EccDec[rcEccTsbWrap0Sadr/2]=head)
#define  rmSetEccTsbTail0(tail)                  (r16EccDec[rcEccTsbWrap0Dadr/2]=tail)

#define  rcEccTsbWrap1Sadr                       0x0020
#define  rcEccTsbWrap1Dadr                       0x0024
#define  rmSetEccTsbHead1(head)                  (r16EccDec[rcEccTsbWrap1Sadr/2]=head)
#define  rmSetEccTsbTail1(tail)                  (r16EccDec[rcEccTsbWrap1Dadr/2]=tail)

#define  rcEccTsbWrap2Sadr                       0x0028
#define  rcEccTsbWrap2Dadr                       0x002C
#define  rmSetEccTsbHead2(head)                  (r16EccDec[rcEccTsbWrap2Sadr/2]=head)
#define  rmSetEccTsbTail2(tail)                  (r16EccDec[rcEccTsbWrap2Dadr/2]=tail)

#define  rcDataOnesCntValue                      0x0032
#define  rmSetDataOnesCntTh(value)               (r16EccDec[rcDataOnesCntValue/2]=value)

#define  rcLdpcDebug                             0x004C
#define rmSetLdpcDebugMode                       (rEccDec[rcLdpcDebug]|=cBit0)
#define rmClrLdpcDebugMode                       (rEccDec[rcLdpcDebug]&=(~cBit0))
#define rmChkLdpcDebugMode                       (rEccDec[rcLdpcDebug]&cBit0)
#define rmSetFshDebugMode                        (rEccDec[rcLdpcDebug]|=cBit1)
#define rmClrFshDebugMode                        (rEccDec[rcLdpcDebug]&=(~cBit1))
#define rmChkFshDebugMode                        (rEccDec[rcLdpcDebug]&cBit1)
#define rmSetForceXfrTsbLdpc                     (rEccDec[rcLdpcDebug]|=cBit7)    // read data to both raid(Ldpc) and tsb
#define rmClrForceXfrTsbLdpc                     (rEccDec[rcLdpcDebug]&=~cBit7)

#define  rcLDPCDecResult                         0x0052
#define  rmGetLDPCSyndWt                         r16EccDec[rcLDPCDecResult/2]

#define rcRaidDecCtl                             0x0054
#define rmChkRaidDecInDone                       (rEccDec[rcRaidDecCtl]&cBit7)
#define rmChkLdpcRaidDecOutDone                  (rEccDec[rcRaidDecCtl]&cBit4)
#define rmTrigLdpcRaidDecOut                     (rEccDec[rcRaidDecCtl]|=cBit0)
#define rmTrigRaidDecOut\
    {rmTrigLdpcRaidDecOut;\
     while(!rmChkLdpcRaidDecOutDone)\
         ;\
    }

#define rcRaidDecStartSect                       0x0055
#define rmSetRaidDecStartSect(index)             (rEccDec[rcRaidDecStartSect]=index)
#define rmClrRaidDecStartSect                    (rEccDec[rcRaidDecStartSect]=0x00)

#define rcRaidDecWantedPage                      0x0056
#define rmSetRaidDecWantedPage(index)            (r16EccDec[rcRaidDecWantedPage/2]=index)
#define rmClrRaidDecWantedPage                   (r16EccDec[rcRaidDecWantedPage/2]=0x0000)

#define rcErrChunkMap                            0x0058
#define rmSetErrChunkMap(errbitmap)              (r16EccDec[rcErrChunkMap/2]=errbitmap)
#define rmClrErrChunkMap                         (r16EccDec[rcErrChunkMap/2]=0x0000)

#define rcRaidDecOutErrChunkMap                  0x005A
#define rmChkRaidDecOutErrChunkMap               r16EccDec[rcRaidDecOutErrChunkMap/2]

#define rcRaidDecCtl2                            0x005F
#define rmSetEarlyTermLdpcDecIn                  (rEccDec[rcRaidDecCtl2]|=cBit0)
#define rmClrEarlyTermLdpcDecIn                  (rEccDec[rcRaidDecCtl2]&=~cBit0)

#define rcLdpcDoutDebug3Low                      0x0080
#define rmChkLdpcDmaSt                           (rEccDec[rcLdpcDoutDebug3Low]&0x07)

#define rcLdpcDoutDebug3High                     0x0081

#define rcEccBitofChunk0                        0x00A0
#define rcEccBitofChunk1                        0x00A2
#define rcEccBitofChunk2                        0x00A4
#define rcEccBitofChunk3                        0x00A6
#define rcEccBitofChunk4                        0x00A8
#define rcEccBitofChunk5                        0x00AA
#define rcEccBitofChunk6                        0x00AC
#define rcEccBitofChunk7                        0x00AE

#define rmGetLdpcChkErrCnt(x)                   (r16EccDec[rcEccBitofChunk0/2+x])

#define rcLdpcInfoFifoSts0                       0x00E0
#define rmChkLdpcInfoFifoReady                   (rEccDec[rcLdpcInfoFifoSts0]&cBit7)    // #define rmChkLdpInfoValid

#define rmChkLdpcInfoFifoEmpty                   (rEccDec[rcLdpcInfoFifoSts0]&cBit2)
#define rmChkLdpcInfoFifoFull                    (rEccDec[rcLdpcInfoFifoSts0]&cBit1)
#define rmPopLdpcInfo                            (rEccDec[rcLdpcInfoFifoSts0]|=cBit0)

#define rcLdpcInfoFifoSts1                       0x00E3
#define rmChkLdpcInfoFifoOverflow                (rEccDec[rcLdpcInfoFifoSts1]&cBit7)
#define rmClrLdpcInfoFifoOverflow                (rEccDec[rcLdpcInfoFifoSts1]|=cBit7)
#define rmChkLdpcInfoFifoUnderflow               (rEccDec[rcLdpcInfoFifoSts1]&cBit6)
#define rmClrLdpcInfoFifoUnderflow               (rEccDec[rcLdpcInfoFifoSts1]|=cBit6)
#define rmResetkLdpcInfoFifo                     (rEccDec[rcLdpcInfoFifoSts1]|=cBit0)

#define rcLdpcErrInfoBitMap                      0x00E4    // #define rcLdpcErrInfo                            0xE4
#define rmGetLdpcErrInfoBitMap                   rEccDec[rcLdpcErrInfoBitMap]    // #define rmGetLdpcErrInfo
//                         rEccDec[rcLdpcErrInfo]

#define rcLdpcErrInfoId                          0x00E6    // #define rcLdpcErrDmaId                           0xE6
#define rmGetLdpcErrInfoId                       (r16EccDec[rcLdpcErrInfoId/2])    // #define rmGetLdpcDecDmaId
//                        r16EccDec[rcLdpcErrDmaId/2]
#define rmGetLdpcDecSrcIdx(x)                    (x&0x007F)
#define rmGetLdpcErrPlaneIdx(x)                  ((x>>7)&0x0003)







