







#include "Common/Model.h"

#ifndef __OPTION_H__
#define __OPTION_H__

#define _FPGA                             (0)    // 0: Real Chip   1:FPGA

#if (!_FW_RELEASE)
#define _DEBUG_COD
#endif

#define _DONTGETPARA                      1
#define _CHK_BASIC_FREQ                   (0)

#ifdef _DEBUG_COD
#define _ICE_DEBUG                        1
#define _ICE_LOAD_ALL                     1
#define _WO_INFOB                         0
#define _TEMP_MARK                        0    // 0:temp mark, 1:not temp mark
#else
#define _ICE_DEBUG                        0
#define _ICE_LOAD_ALL                     0    // 1:ICE Load All use ; 0:Swap code
#define _WO_INFOB                         0
#define _TEMP_MARK                        0    // 0:temp mark, 1:not temp mark
#endif

#ifdef __LTS__
#define _Divide                           (1)    // 1: use HW Divider to do division
#else
#define _Divide                           (1)    // 1: use HW Divider to do division
#endif

#define _SM226X_A0                        (0)    // 2262/2263 A0 temp FW solution, intend to use for temperory workarond and can be removed
#define _BGA_SSD                          (1)    // For 2263 BGA SSD, for PLL_VDD not connect to 1.8V used
// after A1 back
#define _LOAD_OPROM                       (0)
#define _FLASH_TRIG_HOST                  (0)
#define _ENABLE_COMPARE                   (1)
#define _ENABLE_WUNC                      (1)
#define _ENABLE_TRIM                      (1)
#define _EN_TRIM_TIMEOUT                  (0)
#define _ENABLE_WRITE_ZERO                (1)
#define _RR_WORKAROUND                    (0)
#define _2260PCIE_WORKAROUND              (0)
#define _PCIE_FUN_LVL_RST                 (1)
#define _EN_DIFFADDR                      (1)
#define _DCache                           (0)
#define _ICache                           (0)

#define _FW_CTRL_LFCK                     (1)
#define _CR_POLLING                       (1)    // disable CR config auto-clear request function
#define _PHYCHG2_3_KI                     (0)
#define _PHYCHG5_CR                       (0)    // new CR interface workaround
#define _DPHY_11                          (1)    // FW option: when ISA=1, RXPD set to 1
#define _DPHY_14                          (1)    // FW Patch limit EQ2 min time and preset value
#define _DPHY_18                          (1)    // FW Patch : Set KP(TX parameter) and EQ setting for Loopback mode in Gen 3.
#define _DPHY_18_1                        (1)    // FW patch : Only for JBERTB, manually cal EQC EQR TAP123 OFFD
#define _ENABLE_BUS_ERR_HANDLE            (1)    // AXI/AHB/TSB_Like Error Handle enable
#define _TBCOFF_PATCH_OPTION1_EN          (1)
#define _TBCOFF_PATCH_OPTION2_EN          (0)    // Fix TBCOFF skew issue for A1, but we found it may cause some sample drop to 1 lane We
#define _EN_TX_SWING                      (1)    // Modify TX SWING

// disable this function.
#define _FW_HANDLE_L12                    (0)    // 2263 HW auto handle L1.2
#define _PHYCHG4_LTR                      (0)    // Manual LTR
#define _PCIE_D3HOT_D0_LTR_WORKAROUND     (1)
#define _PS3p5                            (0)
#define _PS4_RST_CPU                      (0)
#define _ACER_ESD_ONELANE                 (1)
#define _LDPC_HD_AUTODIV                  (1)    // for LDPC HD high power mode, clock div by 2 to avoid power drop reset
#define _LDPC_SD_AUTODIV                  (0)    // for LDPC SD high power mode, clock div by 2 to avoid power drop reset
#define _SLEEP_CK3                        (0)    // it is mutual exclusive to div4
#define _SLEEP_DIV4                       (1)    // it is mutual exclusive to ck3
#define _CORE1_SLEEP                      (1)

#define _ENABLE_RDWR_FLOW                 (1)    // for test, Bypass Rd/Wr flow
#define _ENABLE_DUMMY_RDWR                (0)
#define _ENABLE_CID_LS                    (1)
#define _ENABLE_NVME_LS                   (1)
#define _ENABLE_NVME_LS_FEAT_SUPPORT_OPT  (1)
#define _ENABLE_PCIE_LS                   (1)
#define _ENABLE_PCIE_LS_FEAT_SUPPORT_OPT  (0)
#define _ENABLE_THRMLTHROTTLING_LS        (1)
#define _ENABLE_SMART_LS                  (1)
#define _ENABLE_THERMAL                   (1)
#define _ENABLE_THERMAL_SYNC_LPF          (1)
#define _ENABLE_NVME_DST                  (1)
#define _ENABLE_NVME_FEAT_TIMESTAMP       (1)
#define _ENABLE_NVME_FEAT_NONOPPWRSTATE   (1)
#define _ENABLE_NVME_FEAT_SWPROGRESS      (1)
#if (OEM==LENOVO)
#define _ENABLE_TELEINITLOG               (1)
#else
#define _ENABLE_TELEINITLOG               (0)    // 20181225_SamHu_02_Dell not support
#endif
#define _ENABLE_SANITIZE                  (1)
#define _ENABLE_DIRECTIVE                 (0)
#define _ENABLE_STREAM                    (0)
#define _EN_BUILD_FWSLOTISPBLK            (1)

#if (!(_GREYBOX||_INITDRAM))
#define _ENABLE_STANDBY_MODE              (1)
#define _ENABLE_NVME_PM                   (1)
#define _ENABLE_NVMEFEAT_APST             (1)
#define _ENABLE_PM_BACKUP_SMART           (1)
#else
#define _ENABLE_NVME_PM                   (0)
#define _ENABLE_NVMEFEAT_APST             (0)
#define _ENABLE_PM_BACKUP_SMART           (0)
#endif

#define _ENABLE_UPDATE_NVMEFEATSETTING_INISR (0)
#define _ENABLE_DASP_LED                  (1)
// #define _ENABLE_SHIFT_INIT_NVME           (1)
#define _EN_PWR_EccOverThrChk             (1)

#define _ENABLE_E2E_PROTECTION            (1)

#if _ENABLE_E2E_PROTECTION
#define _ENABLE_E2E_CMD_RETRY             (1)
#define _ENABLE_E2E_TAB                   (0)
#define _ENABLE_E2E_WHILE                 (0)
#endif

#define _ENABLE_SRAM_ECC_PROTECTION       (1)
#define _WHILE4ECC_ISR                    (1)
#define _ENABLE_SGLS                      (0)

#define _EN_AUTHENTICATION                (1)
// ===========SecurityAPI=======================
#define _ENABLE_SECAPI_SWITCH             1

#if (_ENABLE_SECAPI_SWITCH)
#define _ENABLE_TCG                       (1)    // API use
#define _ENABLE_IEEE1667                  (1)    // API use
#define _ENABLE_SECAPI                    (1)
#define _ENABLE_SECAPI_DEBUG              (0)
#define _ENABLE_SECAPI_R_DEBUG            (0)
#define _ENABLE_SECAPI_W_DEBUG            (0)
#define _ENABLE_SECAPI_PRET               (1)
#define _ENABLE_PYRITE                    (1)
#define _ENABLE_OPALITE                   (1)
#define _ENABLE_ATA_PASSTHROUGH           (_ENABLE_SECAPI&&(1))
#else
#define _ENABLE_TCG                       (0)
#define _ENABLE_IEEE1667                  (0)
#define _ENABLE_SECAPI                    (0)
#define _ENABLE_SECAPI_PRET               (0)
#define _ENABLE_PYRITE                    (0)
#define _ENABLE_OPALITE                   (0)
#define _ENABLE_ATA_PASSTHROUGH           (_ENABLE_SECAPI&&(1))
#endif    // if _ENABLE_SECAPI_SWITCH

#define _ENABLE_TRNG                      (1)
#define _ENABLE_EFUSE                     (0)
#define _ENABLE_AUTHENTICATION            (0)

#define _EN_HMB                           (1)
#define _ENABLE_OCC_FLAG                  (1)
#define _ENABLE_CPU_CYCLE_COUNTER         (1)
#define _DIS_SCP_PLP                      (0)
#if (OEM==DELL)    // 20181010_Jesse_01, Add for Dell spec "ENG0013785_A01"
#define _EN_SCP                           (1)
#define _EN_PLP                           (0)
#define _ENABLE_STANDBY_KEEP_L1           (0)
#define _EN_D3Hot_L12                     (0)    // For Modern standby request,20190121_Eason
#define _EN_D3Hot_PS4                     (1)    // For Modern standby request,20190421_Eason
#elif (OEM==LENOVO)
#define _EN_SCP                           (0)
#define _EN_PLP                           (2)
#define _ENABLE_STANDBY_KEEP_L1           (1)
#define _EN_D3Hot_L12                     (1)    // For Modern standby request,20190121_Eason
#define _EN_D3Hot_PS4                     (0)    // For Modern standby request,20190421_Eason
#elif (OEM==SAMSUNG)
#define _EN_SCP                           (0)
#define _EN_PLP                           (0)
#define _ENABLE_STANDBY_KEEP_L1           (0)
#define _EN_D3Hot_L12                     (1)    // revert En_D3hot_PS4 from 1 for SS_2280
#define _EN_D3Hot_PS4                     (0)    // revert En_D3hot_PS4 from 1 for SS_2280
#else // if (OEM==DELL)
#define _EN_SCP                           (0)
#define _EN_PLP                           (0)
#define _ENABLE_STANDBY_KEEP_L1           (1)
#define _EN_D3Hot_L12                     (1)    // For Modern standby request,20190121_Eason
#define _EN_D3Hot_PS4                     (0)    // For Modern standby request,20190421_Eason
#endif    // if (OEM==DELL)
#define _ENABLE_SCP_PLP                   (_EN_SCP|_EN_PLP)
#define _EN_Delay_Dis_LTSSM               (0)    // PERST delay to Disable LTSSM, wait GC done during GC process

// #define _DEBUG_UART                       (0)
#if (_CODECOVER)
#define _DEBUG_LOG                        (0)
#else
#define _DEBUG_LOG                        (1)
#endif
#define _DEBUG_LOGEXPCIE                  (1)
#define _EN_SAVEEVTLOG                    (1)
#define _TSB_BiCS3                        (0)
#define _TSB_BiCS4                        (1)
#define _SANDISK_3D_GEN2                  (0)    // Bics2
#define _SANDISK_3D_GEN3                  (0)    // Bics3

#define _ENABLE_ERRINJECT                 (0)
#define _ENABLE_NAND_TestReadVth          (0)
#define _ENABLE_ECC_TEAM_TRACKING_MODULE  (1)
#if ((_INITDRAM==1)||_CODECOVER==1)
#define _ENABLE_NAND_UART_DEBUG           (0)
#else
#define _ENABLE_NAND_UART_DEBUG           (0)
#endif

#if _SANDISK_3D_GEN2
#define _ENABLE_DDR525                    (1)
#define _EVB_DDR400                       (0)
#define _ENABLE_RETRY_SANDISK_BiCS2       (1)
#define _ENABLE_SOFTDECODE                (1)
#define _BypassRetryTable                 (0)
#define _En_SoftDecodeFromVth0            (1)
#define _BypassLdpcSoftDecode             (0)
#define _USE_LAST_PASS_VTHTRACKING        (0)
#define _RetryTableContinue               (0)
#if _WO_INFOB
#define _SANDISK_3D_GEN2_Ch0xF            (1)
#else
#define _SANDISK_3D_GEN2_Ch0xF            (0)
#endif
#define _EN_HalfR                         (0)
#define _EN_CacheR                        (1)
#endif    // if _SANDISK_3D_GEN2

#if _SANDISK_3D_GEN3
#define _ENABLE_DDR525                    (1)
#define _EVB_DDR400                       (0)
#define _ENABLE_RETRY_SANDISK_BiCS3       (0)
#define _ENABLE_RETRY_SANDISK_BiCS3_ex3_V12   (1)    // BiCS3_ex3_256Gb_DAT8_Chronus_DRT_V1.2.xlsx
#define _ENABLE_SOFTDECODE                (1)
#define _BypassRetryTable                 (0)
#define _En_SoftDecodeFromVth0            (1)
#define _BypassLdpcSoftDecode             (0)
#define _USE_LAST_PASS_VTHTRACKING        (1)
#define _RetryTableContinue               (1)
#if _WO_INFOB
#define _SANDISK_3D_GEN3_Ch0xF            (1)
#else
#define _SANDISK_3D_GEN3_Ch0xF            (0)
#endif
#define _EN_HalfR                         (0)
#define _EN_CacheR                        (1)
#define _EN_Precmd                        (1)
#define _EN_NAND_TEMP                     (0)
#define _EN_MutiWayCacheRImprove          (0)
#define _EN_WD_ResetCmd_Force_SDR         (0)
#endif    // if _SANDISK_3D_GEN3

#if _TSB_BiCS3
// #define _ENABLE_DDR525                    (1)
#define _EVB_DDR400                       (1)
#define _ENABLE_RETRY_TSB_BiCS3           (1)
#define _ENABLE_SOFTDECODE                (1)
#define _BypassRetryTable                 (0)
#define _En_SoftDecodeFromVth0            (1)
#define _BypassLdpcSoftDecode             (0)
#define _USE_LAST_PASS_VTHTRACKING        (0)
#define _RetryTableContinue               (0)
#if _WO_INFOB
#define _TSB_BiCS3_EVB_Ch0xF              (1)
#else
#define _TSB_BiCS3_EVB_Ch0xF              (1)
#endif
#define _EN_HalfR                         (0)
#define _EN_CacheR                        (1)
#endif    // if _TSB_BiCS3

#if _TSB_BiCS4
// #define _ENABLE_DDR525                    (1)
#define _EVB_DDR400                       (0)
#define _ENABLE_SOFTDECODE                (1)
#define _BypassRetryTable                 (0)
#define _En_SoftDecodeFromVth0            (1)
#define _BypassLdpcSoftDecode             (0)
#define _USE_LAST_PASS_VTHTRACKING        (1)
#define _RetryTableContinue               (1)
#define _EN_NAND_TEMP                     (0)
#define _EN_WD_ResetCmd_Force_SDR         (0)
#define _EN_Fake_ProgramFail_Check        (1)
#define _TSB_BiCS4_WR                     (1)    // Bics4 temporary plan
#define _LiteOn_RR_MdfyDrv                (1)
#if _WO_INFOB
#define _TSB_BiCS3_EVB_Ch0xF              (1)
#else
#define _TSB_BiCS3_EVB_Ch0xF              (0)
#endif
#define _EN_HalfR                         (0)
#define _EN_Precmd                        (1)
#define _EN_CacheR                        (1)
#define _EN_MutiWayCacheRImprove          (0)

#endif    // if _TSB_BiCS4

#define _DEBUG_EasyToREADRECLAIM          (0)

// #define _RANDOM_READ_POST_TRIG            (1)

#if _ICE_LOAD_ALL
#define _ByPassRdLink                     (1)
#else
#define _ByPassRdLink                     (0)
#endif
#define _DEBUG_VPCNT                      (0)
#define _FlushLast2F2h                    (1)
#define _EN_QUICKRBOOT                    (1)
#define _DEBUG_QBOOT                      (0)
// #define _ENABLE_2K_SEGMENT                (1)

#define _ENABLE_SRC_LINK_LIST             (1)    // 0)

#define _EnSpareFunc                      (1)
#define _ENABLE_RAID                      (1)
#if _ENABLE_RAID
#define _EN_RAID_H2F                      (1)
#define _EN_RAID_GC                       (1)
#define _EN_RAID_DECODE                   (1)
#define _EN_RAID_GSD                      (1)
#define _EN_RAID_UGSD                     (1)
#define _EN_RAID_HMB                      (1)
#define _EN_TEST_RAID_DECODE              (0)
#endif
#define _FIX_SLC_Boundary                 (0)
#define _PWSample                         (1)
#define _Enable_Core1                     (1)
#define _ChkDiffMapping                   (0)
#define _BuildIceLoadAllBin               (0)
#define _EN_WPRO_WITH_DIFFTYPE2           (0)    // 1)
#define _EN_CPUCLK575                     (1)
#define _HwPlane2SprIssue                 (1)
#define _ENABLE_HMB_FLUSH                 (_EN_HMB&&0)
#define _ENABLE_LDPCPIPELINE              (1)

#define _EN_H2FSgmtWorkaround             (0)

#define _EN_CPLtimeouttest                (0)    // OscarTsai_20190418 sync SMI CPL timeout test issue code

#define _EN_READRECLAIM                   (1)
#if _ENABLE_RAID
#define _EN_GCPWR                         (0)
#else
#define _EN_GCPWR                         (1)
#endif
#define _BypassEraseFlag                  (1)
#define _EN_EraseFail                     (1)
#define _RetryTableConti                  (0)
#define _EN_BIN_SEARCH                    (1)
#define _EN_FW_DEBUG_UART                 (1)    // 20181031_Bill
#define _EN_PCIE_ERR_HANG                 (0)
#define _EN_PCIE_PATH_REC                 (1)
#define _EN_PCIE_TIME_REC                 (0)
#if _EN_CPLtimeouttest
#define _EN_PCIE_DEBUG                    (1)
#else
#define _EN_PCIE_DEBUG                    (0)
#endif

#define _EN_DEBUGF2H                      (0)
#define _EN_DEBUGDECVPC                   (0)
#define _EN_NVMEWRDUALENGINE              (0)
#define _EN_NVMERDDUALENGINE              (1)
#define _EN_SEQRSGMTTAB                   (1)
#define _EN_PATCH_SM2263AA                (0)
#if !_EN_PATCH_SM2263AA
#define _EN_HMBDWORDMO                    (0)
#endif
#define _EN_WRHWPRDCORE1                  (1)
#define _EN_MAGICCODE                     (1)
#define _EN_Dynamic_Fix_Boundary          (1)
#define _EN_CACHEPROG                     (1)
#define _EN_BgdGc                         (1)
#define _EN_SLC_END_PARA                  (_SANDISK_3D_GEN3&&_FIX_SLC_Boundary&&1)
#define _EN_FLASH_WR_CMD                  (_SANDISK_3D_GEN3&&_FIX_SLC_Boundary&&1)
#define _EN_Always_DynamicMode           (_TSB_BiCS4&&_EN_Dynamic_Fix_Boundary&&1)
#define _EN_PROGFAILLOG                   (1)
#define _EN_PROGFAILRECOV                 (0)
#define _EN_SLCOpenBlkReadScrub           (1)
#define _EN_RDLINK_PF                     (0)    // partial flush in rdlink
#define _EN_IDLEGC_DELAY                  (1)
#define _DEBUG_DEADLOCK                   (1)
#if ((PRODUCT_NAME&0x0008)==0x0008)
#define _EN_VPC_SWAP                      (1)
#define _ENABLE_RETRY_TSB_BiCS4_256Gb     (0)
#define _ENABLE_RETRY_TSB_BiCS4_512Gb     (1)
#else
#define _EN_VPC_SWAP                      (0)
#define _ENABLE_RETRY_TSB_BiCS4_256Gb     (1)
#define _ENABLE_RETRY_TSB_BiCS4_512Gb     (0)
#endif
#if (_TSB_BiCS4_WR)
#define _EN_WDT                           (0)
#else
#define _EN_WDT                           (1)
#endif
#if (_INITDRAM||_GREYBOX||_CODECOVER)
#define _EN_CHRONUS_UART_DEBUG            (0)
#else
#define _EN_CHRONUS_UART_DEBUG            (1)
#endif

#if (_PRJ_BOOT1||_PRJ_BOOT2)
#define _PRJ_BOOT                         (1)
#else
#define _PRJ_BOOT                         (0)
#endif

#define _EN_CHK_FINGER_FAIL               (1)
#if (OEM==VERIFY)
#define _EN_KEEP_RW_ON_ERROR              (0)
#define _EN_DisHMBInReset                 (0)    // 20190808_Bruce
#define _EN_RWEND_NOGC                    (0)    // 20190508_ChrisSu_02
#define _EN_EarlyBdGC                     (1)
#define _EN_CmdDelayBGC                   (1)
#else
#define _EN_KEEP_RW_ON_ERROR              (1)
#define _EN_DisHMBInReset                 (0)    // 20190808_Bruce
#define _EN_RWEND_NOGC                    (0)
#define _EN_EarlyBdGC                     (0)
#define _EN_CmdDelayBGC                   (0)

#endif
#define _EN_PERST_WAKEINLOWPOWER          (1)
#define _EN_FeatTempThresh_Debug          (0)    // temp add for debug _Chief_20181224
#define _EN_FeatTempThresh_Return_Sensor1 (0)    // SamHu_20190411_01

#define _EN_Liteon_ErrHandle              (1)    // for liteon error handle 20190305_Louis

#define DEBUG_Bill_FTL                    (0)    // Bill_20181114
#define _EN_LiteonRetryLog                (1)    // Bill_20190125
#define _EN_WUNCTable                     (1)    // WUNCTable Chief_21081121
#if _EN_WUNCTable
#define _EN_WuncInNand                    (1)
#endif
#define _EN_WriteZeroNonAlign             (1)    // WriteZeroNonAlign_20181031_Chief
#define WZ_debug                          (0)
#define WUNC_debug                        (0)
#define _EN_PopBlk0                       (1)    // Chief_20190104
#define _EN_BICS4_2048BLK                                 (1)
#define Power_slcQoverflow                (1)
#define CC_EN_EARLY                       (1)    // Eason_20190125
#define _EN_E2ENonCRCChk                  (1)    // Oscar_20190220
#define _EN_512Gb_Debug                   (1)    // Louis_20190521
#define _EN_SKIPGC10MIN                   (0)    // 20190806_ChrisSu

#if (OEM==SAMSUNG&&((PRODUCT_NAME&FF_M2_2280SS)==FF_M2_2280SS))    // 20191220_ChrisSu
#define _EN_LS_CACHER                     (1)
#else
#define _EN_LS_CACHER                     (0)
#endif

#if ((OEM==VERIFY)||(OEM==STD))
#define _EN_D3Hot_DisPS34                 (1)    // For eDevx Script, Set PS34 to D3hot fail,20190626_Eason
#else
#define _EN_D3Hot_DisPS34                 (0)    // For eDevx Script, Set PS34 to D3hot fail,20190626_Eason
#endif

#define _EN_ChkCpuErr_Debug               (0)
#define APST_Timer                        (1)    // 20190604_LeverYu_APST
#define ModernStandby_Dis3mW              (1)    //  1: MS test >3mW , 0: MS test <3mW

#if (OEM!=VERIFY)    // 20190723_SamHu_01
#define _EN_FWCommit_Protect              (1)    // SamHu_20190418
#else
#define _EN_FWCommit_Protect              (0)
#endif

#if (OEM==DELL)
#define S_SpeedUPSLCProg                  (1)    // ChrisSu_20190109
#define _EN_CDMTRIG                       (1)
#define _EN_LenovoPFail                   (0)
#define _EN_BgdT2tClnCdm                  (0)
#define _EN_RTUpdateH2F_HMB               (0)

#if _EN_VPC_SWAP
#define _EN_IOMTRIG                       (1)
#else
#define _EN_IOMTRIG                       (0)
#endif
#define _EN_SHN_SUPPORT_CMD               (1)    // Bill_20190517
#define _EN_Lenovo_RecoveryChk            (0)
#define _EN_External_CDM                  (0)

#elif (OEM==LENOVO)    // Chief_20190129
#define S_SpeedUPSLCProg                  (0)
#define _EN_CDMTRIG                       (0)
#define _EN_LenovoPFail                   (1)
#define _EN_BgdT2tClnCdm                  (1)    // ChrisSu_20190329  sync SMI S0322B
#define _EN_RTUpdateH2F_HMB               (1)
#define _EN_IOMTRIG                       (0)
#define _EN_SHN_SUPPORT_CMD               (0)    // Bill_20190517
#define _EN_Lenovo_RecoveryChk            (1)    // Bruce_20190524 for Lenovo Performance Recovery Check Test
#define _EN_External_CDM                  (0)

#elif (OEM==ASUS)

#define S_SpeedUPSLCProg                  (1)
#define _EN_CDMTRIG                       (1)
#define _EN_LenovoPFail                   (1)
#define _EN_BgdT2tClnCdm                  (0)
#define _EN_RTUpdateH2F_HMB               (0)
#define _EN_IOMTRIG                       (0)
#define _EN_SHN_SUPPORT_CMD               (0)    // Bill_20190517
#define _EN_External_CDM                  (1)    // 20190724_ChrisSu_2

#else // if (OEM==DELL)

#define S_SpeedUPSLCProg                  (1)
#define _EN_CDMTRIG                       (1)
#define _EN_LenovoPFail                   (1)
#define _EN_BgdT2tClnCdm                  (0)
#define _EN_RTUpdateH2F_HMB               (0)
#define _EN_IOMTRIG                       (0)
#define _EN_SHN_SUPPORT_CMD               (0)    // Bill_20190517
#define _EN_Lenovo_RecoveryChk            (0)
#define _EN_External_CDM                  (0)
#endif    // if (OEM==DELL)
#define S_NvmeQRWT_timeout                (1)    // ChiefLin_20190329  sync SMI S0322A
#endif    // ifndef __OPTION_H__







