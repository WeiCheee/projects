







#ifndef __REG_TRNG_H__
#define __REG_TRNG_H__

#define rcRngImr                                 0x00
#define rcRngIsr                                 0x02

#define rmRngIsr                                 rTrngCtrl[rcRngIsr]
#define rmDisAllRngInt                           rTrngCtrl[rcRngImr]=0x0F

#define rcRngSts                                 0x3C
#define rmRngValid                               (rTrngCtrl[rcRngSts]&0x01)

#define rcEhrValid15                             0x1B
#define rcEhrValid14                             0x1A
#define rcEhrValid13                             0x19
#define rcEhrValid12                             0x18
#define rcEhrValid11                             0x17
#define rcEhrValid10                             0x16
#define rcEhrValid9                              0x15
#define rcEhrValid8                              0x14
#define rcEhrValid7                              0x13
#define rcEhrValid6                              0x12
#define rcEhrValid5                              0x11
#define rcEhrValid4                              0x10
#define rcEhrValid3                              0x0F
#define rcEhrValid2                              0x0E
#define rcEhrValid1                              0x0D
#define rcEhrValid0                              0x0C

#define rcRndSrcEn                               0x24
#define rmRngSrcEn                               (rTrngCtrl[rcRndSrcEn]=0x01)
#define rmRngSrcDis                              (rTrngCtrl[rcRndSrcEn]=0x00)

#define rcTrngSmapleCnt                          0x28
#define rmSetTrngSmapleCnt(sample)               (r32TrngCtrl[rcTrngSmapleCnt/4]=sample)

#define rcSampleCnt3                             0x2B
#define rcSampleCnt2                             0x2A
#define rcSampleCnt1                             0x29
#define rcSampleCnt0                             0x28
#define rmSampleCnt                              r32TrngCtrl[rcSampleCnt0/4]

#define rcAcorSta2                               0x2E
#define rcAcorSta1                               0x2D
#define rcAcorSta0                               0x2C

#define rcRngBypass                              0x30
#define rmRngTestBypass                          rTrngCtrl[rcRngBypass]

#define rcRngSwRst                               0x34
#define rmRngSoftRst                             (rTrngCtrl[rcRngSwRst]=1)

#define rcRngSts0                                0x3C
#define rcRngSts1                                0x3D
#define rcRngSts2                                0x3E

#define rmMaskEhrValid                           (rTrngCtrl[rcRngImr]|=0x01)
#define rmClrMaskEhrValid                        (rTrngCtrl[rcRngImr]&=0xfe)

#define rmRngClrVec                              (rTrngCtrl[0x06]=0x01)

#endif    // ifndef __REG_TRNG_H__







