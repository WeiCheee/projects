







#ifndef __REG_SYSCTRL_H__
#define __REG_SYSCTRL_H__

// #include "inc/GlobVar0.h"

// System controller  Register PW0@ 0x5000_0000
#define  rcSysContrl0                            0x00
#define  rmChkTestMode                           (rSysCtrl0[rcSysContrl0]&cBit6)

#define  rcSysContrl1                            0x01
#define  rmEnSysBop2Ccm                          (rSysCtrl0[rcSysContrl1]=(rSysCtrl0[rcSysContrl1]&0xFC)|0x03)
#define  rmEnBop2Iccm                            (rSysCtrl0[rcSysContrl1]=(rSysCtrl0[rcSysContrl1]&0xFC)|0x03)
#define  rmEnBop2Dccm                            (rSysCtrl0[rcSysContrl1]=(rSysCtrl0[rcSysContrl1]&0xFC)|0x03)
#define  rmEnSpi2Iccm                            (rSysCtrl0[rcSysContrl1]=(rSysCtrl0[rcSysContrl1]&0xFC))

#define  rcSelMulRdCh                            0x02
#define  rmSelMulRdCh(map)\
    {rSysCtrl0[rcSelMulRdCh]=map;\
     while(rSysCtrl0[rcSelMulRdCh]!=map)\
         ;\
    }                                                                                                               // (rSysCtrl0[rcSelMulRdCh]=map)

#define  rcSelMulFlash                           0x03
#define  rmSelMulFlash(map)\
    {rSysCtrl0[rcSelMulFlash]=map;\
     while(rSysCtrl0[rcSelMulFlash]!=map)\
         ;\
    }                                                                                                                 // (rSysCtrl0[rcSelMulFlash]=map)

#define  rcPcieSrstQ                             0x04
#define  rmPclkPolarSelClr                       (rSysCtrl0[rcPcieSrstQ]&=(~cBit4))
#define  rmPclkPolarSelSet                       (rSysCtrl0[rcPcieSrstQ]|=cBit4)
#define  rmSetStickyRst                          (rSysCtrl0[rcPcieSrstQ]&=(~cBit2))
#define  rmClrStickyRst                          (rSysCtrl0[rcPcieSrstQ]|=cBit2)
#define  rmSetNonStickyRst                       (rSysCtrl0[rcPcieSrstQ]&=(~cBit1))
#define  rmClrNonStickyRst                       (rSysCtrl0[rcPcieSrstQ]|=cBit1)
#define  rmSetCoreRst                         (rSysCtrl0[rcPcieSrstQ]&=(~cBit0))
#define  rmClrCoreRst                         (rSysCtrl0[rcPcieSrstQ]|=cBit0)

#define  rcCryPadCtrl                            0x05
#define  rmClrSysCryPadPd                        (rSysCtrl0[rcCryPadCtrl]|=cBit7)
#define  rmSetSysCryPadPd                        (rSysCtrl0[rcCryPadCtrl]&=(~cBit7))
#define  rmSetPhyRst                          (rSysCtrl0[rcCryPadCtrl]&=(~cBit6))
#define  rmClrPhyRst                          (rSysCtrl0[rcCryPadCtrl]|=cBit6)
#define  rmSysXtalDiv1                           (rSysCtrl0[rcCryPadCtrl]=(rSysCtrl0[rcCryPadCtrl]&0xCF)|0x00)
#define  rmSysXtalDiv4                           (rSysCtrl0[rcCryPadCtrl]=(rSysCtrl0[rcCryPadCtrl]&0xCF)|0x10)
#define  rmSysXtalDiv16                          (rSysCtrl0[rcCryPadCtrl]=(rSysCtrl0[rcCryPadCtrl]&0xCF)|0x20)
#define  rmSysXtalDiv128                         (rSysCtrl0[rcCryPadCtrl]=(rSysCtrl0[rcCryPadCtrl]&0xCF)|0x30)
#define  rmSysSetCk3Div(x)                       (rSysCtrl0[rcCryPadCtrl]=(rSysCtrl0[rcCryPadCtrl]&0xCF)|x)
#define  rmGetSysXtalDiv                         ((rSysCtrl0[rcCryPadCtrl]&0x30)>>4)
#define  rmSysSetPcieDphyRst                     (rSysCtrl0[rcCryPadCtrl]&=(~cBit3))
#define  rmSysClrPcieDphyRst                     (rSysCtrl0[rcCryPadCtrl]|=cBit3)
#define  rmSysSetPw1Rst                          (rSysCtrl0[rcCryPadCtrl]&=(~cBit2))
#define  rmSysClrPw1Rst                          (rSysCtrl0[rcCryPadCtrl]|=cBit2)
#define  rmSysSetSpiRst                          (rSysCtrl0[rcCryPadCtrl]&=(~cBit1))
#define  rmSysClrSpiRst                          (rSysCtrl0[rcCryPadCtrl]|=cBit1)
#define  rmSysSetPwrCtrlRst                      (rSysCtrl0[rcCryPadCtrl]&=(~cBit0))
#define  rmSysClrPwrCtrlRst                      (rSysCtrl0[rcCryPadCtrl]|=cBit0)

#define  rcHwPwrdnTimeoutValL                    0x06
#define  rmSetExPwdnTimer(x)                     (r16SysCtrl0[rcHwPwrdnTimeoutValL/2]=x)

#define  rcClkCtrl0                              0x08
#define  rmAllClkOn                              {r32SysCtrl0[rcClkCtrl0/4]&=0xFFF80000;rmDisableClkGate;}
// #define  rmAllClkOff                           {r32SysCtrl0[rcClkCtrl0/4]|=0x0007ffff; rmEnableClkGate;}
#define  rmAllClkOff                             {r32SysCtrl0[rcClkCtrl0/4]|=0x000D00DF;rSysCtrl0[rcClkCtrl3]|=0xFE;rmEnableClkGate;}
// #define  rmEnDramClkGate                         (rSysCtrl0[rcClkCtrl0]|=cBit7)
// #define  rmDisDramClkGate                        (rSysCtrl0[rcClkCtrl0]&=(~cBit7))
#define  rmDisSysDivChkCfg                       (rSysCtrl0[rcClkCtrl0]|=cBit7)
#define  rmEnSysDivChkCfg                        (rSysCtrl0[rcClkCtrl0]&=(~cBit7))
#define  rmEnEncClkAGate                         (rSysCtrl0[rcClkCtrl0]|=cBit6)
#define  rmDisEncClkAGate                        (rSysCtrl0[rcClkCtrl0]&=(~cBit6))
// #define  rmEnNvmeClkGate                         (rSysCtrl0[rcClkCtrl0]|=cBit5)
// #define  rmDisNvmeClkGate                        (rSysCtrl0[rcClkCtrl0]&=(~cBit5))
#define  rmEnSysClkGate                          (rSysCtrl0[rcClkCtrl0]|=cBit4)
#define  rmDisSysClkGate                         (rSysCtrl0[rcClkCtrl0]&=(~cBit4))
#define  rmEnAesClkGate                          (rSysCtrl0[rcClkCtrl0]|=cBit3)
#define  rmDisAesClkGate                         (rSysCtrl0[rcClkCtrl0]&=(~cBit3))
#define  rmDisCk0ChkIdle                         (rSysCtrl0[rcClkCtrl0]|=cBit2)    // checked
#define  rmEnCk0ChkIdle                          (rSysCtrl0[rcClkCtrl0]&=(~cBit2))    // if be 1, CPU idle force sys clk div whatever sys idle
// or not
#define  rmSysEnBchDecClkAGate                   (rSysCtrl0[rcClkCtrl0]|=cBit1)
#define  rmSysDisBchDecClkAGate                  (rSysCtrl0[rcClkCtrl0]&=(~cBit1))
#define  rmSetCk0BusIdleDivSel1                  (rSysCtrl0[rcClkCtrl0]|=cBit0)
#define  rmClrCk0BusIdleDivSel1                  (rSysCtrl0[rcClkCtrl0]&=(~cBit0))
#define  rmGetSysClkCtl0                         rSysCtrl0[rcClkCtrl0]
#define  rmSetSysClkCtl0(x)                      (rSysCtrl0[rcClkCtrl0]=x)

#define  rcClkCtrl1                              0x09
#define  rmSysEnFsh7ClkGate                      (rSysCtrl0[rcClkCtrl1]|=cBit7)
#define  rmSysDisFsh7ClkGate                     (rSysCtrl0[rcClkCtrl1]&=(~cBit7))
#define  rmSysEnFsh6ClkGate                      (rSysCtrl0[rcClkCtrl1]|=cBit6)
#define  rmSysDisFsh6ClkGate                     (rSysCtrl0[rcClkCtrl1]&=(~cBit6))
#define  rmSysEnFsh5ClkGate                      (rSysCtrl0[rcClkCtrl1]|=cBit5)
#define  rmSysDisFsh5ClkGate                     (rSysCtrl0[rcClkCtrl1]&=(~cBit5))
#define  rmSysEnFsh4ClkGate                      (rSysCtrl0[rcClkCtrl1]|=cBit4)
#define  rmSysDisFsh4ClkGate                     (rSysCtrl0[rcClkCtrl1]&=(~cBit4))
#define  rmSysEnFsh3ClkGate                      (rSysCtrl0[rcClkCtrl1]|=cBit3)
#define  rmSysDisFsh3ClkGate                     (rSysCtrl0[rcClkCtrl1]&=(~cBit3))
#define  rmSysEnFsh2ClkGate                      (rSysCtrl0[rcClkCtrl1]|=cBit2)
#define  rmSysDisFsh2ClkGate                     (rSysCtrl0[rcClkCtrl1]&=(~cBit2))
#define  rmSysEnFsh1ClkGate                      (rSysCtrl0[rcClkCtrl1]|=cBit1)
#define  rmSysDisFsh1ClkGate                     (rSysCtrl0[rcClkCtrl1]&=(~cBit1))
#define  rmSysEnFsh0ClkGate                      (rSysCtrl0[rcClkCtrl1]|=cBit0)
#define  rmSysDisFsh0ClkGate                     (rSysCtrl0[rcClkCtrl1]&=(~cBit0))
#define  rmEnFlashClkAutoGate                    (rSysCtrl0[rcClkCtrl1]=0xFF)
#define  rmDisFlashClkAutoGate                   (rSysCtrl0[rcClkCtrl1]=0x00)
#define  rmChkFlashClkAutoGate                   (rSysCtrl0[rcClkCtrl1]&0xFF)    // ==0xFF)
#define  rmEnFLClkGate(x)                        (rSysCtrl0[rcClkCtrl1]|=cb32BitTab[x])
#define  rmDisFLClkGate(x)                       (rSysCtrl0[rcClkCtrl1]&=(~cb32BitTab[x]))

#define  rcClkCtrl2                              0x0A
#define  rmEnBusIdleClkDiv                       (rSysCtrl0[rcClkCtrl2]|=cBit7)
#define  rmDisBusIdleClkDiv                      (rSysCtrl0[rcClkCtrl2]&=(~cBit7))
#define  rmSetCk0BusIdleDivSel                   (rSysCtrl0[rcClkCtrl2]|=cBit6)
#define  rmClrCk0BusIdleDivSel                   (rSysCtrl0[rcClkCtrl2]&=(~cBit6))
#define  rmBusIdleClkDiv16                       {rmSetCk0BusIdleDivSel1;rmSetCk0BusIdleDivSel;}
#define  rmBusIdleClkDiv8                        {rmSetCk0BusIdleDivSel1;rmClrCk0BusIdleDivSel;}
#define  rmBusIdleClkDiv4                        {rmClrCk0BusIdleDivSel1;rmSetCk0BusIdleDivSel;}
#define  rmBusIdleClkDiv2                        {rmClrCk0BusIdleDivSel1;rmClrCk0BusIdleDivSel;}
#define  rmEnClk8Dsp                             (rSysCtrl0[rcClkCtrl2]|=cBit5)
#define  rmDisClk8Dsp                            (rSysCtrl0[rcClkCtrl2]&=(~cBit5))
#define  rmChkClk8Dsp                            (rSysCtrl0[rcClkCtrl2]&cBit5)
#define  rmEnBchDecClkDiv2                       (rSysCtrl0[rcClkCtrl2]|=cBit4)
#define  rmDisBchDecClkDiv2                      (rSysCtrl0[rcClkCtrl2]&=(~cBit4))
#define  rmEnSysClkDiv2                          (rSysCtrl0[rcClkCtrl2]|=cBit3)
#define  rmDisSysClkDiv2                         (rSysCtrl0[rcClkCtrl2]&=(~cBit3))
#define  rmEnBopClkAGate                         (rSysCtrl0[rcClkCtrl2]|=cBit2)
#define  rmDisBopClkAGate                        (rSysCtrl0[rcClkCtrl2]&=(~cBit2))
#define  rmEnXtalCpuIdleGate                     (rSysCtrl0[rcClkCtrl2]|=cBit1)
#define  rmDisXtalCpuIdleGate                    (rSysCtrl0[rcClkCtrl2]&=(~cBit1))
#define  rmEnFshPllClkGate                       (rSysCtrl0[rcClkCtrl2]|=cBit0)
#define  rmDisFshPllClkGate                      (rSysCtrl0[rcClkCtrl2]&=(~cBit0))

#define  rcHwVersion                              0x0B
#define  rmGetHwVersion                           rSysCtrl0[rcHwVersion]

// Use O8_Sio_Sel b7 ~ b4 for ROM and ISP communication bridge
// FW use register that not be use by HW to record some information
// b[4]  : SoftwareReset     ==1, don't do some SATA initilize
// b[5]  : FWCommitPEIsr     ==1, ISP need to handle a pending perst
// b[6]  : SoftwareForceROM  ==1, Force to stead ROM code mode
// b[7]  : DramSetReady      ==1, don't double setting DRAM
#define  rcSioSel                                0x0C
#define  rmUartEn                                (rSysCtrl0[rcSioSel]|=cBit0)
#define  rmUartDis                               (rSysCtrl0[rcSioSel]&=(~cBit0))
#define  rmPhyClkReqEn                           (rSysCtrl0[rcSioSel]|=cBit1)
#define  rmPhyClkReqDis                          (rSysCtrl0[rcSioSel]&=(~cBit1))
#define  rmSetSoftwareReset                      (rSysCtrl0[rcSioSel]|=cBit4)
#define  rmClrSoftwareReset                      (rSysCtrl0[rcSioSel]&=(~cBit4))
#define  rmChkSoftwareReset                      (rSysCtrl0[rcSioSel]&cBit4)
#define  rmSetFwCommitPeIsr                      (rSysCtrl0[rcSioSel]|=cBit5)
#define  rmClrFwCommitPeIsr                      (rSysCtrl0[rcSioSel]&=(~cBit5))
#define  rmChkFwCommitPeIsr                      (rSysCtrl0[rcSioSel]&cBit5)
#define  rmSetSoftwareForceRom                   (rSysCtrl0[rcSioSel]|=cBit6)
#define  rmClrSoftwareForceRom                   (rSysCtrl0[rcSioSel]&=(~cBit6))
#define  rmChkSoftwareForceRom                   (rSysCtrl0[rcSioSel]&cBit6)
#define  rmSetDramSetReady                       (rSysCtrl0[rcSioSel]|=cBit7)
#define  rmClrDramSetReady                       (rSysCtrl0[rcSioSel]&=(~cBit7))
#define  rmChkDramSetReady                       (rSysCtrl0[rcSioSel]&cBit7)

#define  rcPcieGen                               0x0D
// #define  rmSetPcieGen1                         (rSysCtrl0[rcPcieGen]=0x00)
// #define  rmSetPcieGen2                         (rSysCtrl0[rcPcieGen]=0x01)
// #define  rmSetPcieGen3                         (rSysCtrl0[rcPcieGen]=0x02)

#define  rcClkCtrl3                              0x0E
#define  rmSysEnLdpcClkAutoGate2                 (rSysCtrl0[rcClkCtrl3]|=cBit7)
#define  rmSysDisLdpcClkAutoGate2                (rSysCtrl0[rcClkCtrl3]&=(~cBit7))
#define  rmSysChkLdpcClkAutoGate2                (rSysCtrl0[rcClkCtrl3]&cBit7)
// #define  rmSysEnLdpcClkGate                    (rSysCtrl0[rcClkCtrl3]|=cBit6)
// #define  rmSysDisLdpcClkGate                   (rSysCtrl0[rcClkCtrl3]&=(~cBit6))
// #define  rmSysEnRaidClkGate                    (rSysCtrl0[rcClkCtrl3]|=cBit5)
// #define  rmSysDisRaidClkGate                   (rSysCtrl0[rcClkCtrl3]&=(~cBit5))
#define rmSysEnFakeClkGate                       (rSysCtrl0[rcClkCtrl3]&=(~cBit5))
#define rmSysDisFakeClkGate                      (rSysCtrl0[rcClkCtrl3]|=cBit5)

#define  rmSysChkRaidClkAutoGate                 (rSysCtrl0[rcClkCtrl3]&(cBit4|cBit2|cBit1))
#define  rmSysEnRaidClkAutoGate2                 (rSysCtrl0[rcClkCtrl3]|=(cBit4|cBit2|cBit1))
#define  rmSysDisRaidClkAutoGate2                (rSysCtrl0[rcClkCtrl3]&=((~cBit4)&(~cBit2)&(~cBit1)))

#define  rmSysEnRaidClkAutoGate                  (rSysCtrl0[rcClkCtrl3]|=cBit4)
#define  rmSysDisRaidClkAutoGate                 (rSysCtrl0[rcClkCtrl3]&=(~cBit4))
#define  rmSysSetCk4DivCntRst                    (rSysCtrl0[rcClkCtrl3]|=cBit3)
#define  rmSysClrCk4DivCntRst                    (rSysCtrl0[rcClkCtrl3]&=(~cBit3))
#define  rmSysEnRaidEncClkAutoGate               (rSysCtrl0[rcClkCtrl3]|=cBit2)
#define  rmSysDisRaidEncClkAutoGate              (rSysCtrl0[rcClkCtrl3]&=(~cBit2))
#define  rmSysEnRaidDecClkAutoGate               (rSysCtrl0[rcClkCtrl3]|=cBit1)
#define  rmSysDisRaidDecClkAutoGate              (rSysCtrl0[rcClkCtrl3]&=(~cBit1))
#define  rmSysEnLdpcAutoClkDiv                   (rSysCtrl0[rcClkCtrl3]|=cBit0)
#define  rmSysDisLdpcAutoClkDiv                  (rSysCtrl0[rcClkCtrl3]&=(~cBit0))

// Use O8_TrngClkDivSel b7 ~ b3 for ROM and ISP communication bridge
// FW use register that not be use by HW to record some information
// b[3]  : DebugLocked      =1,default value need to check security flow when Prod flag set
// =0,device be unlock by superlightswitch in ROM
// b[4]  : Reserved
// b[5]  : Reserved
// b[6]  : Reserved
// b[7]  : Reserved
#define  rcTrngClkDivSel                         0x0F
#define  rmTrngClkDiv1                           (rSysCtrl0[rcTrngClkDivSel]=(rSysCtrl0[rcTrngClkDivSel]&0xF8)|0x00))
#define  rmTrngClkDiv16                          (rSysCtrl0[rcTrngClkDivSel]=(rSysCtrl0[rcTrngClkDivSel]&0xF8)|0x01))
#define  rmTrngClkDiv32                          (rSysCtrl0[rcTrngClkDivSel]=(rSysCtrl0[rcTrngClkDivSel]&0xF8)|0x02))
#define  rmTrngClkDiv64                          (rSysCtrl0[rcTrngClkDivSel]=(rSysCtrl0[rcTrngClkDivSel]&0xF8)|0x03))
#define  rmTrngClkDiv128                         (rSysCtrl0[rcTrngClkDivSel]=(rSysCtrl0[rcTrngClkDivSel]&0xF8)|0x04))
#define  rmTrngClkDiv256                         (rSysCtrl0[rcTrngClkDivSel]=(rSysCtrl0[rcTrngClkDivSel]&0xF8)|0x05))
#define  rmTrngClkDiv512                         (rSysCtrl0[rcTrngClkDivSel]=(rSysCtrl0[rcTrngClkDivSel]&0xF8)|0x06))
#define  rmTrngClkDiv1024                        (rSysCtrl0[rcTrngClkDivSel]=(rSysCtrl0[rcTrngClkDivSel]&0xF8)|0x07))
// #define  rmSetDebugLocked                      (rSysCtrl0[rcTrngClkDivSel]|=cBit3)
// #define  rmClrDebugLocked                      (rSysCtrl0[rcTrngClkDivSel]&=(~cBit3))
#define  rmChkDebugLocked                        (rSysCtrl0[rcTrngClkDivSel]&cBit3)

#define  rcPorCtrl                               0x10
#define  rmSysExVdtGood                          (rSysCtrl0[rcPorCtrl]&cBit7)
#define  rmSysExVdtFail                          (!rmSysExVdtGood)
#define  rmSysEnExVdt                            (rSysCtrl0[rcPorCtrl]|=cBit6)
#define  rmSysDisExVdt                           (rSysCtrl0[rcPorCtrl]&=(~cBit6))
#define  rmSysEnExVdtGateClk                     (rSysCtrl0[rcPorCtrl]|=cBit5)
#define  rmSysDisExVdtGateClk                    (rSysCtrl0[rcPorCtrl]&=(~cBit5))
#define  rmSysEnExVdtFwp                         (rSysCtrl0[rcPorCtrl]|=cBit4)
#define  rmSysDisExVdtFwp                        (rSysCtrl0[rcPorCtrl]&=(~cBit4))
// Bit0, 1: whole chip power on reset fall threshold voltage(VFR) selection
// 00    / 01     / 10     / 11
// VFR0  / VFR1   / VFR2   / VFR3 select pin.
// 0.72  / 0.7    / 0.68   / 0.66  Volt.
#define  rmSysSetPorDefaultVfrLevel              (rSysCtrl0[rcPorCtrl]=rSysCtrl0[rcPorCtrl]&0xFC)
#define  rmSysSetPorLowVfrLevel                  (rSysCtrl0[rcPorCtrl]=(rSysCtrl0[rcPorCtrl]&0xFC)|0x03)
#define  rmSysSetPorHighVfrLevel                 (rSysCtrl0[rcPorCtrl]=(rSysCtrl0[rcPorCtrl]&0xFC)|cBit0)
#define  rmClrPorAdj                             (rSysCtrl0[rcPorCtrl]&=(~cBit0))

// VDT23_Fsh1
#define  rcVdtFsh1                               0x11
#define  rmChkVdt23Fsh1Good                      (rSysCtrl0[rcVdtFsh1]&cBit7)
#define  rmEnVdt23Fsh1FlashWp                    (rSysCtrl0[rcVdtFsh1]|=cBit5)
#define  rmDisVdt23Fsh1FlashWp                   (rSysCtrl0[rcVdtFsh1]&=(~cBit5))
#define  rmEnVdt23Fsh1                           (rSysCtrl0[rcVdtFsh1]&=(~cBit4))
#define  rmDisVdt23Fsh1                          (rSysCtrl0[rcVdtFsh1]|=cBit4)
#define  rmSetVdt23Fsh1(val)                     (rSysCtrl0[rcVdtFsh1]=((rSysCtrl0[rcVdtFsh1]&0xF0)|(val&0x0F)))

// VDT27_Fsh2
#define  rcVdtFsh2                               0x12
#define  rmChkVdt27Fsh2Good                      (rSysCtrl0[rcVdtFsh2]&cBit7)
#define  rmEnVdt27Fsh2CpuGate                    (rSysCtrl0[rcVdtFsh2]|=cBit5)
#define  rmDisVdt27Fsh2                          (rSysCtrl0[rcVdtFsh2]|=cBit4)
#define  rmEnVdt27Fsh2                           (rSysCtrl0[rcVdtFsh2]&=(~cBit4))
#define  rmSetVdt27Fsh2(val)                     (rSysCtrl0[rcVdtFsh2]=((rSysCtrl0[rcVdtFsh2]&0xF0)|(val&0x0F)))

// VDT12_FIO
#define  rcVdtFio                                0x13
#define  rmChkVdt12FioGood                       (rSysCtrl0[rcVdtFio]&cBit7)
#define  rmDisVdt12Fio                           (rSysCtrl0[rcVdtFio]|=cBit4)
#define  rmEnVdt12Fio                            (rSysCtrl0[rcVdtFio]&=(~cBit4))
#define  rmSetVdt12Fio(val)                      (rSysCtrl0[rcVdtFio]=((rSysCtrl0[rcVdtFio]&0xF0)|(val&0x0F)))

// VDT18_DRAM
#define  rcVdt18                                 0x14
#define  rmChkVdt18Good                          (rSysCtrl0[rcVdt18]&cBit7)
#define  rmDisVdt18                              (rSysCtrl0[rcVdt18]|=cBit4)
#define  rmEnVdt18                               (rSysCtrl0[rcVdt18]&=(~cBit4))
#define  rmSetVdt18(val)                         (rSysCtrl0[rcVdt18]=((rSysCtrl0[rcVdt18]&0xF0)|(val&0x0F)))

#define  rcVdt10                                 0x102
#define  rmChkVdt10Good                          (rSysCtrl0[rcVdt10]&cBit7)
#define  rmDisVdt10                              (rSysCtrl0[rcVdt10]|=cBit4)
#define  rmEnVdt10                               (rSysCtrl0[rcVdt10]&=(~cBit4))
#define  rmSetVdt10(val)                         (rSysCtrl0[rcVdt10]=((rSysCtrl0[rcVdt10]&0xF0)|(val&0x0F)))

#define  rcThermalCtrl                           0x15
// Thermal Sensor0
#define  rmThermal0PowerDown                     (rSysCtrl0[rcThermalCtrl]|=cBit0)
#define  rmThermal0PowerUp                       (rSysCtrl0[rcThermalCtrl]&=(~cBit0))
#define  rmThermal0LpfEn                         (rSysCtrl0[rcThermalCtrl]|=cBit2)
#define  rmThermal0LpfDis                        (rSysCtrl0[rcThermalCtrl]&=(~cBit2))
#define  rmChkThermal0Lpf                        (rSysCtrl0[rcThermalCtrl]&cBit2)
#define  rmThermal0CollectEn                     (rSysCtrl0[rcThermalCtrl]|=cBit4)
#define  rmThermal0CollectDis                    (rSysCtrl0[rcThermalCtrl]&=(~cBit4))
#define  rmChkThermal0Collect                    (rSysCtrl0[rcThermalCtrl]&cBit4)
#define  rmChkThermoSensor0Rdy                   (rSysCtrl0[rcThermalCtrl]&cBit6)

// Thermal Sensor1
#define  rmThermal1PowerDown                     (rSysCtrl0[rcThermalCtrl]|=cBit1)
#define  rmThermal1PowerUp                       (rSysCtrl0[rcThermalCtrl]&=(~cBit1))
#define  rmThermal1LpfEn                         (rSysCtrl0[rcThermalCtrl]|=cBit3)
#define  rmThermal1LpfDis                        (rSysCtrl0[rcThermalCtrl]&=(~cBit3))
#define  rmChkThermal1Lpf                        (rSysCtrl0[rcThermalCtrl]&cBit3)
#define  rmThermal1CollectEn                     (rSysCtrl0[rcThermalCtrl]|=cBit5)
#define  rmThermal1CollectDis                    (rSysCtrl0[rcThermalCtrl]&=(~cBit5))
#define  rmChkThermal1Collect                    (rSysCtrl0[rcThermalCtrl]&cBit5)
#define  rmChkThermoSensor1Rdy                   (rSysCtrl0[rcThermalCtrl]&cBit7)

#define  rmChkThermal0Valid                      (rSysCtrl0[rcThermalCtrl]&cBit6)
#define  rmChkThermal1Valid                      (rSysCtrl0[rcThermalCtrl]&cBit7)

#define  rcThermal                               0x16
// #define  rmChkThermoSensorRdy                    (rSysCtrl0[rcThermal]&cBit7)
// #define  rmChkThermalVal                         (rSysCtrl0[rcThermal]&0x7F)

#define  rcBgTrim                                0x17
#define  rmSysSetBgBufPd                         rSysCtrl0[rcBgTrim]|=cBit5
#define  rmSetBgTrim(x)                          (rSysCtrl0[rcBgTrim]=(x&0x1F)|cBit5)

#define  rcWakeCtrl0                             0x18
#define  rmEnPw2IsoGate                          (rSysCtrl0[rcWakeCtrl0]=(rSysCtrl0[rcWakeCtrl0]&0x7F)|cBit7)
#define  rmDisPw2IsoGate                         (rSysCtrl0[rcWakeCtrl0]=(rSysCtrl0[rcWakeCtrl0]&0x7F))
#define  rmEnPw1IsoGate                          (rSysCtrl0[rcWakeCtrl0]=(rSysCtrl0[rcWakeCtrl0]&0xBF)|cBit6)
#define  rmDisPw1IsoGate                         (rSysCtrl0[rcWakeCtrl0]=(rSysCtrl0[rcWakeCtrl0]&0xBF))
#define  rmChkPw1PowerSwitch                     (rSysCtrl0[rcWakeCtrl0]&cBit4)
#define  rmChkPw2PowerSwitch                     (rSysCtrl0[rcWakeCtrl0]&cBit5)
#define  rmEnXtalChkCkRq                         (rSysCtrl0[rcWakeCtrl0]|=cBit3)
#define  rmDisXtalChkCkRq                        (rSysCtrl0[rcWakeCtrl0]&=(~cBit3))
#define  rmEnJtagLevelWake                       (rSysCtrl0[rcWakeCtrl0]=(rSysCtrl0[rcWakeCtrl0]&0xFB)|cBit2)
#define  rmDisJtagLevelWake                      (rSysCtrl0[rcWakeCtrl0]=(rSysCtrl0[rcWakeCtrl0]&0xFB))
#define  rmEnJtagBusyWake                        (rSysCtrl0[rcWakeCtrl0]=(rSysCtrl0[rcWakeCtrl0]&0xFD)|cBit1)
#define  rmDisJtagBusyWake                       (rSysCtrl0[rcWakeCtrl0]=(rSysCtrl0[rcWakeCtrl0]&0xFD))
#define  rmEnClkReqAssertWake                    (rSysCtrl0[rcWakeCtrl0]=(rSysCtrl0[rcWakeCtrl0]&0xFE)|cBit0)
#define  rmDisClkReqAssertWake                   (rSysCtrl0[rcWakeCtrl0]=(rSysCtrl0[rcWakeCtrl0]&0xFE))
#define  rmChkClkReqAssertWake                   (rSysCtrl0[rcWakeCtrl0]&cBit0)

#define  rcVdtms                                 0x19    // discuss with HW

#define  rcThsor0ValueL                          0x1A
#define  rcThsor0ValueH                          0x1B
#define  rmThsor0Value                           (r16SysCtrl0[rcThsor0ValueL/2]&0x01FF)    //

#define  rcIntSts0                               0x1C
#define  rmChkCdiInt                             (rSysCtrl0[rcIntSts0]&cBit0)
#define  rmClrCdiInt                             (rSysCtrl0[rcIntSts0]=cBit0)
#define  rmChkEletricIdleInt                     (rSysCtrl0[rcIntSts0]&cBit1)
#define  rmClrEletricIdleInt                     (rSysCtrl0[rcIntSts0]=(cBit0|cBit1))

#define  rcThermalCtrl2                          0x1D    // discuss with HW

#define  rcThsor1ValueL                          0x1E
#define  rcThsor1ValueH                          0x1F
#define  rmThsor1Value                           (r16SysCtrl0[rcThsor1ValueL/2]&0x01FF)    //

#define  rcCryPadCtrl1                           0x20    // discuss with HW

#define  rcWakeCtrl1                             0x21    // discuss with HW
#define  rmSetWakeupByTimer                      (rSysCtrl0[rcWakeCtrl1]|=cBit1)
#define  rmClrWakeupByTimer                      (rSysCtrl0[rcWakeCtrl1]&=(~cBit1))
#define  rmSetEletricIdleWake                    (rSysCtrl0[rcWakeCtrl1]|=cBit2)
#define  rmSetPerstWake                          (rSysCtrl0[rcWakeCtrl1]|=cBit0)
#define  rmClrEletricIdleWake                    (rSysCtrl0[rcWakeCtrl1]&=(~cBit2))
#define  rmClrPerstWake                          (rSysCtrl0[rcWakeCtrl1]&=(~cBit0))
#define  rmClrPerstWakeActive                    (rSysCtrl0[rcWakeCtrl1]|=cBit4)

#define  rcPowerFailQueue                        0x23    // discuss with HW
#define  rmChkPwFail18Dram                      (rSysCtrl0[rcPowerFailQueue]&cBit0)
#define  rmChkPwFail23Fsh1                      (rSysCtrl0[rcPowerFailQueue]&cBit1)
#define  rmChkPwFail27Fsh2                      (rSysCtrl0[rcPowerFailQueue]&cBit2)
#define  rmChkPwFail12Fio                       (rSysCtrl0[rcPowerFailQueue]&cBit3)
#define  rmChkPwFailLEx                         (rSysCtrl0[rcPowerFailQueue]&cBit4)
#define  rmClrPwFail18Dram                      (rSysCtrl0[rcPowerFailQueue]&=(~cBit0))
#define  rmClrPwFail23Fsh1                      (rSysCtrl0[rcPowerFailQueue]&=(~cBit1))
#define  rmClrPwFail27Fsh2                      (rSysCtrl0[rcPowerFailQueue]&=(~cBit2))
#define  rmClrPwFail12Fio                       (rSysCtrl0[rcPowerFailQueue]&=(~cBit3))

#define  rmClrPwFailPor1                        (rSysCtrl0[rcPowerFailQueue]&=(~cBit5))

#define  rcCrcCtrl                               0x24    // discuss with HW
#define  rmEnGlobalCrc                           (rSysCtrl0[rcCrcCtrl]|=cBit0)
#define  rmDisGlobalCrc                          (rSysCtrl0[rcCrcCtrl]&=(~cBit0))
#define  rmChkGlobalCrc                          (rSysCtrl0[rcCrcCtrl]&cBit0)

#define  rcRefClk3Ctrl                           0x25    // discuss with HW
#define  rcFrbCtrl2                              0x26    // discuss with HW

#define  rcFdataReversal                         0x27    // discuss with HW
#define  rcLoopBackEnF                           0x28    // discuss with HW
#define  rcLoopBackEnP                           0x29    // discuss with HW

#define  rcPllCtrl0                              0x2A    // discuss with HW
#define  rcPllCtrl1                              0x2B    // discuss with HW
#define  rcPllCtrl2                              0x2C    // discuss with HW

#define  rcFceIoCtrl                             0x2D
#define  rmSysEnFceOe                            (rSysCtrl0[rcFceIoCtrl]|=cBit3)    // flash chip enable
#define  rmSysDisFceOe                           (rSysCtrl0[rcFceIoCtrl]&=(~cBit3))
#define  rmSysEnFcePu                            (rSysCtrl0[rcFceIoCtrl]|=cBit2)
#define  rmSysDisFcePu                           (rSysCtrl0[rcFceIoCtrl]&=(~cBit2))

#define  rcFreeOscCtrl                           0x2E    // for TRNG
// #define  rmFreeOscChkLock                        (rSysCtrl0[rcFreeOscCtrl]&cBit7)
#define  rmSysEnOscGate                          (rSysCtrl0[rcFreeOscCtrl]|=cBit5)
#define  rmSysDisOscGate                         (rSysCtrl0[rcFreeOscCtrl]&=(~cBit5))
#define  rmSysDisOsc                             (rSysCtrl0[rcFreeOscCtrl]|=cBit4)
#define  rmSysEnOsc                              (rSysCtrl0[rcFreeOscCtrl]&=(~cBit4))
#define  rmSysOsc2P3Ghz                          (rSysCtrl0[rcFreeOscCtrl]=(rSysCtrl0[rcFreeOscCtrl]&0xF8)|0x00)
#define  rmSysOsc1P03Ghz                         (rSysCtrl0[rcFreeOscCtrl]=(rSysCtrl0[rcFreeOscCtrl]&0xF8)|0x01)
#define  rmSysOsc560Mhz                          (rSysCtrl0[rcFreeOscCtrl]=(rSysCtrl0[rcFreeOscCtrl]&0xF8)|0x02)
#define  rmSysOsc1P15Ghz                         (rSysCtrl0[rcFreeOscCtrl]=(rSysCtrl0[rcFreeOscCtrl]&0xF8)|0x04)
#define  rmSysOsc520Mhz                          (rSysCtrl0[rcFreeOscCtrl]=(rSysCtrl0[rcFreeOscCtrl]&0xF8)|0x05)
#define  rmSysOsc280Mhz                          (rSysCtrl0[rcFreeOscCtrl]=(rSysCtrl0[rcFreeOscCtrl]&0xF8)|0x06)
#define  rmSysOsc150Mhz                          (rSysCtrl0[rcFreeOscCtrl]=(rSysCtrl0[rcFreeOscCtrl]&0xF8)|0x07)
#define  rmSysSetSysOsc(x)                       (rSysCtrl0[rcFreeOscCtrl]=(rSysCtrl0[rcFreeOscCtrl]&0xF8)|x)

#define  rcSysPllCtrl                            0x2F
#define  rmChkSysPllLock                         (rSysCtrl0[rcSysPllCtrl]&cBit3)
#define  rmSysIdleSysPllOff                      (rSysCtrl0[rcSysPllCtrl]|=cBit2)
#define  rmSysIdleSysPllOn                       (rSysCtrl0[rcSysPllCtrl]&=(~cBit2))
#define  rmSysSetForceClk3SysPll                 (rSysCtrl0[rcSysPllCtrl]|=cBit1)
#define  rmSysClrForceClk3SysPll                 (rSysCtrl0[rcSysPllCtrl]&=(~cBit1))

#define  rcFshPllCtrl                            0x30
#define  rmChkFshPllLock                         (rSysCtrl0[rcFshPllCtrl]&cBit3)
#define  rmSysIdleFshPllOff                      (rSysCtrl0[rcFshPllCtrl]|=cBit2)
#define  rmSysIdleFshPllOn                       (rSysCtrl0[rcFshPllCtrl]&=(~cBit2))

#define  rcDrmPllCtrl                            0x31
#define  rmChkSysChkDrmPllLock                   (rSysCtrl0[rcDrmPllCtrl]&cBit3)
#define  rmSysIdleDrmPllOff                      (rSysCtrl0[rcDrmPllCtrl]|=cBit2)
#define  rmSysIdleDrmPllOn                       (rSysCtrl0[rcDrmPllCtrl]&=(~cBit2))

// ASIC PLL Setting
#define  cPreScale25Mhz                          0x00
#define  cPreScale12p5Mhz                        0x01

#define  cVcoSelDiv2                             0x00
#define  cVcoSelDiv4                             0x01
#define  cVcoSelDiv8                             0x02
#define  cVcoSelDiv16                            0x03
#define  cVcoSelDiv32                            0x04
#define  cVcoSelDiv64                            0x05
#define  cVcoSelDiv128                           0x06
#define  cVcoSelDiv256                           0x07

#define  cLockSel160us                           0x00
#define  cLockSel80us                            0x01
#define  cLockSel40us                            0x02
#define  cLockSel20us                            0x03

#define  cXtalSel                                0x00    // external clk source 25Mhz
#define  cOscSel                                 0x90    // internal clk source 12.5Mhz

#define  rcSysPllSel                             0x32
#define  rmGetSysClkPll                          r16SysCtrl0[rcSysPllSel/2]
#define  rmRestorSysClkPll(x)\
    {r16SysCtrl0[rcSysPllSel/2]=x;\
     while(!rmChkSysPllLock)\
         ;\
    }
#define  rmGetDivSel                             (rSysCtrl0[rcSysPllSel]&0x7F)

#define  rmSetSysPllClock(locksel, divsel, prescale, vcosel, refclk)\
    do\
    {\
        rmSetRefSwCtl(refclk);\
        r16SysCtrl0[rcSysPllSel/2]=(((locksel&0x03)<<12)|(prescale&0x01)<<11)|((vcosel&0x07)<<8)|(divsel&0xFF);\
        while(!rmChkSysPllLock)\
            ;\
    }\
    while(0)

// #define  rmSetSysPllClockFromLs(x)               {r16SysCtrl0[rcSysPllSel/2]=cbSysFlashPllTab[(x/125)-1]; while(!rmChkSysPllLock);}

#define  rcSysPllSel1                            0x33
#define  rmGetSysPllVcoSel                       (rSysCtrl0[rcSysPllSel1]&0x07)
#define  rmGetSysPllPreScale                     ((rSysCtrl0[rcSysPllSel1]&cBit3)>>3)

#define  rcFshPllSel                             0x34
#define  rmGetFshClkPll                          r16SysCtrl0[rcFshPllSel/2]

#define  rmSetFshPllClock(locksel, divsel, prescale, vcosel)\
    do\
    {\
        r16SysCtrl0[rcFshPllSel/2]=(((locksel&0x03)<<12)|(prescale&0x01)<<11)|((vcosel&0x07)<<8)|(divsel&0xFF);\
        while(!rmChkFshPllLock)\
            ;\
    }\
    while(0)

#define  rcDrmPllSel                             0x36
#define  rmSetDramClkPll(x)\
    {r16SysCtrl0[rcDrmPllSel/2]=x;\
     while(!rmChkSysChkDrmPllLock)\
         ;\
    }
#define  rmGetDramClkPll                         r16SysCtrl0[rcDrmPllSel/2]

#define  rcLdpcPllCtrl                           0x39
#define  rmSysLdpcPllLock26us                    rSysCtrl0[rcLdpcPllCtrl]=(rSysCtrl0[rcLdpcPllCtrl]&0x3F)
#define  rmSysLdpcPllLock13us                    rSysCtrl0[rcLdpcPllCtrl]=(rSysCtrl0[rcLdpcPllCtrl]&0x3F)|0x40
#define  rmSysLdpcPllLock6us                     rSysCtrl0[rcLdpcPllCtrl]=(rSysCtrl0[rcLdpcPllCtrl]&0x3F)|0x80
#define  rmSysLdpcPllLock3us                     rSysCtrl0[rcLdpcPllCtrl]=(rSysCtrl0[rcLdpcPllCtrl]&0x3F)|0xC0
#define  rmSysLdpcPllKvcoSel1p5us                rSysCtrl0[rcLdpcPllCtrl]=(rSysCtrl0[rcLdpcPllCtrl]&0xCF)|cBit4
#define  rmSysLdpcPllKvcoSel2us                  rSysCtrl0[rcLdpcPllCtrl]=(rSysCtrl0[rcLdpcPllCtrl]&0xCF)
#define  rmChkLdpcPllLock                        (rSysCtrl0[rcLdpcPllCtrl]&cBit3)
#define  rmSysIdleLdpcPllOff                     rSysCtrl0[rcLdpcPllCtrl]|=cBit2
#define  rmSysIdleLdpcPllOn                      rSysCtrl0[rcLdpcPllCtrl]&=~cBit2
#define  rmSysSetForceClk3LdpcPll                rSysCtrl0[rcLdpcPllCtrl]|=cBit1
#define  rmSysClrForceClk3LdpcPll                rSysCtrl0[rcLdpcPllCtrl]&=~cBit1

#define  rcLdpcPllSel                            0x3A
#define  rmGetLdpcClkPll                         r16SysCtrl0[rcLdpcPllSel/2]

#define  rmSetLdpcPllClock(locksel, divsel, prescale, vcosel)\
    do\
    {\
        r16SysCtrl0[rcLdpcPllSel/2]=(((locksel&0x03)<<12)|(prescale&0x01)<<11)|((vcosel&0x07)<<8)|(divsel&0xFF);\
        while(!rmChkLdpcPllLock)\
            ;\
    }\
    while(0)

#define  rcDspPllCtrl                            0x3D
#define  rmSysDspPllLock26us                     (rSysCtrl0[rcDspPllCtrl]=(rSysCtrl0[rcDspPllCtrl]&0x3F))
#define  rmSysDspPllLock13us                     (rSysCtrl0[rcDspPllCtrl]=(rSysCtrl0[rcDspPllCtrl]&0x3F)|0x40)
#define  rmSysDspPllLock6us                      (rSysCtrl0[rcDspPllCtrl]=(rSysCtrl0[rcDspPllCtrl]&0x3F)|0x80)
#define  rmSysDspPllLock3us                      (rSysCtrl0[rcDspPllCtrl]=(rSysCtrl0[rcDspPllCtrl]&0x3F)|0xc0)
#define  rmSysDspPllKvcoSel1p5us                 (rSysCtrl0[rcDspPllCtrl]=(rSysCtrl0[rcDspPllCtrl]&0xCF)|cBit4)
#define  rmSysDspPllKvcoSel2us                   (rSysCtrl0[rcDspPllCtrl]=(rSysCtrl0[rcDspPllCtrl]&0xCF))
#define  rmSetSysDspPllKvcoSel                   (rSysCtrl0[rcDspPllCtrl]|=cBit5)
#define  rmClrSysDspPllKvcoSel                   (rSysCtrl0[rcDspPllCtrl]&=(~cBit5))
#define  rmChkDspPllLock                         (rSysCtrl0[rcDspPllCtrl]&cBit3)
#define  rmSysIdleDspPllOff                      (rSysCtrl0[rcDspPllCtrl]|=cBit2)
#define  rmSysIdleDspPllOn                       (rSysCtrl0[rcDspPllCtrl]&=(~cBit2))
#define  rmSysSetForceClk3DspPll                 (rSysCtrl0[rcDspPllCtrl]|=cBit1)
#define  rmSysClrForceClk3DspPll                 (rSysCtrl0[rcDspPllCtrl]&=(~cBit1))

#define  rcDspPllSel                             0x3E
#define  rmGetDspClkPll                          r16SysCtrl0[rcDspPllSel/2]

#define  rmSetDspPllClock(locksel, divsel, prescale, vcosel)\
    do\
    {\
        r16SysCtrl0[rcDspPllSel/2]=(((locksel&0x03)<<12)|(prescale&0x01)<<11)|((vcosel&0x07)<<8)|(divsel&0xFF);\
        while(!rmChkDspPllLock)\
            ;\
    }\
    while(0)

#define  rcF0IoCtrl0                             0x40
#define  rmSysEnF0RwOe                           (rSysCtrl0[rcF0IoCtrl0]|=cBit3)
#define  rmSysDisF0RwOe                          (rSysCtrl0[rcF0IoCtrl0]&=(~cBit3))
#define  rmSysEnF0RwPu                           (rSysCtrl0[rcF0IoCtrl0]|=cBit1)
#define  rmSysDisF0RwPu                          (rSysCtrl0[rcF0IoCtrl0]&=(~cBit1))

#define  rcF0AleCleCtrl0                         0x41
#define  rmSysEnF0AleCleOe                       (rSysCtrl0[rcF0AleCleCtrl0]|=cBit3)
#define  rmSysDisF0AleCleOe                      (rSysCtrl0[rcF0AleCleCtrl0]&=(~cBit3))
#define  rmSysEnF0AleClePd                       (rSysCtrl0[rcF0AleCleCtrl0]|=cBit0)
#define  rmSysDisF0AleClePd                      (rSysCtrl0[rcF0AleCleCtrl0]&=(~cBit0))

#define  rcF0DqsCtrl0                            0x42
#define  rmSysEnF0DqsPd                          (rSysCtrl0[rcF0DqsCtrl0]|=cBit0)
#define  rmSysDisF0DqsPd                         (rSysCtrl0[rcF0DqsCtrl0]&=(~cBit0))
#define  rmSysEnF0DqsPu                          (rSysCtrl0[rcF0DqsCtrl0]|=cBit1)
#define  rmSysDisF0DqsPu                         (rSysCtrl0[rcF0DqsCtrl0]&=(~cBit1))

#define  rcF0DataCtrl0                           0x43
#define  rmSysEnF0DataPd                         (rSysCtrl0[rcF0DataCtrl0]|=cBit0)
#define  rmSysDisF0DataPd                        (rSysCtrl0[rcF0DataCtrl0]&=(~cBit0))
#define  rmSysEnF0DataPu                         (rSysCtrl0[rcF0DataCtrl0]|=cBit1)
#define  rmSysDisF0DataPu                        (rSysCtrl0[rcF0DataCtrl0]&=(~cBit1))

#define  rcF1IoCtrl0                             0x44
#define  rmSysEnF1RwOe                           (rSysCtrl0[rcF1IoCtrl0]|=cBit3)
#define  rmSysDisF1RwOe                          (rSysCtrl0[rcF1IoCtrl0]&=(~cBit3))
#define  rmSysEnF1RwPu                           (rSysCtrl0[rcF1IoCtrl0]|=cBit1)
#define  rmSysDisF1RwPu                          (rSysCtrl0[rcF1IoCtrl0]&=(~cBit1))

#define  rcF1AleCleCtrl0                         0x45
#define  rmSysEnF1AleCleOe                       (rSysCtrl0[rcF1AleCleCtrl0]|=cBit3)
#define  rmSysDisF1AleCleOe                      (rSysCtrl0[rcF1AleCleCtrl0]&=(~cBit3))
#define  rmSysEnF1AleClePd                       (rSysCtrl0[rcF1AleCleCtrl0]|=cBit0)
#define  rmSysDisF1AleClePd                      (rSysCtrl0[rcF1AleCleCtrl0]&=(~cBit0))

#define  rcF1DqsCtrl0                            0x46
#define  rmSysEnF1DqsPd                          (rSysCtrl0[rcF1DqsCtrl0]|=cBit0)
#define  rmSysDisF1DqsPd                         (rSysCtrl0[rcF1DqsCtrl0]&=(~cBit0))
#define  rmSysEnF1DqsPu                          (rSysCtrl0[rcF1DqsCtrl0]|=cBit1)
#define  rmSysDisF1DqsPu                         (rSysCtrl0[rcF1DqsCtrl0]&=(~cBit1))

#define  rcF1DataCtrl0                           0x47
#define  rmSysEnF1DataPd                         (rSysCtrl0[rcF1DataCtrl0]|=cBit0)
#define  rmSysDisF1DataPd                        (rSysCtrl0[rcF1DataCtrl0]&=(~cBit0))
#define  rmSysEnF1DataPu                         (rSysCtrl0[rcF1DataCtrl0]|=cBit1)
#define  rmSysDisF1DataPu                        (rSysCtrl0[rcF1DataCtrl0]&=(~cBit1))

#define  rcF2IoCtrl0                             0x48
#define  rmSysEnF2RwOe                           (rSysCtrl0[rcF2IoCtrl0]|=cBit3)
#define  rmSysDisF2RwOe                          (rSysCtrl0[rcF2IoCtrl0]&=(~cBit3))
#define  rmSysEnF2RwPu                           (rSysCtrl0[rcF2IoCtrl0]|=cBit1)
#define  rmSysDisF2RwPu                          (rSysCtrl0[rcF2IoCtrl0]&=(~cBit1))

#define  rcF2AleCleCtrl0                         0x49
#define  rmSysEnF2AleCleOe                       (rSysCtrl0[rcF2AleCleCtrl0]|=cBit3)
#define  rmSysDisF2AleCleOe                      (rSysCtrl0[rcF2AleCleCtrl0]&=(~cBit3))
#define  rmSysEnF2AleClePd                       (rSysCtrl0[rcF2AleCleCtrl0]|=cBit0)
#define  rmSysDisF2AleClePd                      (rSysCtrl0[rcF2AleCleCtrl0]&=(~cBit0))

#define  rcF2DqsCtrl0                            0x4A
#define  rmSysEnF2DqsPd                          (rSysCtrl0[rcF2DqsCtrl0]|=cBit0)
#define  rmSysDisF2DqsPd                         (rSysCtrl0[rcF2DqsCtrl0]&=(~cBit0))
#define  rmSysEnF2DqsPu                          (rSysCtrl0[rcF2DqsCtrl0]|=cBit1)
#define  rmSysDisF2DqsPu                         (rSysCtrl0[rcF2DqsCtrl0]&=(~cBit1))

#define  rcF2DataCtrl0                           0x4B
#define  rmSysEnF2DataPd                         (rSysCtrl0[rcF2DataCtrl0]|=cBit0)
#define  rmSysDisF2DataPd                        (rSysCtrl0[rcF2DataCtrl0]&=(~cBit0))
#define  rmSysEnF2DataPu                         (rSysCtrl0[rcF2DataCtrl0]|=cBit1)
#define  rmSysDisF2DataPu                        (rSysCtrl0[rcF2DataCtrl0]&=(~cBit1))

#define  rcF3IoCtrl0                             0x4C
#define  rmSysEnF3RwOe                           (rSysCtrl0[rcF3IoCtrl0]|=cBit3)
#define  rmSysDisF3RwOe                          (rSysCtrl0[rcF3IoCtrl0]&=(~cBit3))
#define  rmSysEnF3RwPu                           (rSysCtrl0[rcF3IoCtrl0]|=cBit1)
#define  rmSysDisF3RwPu                          (rSysCtrl0[rcF3IoCtrl0]&=(~cBit1))

#define  rcF3AleCleCtrl0                         0x4D
#define  rmSysEnF3AleCleOe                       (rSysCtrl0[rcF3AleCleCtrl0]|=cBit3)
#define  rmSysDisF3AleCleOe                      (rSysCtrl0[rcF3AleCleCtrl0]&=(~cBit3))
#define  rmSysEnF3AleClePd                       (rSysCtrl0[rcF3AleCleCtrl0]|=cBit0)
#define  rmSysDisF3AleClePd                      (rSysCtrl0[rcF3AleCleCtrl0]&=(~cBit0))

#define  rcF3DqsCtrl0                            0x4E
#define  rmSysEnF3DqsPd                          (rSysCtrl0[rcF3DqsCtrl0]|=cBit0)
#define  rmSysDisF3DqsPd                         (rSysCtrl0[rcF3DqsCtrl0]&=(~cBit0))
#define  rmSysEnF3DqsPu                          (rSysCtrl0[rcF3DqsCtrl0]|=cBit1)
#define  rmSysDisF3DqsPu                         (rSysCtrl0[rcF3DqsCtrl0]&=(~cBit1))

#define  rcF3DataCtrl0                           0x4F
#define  rmSysEnF3DataPd                         (rSysCtrl0[rcF3DataCtrl0]|=cBit0)
#define  rmSysDisF3DataPd                        (rSysCtrl0[rcF3DataCtrl0]&=(~cBit0))
#define  rmSysEnF3DataPu                         (rSysCtrl0[rcF3DataCtrl0]|=cBit1)
#define  rmSysDisF3DataPu                        (rSysCtrl0[rcF3DataCtrl0]&=(~cBit1))

#define  rcF4IoCtrl0                             0x50
#define  rmSysEnF4RwOe                           (rSysCtrl0[rcF4IoCtrl0]|=cBit3)
#define  rmSysDisF4RwOe                          (rSysCtrl0[rcF4IoCtrl0]&=(~cBit3))
#define  rmSysEnF4RwPu                           (rSysCtrl0[rcF4IoCtrl0]|=cBit1)
#define  rmSysDisF4RwPu                          (rSysCtrl0[rcF4IoCtrl0]&=(~cBit1))

#define  rcF4AleCleCtrl0                         0x51
#define  rmSysEnF4AleCleOe                       (rSysCtrl0[rcF4AleCleCtrl0]|=cBit3)
#define  rmSysDisF4AleCleOe                      (rSysCtrl0[rcF4AleCleCtrl0]&=(~cBit3))
#define  rmSysEnF4AleClePd                       (rSysCtrl0[rcF4AleCleCtrl0]|=cBit0)
#define  rmSysDisF4AleClePd                      (rSysCtrl0[rcF4AleCleCtrl0]&=(~cBit0))

#define  rcF4DqsCtrl0                            0x52
#define  rmSysEnF4DqsPd                          (rSysCtrl0[rcF4DqsCtrl0]|=cBit0)
#define  rmSysDisF4DqsPd                         (rSysCtrl0[rcF4DqsCtrl0]&=(~cBit0))
#define  rmSysEnF4DqsPu                          (rSysCtrl0[rcF4DqsCtrl0]|=cBit1)
#define  rmSysDisF4DqsPu                         (rSysCtrl0[rcF4DqsCtrl0]&=(~cBit1))

#define  rcF4DataCtrl0                           0x53
#define  rmSysEnF4DataPd                         (rSysCtrl0[rcF4DataCtrl0]|=cBit0)
#define  rmSysDisF4DataPd                        (rSysCtrl0[rcF4DataCtrl0]&=(~cBit0))
#define  rmSysEnF4DataPu                         (rSysCtrl0[rcF4DataCtrl0]|=cBit1)
#define  rmSysDisF4DataPu                        (rSysCtrl0[rcF4DataCtrl0]&=(~cBit1))

#define  rcF5IoCtrl0                             0x54
#define  rmSysEnF5RwOe                           (rSysCtrl0[rcF5IoCtrl0]|=cBit3)
#define  rmSysDisF5RwOe                          (rSysCtrl0[rcF5IoCtrl0]&=(~cBit3))
#define  rmSysEnF5RwPu                           (rSysCtrl0[rcF5IoCtrl0]|=cBit1)
#define  rmSysDisF5RwPu                          (rSysCtrl0[rcF5IoCtrl0]&=(~cBit1))

#define  rcF5AleCleCtrl0                         0x55
#define  rmSysEnF5AleCleOe                       (rSysCtrl0[rcF5AleCleCtrl0]|=cBit3)
#define  rmSysDisF5AleCleOe                      (rSysCtrl0[rcF5AleCleCtrl0]&=(~cBit3))
#define  rmSysEnF5AleClePd                       (rSysCtrl0[rcF5AleCleCtrl0]|=cBit0)
#define  rmSysDisF5AleClePd                      (rSysCtrl0[rcF5AleCleCtrl0]&=(~cBit0))

#define  rcF5DqsCtrl0                            0x56
#define  rmSysEnF5DqsPd                          (rSysCtrl0[rcF5DqsCtrl0]|=cBit0)
#define  rmSysDisF5DqsPd                         (rSysCtrl0[rcF5DqsCtrl0]&=(~cBit0))
#define  rmSysEnF5DqsPu                          (rSysCtrl0[rcF5DqsCtrl0]|=cBit1)
#define  rmSysDisF5DqsPu                         (rSysCtrl0[rcF5DqsCtrl0]&=(~cBit1))

#define  rcF5DataCtrl0                           0x57
#define  rmSysEnF5DataPd                         (rSysCtrl0[rcF5DataCtrl0]|=cBit0)
#define  rmSysDisF5DataPd                        (rSysCtrl0[rcF5DataCtrl0]&=(~cBit0))
#define  rmSysEnF5DataPu                         (rSysCtrl0[rcF5DataCtrl0]|=cBit1)
#define  rmSysDisF5DataPu                        (rSysCtrl0[rcF5DataCtrl0]&=(~cBit1))

#define  rcF6IoCtrl0                             0x58
#define  rmSysEnF6RwOe                           (rSysCtrl0[rcF6IoCtrl0]|=cBit3)
#define  rmSysDisF6RwOe                          (rSysCtrl0[rcF6IoCtrl0]&=(~cBit3))
#define  rmSysEnF6RwPu                           (rSysCtrl0[rcF6IoCtrl0]|=cBit1)
#define  rmSysDisF6RwPu                          (rSysCtrl0[rcF6IoCtrl0]&=(~cBit1))

#define  rcF6AleCleCtrl0                         0x59
#define  rmSysEnF6AleCleOe                       (rSysCtrl0[rcF6AleCleCtrl0]|=cBit3)
#define  rmSysDisF6AleCleOe                      (rSysCtrl0[rcF6AleCleCtrl0]&=(~cBit3))
#define  rmSysEnF6AleClePd                       (rSysCtrl0[rcF6AleCleCtrl0]|=cBit0)
#define  rmSysDisF6AleClePd                      (rSysCtrl0[rcF6AleCleCtrl0]&=(~cBit0))

#define  rcF6DqsCtrl0                            0x5A
#define  rmSysEnF6DqsPd                          (rSysCtrl0[rcF6DqsCtrl0]|=cBit0)
#define  rmSysDisF6DqsPd                         (rSysCtrl0[rcF6DqsCtrl0]&=(~cBit0))
#define  rmSysEnF6DqsPu                          (rSysCtrl0[rcF6DqsCtrl0]|=cBit1)
#define  rmSysDisF6DqsPu                         (rSysCtrl0[rcF6DqsCtrl0]&=(~cBit1))

#define  rcF6DataCtrl0                           0x5B
#define  rmSysEnF6DataPd                         (rSysCtrl0[rcF6DataCtrl0]|=cBit0)
#define  rmSysDisF6DataPd                        (rSysCtrl0[rcF6DataCtrl0]&=(~cBit0))
#define  rmSysEnF6DataPu                         (rSysCtrl0[rcF6DataCtrl0]|=cBit1)
#define  rmSysDisF6DataPu                        (rSysCtrl0[rcF6DataCtrl0]&=(~cBit1))

#define  rcF7IoCtrl0                             0x5C
#define  rmSysEnF7RwOe                           (rSysCtrl0[rcF7IoCtrl0]|=cBit3)
#define  rmSysDisF7RwOe                          (rSysCtrl0[rcF7IoCtrl0]&=(~cBit3))
#define  rmSysEnF7RwPu                           (rSysCtrl0[rcF7IoCtrl0]|=cBit1)
#define  rmSysDisF7RwPu                          (rSysCtrl0[rcF7IoCtrl0]&=(~cBit1))

#define  rcF7AleCleCtrl0                         0x5D
#define  rmSysEnF7AleCleOe                       (rSysCtrl0[rcF7AleCleCtrl0]|=cBit3)
#define  rmSysDisF7AleCleOe                      (rSysCtrl0[rcF7AleCleCtrl0]&=(~cBit3))
#define  rmSysEnF7AleClePd                       (rSysCtrl0[rcF7AleCleCtrl0]|=cBit0)
#define  rmSysDisF7AleClePd                      (rSysCtrl0[rcF7AleCleCtrl0]&=(~cBit0))

#define  rcF7DqsCtrl0                            0x5E
#define  rmSysEnF7DqsPd                          (rSysCtrl0[rcF7DqsCtrl0]|=cBit0)
#define  rmSysDisF7DqsPd                         (rSysCtrl0[rcF7DqsCtrl0]&=(~cBit0))
#define  rmSysEnF7DqsPu                          (rSysCtrl0[rcF7DqsCtrl0]|=cBit1)
#define  rmSysDisF7DqsPu                         (rSysCtrl0[rcF7DqsCtrl0]&=(~cBit1))

#define  rcF7DataCtrl0                           0x5F
#define  rmSysEnF7DataPd                         (rSysCtrl0[rcF7DataCtrl0]|=cBit0)
#define  rmSysDisF7DataPd                        (rSysCtrl0[rcF7DataCtrl0]&=(~cBit0))
#define  rmSysEnF7DataPu                         (rSysCtrl0[rcF7DataCtrl0]|=cBit1)
#define  rmSysDisF7DataPu                        (rSysCtrl0[rcF7DataCtrl0]&=(~cBit1))

#define  rcFwpIoCtrl                             0x60
#define  rmChkPw1IsoGate                         (rSysCtrl0[rcFwpIoCtrl]&cBit7)
#define  rmChkPw2IsoGate                         (rSysCtrl0[rcFwpIoCtrl]&cBit6)
#define  rmSysDisFwp                             (rSysCtrl0[rcFwpIoCtrl]|=cBit0)    // Flash write protect outpput value
#define  rmSysEnFwp                              (rSysCtrl0[rcFwpIoCtrl]&=(~cBit0))    // Flash write protect output value

#define  rcWdt                                   0x63
#if (_EN_WDT)
#define  rmEnWdt                                 {(gsLightSwitch.usOem3Ls.uEnWdt)?(rSysCtrl0[rcWdt]|=cBit7):(rmDisWdt);}
#else
#define  rmEnWdt                                 rmDisWdt
#endif
#define  rmDisWdt                                (rSysCtrl0[rcWdt]&=(~cBit7))
#define  rmChkWdtTimeOut                         (rSysCtrl0[rcWdt]&cBit6)
#define  rmSetWdtNonResetSys                     (rSysCtrl0[rcWdt]|=cBit5)
#define  rmSetWdtResetSys                        (rSysCtrl0[rcWdt]&=(~cBit5))
#define  rmSetWdt(val)                           (rSysCtrl0[rcWdt]=((rSysCtrl0[rcWdt]&0xE3)|(val<<2)))
#define  rmClrWdtTimeOut                         (rSysCtrl0[rcWdt]|=cBit1)    // clear bit 6
#define  rmResetWdtTimer                         (rSysCtrl0[rcWdt]|=cBit0)

// 2260 timer function
// SM2260 have 1 system timer(25MHz) and 2 RTC timer (1s and 32.768KHz)

// HW system timer run @ 25MHz
// HW system timer will generate interrupt once the counter reach 'high-16bit' meet Int Timer Cnt;
// It don't have extra interrupt control
#define rcTimerIntCnt                            0x64
#define rmSetSysTimerCnt(x)                      (r16SysCtrl0[rcTimerIntCnt/2]=x)

#define rcTimerControl                           0x66
#define rmResetTimerCnt                          (rSysCtrl0[rcTimerControl]|=cBit1)
#define rmTimerEnable                            (rSysCtrl0[rcTimerControl]|=cBit0)
#define rmTimerDisable                           (rSysCtrl0[rcTimerControl]&=(~cBit0))
#define rmChkTimerEnable                         (rSysCtrl0[rcTimerControl]&cBit0)

#define rcTimerIntType                           0x67    // This byte determine which timer interrupt type is , TSB, not implement in hardware
// yet
#define rmTimerIntType                           rSysCtrl0[rcTimerIntType]

#define rcCrData                                 0x68
#define rcCrCtrl                                 0x6A

#define rmClrCtrl                                (rSysCtrl0[rcCrCtrl]=(0x00|cBit5))

#define rmCrDataInOut                            r16SysCtrl0[rcCrData/2]
#define rmCrAck                                  (rSysCtrl0[rcCrCtrl]&cBit7)

#define rmCrAutoClrEn                            (rSysCtrl0[rcCrCtrl]|=(cBit4|cBit5))
#define rmCrAutoClrDis                           (rSysCtrl0[rcCrCtrl]&=(~cBit4|cBit5))

#if _CR_POLLING
#define rmCrCapAddr                              (rSysCtrl0[rcCrCtrl]=(cBit3|cBit5))
#define rmCrCapData                              (rSysCtrl0[rcCrCtrl]=(cBit2|cBit5))
#define rmCrReadData                             (rSysCtrl0[rcCrCtrl]=(cBit1|cBit5))
#define rmCrWriteData                            (rSysCtrl0[rcCrCtrl]=(cBit0|cBit5))
#else
#define rmCrCapAddr                              (rSysCtrl0[rcCrCtrl]=(cBit3|cBit4|cBit5))
#define rmCrCapData                              (rSysCtrl0[rcCrCtrl]=(cBit2|cBit4|cBit5))
#define rmCrReadData                             (rSysCtrl0[rcCrCtrl]=(cBit1|cBit4|cBit5))
#define rmCrWriteData                            (rSysCtrl0[rcCrCtrl]=(cBit0|cBit4|cBit5))
#endif

#define rmPolCrCapAddr                           (rSysCtrl0[rcCrCtrl]&cBit3)
#define rmPolCrCapData                           (rSysCtrl0[rcCrCtrl]&cBit2)
#define rmPolCrReadData                          (rSysCtrl0[rcCrCtrl]&cBit1)
#define rmPolCrWriteData                         (rSysCtrl0[rcCrCtrl]&cBit0)

#define  rmSetCrAddr(x)                          (r32SysCtrl0[rcCrData/4]=0x00080000|x)
#define  rmSetCrData(x)                          (r32SysCtrl0[rcCrData/4]=0x00040000|x)
#define  rmSetCrWr                               (rSysCtrl0[rcCrCtrl]=0x01)
#define  rmSetCrRd                               (rSysCtrl0[rcCrCtrl]=0x02)
#define  rmSetCrIdle                             (rSysCtrl0[rcCrCtrl]=0x00)

#define  rmSetCrIdle                             (rSysCtrl0[rcCrCtrl]=0x00)
#define  rmChkCrAck                              (rSysCtrl0[rcCrCtrl]&cBit7)

#define rcExPwDnCtrl                             0x6C
#define rmSetExPwDnEn                            (rSysCtrl0[rcExPwDnCtrl]|=cBit0)
#define rmClrExPwDnEn                            (rSysCtrl0[rcExPwDnCtrl]&=(~cBit0))

#define rcPerstNi                                0x6D
#define rmChkPerstNi                                                 (rSysCtrl0[rcPerstNi]&cBit0)

#if (_GREYBOX)    // Greybox mode, Please change to normal 3 times..
#define cRwIdle32kTmrVal                         12    // (1/32.768Hz)*4 ~=122us
#define cRwIdleTmrVal                            81    // 27*65536*40ns~=70ms
#define cPartialCleanTmerVal1                    105    // ~=92ms
#define cPartialCleanTmerVal2                    51    // ~=46ms
#define cPartialCleanTmer334ms                   381    // ~=334ms
#define cPartialCleanTmer300ms                   345    // ~=300ms
#define cPartialCleanTmer270ms                   309    // ~=270ms
#define cPartialCleanTmer250ms                   285    // ~=250ms
#define cPartialCleanTmer240ms                   276    // ~=240ms
#define cPartialCleanTmer225ms                   258    // ~=225ms
#define cPartialCleanTmer210ms                   240    // ~=210ms
#define cPartialCleanTmer200ms                   231    // ~=200ms
#define cPartialCleanTmer180ms                   207    // ~=180ms
#define cPartialCleanTmer150ms                   171    // ~=150ms
#define cPartialCleanTmer120ms                   138    // ~=120ms
#define cPartialCleanTmer100ms                   114    // ~=100ms
#define cPartialCleanTmer95ms                    108    // ~=95ms
#define cPartialCleanTmer90ms                    102    // ~=90ms
#define cPartialCleanTmer70ms                    81    // ~=70ms
#define cPartialCleanTmer50ms                    57    // ~=49ms
#define cPartialCleanTmer45ms                    51    // ~=45ms
#define cPartialCleanTmer40ms                    45    // ~=40ms
#define cPartialCleanTmer20ms                    24    // ~=20ms
#define c32PartialCleanRtc5ms                    (5*96)
#define c32PartialCleanRtc10ms                   (10*96)
#define c32PartialCleanRtc15ms                   (15*96)
#define c32PartialCleanRtc20ms                   (20*96)
#define c32PartialCleanRtc25ms                   (25*96)
#define c32PartialCleanRtc30ms                   (30*96)
#define c32PartialCleanRtc50ms                   (50*96)
#define c32PartialCleanRtc100ms                  (100*96)
#define c32PartialCleanRtc120ms                  (120*96)
#define c32PartialCleanRtc150ms                  (150*96)
#define c32PartialCleanRtc200ms                  (200*96)
#define c32PartialCleanRtc240ms                  (240*96)
#define c32PartialCleanRtc480ms                  (480*96)
#define c32PartialCleanRtc2s                     (2000*96)
#define c32PartialCleanRtc8s                     (8000*96)
#define c32PartialCleanRtc32s                    (32000*96)

#define c16PartialCleanTmerVal2                  765    // 255*1.31ms~=335ms
#define cSataTrimTmrVal                          765    // 255*1.31ms~=335ms
#define cIdleTmrVal                              90    // ~=80ms //35    // ~=90ms
#define c16QeTmrVal                              765
#define cReadScrbTmrVal                          c32PartialCleanRtc25ms*3    // 80*1.31~=90ms
#else    // if (_GREYBOX)

#if _EN_LenovoPFail    // Chief_20190129
#define cAPSTIdle32kTmrVal                       2000    // (1/32.768Hz)*4 ~=122us
#define cRwIdle32kTmrVal                         4    // (1/32.768Hz)*4 ~=122us
#define cRwIdleTmrVal                            1    // 27*65536*40ns~=70ms
#else
#define cRwIdle32kTmrVal                         4    // (1/32.768Hz)*4 ~=122us
#define cRwIdleTmrVal                            27    // 27*65536*40ns~=70ms
#endif
#define cPartialCleanTmerVal1                    35    // ~=92ms
#define cPartialCleanTmerVal2                    17    // ~=46ms
#define cPartialCleanTmer334ms                   127    // ~=334ms
#define cPartialCleanTmer300ms                   115    // ~=300ms
#define cPartialCleanTmer270ms                   103    // ~=270ms
#define cPartialCleanTmer250ms                   95    // ~=250ms
#define cPartialCleanTmer240ms                   92    // ~=240ms
#define cPartialCleanTmer225ms                   86    // ~=225ms
#define cPartialCleanTmer210ms                   80    // ~=210ms
#define cPartialCleanTmer200ms                   77    // ~=200ms
#define cPartialCleanTmer180ms                   69    // ~=180ms
#define cPartialCleanTmer150ms                   57    // ~=150ms
#define cPartialCleanTmer120ms                   46    // ~=120ms
#define cPartialCleanTmer100ms                   38    // ~=100ms
#define cPartialCleanTmer95ms                    36    // ~=95ms
#define cPartialCleanTmer90ms                    34    // ~=90ms
#define cPartialCleanTmer70ms                    27    // ~=70ms
#define cPartialCleanTmer50ms                    19    // ~=49ms
#define cPartialCleanTmer45ms                    17    // ~=45ms
#define cPartialCleanTmer40ms                    15    // ~=40ms
#define cPartialCleanTmer20ms                    8    // ~=20ms
#define c32PartialCleanRtc5ms                    (5*32)
#define c32PartialCleanRtc10ms                   (10*32)
#define c32PartialCleanRtc15ms                   (15*32)
#define c32PartialCleanRtc20ms                   (20*32)
#define c32PartialCleanRtc25ms                   (25*32)
#define c32PartialCleanRtc30ms                   (30*32)
#define c32PartialCleanRtc50ms                   (50*32)
#define c32PartialCleanRtc100ms                  (100*32)
#define c32PartialCleanRtc120ms                  (120*32)
#define c32PartialCleanRtc150ms                  (150*32)
#define c32PartialCleanRtc200ms                  (200*32)
#define c32PartialCleanRtc240ms                  (240*32)
#define c32PartialCleanRtc480ms                  (480*32)
#define c32PartialCleanRtc2s                     (2000*32)
#define c32PartialCleanRtc8s                     (8000*32)
#define c32PartialCleanRtc32s                    (32000*32)

#define c16PartialCleanTmerVal2                  255    // 255*1.31ms~=335ms
#define cSataTrimTmrVal                          255    // 255*1.31ms~=335ms
#define cIdleTmrVal                              30    // ~=70ms revert from 50ms for SS_2280
#define c16QeTmrVal                              255
#define cReadScrbTmrVal                          c32PartialCleanRtc25ms
#endif    // if (_GREYBOX)
#define cPcieErrHoldVal                          192    // ~=500ms
#define cPsModeRtcWakeupPos10Min                 (600*2)    // 10min*60s*2Hz=1200
#define cPsModeRtcWakeupNeg10Min                 (0x10000-cPsModeRtcWakeupPos10Min)

enum
{
    cRaiseBufFlag,
    cLowerBufFlag,
};

enum
{
    cBrkRwTmr=cBit0,

    // cGetWFlag=cBit1,
    cBrkRdoWTmr=cBit2,
    cEnSysTmr=cBit7,
};

#define cRwPreventTO                             770    // 2s

#define rcRtcCtrl1                               0x75
#define rmRtcAllReset                            {(rSysCtrl0[rcRtcCtrl1]|=0xC0);_nop();_nop();_nop();(rSysCtrl0[rcRtcCtrl1]&=0x3F);}
#define rmRtcSetReset                            (rSysCtrl0[rcRtcCtrl1]|=0xC0)
#define rmRtcClrReset                            (rSysCtrl0[rcRtcCtrl1]&=0x3F)

#define rmRtc32kReset                            {(rSysCtrl0[rcRtcCtrl1]|=cBit7);_nop();_nop();_nop();(rSysCtrl0[rcRtcCtrl1]&=(~cBit7));}
#define rmRtc1sReset                             {(rSysCtrl0[rcRtcCtrl1]|=cBit6);_nop();_nop();_nop();(rSysCtrl0[rcRtcCtrl1]&=(~cBit6));}
#define rmRtc32kIntEnable                        (rSysCtrl0[rcRtcCtrl1]|=cBit5)
#define rmRtc32kIntDisable                       (rSysCtrl0[rcRtcCtrl1]&=(~cBit5))
#define rmRtc1sIntEnable                         (rSysCtrl0[rcRtcCtrl1]|=cBit4)
#define rmRtc1sIntDisable                        (rSysCtrl0[rcRtcCtrl1]&=(~cBit4))
#define rmRtc32kClearInt                         {(rSysCtrl0[rcRtcCtrl1]|=cBit3);_nop();_nop();_nop();(rSysCtrl0[rcRtcCtrl1]&=(~cBit3));}
#define rmChkRtc32kInt                           (rSysCtrl0[rcRtcCtrl1]&cBit3)
#define rmRtc1sClearInt                          {(rSysCtrl0[rcRtcCtrl1]|=cBit2);_nop();_nop();_nop();(rSysCtrl0[rcRtcCtrl1]&=(~cBit2));}
#define rmChkRtc1sInt                            (rSysCtrl0[rcRtcCtrl1]&cBit2)
#define rmSysSetRtcIs(x)                         (rSysCtrl0[rcRtcCtrl1]=(rSysCtrl0[rcRtcCtrl1]&0xFC)|x)

#define rcRtcCtrl0                               0x76
#define rmRtcTrim(x)                             (r16SysCtrl0[rcRtcCtrl0/2]=(r16SysCtrl0[rcRtcCtrl0/2]&0xFE00)|(x&0x01FF))
// #define rmRtcPowerDown                           (r16SysCtrl0[rcRtcCtrl0/2]|=c16Bit12)
// #define rmRtcPowerUp                             (r16SysCtrl0[rcRtcCtrl0/2]&=(~c16Bit12))

#define rcRtcCtrl2                               0x77
#define rmRtcPowerDown                           (rSysCtrl0[rcRtcCtrl2]|=cBit4)
#define rmRtcPowerUp                             (rSysCtrl0[rcRtcCtrl2]&=(~cBit4))
#define rmRtc2HzReset                            {(rSysCtrl0[rcRtcCtrl2]|=cBit7);_nop();_nop();_nop();(rSysCtrl0[rcRtcCtrl2]&=(~cBit7));}
#define rmRtc2HzIntEnable                        (rSysCtrl0[rcRtcCtrl2]|=cBit6)
#define rmRtc2HzIntDisable                       (rSysCtrl0[rcRtcCtrl2]&=(~cBit6))
#define rmRtc2HzClearInt                         {(rSysCtrl0[rcRtcCtrl2]|=cBit5);_nop();_nop();_nop();(rSysCtrl0[rcRtcCtrl2]&=(~cBit5));}
#define rmChkRtc2HzInt                           (rSysCtrl0[rcRtcCtrl2]&cBit5)

#define rcRtc1S                                  0x80
#define rmGetRtc1sTick                           r32SysCtrl0[rcRtc1S/4]
#define rmSetRtc1sMaskLo(x)                      (r16SysCtrl0[rcRtc1S/2]=x)

// #define rcRtcTimerCk1Hz                          0x80
// #define rcRtcTimerCk32kHz                        0x84
// #define rmGetRtc1HzTimerValue                    r32SysCtrl0[rcRtcTimerCk1Hz/4]
// #define rmGetRtc32kHzTimerValue                  r32SysCtrl0[rcRtcTimerCk32kHz/4]
// #define rmRtc32kTimerSrst\
//    rSysCtrl0[rcRtcCtrl1]|=cBit7;\
//    rSysCtrl0[rcRtcCtrl1]&=~cBit7
// #define rmRtc1sTimerSrst                         rSysCtrl0[rcRtcCtrl1]|=cBit6;rSysCtrl0[rcRtcCtrl1]&=~cBit6

#define rcRtc32K                                 0x84
#define rmGetRtc32kTick                          r32SysCtrl0[rcRtc32K/4]
#define rmSetRtc32kMaskLo(x)                     (r16SysCtrl0[rcRtc32K/2]=x)

#define rcRtc2Hz                                 0x88
#define rmGetRtc2HzTick                          (r32SysCtrl0[rcRtc2Hz/4])
#define rmSetRtc2HzMaskLo(x)                     (r16SysCtrl0[rcRtc2Hz/2]=x)

#define  rcSioSel1                               0x8C
#define  rmDisFshReLPF                           (rSysCtrl0[rcSioSel1]=((rSysCtrl0[rcSioSel1]&0xF0)))    // (rSysCtrl0[rcSioSel1]=((rSysCtrl0[rcSioSel1]&0xFC)))
#define  rmSetFshReLPF(x)                        (rSysCtrl0[rcSioSel1]=((rSysCtrl0[rcSioSel1]&0xF0)|x))    // (rSysCtrl0[rcSioSel1]=((rSysCtrl0[rcSioSel1]&0xFC)|x))

#define  rcCtrlIoCh0                             0x90    // CLE ALE WE RE
#define  rcDataIoCh0                             0x94    // DATA & DQS

#define  rcSysI2cDri                             0xD4
#define  rcSysJtagDri                            0xD5
#define  rcSysLedDri                             0xD6
#define  rcSysLedData                            0xD7    // discuss with HW

#define  rcFwpIoCtrl1                            0xD8
#define  rcIeDdrEn                               0xDC
#define  rmDdrEn                                 (rSysCtrl0[rcIeDdrEn]|=cBit2)
#define  rmDdrDis                                (rSysCtrl0[rcIeDdrEn]&=(~cBit2))
#define  rmChkDdrEn                              (rSysCtrl0[rcIeDdrEn]&cBit2)
#define  rmChkDfDdrEn                            (rSysCtrl0[rcIeDdrEn]&0x03)
#define  rmDfDdrEn                               (rSysCtrl0[rcIeDdrEn]=(rSysCtrl0[rcIeDdrEn]&0xFC)|0x03)
#define  rmDfDdrSet(x)                           (rSysCtrl0[rcIeDdrEn]=(rSysCtrl0[rcIeDdrEn]&0xFC)|x)
#define  rmGetDdrVal                             rSysCtrl0[rcIeDdrEn]
#define  rmSetDdrVal(x)                          (rSysCtrl0[rcIeDdrEn]=x)

#define rcSysVrefCtrl0                           0xE0
#define rcSysVrefCtrl1                           0xE1
#define rmSetVrefDiv2(x)                         rSysCtrl0[rcSysVrefCtrl1]=x    // 0:enable 1:disable
#define rcSysVrefCtrl2                           0xE2
#define rcSysVrefComp                            0xE3    // discuss with HW
#define rmSetSysRefDdIn(x)                       rSysCtrl0[rcSysVrefCtrl0]=(rSysCtrl0[rcSysVrefCtrl0]&0xF0)|(x&0x0F)
#define rmSetSysRefDuIn(x)                       rSysCtrl0[rcSysVrefCtrl0]=(rSysCtrl0[rcSysVrefCtrl0]&0x0F)|((x&0x0F)<<4)

#define rmSysEnFCal                              r32SysCtrl0[rcSysVrefCtrl0/4]=(r32SysCtrl0[rcSysVrefCtrl0/4]&0xFFAAAAFF)|0x00555500
#define rmSysDisFCal                             r32SysCtrl0[rcSysVrefCtrl0/4]=(r32SysCtrl0[rcSysVrefCtrl0/4]&0xFFAAAAFF)
#define rmSetSysFVren(x, y)\
    rSysCtrl0[rcSysVrefCtrl1+x/\
              4]=(rSysCtrl0[rcSysVrefCtrl1+x/4]&~(0x01<<(x%4)*2+1))|(y<<(x%4)*2+1)

#define rmChkSysVfComp(x)                        (rSysCtrl0[rcSysVrefComp]&(0x01<<x))

#define rcFshZqCtrl                              0xE4    // discuss with HW
#define rcFshZqComp                              0xE5    // discuss with HW

// Use AIP b15 ~ b4 for device sleep mode control
// b[3]    : Inform ROM code resume from DevSleep mode, set one in ISP code
// b[5:4]  : Flash operation type
// b[31:6] : BootISP start block
#define  rcAipFlipFlopCtrl0                      0xEC
#define  rcAipFlipFlopCtrl1                      0xED

#define  rmChkDevSleepMode3                      (r16SysCtrl0[rcAipFlipFlopCtrl0/2]&c16Bit3)
#define  rmChkTsbOrSndkA2CmdFlash                (((r16SysCtrl0[rcAipFlipFlopCtrl0/2]&0x0030)>>4)==0x0000)
#define  rmChkSecDACmdFlash                      (((r16SysCtrl0[rcAipFlipFlopCtrl0/2]&0x0030)>>4)==0x0001)
#define  rmChkFlashNormalCmd                     (((r16SysCtrl0[rcAipFlipFlopCtrl0/2]&0x0030)>>4)==0x0002)
#define  rmChkFlashMicronSlcOTFCmd               (((r16SysCtrl0[rcAipFlipFlopCtrl0/2]&0x0030)>>4)==0x0003)
#define  rmBootISPStartBlock                     (r16SysCtrl0[rcAipFlipFlopCtrl0/2]>>6)

#define  rcAipFlipFlopCtrl2                      0xEE
#define  rmEnWrAIPFlipFlop                       (rSysCtrl0[rcAipFlipFlopCtrl2]|=cBit0)
#define  rmDisWrAIPFlipFlop                      (rSysCtrl0[rcAipFlipFlopCtrl2]&=~cBit0)

#define  rcSysCk4ADivCtrl                        0xEF
#define  rmSysEnLdpcHDecAutoDiv                  (rSysCtrl0[rcSysCk4ADivCtrl]|=cBit7)
#define  rmSysDisLdpcHDecAutoDiv                 (rSysCtrl0[rcSysCk4ADivCtrl]&=(~cBit7))
#define  rmSysSetLdpcHDecAutoDiv(x)              (rSysCtrl0[rcSysCk4ADivCtrl]=(rSysCtrl0[rcSysCk4ADivCtrl]&0x8F)|(x<<4))
#define  rmSysEnLdpcSDecAutoDiv                  (rSysCtrl0[rcSysCk4ADivCtrl]|=cBit3)
#define  rmSysDisLdpcSDecAutoDiv                 (rSysCtrl0[rcSysCk4ADivCtrl]&=(~cBit3))
#define  rmSysSetLdpcSDecAutoDiv(x)              (rSysCtrl0[rcSysCk4ADivCtrl]=(rSysCtrl0[rcSysCk4ADivCtrl]&0xF8)|x)

#define  rcSmi2260Ctrl2                          0xF8
#define  rmSetPwrSw1On                           (rSysCtrl0[rcSmi2260Ctrl2]|=cBit4)
#define  rmSetPwrSw1Off                          (rSysCtrl0[rcSmi2260Ctrl2]&=~cBit4)
#define  rmSetPwrSw2On                           (rSysCtrl0[rcSmi2260Ctrl2]|=cBit5)
#define  rmSetPwrSw3Off                          (rSysCtrl0[rcSmi2260Ctrl2]&=~cBit5)

#define  rcSmi2260Ctrl3                          0xFC
#define  rmChkClkReqAssert                       (rSysCtrl0[rcSmi2260Ctrl3]&cBit1)
#define  rmChkClkReqDeassert                     (!rmChkClkReqAssert)

#define  rcSmi2260Ctrl3M                         0xFE    // discuss with HW
#define  rcSmi2260Ctrl3H                         0xFF    // discuss with HW

#define  rcSmi2260Ctrl4                          0x100
// FW can use bit0/bit1/bit2, HW already used bit3-7
#define  rmChkManufactureFlag                    (rSysCtrl0[rcSmi2260Ctrl4]&cBit0)
#define  rmSetManufactureFlag                    (rSysCtrl0[rcSmi2260Ctrl4]|=cBit0)
#define  rmClrManufactureFlag                    (rSysCtrl0[rcSmi2260Ctrl4]&=~cBit0)
#define  rmChkInDevSlp                           (rSysCtrl0[rcSmi2260Ctrl4]&cBit1)
#define  rmSetInDevSlp                           (rSysCtrl0[rcSmi2260Ctrl4]|=cBit1)
#define  rmClrInDevSlp                           (rSysCtrl0[rcSmi2260Ctrl4]&=~cBit1)
#define  rmChkImFlash                            (rSysCtrl0[rcSmi2260Ctrl4]&cBit2)
#define  rmSetImFlash                            (rSysCtrl0[rcSmi2260Ctrl4]|=cBit2)
#define  rmClrImFlash                            (rSysCtrl0[rcSmi2260Ctrl4]&=~cBit2)

#define  rmSetPw1AutoPd                          (rSysCtrl0[rcSmi2260Ctrl4+1]|=cBit0)
#define  rmClrPw1AutoPd                          (rSysCtrl0[rcSmi2260Ctrl4+1]&=~cBit0)
#define  rmSetPw2AutoPd                          (rSysCtrl0[rcSmi2260Ctrl4+1]|=cBit1)
#define  rmClrPw2AutoPd                          (rSysCtrl0[rcSmi2260Ctrl4+1]&=~cBit1)

#define  rcVdt10                                 0x102
#define  rmChkVdt10Good                          (rSysCtrl0[rcVdt10]&cBit7)
#define  rmDisVdt10                              (rSysCtrl0[rcVdt10]|=cBit4)
#define  rmEnVdt10                               (rSysCtrl0[rcVdt10]&=(~cBit4))
#define  rmSetVdt10(val)                         (rSysCtrl0[rcVdt10]=((rSysCtrl0[rcVdt10]&0xF0)|(val&0x0F)))

#define  rcCmlSel                                0x103
// #define  rmSysSetCmlPd(x)                        (rSysCtrl0[rcCmlSel]=rSysCtrl0[rcCmlSel]&0x0F)|((x&0F)<<4)
#define  rmSysSetCmlPd                           (rSysCtrl0[rcCmlSel]|=cBit3)

#define rcPciePd0                                0x105
// FW can use bit2-7, HW already used bit0-1
// #if _PS3p5
// #define  rmChkInPs3p5                            (rSysCtrl0[rcPciePd0]&cBit2)
// #define  rmSetInPs3p5                            (rSysCtrl0[rcPciePd0]|=cBit2)
// #define  rmClrInPs3p5                            (rSysCtrl0[rcPciePd0]&=(~cBit2))
// #endif
#define  rmChkFwCommitRst                        (rSysCtrl0[rcPciePd0]&cBit3)
#define  rmSetFwCommitRst                        (rSysCtrl0[rcPciePd0]|=cBit3)
#define  rmClrFwCommitRst                        (rSysCtrl0[rcPciePd0]&=(~cBit3))

#define  rmSetFVdt18                             (rSysCtrl0[rcPciePd0]|=cBit6)
#define  rmClrFVdt18                             (rSysCtrl0[rcPciePd0]&=(~cBit6))
#define  rmChkFVdt18                             (rSysCtrl0[rcPciePd0]&cBit6)

#define  rmSetFVdt23                             (rSysCtrl0[rcPciePd0]|=cBit7)
#define  rmClrFVdt23                             (rSysCtrl0[rcPciePd0]&=(~cBit7))
#define  rmChkFVdt23                             (rSysCtrl0[rcPciePd0]&cBit7)
#define  rmClrFVdt                               (rSysCtrl0[rcPciePd0]&=0x3F)
#define rcPciePd1                                0x106
#define rmPciePxPdWPull(ch)                      (rSysCtrl0[rcPciePd1]|=(cbBitTab[ch]<<4))
#define rmPciePxPoWPull(ch)                      (rSysCtrl0[rcPciePd1]&=(~(cbBitTab[ch]<<4)))
#define rmPciePxPdTx(ch)                         (rSysCtrl0[rcPciePd1]|=cbBitTab[ch])
#define rmPciePxPoTx(ch)                         (rSysCtrl0[rcPciePd1]&=(~cbBitTab[ch]))

#define rcPciePd2                                0x107
#define rmPciePxPdRx(ch)                         (rSysCtrl0[rcPciePd2]|=(cbBitTab[ch]<<4))
#define rmPciePxPoRx(ch)                         (rSysCtrl0[rcPciePd2]&=(~(cbBitTab[ch]<<4)))
#define rmPciePxPdSq(ch)                         (rSysCtrl0[rcPciePd2]|=cbBitTab[ch])
#define rmPciePxPoSq(ch)                         (rSysCtrl0[rcPciePd2]&=(~cbBitTab[ch]))

#define  rcPcieDphyPxReg                         0x108
#define  rmPcieTxInvertEn                        (rSysCtrl0[rcPcieDphyPxReg]|=((cBit7|cBit5|cBit3|cBit1)))
#define  rmPcieTxInvertDis                       (rSysCtrl0[rcPcieDphyPxReg]&=(~(cBit7|cBit5|cBit3|cBit1)))
#define  rmPcieRxInvertEn                        (rSysCtrl0[rcPcieDphyPxReg]|=((cBit8|cBit6|cBit4|cBit2)))
#define  rmPcieRxInvertDis                       (rSysCtrl0[rcPcieDphyPxReg]&=(~(cBit8|cBit6|cBit4|cBit2)))

#define  rcPcieStepReg                           0x109
#define  rmEnablePcieSsc                         (rSysCtrl0[rcPcieStepReg]|=cBit7)
#define  rmDisablePcieSsc                        (rSysCtrl0[rcPcieStepReg]&=(~cBit7))
#define  rmCheckPcieSsc                          (rSysCtrl0[rcPcieStepReg]&cBit7)

#define  rmSetPcieStep(x)                        (rSysCtrl0[rcPcieStepReg]=(rSysCtrl0[rcPcieStepReg]&(~0x1F))|(x&0x1F))
#define  rmGetPcieStep                           (rSysCtrl0[rcPcieStepReg]&0x1F)

#define  rcPcieSmaxReg                           0x10A
#define  rmSetPcieSmax(x)                        (rSysCtrl0[rcPcieSmaxReg]=(rSysCtrl0[rcPcieSmaxReg]&(~0x3F))|(x&0x3F))
#define  rmGetPcieSmax                           (rSysCtrl0[rcPcieSmaxReg]&0x3F)

#define  rcPcieSminReg                           0x10B
#define  rmSetPcieSmin(x)                        (rSysCtrl0[rcPcieSminReg]=(rSysCtrl0[rcPcieSminReg]&(~0x3F))|(x&0x3F))
#define  rmGetPcieSmin                           (rSysCtrl0[rcPcieSminReg]&0x3F)

#define  rcPcieDphyReg                           0x10C
#define  rmSetEndIfReff                          (rSysCtrl0[rcPcieDphyReg]|=cBit0)
#define  rmClrEndIfReff                          (rSysCtrl0[rcPcieDphyReg]&=(~cBit0))
#define  rmSetEnExtOsc                           (rSysCtrl0[rcPcieDphyReg]|=cBit1)
#define  rmClrEnExtOsc                           (rSysCtrl0[rcPcieDphyReg]&=(~cBit1))
#define  rmSetLfckAutoGate                       (rSysCtrl0[rcPcieDphyReg]|=cBit2)
#define  rmClrtLfckAutoGate                      (rSysCtrl0[rcPcieDphyReg]&=(~cBit2))
#define  rmSetLfckGating                         (rSysCtrl0[rcPcieDphyReg]|=cBit4)
#define  rmClrLfckGating                         (rSysCtrl0[rcPcieDphyReg]&=(~cBit4))
// #define  rmSetCKUNGATE                         (rSysCtrl0[rcPcieDphyReg]|=cBit5)
// #define  rmClrCKUNGATE                         (rSysCtrl0[rcPcieDphyReg]&=(~cBit5))
#define  rmSysDisGen12AutoGate                   (rSysCtrl0[rcPcieDphyReg]|=cBit5)
#define  rmSysEnGen12AutoGate                    (rSysCtrl0[rcPcieDphyReg]&=(~cBit5))

#define  rcSysStepGen2                           0x10D    // discuss with HW
#define rmSetBypassPhyStatusReady                (rSysCtrl0[rcSysStepGen2]|=cBit7)

#define  rcPciePhyStatus                         0x10E
#define  rmChkPclkReady                          (rSysCtrl0[rcPciePhyStatus]&cBit3)

#define  rcSysStepGen3                           0x10F    // discuss with HW

#define  rcP0IntSet                              0x130    // [7:0]discuss with HW
// #define  rcP0IntSet                            0x131  //[15:8]discuss with HW
// #define  rcP0IntSet                            0x132  //[23:16]discuss with HW
// #define  rcP0IntSet                            0x133  //[31:24]discuss with HW

#define  rcP1IntSet                              0x134    // [7:0]discuss with HW
// #define  rcP1IntSet                            0x135  //[15:8]discuss with HW
// #define  rcP1IntSet                            0x136  //[23:16]discuss with HW
// #define  rcP1IntSet                            0x137  //[31:24]discuss with HW

#define  rcP2IntSet                              0x138    // [7:0]discuss with HW
// #define  rcP2IntSet                            0x139  //[15:8]discuss with HW
// #define  rcP2IntSet                            0x13A  //[23:16]discuss with HW
// #define  rcP2IntSet                            0x13B  //[31:24]discuss with HW

#define  rcGpioIntClr                            0x13C    // [7:0]discuss with HW
// #define  rcGpioIntClr                          0x13D  //[15:8]discuss with HW
// #define  rcGpioIntClr                          0x13E  //[23:16]discuss with HW

#define  rcRefSwCtl                              0x142
#define  rmSetCk3SourceXtal                      (rSysCtrl0[rcRefSwCtl]&=(~cBit7))
#define  rmSetPllTopSourceXtal                   (rSysCtrl0[rcRefSwCtl]&=(~cBit4))
#define  rmSetRefSwCtl(x)                        (rSysCtrl0[rcRefSwCtl]=(rSysCtrl0[rcRefSwCtl]&(~0x90))|(x))

#define  rcThsorIntCtrl0                         0x146    // discuss with HW
#define  rcThsorIntCtrl1                         0x147    // discuss with HW

#define  rcCk4AdivCntThr                         0x148    // discuss with HW
#define  rmSetLdpcClkDivCntThr(x)                (rSysCtrl0[rcCk4AdivCntThr]=x)

#define  rcCk4Adiv2ErrThr                        0x14A    // [7:0]discuss with HW
// #define  rcCk4Adiv2ErrThr                      0x14B  //[15:8]discuss with HW
#define  rmSetLdpcClkDiv2ErrThr(x)               (rSysCtrl0[rcCk4Adiv2ErrThr]=x)

#define  rcCk4Adiv3ErrThr                        0x14C    // [7:0]discuss with HW
// #define  rcCk4Adiv3ErrThr                      0x14D  //[15:8]discuss with HW
#define  rmSetLdpcClkDiv3ErrThr(x)               (rSysCtrl0[rcCk4Adiv3ErrThr]=x)

#define  rcCk4Adiv4ErrThr                        0x14E    // [7:0]discuss with HW
// #define  rcCk4Adiv4ErrThr                      0x14F  //[15:8]discuss with HW
#define  rmSetLdpcClkDiv4ErrThr(x)               (rSysCtrl0[rcCk4Adiv4ErrThr]=x)

#define  rcCk4Adiv5ErrThr                        0x150    // [7:0]discuss with HW
// #define  rcCk4Adiv5ErrThr                      0x151  //[15:8]discuss with HW
#define  rmSetLdpcClkDiv5ErrThr(x)               (rSysCtrl0[rcCk4Adiv5ErrThr]=x)

#define  rcCk4Adiv6ErrThr                        0x152    // [7:0]discuss with HW
// #define  rcCk4Adiv6ErrThr                      0x153  //[15:8]discuss with HW
#define  rmSetLdpcClkDiv6ErrThr(x)               (rSysCtrl0[rcCk4Adiv6ErrThr]=x)

#define  rcIsdSsel                               0x180    // [7:0]discuss with HW
// #define  rcIsdSsel                             0x181  //[15:8]discuss with HW

#define  rcIsdDselP0                             0x184    // [7:0]discuss with HW
// #define  rcIsdDselP0                           0x185  //[15:8]discuss with HW
// #define  rcIsdDselP0                           0x186  //[23:16]discuss with HW
// #define  rcIsdDselP0                           0x187  //[31:24]discuss with HW

#define  rcIsdDselP1                             0x188    // [7:0]discuss with HW
// #define  rcIsdDselP1                           0x189  //[15:8]discuss with HW
// #define  rcIsdDselP1                           0x18A  //[23:16]discuss with HW
// #define  rcIsdDselP1                           0x18B  //[31:24]discuss with HW

#define  rcIsdDselP2                             0x18C    // [7:0]discuss with HW
// #define  rcIsdDselP2                           0x18D  //[15:8]discuss with HW
// #define  rcIsdDselP2                           0x18E  //[23:16]discuss with HW
// #define  rcIsdDselP2                           0x18F  //[31:24]discuss with HW

#define  rcThsorTrr1                             0x190    // [7:0]discuss with HW
// #define  rcThsorTrr1                           0x191  //[8]discuss with HW

#define  rcThsorTfr1                             0x192    // [7:0]discuss with HW
// #define  rcThsorTfr1                           0x193  //[8]discuss with HW

#define  rcThsorTrr2                             0x194    // [7:0]discuss with HW
// #define  rcThsorTrr2                           0x195  //[8]discuss with HW

#define  rcThsorTfr2                             0x196    // [7:0]discuss with HW
// #define  rcThsorTfr2                           0x197  //[8]discuss with HW

#define  rcThsorTrr3                             0x198    // [7:0]discuss with HW
// #define  rcThsorTrr3                           0x199  //[8]discuss with HW

#define  rcThsorTfr3                             0x19A    // [7:0]discuss with HW
// #define  rcThsorTfr3                           0x19B  //[8]discuss with HW

#define  rcSys1Cltr3                             0x19D
#define  rmEnE2eCrc15                            {(rSysCtrl0[rcSys1Cltr3]|=cBit0);asm ("DSB");}    // it is sector bypass mode
#define  rmDisE2eCrc15                           {(rSysCtrl0[rcSys1Cltr3]&=~cBit0);asm ("DSB");}
#define  rmChkE2eCrc15                           (rSysCtrl0[rcSys1Cltr3]&cBit0)

// System controller  Register PW1@ 0x5100_0000
#define  rcPw1SysCtrl0                           0x00
#define  rmChkI2cForceRom                        (rSysCtrl1[rcPw1SysCtrl0]&cBit7)

#define  rcPw1SysCtrl1                           0x01
#define  rmTrigClrBvfRam                         (rSysCtrl1[rcPw1SysCtrl1]|=cBit7)
#define  rmClrBvfRamDone                         (!(rSysCtrl1[rcPw1SysCtrl1]&cBit7))

#define  rcPw1ClkCtrl3                           0x0A
#define  rmSysEnLdpcClkAutoGate                  {rSysCtrl1[rcPw1ClkCtrl3]|=cBit6;rmSysEnLdpcClkAutoGate2;}
#define  rmSysDisLdpcClkAutoGate                 {rSysCtrl1[rcPw1ClkCtrl3]&=(~cBit6);rmSysDisLdpcClkAutoGate2;}
#define  rmSysEnRaidClkGate                      (rSysCtrl1[rcPw1ClkCtrl3]|=cBit5)
#define  rmSysDisRaidClkGate                     (rSysCtrl1[rcPw1ClkCtrl3]&=(~cBit5))
#define  rmSysEnFwAesClkGate                     (rSysCtrl1[rcPw1ClkCtrl3]|=cBit4)
#define  rmSysDisFwAesClkGate                    (rSysCtrl1[rcPw1ClkCtrl3]&=(~cBit4))
#define  rmSysEnRsaClkGate                       (rSysCtrl1[rcPw1ClkCtrl3]|=cBit3)
#define  rmSysDisRsaClkGate                      (rSysCtrl1[rcPw1ClkCtrl3]&=(~cBit3))
#define  rmSysEnBchClkGate                       (rSysCtrl1[rcPw1ClkCtrl3]|=cBit2)
#define  rmSysDisBchClkGate                      (rSysCtrl1[rcPw1ClkCtrl3]&=(~cBit2))
#define  rmEnableClkGate                         (rSysCtrl1[rcPw1ClkCtrl3]=0x7C)
#define  rmDisableClkGate                        (rSysCtrl1[rcPw1ClkCtrl3]=0x00)

// #define  rcHwVersion                             0x0B
// #define  rmGetHwVersion                          rSysCtrl1[rcHwVersion]

#define  rcSysFshMemPd                           0x0C
#define  rmSysSetFshMemPd(x)                     (rSysCtrl1[rcSysFshMemPd]=x)

// #define  M_SysEnAllMemPdExceptRaidNvmeAes        r16SysCtrl1[rcSysFshMemPd/2]=0x2900   //2262
#define  M_SysEnAllMemPdExceptRaidNvmeAes        r16SysCtrl1[rcSysFshMemPd/2]=0x2800
// #define  rmSysEnAllMemPd                      (r16SysCtrl1[rcSysFshMemPd/2]=0x3B00)  //2262
#define  rmSysEnAllMemPd                         (r16SysCtrl1[rcSysFshMemPd/2]=0x3A00)
#define  rmSysDisAllMemPd                        (r16SysCtrl1[rcSysFshMemPd/2]=0x0800)

#define  rcSysMemPd                              0x0D
#define  rmSysEnBvfMemPd                         (rSysCtrl1[rcSysMemPd]|=cBit6)
#define  rmSysDisBvfMemPd                        (rSysCtrl1[rcSysMemPd]&=(~cBit6))
#define  rmSysEnLdpcMemPd                        (rSysCtrl1[rcSysMemPd]|=cBit5)
#define  rmSysDisLdpcMemPd                       (rSysCtrl1[rcSysMemPd]&=(~cBit5))
#define  rmSysEnRaidMemPd                        (rSysCtrl1[rcSysMemPd]|=cBit4)
#define  rmSysDisRaidMemPd                       (rSysCtrl1[rcSysMemPd]&=(~cBit4))
#define  rmSysEnAhciMemPd                        (rSysCtrl1[rcSysMemPd]|=cBit3)
#define  rmSysDisAhciMemPd                       (rSysCtrl1[rcSysMemPd]&=(~cBit3))
#define  rmSysEnNvmeMemPd                        (rSysCtrl1[rcSysMemPd]|=cBit2)
#define  rmSysDisNvmeMemPd                       (rSysCtrl1[rcSysMemPd]&=(~cBit2))
#define  rmSysEnAesMemPd                         (rSysCtrl1[rcSysMemPd]|=cBit1)
#define  rmSysDisAesMemPd                        (rSysCtrl1[rcSysMemPd]&=(~cBit1))
#define  rmSysEnTsbMemPd                         (rSysCtrl1[rcSysMemPd]|=cBit0)
#define  rmSysDisTsbMemPd                        (rSysCtrl1[rcSysMemPd]&=(~cBit0))

#define  rcFrbMode                               0x11
#define  rmEnFrbMode                             (rSysCtrl1[rcFrbMode]=1)

#define  rcFrbCtrl3                              0x14
#define  rmFrb                                   rSysCtrl1[rcFrbCtrl3]

#define  rcFrbCtrl1                              0x15
#define  rmFrbPullUp                             (rSysCtrl1[rcFrbCtrl1]=0x10)
#define  rmFrbPullDown                           (rSysCtrl1[rcFrbCtrl1]=0x01)

#define  rcFshSlv0DqsIoCtrl                      0x18
#define  rmSysEnF0DqsOe                          (rSysCtrl1[rcFshSlv0DqsIoCtrl]|=cBit0)
#define  rmSysDisF0DqsOe                         (rSysCtrl1[rcFshSlv0DqsIoCtrl]&=(~cBit0))

#define  rcFshSlv0DataIoCtrl                     0x19
#define  rmSysEnF0DataOe                         (rSysCtrl1[rcFshSlv0DataIoCtrl]|=cBit0)
#define  rmSysDisF0DataOe                        (rSysCtrl1[rcFshSlv0DataIoCtrl]&=(~cBit0))

#define  rcFshSlv1DqsIoCtrl                      0x1C
#define  rmSysEnF1DqsOe                          (rSysCtrl1[rcFshSlv1DqsIoCtrl]|=cBit0)
#define  rmSysDisF1DqsOe                         (rSysCtrl1[rcFshSlv1DqsIoCtrl]&=(~cBit0))

#define  rcFshSlv1DataIoCtrl                     0x1D
#define  rmSysEnF1DataOe                         (rSysCtrl1[rcFshSlv1DataIoCtrl]|=cBit0)
#define  rmSysDisF1DataOe                        (rSysCtrl1[rcFshSlv1DataIoCtrl]&=(~cBit0))

#define  rcFshSlv2DqsIoCtrl                      0x20
#define  rmSysEnF2DqsOe                          (rSysCtrl1[rcFshSlv2DqsIoCtrl]|=cBit0)
#define  rmSysDisF2DqsOe                         (rSysCtrl1[rcFshSlv2DqsIoCtrl]&=(~cBit0))

#define  rcFshSlv2DataIoCtrl                     0x21
#define  rmSysEnF2DataOe                         (rSysCtrl1[rcFshSlv2DataIoCtrl]|=cBit0)
#define  rmSysDisF2DataOe                        (rSysCtrl1[rcFshSlv2DataIoCtrl]&=(~cBit0))

#define  rcFshSlv3DqsIoCtrl                      0x24
#define  rmSysEnF3DqsOe                          (rSysCtrl1[rcFshSlv3DqsIoCtrl]|=cBit0)
#define  rmSysDisF3DqsOe                         (rSysCtrl1[rcFshSlv3DqsIoCtrl]&=(~cBit0))

#define  rcFshSlv3DataIoCtrl                     0x25
#define  rmSysEnF3DataOe                         (rSysCtrl1[rcFshSlv3DataIoCtrl]|=cBit0)
#define  rmSysDisF3DataOe                        (rSysCtrl1[rcFshSlv3DataIoCtrl]&=(~cBit0))

#define  rcFshSlv4DqsIoCtrl                      0x28
#define  rmSysEnF4DqsOe                          (rSysCtrl1[rcFshSlv4DqsIoCtrl]|=cBit0)
#define  rmSysDisF4DqsOe                         (rSysCtrl1[rcFshSlv4DqsIoCtrl]&=(~cBit0))

#define  rcFshSlv4DataIoCtrl                     0x29
#define  rmSysEnF4DataOe                         (rSysCtrl1[rcFshSlv4DataIoCtrl]|=cBit0)
#define  rmSysDisF4DataOe                        (rSysCtrl1[rcFshSlv4DataIoCtrl]&=(~cBit0))

#define  rcFshSlv5DqsIoCtrl                      0x2C
#define  rmSysEnF5DqsOe                          (rSysCtrl1[rcFshSlv5DqsIoCtrl]|=cBit0)
#define  rmSysDisF5DqsOe                         (rSysCtrl1[rcFshSlv5DqsIoCtrl]&=(~cBit0))

#define  rcFshSlv5DataIoCtrl                     0x2D
#define  rmSysEnF5DataOe                         (rSysCtrl1[rcFshSlv5DataIoCtrl]|=cBit0)
#define  rmSysDisF5DataOe                        (rSysCtrl1[rcFshSlv5DataIoCtrl]&=(~cBit0))

#define  rcFshSlv6DqsIoCtrl                      0x30
#define  rmSysEnF6DqsOe                          (rSysCtrl1[rcFshSlv6DqsIoCtrl]|=cBit0)
#define  rmSysDisF6DqsOe                         (rSysCtrl1[rcFshSlv6DqsIoCtrl]&=(~cBit0))

#define  rcFshSlv6DataIoCtrl                     0x31
#define  rmSysEnF6DataOe                         (rSysCtrl1[rcFshSlv6DataIoCtrl]|=cBit0)
#define  rmSysDisF6DataOe                        (rSysCtrl1[rcFshSlv6DataIoCtrl]&=(~cBit0))

#define  rcFshSlv7DqsIoCtrl                      0x34
#define  rmSysEnF7DqsOe                          (rSysCtrl1[rcFshSlv7DqsIoCtrl]|=cBit0)
#define  rmSysDisF7DqsOe                         (rSysCtrl1[rcFshSlv7DqsIoCtrl]&=(~cBit0))

#define  rcFshSlv7DataIoCtrl                     0x35
#define  rmSysEnF7DataOe                         (rSysCtrl1[rcFshSlv7DataIoCtrl]|=cBit0)
#define  rmSysDisF7DataOe                        (rSysCtrl1[rcFshSlv7DataIoCtrl]&=(~cBit0))

#define  rcFshMstrDllDlyCnt                      0x3C
#define  rmGetFshDllDlyCnt                       rSysCtrl1[rcFshMstrDllDlyCnt]
#define  rmSetFshDllDlyCnt(x)                    rSysCtrl1[rcFshMstrDllDlyCnt]=x

#define  rcFshMstrDllCtrl                        0x3D
#define  rmSysSetDllRst                          (rSysCtrl1[rcFshMstrDllCtrl]|=cBit7)
#define  rmSysClrDllRst                          (rSysCtrl1[rcFshMstrDllCtrl]&=(~cBit7))
#define  rmSysSetDllAutoLock                     (rSysCtrl1[rcFshMstrDllCtrl]|=cBit6)
#define  rmSysClrDllAutoLock                     (rSysCtrl1[rcFshMstrDllCtrl]&=(~cBit6))

#define  rcFshMstrDllSts                         0x3E
#define  rmChkSysDllLock                         (rSysCtrl1[rcFshMstrDllSts]&cBit0)

#define  rcCtrlOdt                               0x40

#define  rcOdtTrAutosSel                         0x7C
#define  rmEnOdtTrAuto                           (rSysCtrl1[rcOdtTrAutosSel]|=cBit4)
#define  rmDisOdtTrAuto                          (rSysCtrl1[rcOdtTrAutosSel]&=(~cBit4))

#define  rcFifoAllBusy                           0x81    // use abnormal number to check busy state
#define  rmWaitSysCmdFifoBz\
    while(rSysCtrl1[rcFifoAllBusy])
#define  rmChkSysCmdFifoBz                       (rSysCtrl1[rcFifoAllBusy])

#define  rcFifoNextFreeze                        0x86
#define  rmAllFreezeBusy                         (rSysCtrl1[rcFifoNextFreeze])    // some ch are busy
#define  rmChkAllChNextBusy                      (rSysCtrl1[rcFifoNextFreeze]==0x0F)    // all ch are busy
#define  rmAnyChReady                            (rSysCtrl1[rcFifoNextFreeze]!=gChMap)

#define  rmChkChFreeze(ch)                       (rSysCtrl1[rcFifoNextFreeze]&cbBitTab[ch])

#define  rcStsErr                                0x88
#if _EN_PROGFAILLOG
#define rmChkSysStsErr                           rSysCtrl1[rcStsErr]
#else
#define rmChkSysStsErr                           0
#endif

#define  rcEccFailStatus                         0x8B
#define  rmChkEccFailCh(ch)                      (rSysCtrl1[rcEccFailStatus]&cbBitTab[ch])
#define  rmChkSysUNC                             rSysCtrl1[rcEccFailStatus]

#define  rmChkDestroy                            0

#define rcRsaCtrl                                0x90
#define rmRsaClkDiv2                             (rSysCtrl1[rcRsaCtrl]&=(~cBit0))
#define rmRsaClkDiv1                             (rSysCtrl1[rcRsaCtrl]|=cBit0)
#define rmRsaNonInv                              (rSysCtrl1[rcRsaCtrl]&=(~cBit1))
#define rmRsaInv                                 (rSysCtrl1[rcRsaCtrl]|=cBit1)

#endif    // ifndef __REG_SYSCTRL_H__







