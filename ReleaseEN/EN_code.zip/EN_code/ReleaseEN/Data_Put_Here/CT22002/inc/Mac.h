







#ifndef _MAC_H_
#define _MAC_H_

enum
{
    cSecurErase,
    cSanitize,
    cFwCommit,
    cChangeSecurityState,
#if _EN_KEEP_RW_ON_ERROR    // Chief_20190305
    crelinkWhileFormat,
#endif
};

// >>> merge 58xt IM3D
#define mRstCacheInfoSpf                         g32SpecFuncFlag=0
#define mChkCacheInfoSpf(x)                      mChkBitMask(g32SpecFuncFlag, x)
#define mSetCacheInfoSpf(x)                      mSetBitMask(g32SpecFuncFlag, x)
#define mClrCacheInfoSpf(x)                      mClrBitMask(g32SpecFuncFlag, x)

#define mGetSprId                                usBlkSprInfo.u16Spr8.us2BYTE.LowByte
#define mGetSprIdPtr                             upBlkSprInfo->u16Spr8->us2BYTE->LowByte
#define mGetSpr0                                 usBlkSprInfo.u16Spr0.u16all

// Mark Bad
#define mSetBadBitTab(x)                         mSetBitMask(g32arBadInfoBuf[cBadBlockMapOffset+div(x, 32)], x&0x1F)
#define mChkBadBitTab(x)                         mChkBitMask(g32arBadInfoBuf[cBadBlockMapOffset+div(x, 32)], x&0x1F)
// >>>

#define mGetWproBlkIdx(x)                        (gsWproInfo.uarWproIdxPtr[x])
#define c16GcInfoHmbBit                          c16Bit15
#define mGetWproPagePtr(x)                       (gsWproInfo.u16arWproIdxPagePtr[x]&~c16GcInfoHmbBit)
#define mChkGcInfoHmbLink(x)\
    ((gsWproInfo.u16arWproIdxPagePtr[x]!=c16BitFF)&&\
     (gsWproInfo.u16arWproIdxPagePtr[x]&c16GcInfoHmbBit))
#define mSetGcInfoHmbLink(x)                     (gsWproInfo.u16arWproIdxPagePtr[x]|=c16GcInfoHmbBit)
#define mClrGcInfoHmbLink(x)                     (gsWproInfo.u16arWproIdxPagePtr[x]&=~c16GcInfoHmbBit)

// #define mSetWproEntry(x, y, z)                 (gsWproInfo.u16arWproIdxPagePtr[x]=((y<<(3))|z))

#define mGetmin(A, B)                            ((A>B)?B:A)
#define mGetmax(A, B)                            ((A<B)?B:A)

#define g32HSector                               gpHostAddrInfo->u32HSector
#define g16HBlock                                gpHostAddrInfo->u16HBlock
#define g16HPage                                 gpHostAddrInfo->u16HPage
#define g16HSgmt                                 gpHostAddrInfo->u16HSgmt
#define gStartSector                             gpHostAddrInfo->uStartSector
#define gbChgBlock                               gpHostAddrInfo->ubChgBlock
// #define gbChgPlane                               gpHostAddrInfo->ubChgPlane

#define gDataReadPtr                             gpHostAddrInfo->uDataReadPtr
#define g32RestSctrCnt                           gpHostAddrInfo->u32RestSctrCnt
#define gbNewSrcF                                gpHostAddrInfo->ubNewSrcF
// #define gHSgmtCnt                                gpHostAddrInfo->uHSgmtCnt

// Read Write flow
#define mGetSrcOccpyCnt()\
    (gsRwCtrl.u32FreeSrcFifoHead==gsRwCtrl.u32FreeSrcFifoTail)?0:((gsRwCtrl.u32FreeSrcFifoHead>gsRwCtrl.u32FreeSrcFifoTail)?\
                                                                  (gsRwCtrl.u32FreeSrcFifoHead-\
                                                                   gsRwCtrl.u32FreeSrcFifoTail):((gsRwCtrl.u32FreeSrcFifoHead+\
                                                                                                  cReadFifoDpt)-gsRwCtrl.u32FreeSrcFifoTail))
#define mChkH2f1kTabSgmtExpire(x)                (garH2f1kTabSgmtExpire[x]==0)    // mChkBitMask(gsCacheInfo.u32H2f1kTabSgmtExpire, x)
#define mSetH2f1kTabSgmtExpire(x)                (garH2f1kTabSgmtExpire[x]--)    // mSetBitMask(gsCacheInfo.u32H2f1kTabSgmtExpire, x)
#define mClrH2f1kTabSgmtExpire(x)                (garH2f1kTabSgmtExpire[x]++)    // mClrBitMask(gsCacheInfo.u32H2f1kTabSgmtExpire, x)

#define mChkH2f1kTabSgmtPrep(x)                  mChkBitMask(gsCacheInfo.u32H2f1kTabSgmtPrep, x)
#define mSetH2f1kTabSgmtPrep(x)                  mSetBitMask(gsCacheInfo.u32H2f1kTabSgmtPrep, x)
#define mClrH2f1kTabSgmtPrep(x)                  mClrBitMask(gsCacheInfo.u32H2f1kTabSgmtPrep, x)

// #define mChkH2fTabNullF(x)                       mChkBitMask(g32arH2fTabNullFlag[(x)>>5], (x)&0x1F)
// #define mSetH2fTabNullF(x)                       mSetBitMask(g32arH2fTabNullFlag[(x)>>5], (x)&0x1F)
// #define mClrH2fTabNullF(x)                       mClrBitMask(g32arH2fTabNullFlag[(x)>>5], (x)&0x1F)
#define mGetH2fTabBlkIndex(x)                    ((BYTE)(g16arH2fTabPtr[x]>>gsCacheInfo.uH2fTabPagePtrShift))
#define mSetH2fTabBlkIndex(x,\
                           y)                 ((g16arH2fTabPtr[x]&gsCacheInfo.u16H2fTabPagePtrMsk)|\
                                               ((WORD)((y)<<gsCacheInfo.uH2fTabPagePtrShift)))
#define mGetH2fTabPagePtr(x)                     (g16arH2fTabPtr[x]&gsCacheInfo.u16H2fTabPagePtrMsk)
#define mSetH2fTabPagePtr(x, y)                  ((g16arH2fTabPtr[x]&~gsCacheInfo.u16H2fTabPagePtrMsk)|(y))
#define mSetH2fTabEntry(x, y, z)                 (g16arH2fTabPtr[x]=((WORD)((y)<<gsCacheInfo.uH2fTabPagePtrShift))|(z))

// #define mTranFAddr2Lword(_Fblk, _Fpage)        (((LWORD)_Fblk<<20)|_Fpage)
// #define mGetFblkFromLword(_FAddr)              ((WORD)(_FAddr>>20))
// #define mGetFPageFromLword(_FAddr)             ((LWORD)(_FAddr&0xFFFFF))

#define mChkSrcInCache(x)                        mChkBitMask(g32arSrcInCacheFlag[x>>5], x&0x1F)
#define mSetSrcInCache(x)                        {mSetBitMask(g32arSrcInCacheFlag[x>>5], x&0x1F);gsCacheInfo.u16HblkCntInCache++;}
#define mClrSrcInCache(x)                        {mClrBitMask(g32arSrcInCacheFlag[x>>5], x&0x1F);gsCacheInfo.u16HblkCntInCache--;}
#if (!_BypassEraseFlag)
#define mChkEraseFlag(x)                         (!mChkBitMask(g32arEraseFlag[x>>5], x&0x1F))
#define mSetEraseFlag(x)\
    do\
    {\
        while(rmChkBopBz)\
            ;\
        mClrBitMask(g32arEraseFlag[x>>5], x&0x1F);\
    }\
    while(0)
#define mClrEraseFlag(x)\
    do\
    {\
        while(rmChkBopBz)\
            ;\
        mSetBitMask(g32arEraseFlag[x>>5], x&0x1F);\
    }\
    while(0)
#endif    // if !_BypassEraseFlag
#define mChkBitMask(x, y)                        (x&cb32BitTab[y])
#define mSetBitMask(x, y)                        (x|=cb32BitTab[y])
#define mClrBitMask(x, y)                        (x&=~cb32BitTab[y])

#if (!_CPUID)
#define mChk64BitMask(x, y)                      (x&(1<<y))    // cb64BitTab[y])
#define mSet64BitMask(x, y)                      (x|=(1<<y))    // cb64BitTab[y])
#define mClr64BitMask(x, y)                      (x&=~(1<<y))    // cb64BitTab[y])
#endif
#if _ENABLE_HMB_FLUSH
#define mChkHmbTabDirty(x)                       mChkBitMask(g32arHmbTabDirty[x>>5], x&0x1F)
#define mSetHmbTabDirty(x)                       mSetBitMask(g32arHmbTabDirty[x>>5], x&0x1F)
#define mClrHmbTabDirty(x)                       mClrBitMask(g32arHmbTabDirty[x>>5], x&0x1F)

#define mChkRH2fTabDirty(x)                      mChkBitMask(g32arRH2fTabDirty[x>>5], x&0x1F)
#define mSetRH2fTabDirty(x)                      mSetBitMask(g32arRH2fTabDirty[x>>5], x&0x1F)
#define mClrRH2fTabDirty(x)                      mClrBitMask(g32arRH2fTabDirty[x>>5], x&0x1F)
#endif

#define mSetGcFlow(x)                            gsGcInfo.uGcFlow=(x&0x07)
#define mGetGcFlow                               (gsGcInfo.uGcFlow)
#define mSetGcState(x)                           gsGcInfo.uGcState=x
#define mGetGcState                              (gsGcInfo.uGcState)
#if _EN_SLCOpenBlkReadScrub
#define mSetGcFlushState(x)                      gsGcInfo.uFlushState=x
#define mGetGcFlushState                         (gsGcInfo.uFlushState)
#endif
#define mGet16GcSrcBlock(x)                      gsGcInfo.u16GcSrcBlock[gsGcInfo.uGcSrcBlkIdx[x]]

#define cGcDesFull                               c32Bit0
#define cGcNewDesF                               c32Bit1
#define cGcForceClean                            c32Bit2
// #define cWaitLastDesfullB4S2T                    c32Bit3
#define cStopBgdClean                            c32Bit4
#define cBrkBgdGcF                               c32Bit5
#define cUnderBgdGc                              c32Bit6
#define cGcDesFailAbort                          c32Bit7
#define cGcHmbGcInfoFail                         c32Bit8
#define cGcSrchWearF                             c32Bit9
#define cGcSpareNotEnough                        c32Bit10
// #define cGcTlcF2hTabProg                         c32Bit10
// #define cForQBoot                                c32Bit11
// #define cUnderSlcGc                              c32Bit12
// #define cEndWrFlow                               c32Bit13
#define cReadScrubH2F                            c32Bit14
#define cFlushforReclaim                         c32Bit15
#define cUnderReclaim                            c32Bit16
#define cGcLoadNextF2hTab                        c32Bit17
// #define cSrchSrcHBlkDone                         c32Bit18
#define cGcRebuF2hTab                            c32Bit19
// #define cS2TReFold                            c32Bit20
// #define cSvCacheInfo                          c32Bit21
// #define cGcFlushDesTab                        c32Bit22
#define cPwOnH2FGcF                              c32Bit22
#define cGcDownstrHmbRaidParity                  c32Bit23
#define cPwOnGcF                                 c32Bit24
#define cGcWaitSrcDone                           c32Bit25
#define cUnderGcH2fTab                           c32Bit26
#define cUnderFgdGc                              c32Bit27
#define cGcDownstrHmb                            c32Bit28
#define cPwOnExtraGcF                            c32Bit29
#define cGcSkipPrgCacheInfo                      c32Bit30
#define cGcReadF2h                               c32Bit31    // skip read retry fail while(1) when reading F2h pad of src block.

#define mSetGcFlag(x)                            gsGcInfo.u32GcFlag|=(x)
#define mChkGcFlag(x)                            (gsGcInfo.u32GcFlag&(x))
#define mClrGcFlag(x)                            gsGcInfo.u32GcFlag&=~(x)
#define cH2fChg                                 c32Bit0
#define cH2fProgramFail                         c32Bit1
#define cCacheBlockFull                         c32Bit2
#define cH2fTabBlockFull                        c32Bit3
#define cIndexBlockFull                         c32Bit4
#define cMPInfoBlockFull                        c32Bit5
#define cLogInfoBlockFull                       c32Bit6
#define cWproProgramFail                        c32Bit7
#define cDataProgramFail                        c32Bit8
#define cMoveProgramFail                        c32Bit9

#define cPfCacheBlk                             c32Bit16
#define cPfH2fTabBlk                            c32Bit17
#define cPfWproBlk                              c32Bit18
#define cPfGcDesBlk                             c32Bit19
#define cPfNotFound                             c32Bit20
#define cPfRaidEngTemp                          c32Bit31

#define mChkProgFailFlag(x)                     (gsProgFailInfo.u32ProgFailFlag&(x))
#define mSetProgFailFlag(x)                     (gsProgFailInfo.u32ProgFailFlag|=(x))
#define mClrProgFailFlag(x)                     (gsProgFailInfo.u32ProgFailFlag&=~(x))

#if _EN_SLCOpenBlkReadScrub
#define cOccFlushCache                          cBit0
#define cOccReadReclaim                         cBit1
#define cOccMarkBad                             cBit2
#endif

// #define cOccReadScrub                           cBit0
// #define cOccReadReclaim                         cBit1
// #define cOccMarkBad                             cBit2

#define mSetOccFlag(x)                          gsGcInfo.uOccTsbFlag|=(x)
#define mChkOccFlag(x)                          (gsGcInfo.uOccTsbFlag&(x))
#define mClrOccFlag(x)                          gsGcInfo.uOccTsbFlag&=~(x)

#define mSetCacheInfoFlag(x)                    gsCacheInfo.u32CacheInfoFlag|=(x)
#define mChkCacheInfoFlag(x)                    (gsCacheInfo.u32CacheInfoFlag&(x))
#define mClrCacheInfoFlag(x)                    gsCacheInfo.u32CacheInfoFlag&=~(x)

#define mSetCacheInfoChangeFlag(x)              gsCacheInfo.u32CacheInfoChangeFlag|=(x)
#define mChkCacheInfoChangeFlag(x)              (gsCacheInfo.u32CacheInfoChangeFlag&(x))
#define mClrCacheInfoChangeFlag(x)              gsCacheInfo.u32CacheInfoChangeFlag&=~(x)

#define cEobRaid                                cBit0
#define cEob1stF2h                              cBit1
#define cEob2ndF2h                              cBit2

#define mSetCacheEobFlag(x)                     gsCacheInfo.uCacheEobFlag|=(x)
#define mChkCacheEobFlag(x)                     (gsCacheInfo.uCacheEobFlag&(x))
#define mClrCacheEobFlag(x)                     gsCacheInfo.uCacheEobFlag&=~(x)

#define mGetGlobEraseCnt(x)                      (g16arGlobEraseCnt[x])
#define mSetGlobEraseCnt(x, y)\
    do\
    {\
        g16arGlobEraseCnt[x]=y;\
    }\
    while(0)
#define mSetPoppedBit(x)                         mSetBitMask(g32arPopBit[x>>5], x&0x1F)
#define mChkPoppedBit(x)                         mChkBitMask(g32arPopBit[x>>5], x&0x1F)
#define mClrPoppedBit(x)                         mClrBitMask(g32arPopBit[x>>5], x&0x1F)

#define mGetGlobEraseCntRL(x)                    (g16arTempGlobEraseCnt[x])
#define mSetGlobEraseCntRL(x, y)\
    do\
    {\
        g16arTempGlobEraseCnt[x]=y;\
    }\
    while(0)
#if _EN_VPC_SWAP
#define mSetGlobReadCnt(x, y)\
    do\
    {\
        garGlobReadCntHighByte[x]=(y>>16);\
        g16arGlobReadCnt[x]=(y&0xFFFF);\
    }\
    while(0)
#define mGetGlobReadCnt(x)            ((((LWORD)garGlobReadCntHighByte[x])<<16)|g16arGlobReadCnt[x])
#else
#define mSetGlobReadCnt(x, y)        (g32arGlobReadCnt[x]=y)
#define mGetGlobReadCnt(x)        (g32arGlobReadCnt[x])
#endif

#define mSetPoppedBitRL(x)                       mSetBitMask(g32arPopDeniedFlag[x>>5], x&0x1F)
#define mChkPoppedBitRL(x)                       mChkBitMask(g32arPopDeniedFlag[x>>5], x&0x1F)
#define mClrPoppedBitRL(x)                       mClrBitMask(g32arPopDeniedFlag[x>>5], x&0x1F)

#define mSetSlcSkipRam(x)                        mSetBitMask(r32SkipRam[x>>5], x&0x1F)
#define mChkSlcSkipRam(x)                        (mChkBitMask(r32SkipRam[x>>5], x&0x1F))
#define mClrSlcSkipRam(x)                        mClrBitMask(r32SkipRam[x>>5], x&0x1F)

#if _EN_VPC_SWAP
#define mGetCacheBlkVpCnt(x)                     (g32arCacheBlkVpCnt[x])

#define mSetSkipGcBit(x)                         mSetBitMask(g32arSkipGcSrch[x>>5], x&0x1F)    // (g32arCacheBlkVpCnt[x]|=c32Bit31)
#define mClrSkipGcBit(x)                         mClrBitMask(g32arSkipGcSrch[x>>5], x&0x1F)    // (g32arCacheBlkVpCnt[x]&=~c32Bit31)

#define mSetVPCntValid(x)                        mSetBitMask(g32arVPCntValid[x>>5], x&0x1F)
#define mChkVPCntValid(x)                        (mChkBitMask(g32arVPCntValid[x>>5], x&0x1F))
#define mClrVPCntValid(x)                        mClrBitMask(g32arVPCntValid[x>>5], x&0x1F)

#else

#define mGetCacheBlkVpCnt(x)                     (g32arCacheBlkVpCnt[x]&~(c32Bit31|c32Bit30))

#define mSetSkipGcBit(x)                         (g32arCacheBlkVpCnt[x]|=c32Bit31)
#define mClrSkipGcBit(x)                         (g32arCacheBlkVpCnt[x]&=~c32Bit31)
#endif

#define mChkSkipGcSrcHblkSrch(x)                 mChkBitMask(g32GcSkipSrcHblkSrch[x>>5], (x&0x1F))
#define mSetSkipGcSrcHblkSrch(x)                 mSetBitMask(g32GcSkipSrcHblkSrch[x>>5], (x&0x1F))
#define mChkGcSrcBlkBmap(x)                      mChkBitMask(g32arGcSrcBlkBitMap[x>>5], x&0x1F)
#define mSetGcSrcBlkBmap(x)\
    do\
    {\
        mSetBitMask(g32arGcSrcBlkBitMap[x>>5], x&0x1F);gsGcInfo.u16MtCacheBlockCnt++;\
    }\
    while(0)
#define mClrGcSrcBlkBmap(x)\
    do\
    {\
        mClrBitMask(g32arGcSrcBlkBitMap[x>>5], x&0x1F);gsGcInfo.u16MtCacheBlockCnt--;\
    }\
    while(0)

#define mIncTotalVpc(x)\
    do\
    {\
        if((x))\
        {\
            gsGcInfo.u32TotalSlcVpc++;\
        }\
        else\
        {\
            gsGcInfo.u32TotalTlcVpc++;\
        }\
    }\
    while(0)
#define mIncTotalVpcN(x, y)\
    do\
    {\
        if((x))\
        {\
            gsGcInfo.u32TotalSlcVpc+=y;\
        }\
        else\
        {\
            gsGcInfo.u32TotalTlcVpc+=y;\
        }\
    }\
    while(0)
#define mIncTotalVpcN2(x, y1, y2, z)\
    do\
    {\
        if((x))\
        {\
            y1+=z;\
        }\
        else\
        {\
            y2+=z;\
        }\
    }\
    while(0)
#define mDecTotalVpc(x)\
    do\
    {\
        if(!mChkMlcMoBit(x))\
        {\
            gsGcInfo.u32TotalSlcVpc--;\
        }\
        else\
        {\
            gsGcInfo.u32TotalTlcVpc--;\
        }\
    }\
    while(0)

#define mDecTotalVpcN(x, y)\
    do\
    {\
        if(!mChkMlcMoBit(x))\
        {\
            gsGcInfo.u32TotalSlcVpc-=y;\
        }\
        else\
        {\
            gsGcInfo.u32TotalTlcVpc-=y;\
        }\
    }\
    while(0)

#if _EN_VPC_SWAP
#define mSetSkipGcSrch(x)\
    do\
    {\
        mSetBitMask(g32arSkipGcSrch[x>>5], x&0x1F);\
        if(!mChkMlcMoBit(x))\
        {\
            gsCacheInfo.u16FullCacheBlockCnt--;\
        }\
        else\
        {\
            gsCacheInfo.u16TLCFullCacheBlockCnt--;\
        }\
    }\
    while(0)
#define mChkSkipGcSrch(x)                        (mChkBitMask(g32arSkipGcSrch[x>>5], x&0x1F))
#define mClrSkipGcSrch(x)\
    do\
    {\
        mClrBitMask(g32arSkipGcSrch[x>>5], x&0x1F);\
        if(!mChkMlcMoBit(x))\
        {\
            gsCacheInfo.u16FullCacheBlockCnt++;\
        }\
        else\
        {\
            gsCacheInfo.u16TLCFullCacheBlockCnt++;\
        }\
    }\
    while(0)
#else    // if _EN_VPC_SWAP
#define mSetSkipGcSrch(x)\
    do\
    {\
        g32arCacheBlkVpCnt[x]|=c32Bit31;\
        if(!mChkMlcMoBit(x))\
        {\
            gsCacheInfo.u16FullCacheBlockCnt--;\
        }\
        else\
        {\
            gsCacheInfo.u16TLCFullCacheBlockCnt--;\
        }\
    }\
    while(0)
#define mChkSkipGcSrch(x)                        (g32arCacheBlkVpCnt[x]&c32Bit31)
#define mClrSkipGcSrch(x)\
    do\
    {\
        g32arCacheBlkVpCnt[x]&=~c32Bit31;\
        if(!mChkMlcMoBit(x))\
        {\
            gsCacheInfo.u16FullCacheBlockCnt++;\
        }\
        else\
        {\
            gsCacheInfo.u16TLCFullCacheBlockCnt++;\
        }\
    }\
    while(0)
#endif    // if _EN_VPC_SWAP
#define mChkCacheInBuf(x)                        mChkBitMask(gsRwCtrl.u16CacheInBuf, x)
#define mSetCacheInBuf(x)                        mSetBitMask(gsRwCtrl.u16CacheInBuf, x)
// #define mClrCacheInBufF                          gsRwCtrl.u16CacheInBuf=0
#define mClrCacheInBuf(x)                        mClrBitMask(gsRwCtrl.u16CacheInBuf, x)
#define mChkCacheInBufF                          (gsRwCtrl.u16CacheInBuf!=0)
// #define gStartSector                             gpHostAddrInfo->uStartSector

#define mGetStartSctr                            gsRwCtrl.uCacheStartSctr
#define mGetEndSctr                              gsRwCtrl.uCacheEndSctr

// #define mTran4kAddr(x)                         div(x, g4kNumPerPlane)  // 4kb to page
#define cProgFail                                cBit4
#define cChkAhead                                cProgFail
#define cDone                                    cBit5
#define cBackClrOccF                             cBit6
#define cForeClrOccF                             cBit7
#define cSecondPassProg                          cForeClrOccF
#define cCacheRdF                                cBit3

#define mGetCEAddr(x)                            (x>>gDieBitCnt)
#define mGetDieAddr(x)                           (x&(gPhyDiePerPackage-1))    // (x%gPhyDiePerPackage)
#define mTran4kAddr(x)                           div(x, g4kNumPerPlane)
#define mTranSctr4kAddr(x)                       ((x&(g4kNumPerPlane-1))<<cSctrTo4kShift)    // (mod(x, g4kNumPerPlane)*cSctrPer4k)
#define mTranH2fTabAddr(x)                       (x*gPage4kPerH2fTab)
#define mTranRaidPtyAddr(x)                      (x*c4kNumPerRaidPty)

enum
{
    cPageRead1,
    cPageRead2,
    cPageProg1,
    cPageProg2,
    cBlockErase1,
    cBlockErase2,
    cReset,
    cSetFeature,
    cSetDieFeature,
};

#define gPageReadCmd1                            garFLCmdSetTab2[cPageRead1]    // 0x00
#define gPageReadCmd2                            garFLCmdSetTab2[cPageRead2]    // 0x30
#define gPageProgCmd1                            garFLCmdSetTab2[cPageProg1]    // 0x80
#define gPageProgCmd2                            garFLCmdSetTab2[cPageProg2]    // 0x10
#define gBlockEraseCmd1                          garFLCmdSetTab2[cBlockErase1]    // 0x60
#define gBlockEraseCmd2                          garFLCmdSetTab2[cBlockErase2]    // 0xD0
#define gResetCmd                                garFLCmdSetTab2[cReset]    // 0xFF
#define gSetFeatureCmd                           garFLCmdSetTab2[cSetFeature]    // 0xEF
#define gSetDieFeatureCmd                        garFLCmdSetTab2[cSetDieFeature]    // 0xEF
#define cDummyProgramCMD                         0xC6
#define cHalfReadCMD                             0x20

enum
{
    cCacheRead,    // 0x00
    cLastPageCacheRead,    // 0x01
    cCacheProg,    // 0x02
    cRandomIn,    // 0x03
    cRandomOut1,    // 0x04
    cRandomOut2,    // 0x05
    cReadStatus,    // 0x06
    cReadStatusEnh,    // 0x07
    cSlcMoAccess,    // 0x08
    cSlcMoAbort,    // 0x09
    cMulPlaneRead1,    // 0x0A
    cMulPlaneRead2,    // 0x0B
    cMulPlaneProg1,    // 0x0C
    cMulPlaneProg2,    // 0x0D
    cSyncReset,    // 0x0E
    cPriBlockErase2,    // 0x0F
};

#define gCacheReadCmd                            garFLCmdSetTab[cCacheRead]    // 0x31
#define gLastPageCacheReadCmd                    garFLCmdSetTab[cLastPageCacheRead]    // 0x33
#define gCacheProgCmd                            garFLCmdSetTab[cCacheProg]    // 0x15
#define gRandomInCmd                             garFLCmdSetTab[cRandomIn]    // 0x85
#define gRandomOutCmd1                           garFLCmdSetTab[cRandomOut1]    // 0x05
#define gRandomOutCmd2                           garFLCmdSetTab[cRandomOut2]    // 0xE0
#define gReadStatusCmd                           garFLCmdSetTab[cReadStatus]    // 0x70
#define gReadStatusEnhCmd                        garFLCmdSetTab[cReadStatusEnh]    // 0x78
#define gSlcMoAccessCmd                          garFLCmdSetTab[cSlcMoAccess]    // 0xDA
#define gSlcMoAbortCmd                           garFLCmdSetTab[cSlcMoAbort]    // 0xDF
#define gPriMPlaneReadCmd1                       garFLCmdSetTab[cMulPlaneRead1]    // 0x00
#define gPriMPlaneReadCmd2                       garFLCmdSetTab[cMulPlaneRead2]    // 0x32
#define gMulPlaneProgCmd1                        garFLCmdSetTab[cMulPlaneProg1]    // 0x11
#define gMulPlaneProgCmd2                        garFLCmdSetTab[cMulPlaneProg2]    // 0x81
#define gSyncResetCmd                            garFLCmdSetTab[cSyncReset]    // 0xFC
#define gPriMPlaneEraseCmd2                      garFLCmdSetTab[cPriBlockErase2]    // 0xD1

#define gSecMPlaneReadCmd1                       gBlockEraseCmd1
#define gMulPlaneReadCmd2                        gPageReadCmd2
#define gReadMoCmd                               gPageReadCmd1
#define gMulPlaneEraseCmd1                       gBlockEraseCmd1
#define gMulPlaneEraseCmd2                       gBlockEraseCmd2
#define gMulPlaneRandomOutCmd1                   gPageReadCmd1

#define gNorEccStrPage                           gSeedTableStartPage

// for H2fTab
#define mGetSrcFBlkAddr(x)                       (((x)>>c32SrcFPageAddrBitNum)&c16FBlockInitValue)
#define mGetSrcFPageAddr(x)                      ((x)&c32SrcFPageAddrMask)
#define mSetSrcFBlkAddr(x)                       (((LWORD)x)<<c32SrcFPageAddrBitNum)
#define mSetH2fSrcFAddr(x, y)                    (((LWORD)x)<<c32SrcFPageAddrBitNum|(y))

#define mGetH2fSpr1                              garDesF2hInfo[gsRwCtrl.uChProgFifoIdx[uCh][gsRwCtrl.uChProgFifoTrig[uCh]]].u16arHPage[1]
#define mGetH2fSpr2                              garDesF2hInfo[gsRwCtrl.uChProgFifoIdx[uCh][gsRwCtrl.uChProgFifoTrig[uCh]]].u16arHPage[0]
#define mGetH2fSprSerial                         gsCacheInfo.u32H2fTabBlkSerial    // gpFlashAddrInfo->u32Serial

#define mSetH2fSpr1                              garDesF2hInfo[gsGcInfo.uPreProgFifo].u16arHPage[1]=gsCacheInfo.u16H2fTabFreePagePtr
#define mSetH2fSpr2                              garDesF2hInfo[gsGcInfo.uPreProgFifo].u16arHPage[0]=gsCacheInfo.uActH2fTabBlkIdx
// #define mSetH2fSprSerial                         gpFlashAddrInfo->u32Serial=gsCacheInfo.u32H2fTabBlkSerial

#define mGetHmbLink(x)                           (mGetH2fTabPagePtr(x))
#define mChkHmbLink(x)                           (mGetH2fTabBlkIndex(x)==gMaxH2fTabBlkNum)

#define mGetCh(u32FpageNoTran)                   (((u32FpageNoTran)>>gChAddrBitShiftCnt)&(gChBitCnt-1))
// #define mChkLargePage(u16PageIdx)                ((cbSharePageBitMap[(u16PageIdx)>>3]&cbBitTab[(u16PageIdx)&0x07])!=0)

#define mSetSrchPos(uSrchFifoPtr, uSrchPagePtr, uSrch4kPtr)     ((((LWORD)uSrchPagePtr)<<16)|(((LWORD)uSrchFifoPtr)<<8)|((LWORD)uSrch4kPtr))
#define mGetSrchFifoPtr(u32SrchPos)              (((u32SrchPos)>>8)&0xFF)
#define mGetSrchPagePtr(u32SrchPos)              (((u32SrchPos)>>16)&0xFF)
#define mGetSrch4kPtr(u32SrchPos)                ((u32SrchPos)&0xFF)
#define mSetInvalidGcDesPage(x)                  mSetBitMask(g32arGcInvaildPageBimap[x>>5], (x&0x1F))
#define mGetInvalidGcDesPage(x)                  mChkBitMask(g32arGcInvaildPageBimap[(x>>5)], (x&0x1F))

#define cBadInfoBlkFull                          cBit0
#define cBadInfoChg                              cBit1
#define mSetBadInfoFlag(x)                       gsBadInfo.uBadInfoFlg|=(x)
#define mChkBadInfoFlag(x)                       (gsBadInfo.uBadInfoFlg&(x))
#define mClrBadInfoFlag(x)                       gsBadInfo.uBadInfoFlg&=~(x)

// for RAID
#define mSetRaidDecF(x)                          (gsRaidInfo.uRaidDecodeF|=(x))
#define mClrRaidDecF(x)                          (gsRaidInfo.uRaidDecodeF&=(~(x)))
#define mChkRaidDecF(x)                          (gsRaidInfo.uRaidDecodeF&(x))

#define mChkRaidEngBmap(x)                       mChkBitMask(gsRaidInfo.u16RaidEngBitMap, x)
#define mSetRaidEngBmap(x)                       mSetBitMask(gsRaidInfo.u16RaidEngBitMap, x)
#define mClrRaidEngBmap(x)                       mClrBitMask(gsRaidInfo.u16RaidEngBitMap, x)

#define mChkRaidEngPtyBmap(x)                    mChkBitMask(gsRaidInfo.u16RaidEngPtyBitMap, x)
#define mSetRaidEngPtyBmap(x)                    mSetBitMask(gsRaidInfo.u16RaidEngPtyBitMap, x)
#define mClrRaidEngPtyBmap(x)                    mClrBitMask(gsRaidInfo.u16RaidEngPtyBitMap, x)

#define mGetRaidKVal(uRaidType)                  gsRaidInfo.uarRaidTotalType[uRaidType].u16KVal
#define mGetRaidSector(uRaidType)                (gsRaidInfo.uarRaidTotalType[uRaidType].uSctrNum<<cRaidUnitChgShiftBit)

#define mGetRaidPtyBlkIndex(x)                   ((BYTE)(g16arRaidParityPtr[x]>>14))
#define mSetRaidPtyBlkIndex(x, y)                ((g16arRaidParityPtr[x]&0x3FFF)|((WORD)((y)<<14)))
#define mGetRaidPtyPagePtr(x)                    (g16arRaidParityPtr[x]&0x3FFF)
#define mSetRaidPtyPagePtr(x, y)                 ((g16arRaidParityPtr[x]&~0x3FFF)|(y))
#define mSetRaidPtyEntry(x, y, z)                (g16arRaidParityPtr[x]=((WORD)((y)<<14))|(z))

#define mChkRwTmrCtrl(x)                         (gsRwCtrl.uTimerFlag&x)
#define mSetRwTmrCtrl(x)                         (gsRwCtrl.uTimerFlag|=x)
#define mClrRwTmrCtrl(x)                         (gsRwCtrl.uTimerFlag&=(~(x)))
#define mChkRwTimeOutFlag                        (gCpu0TOFlag&&(gLastTrigPrdTaskType!=cNvmeCmdRead))
#define mChkWrStarvation                         (!gCpu0TOFlag&&(gsPrdInfo.usWritePrdList.u16Cnt<cWrStarvationThr))

#define mChkPushReClaimQBit(x)                   mChkBitMask(g32arPushReclaimQ[x>>5], (x&0x1F))
#define mSetPushReClaimQBit(x)                   mSetBitMask(g32arPushReclaimQ[x>>5], (x&0x1F))
#define mClrPushReClaimQBit(x)                   mClrBitMask(g32arPushReclaimQ[x>>5], (x&0x1F))

#define mChkFwBufOcc32Sts(BufLWordIdx, val)      (g32arFwPreOccuFlag[(BufLWordIdx)]&val)
#define mSetFwBufOcc32Sts(BufLWordIdx, val)      (g32arFwPreOccuFlag[(BufLWordIdx)]|=val)
#define mClrFwBufOcc32Sts(BufLWordIdx, val)      (g32arFwPreOccuFlag[(BufLWordIdx)]&=(~(val)))

#define mChkHmbPrdTrigIdx                        ((rmHmbPrdQueTrigIdx!=gsHmbInfo.uHmbHwPrdTail)||mChkHandlePcieErrF)
#define mWaitHmbTransferDone()\
    while(gsHmbInfo.uHmbFreeHwPrdCnt!=cHmbHwPrdDepth)\
    {\
        if(rmHmbPrdQueTrigIdx!=gsHmbInfo.uHmbHwPrdTail)\
        {\
            releaseHmbHwPrd();\
        }\
    }

// wait at least one HMB prd release
#define mWaitHmbRelease(x)\
    while(gsHmbInfo.uHmbFreeHwPrdCnt<=(x))\
    {\
        if(rmHmbPrdQueTrigIdx!=gsHmbInfo.uHmbHwPrdTail)\
        {\
            releaseHmbHwPrd();\
        }\
    }

#if (_EN_PCIE_TIME_REC||_EN_PCIE_PATH_REC)
#define mRecordPcieTimeStamp(x)             gsPcieErrInfo.u32LastPcieErrTimeStamp[x]=getRtcCurrent32k()
#endif

#if _EN_PCIE_PATH_REC
#define mRecPcieErrPath(y)\
    do\
    {\
        if(!gsPcieErrInfo.u32CurrPcieErrPath)\
        {\
            mRecordPcieTimeStamp(0);\
        }\
        gsPcieErrInfo.u32CurrPcieErrPath|=y;\
    }\
    while(0)
#endif

#define mWaitHmbReadDone(uSgmtIdx)\
    while(mChkH2f1kTabSgmtPrep((uSgmtIdx)))\
    {\
        if(rmHmbPrdQueTrigIdx!=gsHmbInfo.uHmbHwPrdTail)\
        {\
            releaseHmbHwPrd();\
        }\
    }

#define mSetFRwParam(a, b, c, d)\
    do\
    {\
        gOpTyp=d;gpFlashAddrInfo->uRwHalfKb=b;gpFlashAddrInfo->u16BufPtr=a;g16RwOpt=c;\
    }\
    while(0)
/*a: pre, b: linkinfo, c: nxt, d: linknode, e: curr*/
#define mInsTailNode(a, b, c, d, e)\
    do\
    {\
        a=b->u16Tail;\
        if(a!=cNull)\
        {\
            c=d[a].uPrev;d[a].uPrev=e;\
        }\
        else\
        {\
            c=b->u16Head;b->u16Head=e;\
        }\
        if(c!=cNull)\
        {\
            d[c].uNext=e;\
        }\
        else\
        {\
            b->u16Tail=e;\
        }\
        d[e].uNext=a;d[e].uPrev=c;\
        if(b->u16Trig==cNull)\
        {\
            b->u16Trig=e;\
        }\
        b->u16Cnt++;\
    }\
    while(0)
/*a: pre, b: linkinfo, c: nxt, d: linknode, e: curr*/
#define mInsNode(a, b, c, d, e)\
    do\
    {\
        a=b->u16Head;\
        if(a!=cNull)\
        {\
            c=d[a].uNext;d[a].uNext=e;\
        }\
        else\
        {\
            c=b->u16Tail;b->u16Tail=e;\
        }\
        if(c!=cNull)\
        {\
            d[c].uPrev=e;\
        }\
        else\
        {\
            b->u16Head=e;\
        }\
        d[e].uPrev=a;d[e].uNext=c;\
        if(b->u16Trig==cNull)\
        {\
            b->u16Trig=e;\
        }\
        b->u16Cnt++;\
    }\
    while(0)
/*a: pre, b: linknode, c: curr, d: nxt, e: linkinfo*/
#define mDelNode(a, b, c, d, e)\
    do\
    {\
        a=b[c].uPrev;d=b[c].uNext;\
        if(a!=cNull)\
        {\
            b[a].uNext=d;\
        }\
        else\
        {\
            e->u16Tail=d;\
        }\
        if(d!=cNull)\
        {\
            b[d].uPrev=a;\
        }\
        else\
        {\
            e->u16Head=a;\
        }\
        e->u16Cnt--;\
    }\
    while(0)
/*a: pre, b: linkinfo, c: nxt, d: linknode, e: curr*/
#define mInsNode16(a, b, c, d, e)\
    do\
    {\
        if(a==c16Null)\
        {\
            a=b->u16Head;\
        }\
        if(a!=c16Null)\
        {\
            c=d[a].u16Next;d[a].u16Next=e;\
        }\
        else\
        {\
            c=b->u16Tail;b->u16Tail=e;\
        }\
        if(c!=c16Null)\
        {\
            d[c].u16Prev=e;\
        }\
        else\
        {\
            b->u16Head=e;\
        }\
        d[e].u16Prev=a;d[e].u16Next=c;\
        if(b->u16Trig==cNull)\
        {\
            b->u16Trig=e;\
        }\
        b->u16Cnt++;\
    }\
    while(0)
/*a: pre, b: linknode, c: curr, d: nxt, e: linkinfo*/
#define mDelNode16(a, b, c, d, e)\
    do\
    {\
        a=b[c].u16Prev;d=b[c].u16Next;\
        if(a!=c16Null)\
        {\
            b[a].u16Next=d;\
        }\
        else\
        {\
            e->u16Tail=d;\
        }\
        if(d!=c16Null)\
        {\
            b[d].u16Prev=a;\
        }\
        else\
        {\
            e->u16Head=a;\
        }\
        e->u16Cnt--;\
    }\
    while(0)
enum
{
    cGcTypFlushF2h,    // 0
    cGcTypForeGrnd,    // 1
    cGcTypH2fTab,    // 2
    cGcTypTLCWearLvl,    // 3
    cGcTypSLCWearLvl,    // 4
    cGcTypWPROSwap,    // 5
    // cGcTypReadReclaim,    // 5
};

#define mPushGcQue(x)\
    do\
    {\
        if(!mChkBitMask(gsGcInfo.uGcTypBit, x))\
        {\
            mSetBitMask(gsGcInfo.uGcTypBit, x);gsGcInfo.uGcQueueCnt++;\
        }\
    }\
    while(0)
#define mPopGcQue(x)\
    do\
    {\
        if(mChkBitMask(gsGcInfo.uGcTypBit, x))\
        {\
            mClrBitMask(gsGcInfo.uGcTypBit, x);gsGcInfo.uGcQueueCnt--;\
        }\
    }\
    while(0)
#define mChkGcQue(x)                             (mChkBitMask(gsGcInfo.uGcTypBit, x))

#if _GREYBOX
#define mCallFuncPtr(x)                          (((void (*)(void))(*(LWORD *)(((LWORD)&codeFuncPtr[x])+g32GreyBoxSwapOffset)))())
#define mCallFuncPtr2(x, p1)                     (((void (*)(BYTE))(*(LWORD *)(((LWORD)&codeFuncPtr2[x])+g32GreyBoxSwapOffset)))(p1))
#define mCallFuncPtr3(x)                         (((BYTE (*)(void))(*(LWORD *)(((LWORD)&codeFuncPtr3[x])+g32GreyBoxSwapOffset)))())
#define mCallFuncPtrCore1(x)                     (((void (*)(void))(*(LWORD *)(((LWORD)&codeFuncPtrCore1[x])+g32GreyBoxSwapOffset1)))())
#define mCallFuncPtr2Core1(x, p1)                (((void (*)(BYTE))(*(LWORD *)(((LWORD)&codeFuncPtr2Core1[x])+g32GreyBoxSwapOffset1)))(p1))
#define mCallFuncPtr3Core1(x, p1,\
                           p2)            (((WORD (*)(WORD, WORD))(*(LWORD *)(((LWORD)&codeFuncPtr3Core1[x])+g32GreyBoxSwapOffset1)))(p1, p2))
#define mCallFuncPtr4Core1(x)                    (((BYTE (*)(void))(*(LWORD *)(((LWORD)&codeFuncPtr4Core1[x])+g32GreyBoxSwapOffset1)))())
#define mCallFuncPtr5Core1(x, p1,\
                           p2)            (((void (*)(WORD, WORD))(*(LWORD *)(((LWORD)&codeFuncPtr5Core1[x])+g32GreyBoxSwapOffset1)))(p1, p2))
#else    // if _GREYBOX
#define mCallFuncPtr(x)                          codeFuncPtr[x]()
#define mCallFuncPtr2(x, p1)                     codeFuncPtr2[x](p1)
#define mCallFuncPtr3(x)                         codeFuncPtr3[x]()
#define mCallFuncPtrCore1(x)                     codeFuncPtrCore1[x]()
#define mCallFuncPtr2Core1(x, p1)                codeFuncPtr2Core1[x](p1)
#define mCallFuncPtr3Core1(x, p1, p2)            codeFuncPtr3Core1[x](p1, p2)
#define mCallFuncPtr4Core1(x)                    codeFuncPtr4Core1[x]()
#define mCallFuncPtr5Core1(x, p1, p2)            codeFuncPtr5Core1[x](p1, p2)
// #define mCallFuncPtr4(x, p1, p2, p3)             codeFuncPtr4[x](p1, p2, p3)
#endif    // if _GREYBOX

#define mChkWdtSaveLog                       (gWdtStatus&cBit1)
#define mSetWdtSaveLog                       (gWdtStatus|=cBit1)
#define mClrWdtSaveLog                       (gWdtStatus&=(~cBit1))
#define mChkWdtRstFlash                      (gWdtStatus&cBit0)
#define mSetWdtRstFlash                      (gWdtStatus|=cBit0)
#define mClrWdtRstFlash                      (gWdtStatus&=(~cBit0))

#if (_EN_CHRONUS_UART_DEBUG)
#define mUartDWofst                              (g32UartCMDofst>>2)
#define mClrUartCMDSOFofst                       (g32UartCMDSOFofst=0)
#define mClrUartCMDEOFofst                       (g32UartCMDEOFofst=0)
#endif    // if (_EN_CHRONUS_UART_DEBUG)

#define mChkUartCMDRdy                           (gUartCMDStatus&cBit7)
#define mSetUartCMDRdy                           (gUartCMDStatus|=cBit7)
#define mClrUartCMDRdy                           (gUartCMDStatus&=(~cBit7))
#define mChkUartHndShkRdy                        (gUartCMDStatus&cBit6)
#define mSetUartHndShkRdy                        (gUartCMDStatus|=cBit6)
#define mClrUartHndShkRdy                        (gUartCMDStatus&=(~cBit6))
#define mChkUartRxRdy                            (gUartCMDStatus&cBit5)
#define mSetUartRxRdy                            (gUartCMDStatus|=cBit5)
#define mClrUartRxRdy                            (gUartCMDStatus&=(~cBit5))
#define mChkUartHoldActiveMo                     (gUartCMDStatus&cBit2)
#define mSetUartHoldActiveMo                     (gUartCMDStatus|=cBit2)
#define mClrUartHoldActiveMo                     (gUartCMDStatus&=(~cBit2))

#define mSetThermalThrottlingByNand              (gThermalThrottlingReason|=cBit0)
#define mSetThermalThrottlingByAsic              (gThermalThrottlingReason|=cBit1)
#define mChkThermalThrottlingByNand              (gThermalThrottlingReason&cBit0)
#define mChkThermalThrottlingByAsic              (gThermalThrottlingReason&cBit1)
#define mClrThermalThrottlingReason              (gThermalThrottlingReason=0)

#if _EN_VPC_SWAP
#define mSetDataBlockBit(x)\
    if(!mChkBitMask(g32DataBlockBitmap[x>>5], x&0x1F))\
    {\
        mSetBitMask(g32DataBlockBitmap[x>>5], x&0x1F);\
    }\
    else\
    {\
        gFor512GbDebug=1;\
    }

#define mClrDataBlockBit(x)\
    if(mChkBitMask(g32DataBlockBitmap[x>>5], x&0x1F))\
    {\
        mClrBitMask(g32DataBlockBitmap[x>>5], x&0x1F);\
    }\
    else\
    {\
        gFor512GbDebug=1;\
    }
#define mChkDataBlockBit(x)                      mChkBitMask(g32DataBlockBitmap[x>>5], x&0x1F)
#endif    // if _EN_VPC_SWAP

#if _EN_Lenovo_RecoveryChk
#define mJudgeRecoverychkTrig                    (gsIomInfo_RecoveryCheck.u8Status==cRecoverychkTrig)
#else
#define mJudgeRecoverychkTrig                    (0)
#endif

#define mSetRLKeepRWBit(x)                         mSetBitMask(g32arRdLkKeepRWBitmap[x>>5], x&0x1F)
#define mChkRLKeepRWBit(x)                         mChkBitMask(g32arRdLkKeepRWBitmap[x>>5], x&0x1F)
#define mClrRLKeepRWBit(x)                         mClrBitMask(g32arRdLkKeepRWBitmap[x>>5], x&0x1F)

#if _EN_DisHMBInReset
#define mChkDisHMBCondition                      (gChkFlag&(cPcieD3State|cPcieSHNState))
#define mClrDisHMBCondition                      (gChkFlag&=(~(cPcieD3State|cPcieSHNState)))
#endif

#endif    // ifndef _MAC_H_







