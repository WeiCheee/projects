







#ifndef __REG_TSB_H__
#define __REG_TSB_H__

// TSB Control register  @ 0x5100_0800
#define rcBuf0Flag                               0x00
#define rmBufStatus(BufByteIdx)                  (rTsbCtrl[rcBuf0Flag+(BufByteIdx)])
#define rm16BufStatus(BufWordIdx)                (r16TsbCtrl[(rcBuf0Flag/2)+(BufWordIdx)])
#define rm32BufStatus(BufLWordIdx)               (r32TsbCtrl[(rcBuf0Flag/4)+(BufLWordIdx)])
#define rmSetBuf32Sts(BufLWordIdx, val)          r32TsbCtrl[(rcBuf0Flag/4)+(BufLWordIdx)]=val
#define rmSetBuf8Sts(BufByteIdx, val)            rTsbCtrl[rcBuf0Flag+(BufByteIdx)]=val

#define rcBuf0OccFlag                            0x200
#define rmBufOccStatus(BufByteIdx)               (rTsbCtrl[rcBuf0OccFlag+(BufByteIdx)])
#define rm32BufOccStatus(BufLWordIdx)            (r32TsbCtrl[(rcBuf0OccFlag/4)+(BufLWordIdx)])
#define rmSetBufOcc32Sts(BufLWordIdx, val)       r32TsbCtrl[(rcBuf0OccFlag/4)+(BufLWordIdx)]=val

#define rcBuf0RaidFlag                           0x400
#define rmBufRaidStatus(BufByteIdx)              (rTsbCtrl[rcBuf0RaidFlag+(BufByteIdx)])
#define rm32BufRaidStatus(BufLWordIdx)           (r32TsbCtrl[(rcBuf0RaidFlag/4)+(BufLWordIdx)])
#define rmSetBufRaid32Sts(BufLWordIdx, val)      (r32TsbCtrl[(rcBuf0RaidFlag/4)+(BufLWordIdx)]=val)
#define rmSetBufRaid8Sts(BufByteIdx, val)        (rTsbCtrl[rcBuf0RaidFlag+(BufByteIdx)]=val)

#define rcTsbEccRmwCorrAddr                      0x788
#define rmGetTsbEccRmwCorrAddr                   (r32TsbCtrl[rcTsbEccRmwCorrAddr/4]&0x3FFFFF)
#define rcTsbEccRmwCorrWe                        0x78B
#define rcTsbEccRmwCorrDack                      0x78C
#define rmGetTsbEccRmwCorrDack                   (r32TsbCtrl[rcTsbEccRmwCorrDack/4]&0x3FFFF)
#define rcTsbEccRmwCorrCnt                       0x78F
#define rmGetTsbEccRmwCorrCnt                    (rTsbCtrl[rcTsbEccRmwCorrCnt]&0xF)
#define rcTsbEccRmwCorrWdataL                    0x790    // [31:0]
#define rmGetTsbEccRmwCorrWdataL                 (r32TsbCtrl[rcTsbEccRmwCorrWdataL/4])
#define rcTsbEccRmwCorrWdataH                    0x794    // [63:32]
#define rmGetTsbEccRmwCorrWdataH                 (r32TsbCtrl[rcTsbEccRmwCorrWdataH/4])

#define rcTsbFlagSt0                             0x79C
#define rmErrHandleEn                            rTsbCtrl[rcTsbFlagSt0]|=cBit7

#define rcTsbFlagSt1                             0x79E
#define rcTsbFlagSt2                             0x79F

#define rcTsbEccRmwErrAddr                       0x7A0
#define rmGetTsbEccRmwErrAddr                    (r32TsbCtrl[rcTsbEccRmwErrAddr/4]&0x3FFFFF)
#define rcTsbEccRmwErrWe                         0x7A3
#define rmGetTsbEccRmwErrWe                      (rTsbCtrl[rcTsbEccRmwErrWe])
#define rcTsbEccRmwErrDack                       0x7A4
#define rmGetTsbEccRmwErrDack                    (r32TsbCtrl[rcTsbEccRmwErrDack/4]&0x3FFFF)
#define rcTsbEccRmwErrCnt                        0x7A7
#define rmGetTsbEccRmwErrCnt                     (rTsbCtrl[rcTsbEccRmwErrCnt]&0xF)
#define rcTsbEccRmwErrWdataL                     0x7A8    // [31:0]
#define rmGetTsbEccRmwErrWdataL                  (r32TsbCtrl[rcTsbEccRmwErrWdataL/4])
#define rcTsbEccRmwErrWataH                      0x7AC    // [63:32]
#define rmGetTsbEccRmwErrWdataH                  (r32TsbCtrl[rcTsbEccRmwErrWataH/4])

#define rcTsbEccCorrAddr                         0x7B0
#define rmGetTsbEccCorrAddr                      (r32TsbCtrl[rcTsbEccCorrAddr/4]&0x3FFFFF)
#define rcTsbEccCorr                             0x7B3
#define rmClrTsbEccCorr                          (rTsbCtrl[rcTsbEccCorr]|=cBit7);asm ("DSB");
#define rmEnTsbEccCorrFlg                        (rTsbCtrl[rcTsbEccCorr]|=cBit6);asm ("DSB");
#define rmDisTsbEccCorrFlg                       (rTsbCtrl[rcTsbEccCorr]&=(~cBit6));asm ("DSB");
#define rcTsbEccCorrDack                         0x7B4
#define rmGetTsbEccCorrDack                      (r32TsbCtrl[rcTsbEccCorrDack/4]&0x3FFFF)
#define rcTsbEccCorrCnt                          0x7B7
#define rmGetTsbEccCorrCnt                       (rTsbCtrl[rcTsbEccCorrCnt]&0xF)
#define rcTsbEccCorrRdataL                       0x7B8    // [31:0]
#define rmGetTsbEccCorrRdataL                    (r32TsbCtrl[rcTsbEccCorrRdataL/4])
#define rcTsbEccCorrRdataH                       0x7BC    // [63:32]
#define rmGetTsbEccCorrRdataH                    (r32TsbCtrl[rcTsbEccCorrRdataH/4])

#define rcTsbEccCorrLhXorPty                     0x7C1
#define rmGetTsbEccCorrLhXorPty                  (r32TsbCtrl[rcTsbEccCorrLhXorPty/4]&0x7F)
#define rcTsbEccCorrLhPtn                        0x7C4
#define rmGetTsbEccCorrLhPtn                     (r32TsbCtrl[rcTsbEccCorrLhPtn/4])
#define rcTsbEccCorrUhXorPty                     0x7C9
#define rmGetTsbEccCorrUhXorPty                  (r32TsbCtrl[rcTsbEccCorrUhXorPty/4]&0x7F)
#define rcTsbEccCorrUhPtn                        0x7CC
#define rmGetTsbEccCorrUhPtn                     (r32TsbCtrl[rcTsbEccCorrUhPtn/4])

#define rcTsbEccErrAddr                          0x7D0
#define rmGetTsbEccErrAddr                       (r32TsbCtrl[rcTsbEccErrAddr/4]&0x3FFFFF)
#define rcTsbEccErr                              0x7D3
#define rmClrTsbEccErr                           (rTsbCtrl[rcTsbEccErr]|=cBit7);asm ("DSB");
#define rmEnTsbEccErrFlg                         (rTsbCtrl[rcTsbEccErr]|=cBit6);asm ("DSB");
#define rmDisTsbEccErrFlg                        (rTsbCtrl[rcTsbEccErr]&=(~cBit6));asm ("DSB");
#define rcTsbEccErrDack                          0x7D4
#define rmGetTsbEccErrDack                       (r32TsbCtrl[rcTsbEccErrDack/4]&0x3FFFF)
#define rcTsbEccErrCnt                           0x7D7
#define rmGetTsbEccErrCnt                        (rTsbCtrl[rcTsbEccErrCnt/4]&0xF)
#define rcTsbEccErrRdataL                        0x7D8    // [31:0]
#define rmGetTsbEccErrRdataL                     (r32TsbCtrl[rcTsbEccErrRdataL/4])
#define rcTsbEccErrRdataH                        0x7DC    // [63:32]
#define rmGetTsbEccErrRdataH                     (r32TsbCtrl[rcTsbEccErrRdataH/4])

#define rcTsbEccErrLhXorPty                      0x7E1
#define rmGetTsbEccErrLhXorPty                   (r32TsbCtrl[rcTsbEccErrLhXorPty/4]&0x7F)
#define rcTsbEccErrLhPtn                         0x7E4
#define rmGetTsbEccErrLhPtn                      (r32TsbCtrl[rcTsbEccErrLhPtn/4])
#define rcTsbEccErrUhXorPty                      0x7E9
#define rmGetTsbEccErrUhXorPty                   (r32TsbCtrl[rcTsbEccErrUhXorPty/4]&0x7F)
#define rcTsbEccErrUhPtn                         0x7EC
#define rmGetTsbEccErrUhPtn                      (r32TsbCtrl[rcTsbEccErrUhPtn/4])

#define  rcTsbErrFlag0                           0x7F0
#define  rcTsbErrFlag1                           0x7F2
#define  rcTsbErrFlag2                           0x7F3
#define  rcErrTimerIntVal                        0x7f4
#define  rcDebugTsfCnt                           0x7f6
#define  rcDebugAddress                          0x7f8
#define  rmChkTsbErr                             (rTsbCtrl[rcTsbErrFlag0]!=0x00)|(rTsbCtrl[rcTsbErrFlag1]!=0x00)|(rTsbCtrl[rcTsbErrFlag2]!=0x00)
#define  rmChkTsbErrPcieLdpc                     (rTsbCtrl[rcTsbErrFlag0]!=0x00)
#define  rmChkTsbErrCpuDma                       (rTsbCtrl[rcTsbErrFlag1]!=0x00)
#define  rmChkTsbErrFlash                        (rTsbCtrl[rcTsbErrFlag2]!=0x00)
#define  rmClrAllTsbErr                          (rTsbCtrl[rcTsbErrFlag0]|=cBit7)
#define  rmGetTsbSelErr                          (rTsbCtrl[rcTsbErrFlag0]<<16)|(rTsbCtrl[rcTsbErrFlag1]<<8)|rTsbCtrl[rcTsbErrFlag2]
#define  rmGetTsbSelErrPcieLdpc                  (rTsbCtrl[rcTsbErrFlag0])
#define  rmGetTsbSelErrCpuDma                    (rTsbCtrl[rcTsbErrFlag1])
#define  rmGetTsbSelErrFlash                     (rTsbCtrl[rcTsbErrFlag2])
#define  rmChkTsbHdaErr                          (rTsbCtrl[rcTsbErrFlag1]&cBit6)
#define  rmSetTsbErrTimerIntVal(x)               (r16TsbCtrl[rcErrTimerIntVal/2]=x)
#define  rmGetTsbDebugAddress                    r32TsbCtrl[rcDebugAddress/4]
#define  rmGetTsbDebugTsfCnt                     r16TsbCtrl[rcDebugTsfCnt/2]

#define  rcTsbCtrl0                              0x7FC
#define  rmTsbEnTsb2Grp                          (rTsbCtrl[rcTsbCtrl0]|=cBit5)
#define  rmTsbDisTsb2Grp                         (rTsbCtrl[rcTsbCtrl0]&=(~cBit5))
#define  rmTsbEnSync                             (rTsbCtrl[rcTsbCtrl0]|=cBit4)
#define  rmTsbDisSync                            (rTsbCtrl[rcTsbCtrl0]&=(~cBit4))
#define  rmTsbEnTsb2Flg                          (rTsbCtrl[rcTsbCtrl0]|=cBit6)
#define  rmTsbDisTsb2Flg                         (rTsbCtrl[rcTsbCtrl0]|=(~cBit6))
#define  rmTsbEnTsb1Flg                          (rTsbCtrl[rcTsbCtrl0]|=cBit3)
#define  rmTsbDisTsb1Flg                         (rTsbCtrl[rcTsbCtrl0]&=(~cBit3))
#define  rmTsbEnTsb0Flg                          (rTsbCtrl[rcTsbCtrl0]|=cBit2)
#define  rmTsbDisTsb0Flg                         (rTsbCtrl[rcTsbCtrl0]&=(~cBit2))
#define  rmTsbEnTsb1Grp                          (rTsbCtrl[rcTsbCtrl0]|=cBit1)
#define  rmTsbDisTsb1Grp                         (rTsbCtrl[rcTsbCtrl0]&=(~cBit1))
#define  rmTsbEnTsb0Grp                          (rTsbCtrl[rcTsbCtrl0]|=cBit0)
#define  rmTsbDisTsb0Grp                         (rTsbCtrl[rcTsbCtrl0]&=(~cBit0))

#define  rmEnTsb0Group                           (rTsbCtrl[rcTsbCtrl0]|=cBit0)    // to control sata and flash bufferhandshake
#define  rmEnTsb1Group                           (rTsbCtrl[rcTsbCtrl0]|=cBit1)
// #define  rmEnTsbGroupMod                        (rTsbCtrl[rcTsbCtrl0]|=0x03)
#define  rmEnTsb0HandShake                       (rTsbCtrl[rcTsbCtrl0]|=cBit2)    // to control sata and flash bufferhandshake
#define  rmEnTsb1HandShake                       (rTsbCtrl[rcTsbCtrl0]|=cBit3)
#define  rmDisTsb0HandShake                      (rTsbCtrl[rcTsbCtrl0]&=(~cBit2))    // to control sata and flash bufferhandshake
#define  rmDisTsb1HandShake                      (rTsbCtrl[rcTsbCtrl0]&=(~cBit3))

#define  rmEnSataCtrlFlg                         (rTsbCtrl[rcTsbCtrl0]&=(~cBit5))
#define  rmEnBopCtrlFlg                          (rTsbCtrl[rcTsbCtrl0]|=cBit5)

#define  rcTsbCtrl1                              0x7FD
#define  rmTsbEnClrBFlg                          (rTsbCtrl[rcTsbCtrl1]|=cBit4)
#define  rmTsbDisClrBFlg                         (rTsbCtrl[rcTsbCtrl1]&=(~cBit4))
#define  rmTsbEnClrOFlg                          (rTsbCtrl[rcTsbCtrl1]|=cBit3)
#define  rmTsbDisClrOFlg                         (rTsbCtrl[rcTsbCtrl1]&=(~cBit3))
#define  rmTsbEnClrMFlg                          (rTsbCtrl[rcTsbCtrl1]|=cBit2)
#define  rmTsbDisClrMFlg                         (rTsbCtrl[rcTsbCtrl1]&=(~cBit2))
#define  rmTsbEnSetBFlg                          (rTsbCtrl[rcTsbCtrl1]|=cBit1)
#define  rmTsbDisSetBFlg                         (rTsbCtrl[rcTsbCtrl1]&=(~cBit1))
#define  rmTsbEnSetOFlg                          (rTsbCtrl[rcTsbCtrl1]|=cBit0)
#define  rmTsbDisSetOFlg                         (rTsbCtrl[rcTsbCtrl1]&=(~cBit0))

#define  rmResetBufFlg                           {rmTsbEnClrBFlg;asm ("DSB");rmTsbDisClrBFlg;asm ("DSB");}
#define  rmResetOccupyFlg                        {rmTsbEnClrOFlg;asm ("DSB");rmTsbDisClrOFlg;asm ("DSB");}
#define  rmResetRaidFlg                          {rmTsbEnClrMFlg;asm ("DSB");rmTsbDisClrMFlg;asm ("DSB");}

#define  rmTsbBufCheck(x)                        (rTsbCtrl[x/8]&(1<<(x%8)))
#define  rmTsbBufFlip(x)                         (rTsbCtrl[x/8]=(1<<(x%8)))

#define  rmSetAllBufFlg                          {rTsbCtrl[rcTsbCtrl1]|=cBit1;rTsbCtrl[rcTsbCtrl1]&=(~cBit1);}
#define  rmSetAllOccupyFlg                       (rTsbCtrl[rcTsbCtrl1]|=cBit0)
// Allen TSB bank interleave
#define  rmTsbInterLeaveDisable                  (rTsbCtrl[rcTsbCtrl1]=(rTsbCtrl[rcTsbCtrl1]&0x1f)|0x00)
#define  rmTsbInterLeave512B                     (rTsbCtrl[rcTsbCtrl1]=(rTsbCtrl[rcTsbCtrl1]&0x1f)|0x20)
#define  rmTsbInterLeave1K                       (rTsbCtrl[rcTsbCtrl1]=(rTsbCtrl[rcTsbCtrl1]&0x1f)|0x40)
#define  rmTsbInterLeave2K                       (rTsbCtrl[rcTsbCtrl1]=(rTsbCtrl[rcTsbCtrl1]&0x1f)|0x60)
#define  rmTsbInterLeave4K                       (rTsbCtrl[rcTsbCtrl1]=(rTsbCtrl[rcTsbCtrl1]&0x1f)|0x80)

#define  rcTsbCtrl2                              0x7FE
#define  rmEnTsb2Group                           (rTsbCtrl[rcTsbCtrl2]|=cBit0)    // to control sata and flash bufferhandshake
#define  rmEnTsb3Group                           (rTsbCtrl[rcTsbCtrl2]|=cBit1)
#define  rmEnTsb2HandShake                       (rTsbCtrl[rcTsbCtrl2]|=cBit2)    // to control sata and flash bufferhandshake
#define  rmEnTsb3HandShake                       (rTsbCtrl[rcTsbCtrl2]|=cBit3)
#define  rmDisTsb2HandShake                      (rTsbCtrl[rcTsbCtrl2]&=(~cBit2))    // to control sata and flash bufferhandshake
#define  rmDisTsb3HandShake                      (rTsbCtrl[rcTsbCtrl2]&=(~cBit3))
// #define  rmEnTsb4Group                           (rTsbCtrl[rcTsbCtrl2]|=cBit4)    // to control sata and flash bufferhandshake
#define  rmEnOccpRaidSel                         (rTsbCtrl[rcTsbCtrl2]|=cBit5)
#define  rmSeqMskNseqEn                          (rTsbCtrl[rcTsbCtrl2]|=cBit7)
#define  rmEnTsbEcc                              (rTsbCtrl[rcTsbCtrl2]|=cBit6);asm ("DSB");
#define  rmDisTsbEcc                             (rTsbCtrl[rcTsbCtrl2]&=(~cBit6));asm ("DSB");

#define  rmEnTsbGroupMod                         {rTsbCtrl[rcTsbCtrl0]|=0x03;rTsbCtrl[rcTsbCtrl2]|=0x03;}

#define  rcTsbCtrl3                              0x7FF
#define  rmSetTsbMSel(x)                         (rTsbCtrl[rcTsbCtrl3]=(x&0x1F))

// TSB4 Control register  @ 0x5000_0600
#define rcTsb4EccRmwCorrAddr                     0x8C
#define rmGetTsb4EccRmwCorrAddr                  (r32Tsb4Ctrl[rcTsb4EccRmwCorrAddr/4]&0x3FFFFF)
#define rcTsb4EccRmwCorrDack                     0x90
#define rmGetTsb4EccRmwCorrDack                  (r32Tsb4Ctrl[rcTsb4EccRmwCorrDack/4]&0x3FFFF)
#define rcTsb4EccRmwCorrCnt                      0x93
#define rmGetTsb4EccRmwCorrCnt                   (rTsb4Ctrl[rcTsb4EccRmwCorrCnt]&0xF)
#define rcTsb4EccRmwCorrWdataL                   0x94    // [31:0]
#define rmGetTsb4EccRmwCorrWdataL                (r32Tsb4Ctrl[rcTsb4EccRmwCorrWdataL/4])
#define rcTsb4EccRmwCorrWdataH                   0x98    // [63:32]
#define rmGetTsb4EccRmwCorrWdataH                (r32Tsb4Ctrl[rcTsb4EccRmwCorrWdataH/4])

#define rcTsb4FlagSt0                            0x9C
#define rmEnTsb4ErrHandle                        (rTsb4Ctrl[rcTsb4FlagSt0]|=cBit7)
#define rmDisTsb4ErrHandle                       (rTsb4Ctrl[rcTsb4FlagSt0]&=(~cBit7))
#define rcTsb4FlagSt2                            0x9E
#define rmGetTsb4FlagSt2                         (rTsb4Ctrl[rcTsb4FlagSt2])

#define rcTsb4EccRmwErrAddr                      0xA0
#define rmGetTsb4EccRmwErrAddr                   (r32Tsb4Ctrl[rcTsb4EccRmwErrAddr/4]&0x3FFFFF)
#define rcTsb4EccRmwErrWe                        0xA3
#define rmGetTsb4EccRmwErrWe                     (rTsb4Ctrl[rcTsb4EccRmwErrWe])
#define rcTsb4EccRmwErrDack                      0xA4
#define rmGetTsb4EccRmwErrDack                   (r32Tsb4Ctrl[rcTsb4EccRmwErrDack/4]&0x3FFFF)
#define rcTsb4EccRmwErrCnt                       0xA7
#define rmGetTsb4EccRmwErrCnt                    (rTsb4Ctrl[rcTsb4EccRmwErrCnt]&0xF)
#define rcTsb4EccRmwErrWdataL                    0xA8    // [31:0]
#define rmGetTsb4EccRmwErrWdataL                 (r32Tsb4Ctrl[rcTsb4EccRmwErrWdataL/4])
#define rcTsb4EccRmwErrWdataH                    0xAC    // [63:32]
#define rmGetTsb4EccRmwErrWdataH                 (r32Tsb4Ctrl[rcTsb4EccRmwErrWdataH/4])

#define rcTsb4EccCorrAddr                        0xB0
#define rmGetTsb4EccCorrAddr                     (r32Tsb4Ctrl[rcTsb4EccCorrAddr/4]&0x3FFFFF)

#define rcTsb4EccCorr                            0xB3
#define rmClrTsb4EccCorr                         (rTsb4Ctrl[rcTsb4EccCorr]|=cBit7);asm ("DSB");
#define rmEnTsb4EccCorrFlg                       (rTsb4Ctrl[rcTsb4EccCorr]|=cBit6);asm ("DSB");
#define rmDisTsb4EccCorrFlg                      (rTsb4Ctrl[rcTsb4EccCorr]&=(~cBit6));asm ("DSB");

#define rcTsb4EccCorrDack                        0xB4
#define rmGetTsb4EccCorrDack                     (r32Tsb4Ctrl[rcTsb4EccCorrDack/4]&0x3FFFF)
#define rcTsb4EccCorrCnt                         0xB7
#define rmGetTsb4EccCorrCnt                      (rTsb4Ctrl[rcTsb4EccCorrCnt]&0xF)
#define rcTsb4EccCorrRdataL                      0xB8    // [31:0]
#define rmGetTsb4EccCorrRdataL                   (r32Tsb4Ctrl[rcTsb4EccCorrRdataL/4])
#define rcTsb4EccCorrRdataH                      0xBC    // [63:32]
#define rmGetTsb4EccCorrRdataH                   (r32Tsb4Ctrl[rcTsb4EccCorrRdataH/4])

#define rcTsb4EccCorrLhXorPty                    0xC1
#define rmGetTsb4EccCorrLhXorPty                 (r32Tsb4Ctrl[rcTsb4EccCorrLhXorPty/4]&0x7F)
#define rcTsb4EccCorrLhPtn                       0xC4
#define rmGetTsb4EccCorrLhPtn                    (r32Tsb4Ctrl[rcTsb4EccCorrLhPtn/4])
#define rcTsb4EccCorrUhXorPty                    0xC9
#define rmGetTsb4EccCorrUhXorPty                 (r32Tsb4Ctrl[rcTsb4EccCorrUhXorPty/4]&0x7F)
#define rcTsb4EccCorrUhPtn                       0xCC
#define rmGetTsb4EccCorrUhPtn                    (r32Tsb4Ctrl[rcTsb4EccCorrUhPtn/4])

#define rcTsb4EccErrAddr                         0xD0
#define rmGetTsb4EccErrAddr                          (r32Tsb4Ctrl[rcTsb4EccErrAddr/4]&0x3FFFFF)
#define rcTsb4EccErr                             0xD3
#define rmClrTsb4EccErr                          (rTsb4Ctrl[rcTsb4EccErr]|=cBit7);asm ("DSB");
#define rmEnTsb4EccErrFlg                        (rTsb4Ctrl[rcTsb4EccErr]|=cBit6);asm ("DSB");
#define rmDisTsb4EccErrFlg                       (rTsb4Ctrl[rcTsb4EccErr]&=(~cBit6));asm ("DSB");

#define rmTsb4EccErrDack                         0xD4
#define rmGetTsb4EccErrDack                      (r32Tsb4Ctrl[rmTsb4EccErrDack/4]&0x3FFFF)
#define rcTsb4EccErrCnt                          0xD7
#define rmGetTsb4EccErrCnt                       (rTsb4Ctrl[rcTsb4EccErrCnt]&0xF)
#define rcTsb4EccErrRdataL                       0xD8    // [31:0]
#define rmGetTsb4EccErrRdataL                    (r32Tsb4Ctrl[rcTsb4EccErrRdataL/4])
#define rcTsb4EccErrRdataH                       0xDC    // [63:32]
#define rmGetTsb4EccErrRdataH                    (r32Tsb4Ctrl[rcTsb4EccErrRdataH/4])

#define rcTsb4EccErrLhXorPty                     0xE1
#define rmGetTsb4EccErrLhXorPty                  (r32Tsb4Ctrl[rcTsb4EccErrLhXorPty/4]&0x7F)
#define rcTsb4EccErrLhPtn                        0xE4
#define rmGetTsb4EccErrLhPtn                     (r32Tsb4Ctrl[rcTsb4EccErrLhPtn/4])
#define rcTsb4EccErrUhXorPty                     0xE9
#define rmGetTsb4EccErrUhXorPty                  (r32Tsb4Ctrl[rcTsb4EccErrUhXorPty/4]&0x7F)
#define rcTsb4EccErrUhPtn                        0xEC
#define rmGetTsb4EccErrUhPtn                     (r32Tsb4Ctrl[rcTsb4EccErrUhPtn/4])

#define  rcTsb4ErrFlag0                          0xF0
#define  rmClrAllTsb4Err                         (rTsb4Ctrl[rcTsb4ErrFlag0]|=cBit7)
#define  rcTsb4ErrFlag1                          0xF2
#define  rmChkTsb4ErrCpuDma                      (rTsb4Ctrl[rcTsb4ErrFlag1]!=0x00)
#define  rmGetTsb4ErrCpuDma                      (rTsb4Ctrl[rcTsb4ErrFlag1])
#define  rmChkTsb4Err                            (rTsb4Ctrl[rcTsb4ErrFlag1]!=0x00)
#define  rcTsb4ErrTimerIntVal                    0xF4
#define  rcTsb4Ctrl2                             0xFE
#define  rmEnTsb4Group                           (rTsb4Ctrl[rcTsb4Ctrl2]|=cBit4);asm ("DSB");
#define  rmEnTsb4Ecc                             (rTsb4Ctrl[rcTsb4Ctrl2]|=cBit6);asm ("DSB");
#define  rmDisTsb4Ecc                            (rTsb4Ctrl[rcTsb4Ctrl2]&=(~cBit6));asm ("DSB");

#endif    // ifndef __REG_TSB_H__







