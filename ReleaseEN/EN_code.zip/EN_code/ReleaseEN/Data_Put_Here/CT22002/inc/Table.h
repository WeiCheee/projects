







#ifndef __TABLE_H__
#define __TABLE_H__

#include "inc/TypeDef.h"
#include "inc/Option.h"

extern CBYTE cbSignFwPublicKey[260];

#if _ENABLE_RETRY_TSB_BiCS4_256Gb
extern CBYTE cbRetryTable[768];
#else
extern CBYTE cbRetryTable[512];
#endif
extern CBYTE cbParaPageId[];
extern CBYTE cbRomTag[];

// extern CBYTE cbNvmeLbaRangeType[]; //for test

extern CBYTE cbBitTab[];
extern CWORD cb16BitTab[];
extern CLWORD cb32BitTab[];
extern CLWORD cb32BitNumTab[];
extern CQWORD cb64BitTab[];
extern CBYTE cbBitNumTab[];

// extern CWORD cb16FlashPLL[];
// extern CWORD cb16SysPLL[];
// extern CBYTE cbLightSwTab[];
extern CBYTE cbMainTag[];

// ---SSDBIN Binary Info-----
extern CBYTE cbHeader[];
extern CBYTE cbModelname2[];
extern CBYTE cbRevision1[];
extern CBYTE cbRevision2[];
extern CBYTE cbCompamentID[];
extern CBYTE cbOEMversion[];
extern CBYTE cbSupportCapacity[];
extern CBYTE cbReleaseTime[];
extern CBYTE cbReserved0[];
extern CBYTE cbSecurityVer[];
#ifdef TCG_SUPPORT
extern CBYTE cbTCGTag[];
#endif
// ---SSDBIN Binary Info-----

#endif    // ifndef __TABLE_H__







