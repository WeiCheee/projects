







#include "inc/TypeDef.h"
#include "inc/Const.h"

// -----------------TSB----------------//
// #pragma default_variable_attributes = @ ".TSBUF0"  //TSB0 384K
// extern volatile BYTE garTsb0[cTsb0Size][512];
// #pragma default_variable_attributes =

// #pragma default_variable_attributes = @ ".BADINFOBUF"
// extern volatile BYTE garBadInfoBuf[cTsb0Size*512];
// #pragma default_variable_attributes =

// #pragma default_variable_attributes = @ ".TSBUF0_16"
// extern volatile WORD g16arTsb0[cTsb0Size][512/2];
// #pragma default_variable_attributes =

// #pragma default_variable_attributes = @ ".BADINFOBUF_16"
// extern volatile WORD g16arBadInfoBuf[(cTsb0Size*512)/2];
// #pragma default_variable_attributes =

// #pragma default_variable_attributes = @ ".TSBUF0_32"
// extern volatile LWORD g32arTsb0[cTsb0Size][512/4];
// #pragma default_variable_attributes =

// #pragma default_variable_attributes = @ ".BADINFOBUF_32"
// extern volatile LWORD g32arBadInfoBuf[(cTsb0Size*512)/4];
// #pragma default_variable_attributes =

// #pragma default_variable_attributes = @ ".TSBUF0_64"
// extern volatile QWORD g64arTsb0[cTsb0Size][512/8];
// #pragma default_variable_attributes =

// #pragma default_variable_attributes = @ ".F2H_TAB"
// #pragma default_variable_attributes =

// #pragma default_variable_attributes = @ ".H2F_TAB"
// #pragma default_variable_attributes =

// #pragma default_variable_attributes = @ ".TSB2"
// #pragma default_variable_attributes =

// #pragma default_variable_attributes = @ ".TSB3"
// #pragma default_variable_attributes =

// #pragma default_variable_attributes = @ ".TSB4"
extern volatile WORD g16arEventLog[cEventLogSize];
// extern volatile WORD g16arCore1EventLog[cCore1EventLogSize];
extern LWORD g32arHmbCrc[c16HmbMaxTableNumAlign];    // 2kB
extern BYTE gCrcDataBuffer[cCrcDataBufferSize];    // 1K
extern LWORD g32arGcDataCrc[(cMaxHmbGcCacheNum*cTsb0Size/cHmbChunkSctrSize)*2];    // 1.5K
extern LWORD g32arGcInfoCrc[(cWproGcInfoPage-cWproGcDesF2hTab00+1)*(c32GcInfoTabSctrCnt/c16LoadPartTabStcrCnt)];    // <512b
extern LWORD g32arGcPtyCrc[cPartialParityNum*2];    // 3K
extern LWORD g32arTsbCrc[(cTsb0Size/cHmbChunkSctrSize)*2];    // 48b
extern BYTE garTsb4Rsvd[4096];
// extern LIGHTSWITCH gsLightSwitch;
// #pragma default_variable_attributes =

// #pragma default_variable_attributes = @ ".CACHE_INFO"
// #pragma default_variable_attributes =

// #pragma default_variable_attributes = @ ".LIGHTSWITCH"  //LightSwitch 384K
// extern LIGHTSWITCH gsLightSwitch;
// #pragma default_variable_attributes =

// #pragma default_variable_attributes = @ ".NVMEFEATURE"    // TSB0
// extern NVMEFEATVAR gsNvmeFeatVar;
// #pragma default_variable_attributes =

// #pragma default_variable_attributes = @ ".GETLOGPAGE"    // TSB0
// extern GETLOGINFO gsGetLog;
// #pragma default_variable_attributes =

// ====================================================================MIKEY add
// #pragma default_variable_attributes = @ ".F2H_TAB"
extern F2HTABLE garCacheF2hTab[c16CacheF2hSize];    // 32KB
#if (!_TSB_BiCS4)
extern LWORD g32arHmbCrc[c16HmbMaxTableNum];    // 2kB
extern LWORD g32arGlobReadCnt[c16MaxBlockNum];    // 6kB
extern LWORD g32arLogNandQueue[2048/4];    // 2kB
extern BYTE gCrcDataBuffer[cCrcDataBufferSize];    // 1K
extern LWORD g32arGcDataCrc[(cMaxHmbGcCacheNum*cTsb0Size/cHmbChunkSctrSize)*2];    // 1.5K
extern LWORD g32arGcInfoCrc[(cWproGcInfoPage-cWproGcDesF2hTab00+1)*(c32GcInfoTabSctrCnt/c16LoadPartTabStcrCnt)];    // <512b
extern LWORD g32arGcPtyCrc[cPartialParityNum*2];    // 3K
extern LWORD g32arTsbCrc[(cTsb0Size/cHmbChunkSctrSize)*2];    // 48b
#endif
// #pragma default_variable_attributes =   //END OF .F2H_TAB

// #pragma default_variable_attributes = @ ".RSV_SCT"
extern LWORD g32arGcInvaildPageBimap[c16RaidBufSize];    // 16KB
// #pragma default_variable_attributes =

// #pragma default_variable_attributes = @ ".H2F_TAB"
extern LWORD g32arH2fTable[c32H2fTabRamSize/4];    // 64KB
// #pragma default_variable_attributes =   //END OF .H2F_TAB

extern LWORD garH2f1kTable[cMaxRH2fTabNum][c16RH2fTabSize];    // 32kb

//// #pragma default_variable_attributes = @ ".BootTempVar"
// extern WORD g16arTempGlobEraseCnt[c16MaxBlockNum];    // 2kb
// #pragma default_variable_attributes = //END OF .BootTempVar

// CACHEINFO
// #pragma default_variable_attributes = @ ".CACHE_INFO"
// extern UCLWORD g32arGlobEraseCnt[c16MaxBlockNum];    // 4kb
#if _EN_VPC_SWAP
extern LWORD g32arMlcMoBit[c16MaxBlockNum/32];
extern LWORD g32arSkipGcSrch[c16MaxBlockNum/32];
extern LWORD g32arVPCntValid[c16MaxBlockNum/32];
#else
extern LWORD g32arCacheBlkVpCnt[c16MaxBlockNum];    // 4kb
#endif
extern LWORD g32arPopBit[c16MaxBlockNum/32];    // 192b
extern LWORD g32arH2fTabBlkSn[c16MaxH2fTabBlkNum];    // 32b
extern WORD g16arH2fTabBlk[c16MaxH2fTabBlkNum];    // 16b
extern WORD g16arH2fTabPtr[c16MaxH2fTabNum+c16HmbMaxTableNum];    // 18kb+1kb
extern WORD g16arH2fBackup[c16HmbMaxTableNum];    // 1kb
// extern LWORD g32arH2fTabNullFlag[c16MaxH2fTabNum/32];
extern WORD g16arH2fTabBlkVpCnt[c16MaxH2fTabBlkNum];    // 16b
extern LWORD g32GcSkipSrcHblkSrch[c16MaxH2fTabNum/32];    // 1kb

extern WORD g16arRaidParityBlk[cRaidParityBlockNum];
extern WORD g16arRaidParityPtr[cRaidParityPageNum];
extern WORD g16arRaidPtyBlkVpCnt[cRaidParityBlockNum];

// extern WORD g16arCacheBlock[c16MaxCacheBlkNumInF2hTab];    // 128b
#if (!_BypassEraseFlag)
extern LWORD g32arEraseFlag[c16MaxBlockNum/32];    // 256b
#endif
extern PUSHSPRINFO garPushSpareQ[c16MaxPushSprbNum];
extern LWORD g16PushSpareCnt;
extern LWORD g16PushSpareTail;
extern LWORD g16PushSpareHead;
// extern WORD g16RebuGcDesF2hCnt;
extern WORD g16MaxSlcCacheBlockThr;
extern WORD g16CurrSlcCacheBlockThr;
extern LWORD g32WearLevelCnt;
// rdlink
extern LWORD g32BkRdActCBlkSerial;
extern LWORD g32BkRdCacheFreePagePtr;
extern LWORD g32BkCacheBlkSerial;
extern LWORD g32BkFluBlkSerial;
extern LWORD g32BkGcDesSerial;
extern LWORD g32BkH2fTabBlkSerial;
// extern LWORD g32BkGcSrcF4kPtr;
extern LWORD g32BkTotalSlcVpc;
extern LWORD g32BkTotalTlcVpc;
extern WORD g16BkCacheF2hTabFreePtr;
extern WORD g16BkRdActiveCacheBlock;
extern WORD g16BkActiveCacheBlock;
extern WORD g16BkGcDesSlcBlock;
extern WORD g16BkGcDesTlcBlock;
extern WORD g16BkFluCacheBlock;
extern WORD g16BkPrePopCacheBlock;
extern WORD g16BkActH2fTabFblk;
extern WORD g16BkH2fTabFreePagePtr;

extern LWORD g32TotalEraseCnt;
extern LWORD g32DynamicTotalEraseCnt;
extern LWORD g32SLCTotalEraseCnt;

#if (_EN_SLC_END_PARA)
extern LWORD g32SlcMaxEraseCnt;
extern LWORD g32TlcMaxEraseCnt;
#endif

extern WORD g16TLCGcWLCnt;
extern WORD g16SLCReclaimCnt;
extern WORD g16ReclaimCnt;
extern WORD g16WLCheckBlk;

#if _EN_SLCOpenBlkReadScrub
extern WORD g16SLCFlushCnt;
extern WORD g16H2FReadScrubCnt;
#endif

extern BYTE gBkFidBlock;
extern BYTE gBkRdActF2hTabBank;

extern WORD g16BkCacheActWindow;
extern WORD g16BkCacheWindowGrp;
extern WORD g16BkActiveGcDesBlock;
extern WORD g16BkGcDesActWindow;
extern WORD g16BkGcDesWindowGrp;

// extern LWORD g32BkWproSerial;

extern LWORD g32SpecFuncFlag;

extern BYTE gPowerDownMode;

extern WORD g16BkWriteBufPtr;
extern WORD g16BkFlashWBufPtr;
extern LWORD g32MaxRebuTime;

extern LWORD g32MaxS2TGCtime;
extern LWORD g32MaxT2TGCtime;
// extern BYTE gPCIEerrCnt;
extern QWORD g64HostWrCmdCnt;
extern QWORD g64HostRdCmdCnt;
extern QWORD g64TotalHostRdSecCnt;
extern QWORD g64NandSlcTotalWriteSecCnt;
extern QWORD g64NandTlcTotalWriteSecCnt;
extern QWORD g64NandSlcTotalReadSecCnt;
extern QWORD g64NandTlcTotalReadSecCnt;

extern WORD g16TotalProgFailCnt;
extern WORD g16RaidDecTotalCnt;
extern WORD g16RaidDecSkipCnt;
extern BYTE gRaidMaxPopEngCnt;

extern WORD g16StaticBound;

extern CACHEINFO gsBkPcieErrCacheInfo;

extern NAMESPACEINFO gsNamespace;

extern LWORD g32E2eDetectCnt;
extern WORD g16SramOneBitErrCnt;
extern WORD g16SramTwoBitErrCnt;
extern LWORD g32InternalDataPath;
extern LWORD g32PrdCommandRetryCnt;

extern LWORD g32Vdt27FailCnt;
extern LWORD g32ThermalMT1TranCnt;
extern LWORD g32ThermalMT2TranCnt;
extern LWORD g32PwrOnAbortPs3Cnt;
extern LWORD g32PwrOnAbortPs4Cnt;
extern QWORD g64PwrOnPs3Cnt;
extern QWORD g64PwrOnPs4Cnt;
extern LWORD g32TotalPcieRdErrCnt;
extern LWORD g32TotalPcieWrErrCnt;
extern LWORD g32TotalPcieOthErrCnt;

extern LWORD g32BkRdFlsCBlkSerial;
extern WORD g16BkRdFlushCacheBlock;
extern BYTE gBkRdFlsF2hTabBank;    // The F2h bank of flush  cache block at last rdlink
extern LWORD g32ThermalMT3TranCnt;
extern LWORD g32AsicThermalMT3TranCnt;

extern LWORD g32arCacheBlkSerial[cCacheBlkNum];
extern WORD g16arCacheBlock[cCacheBlkNum];
extern BYTE garCacheBlkF2hTabBank[cCacheBlkNum];
extern LWORD g32StaticSLCTotalEC;
extern LWORD g32DynamicSLCTotalEC;

extern WORD g16DummyQBAnalysis[4];

#if _EN_VPC_SWAP
extern WORD g16arGlobReadCnt[c16MaxBlockNum];    // 5kB
extern BYTE garGlobReadCntHighByte[c16MaxBlockNum];    // 5kB
#endif
// #pragma default_variable_attributes =
extern DBGLOG gsFtlDbg;
// #pragma default_variable_attributes =   //END OF .CACHE_INFO
// extern PS4BACKUP garBkPS4Data;
// #pragma default_variable_attributes =







