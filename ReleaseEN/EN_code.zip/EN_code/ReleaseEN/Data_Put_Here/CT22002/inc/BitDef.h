







#include "inc/Option.h"
#include "inc/TypeDef.h"
#include "inc/GlobVar0.h"
#include "inc/GlobVarS.h"

// >>> merge 58xt IM3D

#define mSetISPMode(x)                           gSysOpFlag=(gSysOpFlag&0x0F)|(x<<4)
#define mChkISPMode                              (gSysOpFlag>>4)
#define mChkNotBootISP                           (gSysOpFlag&0xF0)

#define mSetISPC1Mode(x)                         gSysOpC1Flag=(gSysOpC1Flag&0x0F)|(x<<4)
#define mChkISPC1Mode                            (gSysOpC1Flag>>4)

// extern BYTE gSysOption;
#define mClrSysBlkInFL\
    do\
    {\
        gSysOption=0x00;\
        gSysOption1=0x00;\
    }\
    while(0)

#define mChkIspBlkInFL                                  (gSysOption1&cBit0)
#define mSetIspBlkInFL                                  (gSysOption1|=cBit0)
#define mClrIspBlkInFL                                  (gSysOption1&=~cBit0)

#define mChk1stInfoInFL                          (gSysOption&cBit0)
#define mSet1stInfoInFL                          (gSysOption|=cBit0)
#define mClr1stInfoInFL                          (gSysOption&=~cBit0)
#define mChk2ndInfoInFL                          (gSysOption&cBit1)
#define mSet2ndInfoInFL                          (gSysOption|=cBit1)
#define mClr2ndInfoInFL                          (gSysOption&=~cBit1)
#define mChkAllInfoInFL                          ((gSysOption&(cBit1|cBit0))==(cBit1|cBit0))
#define mChkMPInfoInFL                           (gSysOption&cBit2)
#define mSetMPInfoInFL                           (gSysOption|=cBit2)
#define mClrMPInfoInFL                           (gSysOption&=~cBit2)
#define mChkIndexbInFL                           (gSysOption&cBit3)
#define mSetIndexbInFL                           (gSysOption|=cBit3)
#define mClrIndexbInFL                           (gSysOption&=~cBit3)
#define mChkLogInfoInFL                          (gSysOption&cBit4)
#define mSetLogInfoInFL                          (gSysOption|=cBit4)
#define mClrLogInfoInFL                          (gSysOption&=~cBit4)
#define mChkMPInfoInjured                        (gSysOption&cBit5)
#define mSetMPInfoInjured                        (gSysOption|=cBit5)
#define mClrMPInfoInjured                        (gSysOption&=~cBit5)
#define mChk1stInfoInjured                       (gSysOption&cBit6)
#define mSet1stInfoInjured                       (gSysOption|=cBit6)
#define mClr1stInfoInjured                       (gSysOption&=~cBit6)
#define mChk2ndInfoInjured                       (gSysOption&cBit7)
#define mSet2ndInfoInjured                       (gSysOption|=cBit7)
#define mClr2ndInfoInjured                       (gSysOption&=~cBit7)
#define mChkInjuredInfo                          (gSysOption&(cBit6|cBit7))
#define mChkInjuredAllInfo                       ((gSysOption&(cBit6|cBit7))==(cBit6|cBit7))
#define mChkSelInfoInFL(x)                       (gSysOption&(cbBitTab[x]))
#define mSetSelInfoInFL(x)                       (gSysOption|=(cbBitTab[x]))
#define mClrSelInfoInFL(x)                       (gSysOption&=~(cbBitTab[x]))

// #define mChkProgInFL                           (gSysOption&(cBit0/*|cBit1*/))
// <<< merge 58xt IM3D

#define mSetCrlcActive                           gbsCrlcBit|=cBit0
#define mClrCrlcActive                           gbsCrlcBit&=~cBit0
#define mChkCrlcActive                           gbsCrlcBit&cBit0

#define mSetCacheEnable                          gbsNvmeOpt1|=cBit0
#define mClrCacheEnable                          gbsNvmeOpt1&=~cBit0
#define mChkCacheEnable                          gbsNvmeOpt1&cBit0

#define cIntlvMo                                 cBit1
#define cMultiDie                                cBit2
#define cL06bToB0kb                              cBit3
#define cWithSlcMo                               cBit4
#define cSndkParamChg                            cBit6    // obs
#define cSndkDynamicRd                           cBit7
#define mChkCardMode(x)                          (gCardMode&x)
#define mSetCardMode(x)                          (gCardMode|=x)
#define mClrCardMode(x)                          (gCardMode&=~x)

#define cEnMPlaneRead                            cBit0
#define cEnMPlaneProg                            cBit1
#define cBpcOpCoCmd                              cBit2
#define cEnCacheRead                             cBit3
#define cEnCacheProg                             cBit4
#define cONFIMo                                  cBit5
#define cEnReadScrub                             cBit6
#define cEnSnapRead                              cBit7
#define mChkFLOption(x)                          (gFLOption&x)
#define mSetFLOption(x)                          (gFLOption|=x)
#define mClrFLOption(x)                          (gFLOption&=~x)

#define cMlc                                     cBit0    // obs
#define cTlc                                     cBit1
#define cFLSyncMo                                cBit2
#define cManToTogMo                              cBit3
#define cWithRlibMo                              cBit4
#define cMPlaneMo                                cBit5
#define cWithPrimaryCmd                          cBit6
#define cLsbPlanebit                             cBit7
#define mChkFLParam(x)                           (gFLParam&x)
#define mSetFLParam(x)                           (gFLParam|=x)

// extern BITS gbsTmpFlag;
#define gbTmpFlagRsv0                            gbsTmpFlag.BIT00
#define gbQeTmrF                                 gbsTmpFlag.BIT01
#define gbUpdIdxF                                gbsTmpFlag.BIT02
#define gbUpdBadInfoF                            gbsTmpFlag.BIT03
#define gbAutoRtnSts                             gbsTmpFlag.BIT04
#define gbManulDisSprOnes                        gbsTmpFlag.BIT05
#define gbReclaimF                               gbsTmpFlag.BIT06
#define gbPwrFailF                               gbsTmpFlag.BIT07

// extern BITS gbsFLSts;
#define gbEccFail                                gbsFLSts.BIT00
#define gbSprEccFail                             gbsFLSts.BIT01
#define gbDataEccFail                            gbsFLSts.BIT02
#define gbRlibMoOn                               gbsFLSts.BIT03
#define gbEnDiffAddr                             gbsFLSts.BIT04
#define gbEraseFail                              gbsFLSts.BIT05
#define gbCorrStopF                              gbsFLSts.BIT06
#define gbOnesCntFail                            gbsFLSts.BIT07

// extern BYTE gSysOpFlag;
#define mChkDummyRead                            (gSysOpFlag&cBit0)
#define mSetDummyRead                            (gSysOpFlag|=cBit0)
#define mClrDummyRead                            (gSysOpFlag&=~cBit0)
#define mChkDummyWrite                           (gSysOpFlag&cBit1)
#define mSetDummyWrite                           (gSysOpFlag|=cBit1)
#define mClrDummyWrite                           (gSysOpFlag&=~cBit1)
#define mChkDummyReadWrite                       (gSysOpFlag&(cBit0|cBit1))
#define mSetDummyReadWrite                       (gSysOpFlag|=(cBit0|cBit1))
#define mClrDummyReadWrite                       (gSysOpFlag&=~(cBit0|cBit1))
#define mChkunSaveDummyInfo                      (gSysOpFlag&cBit2)
#define mSetSaveDummyInfo                        (gSysOpFlag|=cBit2)
#define mClrSaveDummyInfo                        (gSysOpFlag&=~cBit2)

// #define mChkInSataErr                            (gSysOpFlag&cBit2)
// #define mSetInSataErr                            (gSysOpFlag|=cBit2)
// #define mClrInSataErr                            (gSysOpFlag&=~cBit2)
// #define mChkInGcFlow                             (gSysOpFlag&cBit3)
// #define mSetInGcFlow                             (gSysOpFlag|=cBit3)
// #define mClrInGcFlow                             (gSysOpFlag&=~cBit3)
// #define mChkInSataErrOrGc                        (gSysOpFlag&(cBit2|cBit3))

// #define mSetReadHdmaF                            gReadFlag|=cBit1    // mSetBitMask(gReadFlag, 1)
// #define mChkReadHdmaF                            (gReadFlag&cBit1)    // mChkBitMask(gReadFlag, 1)
// #define mClrReadHdmaF                            gReadFlag&=~cBit1    // mClrBitMask(gReadFlag, 1)
#define mSetReadAhead                            gReadFlag|=cBit3    // mSetBitMask(gReadFlag, 3)
#define mChkReadAhead                            (gReadFlag&cBit3)    // mChkBitMask(gReadFlag, 3)
#define mClrReadAhead                            gReadFlag&=~cBit3    // mClrBitMask(gReadFlag, 3)
// #define mSetStopContiR                           gReadFlag|=cBit4    // mSetBitMask(gReadFlag, 4)
// #define mChkStopContiR                           (gReadFlag&cBit4)    // mChkBitMask(gReadFlag, 4)
// #define mClrStopContiR                           gReadFlag&=~cBit4    // mClrBitMask(gReadFlag, 4)
// #define mSetReadProcessF                          gReadFlag|=cBit5    // mSetBitMask(gReadFlag, 5)
// #define mChkReadProcessF                          (gReadFlag&cBit5)    // mChkBitMask(gReadFlag, 5)
// #define mClrReadProcessF                          gReadFlag&=~cBit5    // mClrBitMask(gReadFlag, 5)
#define mSetContHAddrR                           gReadFlag|=cBit6    // mSetBitMask(gReadFlag, 6)
#define mChkContHAddrR                           (gReadFlag&cBit6)    // mChkBitMask(gReadFlag, 6)
#define mClrContHAddrR                           gReadFlag&=~cBit6    // mClrBitMask(gReadFlag, 6)
// #define mSetUnlimitedR                           gReadFlag|=cBit7    // mSetBitMask(gReadFlag, 7)
// #define mChkUnlimitedR                           (gReadFlag&cBit7)    // mChkBitMask(gReadFlag, 7)
// #define mClrUnlimitedR                           gReadFlag&=~cBit7    // mClrBitMask(gReadFlag, 7)
// #define mSetAutoSrchReg                          gReadFlag|=cBit0
// #define mChkAutoSrchReg                          (gReadFlag&cBit0)

#define mSetRandom4kWrF                          gFtlChgFlag|=cBit0
#define mChkRandom4kWrF                          (gFtlChgFlag&cBit0)
#define mClrRandom4kWrF                          gFtlChgFlag&=~cBit0
#define mSetLastRandom4kWr                       gFtlChgFlag|=cBit1
#define mChkLastRandom4kWr                       (gFtlChgFlag&cBit1)
#define mClrLastRandom4kWr                       gFtlChgFlag&=~cBit1
#define mSetDDR400En                             gFtlChgFlag|=cBit2
#define mChkDDR400En                             (gFtlChgFlag&cBit2)
#define mClrDDR400En                             gFtlChgFlag&=~cBit2
#define mSetSeqAccess                            gFtlChgFlag|=cBit7
#define mChkSeqAccess                            (gFtlChgFlag&cBit7)
#define mClrSeqAccess                            gFtlChgFlag&=~cBit7

#define mSetChgBlock                             gWriteFlag|=cBit0
#define mChkChgBlock                             (gWriteFlag&cBit0)
#define mClrChgBlock                             gWriteFlag&=~cBit0
#define mSetCacheInBufW                          gWriteFlag|=cBit1
#define mChkCacheInBufW                          (gWriteFlag&cBit1)
#define mClrCacheInBufW                          gWriteFlag&=~cBit1
#define mSetCalWriteSctr2ChgBlk                  gWriteFlag|=cBit3
#define mChkCalWriteSctr2ChgBlk                  (gWriteFlag&cBit3)
#define mClrCalWriteSctr2ChgBlk                  gWriteFlag&=~cBit3
#define mSetNewDesF                              gWriteFlag|=cBit4
#define mChkNewDesF                              (gWriteFlag&cBit4)
#define mClrNewDesF                              gWriteFlag&=~cBit4
#define mSetTermWFua                             gWriteFlag|=cBit5
#define mChkTermWFua                             (gWriteFlag&cBit5)
#define mClrTermWFua                             gWriteFlag&=~cBit5
#define mSetQueueFuaCmd                          gWriteFlag|=cBit6
#define mChkQueueFuaCmd                          (gWriteFlag&cBit6)
#define mClrQueueFuaCmd                          gWriteFlag&=~cBit6

#define mSetNvmeEnPlpScp                         gHandlePlpScpFlow|=cBit0
#define mChkNvmeEnPlpScp                         (gHandlePlpScpFlow&cBit0)
#define mClrNvmeEnPlpScp                         gHandlePlpScpFlow&=~cBit0
#define mSetGpioInitPlpScp                       gHandlePlpScpFlow|=cBit1
#define mChkGpioInitPlpScp                       (gHandlePlpScpFlow&cBit1)
#define mClrGpioInitPlpScp                       gHandlePlpScpFlow&=~cBit1
#define mChkInitPlpScp                          ((gHandlePlpScpFlow&(cBit0|cBit1))==(cBit0|cBit1))
// 20190218_Jesse_01, Add for Dell spec "ENG0013785_A01", DITM saveable doesn't keep after Power-off.
#define mNvmeSetPowerOn                          (gHandlePlpScpFlow|=cBit2)    // Power On Flag
#define mNvmeChkPowerOn                          (gHandlePlpScpFlow&cBit2)    // Power On Flag
#define mNvmeClrPowerOn                          (gHandlePlpScpFlow&=~cBit2)    // Power On Flag







