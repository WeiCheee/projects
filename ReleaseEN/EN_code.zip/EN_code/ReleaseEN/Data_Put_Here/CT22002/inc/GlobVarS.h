







#ifndef __GLOBVARS_H__
#define __GLOBVARS_H__

// #include "inc/nvmectrl.h"

// #pragma default_variable_attributes = @ ".ROM_VAR"
// parameter page
// para-0x00
extern BYTE garParaPageId[10];
extern BYTE gFlashVendor;
extern BYTE gCardMode;    // BITS gbsCardMode;
extern BYTE gFLParam;    // BITS gbsFLParam;
extern BYTE gFLOption;    // BITS gbsFLOption;
extern WORD g16PadCnt;
// 0x010
extern BYTE gChMap;
extern BYTE gCeMap;
extern BYTE gIntlvWay;
extern BYTE gPlaneNum;
extern BYTE gTotalChNum;
extern BYTE gTotalCeNum;
extern BYTE gTotalIntlvChNum;
extern BYTE gTotalDiePerCe;
extern BYTE gDataECCLevel;
extern BYTE gSprECCLevel;
extern BYTE gPageNumReg;
extern BYTE gBlockNumReg;
extern BYTE gPlaneNumReg;
extern BYTE gRsv1_D;
extern BYTE gTotalIntlvChPlaneNum;
extern BYTE gTotalChPlaneNum;
// 0x020:
extern BYTE garSysBlock[cRsvSysBlkNum];

extern WORD g16MinStaticTlcCnt;

// BYTE garParaTabRsv2[0];
// 0x030
extern WORD g16FirstFBlock;
extern WORD g16TotalFBlock;
extern WORD g16TotalHBlock;
extern WORD g16FBlockPerCe;
extern WORD g16FBlockPerDie;
extern WORD g16OrgSpareBlockCnt;
extern WORD g16OrgBadBlockCnt;
extern WORD g16LaterBadBlockCnt;
// BYTE garParaTabRsv3[0];
// 0x040
extern BYTE gSectorPerPageF;
extern BYTE gSectorPerPageH;
extern BYTE gSectorPerPlaneF;
extern BYTE gSectorPerPlaneH;
extern BYTE gDiffType3Num;
extern BYTE gISPCore1StartPage;
extern WORD g16PagePerBlock1;    // the number of page in one plane
extern WORD g16PagePerBlock1_SLC;    // the number of page in one SLC super block
extern WORD g16PagePerBlock3_SLC;
extern LWORD g32SectorPerBlockH;
// 0x050
extern BYTE garFLCmdSetTab[16];
// BYTE garParaTabRsv5[0];
// 0x060
extern LWORD g32TotalDatSector;
extern BYTE garDllAdj[5];
extern BYTE gRtcSel;
extern BYTE gIntlvPlaneNum;
extern BYTE gDiffBitMapOfst;
extern WORD g16RTCTrim;
extern WORD g16Rsv6_E;

// 0x70
extern BYTE gBlockStatusStartPage;
extern BYTE gEraseBlockStatusStartPage;
extern BYTE gBadCntTableStartPage;
extern BYTE gTotalBlockStatusStartPage;
extern BYTE gBadBlockBitMapStartPage;
extern BYTE gTotalDiffAddrTableStartPage;
extern BYTE gISPBlockStartPage;
extern BYTE gMinStaticSlcCnt;    // 0x77   // PDTool set this number as 40
extern BYTE gRetryTableStartPage;
extern BYTE gDiffType2Num;
extern BYTE gFormFactor;
extern BYTE gSeedTableStartPage;
extern WORD g16TlcValidPgPerF2hTab;
extern WORD g16FlashClock;

// 0x080
extern WORD g16ValidPgPerF2hTab;
extern WORD g16PagePerH2fTab;
extern WORD g16TotalPgPerF2hTab;
extern WORD g16MaxCachePageNum;
extern WORD g16TotalTlcPgPerF2hTab;    // g16MaxCacheBlkNum;//obs
extern BYTE gTotalPlaneOfH2fTab;
extern BYTE gTotal4kNumOfF2hTab;
extern BYTE gTotalPlaneOfCacheInfoTab;
extern BYTE gTotalBankOfF2hTab;
extern BYTE g4kNumPerPlane;
extern BYTE g4kNumPerPage;
// 0x090~0x0AF
extern BYTE gPlaneSizeBitCnt;
extern BYTE gPlaneBitCnt;
extern BYTE gChBitCnt;
extern BYTE gDieBitCnt;
extern BYTE gCeBitCnt;
extern BYTE gPlaneAddrBitShiftCnt;
extern BYTE gChAddrBitShiftCnt;
extern BYTE gCeAddrBitShiftCnt;
extern BYTE gDieAddrBitShiftCnt2;
extern BYTE gPhyPageAddrBitShiftCnt;
extern WORD g16BlockBitMask;
extern WORD g16DiffOffsetNum;
extern BYTE gBlockBitCnt;
extern BYTE gTlcTotal4kNumOfF2hTab;
extern BYTE gTlcLgPgDieAddrBitShiftCnt2;
extern BYTE gTlcLgPgCeAddrBitShiftCnt;
extern BYTE gTlcLgPgPhyPageAddrBitShiftCnt;
extern BYTE gTlcLgPgShiftCnt;
extern BYTE gRsvA[12];

// 0x0B0
extern LWORD g32VpcPerTlcBlk;
extern WORD g16MaxDualMoPeThr;    // g16PagePerBlock2_SLC;
extern WORD g16TlcFullCachebGcThr;    // g16LastSLCBlock;
extern LWORD g32VpcPerSlcBlk;
extern BYTE gTotalTlcBankOfF2hTab;    // gLogiPlaneNum;
extern BYTE gPhyDiePerPackage;
extern BYTE gOPRomStrPage;
extern BYTE gRDTStrPage;
// 0x0C0
extern LWORD g32PagePerBlock2;
extern LWORD g32PagePerBlock2By4k;
extern LWORD g32PagePerBlock2_SLCBy4k;
extern BYTE garParaTabRsvC[4];
// 0x0D0
// 0x0D0
extern BYTE gSecurityOption;
extern BYTE gChgNANDClock;
extern BYTE gRsvD[13];
extern BYTE gTcgReservedSecShiftCnt;

// 0x0E0
extern BYTE gCh0FshODTAndDrv;
extern BYTE gCh0CtrlIODrv;
extern BYTE gCh0DataDQSDrv;
extern BYTE gCh0SchmtWindAndODT;
extern BYTE gCh1FshODTAndDrv;
extern BYTE gCh1CtrlIODrv;
extern BYTE gCh1DataDQSDrv;
extern BYTE gCh1SchmtWindAndODT;
extern BYTE gCh2FshODTAndDrv;
extern BYTE gCh2CtrlIODrv;
extern BYTE gCh2DataDQSDrv;
extern BYTE gCh2SchmtWindAndODT;
extern BYTE gCh3FshODTAndDrv;
extern BYTE gCh3CtrlIODrv;
extern BYTE gCh3DataDQSDrv;
extern BYTE gCh3SchmtWindAndODT;
// 0x0F0
extern BYTE gFlashId[8];
extern BYTE gCeDieMap[8];

// 0x0F0

extern WPROINFO gsWproInfo;
extern WORD g16arCurrSysBlkEsCnt[cRsvSysBlkNum];
extern LWORD g32IndexBlkSerial;
extern WORD g16IdxBlkFreePagePtr;
extern BYTE gSysOption;
extern BYTE gSysOption1;
extern LWORD g32Ps3EnPwrDomain1;
extern LWORD g32CurMaxNandTemp;
extern LWORD g32PwrOnMaxNandTemp;
extern LWORD g32AvgNandTemp;
extern WORD g16LogBlkFreePagePtr;
extern BYTE gSecurityStatus;
#if _EN_CDMTRIG
extern BYTE gCDMStatus;
extern LWORD g32CDMTimer;
#endif
#if _EN_Lenovo_RecoveryChk    // Bruce_20190524 for Lenovo Performance Recovery Check Test
extern IomInfo gsIomInfo_RecoveryCheck;
#endif

#if _EN_EarlyBdGC
extern LWORD g32EarGCTimer;
extern LWORD g32EarIOcnt;
extern BYTE gEarGCflag;

#endif
#if _EN_DisHMBInReset    // 20190424_Chief_DisHMB
extern BYTE gDisHMBCnt_NormalBehavior;
extern BYTE gDisHMBCnt_AbnormalBehavior;
extern BYTE gChkFlag;
extern LWORD g32DisHMBTimer;
#endif
#if _EN_SKIPGC10MIN
extern LWORD g32BgdGCSkip10min;
#endif

/********Managers*********/
#if 1
// extern volatile BYTE *regFCTRL;
// extern volatile WORD *reg16FCTRL;
// extern volatile LWORD *reg32FCTRL;

// extern volatile BYTE *regLDPC;
// extern volatile WORD *reg16LDPC;
// extern volatile LWORD *reg32LDPC;

extern volatile BYTE(*regLdpcDsp)[0x20000];
extern volatile WORD(*reg16LdpcDsp)[0x10000];
extern volatile LWORD(*reg32LdpcDsp)[0x8000];

extern volatile BYTE(*regFSHA)[0x10000];
extern volatile WORD(*reg16FSHA)[0x8000];
extern volatile LWORD(*reg32FSHA)[0x4000];

// ----------------------------------------parameter pag
extern volatile BYTE gSysOpFlag;
extern BITS gbsTmpFlag;
extern BITS gbsFLSts;
// extern BYTE gReadFlag;
extern BYTE gWriteFlag;
extern BYTE gFtlChgFlag;
extern LWORD g32EccCorrCnt;
extern LWORD g32EccErrCnt;
extern WORD g16TempPage;
extern BYTE gIntlvShiftCnt;
extern BYTE gTempRest;
extern BYTE garChMapTable[cMaxPhyChNum];
extern BYTE garCeMapTable[cCePin];

// ================== remove when para tab done =====================================
#if 0
extern BYTE gPlaneSizeBitCnt;    // g4kNumPerPlane shift bit count
extern BYTE gPlaneBitCnt;
extern BYTE gChBitCnt;
extern BYTE gDieBitCnt;
extern BYTE gCeBitCnt;

extern BYTE gPlaneAddrBitShiftCnt;
extern BYTE gChAddrBitShiftCnt;
// extern BYTE gDieAddrBitShiftCnt;     // already declare above
extern BYTE gCeAddrBitShiftCnt;
extern BYTE gPhyPageAddrBitShiftCnt;
#endif
// ================== remove when para tab done =====================================
// -------------------------------- flash character    //(JL), don't add new vairable in this range
extern WORD g16PagePerChannel;
extern WORD g16RwBufIdx;
extern BYTE gSectorPerPageH2n;
extern BYTE gIntlvOddA;
extern BYTE gActiveCh;
extern BYTE gWithInfoBlk;
// --- (ab) add for extened block ---//
extern BYTE gNewTech;    // =NewSamsung or NewHynix
extern WORD g16FBlockCombinUnit;
extern BYTE gChipAddrShitCnt;
// -------------------------------- initial device
extern LWORD g32HostXfrCnt;
extern LWORD g32FlashXfrCnt;

extern BYTE garTestArg[32];
extern BYTE gFlashErrorCode;
extern BYTE gPretestErrorCode;
extern BYTE gSecurityErrorCode;
extern BYTE gVendorCmdErrCode;

// ---------------------------------- flash parameter
extern BYTE gNowFCeNum;
extern BYTE gSectorF;
extern BYTE gCMDID;
extern BYTE gSMICMDPTR;
extern BYTE garCeFlashMap[cCePin];
extern BYTE gUseOrphan;
extern BYTE gUseSysOrphan;
extern LWORD g32arFlashStatus[cMaxIntlvWayROM];

extern BYTE gXfrDir;
extern WORD g16arTotalFBlockBeforeCe[cCePin];

// ///////////////////////////////////////////////////////////////////
extern volatile LWORD g32NvmeCondition;
extern volatile LWORD g32PcieRstOrErrEvent;
extern volatile LWORD g32IntISR;
extern volatile BYTE gModeFPDMA;
extern volatile BYTE gSataErr;
extern BYTE garFLCmdSetTab2[16];
extern LWORD g32arGcSrcBlkBitMap[c16MaxBlockNum/32];
extern ADDRINFO gsFlashAddrInfoTemp;
extern ADDRINFO gpVendorAddrInfo;
extern ADDRINFO garSrcAddrInfo[cReadFifoDpt];
extern ADDRINFO garDesAddrInfo[cWriteFifoDpt];
extern F2HINFO garDesF2hInfo[cWriteFifoDpt];
extern LWORD g32QueAddrNow;
extern LWORD g32QueAddrLast;
extern LWORD g32AuxQueAddr;
extern WORD g16MaxEccBit;
extern WORD g16MaxEccPage;
extern LWORD g32PageNumForEccOverTh;
extern BYTE gVenderOfNand;
extern BYTE gUncFifoPtr;

// ----------------------------------------- system parameter
extern LWORD g32SectorsPerBlock;
extern WORD g16FBlockPerChip;
extern WORD g16arROMInfoBlockAddr[];
extern volatile LWORD g32arFwPreOccuFlag[(c16WriteBufSize/cSctrPer4k)/32];

// Retry variable
extern BYTE gWithRetryTable;
extern BYTE gRetryType;
extern BYTE gRegisterCnt;
extern BYTE gSLC_RegisterCnt;
extern BYTE gRetryTimes;
extern BYTE gSLC_RetryTimes;    // for SLC mode block(ex. TSB A2 command)
extern BYTE gLowerRetryTimes;
extern BYTE gUpperRetryTimes;
extern BYTE gRetryEraseTimes;
extern BYTE gRetryIteration;

// ROM code add
extern WORD g16BootISPStartBlock;
extern WORD g16BootISPEndBlock;
extern BYTE gFlashEccFailStatus;
// extern WORD garRwBufIdx[C_MaxChNum];
extern LWORD g32ROMCodeFlowBit;

// for security use
extern BYTE gSecuDerivedKey[32];
extern BYTE gSuperLightSwitch;
extern BYTE gDebugLocked;

extern BYTE gMaxErrCnt;
// extern BYTE gTotalCeNum;
extern BYTE gTotalBank;
extern BYTE gIntIntlvMask;
extern BYTE gIntIntlv2n;
// extern BYTE gDataECCLevel;
// extern BYTE gSprECCLevel;
// extern BYTE gPlaneNum;
extern BYTE garLinkId[20];
extern BYTE gMLC2SLCCmdROM;    // for shuttle ROM code compatible
extern BITS gbsFlashStatus;
extern BITS gbsFlashOperation;
extern BITS gbsVendorRWOption;

// -------------------------- bit mask operation, define in Struct.h
extern BYTE gIBITREG1;
extern BYTE gIBITREG2;
extern BYTE gIBITREG3;
extern BYTE gIBITREG4;
extern BYTE gOPT02;
extern BYTE gOPT07;
extern BYTE gCardMode;
extern BYTE gDegArray[32];

extern BYTE gFeatureCmd;
extern LWORD isrServiceCnt;

// for SLC SortQ
extern WORD g16SlcSortQCnt;    // 20181223_Bruce

// for timer
extern LWORD g32Timer0Limit;
extern LWORD g32PowerOnHour;
extern LWORD g32Timer0TickCnt;
extern BYTE gThsor0TemperatureBk;
extern LWORD g32RWTickCnt;
extern LWORD g32Rtc32kStartVal;
// extern LWORD g32Rtc32kEndVal;
extern LWORD g32Cpu1TOFlag;
extern LWORD g32SysTmrOn;
extern LWORD gNvmeNumberOfQueuesReqROM;
extern LWORD gNvmeArbitrationROM;
extern LWORD gNvmeIntCoalescingROM;
#endif    // if 1

// extern HWPRDCTRL gsHwPrd;
extern PRDINFO gsPrdInfo;
// extern READHADDRQ gsRdHaddrMgr;
extern volatile RWCTRL gsRwCtrl;
extern CACHEINFO gsCacheInfo;
extern RDLINKINFO gsRdlinkInfo;
extern QBOOTINFO gsQBootInfo;
extern BADINFO gsBadInfo;
extern GCINFO gsGcInfo;
extern FWDLINFO gsFwDlInfo;
extern volatile TASKFIFOCTRL gsTskFifoCtrl;
// extern volatile ISRCTRL gsIsrCtrl;
extern volatile MUTEXINFO gsMutexInfo;
extern volatile MUTEXINFO gsOccuMutexInfo;
// extern volatile BOOTMUTEXINFO gsBtMutexInfo;

extern UCBYTE *FlashDataBasePtr;
extern WORD g16ReadBufPtr;
extern WORD g16PHYErrAddr;
extern BYTE gPHYErrExpVal;
extern BYTE gPHYErrData;

// extern ERRORINFO garErrorLog[cMaxErrLogEntryCnt];

// extern VENDORCMDDEBUGINFO gsVendorCmdDebugInfo;

// >>> merge 58xt IM3D
extern BYTE garCmdFifoDpt[3];
extern BYTE gReadLinkRetrySlcVth[cMaxChNum][cMaxPlaneNum];
// <<<

extern volatile BYTE garH2fSgmtRdyQ[cH2fSgmtRdyDept];
extern volatile BYTE gH2fSgmtRdyHead;
extern volatile BYTE gH2fSgmtRdyTail;
extern volatile BYTE gH2fSgmtRdyCnt;
extern volatile BYTE gH2f1KPrepCnt;
extern volatile QWORD g64H2f1kTabSgmtPrep;

extern LWORD g32H2fTabFullSize;
extern LWORD g32H2fTabValidSize;
extern WORD g16H2fTabSize;
extern WORD g16H2fTabSctrSize;
extern WORD g16H2fTabValidSctrSize;
extern WORD g16WproSwapSBuf;
extern WORD g16HmbMaxTableNum;
extern BYTE gGCH2fTabShiftSize;
extern BYTE gPage4kPerH2fTab;
extern BYTE gHmbH2FTableShift;

extern WORD g16SlcF2hPadStartAddr_1;
extern WORD g16SlcF2hPadStartAddr_2;
extern WORD g16TlcF2hPadStartAddr_1;
extern WORD g16TlcF2hPadStartAddr_2;
extern BYTE gSlcSecNumPadF2h_1;
extern BYTE gSlcSecNumPadF2h_2;
extern BYTE gTlcSecNumPadF2h_1;
extern BYTE gTlcSecNumPadF2h_2;
extern BYTE gSpareCnt[cMaxChNum];
extern BYTE gWaitSpareTyp[cMaxChNum];
extern BYTE gSparePtrHead[cMaxChNum];
extern BYTE gSparePtrTail[cMaxChNum];
extern BYTE gSpareDesIdx[cMaxChNum][cSpareRegisterCnt];

// RAID related
extern WORD g16RaidStrAddr[cRaidParityNum];
extern WORD g16SlcRaidStrAddr[cRaidParityNum];
extern WORD g16TlcPartialParityNum;
extern WORD g16SlcPartialParityNum;
extern BYTE gSlcPadF2h4KNum;
extern BYTE gTlcPadF2h4KNum;
extern BYTE gSlcSecNumDummyF2h;
extern BYTE gTlcSecNumDummyF2h;
extern BYTE gMaxH2fTabBlkNum;
extern volatile LWORD g32DecodeWait;
extern volatile LWORD g32ParityOut;

extern volatile LWORD g32Core1State;
extern volatile LWORD g32NandTempSensor;

extern WORD g16SaveEventLog;
extern WORD g16Core1SaveEventLog;
extern WORD g16SaveEventLog2;
extern WORD g16Core1SaveEventLog2;
extern WORD g16EventLogPtr;
extern WORD g16Core1EventLogPtr;
extern WORD g16EventLogPtrBK;
extern WORD g16Core1EventLogPtrBK;
extern WORD g16LinkLogPtr;
extern WORD g16LinkLogPtrBK;
extern volatile WORD g16arLinkLog[cLinkLogSize];
// extern BYTE gEventLogPageWproPtr;
extern CMDSTRUCT garCmdHistory[cCmdHistorySize];
extern NVMEPRDSTRUCT garCmdValidHistory[cCmdHistorySize];
extern LWORD g32CmdHistoryPtr;
extern LWORD g32EndCmdHistoryPtr;

extern LWORD g32RxTrigStartmsTime;
extern LWORD g32OutputUART;    // g32OutputUart for security crypto library.
extern BYTE gHandlePlpScpFlow;
extern LWORD g32arPlpScpTimeStamp;
// Vu command
extern BYTE gVuMode;
extern BYTE gTlcMode;

#if (_INITDRAM||_GREYBOX)
extern BYTE gGreyBoxBootSta;
#endif

// Flash/Ftl
extern LWORD g32DieAddrBitMask;
extern LWORD g32CeAddrBitMask;
extern LWORD g32ChAddrBitMask;
extern LWORD g32PlaneAddrBitMask;
extern LWORD g32PhyPageAddrMask;
extern BYTE gPlaneUNCSts[cMaxChNum];
extern BYTE gPlaneCorrSts[cMaxChNum];
extern BYTE gPlaneOnesCntSts[cMaxChNum];
extern LWORD gTotalRetryTimes;

extern LWORD g32arRH2fTabDirty[cMaxRH2fTabNum/32];    // if set 1, mean the segment of 64kb RH2f is modified and not sync to HMB and NAND flash
extern LWORD g32arH2f1kTabSgmt[cMaxRH2fTabNum];    // 128b

// E2E for BOP/HDMA
extern LWORD g32E2eLba;

extern WORD g16FlashClkForThermal;

extern WORD g16OneFblockGlobEraseCnt;

extern LWORD g32HmbTotalH2FTableSize;
// extern LWORD g32HmbGcInfoStrAddr;

#if _EN_Dynamic_Fix_Boundary
extern WORD g16TLCGCSpareCnt_Ori;
extern WORD g16TLCGCSpareCnt_Run;
#endif

extern E2EINFO gsE2eInfo;

volatile extern BYTE(*garTsb0)[512];
volatile extern WORD(*g16arTsb0)[512/2];
volatile extern LWORD(*g32arTsb0)[512/4];
volatile extern QWORD(*g64arTsb0)[512/8];

volatile extern BYTE *garBadInfoBuf;
volatile extern WORD *g16arBadInfoBuf;
volatile extern LWORD *g32arBadInfoBuf;

volatile extern NVMEFEATVAR *gpNvmeFeatVar;
volatile extern GETLOGINFO *gpGetLog;

volatile extern BYTE *garIfSendBufPtr;
volatile extern BYTE *garIfRecvBufPtr;

extern LWORD g32TsbCodeCnt;

#if 1    // _ENABLE_SECAPI
/* Used in SecIntf_TCG_Write()*/
extern BYTE gSecurityWProMode;
#endif
extern WBITS gbsSecurity;
extern BITS gbsSecAPI;
extern volatile BYTE gInSecApi;
extern volatile BYTE gByPassSecApiLog;

extern BYTE gSecurityLockRWErr;
extern ERASEUNITINFO gsEraseUnitInfo;

extern volatile BYTE gWdtStatus;
extern BYTE gTelemetryCtlrInfo;
extern BYTE gTelemetryCtlrGenNum;

extern volatile BYTE gUartCMDStatus;
#if (_EN_CHRONUS_UART_DEBUG)
extern sChronusUartCMD *gpUartCMD;
extern LWORD *gp32UartCMDStartAddress;
extern LWORD g32UartCMDofst;
extern LWORD g32UartCMDDW;
extern LWORD g32UartRSPofst;
extern LWORD g32arUartHndShkCMD[4];
extern LWORD g32arUartCQEntryDW[4];
extern LWORD g32UartCMDSOFofst;
extern LWORD g32UartCMDEOFofst;
extern LWORD g32UartCMDWaitTime;
#endif

#if (_EN_WDT)
extern volatile BYTE gWdtTOExtensionCnt;
#endif

extern LWORD g32CmdPara0;
extern LWORD g32CmdPara1;
extern LWORD g32CmdPara2;
extern LWORD g32CmdPara3;

volatile extern BYTE gProgFifoPtr;
volatile extern HMBPTYINFO gsHmbPtyInfo;

extern BYTE gVuCmdSpFlag;    // bit0->VthCenter
extern BYTE garVuCmdVthCenter[cMaxRetryRegisterCnt];    // ACEGBDFS
extern LWORD g32RamAddrRetryTablePassIndex;
extern LWORD g32RamAddrLastPassVthCenter;
#if _EN_VPC_SWAP
extern volatile LWORD *g32arCacheBlkVpCnt;

extern WORD g16arGlobEraseCnt[c16MaxBlockNum];    // 2kb
extern LWORD g32VPCSwapFlag;
extern BYTE gFor512GbDebug;
#else
#if (_TSB_BiCS4)
extern LWORD g32arGlobReadCnt[c16MaxBlockNum];
#endif
#endif
extern LWORD g32PS4BootTimeStamp;

#if _EN_CDMTRIG
extern BYTE gCCTFlag;
extern LWORD g32CDM_WSctrCnt;
extern LWORD g32CDM_RSctrCnt;

extern LWORD g32CDM_SWCnt;
extern LWORD g32CDM_SRCnt;
extern LWORD g32CDM_WBrkCnt;
extern LWORD g32CDM_RBrkCnt;

#endif
#if _EN_PopBlk0
volatile extern BYTE gBlkEmergencyflag;
#endif

#if _EN_Liteon_ErrHandle
extern BYTE gJdgBootGCFlag;
#endif

#if _EN_VPC_SWAP
extern LWORD g32SLCAvgVpc;
extern WORD g16MaxSlcBlkQ;
#endif

#if _EN_IOMTRIG
extern IomInfo gsIomInfo;
extern IomInfo gsIomInfo1Thr;
#endif
extern BYTE gGCOpt;
#endif    // ifndef __GLOBVARS_H__







