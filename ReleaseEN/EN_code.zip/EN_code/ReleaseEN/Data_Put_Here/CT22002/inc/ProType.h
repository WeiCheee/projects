







#include "inc/Const.h"
#include "inc/TypeDef.h"
#include "inc/Option.h"
// #include "inc/NvmeCtrl.h"

// main.c
void chkBgdClnBlkProc();
void swapWproBlkCore0();
WORD popSpareBlockCore0(BYTE);
// void prepopBlkEraseCore0(BYTE);
LWORD prepopBlkChkStatusCore0(BYTE);
void pushSpareBlockCore0(WORD, BYTE);
void waitAllChCeBzCore0();
// void chkEraseStatusCore0();
void progWproPageCore0(BYTE, WORD);
void readWproPageCore0(BYTE, WORD, BYTE);
void loadBadCntTabCore0(WORD, BYTE);
void loadOrgBadTabCore0(WORD, BYTE);
void progH2fTableCore0(WORD, WORD, WORD, WORD, BYTE);
void waitProgH2fTxDataCore0();
void markBadBlockCore0();
void loadISPCodeCore0(BYTE, BYTE);
void buildValidCachePageCore0();
// void setRaidEncodeCore0(WORD, WORD, WORD, WORD, BYTE, BYTE);
// void getRaidParityCore0(WORD, WORD, BYTE, WORD, BYTE);
void progPartialRaidParityCore0(WORD, WORD, BYTE, BYTE);
void pushRaidPtyBlkCore0(BYTE);
void initRaidEngineCore0();
void rstRaidEngVarCore0(BYTE);
void forceInvCpu1DCache();
void saveQBInfowithDummyCore0(BYTE);
void saveQBInfo(BYTE);
void initCache();
void flushDCache();
void invalidateDCache();
void disableCache();
void disableBranchPredict();
void disableVe();
void invalidateInstCache();
BYTE beforeHandlingCmd();
void afterHandlingCmd(BYTE);
void setWriteDes(WORD, ADDRINFO *, BYTE);
void loadISPCode(BYTE, BYTE);
void setEraseBadBlock(WORD, LWORD);
void chkPushSpareQCore0(BYTE);
void chkPostWriteRead(BYTE);
void clrLastReadGrp();
BYTE chkBgdGCWakeup();
void chkPwrOnForceClnProc();
void chkPwrOnExtraClnProc();
void remWproPageCore0(BYTE);
void setGcInfoHmbLinkCore0(BYTE);
void saveRdTimeStamp(BYTE);
BYTE Check_EEPROM_Tag(WORD u16BufIdx);
void rstUNCStsCore0();
void Init_EEPROM();
void rstUNCSts1PlaneCore0(BYTE, BYTE);
void invPlaneBufFlagCore0(WORD, BYTE, BYTE);
void handleAsyncEvent();
void setSlcEndurParaCore0();
#if _EN_FLASH_WR_CMD
void flashWriteCmdCore0(WORD u16Fblk);
#else
#define flashWriteCmdCore0(...)
#endif
void insSlcSortQ(WORD);
void insSlcSortQCore0(WORD);
void getGcSrcBlk();
void getGcSrcBlkCore0();
void initSlcQCore0();
void restoreSlcQCore0(BYTE);
// void resetGCFlagCore0();
#if _EN_SLCOpenBlkReadScrub
void pushWLReadReclaimQCore0(WORD);
#endif
void initGcProcCore0();
void gcDesBlkFullSettingCore0();
void deleteGcSrcBlkCore0(BYTE);
void runTimeKeepSmartInfo();
void loadDiffTabCore0();
void saveWproBadInfoCore0();
#if _EN_CHK_FINGER_FAIL
BYTE chkFingerFailCore0();
#endif
void setEraseBadBlockCore0(WORD u16FBlock, LWORD u32EraseFail);
extern void dummyFunc();
extern BYTE dummyFunc1();
extern void dummyFunc2(BYTE);
extern void dummyFunc3(WORD, BYTE, BYTE);
// void loadIspCode();
// void progIspCode();
// void eraseIspCode();
void debugLoop(BYTE uFailType);
void debugWhile();
void debugDeadLock(WORD);
void setLock(volatile MUTEXINFO *);
void clrLock(volatile MUTEXINFO *);
BYTE compareByte(BYTE *, BYTE *, LWORD);
void resetAllFlashCore0();
void resetCore1Var();
void changeFlashClock();
void core1Sleep(BYTE);
void core1ResumePs3();
void core1SwapNvmeBank();
void core1SwapIspBank();

void rstAllFshInHdPCIeErr();
#if _ENABLE_RAID
void core1TskRstRaidPara();
#endif
void handleSecFlag();
void handleSecFlagSub();
WORD GetAvgECCore0(BYTE);
// isr0.c
BYTE chkUnderRwProc();
void tracePcieEvent(BYTE);
void debugTSBflagCpu0(BYTE uOpt);

#if (S_PCIE_DEBUG)
WORD Chk_DPHY_Error(BYTE);
WORD Chk_PHY_Error(BYTE);
void Set_PHY_Error(BYTE);
#endif

// BootFunc1.c BootFunc2.c
void bootFunc1();
void bootFunc2();
void setChMapTab();
void setCeMapTab();
void setBasicPoint();
void setFlashParam();
void getParamTab();
void initSram();
void initDramLowPower();
void initFtlVar();
void setSpareBlockCnt();
void initGlobOpt(BYTE);
void initBufWrap();
void rdlinkFunc();
void initNvmeFeatureAttribute();
void initNvmeFeatureSC();
void initNvmeFeatureDefaultAttribute(BYTE);
void initNvme();
void initPhy();
void initTimer(WORD);
void initThermal();
void initAes();
void initSmart();
void clrNvmeIntStatus();
LWORD tran2DecClk();
void initUart();
void initBusErrHandler();
void initGPIO();
void gpioIsrEnable(LWORD, BYTE);
void gpioIsrDisable(LWORD, BYTE);
void gpioHiActiveEnable(LWORD, BYTE);
void gpioHiActiveDisable(LWORD, BYTE);
void gpioLoActiveEnable(LWORD, BYTE);
void gpioLoActiveDisable(LWORD, BYTE);
void gpioSetEdgeMode(LWORD, BYTE);
void gpioSetLevelMode(LWORD, BYTE);
void enableCore1();
void initRootBlockVar();
void findSysRsvBlock();
void redefParaVal();
void doorBellPatch(void);
void initBop();
void judgeSwapIspCore0();
void initThermalVar();
void restoreNvmeFeatureForPS4();
void restoreDSTForPS4();
void initTsb0VarPointer();
void setOrgFlashCmd();
void initSecuritySwitches();
void relinkSaveQBDummy(BYTE);
void relinkSaveDummyQBAnalysis(WORD u16Para0, WORD u16Para1, WORD u16Para2, WORD u16Para3);
#if _EN_KEEP_RW_ON_ERROR
void relinkKeepRwonError(WORD u16Para0, WORD u16Para1, WORD u16Para2, WORD u16Para3);
#endif
void pushVPCtoRaidCore0(WORD);
void popVPCfromRaidCore0(WORD);
void InitEraseCntCore0();

// Bop.c
void bopClrRam(LWORD, LWORD, LWORD, WORD);
void bopClrRamForTsbCode(LWORD, LWORD, LWORD, WORD);
void bopCopyRam(LWORD, LWORD, LWORD, WORD);
WORD bopSrchRam(LWORD, LWORD, LWORD, WORD, WORD, WORD);
BYTE bopDmaComp(LWORD, LWORD, LWORD, WORD);

// StbLib.c
void fillCcmVal(BYTE *, LWORD, BYTE);
void sysDelay(LWORD);
LWORD mod(LWORD, LWORD);
LWORD div(LWORD, LWORD);
QWORD mod64(QWORD, QWORD);
QWORD div64(QWORD, QWORD);
WORD addWriteBufPtr(WORD, LWORD);
WORD addReadBufPtr(WORD, LWORD);
BYTE addPrdPtrBy1(BYTE);
WORD addHwPrdPtrBy1(WORD);
BYTE addWrFfPtrBy1(BYTE);
BYTE subWrFfPtrBy1(BYTE);
BYTE addRdFfPtrBy1(BYTE);
BYTE addChRdFfPtrBy1(BYTE);
BYTE addChPgFfPtrBy1(BYTE);
BYTE subPrdPtrBy1(BYTE);
LWORD addPtrBy1(LWORD, LWORD);
LWORD subPtrBy1(LWORD, LWORD);
WORD getReadBufPtr(WORD);
void resetRam(BYTE *, LWORD, BYTE);
void copyCcmVal(BYTE *, BYTE *, WORD);
void copySdram2Tsb(volatile UCBYTE *, BYTE *, LWORD);
void copyTsb2Sdram(UCBYTE *, volatile BYTE *, LWORD);

// void copyCcm2Tsb(UCBYTE *, BYTE *, WORD);
// void copyTsb2Ccm(BYTE *, UCBYTE *, WORD);
// void copyTsb2Tsb(UCBYTE *, UCBYTE *, WORD);
void copyReg2Tsb(BYTE *, volatile BYTE *, WORD);
void copyReg2Tsb32(volatile LWORD *, volatile LWORD *, WORD);
void copyTsb2Reg(volatile BYTE *, BYTE *, WORD);
void copyTsb2Reg32(volatile LWORD *, volatile LWORD *, WORD);
void setRegMask(LWORD *, LWORD, LWORD);
BYTE compareTsb2Tsb(UCBYTE *, BYTE *, LWORD);
// BYTE compareVal(BYTE *, BYTE, LWORD);
WORD calFreeRdBuf(WORD);
BYTE memoryCompareAddress(LWORD, LWORD, LWORD);
// void copyMem(void *, const void *, LWORD);
#if _ENABLE_CPU_CYCLE_COUNTER
__arm LWORD initCyclecounter();
__arm void resetCycleCounter();
__arm void enableDividerCycleCounter();
__arm LWORD getCycleCounter();
#endif

// RwCmd.c
void servRwCmdQue();
#if _EN_CDMTRIG
void InitCDM();
#endif
void clrRwTimeOutFlag(BYTE);
void termFuaWFlow();
void postRwTaskToPrdInfo();
void termFlashOperRw(BYTE);
void trigHostRw(WORD, LWORD, LWORD);
BYTE hostRequset();
void chkBgdClnBlkProc();
void handlePcieError();
void saveRaidAllParity();
void restoRaidAllParity();
void releaseHwHmbPrd(BYTE);
void chkOccAtRWService();
void termFlashRW();
#if _EN_SLCOpenBlkReadScrub
void flushOpenBlock();
#endif
LWORD GetReadGHP(LWORD);
BYTE chkHitRange(LWORD, LWORD, LWORD *, LWORD *);
void SecAPI_ChkHitRange(LWORD, LWORD, BYTE, BYTE);
// void rstHmbTable();

// NvmeCtrl.c
void initPcie();
void resetNvmeIp();
void initNvmeBufWrap();
void initNvmeIp();
void handleNvmeReset();
void handlePcieReset(BYTE);
void handleFlr();
void handleShn();
void handleNvmeCondition();
BYTE chkHostIdle(BYTE);
void manualCompletion(WORD, LWORD, BYTE, BYTE);
void trigCompletion(LWORD, LWORD, LWORD, LWORD, BYTE);
BYTE trigNonRWCmd(volatile WORD, volatile WORD, volatile BYTE, volatile BYTE, volatile BYTE);
void waitBufStatus(WORD, WORD, BYTE);
void setHwPrd(BYTE, LWORD, LWORD, LWORD, BYTE, BYTE);
void setDesc(BYTE, BYTE, LWORD, BYTE);
void setHwPrdRw(PRDQUEUE *);
void setHwDescRw(PRDQUEUE *, BYTE);
void waitHostDone();
BYTE checkIfPrpOverlap(LWORD, LWORD, LWORD, LWORD, LWORD);
BYTE checkIfNonDWordAligned(LWORD, LWORD);
BYTE validatePrp(BYTE);
void chkPcieErrorEvent();
void initNvmeGlobVar(BYTE);
void resetFwDlFlow(BYTE);
void rstFwDlInfo(BYTE);
void activateIspCore0();
void resetCpuFwCommit(BYTE);
void resetCpu(BYTE);
void remHmbLink(WORD);
void disableHmbFunc(BYTE);    // LeverYu_0813 SMI S0813A  SQ mismatch issue
void initPcieLtrMsg();
BYTE chkDstInProgress();
void remAllHmbLink();

// NvmeCmd.c
extern void(*const NvmeCmdGrp[]) ();
// void nvmeHandleDeletedCmd();
void nvmeDeleteSubQueueSwap();
void nvmeCreateSubQueueSwap();
void nvmeGetLogPageSwap();
void nvmeInvalidCmd();
void nvmeDeleteCmplQueueSwap();
void nvmeCreateCmplQueueSwap();
// void SetupVUID(LWORD u32IDTableStartAddr);
void nvmeIdentifySwap();
void nvmeAbortSwap();
void nvmeSetFeatureSwap();
void nvmeGetFeatureSwap();
void nvmeAsynEventSwap();
void nvmeFwCommitSwap();
void nvmeFwImageDlSwap();
void nvmeFormatSwap();
void nvmeSecuritySendSwap();
void nvmeSecurityReceiveSwap();
void nvmeDstSwap();
void nvmeNamespaceManagementSwap();
void nvmeNamespaceAttachmentSwap();
void nvmeDirectiveSendSwap();
void nvmeDirectiveReceSwap();
void nvmeSanitizeSwap();
void nvmeVendorNonData();
void nvmeVendorDataOut();
void nvmeVendorDataIn();
// #if _HynixVuCmd
void nvmeVuCmdNonData();
void nvmeVuCmdDataOut();
void nvmeVuCmdDataIn();
// #endif
void nvmeLiteonVendorNonData();
void nvmeLiteonVendorDataOut();
void nvmeLiteonVendorDataIn();
void addCmdHistory();
void nvmeHandleAdmin();
// void NvmeCore0HandleAdmin();
void initNvmeDelFeature();
void initNvmeAbortFeature();
void nvmeAdminPM(BYTE);
void nvmeVendorNonDataSwap();
void nvmeVendorDataOutSwap();
void nvmeVendorDataInSwap();
void nvmeVuCmdNonDataSwap();
void nvmeVuCmdDataOutSwap();
void nvmeVuCmdDataInSwap();
void nvmeLiteonVendorNonDataSwap();
void nvmeLiteonVendorDataOutSwap();
void nvmeLiteonVendorDataInSwap();
void initTcgParameterSwap(BYTE);
void handleSpMethodSwap();
BYTE handleTcgTrustedSendSwap();
BYTE handleTcgTrustedReceiveSwap();
void updateNvmeFeatureSetting();
BYTE readSecurityWpro();
void chkAerSpareThreshold();
void chkAerTempThreshold(WORD);
void chkAerReliability();
void chkAerReadOnly();
void chkAerVolatileMemFail();
BYTE getDriveUsedPercentage();
void getGlobEraseCntOfSpecFblock(WORD);
void updateNvmeApstTable();
void saveSmartInfo(BYTE);
void resumeHmbSetting(BYTE);
void initTimestamp(LWORD, WORD, BYTE);
void updateTimestamp();
void saveNvmeFeatInfo(BYTE);
void updateInvalidDbErrLog();
BYTE pendingAsyncEvent();

// NvmeCmdExt.c
BYTE GetCapacityIndex();
void GetModelName(BYTE *);
void nvmeDeleteSubQueue();
void nvmeCreateSubQueue();
void nvmeDeleteCmplQueue();
void nvmeCreateCmplQueue();
void nvmeIdentify();
WORD handleFeatApst();
WORD handleFeatLbaRangeType(LWORD);
WORD handleFeatErrorRecovery(LWORD);
WORD handleFeatWriteAtomic(LWORD);
void nvmeSetFeature();
void nvmeGetFeature();
LWORD nvmeGetFeatureAttribute(NVMEFEATURESEL *, BYTE);
WORD nvmeSetFeatureAttribute(NVMEFEATURESEL *, LWORD, BYTE);
void nvmeFormat();
LWORD chkHctmValid(WORD, WORD);
void nvmeDst();
void handleDst();
void nvmeAsynEvent();
WORD setNvmeFeatApst();
BYTE getHmbDescList();
void handleAsyncEvent();
void nvmeNamespaceManagement();
void nvmeNamespaceAttachment();
void nvmeAbort();
void chkHmbEnbleFlag();
void nvmeDirectiveSend();
void nvmeDirectiveRece();

// VicCtrl.c
void initVic0(LWORD);
void initInt(BYTE, BYTE);
void initVic1(LWORD);

// SysCtrl.c
void setSysPllClock(WORD);
void setFlashClock(WORD);
void gpioClrIsr(LWORD, BYTE);
LWORD tran2DecClk();
// LWORD getRtcCurrent2s();
LWORD getRtcCurrent1s();
LWORD getRtcCurrent32k();
LWORD getRtcCurrentMsForTsbCode();
LWORD getRtcCurrentMs();
// LWORD getRtcDiff2s();
LWORD getRtcDiff1s();
LWORD getRtcDiffMs();
LWORD getRtcDiffWcTemp();
LWORD getRtcDiffCcTemp();
// void startRtcCounting2s();
void startRtcCounting1s();
void startRtcCountingMs();
void startRtcCountingWcTemp();
void startRtcCountingCcTemp();
#if (!_EN_NAND_TEMP)
void sleepRWTickTemp();
#else
#define sleepRWTickTemp(...)
#endif
BYTE getThermalSensorTemp();
extern void enSysTmr(WORD);
extern void enSysTmrMs(WORD);
extern void disSysTmr();
BYTE getCurrentNandTemp(BYTE, BYTE);
BYTE chkRtc32kTimeout(LWORD);
LWORD chkRtc32kProcTime(LWORD);

// PhyCtrl.c
WORD crRead(WORD);
void crWrite(WORD, WORD);
void wakeUpPhy(BYTE);
void chkPhyValue(BYTE, BYTE, LWORD);
void writeWiMask(WORD, BYTE, BYTE);
void chkWriteWiMask(WORD, BYTE, BYTE);
void aPhyReadBack(WORD, BYTE, BYTE);
void aPhyWrite(WORD, BYTE, BYTE);
void aPhyParameter(WORD, BYTE);
void aPhyGlobalParameter(BYTE);
void setDphyParameter(WORD, BYTE);
void setDphyGlobalParameter(BYTE);
void setDummyPHYAddr(BYTE);
// void chkDM(WORD, BYTE);
void checkPhyEQ();
// void initDphyPatch();
void setAPhyKP(BYTE);
void initAPhyLP();
BYTE chkDphyPatch();
void srvLtrSend(BYTE);
BYTE setExtSync(BYTE);
void gen3ConfigPatch();
void disableUnusedLanes();
BYTE chkEqPhase2PresetValueCnt();
#if (_EN_PCIE_DEBUG)
WORD chkDphyError(BYTE);
WORD chkPhyError(BYTE);
void setPhyError(BYTE);
#endif

// PowerState.c
void chkHostEnL1andL1sub();
BYTE chkEnClkReq();
void enablePcieL12();
BYTE disableL12();
void enableL12();
void waitPclkRdy();
void chkAllIdle();
void pllGatingCtrl(BYTE);
void pwrDomin1Ctrl(BYTE);
void sysClkPwrMoCtrl(BYTE);
void setClockGate(BYTE);
BYTE chkLinkStateIdle();
void intPwrMoCtrl(BYTE);
void cpuPwrMoCtrl(BYTE, BYTE);
void initVdt();
void disVdtDetect();
void setAipPwrOff();
void setIsoFlashIo();
void restorFlashIo();
void setIsoGpioPuPd();
void restorGpioPuPd();
BYTE chkIsrStateEnable(LWORD *);
BYTE chkHostEnAspm();
WORD chkWakeUpTimer(BYTE);
BYTE chkRxAckNum();
BYTE chkPcieEnterLowPwrMode(BYTE, BYTE, BYTE);
void disPcieLowPwrMo(BYTE);
void restorHwRegFromPs3();
void busyHostConfigIdleForL1();
void resumeFromPs3Mo();
BYTE tran2Ps3Mo();
void tran2Ps4MoAbort();
BYTE tran2Ps4Mo();
BYTE setSuspendMo(BYTE);
BYTE hdlHipmProc();
void resumeFromStandbyMo();
void hdlStandbyProc();
BYTE tran2ActiveMo(BYTE);
void tran2MemoryEccLowPwrMo();
void tran2MemoryEccActiveMo();
void cpuSpiLoaderRst();
BYTE chkNvmeAllIdle();
BYTE idleFunction(LWORD);
BYTE chkHostEnAspm();
void chgCurrentPowerState(BYTE);
BYTE chkThrottlingPowerState(BYTE);
void tran2ThermalThrottlingState();
void getOverTmpElapseTime(BYTE);
void chkOverTmpTime();
#if _ENABLE_SCP_PLP
void hdlPlpScpFlow(BYTE);
#endif    // #if _ENABLE_SCP_PLP

// isr.c
void errorHandler(BYTE);
void resumePS3();
void handleVDET(BYTE);

// FlashCMD.c
void setSprByteOfTabBlk(BYTE, WORD, WORD, WORD, LWORD, BYTE, WORD);
void setSprByteforTest(BYTE, WORD, WORD, WORD, WORD, BYTE, LWORD);
void writeFourData(BYTE, BYTE, BYTE, BYTE);
void setFeatureByChCe(BYTE, BYTE, BYTE, BYTE, BYTE, BYTE, BYTE, BYTE);
#if (_EN_WD_ResetCmd_Force_SDR)
void initForceSDRforResetCmd();
#endif
void resetFlashAtIntlv(BYTE, BYTE);
void resetFlash();
// void setFeatureByChCeDie(BYTE, BYTE, BYTE, BYTE, BYTE, BYTE, BYTE, BYTE, BYTE);
void setFlashFeature(BYTE, BYTE, BYTE, BYTE, BYTE, BYTE);
void initNandBusAndAleReg();
void initNandFlash();
void pollStatus(BYTE);
void setAutoWrite(BYTE, WORD);
void setAutoRead(BYTE, WORD);
void setAutoRead2(BYTE, WORD);
void setAutoAleReg(BYTE);
void setAutoFBlock(BYTE, BYTE);
void setMultiPlaneRead();
void setSinglePlaneRead(BYTE);
void setReadCmdAle(WORD);
void setRandomoutCmd(BYTE);
void setFlashAddrReg(BYTE, ADDRINFO *);
void chkRlibMoCmd();
// void setFRwParam(WORD, BYTE, WORD, BYTE);
// void tranCeNum(ADDRINFO *);

#if (_TSB_BiCS3|_SANDISK_3D_GEN2|_SANDISK_3D_GEN3|_TSB_BiCS4)
#else
void setBitPerCell(BYTE);
#endif
void setMultiPlaneProg(WORD, BYTE);
void trigProgSpare(WORD);
void trigReadSpare(BYTE);
void flashChangeDieCmd(BYTE);
void flashReadPage();
void flashProgPage(WORD, BYTE, WORD);
void flashErase(WORD);
BYTE chkEraseStatus();
void setTsb1SectorPatterforDebug(WORD, WORD);
// readretry
BYTE readRetry(BYTE, ADDRINFO *, BYTE);
void jdgReadRetry(ADDRINFO *, BYTE);
void chkAllChEccFail(BYTE);
void getFeatureByChCeDie(BYTE, BYTE, BYTE, BYTE);
void ctrlAuxQue(BYTE);    // 0:OUT 1:IN
void setFlashFeatureForInterface(WORD, BYTE, BYTE, BYTE, BYTE);
BYTE chkFlashVendorID();
void readFlashId(BYTE *);
void readFlashId_LiteOnVU(BYTE *);
void readGlobEraseCnt_LiteOnVU(BYTE *);

void doVtDistribution();
BYTE checkSharePage(WORD);
void addReadOpIdex(BYTE);
void addProgOpIdex(BYTE);
void setBzInfo(BYTE, BYTE, BYTE);
void waitChCeBz(BYTE, BYTE, BYTE);
void waitAllChCeBz();
void waitAllFlashReady();
// void chkHdmaCnt();
void chkRwOpIdxTail(BYTE);
void chkOpIdxAccCnt(BYTE);
void chkOpIdxAccCntW(BYTE);
void chkLdpcResult(BYTE);
BYTE getUNCOpIdx(BYTE, BYTE);
void chkEccFail(BYTE);
void postFlashPreCmdAle(BYTE, BYTE);
void handlePipeEccFail(BYTE, BYTE);
void chkReadState(ADDRINFO *);
void rstFifoTailPtrR();
void rstFifoTailPtrW();
#if _ENABLE_RETRY_HYNIX
void loadRetryOTPTable(BYTE, BYTE, BYTE, BYTE, BYTE *);
void initHynixRetryValue();
void setHynixRrPara(BYTE, BYTE, BYTE, BYTE, BYTE);
#endif
void getNandParam(BYTE, BYTE *);
void setNandParam(BYTE, BYTE);
void resetFlashForErrHandle();
void resetRwCtrlForErrHandle();
void setFlashDriverStrength(BYTE, BYTE);
void setFlashToggleSpecific(BYTE, BYTE);
void changeFlashClockForThermal();
BYTE recoverFlashReg();
void vendorCmdWriteMPInfo();

#if (_EN_SLC_END_PARA)
BYTE getParaSlcEndurance(BYTE uCh, BYTE uCe, BYTE uDieIndex);
void setParaSlcEndurance(BYTE uCh, BYTE uCe, BYTE uDieIndex, BYTE uParaEndurance);
void setSlcEndurPara();
#else
#define getParaSlcEndurance(...)
#define setParaSlcEndurance(...)
#define setSlcEndurPara(...)
#endif

#if (_EN_FLASH_WR_CMD)
void flashWriteCmd(WORD u16Fblock);
#else
#define flashWriteCmd(...)
#endif
void getNandTempSensor();

// VthTracking.c
void gChkOverHill(Tracking *TrackingPara);
void gFirstInitial(Tracking *TrackingPara);
void gCntHistogram(Tracking *TrackingPara);
void gCntShift(Tracking *TrackingPara);
void gUpdateVthCenter(Tracking *TrackingPara);
void gSetLimitation(Tracking *TrackingPara);
void gLDPC_Vth_tracking(Tracking *TrackingPara);

// FlashCtrl.c
void tranAddrInfoToAllCh(ADDRINFO *);
void flashDummyProgram(WORD);
void setSelMulFL(BYTE uMul);
void setBusSyncMode();
void setBusDiff();
void setBusEdoMode();
void setBusToggleMode();
void enEccInMax();
void enEccInNormal();
void enSprEcc();
void resetEcc();
void setChunkAddr(BYTE);
void setAleRegister();
void setCeQueAddr();
void setSprByte(BLKSPRINFO *, BYTE);
void initNandCtrlReg();
void enDataOnesCnt();
void disDataOnesCnt();
void ctrlOnesCntStop(BYTE);
void enAllChStop(BYTE);
void disAllChStop(BYTE *);
void enErrStop();
void disErrStop();
void enEccStop();
void disEccStop();
void enEccStopCh();
void disEccStopCh();
void setFlashDrv();
void ctrlScrbBothAndEcc(BYTE, BYTE);
void ctrlErrInject(BYTE, BYTE, BYTE, WORD, WORD);
void ctrlAuxQue(BYTE);
BYTE getChFiFoBusy(BYTE);
void setChOpIndex(BYTE, BYTE);
// void addChOpIndex(BYTE);
BYTE getChOpIndex(BYTE);
BYTE getChOpIdxCntInFifo(BYTE);
BYTE getChEccResultSts(BYTE);
BYTE getChOpResultFlag(BYTE);
void waitCmdFifoDpt(BYTE, ADDRINFO *);
void chkStatusFail(BYTE);
void chkAllChStatusFail(BYTE);
void enLDPCAutoGate(BYTE);
void disLDPCAutoGate(BYTE *);
void enFlashAutoGate(BYTE);
void disFlashAutoGate(BYTE *);
LWORD readDataInLdpc(BYTE, LWORD, BYTE);
void setSprOnesCnt(BYTE);
void enRetryDataOnesCnt(BYTE);
void disRetryDataOnesCnt(BYTE);
void setFlashDllAdj();
void SetMskCeCnt(WORD);
void setFlashRWDelayTime(WORD);
void setAuxQue(BYTE);

// FlashReadRetry.c
void updateLogNandQueue();
void doLDPCSeparateTrack(BYTE, RETRYINFO *);
void setRRCmdAle(RETRYINFO *, BYTE);
void dataIn1Byte(BYTE);
void setRetryCmd(RETRYINFO *, BYTE);
void flashReadRetry(RETRYINFO *);
void doLDPCSoftDecode(BYTE, BYTE, RETRYINFO *);
void replaceVthTab(BYTE *, BYTE *, BYTE, BYTE);
BYTE find1stUNCPlane(RETRYINFO *);
void setReadRetryInfo(RETRYINFO *);
void calRetryPara(RETRYINFO *, ADDRINFO *, BYTE, BYTE);
void readRetryMarkBad(ADDRINFO *);
void doReadRetry(ADDRINFO *, BYTE, BYTE);
#if _LiteOn_RR_MdfyDrv
void modifyDring(BYTE, BYTE);
#endif
void setTestRetryCmd();
void setWriteDataBufReg(WORD, BYTE, BYTE, WORD);
void setReadDataBufReg(WORD, BYTE, BYTE, WORD);
#if (_TSB_BiCS3||_SANDISK_3D_GEN2||_SANDISK_3D_GEN3||_TSB_BiCS4)
void inputBiCS3TLCRRCmd(RETRYINFO *, BYTE);
#endif
void initRetryTablePassIndex();
void initTrackingPara();
BYTE getTrackingPageKSize(BYTE uSectorH, BYTE uRwHalfKb);
void replaceVthTabForTrackingPara(BYTE *uDesVthTab, BYTE *uSrcVthTab, BYTE uPageTyp, BYTE *uSoftStep, BYTE uReadCnt);
void replaceVthTabForSeparateTrack(BYTE *uDesVthTab, BYTE *uSrcVthTab, BYTE uEnSeparateUpper, BYTE *uSoftStep, BYTE uReadCnt);

// Read.c
BYTE getReadSctrCnt(LWORD);
BYTE trigHostPrdTaskR();
BYTE trigHostSeqRead(BYTE);
void findReadSrc(WORD, WORD, BYTE);
// void chkAddReadFifoHead();
// void addSrcAddrInfo(WORD *);
void setReadHAddrInfo(PRDQUEUE *, BYTE);
void postFlashAddrInfoR();
void postSrchF2hTab(void);
void postReadH2fSgmtTab(void);
void termFlashOperR();
void chkPostReadFifo();
void trigFlCmdFfStep2();
void trigChFlashCmdFifoR(BYTE);
void chkPostReadFifo3();
// void trigFlashCmdFifoR();
void chkPostPreReadFifo(WORD, BYTE, BYTE);
BYTE getFreeNcqTag();
// void ReleaseFreeNcqTag(BYTE);
// void postReadH2f1kTab(void);
// void rstPrdTrigPtr(void);
BYTE getFreeRdHaddrTag();
void releaseFreeRdHaddrTag(BYTE);
void getReadH2fTabRdy(H2FTABLE *, WORD, BYTE);
void findReadSrc2(WORD, WORD, H2FTABLE *, BYTE);
void postFAddrInfoSeqR(PRDQUEUE *, WORD, WORD);
void termContiR();
BYTE srchSrcInHmb(WORD, WORD);

// Write.c
WORD getWrPrdCnt(LWORD, BYTE);
WORD getWriteBufPtr(WORD);
BYTE getWriteSctrCnt(WORD);
void incWriteAddr(BYTE);
void trigHostPrdTaskW(WORD);
// void setWriteDes(WORD, ADDRINFO *, BYTE);
void sortProgFifoIdx(BYTE, BYTE);
void trigChFlashCmdFifoW(BYTE);
void chkPostProgFifo();
void trigFlashCmdFifoW();
void chkAddProgFifoHead(WORD);
void addDesAddrInfo();
void setProgFifoOpt(WORD);
void invPlaneBufFlag(WORD, BYTE, BYTE);
void flushWriteCache();
BYTE chkWriteDataDone();    // BYTE);
void termFlashOperW(BYTE);
WORD findSrcInBuf(WORD, WORD);
void findSrcInWfifo(WORD, WORD);
BYTE waitHitBufDatRdy(WORD, BYTE);
void readNop1Proc();
BYTE chkBrkWriteInPcieErr(WORD);
void initNewFblkProc(WORD);
void postFlashAddrInfoW();
void rstRdyTyp();
// void bkOneShotChPtr();
// void restoOneShotChPtr();
void getWriteSctr2ChgBlk();
void chkTrigHostWrQue(BYTE);
BYTE getTailFifoOffset();
void chkBufOccupy(WORD);
void backupRwBufferForSecApi(BYTE);

// Ftl.c
void tranLba2HAddr(LWORD, HADDRINFO *);
void chkVpCnt();
void addLbaAddr(BYTE uSctrCnt);
void setH2fSrcBlock(LWORD *, WORD, LWORD, BYTE, BYTE);
BYTE srchH2f1kTabSgmt(LWORD);    // , WORD);
#if _ENABLE_RAID
BYTE setH2f1kTabSgmt(LWORD, BYTE);
#else
BYTE setH2f1kTabSgmt(LWORD);
#endif
BYTE srchH2f1kTabSgmt2(LWORD, BYTE);
// void remH2f1kTabSgmt(BYTE);
// void sortH2f1kTabSgmt(BYTE);
void createPrdTabLink(BYTE, BYTE);
BYTE delePrdTabLink(BYTE);
void handleH2fSgmtRdy(void);
void handleHmbSgmtRdy();
void setSprByteOfDataBlk(BYTE);
void setH2fTabSgmt(WORD);
BYTE srchSrcInF2hTab2(WORD, WORD, H2FTABLE *, BYTE);
BYTE judgeSerial(LWORD, LWORD);
BYTE assignFreeBtSrcAddrInfo();
void waitCmdAllDone(BYTE);
void releaseBtSrcAddrInfo();
void setZeroVpcBlock(WORD);
BYTE assignFreeBtDesAddrInfo();
void releaseBtDesAddrInfo();
BYTE chkPopBlkOpt();
BYTE chkH2fFindHMBQueue(WORD);
void readNandH2fTab(LWORD, WORD, WORD, WORD, BYTE);
void recordCacheBlk();

// SystemBlockCtl.c
void loadRootPage(WORD, WORD, WORD, BYTE, BYTE, BYTE);
void progRootPage(WORD, BYTE, WORD, WORD);

// DiffAddr.c
BYTE loadInfoPage(WORD, BYTE, WORD, BYTE, BYTE, BYTE);
void initDiffTable();
void setInjuredInfo(BYTE, BYTE);

// F2hTab.c
// void popCacheF2hTab(WORD, WORD);
void flushCacheF2hTab(BYTE);
void updateF2hTable(LWORD);
WORD srchSrcInF2hTab(WORD, WORD);
BYTE readCacheF2hTab(WORD, WORD, LWORD, BYTE);
BYTE srchDataInF2h();
void mskRptF2hTab();
void getSrchResult(BYTE);
void chkRaidParityOccF(LWORD);

// FakeEngine.c
#if _FAKE_ENGINE_TEST
void setFakeRead(LWORD, WORD, LWORD);
void setFakeWrite(WORD, LWORD, WORD, LWORD);
void setFakeEngine(LWORD, WORD, LWORD, BYTE);
void initFakeEngine();
#endif

// InitDram.c
void initDramSetting();
void goCore0DramCode(void);
void goCore1DramCode(void);

// Hdma.c
void hdmaClrRam(LWORD, LWORD, LWORD, WORD);
void hdmaCopyRam(LWORD, LWORD, LWORD, WORD);
void hdmaEncRam(WORD, WORD, WORD, WORD, BYTE, BYTE);
void hdmaGetRaidPty(WORD, WORD, BYTE, WORD, BYTE);

// Raid.c
void trigRaidEngInit(BYTE, BYTE);
void trigRaidSetKVal(BYTE, BYTE, BYTE);
void trigRaidDataEnc(WORD, WORD, BYTE, BYTE, BYTE, WORD, BYTE, BYTE, BYTE);
void trigRaidPtyOut(WORD, BYTE, BYTE, BYTE, BYTE, BYTE);
void trigRaidHdmaTerm(WORD, BYTE, BYTE, BYTE, BYTE, BYTE);
void trigRaidHdmaResm(BYTE, BYTE);
void trigRaidBopTerm(WORD, BYTE, BYTE, BYTE, BYTE);
void trigRaidBopResm(BYTE, BYTE);
void trigRaidBopDecIn(WORD, WORD, BYTE, WORD, BYTE);
void trigRaidBopDecOut(WORD, WORD, BYTE, WORD, BYTE);
void setRaidEngBitMap(BYTE);
void clrRaidEngBitMap(BYTE);
void setRaidEngPtyBitMap(BYTE);
void clrRaidEngPtyBitMap(BYTE);
// BYTE chkRaidFlag(WORD, WORD, BYTE);
BYTE chkTailFifoOffset();
void defineRaidType(BYTE, WORD, BYTE);
void initRaidEngine();
void initRaidEngineResumePS3();
void rstRaidEngVar(BYTE);
BYTE getFreeRaidEngIdx(BYTE);
void pushRaidPtyBlk(BYTE);
// void setRaidEncode(WORD, WORD, WORD, WORD, BYTE, BYTE);
// void getRaidParity(WORD, WORD, BYTE, WORD, BYTE);
void trigHdmaEncData(ADDRINFO *);
void termRaidAllEngForQB();
void resmRaidAllEngForQB();
void doRaidDecode();

// H2fTab.c
void save1stCacheInfoBefW();
void readH2fSgmtTable(WORD, WORD, BYTE, BYTE);
void initH2fTabFblock(BYTE);
void readH2fTable(WORD, WORD, WORD, BYTE);
void swapH2fTable(WORD, WORD, BYTE);
void progH2fTable(WORD, WORD, WORD, WORD, BYTE);
// void readH2f1kTable(WORD, H2F1KTABSGMT *, BYTE);
BYTE jdgH2fTabBlockFull();

// ISP_GcH2fTab.c
BYTE chkBgdClnH2fTabBlk();
void postReadH2fPage(WORD, WORD);
void trigFLCmdFifoWtab();
void bgdClnH2fTabblkProc();
BYTE chkExitGcH2fTabProc();

// SprBlk.c
BYTE popSysSprBlkIdx();
void initErasedSysSprBlk(BYTE, BYTE);
WORD popSpareBlock(BYTE);
void setBlockMoSkipBit(WORD);
WORD prepopBlockErase(BYTE);
BYTE prepopBlockChkStatus(WORD, BYTE);
void pushSpareBlock(WORD, BYTE);
LWORD eraseBlockProc(WORD, BYTE);
LWORD erasedDiffType2Blk(WORD);
void chkPushSpareQ(BYTE);

// PrdMgr.c
// void insertNodeToList(LINKNODE*, LINKINFO*, WORD, WORD);
// void deleteNodeFromList(LINKNODE*, LINKINFO*, WORD);
void chkReleaseFreeHwPrd();
void releaseFreeHwPrd();
void deletePrdLinkList(WORD);
BYTE getFreeHwPrd();
void releaseFreePrdInfo(WORD);
BYTE getFreePrdInfo();
BYTE deleteTaskFromRwPrdList(WORD);
void insertTaskToReadPrdList(WORD, WORD);
void insertTaskToWritePrdList(WORD, WORD);
void sortRwTaskAndInsertToPrdList(WORD);
void releaseSrcAddrInfo(WORD);
BYTE getFreeSrcAddrInfo();
void insertTaskToSrcAddrInfo(WORD);
void releaseFreeHwPrd2();

// VendorCmdCommon.c
LWORD getTime();
void initVendorCmdDebugInfo();
void closeVendorCmdDebugInfo(BYTE, BYTE);
void fillUnknownVendorCmdPattern();
void setVendorRwInfo();
void setSprByteforVendor(BYTE, WORD, WORD, WORD, WORD, BYTE);
void insertVendorTask(BYTE);

// DataInVendorCmd.c
BYTE dataInVendorCmdReadVendorCmdDebugInfo();
BYTE dataInVendorCmdReadFlashId();
BYTE dataInVendorCmdReadRam();
BYTE dataInVendorCmdReadLog();
BYTE dataInVendorCmdReadDriveInfo();
BYTE dataInVendorCmdReadPhysicalPage();
BYTE dataInVuCmdLba2Pba();
BYTE dataInVendorCmdReadWproPage();
BYTE dataInVendorCmddoVtDistribution();
BYTE dataInVendorCmdReadEfuseReg();
BYTE dataInVendorCmdWdPhyErase();
BYTE dataInVendorCmdWdPhyRead();
BYTE dataInVendorCmdWdCheckSts();
#if _GREYBOX
BYTE dataInVendorCmdGreyBoxPre();
BYTE dataInVendorCmdGreyBoxTrig();
BYTE dataInVendorCmdGreyBoxDone();
BYTE dataInVendorCmdGreyBoxModifyEraseCnt();
BYTE dataInVendorCmdGreyBoxMarkBadBlock();
BYTE dataInVendorCmdGreyBoxSecurityRW();
BYTE dataInVendorCmdGreyBoxReadH2fTab();
BYTE getH2fTabBlkInfo(WORD, WORD);
BYTE dataInVendorCmdGreyBoxSaveQBInfo();
#endif

// DataOutVendorCmd.c
void dataOutVendorCmdWriteRam();
void dataOutVendorCmdWritePhysicalPage();
void dataOutVendorCmdWdPhyProgram();

#if _GREYBOX
void dataOutVendorCmdGreyBoxTrig();
void dataOutVendorCmdGreyBoxFwUniTestIn();
#endif

// NonDataVerdorCmd.c
WORD nonDataVendorCmdResetCpu();
void nonDataVendorCmdErasePhysicalBlock();
void nonDataVendorCmdEraseTotalBlock();    // MPFormat_Chief_20181109
void nonDataVendorCmdClearSmart();
void inputVthSet();

// GetLogPage.c
void nvmeGetLogPage();
void getLogNvmeErrInfo(BYTE);
void getLogNvmeSmart(BYTE);
void getLogDellSmart(BYTE, WORD *);
#if (OEM==LENOVO)
void getLogLenovoPageDFh(BYTE);
#endif
void getLogPLPStatistics(BYTE);
void addErrorLog(WORD, BYTE, BYTE);
void updateSmartCnt(QWORD *, QWORD *, LWORD);
void getLogVendorTelemetry();
void getLogTelemetryHost();
void getLogTelemetryController(BYTE);
void getLogSanitize(BYTE);

// Hmb.c
void readHmbH2fTab(WORD, WORD, WORD, BYTE, BYTE);
void writeHmbH2fTab(WORD, WORD, WORD);
void writeHmbH2fTabSgmt(WORD, WORD, WORD, WORD);
void insertHmbDirtyLink(WORD, BYTE);
// void workaroundHmb0();
// void workaroundHmb1();
// void writeHmbData(WORD, WORD, LWORD, BYTE, BYTE, LWORD);
// void readHmbData(WORD, WORD, LWORD, BYTE, BYTE, LWORD);
void txfrHmbData(BYTE, WORD, WORD, LWORD, WORD, BYTE, LWORD, LWORD);
void postHmbReadData();
void flipOccFlag(WORD, WORD, BYTE);
void releaseHmbHwPrd();
void chkHmbPrdDone();
void waitHmbPrdDone();
void readHmbH2fTab2(WORD, WORD, WORD);
void writeHmbGcInfoTab(WORD, WORD, WORD);
void readHmbGcInfoTab(WORD, WORD, WORD, BYTE);
void readHmbH2f4B(WORD, WORD, BYTE);
void trigHmbDataXfer(HMBPRDQ *, LWORD);
void writeE2eCrc2Hmb(BYTE);
void readE2eCrcFromHmb();
void writeTsbE2e2Hmb(BYTE, BYTE);
void readTsbE2eFromHmb(BYTE);
void writePtyE2e2Hmb(BYTE, WORD);
void readPtyE2eFromHmb(WORD);

void saveIndexBlock();

// ISP_WproBlk.c
// void progWproPage(BYTE , WORD);
// void readWproPage(BYTE , WORD);
extern BYTE chkDiffType2Ptr(WORD);
extern void progWproPage(BYTE, WORD);
extern void progWproPage2(BYTE, WORD);
extern void prog1stInvQBootInWpro();
extern void readWproPage(BYTE, WORD, BYTE);
extern void setWproPagePtr(BYTE, WORD);
extern void remWproPage(BYTE);

// I2cCtrl.c
BYTE i2cChkAck();
void i2cInit();
BYTE i2cMasterStart();
BYTE i2cMasterStop();
BYTE i2cMasterTxData(BYTE);
BYTE i2cMasterRxData(BYTE *);
static WORD computeTemperature(WORD);
BYTE I2cTemperatureSensor();

// ISP_FuncPtr.c
extern void(*const codeFuncPtr[]) (void);
extern void(*const codeFuncPtr2[]) (BYTE);
extern BYTE(*const codeFuncPtr3[]) (void);

// ISP_FuncPtrCore1.c
extern void(*const codeFuncPtrCore1[]) (void);
extern void(*const codeFuncPtr2Core1[]) (BYTE);
extern WORD(*const codeFuncPtr3Core1[]) (WORD, WORD);
extern BYTE(*const codeFuncPtr4Core1[]) (void);
extern void(*const codeFuncPtr5Core1[]) (WORD, WORD);

// extern void(*const codeFuncPtr4[]) (WORD, BYTE, BYTE);
// extern void(*const codeFuncPtr5[]) (BYTE, WORD);
// extern void(*const codeFuncPtr6[]) (WORD, WORD);

// extern void (*const codeFuncPtr5[])(ADDRINFO *);
// extern void (*const codeFuncPtr6[])(RETRYINFO *);

// debugLog.c
#if _DEBUG_LOG
void debugLog(BYTE, BYTE, BYTE, ...);
void debugLogSave(BYTE, BYTE, BYTE, WORD, ...);
void debugLink(BYTE, BYTE, BYTE, ...);
void debugLinkSave(BYTE, BYTE, BYTE, WORD, ...);
void fillEventLog(WORD);
#else
#define debugLog(...);
#define debugLogSave(...);
#define debugLink(...);
#define debugLinkSave(...);
#endif

#if _EN_SAVEEVTLOG
void saveEventLog(BYTE);
#else
#define saveEventLog(...);
#endif
void calEraseCnt(LWORD *, LWORD *, LWORD *, BYTE);
extern void printNandPhyAddr(ADDRINFO *);
extern void debugAllChReadFifo(BYTE uOpt);
extern void debugTSBflag(BYTE);
extern void getPfRtcTime(LWORD);
// ISP_GcCacheB.c
extern BYTE getBrkBgdGcF();
extern BYTE chkGcLoadH2fTab(WORD, WORD);
extern void bgdClnCacheblkProc(BYTE);
void setOddPlaneProgGc(WORD);
void trigFLCmdFifoWgc();
void flushGcDesF2hTab();
BYTE popGcDesF2hTab(WORD, LWORD, WORD, WORD);
// void initGcProc(void);
void endOfBgdClnCacheblkProc(void);
void addNewGcSrcBlk();
void deleteGcSrcBlk(BYTE);
void selectSrcBlk();
void buildSrcFaddrDesF2hTab();
void trigFLCmdFifoWgc();
void trigNxtVPCmdAle(WORD, WORD, BYTE, BYTE, ADDRINFO *);
void buildValidCachePage(WORD, WORD);
BYTE chkExitGcProc();
BYTE setGcFlowAndBlkCnt();
void srchGcSrcF2hTab(WORD, BYTE);
void setOddPlaneProgGc(WORD);
void addGcDesSerial();
void initGcDesFblkProc();
void updateGcDesF2hTab();
// void gcDesBlkFullSetting();
BYTE getTotalGc4kCnt();
BYTE chkBgdWlColdBlk(BYTE, BYTE);
WORD addCopyBufPtrGc(WORD, LWORD);
WORD setProgFifoOptGc(WORD, BYTE);
WORD loadPartialGCTab(WORD, WORD);
BYTE chkLoadGCInfoTab();
void loadGcInfoTab(BYTE, WORD, BYTE);    // , WORD);
#if _EN_RAID_GC
void handleGcRaidParity(WORD, WORD, BYTE);
void chkHmbStsChg();
void chkTrigHmbPtyQue();
#endif
BYTE chkAddGcOneShotPtr();
LWORD getGcTabAddr(LWORD);
WORD setWriteGcDataHmb(WORD, WORD);
void chkExitGcCondition();

// MarkBad.c
void markBadBlock();
void setMarkBadBlock(ADDRINFO *, BYTE);

// FwCommitDl.c
void nvmeFwCommit();
void nvmeFwImageDl();
void progFwDlTempIspblockCore0(WORD);
void swapFwSlotIspCore0(BYTE);
BYTE loadIspPageCore0(WORD, BYTE);
#if _EN_BUILD_FWSLOTISPBLK
void buildFwslotIspBlk();
#endif
void activateFwImm(LWORD, BYTE, BYTE);

// Tcg.c
void setRangeLoadPtr();
void trustedSend();
void trustedReceive();
void initTcgParameter(BYTE);
// void handleSpMethod();
void sessionManagerControlMethod();
void sessionManagerRegularMethod();
BYTE handleTcgTrustedSend();
BYTE handleTcgTrustedReceive();
void securityWrite();
void securityRead();

// Security.c
void getRandom(LWORD, BYTE *);
void shaEncryption(BYTE *, LWORD, BYTE *, BYTE);
void hmac(BYTE *, BYTE, BYTE *, BYTE *, LWORD);

// BootFshCmdHS.c
void addDoneBtDesAddrInfo();
void trigBtFlashCmdFifoW();
void trigBtFlashCmdFifoR();
void addDoneBtSrcAddrInfo();

// TrigAddrInfo.c
void insSrcCmdList();
BYTE waitSpareReady(BYTE);
void chkPreCmdAle(BYTE);
void trigFlCmdFfStep3();
// void trigFlPreCmdAle();
void chkPostReadFifo2();
// void trigFlashCmdFifoR3();
void termContiRCore1();
BYTE chkReadCnt(WORD);
void setFifoClrOccF(WORD, BYTE);
BYTE chkReadBufFree(BYTE, BYTE, BYTE);
BYTE compareBufSerl(BYTE, BYTE, BYTE, BYTE);

// FlashPub.c
void setFLActCh(BYTE);
void getSprByte(BLKSPRINFO *, BYTE);
void setFLAddrActCh(BYTE, ADDRINFO *);
WORD tranRsvBlkAddr(BYTE, ADDRINFO *);
void setBufStatus(WORD, WORD, BYTE);
void insertTaskFifo(TASKENTRY);
void initCacheFblkProc();
void addCacheBlkSerial();
void enableLdpcPipe();
void disableLdpcPipe();
void funcTskDisLdpcPipe(BYTE);
void funcTskEnLdpcPipe(BYTE);
void funcTskInitSlcQ(BYTE);

// NvmeIoCmd.c
void nvmeFlush();
void nvmeWriteUncorrectable();
void nvmeCompare();
void nvmeWriteZero();
void nvmeDataSetManagemaent();
WORD chkCmdInfoError(LWORD, LWORD, LWORD);
WORD chkLbaRange(LWORD, LWORD, LWORD, LWORD, BYTE);
void readRequrementData(WORD, BYTE);
void remRptH2f1kTabSgmt(WORD);

void setDiffType2AddrInfo(WORD);

WORD getDiffAddr(WORD, BYTE, BYTE, BYTE);

void getDiffAddr2(ADDRINFO *, WORD, BYTE, BYTE, BYTE);
void tranType2Addr(ADDRINFO *, WORD);

// TrimCmd.c
void nvmeDataSetManagemaent();
WORD chkAllEntryValid(WORD *, TRIMTOUTINFO *, BYTE);
#if _ENABLE_TRIM
BYTE chkTimeOut(TRIMTOUTINFO *);
void popCacheF2hTab(WORD, TRIMTOUTINFO *);
BYTE chkTrimHblockChg(WORD, TRIMTOUTINFO *);
BYTE chkEmptyHBlk(WORD);
void trim4k(WORD, TRIMTOUTINFO *, BYTE);
BYTE chkH2fTabInvalid(TRIMTOUTINFO *);
// void setH2fSrcPageInvalid(UCLWORD *);    // _Uncached H2FTABLE *)
void chkTrimH2fChg(TRIMTOUTINFO *);
void processTrim(BYTE uType);
#else
#define processTrim(...);
#endif

#if _ENABLE_HMB_FLUSH
BYTE flushCacheHmbTab();
void modifyHmbByH2f1kTab(BYTE);
void modifyH2f1kTabByF2h(WORD, WORD, LWORD);
#else
#define flushCacheHmbTab(...)
#define modifyHmbByH2f1kTab(...)
#define modifyH2f1kTabByF2h(...)
#endif

// Core1
void saveQBInfowithDummy(BYTE);

void blinkLed();
void loadIspCode(BYTE, BYTE);
void rstCacheInfoTab(BYTE);
BYTE chkWproBlk(WORD);
BYTE readIspBlock(WORD, BYTE, BLKSPRINFO *);
void setSprByteOfIspBlk(BLKSPRINFO *, WORD, BYTE);
void modifyH2FtabBootCore1();
void modifyH2FtabCore1();
void setHwPrdCore1();
WORD getDiffFBlock(WORD, BYTE, BYTE, BYTE);
void saveWproBadInfo();
void setSprByteOfSysBlk(WORD, BYTE, BYTE);
void chkPfFblockProc(BYTE);
void doRaidDecodeSwap();
void tempSetFlashCmd();
void initNandCtrlReg();
void initNandBusAndAleReg();
void initNandFlash();
void initBufWrap();
void saveWdtDebugInfo(WORD);
#if S_SpeedUPSLCProg
void AIPRSet(BYTE uALE, BYTE uData);
void Overload_AIPR_Disable();
void ReturnNormal();
#endif
WORD AvgECForCore1(BYTE);
// SramEcc.c
/* TSB Ecc relative function */
void tsbEccDisable();
void initTsb0123Ecc();
void initTsb4Ecc(BYTE);
// LWORD tsbEccGetDackValue(BYTE, BYTE);
LWORD tsbEccGetErrAddr(BYTE, BYTE);
LWORD tsbEccGetErrOffset(BYTE, BYTE, BYTE);
// BYTE tsbEccChkEccStatus(BYTE *);

/* CPU Ecc relative funciton */
void cpuEccInit(BYTE);
void cpuEccDisable(void);
BYTE cpuEccGetFailStatus(BYTE);
BYTE cpuEccChkStatus(BYTE, BYTE *);

// void chkReadCntInBg();
void pushWLReadReclaimQ(WORD, BYTE);
void chkPopWLReadReclaimQ(WORD);

// E2e.c
BYTE chkInternalDataCrc(WORD, WORD, LWORD, BYTE);
void genInternalDataCrc(WORD, WORD, LWORD, BYTE);
void genIternalFakeCrc(WORD, WORD);
BYTE chkReadTableCrcCnt(ADDRINFO *);

// NvmeCommon.c
void nvmeInitFtlVar();
void eraseUnitProcCore0(BYTE);
void updateNvmeDstData(BYTE, BYTE);
void handleCore0VarErase();
void SaveFWHistory(BYTE, BYTE);

#if _ENABLE_SECAPI
#include "inc/SecAPI_BaseFW.h"
#include "inc/Security.h"
#endif

// ProgFail.c
void chkPfFblock(BYTE);
void setMarkPfFblock(BYTE);
BYTE chkProgFailBlock(ADDRINFO *, WORD);
void recovPfPageData(ADDRINFO *, BYTE, BYTE);
void rstChFifoPtrW(BYTE);
void rstChFifoPtrR(BYTE);
void rstOpIndex(BYTE);
BYTE getProgFailSts(BYTE);
void setReproFifoPtr(BYTE);
void movePfChPageData();
BYTE chkPfChPageRead();
void setProgFailPara(WORD);
void restoProgFailPara();
void setPfWrPara(BYTE, BYTE);

// Core1BootFunc.c
void core1Boot();

// FwCommitDlCore1.c
void funcTskProgFwDlTempIspBlock(BYTE);
void funcTskActivateIsp(BYTE);
void funcTskJudgeSwapIsp(BYTE);
void funcTskChkIspBlock(BYTE);
void funcTskSwapFwSlotIsp(BYTE);
void funcTskLoadIspPage(BYTE);
void progFwDlImageBlk(WORD, WORD);
LWORD getChkSumofFwImageDl(WORD);
void swapIspBlock(BYTE);
BYTE confirmIspBlock(BYTE);
BYTE judgeSwapIsp();
void progSysBlk(WORD, WORD, BYTE, BYTE);

// Core1Nvme.c:
void rstCacheInfoTab(BYTE);
void eraseTotalFBlock(BYTE);
void funcTskEraseUnitProc(BYTE);
void funcTskEraseUnitStart(BYTE);
void funcTskEraseUnitContinue(BYTE);
void funcTskLoadTelemetryCtlrLog(BYTE);
void funcTskHandleCntForSanitize(BYTE);

// Core1Vu.c:
void funcTskVendorOp(BYTE);

// GcCore1.c
void chkPWRCore1(BYTE);

// FtlPub.c
void progCacheInfoTab();
void pushH2fBlk(BYTE);
void setH2fTabPagePtr(WORD, BYTE, WORD);
void tranAddrInfo(ADDRINFO *);
void tranAddrInfoTo2Ch(ADDRINFO *);
BYTE chkBgdClnCacheBlk();
void rstWrpoInHmb();
void rstH2F1KInfo(void);
void rstH2F1KInfo2(BYTE);
void setFwPreOccuFlag(WORD);
void clrFwPreOccuFlag(WORD);
void setPageSelCmd(ADDRINFO *, BYTE);
void restoreCacheBlockFull();
void recovPcieErrW2(BYTE);

#if (_EN_CHRONUS_UART_DEBUG)
void chkUartDebugCmd();
void sendUartCmdRsp(WORD);
#endif

#if _EN_IOMTRIG
void InitIoMeter();
void InitIoMeter1Thr();
#endif

#if _EN_Lenovo_RecoveryChk
void InitIoMeter_RecoveryChk();
#endif

// Sanitize.c
void nvmeSanitize();
void eraseUnitStart(BYTE);
void sanitizeStartOperation();
void sanitizeBlockErase();
void sanitizeOverwrite();
void sanitizeContinueOperation();
BYTE eraseUnitContinue();
void saveSanitizeInfo(BYTE);
void eraseUnitStartCore0(BYTE, BYTE);
BYTE eraseUnitContinueCore0();
// void sanitizeCryptoErase();

// TaskFuncForMain.c
void callCore1Task(BYTE);







