







#ifndef __REG_I2C_H__
#define __REG_I2C_H__

// I2C Control register  @ 0x5100_0700

#define rcCmdSta                                 0x00
#define rcCmdStp                                 0x01
#define rcCmdTxReg                               0x02
#define rcCmdRxReg                               0x03
#define rcCmdTxd                                 0x04
#define rcCmdRxd                                 0x05
#define rcLoadTsbAddr                            0x06
#define rcClkPre                                 0x08
#define rcSetupCtrl                              0x09
#define rcIFlag                                  0x0A
#define rcStatusM                                0x0C
#define rcStatusS                                0x0D
#define rcDevStatus                              0x0E
#define rcSaddr                                  0x10

#define rcTsbSaddrL0                             0x14
#define rcTsbSaddrL1                             0x15
#define rcTsbSaddrH0                             0x16

#define rcDmaCntL                                0x18
#define rcDmaCntH                                0x19

#define rcTxd0                                   0x20
#define rcTxd1                                   0x21
#define rcTxd2                                   0x22
#define rcTxd3                                   0x23
#define rcTxd4                                   0x24
#define rcTxd5                                   0x25
#define rcTxd6                                   0x26
#define rcTxd7                                   0x27

#define rcRxd0                                   0x28
#define rcRxd1                                   0x29
#define rcRxd2                                   0x2A
#define rcRxd3                                   0x2B
#define rcRxd4                                   0x2C
#define rcRxd5                                   0x2D
#define rcRxd6                                   0x2E
#define rcRxd7                                   0x2F

#define rmI2cCmdStart                            (rI2cCtrl[rcCmdSta]=0x01)
#define rmI2cCmdStop                             (rI2cCtrl[rcCmdStp]=0x01)
#define rmI2cSendData                            (rI2cCtrl[rcCmdTxReg]=0x01)
#define rmI2cReceiveData                         (rI2cCtrl[rcCmdRxReg]=0x01)
#define rmI2cSendDataTsb                         (rI2cCtrl[rcCmdTxd]=0x01)
#define rmI2cReceiveDataTsb                      (rI2cCtrl[rcCmdRxd]=0x01)

#define rmI2cLoadTsbInit                         (rI2cCtrl[rcLoadTsbAddr]=0x01)

#define rmI2cClkPre                              rI2cCtrl[rcClkPre]

#define rmI2cEn                                  (rI2cCtrl[rcSetupCtrl]|=0x80)
#define rmI2cDisable                             (rI2cCtrl[rcSetupCtrl]&=0x7F)
#define rmI2cDisInt                              (rI2cCtrl[rcSetupCtrl]&=0xBF)
#define rmAackn                                  (rI2cCtrl[rcSetupCtrl]|=0x01)
#define rmNackn                                  (rI2cCtrl[rcSetupCtrl]&=0xFE)

#define rmI2cImflag                              (rI2cCtrl[rcIFlag]&cBit0)
#define rmI2cClrImflag                           (rI2cCtrl[rcIFlag]=0x01)
#define rmI2cIsflag                              (rI2cCtrl[rcIFlag]&cBit1)
#define rmI2cClrIsflag                           (rI2cCtrl[rcIFlag]=0x02)

#define rmI2cRcvAckn                             (rI2cCtrl[rcStatusM]&cBit2)

#define rmI2cTsbSaddr(u32Addr)                   (r32I2cCtrl[rcTsbSaddrL0/4]=u32Addr)

#define rmI2cDmaCnt(u16Cnt)                      (r16I2cCtrl[rcDmaCntL/2]=u16Cnt)

#define rmI2cIflag                               rI2cCtrl[rcIFlag]
#define rmI2cMasterSts                           rI2cCtrl[rcStatusM]
#define rmI2cSlaveSts                            rI2cCtrl[rcStatusS]
#define rmClrDeviceBsy                           (rI2cCtrl[rcDevStatus]|=cBit0)
#define rmI2cSaddr                               rI2cCtrl[rcSaddr]

#define rmI2cTsbSaddrL0                          rI2cCtrl[rcTsbSaddrL0]
#define rmI2cTsbSaddrL1                          rI2cCtrl[rcTsbSaddrL1]
#define rmI2cTsbSaddrH0                          rI2cCtrl[rcTsbSaddrH0]

#define rmI2cDmaCntL                             rI2cCtrl[rcDmaCntL]
#define rmI2cDmaCntH                             rI2cCtrl[rcDmaCntH]

#define rmI2cTxd0                                rI2cCtrl[rcTxd0]
#define rmI2cTxd1                                rI2cCtrl[rcTxd1]
#define rmI2cTxd2                                rI2cCtrl[rcTxd2]
#define rmI2cTxd3                                rI2cCtrl[rcTxd3]
#define rmI2cTxd4                                rI2cCtrl[rcTxd4]
#define rmI2cTxd5                                rI2cCtrl[rcTxd5]
#define rmI2cTxd6                                rI2cCtrl[rcTxd6]
#define rmI2cTxd7                                rI2cCtrl[rcTxd7]

#define rmI2cRxd0                                rI2cCtrl[rcRxd0]
#define rmI2cRxd1                                rI2cCtrl[rcRxd1]
#define rmI2cRxd2                                rI2cCtrl[rcRxd2]
#define rmI2cRxd3                                rI2cCtrl[rcRxd3]
#define rmI2cRxd4                                rI2cCtrl[rcRxd4]
#define rmI2cRxd5                                rI2cCtrl[rcRxd5]
#define rmI2cRxd6                                rI2cCtrl[rcRxd6]
#define rmI2cRxd7                                rI2cCtrl[rcRxd7]

#endif    // ifndef __REG_I2C_H__







