







// ISP_RestoCacheInfo.c
extern void findCacheInfoBlock();
extern void findIndexBlock(BYTE);
extern void findLogBlock(BYTE);
extern void restoCacheInfo();
extern WORD getLastPageInfo(WORD, WORD, BLKSPRINFO *, BYTE);
extern WORD getRsvLastPageInfo(BYTE, WORD, BYTE, BLKSPRINFO *);
extern WORD getFirstFullPage(WORD u16Fblock, WORD u16BlkId, BYTE uMode, BLKSPRINFO *upBlkSprInfo, WORD *up16FirstEmptyPagePtr, BYTE uSkipDum);    //
                                                                                                                                                  //
                                                                                                                                                  //
                                                                                                                                                  //
                                                                                                                                                  //
                                                                                                                                                  //
                                                                                                                                                  //
                                                                                                                                                  //
                                                                                                                                                  //
                                                                                                                                                  //
                                                                                                                                                  //
                                                                                                                                                  //
                                                                                                                                                  //
                                                                                                                                                  //
                                                                                                                                                  // 20190305_ChrisSu
extern BYTE getRsvPageInfo(BYTE, WORD, WORD, BLKSPRINFO *, BYTE);

// ISP_RebuSprBlk.c
extern void rebuSpareFblock();
extern void addRdlinkReBuCacheBlock(WORD, BYTE);
extern void dummyProgTab(BYTE, BYTE);
extern void dummyProgBlk(WORD);

void setErrorBlock(WORD, WORD, WORD);
// BYTE cmprGcDesWindowGroup(LWORD, BYTE);
// BYTE cmprCacheBlkWindowGroup(LWORD);
// BYTE cmprWindowGroup(LWORD, LWORD);
void initCacheQuePtr();
extern void addBlock2CacheQ(WORD, BYTE, BYTE);

extern void sortFoundCacheQ(LWORD, WORD, BYTE, BYTE);
void sortFoundH2fTabQ(WORD, WORD, WORD, LWORD);
WORD getFoundH2fTabWin(WORD, LWORD);
void sortFoundTLCQ(BLKSPRINFO *, WORD, BYTE);
void setBlkSerial(BYTE, LWORD);

// ISP_RebuH2fTab.c
LWORD getH2fMemLocation(WORD, WORD, BLKSPRINFO *);
WORD setMemAddr(BYTE);
void rstLastH2fTab();
extern void rebuH2fTableInfo();
void sortH2fTabQ();
void updateH2fTabWindow(WORD, WORD, BYTE);
BYTE cmprValueWORD(WORD, WORD);
// WORD getH2fTabBlkLastPage(WORD,BLKSPRINFO *);
BYTE getH2fTabBlkPageInfo(WORD, WORD, BLKSPRINFO *, BYTE);
void rebuCacheBlkVpCnt(BYTE, WORD);

// ISP_RebuChildF2hTab.c
extern void copyFBlockProc(WORD);
extern void rebuChildF2hTable();
void chkAddChildFblock();
// void bootPopChildF2hTab(BYTE);
void fillBlockDummyPage(WORD, WORD, BYTE);
extern WORD chkBlockLastPagePtr(WORD, BYTE);
extern void buildBlockF2hTab(WORD, WORD, WORD, BYTE, F2HTABLE *upF2hTab);

// extern void bootSetH2fSrcBlock(_Uncached H2FTABLE *, WORD, WORD);
// BYTE cmprDataSerial(QWORD, QWORD);
void trigNexReadCmd(WORD, BYTE, BYTE, BYTE, ADDRINFO *);
// BYTE chkChgH2fSrcBlock(BLKSPRINFO *, BLKSPRINFO *);

// ISP_RebuCacheF2hTab.c
void debugLoop(BYTE uFailType);
extern void rebuCacheF2hTable();
void doExtractOpenBlockFlow();
void flushCurActCacheF2h();
void chkAddCacheFblock();
void chkAddRefreshFblock();
void flushRefreshF2hTab();
void bootPopCacheF2hTab(WORD);
void restoBkActCacheb();
void recoverCacheF2hTab(RLFLUSHF2HTAB *upFlushF2hTab);

// void delRepeatF2hItem();
// void copyCacheF2hTab(_Uncached F2HTABLE *, _Uncached F2HTABLE *);

// #if _FluMultF2hBank
// void restoCacheF2hTab(LWORD);
void popCacheF2hTabInRdlink(WORD);
void flushF2hTableInRdlink();
// #else
void restoCacheF2hTab(WORD u16SbufPtr);
// #endif

void flushCacheF2hInRdlink(RLFLUSHF2HTAB *);
void addReBuCacheBlock(RLFLUSHF2HTAB *, LWORD, WORD, BYTE);
void addCacheFblock(WORD);
void addGcDesFblock(LWORD, BYTE);
void rebuildActiveCache(WORD);
void insSdGrp(WORD, BYTE);
void setPOP(WORD, BYTE, BYTE);
void hdlMigratingStage();

// ISP_RebuSysB.c
extern void rebuSysBlk();
extern void chkBadInfo();
extern void chkLogInfo();
extern void chkMPInfo();

// ISP_RebuWproInfo.c
extern void rebuWproInfo();
void setQBootInvalid(BYTE *, BYTE);
extern UCLWORD g32arPopDeniedFlag[c16MaxBlockNum/32];

// ISP_RebuQbootInfo.c
extern void rebuQBootInfo();
// extern BYTE chkH2fTableBlockInfo();
// extern BYTE chkCacheBlock();
// extern BYTE chkCacheInfoBlk();
// extern BYTE chkGcInfo();

// ISP_Boot.c
WORD addCopyBufPtrCp(WORD, LWORD);
void initDesFblkProc();
BYTE getTotalProgBuf4kCnt(WORD, WORD, BYTE);
WORD setProgLastOptRdLk(WORD, LWORD, BYTE, void (*funcPtr)(WORD));

// ISP_RdLinkExtractFunc
void extractOpenBlock(WORD, BYTE);
void migrateSrcBlkToCache(WORD, WORD, BYTE, BYTE);
BYTE cmprReadSrcInH2f(WORD, WORD, WORD, LWORD);
WORD getTotalMigrated4kCnt(WORD, WORD, BYTE, BYTE);
WORD addMigrateBufPtr(WORD, LWORD);
BYTE getTotalMigrateBuf4kCnt(WORD, WORD, BYTE);
void postRdLkProgLastCachePage(WORD, LWORD, BYTE, void (*funcPtr)(WORD));
void trigFlashCmdFifoMigrate();
void updRdLkCacheFreePagePtr();
BYTE chkCmdFifoDptChMg(BYTE);
void chkPostProgFifoMg();
void progDesF2hTab(WORD, BYTE, LWORD);
void destroySrcBlock(WORD);
void popCacheF2hTabCp(WORD u16Hblock, WORD u16SrcFblock);
WORD setProgFifoOptMg(WORD, LWORD, BYTE, void (*funcPtr)(WORD), BYTE);
void initDesFblkProc();
void saveflushTimeStamp(LWORD, LWORD, WORD);
void waitFifoOpIdxMg(BYTE, BYTE);

WORD dummyProgOpenWL(WORD, WORD, LWORD, BYTE, BYTE);
BYTE get1stPageInfo(WORD, BYTE, BLKSPRINFO *);
void addSpareBlockCnt(WORD);

void saveIndexBlockCore0();
void InitEraseCntCore0();

BYTE getWproPageInfo(WORD, WORD, WORD, BLKSPRINFO *, BYTE, BYTE);
void setDiffType2BlkEraseCnt();
WORD getWproFreePage(WORD, BLKSPRINFO *, BYTE);
BYTE chkReBuedWproBlock(WORD);
void calWproBlkCnt();
void setWproBlkPopBit();
void chkIspBlockCore0();

void waitAllChCeBzBtCore0();







