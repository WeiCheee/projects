







#ifndef __REG_LDPC_H__
#define __REG_LDPC_H__

// #include "inc/GlobVar0.h"

// DSP Wrapper Register interface 0x5120_0000

#define  rmSetLdpcChannel(x)\
    {rLdpcDsp=(void *)reg32LdpcDsp[x];r16LdpcDsp=(void *)reg32LdpcDsp[x];r32LdpcDsp=\
         (void *)reg32LdpcDsp[x];}

#define  rcLdpcControl                           0x0000
#define  rmSetForceUpdatellr                     (r32LdpcDsp[rcLdpcControl/4]|=0x00000080)
#define  rmClrForceUpdatellr                     (r32LdpcDsp[rcLdpcControl/4]&=0xFFFFFF7F)

#define  rcLdpcModeConfig                        0x0004
#define  rcLdpcParity                            0x0008
#define  rcLdpcInitTakeLoc                       0x000C
#define  rcLdpcSoftMap                           0x0010
#define  rcLdpcEncRemap                          0x0018
#define  rcLdpcSymbolRemap                       0x001C
#define  rcLdpcMapChannelNum0                    0x0020
#define  rcLdpcMapChannelNum1                    0x0024
#define  rcLdpcMapChannelNum2                    0x0028
#define  rcLdpcMapChannelNum3                    0x002C
#define  rcLdpcMapChannelNum4                    0x0030
#define  rcLdpcMapChannelNum5                    0x0034
#define  rcLdpcMapChannelNum6                    0x0038
#define  rcLdpcMapChannelNum7                    0x003C
#define  rcLdpcMiscControl                       0x0040
#define  rmSetSoftType(x)                        r32LdpcDsp[rcLdpcMiscControl/4]|=(x<<8)
#define  rcLdpcManualPush                        0x0044

#define  rcLdpc0to1Counter                       0x0048
#define  rmGet1to0Count                          r32LdpcDsp[rcLdpc0to1Counter/4]

#define  rcLdpc1to0Counter                       0x004C
#define  rmGet0to1Count                          r32LdpcDsp[rcLdpc1to0Counter/4]

#define  rcLdpcFlipCounter                       0x0050
#define  rmGetFlipCounter                        r32LdpcDsp[rcLdpcFlipCounter/4]
#define  rcLdpcRetControl                        0x0060
#define  rcLdpcDspDebug1                         0x0064
#define  rcLdpcDspDebug2                         0x0068
#define  rcLdpcInfoDebug1                        0x0070
#define  rcLdpcInfoDebug2                        0x0074

// Ldpc Wrapper Register interface 0x5130_0000

#define  rcLdpcDecConfig                         0x0000
#define  rmSetLdpchardDecodeOnly                 (r32LdpcDec[rcLdpcDecConfig/4]|=0x00000001)
#define  rmClrLdpchardDecodeOnly                 (r32LdpcDec[rcLdpcDecConfig/4]&=(~0x00000001))

#define  rmSetnotReportDecFailinByPassMode       (r32LdpcDec[rcLdpcDecConfig/4]|=0x00000002)
#define  rmClrnotReportDecFailinByPassMode       (r32LdpcDec[rcLdpcDecConfig/4]&=(~0x00000002)

#define  rmSetCpuDecEnable                       (r32LdpcDec[rcLdpcDecConfig/4]|=0x00000004)
#define  rmClrCpuDecEnable                       (r32LdpcDec[rcLdpcDecConfig/4]&=(~0x00000004))

#define  rmSetMixDecResult                       (r32LdpcDec[rcLdpcDecConfig/4]|=0x00000008)
#define  rmClrMixDecResult                       (r32LdpcDec[rcLdpcDecConfig/4]&=(~0x00000008))

#define  rmLdpc2KMode                            (r32LdpcDec[rcLdpcDecConfig/4]|=0x00000010)
#define  rmsetN2LowPowerDetectionMode            (r32LdpcDec[rcLdpcDecConfig/4]|=0x00000020)
#define  rmsetN2LowPowerClipMode                 (r32LdpcDec[rcLdpcDecConfig/4]|=0x00000040)
#define  rmClearLdecWrapper                      (r32LdpcDec[rcLdpcDecConfig/4]|=0x00010000)
#define  rmEnAutoClearDecREGe                    (r32LdpcDec[rcLdpcDecConfig/4]|=0x01000000)
#define  rmLdpcEnLowPower                        (r32LdpcDec[rcLdpcDecConfig/4]|=(0x00000040|0x00000020))
#define  rmLdpcDisLowPower                       (r32LdpcDec[rcLdpcDecConfig/4]&=(0xFFFFFFBF&0xFFFFFFDF))

#if 0    // This part need to check!!
#define  rcLdpcClkLockGat                        0x0008
#define  rmldecCkgSynWtSt2                       r32LdpcDec[rcLdpcClkLockGat/4]
#define  rmldecCkgSynWtSt1                       r32LdpcDec[rcLdpcClkLockGat/4]
#define  rmldecCkgStrategy                       r32LdpcDec[rcLdpcClkLockGat/4]
#define  rmldecCkgIniSpd                         r32LdpcDec[rcLdpcClkLockGat/4]

#define  rcLdpcllrN2MapTab0                      0x0010
#define  rmllrn2map000                           r32LdpcDec[rcLdpcllrN2MapTab0/4]
#define  rmllrn2map001                           r32LdpcDec[rcLdpcllrN2MapTab0/4]
#define  rmllrn2map010                           r32LdpcDec[rcLdpcllrN2MapTab0/4]
#define  rmllrn2map011                           r32LdpcDec[rcLdpcllrN2MapTab0/4]

#define  rcLdpcllrN2MapTab1                      0x0014
#define  rmllrn2map100                           r32LdpcDec[rcLdpcllrN2MapTab1/4]
#define  rmllrn2map101                           r32LdpcDec[rcLdpcllrN2MapTab1/4]
#define  rmllrn2map110                           r32LdpcDec[rcLdpcllrN2MapTab1/4]
#define  rmllrn2map111                           r32LdpcDec[rcLdpcllrN2MapTab1/4]

#define  rcLdpcllrN3MapTab0                      0x0018
#define  rmllrn3map000                           r32LdpcDec[rcLdpcllrN3MapTab0/4]
#define  rmllrn3map001                           r32LdpcDec[rcLdpcllrN3MapTab0/4]
#define  rmllrn3map010                           r32LdpcDec[rcLdpcllrN3MapTab0/4]
#define  rmllrn3map011                           r32LdpcDec[rcLdpcllrN3MapTab0/4]

#define  rcLdpcllrN3MapTab1                      0x001C
#define  rmllrn3map100                           r32LdpcDec[rcLdpcllrN3MapTab1/4]
#define  rmllrn3map101                           r32LdpcDec[rcLdpcllrN3MapTab1/4]
#define  rmllrn3map110                           r32LdpcDec[rcLdpcllrN3MapTab1/4]
#define  rmllrn3map111                           r32LdpcDec[rcLdpcllrN3MapTab1/4]

#define  rcLdpcllrN4MapTab0                      0x0020
#define  rmllrn4map000                           r32LdpcDec[rcLdpcllrN4MapTab0/4]
#define  rmllrn4map001                           r32LdpcDec[rcLdpcllrN4MapTab0/4]
#define  rmllrn4map010                           r32LdpcDec[rcLdpcllrN4MapTab0/4]
#define  rmllrn4map011                           r32LdpcDec[rcLdpcllrN4MapTab0/4]

#define  rcLdpcllrN4MapTab1                      0x0024
#define  rmllrn4map100                           r32LdpcDec[rcLdpcllrN4MapTab1/4]
#define  rmllrn4map101                           r32LdpcDec[rcLdpcllrN4MapTab1/4]
#define  rmllrn4map110                           r32LdpcDec[rcLdpcllrN4MapTab1/4]
#define  rmllrn4map111                           r32LdpcDec[rcLdpcllrN4MapTab1/4]

#define  rcLdpcllrN6MapTab0                      0x0028
#define  rmllrn6map000                           r32LdpcDec[rcLdpcllrN6MapTab0/4]
#define  rmllrn6map001                           r32LdpcDec[rcLdpcllrN6MapTab0/4]
#define  rmllrn6map010                           r32LdpcDec[rcLdpcllrN6MapTab0/4]
#define  rmllrn6map011                           r32LdpcDec[rcLdpcllrN6MapTab0/4]

#define  rcLdpcllrN6MapTab1                      0x002C
#define  rmllrn6map111                           r32LdpcDec[rcLdpcllrN6MapTab1/4]
#define  rmllrn6map101                           r32LdpcDec[rcLdpcllrN6MapTab1/4]
#define  rmllrn6map101                           r32LdpcDec[rcLdpcllrN6MapTab1/4]
#define  rmllrn6map111                           r32LdpcDec[rcLdpcllrN6MapTab1/4]

#define  rcLdpcllrN8MapTab0                      0x0030
#define  rmllrn8map000                           r32LdpcDec[rcLdpcllrN8MapTab0/4]
#define  rmllrn8map001                           r32LdpcDec[rcLdpcllrN8MapTab0/4]
#define  rmllrn8map010                           r32LdpcDec[rcLdpcllrN8MapTab0/4]
#define  rmllrn8map011                           r32LdpcDec[rcLdpcllrN8MapTab0/4]

#define  rcLdpcllrN8MapTab1                      0x0034
#define  rmllrn8map100                           r32LdpcDec[rcLdpcllrN8MapTab1/4]
#define  rmllrn8map101                           r32LdpcDec[rcLdpcllrN8MapTab1/4]
#define  rmllrn8map110                           r32LdpcDec[rcLdpcllrN8MapTab1/4]
#define  rmllrn8map111                           r32LdpcDec[rcLdpcllrN8MapTab1/4]

#define  rcLdpcArbitConfig                       0x0038
#define  rmAllocStrategy                         r32LdpcDec[rcLdpcArbitConfig/4]
#define  rmsingleDecodeModeSel                   r32LdpcDec[rcLdpcArbitConfig/4]

#define  rcLdpcArbitInfor                        0x003C
#define  rmSurvivalXfrgroupList                  r32LdpcDec[rcLdpcArbitInfor/4]
#define  rmArbiter0RemanentCodeword              r32LdpcDec[rcLdpcArbitInfor/4]
#define  rmArbiter1RemanentCodeword              r32LdpcDec[rcLdpcArbitInfor/4]
#define  rmArbiter0RemanentXfrgroup              r32LdpcDec[rcLdpcArbitInfor/4]
#define  rmArbiter1RemanentXfrgroup              r32LdpcDec[rcLdpcArbitInfor/4]
#endif    // if 0

#define rcLdpcBFupperBound                       0x0040
#define rmLdpcSetBFupperbound(x)                 (r32LdpcDec[rcLdpcBFupperBound/4]=x)

#if 0    // This part need to check!!
#define rcLdpcDecSetting                         0x0044
#define rmNormalset                              r32LdpcDec[rcLdpcDecSetting/4]
#define rmTsTarget                               r32LdpcDec[rcLdpcDecSetting/4]
#define rmTsLimit                                r32LdpcDec[rcLdpcDecSetting/4]

#define rcLdpcMaxIterBF                          0x0048
#define rmMaxiterBf                              r32LdpcDec[rcLdpcMaxIterBF/4]

#define rcLdpcMaxIterN2                          0x004C
#define rmMaxiterB2                              r32LdpcDec[rcLdpcMaxIterN2/4]

#define rcLdpcMaxIterN3                          0x0050
#define rmMaxiterN3                              r32LdpcDec[rcLdpcMaxIterN3/4]

#define rcLdpcMaxIterN4                          0x0054
#define rmMaxiterN4                              r32LdpcDec[rcLdpcMaxIterN4/4]

#define rcLdpcMaxIterN6                          0x0058
#define rmMaxiterN6                              r32LdpcDec[rcLdpcMaxIterN6/4]

#define rcLdpcMaxIterN8                          0x005C
#define rmMaxiterN8                              r32LdpcDec[rcLdpcMaxIterN8/4]

#define rcLdpcMaxIterSoftDec                     0x0060
#define rmDec0MaxiterSoftDec                     r32LdpcDec[rcLdpcMaxIterSoftDec/4]
#define rmDec1MaxiterSoftDec                     r32LdpcDec[rcLdpcMaxIterSoftDec/4]

#define rcLdpcDec0llrMapLDW                      0x0070
#define rmllrMapping0L                           r32LdpcDec[rcLdpcDec0llrMapLDW/4]

#define rcLdpcDec0llrMapHDW                      0x0074
#define rmllrMapping0H                           r32LdpcDec[rcLdpcDec0llrMapHDW/4]

#define rcLdpcDec1llrMapLDW                      0x0078
#define rmllrMapping1L                           r32LdpcDec[rcLdpcDec1llrMapLDW/4]

#define rcLdpcDec1llrMapHDW                      0x007C
#define rmllrmapping1H                           r32LdpcDec[rcLdpcDec1llrMapHDW/4]

#define rcLdpcDoutIdxDw0                         0x0080
#define rmDoutIdxDw0                             r32LdpcDec[rcLdpcDoutIdxDw0/4]

#define rcLdpcDoutIdxDw1                         0x0084
#define rmDoutIdxDw1                             r32LdpcDec[rcLdpcDoutIdxDw1/4]

#define rcLdpcDoutIdxDw2                         0x0088
#define rmDoutIdxDw2                             r32LdpcDec[rcLdpcDoutIdxDw2/4]

#define rcLdpcDoutIdxDw3                         0x008C
#define rmDoutIdxDw3                             r32LdpcDec[rcLdpcDoutIdxDw3/4]
#endif    // if 0

#endif    // ifndef __REG_LDPC_H__







