







#ifndef __GLOBVAR0_H__
#define __GLOBVAR0_H__

#include "inc/TypeDef.h"
#include "inc/Const.h"
#include "inc/table.h"

// -----------------Domain0----------------//
// #pragma default_variable_attributes = @ ".R8_SysCtrl0"
extern volatile BYTE rSysCtrl0[0x400];
// #pragma default_variable_attributes =

// #pragma default_variable_attributes = @ ".R16_SysCtrl0"
extern volatile WORD r16SysCtrl0[0x200];
// #pragma default_variable_attributes =

// #pragma default_variable_attributes = @ ".R32_SysCtrl0"
extern volatile LWORD r32SysCtrl0[0x100];
// #pragma default_variable_attributes =

// #pragma default_variable_attributes = @ ".R8_EfuseCtrl"
extern volatile BYTE rEfuseCtrl[0x200];
// #pragma default_variable_attributes =

// #pragma default_variable_attributes = @ ".R16_EfuseCtrl"
extern volatile WORD r16EfuseCtrl[0x100];
// #pragma default_variable_attributes =

// #pragma default_variable_attributes = @ ".R32_EfuseCtrl"
extern volatile LWORD r32EfuseCtrl[0x80];
// #pragma default_variable_attributes =

// #pragma default_variable_attributes = @ ".R8_Tsb4Ctrl"
extern volatile BYTE rTsb4Ctrl[0x100];
// #pragma default_variable_attributes =

// #pragma default_variable_attributes = @ ".R16_Tsb4Ctrl"
extern volatile WORD r16Tsb4Ctrl[0x80];
// #pragma default_variable_attributes =

// #pragma default_variable_attributes = @ ".R32_Tsb4Ctrl"
extern volatile LWORD r32Tsb4Ctrl[0x40];
// #pragma default_variable_attributes =

// #pragma default_variable_attributes = @ ".R8_PCIe"
extern volatile BYTE rPcie[0x2000];
// #pragma default_variable_attributes =

// #pragma default_variable_attributes = @ ".R16_PCIe"
extern volatile WORD r16Pcie[0x1000];
// #pragma default_variable_attributes =

// #pragma default_variable_attributes = @ ".R32_PCIe"
extern volatile LWORD r32Pcie[0x800];
// #pragma default_variable_attributes =

// #pragma default_variable_attributes = @ ".R8_NVMe0"
extern volatile BYTE rNvme0[0x2000];
// #pragma default_variable_attributes =

// #pragma default_variable_attributes = @ ".R16_NVMe0"
extern volatile WORD r16Nvme0[0x1000];
// #pragma default_variable_attributes =

// #pragma default_variable_attributes = @ ".R32_NVMe0"
extern volatile LWORD r32Nvme0[0x800];
// #pragma default_variable_attributes =

// -----------------Domain2----------------//
// #pragma default_variable_attributes = @ ".R8_BvacCtrl"
extern volatile BYTE rBvacCtrl[0x100];
// #pragma default_variable_attributes =

// #pragma default_variable_attributes = @ ".R16_BvacCtrl"
extern volatile WORD r16BvacCtrl[0x80];
// #pragma default_variable_attributes =

// #pragma default_variable_attributes = @ ".R32_BvacCtrl"
extern volatile LWORD r32BvacCtrl[0x40];
// #pragma default_variable_attributes =

// #pragma default_variable_attributes = @ ".R8_VIC0"
extern volatile BYTE rSvic0[0x1000];
// #pragma default_variable_attributes =

// #pragma default_variable_attributes = @ ".R16_VIC0"
extern volatile WORD r16Svic0[0x800];
// #pragma default_variable_attributes =

// #pragma default_variable_attributes = @ ".R32_VIC0"
extern volatile LWORD r32Svic0[0x400];
// #pragma default_variable_attributes =

// #pragma default_variable_attributes = @ ".R64_VIC0"
extern volatile QWORD r64Svic0[0x200];
// #pragma default_variable_attributes =

// #pragma default_variable_attributes = @ ".R8_VIC1"
extern volatile BYTE rSvic1[0x1000];
// #pragma default_variable_attributes =

// #pragma default_variable_attributes = @ ".R16_VIC1"
extern volatile WORD r16Svic1[0x800];
// #pragma default_variable_attributes =

// #pragma default_variable_attributes = @ ".R32_VIC1"
extern volatile LWORD r32Svic1[0x400];
// #pragma default_variable_attributes =

// #pragma default_variable_attributes = @ ".R64_VIC1"
extern volatile QWORD r64Svic1[0x200];
// #pragma default_variable_attributes =

// #pragma default_variable_attributes = @ ".R8_AUX"
extern volatile BYTE rAux[0x1000];
// #pragma default_variable_attributes =

// #pragma default_variable_attributes = @ ".R16_AUX"
extern volatile WORD r16Aux[0x800];
// #pragma default_variable_attributes =

// #pragma default_variable_attributes = @ ".R32_AUX"
extern volatile LWORD r32Aux[0x400];
// #pragma default_variable_attributes =

// #pragma default_variable_attributes = @ ".R8_COH"
extern volatile BYTE rCoh[0x1000];
// #pragma default_variable_attributes =

// #pragma default_variable_attributes = @ ".R16_COH"
extern volatile WORD r16Coh[0x800];
// #pragma default_variable_attributes =

// #pragma default_variable_attributes = @ ".R32_COH"
extern volatile LWORD r32Coh[0x400];
// #pragma default_variable_attributes =

// #pragma default_variable_attributes = @ ".R8_DramCtrl"
extern volatile BYTE rDramCtrl[0x2000];
// #pragma default_variable_attributes =

// #pragma default_variable_attributes = @ ".R16_DramCtrl"
extern volatile WORD r16DramCtrl[0x1000];
// #pragma default_variable_attributes =

// #pragma default_variable_attributes = @ ".R32_DramCtrl"
extern volatile LWORD r32DramCtrl[0x800];
// #pragma default_variable_attributes =

// #pragma default_variable_attributes = @ ".APB_REG"
extern volatile BYTE rAPB[0x100000];
// #pragma default_variable_attributes =

// -----------------Domain1----------------//
// #pragma default_variable_attributes = @ ".R8_SysCtrl1"
extern volatile BYTE rSysCtrl1[0x100];
// #pragma default_variable_attributes =

// #pragma default_variable_attributes = @ ".R16_SysCtrl1"
extern volatile WORD r16SysCtrl1[0x80];
// #pragma default_variable_attributes =

// #pragma default_variable_attributes = @ ".R32_SysCtrl1"
extern volatile LWORD r32SysCtrl1[0x40];
// #pragma default_variable_attributes =

// #pragma default_variable_attributes = @ ".R8_BvaCtrl"
extern volatile BYTE rBvaCtrl[0x100];
// #pragma default_variable_attributes =

// #pragma default_variable_attributes = @ ".R16_BvaCtrl"
extern volatile WORD r16BvaCtrl[0x80];
// #pragma default_variable_attributes =

// #pragma default_variable_attributes = @ ".R32_BvaCtrl"
extern volatile LWORD r32BvaCtrl[0x40];
// #pragma default_variable_attributes =

// #pragma default_variable_attributes = @ ".R8_RsaCtrl"
extern volatile BYTE rRsaCtrl[0x200];
// #pragma default_variable_attributes =

// #pragma default_variable_attributes = @ ".R16_RsaCtrl"
extern volatile WORD r16RsaCtrl[0x100];
// #pragma default_variable_attributes =

// #pragma default_variable_attributes = @ ".R32_RsaCtrl"
extern volatile LWORD r32RsaCtrl[0x80];
// #pragma default_variable_attributes =

// #pragma default_variable_attributes = @ ".R8_I2cCtrl"
extern volatile BYTE rI2cCtrl[0x40];
// #pragma default_variable_attributes =

// #pragma default_variable_attributes = @ ".R16_I2cCtrl"
extern volatile WORD r16I2cCtrl[0x20];
// #pragma default_variable_attributes =

// #pragma default_variable_attributes = @ ".R32_I2cCtrl"
extern volatile LWORD r32I2cCtrl[0x10];
// #pragma default_variable_attributes =

// #pragma default_variable_attributes = @ ".R8_TsbCtrl"
extern volatile BYTE rTsbCtrl[0x800];
// #pragma default_variable_attributes =

// #pragma default_variable_attributes = @ ".R16_TsbCtrl"
extern volatile WORD r16TsbCtrl[0x400];
// #pragma default_variable_attributes =

// #pragma default_variable_attributes = @ ".R32_TsbCtrl"
extern volatile LWORD r32TsbCtrl[0x200];
// #pragma default_variable_attributes =

// #pragma default_variable_attributes = @ ".R8_ShaCtrl"
extern volatile BYTE rShaCtrl[0x80];
// #pragma default_variable_attributes =

// #pragma default_variable_attributes = @ ".R16_ShaCtrl"
extern volatile WORD r16ShaCtrl[0x40];
// #pragma default_variable_attributes =

// #pragma default_variable_attributes = @ ".R32_ShaCtrl"
extern volatile LWORD r32ShaCtrl[0x20];
// #pragma default_variable_attributes =

// #pragma default_variable_attributes = @ ".R8_TrngCtrl"
extern volatile BYTE rTrngCtrl[0x100];
// #pragma default_variable_attributes =

// #pragma default_variable_attributes = @ ".R16_TrngCtrl"
extern volatile WORD r16TrngCtrl[0x80];
// #pragma default_variable_attributes =

// #pragma default_variable_attributes = @ ".R32_TrngCtrl"
extern volatile LWORD r32TrngCtrl[0x40];
// #pragma default_variable_attributes =

// #pragma default_variable_attributes = @ ".R8_UartCtrl"
extern volatile BYTE rUartCtrl[0x100];
// #pragma default_variable_attributes =

// #pragma default_variable_attributes = @ ".R16_UartCtrl"
extern volatile WORD r16UartCtrl[0x80];
// #pragma default_variable_attributes =

// #pragma default_variable_attributes = @ ".R32_UartCtrl"
extern volatile LWORD r32UartCtrl[0x40];
// #pragma default_variable_attributes =

// #pragma default_variable_attributes = @ ".R8_EccDec"
extern volatile BYTE rEccDec[0x100];
// #pragma default_variable_attributes =

// #pragma default_variable_attributes = @ ".R16_EccDec"
extern volatile WORD r16EccDec[0x80];
// #pragma default_variable_attributes =

// #pragma default_variable_attributes = @ ".R32_EccDec"
extern volatile LWORD r32EccDec[0x40];
// #pragma default_variable_attributes =

// #pragma default_variable_attributes = @ ".R8_NBS"
extern volatile BYTE rNbs[0x200];
// #pragma default_variable_attributes =

// #pragma default_variable_attributes = @ ".R16_NBS"
extern volatile WORD r16Nbs[0x100];
// #pragma default_variable_attributes =

// #pragma default_variable_attributes = @ ".R32_NBS"
extern volatile LWORD r32Nbs[0x80];
// #pragma default_variable_attributes =

// #pragma default_variable_attributes = @ ".R8_BopCtrl"
extern volatile BYTE rBopCtrl[0x200];
// #pragma default_variable_attributes =

// #pragma default_variable_attributes = @ ".R16_BopCtrl"
extern volatile WORD r16BopCtrl[0x100];
// #pragma default_variable_attributes =

// #pragma default_variable_attributes = @ ".R32_BopCtrl"
extern volatile LWORD r32BopCtrl[0x80];
// #pragma default_variable_attributes =

// #pragma default_variable_attributes = @ ".R8_HdmaCtrl"
extern volatile BYTE rHdmaCtrl[0x200];
// #pragma default_variable_attributes =

// #pragma default_variable_attributes = @ ".R16_HdmaCtrl"
extern volatile WORD r16HdmaCtrl[0x100];
// #pragma default_variable_attributes =

// #pragma default_variable_attributes = @ ".R32_HdmaCtrl"
extern volatile LWORD r32HdmaCtrl[0x80];
// #pragma default_variable_attributes =

// #pragma default_variable_attributes = @ ".R8_LbaChk"
extern volatile BYTE rLbaChk[0x100];
// #pragma default_variable_attributes =

// #pragma default_variable_attributes = @ ".R16_LbaChk"
extern volatile WORD r16LbaChk[0x80];
// #pragma default_variable_attributes =

// #pragma default_variable_attributes = @ ".R32_LbaChk"
extern volatile LWORD r32LbaChk[0x40];
// #pragma default_variable_attributes =

// #pragma default_variable_attributes = @ ".R8_AesCtrl"
extern volatile BYTE rAesCtrl[0x800];
// #pragma default_variable_attributes =

// #pragma default_variable_attributes = @ ".R16_AesCtrl"
extern volatile WORD r16AesCtrl[0x400];
// #pragma default_variable_attributes =

// #pragma default_variable_attributes = @ ".R32_AesCtrl"
extern volatile LWORD r32AesCtrl[0x200];
// #pragma default_variable_attributes =

// #pragma default_variable_attributes = @ ".R8_SkipRam"
extern volatile BYTE rSkipRam[0x1000];
// #pragma default_variable_attributes =

// #pragma default_variable_attributes = @ ".R16_SkipRam"
extern volatile WORD r16SkipRam[0x800];
// #pragma default_variable_attributes =

// #pragma default_variable_attributes = @ ".R32_SkipRam"
extern volatile LWORD r32SkipRam[0x400];
// #pragma default_variable_attributes =

// #pragma default_variable_attributes = @ ".R8_FwAes"
extern volatile BYTE rFwAes[0x800];
// #pragma default_variable_attributes =

// #pragma default_variable_attributes = @ ".R16_FwAes"
extern volatile WORD r16FwAes[0x400];
// #pragma default_variable_attributes =

// #pragma default_variable_attributes = @ ".R32_FwAes"
extern volatile LWORD r32FwAes[0x200];
// #pragma default_variable_attributes =

// #pragma default_variable_attributes = @ ".R8_FakeCtrl"
extern volatile BYTE rFakeCtrl[0x1000];
// #pragma default_variable_attributes =

// #pragma default_variable_attributes = @ ".R16_FakeCtrl"
extern volatile WORD r16FakeCtrl[0x800];
// #pragma default_variable_attributes =

// #pragma default_variable_attributes = @ ".R32_FakeCtrl"
extern volatile LWORD r32FakeCtrl[0x400];
// #pragma default_variable_attributes =

// #pragma default_variable_attributes = @ ".R8_BvfORam"
extern volatile BYTE rBvfORam[0x4000];
// #pragma default_variable_attributes =

// #pragma default_variable_attributes = @ ".R16_BvfORam"
extern volatile WORD r16BvfORam[0x2000];
// #pragma default_variable_attributes =

// #pragma default_variable_attributes = @ ".R32_BvfORam"
extern volatile LWORD r32BvfORam[0x1000];
// #pragma default_variable_attributes =

// #pragma default_variable_attributes = @ ".R8_BvfBRam"
extern volatile BYTE rBvfBRam[0x4000];
// #pragma default_variable_attributes =

// #pragma default_variable_attributes = @ ".R16_BvfBRam"
extern volatile WORD r16BvfBRam[0x2000];
// #pragma default_variable_attributes =

// #pragma default_variable_attributes = @ ".R32_BvfBRam"
extern volatile LWORD r32BvfBRam[0x1000];
// #pragma default_variable_attributes =

// #pragma default_variable_attributes = @ ".R8_NVMe1"
extern volatile BYTE rNvme1[0x2800];
// #pragma default_variable_attributes =

// #pragma default_variable_attributes = @ ".R16_NVMe1"
extern volatile WORD r16Nvme1[0x1400];
// #pragma default_variable_attributes =

// #pragma default_variable_attributes = @ ".R32_NVMe1"
extern volatile LWORD r32Nvme1[0xA00];
// #pragma default_variable_attributes =

// #pragma default_variable_attributes = @ ".R8_NVMePrd"
extern volatile BYTE rNvmePrd[64][32];
// #pragma default_variable_attributes =

// #pragma default_variable_attributes = @ ".R16_NVMePrd"
extern volatile WORD r16NvmePrd[64][16];
// #pragma default_variable_attributes =

// #pragma default_variable_attributes = @ ".R32_NVMePrd"
extern volatile LWORD r32NvmePrd[64][8];
// #pragma default_variable_attributes =

// #pragma default_variable_attributes = @ ".R8_NVMeDesc"
extern volatile BYTE rNvmeDesc[64][32];
// #pragma default_variable_attributes =

// #pragma default_variable_attributes = @ ".R16_NVMeDesc"
extern volatile WORD r16NvmeDesc[64][16];
// #pragma default_variable_attributes =

// #pragma default_variable_attributes = @ ".R32_NVMeDesc"
extern volatile LWORD r32NvmeDesc[64][8];
// #pragma default_variable_attributes =

// #pragma default_variable_attributes = @ ".R8_NVMeHMB"
extern volatile BYTE rNvmeHmb[0xC000];
// #pragma default_variable_attributes =

// #pragma default_variable_attributes = @ ".R16_NVMeHMB"
extern volatile WORD r16NvmeHmb[0x6000];
// #pragma default_variable_attributes =

// #pragma default_variable_attributes = @ ".R32_NVMeHMB"
extern volatile LWORD r32NvmeHmb[0x3000];
// #pragma default_variable_attributes =

// #pragma default_variable_attributes = @ ".R8_FSHA"
extern volatile BYTE rFSHA[9][0x2000];
// #pragma default_variable_attributes =

// #pragma default_variable_attributes = @ ".R16_FSHA"
extern volatile WORD r16FSHA[9][0x1000];
// #pragma default_variable_attributes =

// #pragma default_variable_attributes = @ ".R32_FSHA"
extern volatile LWORD r32FSHA[9][0x800];
// #pragma default_variable_attributes =

// #pragma default_variable_attributes = @ ".R8_LDPcDsp"
extern volatile BYTE rLdpcDspCtrl[0x100000];
// #pragma default_variable_attributes =

// #pragma default_variable_attributes = @ ".R16_LDPcDsp"
extern volatile WORD r16LdpcDspCtrl[0x80000];
// #pragma default_variable_attributes =

// #pragma default_variable_attributes = @ ".R32_LDPcDsp"
extern volatile LWORD r32LdpcDspCtrl[0x40000];
// #pragma default_variable_attributes =

// #pragma default_variable_attributes = @ ".R8_LDPcDec"
extern volatile BYTE rLdpcDec[0x20000];
// #pragma default_variable_attributes =

// #pragma default_variable_attributes = @ ".R16_LDPcDec"
extern volatile WORD r16LdpcDec[0x10000];
// #pragma default_variable_attributes =

// #pragma default_variable_attributes = @ ".R32_LDPcDec"
extern volatile LWORD r32LdpcDec[0x8000];
// #pragma default_variable_attributes =

extern MPINFO gsMPInfo;
extern ERRORINFO garErrorLog[cMaxErrLogEntryCnt];
extern SMARTATTRIBUTE gsSmart;
extern POWERSTATE gsPowerState;
extern APSTTABLE garApstCurrent[4];
extern LWORD g32ApstEnable;
extern LWORD g32RtcStartTime1s;
extern BYTE gSupportL12;
extern BYTE gMt1In;
extern BYTE gMt2In;
extern BYTE gMt3In;
extern BYTE gMtSdIn;
extern BYTE gMt1Out;
extern BYTE gMt2Out;
extern BYTE gMt3Out;
extern BYTE gAsicMt3In;
extern BYTE gAsicMtSdIn;
extern BYTE gAsicMt1Out;
extern BYTE gBgdGCWakeUp;
extern LWORD g32IdleGcDelayTime;
extern BYTE gMasterState;
extern BYTE gXadmldle;
#if _EN_Delay_Dis_LTSSM
extern BYTE gGCRestFlg;
extern BYTE IORestFlg;
#endif    // #if _EN_Delay_Dis_LTSSM
extern BYTE gbsNvmeOpt1;
extern NVMEAERSTR gsNvmeAer;
#if (OEM==DELL)    // 20181010_Jesse_01, Add for Dell spec "ENG0013785_A01"
#if _ENABLE_SCP_PLP
extern BYTE gScpEnable;    // For FID D8h
#endif
#endif
extern WORD g16ValidSqBitmap;
extern WORD g16ValidCqBitmap;
extern WORD g16Cq2SqidBitmap[cMaxIoSqCqCnt];
// #pragma default_variable_attributes = @ ".CORE0_NVME_VAR"

// =============================================PCIe/NVMe/System USE
extern volatile BYTE gLtssmIntr0;
extern volatile BYTE gLtssmIntr1;
extern volatile BYTE gLtssmIntr2;

// volatile BYTE gLastInt;

extern QWORD g64LastTime;
// NVMe Get Log Page Cmd
extern LWORD g32ErrorCountL;
extern LWORD g32ErrorCountH;
extern INVALIDDBINFO gsInvalidDbInfo;
extern BYTE gErrLogPtr;
extern LWORD g32GrtPeCycle;
// LWORD g32PowerOnDphy7Cnt;
extern LWORD g32HostTotalDataSectorCnt;    // logic range host can access
extern LWORD g32MaxDataXfrSec;

extern BYTE gLpbkSt;

// extern BYTE garSerialNumber[20];
// extern BYTE garModelNumber[40];

// BYTE gFuaWrSta;
// BYTE gWritePrdCnt;

extern BYTE gbsCrlcBit;

// extern BYTE gHandlePcieRstInIsr;
extern BYTE gHostJustL1En;
extern BYTE gHostNoSetLtrEn;
extern BYTE gLtrEnabled;
extern BYTE gChgtoD0;
extern BYTE gL1TimeOutEnabled;
// BYTE gChkPerstF;

extern LWORD g32IntSrc;

// volatile BYTE garDbgTrace[32];

// Doorbell Patch
// extern WORD g16arCommandCount[];
// extern WORD g16CheckDbFlagBitmap;
// extern WORD g16ValidCqBitmap;
extern WORD g16CqEn;
// extern void (*dbPatch)(void);

extern LWORD g32LtrValue0;
extern LWORD g32LtrValue2;

// extern WORD g16ValidSqBitmap;
// extern WORD g16ValidCqBitmap;
// extern WORD g16Cq2SqidBitmap[cMaxIoSqCqCnt];

extern LWORD gar32BkMsixTab[64];

extern BYTE gUART_RxTrigger;    // gUartRxTrig  for security crypto library.

extern BYTE gDdrValue;
extern BYTE gGpio0PuBk;
extern BYTE gGpio0PdBk;
extern BYTE gGpio1PuBk;
extern BYTE gGpio1PdBk;
extern BYTE gGpio2PuBk;
extern BYTE gGpio2PdBk;

extern WORD g16SysClkPll;
extern BYTE gFlashAutoGate;
extern BYTE gDdrValue;
// extern BYTE gFlashPdTimer;  //unless

// extern BYTE gDisableTwoLevelPS4;
extern BYTE gTwoLevelPs4;
extern WORD g16Ps3StayTimeInTwoLevelPs4;
// extern LWORD g32BackgroundTime;
// extern LWORD g32PsStepDebug;  //for debug trace
// extern BYTE gLastInt;  //for debug trace

extern SANITIZE gsSanitizeInfo;

// =============================================Power Management and APST use
extern volatile LWORD g32PsStepDebug;
extern BYTE gLowPowerStateRetryCnt;
extern BYTE gApstRetryCnt;
extern BYTE gApstOngoing;
extern BYTE gApstOperationToPs3;
extern BYTE gApstPs3ToPs4;
extern BYTE gMsixTableFlag;
extern BYTE gLaneNumAcceptTimeoutCnt;

// extern BYTE gChkTemperature;
// extern BYTE gIdleThermalLogCnt;

extern WORD g16Code85;
extern WORD g16Code30;

#if APST_Timer
extern LWORD g32APSTTimeGap;    // 20190604_LeverYu_APST timing
#endif
extern LWORD g32ThermalMT1TransitionCount;
extern LWORD g32ThermalMT2TransitionCount;
extern LWORD g32ThermalMT3TransitionCount;
extern LWORD g32AsicThermalMT3TransitionCount;

extern BYTE gThermalThrottlingReason;

extern BYTE gThsor0Temperature;
// extern BYTE gThsor0TemperatureBk;
extern BYTE gThsor1Temperature;
extern BYTE gThermalOffset;

// extern BYTE gDebugStandbyMoF;
extern DEBUGINFO gsDebugInfo;

// extern BYTE gkeepSerialModelNumFlag;
extern BYTE gFwResetCpuForSec;    // FW Commit to Trig ResetCPU
extern BYTE gHashOffsetBk[32];

// =============================================Device Selt-Test
// extern DSTLOG gsNvmeDst;
extern DSTRESULT gsCurrDstResult;
// extern LWORD g32NvmeDstStartTimeMs;

// =============================================System USE
extern LWORD g32RtcStartTimeMs;
extern LWORD g32RtcStartTime2s;
extern LWORD g32RtcStandbyEntryTime;
extern LWORD g32RtcStandbyExitTime;
extern LWORD g32RtcStandbyEntryTimeBk;
extern LWORD g32RtcStandbyExitTimeBk;
extern LWORD g32BackgroundTimeMs;
extern BYTE gSensorPollingInterval;
extern BYTE gChkTemperature;
extern BYTE gCpu0TOFlag;
// extern BYTE gSysTmrOn;
extern LWORD g32arRWTickCnt[8];
extern BYTE gRWTickCntPtr;
extern BYTE gSmartBackup;
extern LWORD g32SleepStartTime1s;

// ============================================Security
#if 1    // _ENABLE_SECAPI
// --- Not only used in Security (from ".SecurityAPI_Var_BaseFW") ---//
// =====Need to be initialized for Power-cycle and DevSlp=======
extern BYTE gMBRShadow;
extern BYTE gLockingStatus;
extern BYTE gTcgNviSpLockingLifeCycleState;
extern BYTE gMbrRangeHit;
extern BYTE gMbrReturnZero;
extern BYTE gMbrRedirectPassAes;
extern BYTE gMbrDummyReturn;
extern LWORD g32SessionTimerStart;
extern LWORD g32MaxSessionTimeout;

// =====Don't need to be initialized for Power-cycle and DevSlp=======
extern LWORD g32ReceivedXfrByte;
extern LWORD g32ReceivedXfrCnt;
// ------------------------------------------------------//

extern WORD g16SecTrimPtr;
// extern LWORD g32SecTrimLba[16];
// extern LWORD g32SecTrimXfrCnt[16];

// --- Not only used in Security (from ".SecurityVar") ---//
/* Used in MemoryAllocate() */
extern LWORD g16TempRamPtr;
extern LWORD g16TempRamStackPtr;
// --------------------------------------------//
extern WORD g16BackupWriteBufPtr;

/* Used in backup buffer flag */
extern LWORD g32TempBufFlag[24];    // 384KB / 4KB (1B flag means 4KB)

#endif    // if _ENABLE_SECAPI

extern PCIEERRLOGINFO gsPcieErrInfo;
#if (_EN_PERST_WAKEINLOWPOWER)
extern BYTE gHandlePerstInIsrForLowPower;
#endif
// #pragma default_variable_attributes =

// #pragma default_variable_attributes = @ ".CORE0_LS_VAR"    // LightSwitch 384K
extern LIGHTSWITCH gsLightSwitch;
// #pragma default_variable_attributes =

// #pragma default_variable_attributes = @ ".CORE0_FL_VAR"

// LOGINFO gsLogInfo;

extern LWORD g32ISPBlockSerial[4];

// =============================================FTL/CTL USE
extern volatile BYTE *rFLCtrl;
extern volatile WORD *r16FLCtrl;
extern volatile LWORD *r32FLCtrl;

extern volatile BYTE *rLdpcDsp;    // 0x51200000
extern volatile WORD *r16LdpcDsp;
extern volatile LWORD *r32LdpcDsp;

// LWORD gCPUCycleCnt[23];
extern ADDRINFO *gpFlashAddrInfo;
extern HADDRINFO gsWriteHAddrInfo;
extern HADDRINFO gsReadHAddrInfo[cPrdDepth];
extern HMBINFO gsHmbInfo;
// F2HINFO garDesF2hInfo[cWriteFifoDpt];

extern HADDRINFO *gpHostAddrInfo;

extern WORD g16WriteBufPtr;
extern WORD g16FlashWBufPtr;

// WORD g16NowH2fTabFAddr;
// LWORD g32NowSrcFAddr;

extern LWORD g32SectorPerHBlock;
// LWORD g32SectorPerFBlock;
extern LWORD g32MaxCachePageNum;
// BYTE gReadDummySrc;
// extern BYTE gChgBlock;

extern LWORD g32LastLbaW;
extern LWORD g32LastLbaR;
// BYTE gbSeqAccess;
// BYTE gbChgBlock;
// extern BYTE gbCacheInBuf;
extern BYTE gLastTrigPrdTaskType;
extern WORD g16SrchSrcTabFreePtr;
// _Uncached H2FTABLE garSrchSrcTab[cMaxQDept*4];//512b
extern UCLWORD garSrchSrcTab[cSrchSrcNum];    // 1KB
extern UCLWORD g32arSrcInCacheFlag[c16MaxH2fTabNum/32];    // 1kb

extern BYTE garH2f1kTabSgmtExpire[cMaxRH2fTabNum];    // 32b
// BYTE garH2f1kTabSgmtIdx[cMaxRH2fTabNum];    // 32b
// extern LWORD g32arH2f1kTabSgmt[cMaxRH2fTabNum];    // 128b

// WORD g16FakeCmdPtr;

// LWORD g32DramWrPtr;
// LWORD g32DramRdF2hHitPtr;

// WORD g16DRAMPLL;

// LWORD g32TempCachePtr;
extern BYTE gReadFlag;
extern BYTE gActiveCe;

// extern WORD g16arCurrSysBlkEsCnt[cRsvSysBlkNum];    // current system block erased count
extern WORD g16TotalPlaneOfISP[4];
// WORD g16DgFifoFullCnt;
// WORD g16IdxBlkFreePagePtr;

// flashprogpage use, should in share

// RAID related
extern WORD g16GcDesF2hPadStartAddr;
extern WORD g16PadF2hTabPgStr;
extern WORD g16PadF2hTabPgEnd;
extern WORD g16ProgF2hTabStr;
extern WORD g16ProgF2hTabEnd;
extern WORD g16SlcPadF2hTabPgStr;
extern WORD g16SlcPadF2hTabPgEnd;
extern WORD g16SlcProgF2hTabStr;
extern WORD g16SlcProgF2hTabEnd;
extern WORD g16ChkFlushSize;
extern WORD g16FlushStr4K;
extern WORD g16FlushRem4K;
extern WORD g16FlushChkStart;
extern WORD g16SlcF2hChkStart;
extern WORD g16SlcF2hChkSize;
extern WORD g16TlcF2hChkStart;
extern WORD g16TlcF2hChkSize;
extern WORD g16TlcProgRaidChStr4K;
extern WORD g16SlcProgRaidChStr4K;
extern WORD g16ProgRaidUnit;
extern WORD g16Raid4KStrInPage;
extern WORD g16PartialRaidUnit;
// LWORD* g32arGlobEraseCnt; //2kb

extern BYTE gSlc4KNumToPadF2h;
extern BYTE gSlcProgF2HRem4KNum;
extern BYTE gTlc4KNumToPadF2h;
extern BYTE gTlcProgF2HRem4KNum;
extern BYTE gFWShnFlag;
extern LWORD g32BgdGCSkipResetCnt;
// extern BYTE gRsvCacheF2h;
// extern WORD g16F2hTabHitPtr;

extern WORD g16WriteHMBH2FTable[cHmbRacingFreeCnt];
extern BYTE gWriteHMBIndex;

// extern WORD g16GCOneShot4kCnt;
// extern BYTE gGc4kNumPerMaxProgUnit;
extern LWORD g32arHmbTabDirty[c16HmbMaxTableNumAlign/32];    // if set 1, indicate the H2f tab on HMB is modified and not sync to NAND flash
extern SORTF2HTAB *gpSortF2hTab;
extern WORD g16VPCTrimStartIdx;
extern BYTE gSecuEfuse[128];
extern BYTE gOpRomRead;
extern WORD g16arMskRptF2hOfst[c16MskRptF2hOfstDpt];
extern volatile PS4BACKUP *gpBkPS4Data;

extern LWORD *gp32WriteRangeStart;    // 9 elements
extern LWORD *gp32WriteRangeEnd;    // 9 elements
extern LWORD *gp32ReadRangeStart;    // 9 elements
extern LWORD *gp32ReadRangeEnd;    // 9 elements
extern BYTE *gpMBRValidBitMap;    // 4416 elements

extern LWORD g32arWriteRangeStart[9];    // 9 elements
extern LWORD g32arWriteRangeEnd[9];    // 9 elements
extern LWORD g32arReadRangeStart[9];    // 9 elements
extern LWORD g32arReadRangeEnd[9];    // 9 elements
extern BYTE garMBRValidBitMap[4416];    // 4416 elements
#if _EN_WUNCTable    // WUNCTable Chief_21081121
extern WUNCInfo gsWUNCInfo;
#endif
#if _EN_WriteZeroNonAlign    // WUNCTable Chief_21081121
extern WZNonAlginInfo gsWZInfo[C_MaxNonAlginCnt];
extern WORD gsWZCnt;
#endif
extern LWORD g32BaseFwShaTotalSize;    // 20181226_SamHu_01 sync Dennis code for R/W command insert DownloadFW
#if _EN_FWCommit_Protect
extern BYTE gJustReturnPass;
#endif
extern BYTE gDLFWFail;
#if (OEM==LENOVO)    // 20190108_SamHu_01 add for Lenovo 1.26 Spec Log DFh
extern BYTE garLenovoLogDFhSN[30];
extern BYTE garLenovoLogDFhNewSN[30];
#endif
extern BYTE i2cSetPS4CoreIndex[2];    // 2019_0315 LeverYu CorePower Learning
#if _EN_CmdDelayBGC
extern LWORD g32CmdNoGC1s;
#endif
#pragma default_variable_attributes =
#endif    // end of __MEMORY_H__







