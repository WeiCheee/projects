







#ifndef __SECURITY_H__
#define __SECURITY_H__

#include "Crypto_Library.h"

#define cKeyWrapPaddingSize                     8

/*==================== Flash Allocate ====================*/

#define cSecNonWriten                           0xFFFFFFFF

#define mChkTcgDataValid(x, y)                  x[y>>3]&cbBitTab[y&0x07]
#define mSetTcgDataValid(x, y)                  x[y>>3]|=cbBitTab[y&0x07]
#define mClrTcgDataValid(x, y)                  x[y>>3]&=~cbBitTab[y&0x07]

/*==================== SHA ====================*/
// Status code
#define cShaSuccess                             0
#define cShaFailure                             1

// Status code
#define cSha256Success                          0
#define cSha256Failure                          1

// Parameter
#define cSha1                                   160
#define cSha224                                 224
#define cSha256                                 256
#define cSha384                                 384
#define cSha512                                 512

#define cShaStart                               cBit0
#define cShaEnd                                 cBit1
#define cShaMiddle                              0

#define cShaInputSize                           64
#define cShaOutputSize                          32

/*==================== RSA ====================*/
#define cLengthRsaSsa                           2048

#define cKeyHierarchySuccess                    0
#define cKeyHierarchyFail                       1

#define cKeyWrappingIcv                         8
#define cDefaultKeySize                         64    // 2 AES keys are equal to 512-bits for XTS mode.
#define cMekSize                                64

#define cEncryptedSize                          (cRootKeySize+cKeyWrappingIcv)
#define cEncryptedDefaultKeySize                (cDefaultKeySize+cKeyWrappingIcv)

// TSB0 allocation  unit of 512 byte
#define cSecurityApiBufferAddr          0x40010000

#define cSecurityCommandReserved                1
#define cSecurityTabSize                        128
#define cHdrbgTabSize                           128
#define cFdeTabSize                             128
#define cHdrbgTabOfSecurity                     (cSecurityCommandReserved+cSecurityTabSize)
#define cFdeTabOfSecurity                       (cHdrbgTabOfSecurity+cHdrbgTabSize)

#define cPasswordSize                           32
#define cSp800_38fEncryptedSize                 40
#define cSp800_38fEncryptedDeKeySize            72

// Security.c
void resetRam(BYTE *, LWORD, BYTE);
BYTE memoryCompareAddress(LWORD, LWORD, LWORD);
void reverseArray(BYTE *, LWORD);
LWORD memoryAllocate(BYTE, WORD, LWORD);
void memoryRelease(LWORD);
void moveMem2Mem(LWORD, LWORD, LWORD);
void gatherSecurityPageInfo();
void updataSecurityKeyInfo();
BYTE changeAesKey(BYTE, LWORD, BYTE, BYTE, BYTE, BYTE);
BYTE processCryptoErase();
void genKek();
void restoreKek(BYTE *);
void initAesDefaultKey(BYTE);
void getRandom(LWORD, BYTE *);
void modifyMeks(BYTE *);
void restoreAesKey();
#endif    // ifndef __SECURITY_H__







