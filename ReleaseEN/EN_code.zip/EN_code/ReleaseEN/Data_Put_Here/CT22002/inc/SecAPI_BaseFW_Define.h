







#ifndef __SECAPI_DEFINE_BASEFW_H__
#define __SECAPI_DEFINE_BASEFW_H__

#if (_ENABLE_SECAPI||_ENABLE_SECAPI_PRET)
// ----------------Used in SecAPI_FuncPtr_BaseFW.h----------------
#define BASE_FIRMWARE_CORE

/*==================== Memory Allocate ====================*/
// Import Host Data / RW Buffer 64K  0x40000000
#define cTrustedRwBufferAddr                    0x40000000
#define cTrustedRwBufferStartBufIdx             0
#define cTrustedRwBufferIdxSize                 128
#define cTrustedRwBufferBufSize                 (cTrustedRwBufferIdxSize*512)

// Most of the Security Algorithm   64K     0x40010000
#define cSecurityAlgorithmAddr                  0x40010000
#define cSecurityAlgorithmStartBufIdx           128

// CryptoLibrary (Code)             16K     0x40020000
#define cTrustedCryptoLibAddr                   0x40020000
#define cTrustedCryptoLibStartBufIdx            256

// BaseFW (Code, Const)             16K     0x40024000
// SecAPI_FunPtr                    1K      0x40028000
// SecurityFW (Code, Const)         151K    0x40028400
// CryptoLibrary (Variables)        6K+960B 0x4004E000
// garSHABuffer                     1K+64B  0x4004FBC0

// IF-SEND Payload Buffer 32K 0x40050000
#define cTrustedIfSendAddr                      0x40050000
#define cTrustedIfSendStartBufIdx               640
#define cTrustedIfSendIdxSize                   64
#define cTrustedIfSendBufSize                   (cTrustedIfSendIdxSize*512)

// IF-RECV Payload Buffer 32K 0x40058000
#define cTrustedIfRecvAddr                      0x40058000
#define cTrustedIfRecvStartBufIdx               704
#define cTrustedIfRecvIdxSize                   64
#define cTrustedIfRecvBufSize                   (cTrustedIfRecvIdxSize*512)

// ======================================TCG=============================
// ----------------Not Only Used in SecurityFW----------------
/*Const Values*/
#define cTcgMbrSize                         128    // MB
#define cTcgDataStoreSize                   10    // MB

#if 1
#ifdef _FDE_DRIVE
#define cTcgReserveSecCnt                       ((cTcgMbrSize+cTcgDataStoreSize)<<12)    // zone0 and zone1; (128+10)*2=276MB
#else
#define cTcgReserveSecCnt                       (gbEnTCG?((cTcgMbrSize+cTcgDataStoreSize)<<12):0)    // zone0 and zone1; (128+10)*2=276MB
#endif
#else
#if _ENABLE_SECAPI
#define cTcgReserveSecCnt                                       ((cTcgMbrSize+cTcgDataStoreSize)<<12)    // zone0 and zone1; (128+10)*2=276MB
#else
#define cTcgReserveSecCnt                                       0
#endif
#endif

#define cTcgValidUnitBitMapSize                     ((((cTcgMbrSize+cTcgDataStoreSize)<<8)+8-1)/8)    // <<8 is 1 MB / 4KB = 256, 1M has 256
// unit
#define cTcgH2fMapSize                                          ((cTcgMbrSize+cTcgDataStoreSize)<<8)    // <<8 is 1 MB / 4KB = 256, 1M has 256
// unit
#define cTcgTotalHostHPage                                      ((g32TotalDatSector-cTcgReserveSecCnt)>>cSctrTo4kShift)
#define C_TCG_NonWriten                                         0xFFFFFFFF

#define C_PSID_SIZE                                                     32
#define C_MSID_SIZE                                                     16

#define C_TrustRecvBufSize                                      (32*1024)

/*  Locking Feature : Status  */
#define B_TCG_LOCK_STS_READ_LOCKED          cBit7
#define B_TCG_LOCK_STS_WRITE_LOCKED                             cBit6
#define B_TCG_LOCK_STS_MBR_DONE                                 cBit5
#define B_TCG_LOCK_STS_MBR_ENABLED                              cBit4
#define B_TCG_LOCK_STS_MEDIA_ENCRYPTION                 cBit3    // for Locking Feature Descriptor
#define B_TCG_LOCK_STS_LOCKED                                           cBit2
#define B_TCG_LOCK_STS_LOCKING_ENABLED                  cBit1    // for Locking Feature Descriptor
#define B_TCG_LOCK_STS_LOCKING_SUPPORTED                cBit0    // for Locking Feature Descriptor

/*  Max Ranges  */
#define cTcgMaxRange                            0x08

/* Range Policy Update */
#define cMbrUpdate                              cBit0
#define cLockingStatusUpdate                    cBit1
#define cTcgNviSpLockingLifeCycleStateUpdate    cBit2

/* Check Security */
#define cChkSecurityEnable                      0
#define cChkSecurityLock                        1

/* Range Register Update */
#define cEnableRange                cBit0
#define cDisableRange               cBit1

/* KeyWrapping Direction */
#define cEncrypt                    cBit0
#define cDecrypt                    cBit1

/* SP LifeCycle */
#define C_Manufactured_Inactive         0x08
#define C_Manufactured                          0x09

/* Memory Usage */
#define Memory_Allocate                         cBit0
#define Memory_Release                          cBit1

/* Session Timeout */
#define cDefaultSessionTimeout      300000    // If EnSessionTimer=0, C_Default_SessionTimeout=0; If EnSessionTimer=1, C_Default_SessionTimeout
// should be bigger than 5000(ms)(C_TCG_TPER_MIN_SESSION_TIMEOUT)
#define cSessionTimeoutStart        cBit0
#define cSessionTimeoutStop             cBit1

/* Initial Usage */
#define cInitNormal                     cBit0
#define cInitForce                      cBit1
#define cInitSwap                       cBit2

/* BackupResume Actions*/
#define cDevSlpBackup                           cBit0
#define cDevSlpResume                           cBit1
#define cSwapBackup                             cBit2
#define cSwapResume                             cBit3

/* Reset Types*/
#define cPCIeRst                                        cBit0
#define cNSSR                                           cBit1

/* Prd SecFlag */
#define cMbrDummyReturn             cBit0
#define cMbrRedirectPassAes         cBit1

/*Trim Invalid Pages*/
typedef enum
{
    C_TCG_TrimOriginBitmap=0,
    C_TCG_TrimUpdateBitmap=1,
    C_TCG_SPORTrimBitMap=2,
    C_TCG_TrimAll=3
}trim_e;

/*  Range ID  */
typedef enum
{
    cRangeIdRange1=1,
    cRangeIdRange2,
    cRangeIdRange3,
    cRangeIdRange4,
    cRangeIdRange5,
    cRangeIdRange6,
    cRangeIdRange7,
    cRangeIdRange8,
    cRangeIdGlobalRange=0xFF
}range_id_e;

/* SecIntf_MOVE_MEM2MEM */
typedef enum
{
    cDmaTsb2Tsb=0,
    cDmaTsb2Bvci=1,
    cDmaBvci2Tsb=2,
    cDmaBvci2Bvci=3,
    cDmaTsb2Dccm=4,
    cDmaDccm2Tsb=5,
    cDmaIccm2Tsb=6,
    cDmaTsb2Iccm=7,
    cDmaTsb2Stcm=8,
    cDmaStcm2Tsb=9,
    cDmaBoundary=10,

    // Not Handled in SM2260
    cDmaDccm2Bvci=0xFF
}mem_type_e;

/* TPer Error ID according to SIIS */
typedef enum
{
    cGood=0,
    cInvalidProtocolId=1,
    cInvalidTransferLength=2,
    cOtherInvalidCommand=3,
    cSynchronousProtocolViolation=4,
    cDataProtectionError=5,
    cInvalidSecurityState=6,
    cAccessDenied=7,
#if _ENABLE_ATA_PASSTHROUGH
    cATASecurityCmdError=8,
    cATASecurityLocked=9,
#endif

    // Special execution
    cFaultyGood=0xC0,
    cNoDataGood=0xC1,
    cInvalidTransferLengthIEEE1667=0xC2,
    cNoAllocationLength=0xE0,
    cCommandAborted=0xE1
}tper_error_id_e;

/* SecIntf_TCG_Read or SecIntf_TCG_Write */
typedef enum
{
    cRwSuccess=0,
    cRwReadOnly=1,
    cRwNoXfrCnt=2,
    cRwUnc=3,
    cRwFail=4
}rw_status_e;

// ----------------Only Used in BaseFW----------------
/* SecAPI_ChkStackOverFlow */
#define cSVCStackEnd                0x27200
#define cIRQStackEnd                0x27800

#define C_TSBAddr_SecAPI                        0x40080000    // Please be aware of buffer wrap

/* Check Locking Status */
#define rmChkReadLock               (gLockingStatus&B_TCG_LOCK_STS_READ_LOCKED)
#define rmChkWriteLock              (gLockingStatus&B_TCG_LOCK_STS_WRITE_LOCKED)

/* Range hit */
typedef enum
{
    cRangeMiss=0,
    cRangeHit=1,
    cRangeFullyOverlap=2
}range_hit_e;

// ----------------From SecurityFW For Reference----------------

// ======================================IEEE=============================

// ----------------Not Only Used in SecurityFW----------------

// ----------------Only Used in BaseFW----------------

// ----------------From SecurityFW For Reference----------------

// ======================================ATA Security========================

#if _ENABLE_ATA_PASSTHROUGH
// ----------------Not Only Used in SecurityFW----------------
#define rmSetSecurityErasePrepare       gSecurityStatus|=cBit0
#define rmClrSecurityErasePrepare       gSecurityStatus&=~cBit0
#define rmChkSecurityErasePrepare           (gSecurityStatus&cBit0)

#define rmSetSecurityEnable             gSecurityStatus|=cBit1
#define rmClrSecurityEnable             gSecurityStatus&=~cBit1
#define rmChkSecurityEnable             (gSecurityStatus&cBit1)

#define rmSetSecurityLock               gSecurityStatus|=cBit2
#define rmClrSecurityLock               gSecurityStatus&=~cBit2
#define rmChkSecurityLock               (gSecurityStatus&cBit2)

#define rmSetSecurityFrozen             gSecurityStatus|=cBit3
#define rmClrSecurityFrozen                 gSecurityStatus&=~cBit3
#define rmChkSecurityFrozen             (gSecurityStatus&cBit3)

#define rmSetSecurityCountExpired       gSecurityStatus|=cBit4
#define rmClrSecurityCountExpired       gSecurityStatus&=~cBit4
#define rmChkSecurityCountExpired       (gSecurityStatus&cBit4)

#define rmSetSecurityUserPassword       gSecurityStatus|=cBit5
#define rmClrSecurityUserPassword       gSecurityStatus&=~cBit5
#define rmChkSecurityUserPassword       (gSecurityStatus&cBit5)

#define rmSetSecurityMasterPassword     gSecurityStatus|=cBit6
#define rmClrSecurityMasterPassword     gSecurityStatus&=~cBit6
#define rmChkSecurityMasterPassword     (gSecurityStatus&cBit6)
#define rmRetainSecurityMasterPassword  gSecurityStatus&=cBit6

#define rmSetSecCommandErr              (gSecurityStatus|=cBit7)
#define rmClrSecCommandErr              (gSecurityStatus&=~cBit7)
#define rmChkSecCommandErr              (gSecurityStatus&cBit7)

/* Update ATA Security Status Actions*/
#define cUpdateBaseFW                           cBit0
#define cUpdateSecurityFW                       cBit1

typedef enum
{
    cAtaSecuritySetPassword=1,
    cAtaSecurityUnlock=2,
    cAtaSecurityErasePrepare=3,
    cAtaSecurityErase=4,
    cAtaSecurityFreezeLock=5,
    cAtaSecurityDisablePassword=6
}ata_comid_e;

// ----------------Only Used in BaseFW----------------

// ----------------From SecurityFW For Reference----------------

#endif    // if _ENABLE_ATA_PASSTHROUGH

#endif    // if (_ENABLE_SECAPI||_ENABLE_SECAPI_PRET)

/*==================== HDRBG ====================*/
#define cHdrbgInstanitate                   (0)
#define cHdrbgReseed                        (1)
/*  Status code  */
#define cHdrbgSuccess                       (0)
#define cHdrbgErrorFlag                     (1)
// #define C_HDRBG_CATASTROPHIC_ERROR_FLAG     (2)
#define cHdrbgReseedRequired                 (3)
// ---length------//
#define cHdrbgSeedLen_I                     (440)    // bits
#define cHdrbgSeedLen_O                     (440>>3)    // bytes
#define cHdrbgHLen_I                        (cSha256)    // bits
#define cHdrbgHLen_O                        (cSha256>>3)    // bytes
#define cHdrbgMaxSupportSeedLength_O        (440>>3)
/*  parameter  */
#define cHdrbgMaxNumberOfBitsPerRequest     (2048)
#define cHdrbgReseedInterval                (10000)
// #define C_HDRBG_MAX_PERSONALIZATION_STRING_LENGTH_I     (512)
// #define C_HDRBG_MAX_ADDITIONAL_INPUT_STRING_LENGTH_I    (512)
// #define C_HDRBG_MAX_LENGTH                              (1000)
// #define C_HDRBG_MAX_SUPPORT_HASH_LENGTH_I                C_SHA256

// security error code
// #define  cSecuErrRootEccErr                  (1)
// #define  cSecuErrFwSIgnKeyEccErr             (2)
// #define  cSecuErrPOSTHamErr                  (3)
// #define  cSecuErrPOSTHmacErr                 (4)
// #define  cSecuErrPOSTRSAErr                  (5)
// #define  cSecuErrLightSwitchErr              (6)
// #define  cSecuErrBootBinHmacChkErr           (7)
// #define  cSecuErrBootBinPubKeyHashEccErr     (8)
// #define  cSecuErrMpispKeyChkErr              (9)
// #define  cSecuErrMpispRSAChkErr              (10)
// #define  cSecuErrMpispBinHashChkErr          (11)
// #define  cSecuErrISPCore0IBinHmacChkErr      (12)
// #define  cSecuErrISPCore1IBinHmacChkErr      (13)
// #define  cSecuErrISPDRAMBinHmacChkErr        (14)
// 31~xx for other code
#define  cSecuErrFWImageProgKeyChkErr        31
#define  cSecuErrFWImageProgRSAChkErr        32
#define  cSecuErrFWImageProgBinHashChkErr    33
// #define  cSecuErrres                         34
// #define  cSecuErrres                         35
#define  cSecuErrBootBinHashChkErr           36    // cSecuErrFWImageProgBinHashChkErr+3
#define  cSecuErrCIDBinHashChkErr            37    // cSecuErrFWImageProgBinHashChkErr+4
#define  cSecuErrNormalHashChkErr            38    // cSecuErrFWImageProgBinHashChkErr+5
#define  cSecuErrOROMBinHashChkErr           39    // cSecuErrFWImageProgBinHashChkErr+6
#define  cSecuErrRDTHashChkErr               40    // cSecuErrFWImageProgBinHashChkErr+7
#define  cSecuErrParaPageHashChkErr          41    // cSecuErrFWImageProgBinHashChkErr+8
#define  cSecuErrDiagUnlockKeyChkErr         42
#define  cSecuErrDiagUnlockRSAChkErr         43
#define  cSecuErrDiagLeafRSAChkErr           44
#define  cSecuErrMpispWithUnlock             45
#define  cSecuErrDownloadFWKeyErr            46
#define  cSecuErrDownloadSignKeyErr          47
#define  cSecuErrDownloadAesKeyErr           48
#define  cSecuErrProgSecuKeyErr              49
#define  cSecuErrProgSecuKeyChkErr           50
// #define  cSecuErrPsidCheckFail               51
#define  cSecuErrAdminDLProgKeyChkErr        52
#define  cSecuErrAdminDLProgRSAChkErr        53
#define  cSecuErrAdminDLProgBinHashChkErr    54
#define  cSecuErrAdminDLActionErr            55
#define  cSecuErrAdminDLSlotErr              56
#define  cSecuErrAdminDLHeaderVendorErr      57
#define  cSecuErrAdminDLFWVersionErr         58
#define  cSecuErrAdminDLFWImageContentErr    59
#define  cSecuErrAdminDLFWAPIChkErr          60
#define  cSecuErrAdminDLFWSecStateChkErr     61
#define  cSecuErrAdminDLFWTimeOutErr         62
#define  cSecuErrSetCpinFail               63
#define  cSecuErrPsidCheckFailDetial         64    // API_PSID_VER_ERROR
#define  cSecuErrPsidCheckFailDetial1        65    // API_PSID_RETRY_ERROR
#define  cSecuErrPsidCheckFailDetial2        66    // API_PSID_PAGEGET_ERROR
#define  cSecuErrPsidCheckFailDetial3        67    // API_PSID_PAGECPY_ERROR
#define  cSecuErrPsidCheckFailDetial4        68    // API_PSID_NULLPTR_ERROR
#define  cSecuErrPsidCheckFailDetial5        69    // API_PSID_DUPSET_ERROR
#define  cSecuErrPsidCheckFailDetial6        70    // API_PSID_NVM_ERROR
#define  cSecuErrPsidCheckFailDetial7        71    // API_PSID_AUTH_ERROR
#define  cSecuErrAdminLoadFWErr              72
#define  cSecuErrAdminLoadFWHMACChkErr       73
#define  cSecuErrZeroizationOverTest         74
#define  cSecuErrZeroizationProgFail         75
#define  cSecuErrAdminDLFWLSChkErr           76
#define  cSecuErrFindISPBlkFail               77    // (Sonia) 2017/05/17 - Find ISP Blocks fail (2 blks ECC)
#define  cSecuErrAdminDLFWResetBeforeFWCommit 78    // CSSD-5246

#endif    // end of __SECAPI_DEFINE_BASEFW_H__







