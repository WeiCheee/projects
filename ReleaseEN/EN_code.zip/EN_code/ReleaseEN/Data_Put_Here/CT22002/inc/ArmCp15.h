







// OP1,CRn,CRm,OP2
#define cCp15MIDR                                0, 0, 0, 0
#define cCp15CTR                                 0, 0, 0, 1
#define cCp15TCMTR                               0, 0, 0, 2
#define cCp15TLBTR                               0, 0, 0, 3
#define cCp15MPIDR                               0, 0, 0, 5
#define cCp15REVIDR                              0, 0, 0, 6

#define cCp15IDPFR0                              0, 0, 1, 0
#define cCp15IDPFR1                              0, 0, 1, 1
#define cCp15IDDFR0                              0, 0, 1, 2
#define cCp15IDAFR0                              0, 0, 1, 3
#define cCp15IDMMFR0                             0, 0, 1, 4
#define cCp15IDMMFR1                             0, 0, 1, 5
#define cCp15IDMMFR2                             0, 0, 1, 6
#define cCp15IDMMFR3                             0, 0, 1, 7

#define cCp15IDISAR0                             0, 0, 2, 0
#define cCp15IDISAR1                             0, 0, 2, 1
#define cCp15IDISAR2                             0, 0, 2, 2
#define cCp15IDISAR3                             0, 0, 2, 3
#define cCp15IDISAR4                             0, 0, 2, 4
#define cCp15IDISAR5                             0, 0, 2, 5

#define cCp15CCSIDR                              1, 0, 0, 0
#define cCp15CLIDR                               1, 0, 0, 1
#define cCp15AIDR                                1, 0, 0, 7
#define cCp15CSSELR                              2, 0, 0, 0
#define cCp15VPIDR                               4, 0, 0, 0
#define cCp15VMPIDR                              4, 0, 0, 0

#define cCp15SCTLR                               0, 1, 0, 0
#define cCp15ACTLR                               0, 1, 0, 1
#define cCp15CPACR                               0, 1, 0, 2
#define cCp15SCR                                 0, 1, 1, 0
#define cCp15SDER                                0, 1, 1, 1
#define cCp15NSACR                               0, 1, 1, 2

#define cCp15PMCR                                0, 9, 12, 0
#define cCp15PMCNTENSET                          0, 9, 12, 1
#define cCp15PMCNTENCLR                          0, 9, 12, 2
#define cCp15PMOVSR                              0, 9, 12, 3
#define cCp15PMSWINC                             0, 9, 12, 4
#define cCp15PMSELR                              0, 9, 12, 5
#define cCp15PMCEID0                             0, 9, 12, 6
#define cCp15PMCEID1                             0, 9, 12, 7

#define cCp15PMCCNTR                             0, 9, 13, 0
#define cCp15PMXEVTYPER                          0, 9, 13, 1
#define cCp15PMXEVCNTR                           0, 9, 13, 2
#define cCp15PMUSERENR                           0, 9, 14, 0
#define cCp15PMINTENSET                          0, 9, 14, 1
#define cCp15PMINTENCLR                          0, 9, 14, 2
#define cCp15PMOVSSET                            0, 9, 14, 3

// OP1, WD,CRn,CRm,OP2
#define mCp15MIDR(x)                             0, x, 0, 0, 0
#define mCp15CTR(x)                              0, x, 0, 0, 1
#define mCp15TCMTR(x)                            0, x, 0, 0, 2
#define mCp15TLBTR(x)                            0, x, 0, 0, 3
#define mCp15MPIDR(x)                            0, x, 0, 0, 5
#define mCp15REVIDR(x)                           0, x, 0, 0, 6

#define mCp15IDPFR0(x)                           0, x, 0, 1, 0
#define mCp15IDPFR1(x)                           0, x, 0, 1, 1
#define mCp15IDDFR0(x)                           0, x, 0, 1, 2
#define mCp15IDAFR0(x)                           0, x, 0, 1, 3
#define mCp15IDMMFR0(x)                          0, x, 0, 1, 4
#define mCp15IDMMFR1(x)                          0, x, 0, 1, 5
#define mCp15IDMMFR2(x)                          0, x, 0, 1, 6
#define mCp15IDMMFR3(x)                          0, x, 0, 1, 7

#define mCp15IDISAR0(x)                          0, x, 0, 2, 0
#define mCp15IDISAR1(x)                          0, x, 0, 2, 1
#define mCp15IDISAR2(x)                          0, x, 0, 2, 2
#define mCp15IDISAR3(x)                          0, x, 0, 2, 3
#define mCp15IDISAR4(x)                          0, x, 0, 2, 4
#define mCp15IDISAR5(x)                          0, x, 0, 2, 5

#define mCp15CCSIDR(x)                           1, x, 0, 0, 0
#define mCp15CLIDR(x)                            1, x, 0, 0, 1
#define mCp15AIDR(x)                             1, x, 0, 0, 7
#define mCp15CSSELR(x)                           2, x, 0, 0, 0
#define mCp15VPIDR(x)                            4, x, 0, 0, 0
#define mCp15VMPIDR(x)                           4, x, 0, 0, 0

#define mCp15SCTLR(x)                            0, x, 1, 0, 0
#define mCp15ACTLR(x)                            0, x, 1, 0, 1
#define mCp15CPACR(x)                            0, x, 1, 0, 2
#define mCp15SCR(x)                              0, x, 1, 1, 0
#define mCp15SDER(x)                             0, x, 1, 1, 1
#define mCp15NSACR(x)                            0, x, 1, 1, 2

#define mCp15PMCR(x)                             0, x, 9, 12, 0
#define mCp15PMCNTENSET(x)                       0, x, 9, 12, 1
#define mCp15PMCNTENCLR(x)                       0, x, 9, 12, 2
#define mCp15PMOVSR(x)                           0, x, 9, 12, 3
#define mCp15PMSWINC(x)                          0, x, 9, 12, 4
#define mCp15PMSELR(x)                           0, x, 9, 12, 5
#define mCp15PMCEID0(x)                          0, x, 9, 12, 6
#define mCp15PMCEID1(x)                          0, x, 9, 12, 7

#define mCp15PMCCNTR(x)                          0, x, 9, 13, 0
#define mCp15PMXEVTYPER(x)                       0, x, 9, 13, 1
#define mCp15PMXEVCNTR(x)                        0, x, 9, 13, 2
#define mCp15PMUSERENR(x)                        0, x, 9, 14, 0
#define mCp15PMINTENSET(x)                       0, x, 9, 14, 1
#define mCp15PMINTENCLR(x)                       0, x, 9, 14, 2
// #define mCp15PMOVSSET(x)                         0,  x,  9, 14,  3  //(Vince) remove

#define mCp15ENVALIRQ(x)                         0, x, 15, 1, 0
#define mCp15ENVALFIQ(x)                         0, x, 15, 1, 1
#define mCp15CLRVALIRQ(x)                        0, x, 15, 1, 4
#define mCp15CLRVALFIQ(x)                        0, x, 15, 1, 5

#define rmCp15DisCCNTInt                         __MCR(15, mCp15PMINTENCLR(c32Bit31))
#define rmCp15EnCCNTInt                          __MCR(15, mCp15PMINTENSET(c32Bit31))
// #define rmCp15ClrCCNTOvFlg                       __MCR(15,mCp15PMOVSSET(c32Bit31))  //(Vince) remove

#define rmCp15DisCCNT                            __MCR(15, mCp15PMCNTENCLR(c32Bit31))
#define rmCp15EnCCNT                             __MCR(15, mCp15PMCNTENSET(c32Bit31))
#define rmCp15EnUsrModeAcc                       __MCR(15, mCp15PMUSERENR(c32Bit0))

#define rmCp15DisUsrModeAcc                      __MCR(15, mCp15PMUSERENR(0x00000000))

// #if (_RTC_Debug)
#define rmCp15SetCCNT(x)                         __MCR(15, mCp15PMCCNTR(x))
#define rmCp15ChkCCNT                            (__MRC(15, cCp15PMCCNTR))
// #else
// #define rmCp15SetCCNT(x)                         __MCR(15, mCp15PMCCNTR(0xFFFFFFFF-x))
// #define rmCp15ChkCCNT                            (0xFFFFFFFF-__MRC(15, Cp15PMCCNTR))
// #endif

#define rmCp15EnCCNTDbgPause                     __MCR(15, mCp15PMCR(__MRC(15, cCp15PMCR)|c32Bit5))
#define rmCp15DisCCNTDbgPause                    __MCR(15, mCp15PMCR(__MRC(15, cCp15PMCR)&~c32Bit5))
#define rmCp15EnCCNTDiv64                        __MCR(15, mCp15PMCR(__MRC(15, cCp15PMCR)|c32Bit3))
#define rmCp15DisCCNTDiv64                       __MCR(15, mCp15PMCR(__MRC(15, cCp15PMCR)&~c32Bit3))
#define rmCp15RstCNT                             __MCR(15, mCp15PMCR(__MRC(15, cCp15PMCR)|c32Bit2))
#define rmCp15EnPMCNT                            __MCR(15, mCp15PMCR(__MRC(15, cCp15PMCR)|c32Bit0))
#define rmCp15DisPMCNT                           __MCR(15, mCp15PMCR(__MRC(15, cCp15PMCR)&~c32Bit0))
#define rmCp15ChkPMOVFlag                        __MRC(15, Cp15PMOVSR)
#define rmCp15ClrPMOVFlag                        __MCR(15, mCp15PMOVSR(c32Bit31))
#define rmCp15EnVALIRQ                           __MCR(15, mCp15ENVALIRQ(c32Bit31))
#define rmCp15EnRVALFIQ                          __MCR(15, mCp15ENVALFIQ(c32Bit31))
#define rmCp15ClrVALIRQ                          __MCR(15, mCp15CLRVALIRQ(c32Bit31))
#define rmCp15ClrVALFIQ                          __MCR(15, mCp15CLRVALFIQ(c32Bit31))







