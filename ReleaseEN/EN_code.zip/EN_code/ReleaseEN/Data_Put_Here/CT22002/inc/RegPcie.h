







#ifndef __REG_PCIE_H__
#define __REG_PCIE_H__

// #include "inc/GlobVar0.h"

// Pcie Configuration Header @0x50001000
// ref. DWC_pcie_ep_databook_4.11a Ch 5.1.2
#define rcDeviceVenderIdReg                                    0x00
#define rmSetPcieCfgVenderId(x)                                (r16Pcie[rcDeviceVenderIdReg/2]=x)
#define rmSetPcieCfgDeviceId(x)                                (r16Pcie[(rcDeviceVenderIdReg/2)+1]=x)
#define rmSetPcieCfgDeviceVenderId(x)                          (r32Pcie[rcDeviceVenderIdReg/4]=x)

#define rcCommandReg                                           0x04
#define rmChkBusMasterDis                                      ((rPcie[rcCommandReg]&cBit2)==0x00)

#define rmSetIose(x)                                           (r16Pcie[rcCommandReg/2]=(r16Pcie[rcCommandReg/2]&0xFFFE)|(x&0x0001))
#define rmSetMse(x)\
    (r16Pcie[rcCommandReg/\
             2]=(r16Pcie[rcCommandReg/2]&0xFFFD)|((x&0x0001)<<1))
#define rmSetBme(x)\
    (r16Pcie[rcCommandReg/\
             2]=(r16Pcie[rcCommandReg/2]&0xFFFB)|((x&0x0001)<<2))
#define rmSetSce(x)\
    (r16Pcie[rcCommandReg/\
             2]=(r16Pcie[rcCommandReg/2]&0xFFF7)|((x&0x0001)<<3))
#define rmSetMwie(x)\
    (r16Pcie[rcCommandReg/\
             2]=(r16Pcie[rcCommandReg/2]&0xFFEF)|((x&0x0001)<<4))
#define rmSetVga(x)\
    (r16Pcie[rcCommandReg/\
             2]=(r16Pcie[rcCommandReg/2]&0xFFDF)|((x&0x0001)<<5))
#define rmSetPee(x)\
    (r16Pcie[rcCommandReg/\
             2]=(r16Pcie[rcCommandReg/2]&0xFFBF)|((x&0x0001)<<6))
#define rmHardwiredto0(x)\
    (r16Pcie[rcCommandReg/\
             2]=(r16Pcie[rcCommandReg/2]&0xFF7F)|((x&0x0001)<<7))
#define rmSetSee(x)\
    (r16Pcie[rcCommandReg/\
             2]=(r16Pcie[rcCommandReg/2]&0xFEFF)|((x&0x0001)<<8))
#define rmSetFbe(x)\
    (r16Pcie[rcCommandReg/\
             2]=(r16Pcie[rcCommandReg/2]&0xFDFF)|((x&0x0001)<<9))
#define rmSetId(x)\
    (r16Pcie[rcCommandReg/\
             2]=(r16Pcie[rcCommandReg/2]&0xFBFF)|((x&0x0001)<<10))
// #define Reserved                                             //:5;

#define rcStatusReg                                            0x06
#define rmSetStatusReg(x)                                      (r16Pcie[rcStatusReg/2]=x)

#define rcRevisionId                                           0x08
#define rmSetRevisionId(x)                                     (rPcie[rcRevisionId]=x)

#define rcClassCode                                            0x09
#define rmSetClassCode(x, y, z)                                  {rPcie[rcClassCode]=x;rPcie[rcClassCode+1]=y;rPcie[rcClassCode+2]=z;}

#define rcCacheLineSize                                        0x0C
#define rmSetCacheLineSize(x)                                  (rPcie[rcCacheLineSize]=x)

#define rcMasterLatencyTimer                                   0x0D
#define rmSetMasterLatencyTimer(x)                             (rPcie[rcMasterLatencyTimer]=x)

#define rcHeaderType                                           0x0E
#define rmSetHeaderType(x)                                     (rPcie[rcHeaderType]=x)

#define rcBist                                                 0x0F
#define rmSetBist(x)                                           (rPcie[rcBist]=x)

#define rcPcieBar0                                             0x10
#define rmSetPcieBar0Type                                      (r32Pcie[rcPcieBar0/4]=0x00000004)
#define rmSetPcieBar0Mask(x, y)                                 (r32Pcie[(rcPcieBar0/4)+x]=y)
#define rmClrPcieBarAddr(x, y)                                  (r32Pcie[(rcPcieBar0/4)+x]=y)
#define rmSetPcieBar0CheckNotInit                              ((r32Pcie[rcPcieBar0/4]^0x00000004)!=0x00000000)    // yes if not all zero
#define rmSetPcieBar0CheckHasValue                             ((r32Pcie[rcPcieBar0/4]^0xFFF00004)!=0x00000000)    // yes if not all FF
#define rmGetPcieBar0Addr                                      r32Pcie[rcPcieBar0/4]

#define rcPcieBar1                                             0x14
#define rmSetPcieBar1                                          (r32Pcie[rcPcieBar1/4]=0x00000000)

#define rcPcieBar2                                             0x18
#define rcPcieBar3                                             0x1C
#define rcPcieBar4                                             0x20
#define rcPcieBar5                                             0x24

#define rcCardBusCisPointer                                    0x28
#define rmSetCcpr(x)                                           (r32Pcie[rcCardBusCisPointer/4]=x)

#define rcSsvid                                                0x2C
#define rmSetSsvid(x)                                          (r16Pcie[rcSsvid/2]=x)

#define rcSsid                                                 0x2E
#define rmSetSsid(x)                                           (r16Pcie[rcSsid/2]=x)

#define rcExpansionRom                                         0x30
#define rmSetEprom(x)                                          (r32Pcie[rcExpansionRom/4]=x)

#define rmClosePcieEprom                                       (r32Pcie[rcExpansionRom/4]=0x00000000)

#define rcCapabilitiesPointer                                  0x34
#define rmSetCapPointer(x)                                     (rPcie[rcCapabilitiesPointer]=x)

#define rcIntInformation                                       0x3C
#define rmSetPcieIntr(x)                                       (r16Pcie[rcIntInformation/2]=x)
#define rmClrPcieIntr                                          (r16Pcie[rcIntInformation/2]=0)

#define rmSetPcieCapNextPtr(x, y)                               (rPcie[x]=y)

#define rcPowerManagementCapId                                 0x40
#define rcPowerManagementCapNextPtr                            0x41
#define rcPowerManagementCapReg                                0x42
#define rmPowerManagementCapId(x)                              (rPcie[rcPowerManagementCapId]=x)
#define rmPowerManagementCapNextPtr(x)                         (rPcie[rcPowerManagementCapNextPtr]=x)
#define rmSetPowerManagementCapReg(x)                          (r16Pcie[rcPowerManagementCapReg/2]=x)

#define rmSetPowerManagementCapRegVersion(x)\
    (r16Pcie[rcPowerManagementCapReg/\
             2]=(r16Pcie[rcPowerManagementCapReg/2]&0xFFF8)|(x&0x0007))    //
//
// 3
#define rmSetPowerManagementCapRegPmeClock(x)\
    (r16Pcie[rcPowerManagementCapReg/\
             2]=(r16Pcie[rcPowerManagementCapReg/2]&0xFFF7)|((x<<3)&0x0008))    //
//
// 1
#define rmSetPowerManagementCapRegPmeImmReadiRtnD0(x)\
    (r16Pcie[rcPowerManagementCapReg/2]=(r16Pcie[rcPowerManagementCapReg/2]&0xFFEF)|\
                                         ((x<<4)&0x0010))    //
//
// 1
#define rmSetPowerManagementCapRegDeviceSpecInit(x)\
    (r16Pcie[rcPowerManagementCapReg/\
             2]=(r16Pcie[rcPowerManagementCapReg/2]&0xFFDF)|((x<<5)&0x0020))    //
//
// 1
#define rmSetPowerManagementCapRegAuxCurrent(x)\
    (r16Pcie[rcPowerManagementCapReg/\
             2]=(r16Pcie[rcPowerManagementCapReg/2]&0xFE3F)|((x<<6)&0x01C0))    //
//
// 3
#define rmSetPowerManagementCapRegD1Support(x)\
    (r16Pcie[rcPowerManagementCapReg/\
             2]=(r16Pcie[rcPowerManagementCapReg/2]&0xFDFF)|((x<<9)&0x0200))    //
//
// 1
#define rmSetPowerManagementCapRegD2Support(x)\
    (r16Pcie[rcPowerManagementCapReg/\
             2]=(r16Pcie[rcPowerManagementCapReg/2]&0xFBFF)|((x<<10)&0x0400))    //
//
// 1
#define rmSetPowerManagementCapRegPmed0(x)\
    (r16Pcie[rcPowerManagementCapReg/\
             2]=(r16Pcie[rcPowerManagementCapReg/2]&0xF7FF)|((x<<11)&0x0800))    //
//
// 1
#define rmSetPowerManagementCapRegPmed1(x)\
    (r16Pcie[rcPowerManagementCapReg/\
             2]=(r16Pcie[rcPowerManagementCapReg/2]&0xEFFF)|((x<<12)&0x1000))    //
//
// 1
#define rmSetPowerManagementCapRegPmed2(x)\
    (r16Pcie[rcPowerManagementCapReg/\
             2]=(r16Pcie[rcPowerManagementCapReg/2]&0xDFFF)|((x<<13)&0x2000))    //
//
// 1
#define rmSetPowerManagementCapRegPmed3Hot(x)\
    (r16Pcie[rcPowerManagementCapReg/\
             2]=(r16Pcie[rcPowerManagementCapReg/2]&0xBFFF)|((x<<14)&0x4000))    //
//
// 1
#define rmSetPowerManagementCapRegPmed3Cold(x)\
    (r16Pcie[rcPowerManagementCapReg/\
             2]=(r16Pcie[rcPowerManagementCapReg/2]&0x7FFF)|((x<<15)&0x8000))    //
//
// 1

#define rcPowerMangementCtrl                                   0x44
#define rmChkD0state                                           ((rPcie[rcPowerMangementCtrl]&0x03)==0x00)
#define rmChkD3state                                           ((rPcie[rcPowerMangementCtrl]&0x03)==0x03)
#define rmGetDxstate                                           ((rPcie[rcPowerMangementCtrl]&0x07))

#define rmSetD0State                                           (rPcie[rcPowerMangementCtrl]=(rPcie[rcPowerMangementCtrl]&0xF8))
#define rmSetD1State                                           (rPcie[rcPowerMangementCtrl]=(rPcie[rcPowerMangementCtrl]&0xF8)|0x01)
#define rmSetD3State                                           (rPcie[rcPowerMangementCtrl]=(rPcie[rcPowerMangementCtrl]&0xF8)|0x03)

#define rmSetPmCtrlPowerState(x)\
    (r32Pcie[rcPowerMangementCtrl/\
             4]=(r32Pcie[rcPowerMangementCtrl/4]&0xFFFFFFFC)|(x&0x00000003))    //
//
// :2;
// #define Rsvd1                                                                                                                     //:1;
#define rmSetPmCtrlNoSoftReset(x)\
    (r32Pcie[rcPowerMangementCtrl/\
             4]=(r32Pcie[rcPowerMangementCtrl/4]&0xFFFFFFF7)|((x&0x00000001)<<3))    //
// :1;
// #define Rsvd2                                                                                                                     //:4;
#define rmSetPmCtrlPmeEnable(x)\
    (r32Pcie[rcPowerMangementCtrl/\
             4]=(r32Pcie[rcPowerMangementCtrl/4]&0xFFFFFEFF)|((x&0x00000001)<<8))    //
// :1;
#define rmSetPmCtrlDataSelect(x)\
    (r32Pcie[rcPowerMangementCtrl/\
             4]=(r32Pcie[rcPowerMangementCtrl/4]&0xFFFFE1FF)|((x&0x0000000F)<<9))    //
// :4;
#define rmSetPmCtrlDataScale(x)\
    (r32Pcie[rcPowerMangementCtrl/\
             4]=(r32Pcie[rcPowerMangementCtrl/4]&0xFFFF9FFF)|((x&0x00000003)<<13))    //
// :2;
#define rmSetPmCtrlPmeStatus(x)\
    (r32Pcie[rcPowerMangementCtrl/\
             4]=(r32Pcie[rcPowerMangementCtrl/4]&0xFFFF7FFF)|((x&0x00000001)<<15))    //
// :1;
// #define Rsvd3                                                                                                                     //:6;
#define rmSetPmCtrlB2B3Support(x)\
    (r32Pcie[rcPowerMangementCtrl/\
             4]=(r32Pcie[rcPowerMangementCtrl/4]&0xFFBFFFFF)|((x&0x00000001)<<22))    //
// :1;
#define rmSetPmCtrlBusPowerClockControlEnable(x)\
    (r32Pcie[rcPowerMangementCtrl/\
             4]=(r32Pcie[rcPowerMangementCtrl/4]&0xFF7FFFFF)|((x&0x00000001)<<23))    //
// :1;
#define rmSetPmCtrlDataRegisterForAdditionalInfo(x)\
    (r32Pcie[rcPowerMangementCtrl/\
             4]=(r32Pcie[rcPowerMangementCtrl/4]&0x00FFFFFF)|((x&0x000000FF)<<24))    //
// :8;

#define rcMsiCapId                                             0x50
#define rcMsiCapNextPtr                                        0x51
#define rcMsiControlReg                                        0x52

#define rmSetMsiCapNextPtr(x)                                  (rPcie[rcMsiCapNextPtr]=x)
// #define rmSetMsiMultiMsgCap(x)                               (rPcie[rcMsiControlReg]=((rPcie[rcMsiControlReg]&0xF1)|(x<<1)))
// #define rmSetMsiControlReg(x)                                (rPcie[rcMsiControlReg]=x )

#define rmSetMsiControlRegEnable(x)                            (r16Pcie[rcMsiControlReg/2]=(r16Pcie[rcMsiControlReg/2]&0xFFFE)|(x&0x0001))
#if _ENABLE_PCIE_LS
#define rmSetMsiControlRegMultipleMessageCapable(x)            (r16Pcie[rcMsiControlReg/2]=(r16Pcie[rcMsiControlReg/2]&0xFFF1)|x)    // 3
#else
#define rmSetMsiControlRegMultipleMessageCapable(x)            (r16Pcie[rcMsiControlReg/2]=(r16Pcie[rcMsiControlReg/2]&0xFFF1)|((x<<1)&0x000E))
#endif
#define rmSetMsiControlRegMultipleMessageEnable(x)             (r16Pcie[rcMsiControlReg/2]=(r16Pcie[rcMsiControlReg/2]&0xFF8F)|((x<<4)&0x0070))
#define rmSetMsiControlRegCapableOf64Bits(x)                   (r16Pcie[rcMsiControlReg/2]=(r16Pcie[rcMsiControlReg/2]&0xFF7F)|((x<<7)&0x0080))
#define rmSetMsiControlRegPerVectorMaskCapable(x)              (r16Pcie[rcMsiControlReg/2]=(r16Pcie[rcMsiControlReg/2]&0xFEFF)|((x<<8)&0x0100))
// WORD Reserved  :7;

#define rcMsiLower32BitsAddressRegister                        0x54
// #define Reserved                                                           //:2;
#define rmSetMsiLower32BitsAddress(x)\
    (r32Pcie[rcMsiLower32BitsAddressRegister/\
             4]=(r32Pcie[rcMsiLower32BitsAddressRegister/4]&0xFFFFFFFC)|((x&0x3FFFFFFF)<<2))    //
// :30;

#define rcMsiUpper32BitsAddressRegister                        0x58
#define rmSetMsiUpper32BitsAddress(x)                          (r32Pcie[rcMsiUpper32BitsAddressRegister/4]=x)

#define rcMsiDataRegister                                      0x5C
#define rmSetMsiData(x)                                        (r32Pcie[rcMsiDataRegister/4]=x)

#define rcPcieCapId                                            0x70
#define rcPcieCapNextPtr                                       0x71
#define rcPcieCapReg                                           0x72
#define rmSetPcieCapId(x)                                      (rPcie[rcPcieCapId]=x)
#define rmSetPcieCapReg(x)                                     (r16Pcie[rcPcieCapReg/2]=x)
#define rmPcieCapNextPtr(x)                                    (rPcie[rcPcieCapNextPtr]=x)

#define rmPcieCapRegCapabilityVersion(x)                       (r16Pcie[rcPcieCapReg/2]=(r16Pcie[rcPcieCapReg/2]&0xFFF0)|(x&0x000F))    // 4
#define rmPcieCapRegDeviceType(x)                              (r16Pcie[rcPcieCapReg/2]=(r16Pcie[rcPcieCapReg/2]&0xFF0F)|((x<<4)&0x00F0))
#define rmPcieCapRegSlotImplemented(x)                         (r16Pcie[rcPcieCapReg/2]=(r16Pcie[rcPcieCapReg/2]&0xFEFF)|((x<<8)&0x0100))
#define rmPcieCapRegInterruptMessageNumber(x)                  (r16Pcie[rcPcieCapReg/2]=(r16Pcie[rcPcieCapReg/2]&0xC1FF)|((x<<9)&0x3E00))
// WORD Rsvd  :2;

#define rcPcieDeviceCap                                        0x74
#define rmSetPcieDeviceCap(x)                                  (r32Pcie[rcPcieDeviceCap/4]=x)

#define rmSetPcieDeviceCapMaxPayloadSizeSupported(x)           (r32Pcie[rcPcieDeviceCap/4]=(r32Pcie[rcPcieDeviceCap/4]&0xFFFFFFF8)|x)    // 3
#define rmSetPcieDeviceCapPhantomFunctionsSupported(x)\
    (r32Pcie[rcPcieDeviceCap/\
             4]=(r32Pcie[rcPcieDeviceCap/4]&0xFFFFFFE7)|((x<<3)&0x00000018))    //
//
// 2
#define rmSetPcieDeviceCapExtendedTagSupported(x)\
    (r32Pcie[rcPcieDeviceCap/\
             4]=(r32Pcie[rcPcieDeviceCap/4]&0xFFFFFFDF)|((x<<5)&0x00000020))    //
//
// 1
#if _ENABLE_PCIE_LS
#define rmSetPcieDeviceCapL0sAcceptableLatency(x)              (r32Pcie[rcPcieDeviceCap/4]=(r32Pcie[rcPcieDeviceCap/4]&0xFFFFFE3F)|x)    // 3
#define rmSetPcieDeviceCapL1AcceptableLatency(x)               (r32Pcie[rcPcieDeviceCap/4]=(r32Pcie[rcPcieDeviceCap/4]&0xFFFFF1FF)|x)    // 3
#else
#define rmSetPcieDeviceCapL0sAcceptableLatency(x)\
    (r32Pcie[rcPcieDeviceCap/\
             4]=(r32Pcie[rcPcieDeviceCap/4]&0xFFFFFE3F)|((x<<6)&0x000001C0))    //
//
// 3
#define rmSetPcieDeviceCapL1AcceptableLatency(x)\
    (r32Pcie[rcPcieDeviceCap/\
             4]=(r32Pcie[rcPcieDeviceCap/4]&0xFFFFF1FF)|((x<<9)&0x00000E00))    //
//
// 3
#endif
// LWORD Undefined  :3;
//                                                                                                                   0x00007000     //3
#define rmSetPcieDeviceCapRoleBasedErrorReporting(x)\
    (r32Pcie[rcPcieDeviceCap/\
             4]=(r32Pcie[rcPcieDeviceCap/4]&0xFFFF7FFF)|((x<<15)&0x00008000))    //
//
// 1
// LWORD Rsvd1  :2;
//                                                                                                                        0x00030000     //2
#define rmSetPcieDeviceCapCapturedSlotPowerLimit(x)\
    (r32Pcie[rcPcieDeviceCap/\
             4]=(r32Pcie[rcPcieDeviceCap/4]&0xFC03FFFF)|((x<<18)&0x03FC0000))    //
//
// 8
#define rmSetPcieDeviceCapCapturedSlotPowerLimitScale(x)\
    (r32Pcie[rcPcieDeviceCap/\
             4]=(r32Pcie[rcPcieDeviceCap/4]&0xF3FFFFFF)|((x<<26)&0x0C000000))    //
//
// 2
#define rmSetPcieDeviceCapFunctionLevelResetCapability(x)\
    (r32Pcie[rcPcieDeviceCap/\
             4]=(r32Pcie[rcPcieDeviceCap/4]&0xEFFFFFFF)|((x<<28)&0x10000000))    //
//
// 1
// LWORD Rsvd2  :3;

#define rcPcieDeviceCtrl                                       0x78
#define rmSetPcieDeviceCtrl(x)                                 (r32Pcie[rcPcieDeviceCtrl/4]=x)
#define rmSetPcieDeviceCapMaxPayloadSize(x)\
    (r32Pcie[rcPcieDeviceCtrl/\
             4]=(r32Pcie[rcPcieDeviceCtrl/4]&0xFFFFFF1F)|((x<<5)&0x000000E0))    //
//
// 3

#define rmCorrectableErrorEnable(x)                            (r16Pcie[rcPcieDeviceCtrl/2]=(r16Pcie[rcPcieDeviceCtrl/2]&0xFFFE)|(x&0x0001))
#define rmNonFatalErrorEnable(x)\
    (r16Pcie[rcPcieDeviceCtrl/2]=(r16Pcie[rcPcieDeviceCtrl/2]&0xFFFD)|\
                                  ((x&0x0001)<<1))
#define rmFatalErrorEnable(x)\
    (r16Pcie[rcPcieDeviceCtrl/2]=(r16Pcie[rcPcieDeviceCtrl/2]&0xFFFB)|\
                                  ((x&0x0001)<<2))
#define rmUnsupportedRequestErrorEnable(x)\
    (r16Pcie[rcPcieDeviceCtrl/2]=(r16Pcie[rcPcieDeviceCtrl/2]&0xFFF7)|\
                                  ((x&0x0001)<<3))
#define rmEnableRelaxedOrder(x)\
    (r16Pcie[rcPcieDeviceCtrl/2]=(r16Pcie[rcPcieDeviceCtrl/2]&0xFFEF)|\
                                  ((x&0x0001)<<4))
#define rmMaxPayloadSize(x)\
    (r16Pcie[rcPcieDeviceCtrl/2]=(r16Pcie[rcPcieDeviceCtrl/2]&0xFF1F)|\
                                  ((x&0x0007)<<5))
#define rmExtendedTagEnable(x)\
    (r16Pcie[rcPcieDeviceCtrl/2]=(r16Pcie[rcPcieDeviceCtrl/2]&0xFEFF)|\
                                  ((x&0x0001)<<8))
#define rmPhantomFunctionsEnable(x)\
    (r16Pcie[rcPcieDeviceCtrl/2]=(r16Pcie[rcPcieDeviceCtrl/2]&0xFDFF)|\
                                  ((x&0x0001)<<9))
#define rmAuxPowerEnable(x)\
    (r16Pcie[rcPcieDeviceCtrl/\
             2]=(r16Pcie[rcPcieDeviceCtrl/2]&0xFBFF)|((x&0x0001)<<10))    //
//
// :1;
#define rmNoSnoopEnable(x)\
    (r16Pcie[rcPcieDeviceCtrl/\
             2]=(r16Pcie[rcPcieDeviceCtrl/2]&0xF7FF)|((x&0x0001)<<11))    //
//
// :1;
#define rmMaxReadRequestSize(x)\
    (r16Pcie[rcPcieDeviceCtrl/\
             2]=(r16Pcie[rcPcieDeviceCtrl/2]&0x8FFF)|((x&0x0007)<<12))    //
//
// :3;
#define rmBridgeConfigRetryEnable(x)\
    (r16Pcie[rcPcieDeviceCtrl/\
             2]=(r16Pcie[rcPcieDeviceCtrl/2]&0x7FFF)|((x&0x0001)<<15))    //
//
// :1;

#define rcPcieDeviceStatus                                     0x7A
#define rmCorrectableErrorDetected(x)                          (r16Pcie[rcPcieDeviceStatus/2]=(r16Pcie[rcPcieDeviceStatus/2]&0xFFFE)|(x&0x0001))
#define rmNonFatalErrorDetected(x)\
    (r16Pcie[rcPcieDeviceStatus/\
             2]=(r16Pcie[rcPcieDeviceStatus/2]&0xFFFD)|((x&0x0001)<<1))    //
//
// :1;
#define rmFatalErrorDetected(x)\
    (r16Pcie[rcPcieDeviceStatus/\
             2]=(r16Pcie[rcPcieDeviceStatus/2]&0xFFFB)|((x&0x0001)<<2))    //
//
// :1;
#define rmUnsupportedRequestDetected(x)\
    (r16Pcie[rcPcieDeviceStatus/\
             2]=(r16Pcie[rcPcieDeviceStatus/2]&0xFFF7)|((x&0x0001)<<3))    //
//
// :1;
#define rmAuxPowerDetected(x)\
    (r16Pcie[rcPcieDeviceStatus/\
             2]=(r16Pcie[rcPcieDeviceStatus/2]&0xFFEF)|((x&0x0001)<<4))    //
//
// :1;
#define rmTransactionsPending(x)\
    (r16Pcie[rcPcieDeviceStatus/\
             2]=(r16Pcie[rcPcieDeviceStatus/2]&0xFFDF)|((x&0x0001)<<5))    //
//
// :1;
// #define Rsvd                                                 //:10;

#define rcPcieLinkCap                                          0x7C
#define rmSetPcieLinkCap(x)                                    (r32Pcie[rcPcieLinkCap/4]=x)
#define rmChkSupportClkPowerState                              (r32Pcie[rcPcieLinkCap/4]&c32Bit18)

#if _ENABLE_PCIE_LS
#define rmSetPcieLinkCapMaximumLinkSpeed(x)                    (r32Pcie[rcPcieLinkCap/4]=(r32Pcie[rcPcieLinkCap/4]&0xFFFFFFF0)|x)    // 4
#define rmSetPcieLinkCapMaximumLinkWidth(x)                    (r32Pcie[rcPcieLinkCap/4]=(r32Pcie[rcPcieLinkCap/4]&0xFFFFFC0F)|x)    // 6

#define rmChkPcieLinkCapMaximumLinkSpeed                       (r32Pcie[rcPcieLinkCap/4]&0xF)    // 4
#define rmChkPcieLinkCapMaximumLinkWidth                       ((r32Pcie[rcPcieLinkCap/4]&0x3F0)>>4)    // 6

#define rmSetPcieLinkCapActiveStatePmSupport(x)                (r32Pcie[rcPcieLinkCap/4]=(r32Pcie[rcPcieLinkCap/4]&0xFFFFF3FF)|x)    // 2
#define rmSetPcieLinkCapL0sExitLatency(x)                      (r32Pcie[rcPcieLinkCap/4]=(r32Pcie[rcPcieLinkCap/4]&0xFFFF8FFF)|x)    // 3
#define rmSetPcieLinkCapL1ExitLatency(x)                       (r32Pcie[rcPcieLinkCap/4]=(r32Pcie[rcPcieLinkCap/4]&0xFFFC7FFF)|x)    // 3
#define rmSetPcieLinkCapClockPowerManagement(x)                (r32Pcie[rcPcieLinkCap/4]=(r32Pcie[rcPcieLinkCap/4]&0xFFFBFFFF)|x)    // 1
#else
#define rmSetPcieLinkCapMaximumLinkSpeed(x)                    (r32Pcie[rcPcieLinkCap/4]=(r32Pcie[rcPcieLinkCap/4]&0xFFFFFFF0)|(x&0x0000000F))
#define rmSetPcieLinkCapMaximumLinkWidth(x)\
    (r32Pcie[rcPcieLinkCap/\
             4]=(r32Pcie[rcPcieLinkCap/4]&0xFFFFFC0F)|((x<<4)&0x000003F0))
#define rmSetPcieLinkCapActiveStatePmSupport(x)\
    (r32Pcie[rcPcieLinkCap/\
             4]=(r32Pcie[rcPcieLinkCap/4]&0xFFFFF3FF)|((x<<10)&0x00000C00))
#define rmSetPcieLinkCapL0sExitLatency(x)\
    (r32Pcie[rcPcieLinkCap/\
             4]=(r32Pcie[rcPcieLinkCap/4]&0xFFFF8FFF)|((x<<12)&0x00007000))
#define rmSetPcieLinkCapL1ExitLatency(x)\
    (r32Pcie[rcPcieLinkCap/\
             4]=(r32Pcie[rcPcieLinkCap/4]&0xFFFC7FFF)|((x<<15)&0x00038000))
#define rmSetPcieLinkCapClockPowerManagement(x)\
    (r32Pcie[rcPcieLinkCap/\
             4]=(r32Pcie[rcPcieLinkCap/4]&0xFFFBFFFF)|((x<<18)&0x00040000))
#endif    // if _ENABLE_PCIE_LS
#define rmSetPcieLinkCapSurpriseDownErrorReportingCapable(x)\
    (r32Pcie[rcPcieLinkCap/\
             4]=(r32Pcie[rcPcieLinkCap/4]&0xFFF7FFFF)|((x<<19)&0x00080000))
#define rmSetPcieLinkCapDataLinkLayerActiveReportingCapable(x)\
    (r32Pcie[rcPcieLinkCap/\
             4]=(r32Pcie[rcPcieLinkCap/4]&0xFFEFFFFF)|((x<<20)&0x00100000))
#define rmSetPcieLinkCapLinkBandwidthNotificationCapability(x)\
    (r32Pcie[rcPcieLinkCap/\
             4]=(r32Pcie[rcPcieLinkCap/4]&0xFFDFFFFF)|((x<<21)&0x00200000))
#define rmSetPcieLinkCapAspmOptionalityCompliance(x)\
    (r32Pcie[rcPcieLinkCap/\
             4]=(r32Pcie[rcPcieLinkCap/4]&0xFFBFFFFF)|((x<<22)&0x00400000))
// LWORD Rsvd  :1;
//                                              (r32Pcie[rcPcieLinkCap/4]=(r32Pcie[rcPcieLinkCap/4]&0xFF7FFFFF)|((x<<23)&0x00800000))  //1
#define rmSetPcieLinkCapPortNumber(x)\
    (r32Pcie[rcPcieLinkCap/\
             4]=(r32Pcie[rcPcieLinkCap/4]&0x00FFFFFF)|((x<<24)&0xFF000000))

#define rcPcieLinkCtrl                                         0x80
#define rmChkHostEnAspm                                        (rPcie[rcPcieLinkCtrl]&0x03)
#define rmClrHostEnAspm                                        (rPcie[rcPcieLinkCtrl]&=0xFC)
#define rmSetAspmCtrl(x)                                       (rPcie[rcPcieLinkCtrl]=(rPcie[rcPcieLinkCtrl]&0xFC)|x)
#define rmChkHostEnL0s                                         (rPcie[rcPcieLinkCtrl]&cBit0)
#define rmChkHostEnL1                                          (rPcie[rcPcieLinkCtrl]&cBit1)
#define rmSetExtSync                                           (rPcie[rcPcieLinkCtrl]|=cBit7)
#define rmChkExtSync                                           (rPcie[rcPcieLinkCtrl]&cBit7)
#define rmClrExtSync                                           (rPcie[rcPcieLinkCtrl]&=(~cBit7))
#define rmChkHostEnClkPowerState                               (r16Pcie[rcPcieLinkCtrl/2]&c16Bit8)
// For PCIe mac low power when link in L1
#define rmSetHostEnClkPowerState                               (r16Pcie[rcPcieLinkCtrl/2]|=c16Bit8)
#define rmClrHostEnClkPowerState                               (r16Pcie[rcPcieLinkCtrl/2]&=(~c16Bit8))

#define rcPcieLinkStatus                                       0x82
// #define M_Set_Pcie_Link_Status(x)                            (r16Pcie[rcPcieLinkStatus/2]=x)
#define rmChkLinkSts                                           rPcie[rcPcieLinkStatus]
#define rmCheckCurrentSpeed                                    (r16Pcie[rcPcieLinkStatus/2]&0x000F)
#define rmCheckCurrentLinkWidth                                ((r16Pcie[rcPcieLinkStatus/2]&0x03F0)>>4)
#define rmCheckCurrentLinkWidthandSpeed                        rPcie[rcPcieLinkStatus]

#define rcPcieDeviceCap2                                       0x94
#define rmSetPcieDeviceCap2(x)                                 (r32Pcie[rcPcieDeviceCap2/4]=x)

#if _ENABLE_PCIE_LS
#define rmSetPcieDeviceCap2CompletionTimeoutRangesSupported(x) (r32Pcie[rcPcieDeviceCap2/4]=(r32Pcie[rcPcieDeviceCap2/4]&0xFFFFFFF0)|x)    // 4
#else
#define rmSetPcieDeviceCap2CompletionTimeoutRangesSupported(x)\
    (r32Pcie[rcPcieDeviceCap2/\
             4]=(r32Pcie[rcPcieDeviceCap2/4]&0xFFFFFFF0)|(x&0x0000000F))    //
//
// 4
#endif
#define rmSetPcieDeviceCap2CompletionTimeoutDisableSupported(x)\
    (r32Pcie[rcPcieDeviceCap2/\
             4]=(r32Pcie[rcPcieDeviceCap2/4]&0xFFFFFFEF)|((x<<4)&0x00000010))    //
//
// 1
#define rmSetPcieDeviceCap2AriForwardingSupported(x)\
    (r32Pcie[rcPcieDeviceCap2/\
             4]=(r32Pcie[rcPcieDeviceCap2/4]&0xFFFFFFDF)|((x<<5)&0x00000020))    //
//
// 1
#define rmSetPcieDeviceCap2AtomicOpRoutingSupported(x)\
    (r32Pcie[rcPcieDeviceCap2/\
             4]=(r32Pcie[rcPcieDeviceCap2/4]&0xFFFFFFBF)|((x<<6)&0x00000040))    //
//
// 1
#define rmSetPcieDeviceCap2AtomicOpCompleterSupported32Bit(x)\
    (r32Pcie[rcPcieDeviceCap2/\
             4]=(r32Pcie[rcPcieDeviceCap2/4]&0xFFFFFF7F)|((x<<7)&0x00000080))    //
//
// 1
#define rmSetPcieDeviceCap2AtomicOpCompleterSupported64Bit(x)\
    (r32Pcie[rcPcieDeviceCap2/\
             4]=(r32Pcie[rcPcieDeviceCap2/4]&0xFFFFFEFF)|((x<<8)&0x00000100))    //
//
// 1
#define rmSetPcieDeviceCap2CasCompleterSupported128Bit(x)\
    (r32Pcie[rcPcieDeviceCap2/\
             4]=(r32Pcie[rcPcieDeviceCap2/4]&0xFFFFFDFF)|((x<<9)&0x00000200))    //
//
// 1
#define rmSetPcieDeviceCap2NoRoEnabledPrprPassing(x)\
    (r32Pcie[rcPcieDeviceCap2/\
             4]=(r32Pcie[rcPcieDeviceCap2/4]&0xFFFFFBFF)|((x<<10)&0x00000400))    //
//
// 1
#if _ENABLE_PCIE_LS
#define rmSetPcieDeviceCap2LtrMechanismSupported(x)            (r32Pcie[rcPcieDeviceCap2/4]=(r32Pcie[rcPcieDeviceCap2/4]&0xFFFFF7FF)|x)    // 1
#else
#define rmSetPcieDeviceCap2LtrMechanismSupported(x)\
    (r32Pcie[rcPcieDeviceCap2/\
             4]=(r32Pcie[rcPcieDeviceCap2/4]&0xFFFFF7FF)|((x<<11)&0x00000800))    //
//
// 1
#endif
#define rmSetPcieDeviceCap2TphCompleterSupported(x)\
    (r32Pcie[rcPcieDeviceCap2/\
             4]=(r32Pcie[rcPcieDeviceCap2/4]&0xFFFFCFFF)|((x<<12)&0x00003000))    //
//
// 2
// LWORD Rsvd1  :4;
//                                             (r32Pcie[rcPcieDeviceCap2/4]=(r32Pcie[rcPcieDeviceCap2/4]&0xFFFC3FFF)|((x<<14)&0x0003C000)) //4
#if _ENABLE_PCIE_LS
#define rmSetPcieDeviceCap2ObffSupported(x)                    (r32Pcie[rcPcieDeviceCap2/4]=(r32Pcie[rcPcieDeviceCap2/4]&0xFFF3FFFF)|x)    // 2
#else
#define rmSetPcieDeviceCap2ObffSupported(x)\
    (r32Pcie[rcPcieDeviceCap2/\
             4]=(r32Pcie[rcPcieDeviceCap2/4]&0xFFF3FFFF)|((x<<18)&0x000C0000))    //
//
// 2
#endif
#define rmSetPcieDeviceCap2ExtendedFmtFiledSupported(x)\
    (r32Pcie[rcPcieDeviceCap2/\
             4]=(r32Pcie[rcPcieDeviceCap2/4]&0xFFEFFFFF)|((x<<20)&0x00100000))    //
//
// 1
#define rmSetPcieDeviceCap2End2EndTlpPrefixSupported(x)\
    (r32Pcie[rcPcieDeviceCap2/\
             4]=(r32Pcie[rcPcieDeviceCap2/4]&0xFFDFFFFF)|((x<<21)&0x00200000))    //
//
// 1
#define rmSetPcieDeviceCap2MaxEnd2EndTlpPrefixes(x)\
    (r32Pcie[rcPcieDeviceCap2/\
             4]=(r32Pcie[rcPcieDeviceCap2/4]&0xFF3FFFFF)|((x<<22)&0x00C00000))    //
//
// 2
#define rmClrPcieDeviceCap2RsrvBit  (r32Pcie[rcPcieDeviceCap2/4]=(r32Pcie[rcPcieDeviceCap2/4]&0x00FFFFFF))    // Rsvd2  :8;

#define rcPcieDeviceCtrl2                                      0x98
// #define rmSetLtrEnable                                       (r32Pcie[rcPcieDeviceCtrl2/4]|=c32Bit10)
// #define rmClrLtrEnable                                       (r32Pcie[rcPcieDeviceCtrl2/4]&=(~c32Bit10))

#define rmCompletionTimeoutValue(x)\
    (r32Pcie[rcPcieDeviceCtrl2/\
             4]=(r32Pcie[rcPcieDeviceCtrl2/4]&0xFFFFFFF0)|(x&0x0000000F))    //
//
// :4;
#define rmCompletionTimeoutDisable(x)\
    (r32Pcie[rcPcieDeviceCtrl2/\
             4]=(r32Pcie[rcPcieDeviceCtrl2/4]&0xFFFFFFEF)|(x&0x00000001)<<4)    //
//
// :1;
#define rmAriForwardingEnable(x)\
    (r32Pcie[rcPcieDeviceCtrl2/\
             4]=(r32Pcie[rcPcieDeviceCtrl2/4]&0xFFFFFFDF)|(x&0x00000001)<<5)    //
//
// :1;
#define rmAtomicOpRequesterEnable(x)\
    (r32Pcie[rcPcieDeviceCtrl2/\
             4]=(r32Pcie[rcPcieDeviceCtrl2/4]&0xFFFFFFBF)|(x&0x00000001)<<6)    //
//
// :1;
#define rmAtomicOpEgressBlocking(x)\
    (r32Pcie[rcPcieDeviceCtrl2/\
             4]=(r32Pcie[rcPcieDeviceCtrl2/4]&0xFFFFFF7F)|(x&0x00000001)<<7)    //
//
// :1;
#define rmIdoRequestEnable(x)\
    (r32Pcie[rcPcieDeviceCtrl2/\
             4]=(r32Pcie[rcPcieDeviceCtrl2/4]&0xFFFFFEFF)|(x&0x00000001)<<8)    //
//
// :1;
#define rmIdoCompletionEnable(x)\
    (r32Pcie[rcPcieDeviceCtrl2/\
             4]=(r32Pcie[rcPcieDeviceCtrl2/4]&0xFFFFFDFF)|(x&0x00000001)<<9)    //
//
// :1;
#define rmLtrMechanismEnable(x)\
    (r32Pcie[rcPcieDeviceCtrl2/\
             4]=(r32Pcie[rcPcieDeviceCtrl2/4]&0xFFFFFBFF)|(x&0x00000001)<<10)    //
//
// :1;
// #define Rsvd1
//
//
//                                                                                                                                         //:2;
#define rmObffEnable(x)\
    (r32Pcie[rcPcieDeviceCtrl2/\
             4]=(r32Pcie[rcPcieDeviceCtrl2/4]&0xFFFF9FFF)|(x&0x00000003)<<13)    //
//
// :2;
#define rmEnd2EndTlpPrefixBlocking(x)\
    (r32Pcie[rcPcieDeviceCtrl2/\
             4]=(r32Pcie[rcPcieDeviceCtrl2/4]&0xFFFF7FFF)|(x&0x00000001)<<15)    //
//
// :1;
// #define Rsvd2                                                //:16;

// #define rcPcieDeviceCtrl2                                      0x99
#define rmSetLtrEnable                                         (rPcie[rcPcieDeviceCtrl2+1]|=cBit2)
#define rmClrLtrEnable                                         (rPcie[rcPcieDeviceCtrl2+1]&=(~cBit2))
#define rmChkLtrEnable                                         (rPcie[rcPcieDeviceCtrl2+1]&cBit2)

#define rcPcieLinkCap2                                         0x9C
#define rmSetPcieLinkCap2(x)                                   (r32Pcie[rcPcieLinkCap2/4]=x)
// LWORD Rsvd1  :1;
//                                             (r32Pcie[rcPcieLinkCap2/4]=(r32Pcie[rcPcieLinkCap2/4]&0xFFFFFFFE)|(x&0x00000001))      //1
#if _ENABLE_PCIE_LS
#define rmSetPcieLinkCap2SupportedLinkSpeedsVector(x)          (r32Pcie[rcPcieLinkCap2/4]=(r32Pcie[rcPcieLinkCap2/4]&0xFFFFFF01)|x)    // 7
#else
#define rmSetPcieLinkCap2SupportedLinkSpeedsVector(x)\
    (r32Pcie[rcPcieLinkCap2/\
             4]=(r32Pcie[rcPcieLinkCap2/4]&0xFFFFFF01)|((x<<1)&0x000000FE))    //
//
// 7
#endif
#define rmSetPcieLinkCap2CrosslinkSupported(x)\
    (r32Pcie[rcPcieLinkCap2/\
             4]=(r32Pcie[rcPcieLinkCap2/4]&0xFFFFFEFF)|((x<<8)&0x00000100))    //
//
// 1
// LWORD Rsvd2  :22;
#define rmSetPcieLinkCap2PcieCapFrsSupported(x)\
    (r32Pcie[rcPcieLinkCap2/\
             4]=(r32Pcie[rcPcieLinkCap2/4]&0x7FFFFFFF)|((x<<31)&0x10000000))    //
//
// 1

#define rcPcieLinkCtrl2                                        0xA0
#define rmSetTargetSpeed(x)                                    (rPcie[rcPcieLinkCtrl2]=x)
#define rmSetPcieLinkCtrl2(x)                                  (r16Pcie[rcPcieLinkCtrl2/2]=x)
#define rmPcieLinkCtrl2                                        (r16Pcie[rcPcieLinkCtrl2/2])

#define rcPcieLinkStatus2                                      0xA2

#define rcMsixCapId                                            0xB0
#define rcMsixCapNextPtr                                       0xB1
#define rcMsixControlReg                                       0xB2
#define rmSetMsixId(x)                                         (rPcie[rcMsixCapId]=x)
#define rmSetMsixCapNextPtr(x)                                 (rPcie[rcMsixCapNextPtr]=x)
#define rmSetMsixCtrlReg(x)                                    (r16Pcie[rcMsixControlReg/2]=x)

// #define rmSetMsixCtrlRegTableSize(x)
//                         (r32Pcie[rcMsixControlReg/4]=(r32Pcie[rcMsixControlReg/4]&0xFFFFF100)|(x&0x000007FF))      //11
// //Reserved  :3;
//                                              (r32Pcie[rcMsixControlReg/4]=(r32Pcie[rcMsixControlReg/4]&0xFFFFC7FF)|((x<<11)&0x00003800))
//      //3
// #define rmSetMsixCtrlRegFunctionMask(x)
//                      (r32Pcie[rcMsixControlReg/4]=(r32Pcie[rcMsixControlReg/4]&0xFFFFBFFF)|((x<<14)&0x00004000))      //1
// #define rmSetMsixCtrlRegMsixEnable(x)
//                        (r32Pcie[rcMsixControlReg/4]=(r32Pcie[rcMsixControlReg/4]&0xFFFF7FFF)|((x<<15)&0x00008000))      //1
#if _ENABLE_PCIE_LS
#define rmSetMsixCtrlRegTableSize(x)                           (r16Pcie[rcMsixControlReg/2]=(r16Pcie[rcMsixControlReg/2]&0xF100)|x)    // 11
#else
#define rmSetMsixCtrlRegTableSize(x)                           (r16Pcie[rcMsixControlReg/2]=(r16Pcie[rcMsixControlReg/2]&0xF100)|(x&0x07FF))
#endif
// Reserved  :3;
//                                                (r16Pcie[rcMsixControlReg/2]=(r16Pcie[rcMsixControlReg/2]&0xC7FF)|((x<<11)&0x3800))      //3
#define rmSetMsixCtrlRegFunctionMask(x)\
    (r16Pcie[rcMsixControlReg/\
             2]=(r16Pcie[rcMsixControlReg/2]&0xBFFF)|((x<<14)&0x4000))    //
//
// 1
#define rmSetMsixCtrlRegMsixEnable(x)\
    (r16Pcie[rcMsixControlReg/\
             2]=(r16Pcie[rcMsixControlReg/2]&0x7FFF)|((x<<15)&0x8000))    //
//
// 1

#define rmChkMsixCtrlRegMsixEnable                             (r16Pcie[rcMsixControlReg/2]=r16Pcie[rcMsixControlReg/2]&0x8000)

#define rcMsixOffsetAndBir                                     0xB4
// #define rmSetMsixOffsetAndBir(x)                               (r32Pcie[rcMsixOffsetAndBir/4]=x)
// #define rmSetMsixTableOffset(x)\
//    (r32Pcie[rcMsixOffsetAndBir/\
//             4]=(r32Pcie[rcMsixOffsetAndBir/4]&0x00000007)|((x<<3)&0xFFFFFFF8))
#define rmSetMsixTableOffset(x)\
    (r32Pcie[rcMsixOffsetAndBir/\
             4]=(r32Pcie[rcMsixOffsetAndBir/4]&0x00000007)|((x&0x1FFFFFFF)<<3))

#define rcMsixPbaTableOffset                                   0xB8
// #define rmSetPbaMsixTableOffset(x)\
//    (r32Pcie[rcMsixPbaTableOffset/\
//             4]=(r32Pcie[rcMsixPbaTableOffset/4]&0x00000007)|((x<<3)&0xFFFFFFF8))
#define rmSetPbaMsixTableOffset(x)\
    (r32Pcie[rcMsixPbaTableOffset/\
             4]=(r32Pcie[rcMsixPbaTableOffset/4]&0x00000007)|((x&0x1FFFFFFF)<<3))

#define rcAdvancedErrorReport                                  0x100
#define rmSetAdvancedErrorReport(x)                            (r32Pcie[rcAdvancedErrorReport/4]=x)

#define rcUncorrectableErrorMaskAer                            0x108
#define rmSetUncorrectableErrorMaskAer(x)                      (r32Pcie[rcUncorrectableErrorMaskAer/4]=x)
#define rmUncorrectableErrorMaskAer                            (r32Pcie[rcUncorrectableErrorMaskAer/4])

#define rcUncorrectableErrorSeverityAer                        0x10C
#define rmSetUncorrectableErrorSeverityAer(x)                  (r32Pcie[rcUncorrectableErrorSeverityAer/4]=x)
#define rmUncorrectableErrorSeverityAer                        (r32Pcie[rcUncorrectableErrorSeverityAer/4])

#define rcCorrectableAerStsOff                                 0x110
#define rmSetCorrectableAerStsOff(x)                           (r32Pcie[rcCorrectableAerStsOff/4]=x)
#define rmDetectAerRxError                                     (r32Pcie[rcCorrectableAerStsOff/4]&0x0001)
#define rmClrDetectAerRxError                                  (r32Pcie[rcCorrectableAerStsOff/4]&=0xFFFE)

#define rcCorrectableErrorMaskAer                              0x114
#define rmSetCorrectableErrMaskAer(x)                          (r32Pcie[rcCorrectableErrorMaskAer/4]=x)
#define rmCorrectableErrMaskAer                                (r16Pcie[rcCorrectableErrorMaskAer/2])

#define rcAdvancedErrorCapAndControlAer                        0x118
#define rmSetAdvancedErrCapandCtrlAer(x)                       (r32Pcie[rcAdvancedErrorCapAndControlAer/4]=x)
#define rmAdvancedErrCapandCtrlAer                             (r32Pcie[rcAdvancedErrorCapAndControlAer/4])

#define rmSetAerCapCtrlEcrcGenerationCap(x)\
    (rPcie[rcAdvancedErrorCapAndControlAer]=\
         (rPcie[rcAdvancedErrorCapAndControlAer]&0xDF)|x)
#define rmSetAerCapCtrlEcrcCheckCap(x)\
    (rPcie[rcAdvancedErrorCapAndControlAer]=\
         (rPcie[rcAdvancedErrorCapAndControlAer]&0x7F)|x)

#define rcAerHeaderLog0                                        0x11C
#define rmAerHeaderLog0                                        (r32Pcie[rcAerHeaderLog0/4])

#define rcAerHeaderLog1                                        0x120
#define rmAerHeaderLog1                                        (r32Pcie[rcAerHeaderLog1/4])

#define rcAerHeaderLog2                                        0x124
#define rmAerHeaderLog2                                        (r32Pcie[rcAerHeaderLog2/4])

#define rcAerHeaderLog3                                        0x128
#define rmAerHeaderLog3                                        (r32Pcie[rcAerHeaderLog3/4])

#define rcEqCtlLane0                                           0x165
#define rmCheckPreset(x)                                       (rPcie[rcEqCtlLane0+(x*2)]&0x0F)

#define rcLtrMaxSnoopLatency                                   0x17C
#define rmClrLtrMaxSnoopLatency                                (r16Pcie[rcLtrMaxSnoopLatency/2]&=0xE000)
#define rmGetLtrMaxSnoopLatency                                (r16Pcie[rcLtrMaxSnoopLatency/2]&0x1FFF)    // scale+value

#define rcLtrMaxNoSnoopLatency                                 0x17E
#define rmClrLtrMaxNoSnoopLatency                              (r16Pcie[rcLtrMaxNoSnoopLatency/2]&=0xE000)
#define rmGetLtrMaxNoSnoopLatency                              (r16Pcie[rcLtrMaxNoSnoopLatency/2]&0x1FFF)    // scale+value

#define rcL1PmSubstate                                         0x180
#define rmSetL1PmSubstate(x)                                   (r32Pcie[rcL1PmSubstate/4]=x)

#define rcL1SubStateCap                                        0x184
#define rmChkSupportAspmL11                                    (r32Pcie[rcL1SubStateCap/4]&c32Bit3)
#define rmChkSupportAspmL12                                    (r32Pcie[rcL1SubStateCap/4]&c32Bit2)
#define rmChkSupportPmL11                                      (r32Pcie[rcL1SubStateCap/4]&c32Bit1)
#define rmChkSupportPmL12                                      (r32Pcie[rcL1SubStateCap/4]&c32Bit0)
#define rmSetAspmL11Support(x)                                 (r32Pcie[rcL1SubStateCap/4]=(r32Pcie[rcL1SubStateCap/4]&(~c32Bit3))|(x&c32Bit3))
#define rmSetAspmL12Support(x)                                 (r32Pcie[rcL1SubStateCap/4]=(r32Pcie[rcL1SubStateCap/4]&(~c32Bit2))|(x&c32Bit2))

#define rcL1SubStateCtrl                                       0x188
#define rmChkHostEnAspmL11                                     (r32Pcie[rcL1SubStateCtrl/4]&c32Bit3)
#define rmChkHostEnAspmL12                                     (r32Pcie[rcL1SubStateCtrl/4]&c32Bit2)
#define rmSetHostEnAspmL12                                     (r32Pcie[rcL1SubStateCtrl/4]|=c32Bit2)
#define rmClrHostEnAspmL12                                     (r32Pcie[rcL1SubStateCtrl/4]&=~c32Bit2)
#define rmChkHostEnPmL11                                       (r32Pcie[rcL1SubStateCtrl/4]&c32Bit1)
#define rmChkHostEnPmL12                                       (r32Pcie[rcL1SubStateCtrl/4]&c32Bit0)
#define rmSetHostEnPmL12                                       (r32Pcie[rcL1SubStateCtrl/4]|=c32Bit0)
#define rmClrHostEnPmL12                                       (r32Pcie[rcL1SubStateCtrl/4]&=~c32Bit0)
#define rmChkHostEnAspmL11L12                                  (r32Pcie[rcL1SubStateCtrl/4]&0x00000003)
#define rmClrHostEnAspmL11L12                                  (r32Pcie[rcL1SubStateCtrl/4]&=(~(c32Bit2|c32Bit3)))

#define rcRxAckSeqNo                                           0x288
#define rmChkRxAckSeqNo                                        ((r32Pcie[rcRxAckSeqNo/4]&0x00FFF000)>>12)    // bit[23:12]

#define rcAckLatencyReplayTimer                                0x700
#define rmSetAckLatencyReplayTimer(x)                          (r32Pcie[rcAckLatencyReplayTimer/4]=x)

#define cSetAckLatencyTimerLimit                               (0x0012)
#define cSetReplayTimerLimit                                   (0x0036<<16)

#define rcPortFroceLink                                        0x708
#define rmSetPortFroceLink(x)                                  (r32Pcie[rcPortFroceLink/4]=x)
#define rmSetForceEn                                           (rPcie[rcPortFroceLink+1]=0x80)    // y900a

#define rcPortFroceLinkLtssm                                   0x70A
#define rmSetPortFroceLinkLtssm(x)                             (rPcie[rcPortFroceLinkLtssm]=x)

#define cSetLowPowerEntranceCount                              (0x00000070<<24)

#define rcAckFreqL0L1AspmCtrl                                  0x70C
#define rmAckFreqL0L1AspmCtrl(x)                               (r32Pcie[rcAckFreqL0L1AspmCtrl/4]=x)
// #define rmSetL1Entry(x)
//                                      (r32Pcie[rcAckFreqL0L1AspmCtrl/4]=((r32Pcie[rcAckFreqL0L1AspmCtrl/4]&0xC7FFFFFF)|((x&0x00000007)<<27)))
#define rmSetL1Entry(x)                                        (r32Pcie[rcAckFreqL0L1AspmCtrl/4]=(r32Pcie[rcAckFreqL0L1AspmCtrl/4]|x))

#define cSetEnterAspmL1WithoutRcvInL0s                         (0x00000001<<30)
#define cSetL1EntranceLatency                                  (0x00000003<<27)
#define cSetL0sEntranceLatency                                 (0x00000003<<24)
#define cSetCommonClkNfts                                      (0x00000046<<16)
#define cSetAckNfts                                            (0x00000046<<8)
#define cSetAckFreq                                            (0x00000000)

#define rcPortLinkCtrl                                         0x710
#define rmSetPortLinkCtrl(x)                                   (r32Pcie[rcPortLinkCtrl/4]=x)
#define rmSetLinkCapable(x)                                    (rPcie[rcPortLinkCtrl+2]=x)
#define rmSetLinkMode1                                         (rPcie[rcPortLinkCtrl+2]=(rPcie[rcPortLinkCtrl+2]&(~(0x3F)))|0x01)

#define rmSetPortLinkCtrlVendorSpecDllpReq(x)                  (r32Pcie[rcPortLinkCtrl/4]=(r32Pcie[rcPortLinkCtrl/4]&0xFFFFFFFE)|(x&0x00000001))
#define rmSetPortLinkCtrlScrambleDis(x)\
    (r32Pcie[rcPortLinkCtrl/\
             4]=(r32Pcie[rcPortLinkCtrl/4]&0xFFFFFFFD)|((x<<1)&0x00000002))
#define rmSetPortLinkCtrlLoopBackEn(x)\
    (r32Pcie[rcPortLinkCtrl/\
             4]=(r32Pcie[rcPortLinkCtrl/4]&0xFFFFFFFB)|((x<<2)&0x00000004))
#define rmSetPortLinkCtrlResetAssert(x)\
    (r32Pcie[rcPortLinkCtrl/\
             4]=(r32Pcie[rcPortLinkCtrl/4]&0xFFFFFFF7)|((x<<3)&0x00000008))
// LWORD Rsvd1   :1;
//                                            (r32Pcie[rcPortLinkCtrl/4]=(r32Pcie[rcPortLinkCtrl/4]&0xFFFFFFEF)|((x<<4)&0x00000010))      //1
#define rmSetPortLinkCtrlDllLinkEn(x)\
    (r32Pcie[rcPortLinkCtrl/\
             4]=(r32Pcie[rcPortLinkCtrl/4]&0xFFFFFFDF)|((x<<5)&0x00000020))
// LWORD Rsvd2   :1;
//                                            (r32Pcie[rcPortLinkCtrl/4]=(r32Pcie[rcPortLinkCtrl/4]&0xFFFFFFBF)|((x<<6)&0x00000040))      //1
#define rmSetPortLinkCtrlFastLinkMode(x)\
    (r32Pcie[rcPortLinkCtrl/\
             4]=(r32Pcie[rcPortLinkCtrl/4]&0xFFFFFF7F)|((x<<7)&0x00000080))
// LWORD Rsvd3   :8;
//                                            (r32Pcie[rcPortLinkCtrl/4]=(r32Pcie[rcPortLinkCtrl/4]&0xFFFF00FF)|((x<<8)&0x0000FF00))      //8
#define rmSetPortLinkCtrlLinkModeEn(x)\
    (r32Pcie[rcPortLinkCtrl/\
             4]=(r32Pcie[rcPortLinkCtrl/4]&0xFFC0FFFF)|((x<<16)&0x003F0000))
// LWORD Rsvd4   :10;

#define rcPcieCfgLaneSkew                                      0x714
#define rmSetFwSetL1EnterL1Sub                                 (rPcie[rcPcieCfgLaneSkew]|=cBit1)
#define rmClrFwSetL1EnterL1Sub                                 (rPcie[rcPcieCfgLaneSkew]&=(~cBit1))

#define rcPcieStrfm                                            0x71C
#define rmPcieDisDropMsgTlp                                    (rPcie[rcPcieStrfm+3]|=cBit5)
#define rmPcieEnDropMsgTlp                                     (rPcie[rcPcieStrfm+3]&=(~cBit5))

#define rcPcieLtssmMac                                         0x728
#define rmDetectLtssmPreDetMac                                 ((rPcie[rcPcieLtssmMac]&0x3F)==0x05)

#define rcLinkWidthSpdChgCtrl                                  0x80C
#define rmSetLinkWidthSpdChgCtrl(x)                            (r32Pcie[rcLinkWidthSpdChgCtrl/4]=x)
#define rmSetLink1Lane                                         (rPcie[rcLinkWidthSpdChgCtrl+1]=0x01)
#define rmSetDirSpdChg                                         (rPcie[rcLinkWidthSpdChgCtrl+2]|=cBit1)
#define rmClrDirSpdChg                                         (rPcie[rcLinkWidthSpdChgCtrl+2]&=(~cBit1))

#define rmSetLinkWidthSpdChgCtrlNfts(x)\
    (r32Pcie[rcLinkWidthSpdChgCtrl/\
             4]=(r32Pcie[rcLinkWidthSpdChgCtrl/4]&0xFFFFFF00)|(x&0x000000FF))
#define rmSetLinkWidthSpdChgCtrlNumOfLanes(x)\
    (r32Pcie[rcLinkWidthSpdChgCtrl/\
             4]=(r32Pcie[rcLinkWidthSpdChgCtrl/4]&0xFFFFE0FF)|((x<<8)&0x00001F00))
#define rmSetLinkWidthSpdChgCtrlPredeterminedLanes(x)\
    (r32Pcie[rcLinkWidthSpdChgCtrl/\
             4]=(r32Pcie[rcLinkWidthSpdChgCtrl/4]&0xFFFF1FFF)|((x<<13)&0x0000E000))
#define rmSetLinkWidthSpdChgCtrlAutoLaneFlipCtrLen(x)\
    (r32Pcie[rcLinkWidthSpdChgCtrl/\
             4]=(r32Pcie[rcLinkWidthSpdChgCtrl/4]&0xFFFEFFFF)|((x<<16)&0x00010000))
#define rmSetLinkWidthSpdChgCtrlDirectedSpeedChange(x)\
    (r32Pcie[rcLinkWidthSpdChgCtrl/\
             4]=(r32Pcie[rcLinkWidthSpdChgCtrl/4]&0xFFFDFFFF)|((x<<17)&0x00020000))
#define rmSetLinkWidthSpdChgCtrlConfigPhyTxSwing(x)\
    (r32Pcie[rcLinkWidthSpdChgCtrl/\
             4]=(r32Pcie[rcLinkWidthSpdChgCtrl/4]&0xFFFBFFFF)|((x<<18)&0x00040000))
#define rmSetLinkWidthSpdChgCtrlConfigTxComplianceRcvBit(x)\
    (r32Pcie[rcLinkWidthSpdChgCtrl/\
             4]=(r32Pcie[rcLinkWidthSpdChgCtrl/4]&0xFFF7FFFF)|((x<<19)&0x00080000))
#define rmSetLinkWidthSpdChgCtrlDeEmphasisUpstreamPorts(x)\
    (r32Pcie[rcLinkWidthSpdChgCtrl/\
             4]=(r32Pcie[rcLinkWidthSpdChgCtrl/4]&0xFFEFFFFF)|((x<<20)&0x00100000))
// LWORD Rsvd  :11;

#define rcGen3CtrlReg                                          0x890
#define rmSetGen3CtrlReg(x)                                    (r32Pcie[rcGen3CtrlReg/4]=x)

#define rcGen3EqCtrlOffReg                                     0x8A8
#define rmSetGen3EqPsetReqVecReg(y, x)                         (rPcie[rcGen3EqCtrlOffReg+1+y]=x)
#define rmSet16Gen3EqPsetReqVecReg(x)                          (r32Pcie[rcGen3EqCtrlOffReg/4]=(r32Pcie[rcGen3EqCtrlOffReg/4]&0xFF0000FF)|(x<<8))

#define rcGen3EqDirFeedbackCtrl                                0x8AC
#define rmSetGen3EqFmdcTminPhase23(x)                          (rPcie[rcGen3EqDirFeedbackCtrl]=x)

#define rcMiscCtrl1Off                                         0x8BC    // DBI Read-Only Write Enable Register
#define rmEnPcieDbiroWrite                                     r32Pcie[rcMiscCtrl1Off/4]=c32Bit0
#define rmDisPcieDbiroWrite                                    r32Pcie[rcMiscCtrl1Off/4]=0

#define rcLinkFlushControlOff                                   0x8CC
#define rmSetAutoFlushEn                                        (rPcie[rcLinkFlushControlOff]|=cBit0)
#define rmClrAutoFlushEn                                        (rPcie[rcLinkFlushControlOff]&=~cBit0)    // 20190521_LeverYu_PS3 APST abort

#define rcAuxClkFreqOff                                        0xB40
#define rmSetAuxClkFreq(x)                                     (r32Pcie[rcAuxClkFreqOff/4]=(x&0x3FF))

#define rcL12SleepTime                                         0xB44
#define rmSetL12SleepTime(x)                                  (rPcie[rcL12SleepTime]=x)

// Pcie HW Control Register @0x50001C00

#define rcPcieAppCtrl                                          0xC00
#define rmSetPcieAppCtrl(x)                                    (r32Pcie[rcPcieAppCtrl/4]=x)

// LWORD Rsvd1  :1;                                             (r32Pcie[rcPcieAppCtrl/4]=(r32Pcie[rcPcieAppCtrl/4]&0xFFFFFFFE)|(x&0x00000001))
//        //1
#define rmSetPcieAppCtrlAppsPmXmtPme(x)\
    (r32Pcie[rcPcieAppCtrl/\
             4]=(r32Pcie[rcPcieAppCtrl/4]&0xFFFFFFFD)|((x<<1)&0x00000002))
#define rmSetPcieAppCtrlAppReqEntrL1(x)\
    (r32Pcie[rcPcieAppCtrl/\
             4]=(r32Pcie[rcPcieAppCtrl/4]&0xFFFFFFFB)|((x<<2)&0x00000004))
#define rmSetPcieAppCtrlAppReqExitL1(x)\
    (r32Pcie[rcPcieAppCtrl/\
             4]=(r32Pcie[rcPcieAppCtrl/4]&0xFFFFFFF7)|((x<<3)&0x00000008))
#define rmSetPcieAppCtrlAppReadyEntrL23(x)\
    (r32Pcie[rcPcieAppCtrl/\
             4]=(r32Pcie[rcPcieAppCtrl/4]&0xFFFFFFEF)|((x<<4)&0x00000010))
// LWORD Rsvd2  :1;
//                                             (r32Pcie[rcPcieAppCtrl/4]=(r32Pcie[rcPcieAppCtrl/4]&0xFFFFFFDF)|((x<<5)&0x00000020))   //1
#define rmSetPcieAppCtrlAppClkPmEn(x)\
    (r32Pcie[rcPcieAppCtrl/\
             4]=(r32Pcie[rcPcieAppCtrl/4]&0xFFFFFFBF)|((x<<6)&0x00000040))
#define rmSetPcieAppCtrlAppLtssmEn(x)\
    (r32Pcie[rcPcieAppCtrl/\
             4]=(r32Pcie[rcPcieAppCtrl/4]&0xFFFFFF7F)|((x<<7)&0x00000080))
#define rmSetPcieAppCtrlWriteMacCS2(x)\
    (r32Pcie[rcPcieAppCtrl/\
             4]=(r32Pcie[rcPcieAppCtrl/4]&0xFFFFFEFF)|((x<<8)&0x00000100))
#define rmSetPcieAppCtrlCdmSelStickyRst(x)\
    (r32Pcie[rcPcieAppCtrl/\
             4]=(r32Pcie[rcPcieAppCtrl/4]&0xFFFFFDFF)|((x<<9)&0x00000200))
#define rmSetPcieAppCtrlNvmeEn(x)\
    (r32Pcie[rcPcieAppCtrl/\
             4]=(r32Pcie[rcPcieAppCtrl/4]&0xFFFFFBFF)|((x<<10)&0x00000400))
#define rmSetPcieAppCtrlAppReqRetryEn(x)\
    (r32Pcie[rcPcieAppCtrl/\
             4]=(r32Pcie[rcPcieAppCtrl/4]&0xFFFFF7FF)|((x<<11)&0x00000800))
#define rmSetPcieAppCtrlCfgL1AuxClkSwitchCoreClkGateEn(x)\
    (r32Pcie[rcPcieAppCtrl/\
             4]=(r32Pcie[rcPcieAppCtrl/4]&0xFFFFEFFF)|((x<<12)&0x00001000))
#define rmSetPcieAppCtrlFlushEn(x)\
    (r32Pcie[rcPcieAppCtrl/\
             4]=(r32Pcie[rcPcieAppCtrl/4]&0xFFFFDFFF)|((x<<13)&0x00002000))
#define rmSetPcieAppCtrlCfgFroceTwoLane(x)\
    (r32Pcie[rcPcieAppCtrl/\
             4]=(r32Pcie[rcPcieAppCtrl/4]&0xFFFFBFFF)|((x<<14)&0x00004000))
#define rmSetPcieAppCtrlCfgFroceOneLane(x)\
    (r32Pcie[rcPcieAppCtrl/\
             4]=(r32Pcie[rcPcieAppCtrl/4]&0xFFFF7FFF)|((x<<15)&0x00008000))
#define rmSetPcieAppCtrlPmCurrentState(x)\
    (r32Pcie[rcPcieAppCtrl/\
             4]=(r32Pcie[rcPcieAppCtrl/4]&0xFFF8FFFF)|((x<<16)&0x00070000))
#define rmSetPcieAppCtrlXmlhLtssmState(x)\
    (r32Pcie[rcPcieAppCtrl/\
             4]=(r32Pcie[rcPcieAppCtrl/4]&0xFE07FFFF)|((x<<19)&0x01F80000))
#define rmSetPcieAppCtrlCfgLinkRstDlyEn(x)\
    (r32Pcie[rcPcieAppCtrl/\
             4]=(r32Pcie[rcPcieAppCtrl/4]&0xFDFFFFFF)|((x<<25)&0x02000000))
#define rmSetPcieAppCtrlFwPerstN(x)\
    (r32Pcie[rcPcieAppCtrl/\
             4]=(r32Pcie[rcPcieAppCtrl/4]&0xFBFFFFFF)|((x<<26)&0x04000000))
#define rmSetPcieAppCtrlPerstN(x)\
    (r32Pcie[rcPcieAppCtrl/\
             4]=(r32Pcie[rcPcieAppCtrl/4]&0xF7FFFFFF)|((x<<27)&0x08000000))
#define rmSetPcieAppCtrlCfgPerstNhostEn(x)\
    (r32Pcie[rcPcieAppCtrl/\
             4]=(r32Pcie[rcPcieAppCtrl/4]&0xEFFFFFFF)|((x<<28)&0x10000000))
// LWORD Rsvd3  :3;

#define rmStickyEn                                             (r16Pcie[rcPcieAppCtrl/2]|=c16Bit9)

#define rmAppForce1Lan                                         (rPcie[rcPcieAppCtrl+1]=rPcie[rcPcieAppCtrl+1]&0x3F|cBit7)
#define rmPcieAppLtssmEn                                       (rPcie[rcPcieAppCtrl]|=cBit7)
#define rmChkPcieAppLtssmEn                                    (rPcie[rcPcieAppCtrl]&cBit7)
#define rmPcieAppLtssmDis                                      (rPcie[rcPcieAppCtrl]&=(~cBit7))
#define rmSetAppClkPmEn                                        (rPcie[rcPcieAppCtrl]|=cBit6)
#define rmClrAppClkPmEn                                        (rPcie[rcPcieAppCtrl]&=(~cBit6))
#define rmSetAppReadyEntry123                                  (rPcie[rcPcieAppCtrl]|=cBit4)
#define rmClrAppReadyEntry123                                  (rPcie[rcPcieAppCtrl]&=(~cBit4))
#define rmPcieForceLeaveL1                                     (rPcie[rcPcieAppCtrl]|=cBit3)
#define rmPcieDisForceLeaveL1                                  (rPcie[rcPcieAppCtrl]&=(~cBit3))
#define rmPcieForceEnterL1                                     (rPcie[rcPcieAppCtrl]|=cBit2)
#define rmPcieDisForceEnterL1                                  (rPcie[rcPcieAppCtrl]&=(~cBit2))
#define rmPcieCs2En                                            (rPcie[rcPcieAppCtrl+1]|=cBit0)
#define rmPcieCs2Dis                                           (rPcie[rcPcieAppCtrl+1]&=(~cBit0))
#define rmEnSwitchAuxClk                                       (rPcie[rcPcieAppCtrl+1]|=cBit4)
#define rmDisSwitchAuxClk                                      (rPcie[rcPcieAppCtrl+1]&=(~cBit4))
#define rmChkSwitchAuxClk                                      (rPcie[rcPcieAppCtrl+1]&cBit4)

#define rmChkPcieDxstate                                       (rPcie[rcPcieAppCtrl+2]&0x07)
#define rmChkPcieD0State                                       ((rPcie[rcPcieAppCtrl+2]&0x07)==0)
#define rmChkPcieD1State                                       ((rPcie[rcPcieAppCtrl+2]&0x07)==1)
#define rmChkPcieD3State                                       ((rPcie[rcPcieAppCtrl+2]&0x07)==3)

#define rmLinkRstDlyDis                                        (rPcie[rcPcieAppCtrl+3]|=cBit1)    // Wrong define??
#define rmLinkRstDlyEn                                         (rPcie[rcPcieAppCtrl+3]&=(~cBit1))    // Wrong define??
#define rmSetFwPeRst                                           (rPcie[rcPcieAppCtrl+3]&=(~cBit2))    // 2263
#define rmClrFwPeRst                                           (rPcie[rcPcieAppCtrl+3]|=cBit2)    // 2263
#define rmSwFwModePeRst                                        (rPcie[rcPcieAppCtrl+3]&=(~cBit4))    // 2263
#define rmSwHwModePeRst                                        (rPcie[rcPcieAppCtrl+3]|=cBit4)    // 2263

#define rmPcieNvmeEn                                           (r32Pcie[rcPcieAppCtrl/4]|=0x00000400)
// if you need to use Fake engine, disable NVME first
#define rmPcieNvmeDis                                          (r32Pcie[rcPcieAppCtrl/4]&=(~c32Bit10))

#define rmPcieFastSimulationMode                               (r32Pcie[rcPcieAppCtrl/4]|=c32Bit29)

#define rcPcieLtssm                                            0xC04    // Pcie peripheral register
#define rmDetectLtssmPreDet                                    ((rPcie[rcPcieLtssm]&0x3F)==0x05)
#define rmDetectLtssmL1                                        ((rPcie[rcPcieLtssm]&0x3F)==0x14)
#define rmDetectLtssmLPbkAct                                   ((rPcie[rcPcieLtssm]&0x3F)==0x1B)
#define rmDetectLinkState                                      (rPcie[rcPcieLtssm]&0x3F)

#define rcPcieVenMsgCtrl0                                      0xC1C
#define rmSetPcieVenMsgCtrl0(x)                                (r32Pcie[rcPcieVenMsgCtrl0/4]=x)

#define rcPcieVenMsgCtrl02                                     0xC1E
#define rmReqPcieVenMsg                                        (rPcie[rcPcieVenMsgCtrl02]=0x80)

#define rcPcieVenMsgCtrl1                                      0xC20
#define rmSetPcieVenMsgCtrl1(x)                                (r32Pcie[rcPcieVenMsgCtrl1/4]=x)

#define rcPcieVenMsgCtrl2                                      0xC24
#define rmSetPcieVenMsgCtrl2(x)                                (r32Pcie[rcPcieVenMsgCtrl2/4]=x)

#define rcPcieVenMsgCtrl3                                      0xC28
#define rmSetPcieVenMsgCtrl3(x)                                (r32Pcie[rcPcieVenMsgCtrl3/4]=x)

#define rcLtrMsgReg0                                           0xC2C
#define rmSetLtrMsgReg0(x)                                     (r32Pcie[rcLtrMsgReg0/4]=x)

#define rmSetLtrMsgReg0LtrMsgFwEn(x)                           (r32Pcie[rcLtrMsgReg0/4]=(r32Pcie[rcLtrMsgReg0/4]&0xFFFFFFFE)|((x)&0x00000001))
#define rmSetLtrMsgReg0LtrMsgActiveEn(x)\
    (r32Pcie[rcLtrMsgReg0/4]=(r32Pcie[rcLtrMsgReg0/4]&0xFFFFFFFD)|\
                              ((x<<1)&0x00000002))
#define rmSetLtrMsgReg0LtrMsgActiveL1En(x)\
    (r32Pcie[rcLtrMsgReg0/4]=(r32Pcie[rcLtrMsgReg0/4]&0xFFFFFFFB)|\
                              ((x<<2)&0x00000004))
#define rmSetLtrMsgReg0LtrMsgActiveL0sEn(x)\
    (r32Pcie[rcLtrMsgReg0/4]=(r32Pcie[rcLtrMsgReg0/4]&0xFFFFFFF7)|\
                              ((x<<3)&0x00000008))
// LWORD Rsvd1               : 26;

#define rmChkLtrMsgReg0LtrMsgActiveEn                          (r32Pcie[rcLtrMsgReg0/4]&0x00000001)    // 1
#define rmChkLtrMsgReg0LtrMsgIdle0En                           (r32Pcie[rcLtrMsgReg0/4]&0x00000002)    // 1
#define rmChkLtrMsgReg0LtrMsgIdle1En                           (r32Pcie[rcLtrMsgReg0/4]&0x00000004)    // 1
#define rmChkLtrMsgReg0LtrMsgIdle2En                           (r32Pcie[rcLtrMsgReg0/4]&0x00000008)    // 1
#define rmChkLtrMsgReg0LtrMsgIdle3En                           (r32Pcie[rcLtrMsgReg0/4]&0x00000010)    // 1
#define rmChkLtrMsgReg0LtrMsgFwEn                              (r32Pcie[rcLtrMsgReg0/4]&0x00000020)    // 1
// LWORD Rsvd1               : 26;

// #define rcPcieL1Patch                                          0xC2F
// #define rmPcieEnL1Patch                                        (rPcie[rcPcieL1Patch]=0x08)

// #define rcLtrMsgReg1                                           0xC30
// #if _ENABLE_PCIE_LS
// #define rmSetLtrMsgReg1Timer0(x)                               (r32Pcie[rcLtrMsgReg1/4]=(r32Pcie[rcLtrMsgReg1/4]&0xFFFF0000)|x)    // 16
// #define rmSetLtrMsgReg1Timer1(x)                               (r32Pcie[rcLtrMsgReg1/4]=(r32Pcie[rcLtrMsgReg1/4]&0x0000FFFF)|x)    // 16
// #else
// #define rmSetLtrMsgReg1Timer0(x)                               (r32Pcie[rcLtrMsgReg1/4]=(r32Pcie[rcLtrMsgReg1/4]&0xFFFF0000)|(x&0x0000FFFF))
// #define rmSetLtrMsgReg1Timer1(x)\
//    (r32Pcie[rcLtrMsgReg1/\
//             4]=(r32Pcie[rcLtrMsgReg1/4]&0x0000FFFF)|((x<<16)&0xFFFF0000))
// #endif
//
// #define rcLtrMsgReg2                                           0xC34
// #define rmSetLtrMsgReg2Timer0(x)                               (r32Pcie[rcLtrMsgReg2/4]=(r32Pcie[rcLtrMsgReg2/4]&0xFFFF0000)|(x&0x0000FFFF))
// #define rmSetLtrMsgReg2Timer1(x)\
//    (r32Pcie[rcLtrMsgReg2/\
//             4]=(r32Pcie[rcLtrMsgReg2/4]&0x0000FFFF)|((x<<16)&0xFFFF0000))

#define rcLtrMsgCmdActiveL0Reg                                 0xC30
#define rmSetMacLtrL0(x)                                       (r32Pcie[rcLtrMsgCmdActiveL0Reg/4]=(x))
#if _ENABLE_PCIE_LS
#define rmSetLtrMsgReg3MaxSnoopLatencyValue(x)\
    (r32Pcie[rcLtrMsgCmdActiveL0Reg/\
             4]=(r32Pcie[rcLtrMsgCmdActiveL0Reg/4]&0xFFFFFC00)|x)    //
// 10
#define rmSetLtrMsgReg3MaxSnoopLatencyScale(x)\
    (r32Pcie[rcLtrMsgCmdActiveL0Reg/\
             4]=(r32Pcie[rcLtrMsgCmdActiveL0Reg/4]&0xFFFFE3FF)|x)    //
// 3
// LWORD Rsvd1                           :   2;
//                 (r32Pcie[rcLtrMsgCmdActiveL0Reg/4]=(r32Pcie[rcLtrMsgCmdActiveL0Reg/4]&0xFFFF9FFF)|x)   //2
#define rmSetLtrMsgReg3SnoopLatencyRequirement(x)\
    (r32Pcie[rcLtrMsgCmdActiveL0Reg/\
             4]=(r32Pcie[rcLtrMsgCmdActiveL0Reg/4]&0xFFFF7FFF)|x)    //
// 1
#define rmSetLtrMsgReg3MaxNoSnoopLatencyValue(x)\
    (r32Pcie[rcLtrMsgCmdActiveL0Reg/\
             4]=(r32Pcie[rcLtrMsgCmdActiveL0Reg/4]&0xFC00FFFF)|x)    //
// 10
#define rmSetLtrMsgReg3MaxNoSnoopLatencyScale(x)\
    (r32Pcie[rcLtrMsgCmdActiveL0Reg/\
             4]=(r32Pcie[rcLtrMsgCmdActiveL0Reg/4]&0xE3FFFFFF)|x)    //
// 3
// LWORD Rsvd2                           :   2;
//                 (r32Pcie[rcLtrMsgCmdActiveL0Reg/4]=(r32Pcie[rcLtrMsgCmdActiveL0Reg/4]&0x9FFFFFFF)|x)   //2
#define rmSetLtrMsgReg3NoSnoopLatencyRequirement(x)\
    (r32Pcie[rcLtrMsgCmdActiveL0Reg/\
             4]=(r32Pcie[rcLtrMsgCmdActiveL0Reg/4]&0x7FFFFFFF)|x)    //
// 1
#else    // if _ENABLE_PCIE_LS
#define rmSetLtrMsgReg3MaxSnoopLatencyValue(x)\
    (r32Pcie[rcLtrMsgCmdActiveL0Reg/\
             4]=(r32Pcie[rcLtrMsgCmdActiveL0Reg/4]&0xFFFFFC00)|(x&0x000003FF))
#define rmSetLtrMsgReg3MaxSnoopLatencyScale(x)\
    (r32Pcie[rcLtrMsgCmdActiveL0Reg/\
             4]=(r32Pcie[rcLtrMsgCmdActiveL0Reg/4]&0xFFFFE3FF)|((x<<10)&0x00001C00))
// LWORD Rsvd1                           :   2;
//                 (r32Pcie[rcLtrMsgCmdActiveL0Reg/4]=(r32Pcie[rcLtrMsgCmdActiveL0Reg/4]&0xFFFF9FFF)|((x<<13)&0x00006000))   //2
#define rmSetLtrMsgReg3SnoopLatencyRequirement(x)\
    (r32Pcie[rcLtrMsgCmdActiveL0Reg/\
             4]=(r32Pcie[rcLtrMsgCmdActiveL0Reg/4]&0xFFFF7FFF)|((x<<15)&0x00008000))
#define rmSetLtrMsgReg3MaxNoSnoopLatencyValue(x)\
    (r32Pcie[rcLtrMsgCmdActiveL0Reg/\
             4]=(r32Pcie[rcLtrMsgCmdActiveL0Reg/4]&0xFC00FFFF)|((x<<16)&0x03FF0000))
#define rmSetLtrMsgReg3MaxNoSnoopLatencyScale(x)\
    (r32Pcie[rcLtrMsgCmdActiveL0Reg/\
             4]=(r32Pcie[rcLtrMsgCmdActiveL0Reg/4]&0xE3FFFFFF)|((x<<26)&0x1C000000))
// LWORD Rsvd2                           :   2;
//                 (r32Pcie[rcLtrMsgCmdActiveL0Reg/4]=(r32Pcie[rcLtrMsgCmdActiveL0Reg/4]&0x9FFFFFFF)|((x<<29)&0x60000000))   //2
#define rmSetLtrMsgReg3NoSnoopLatencyRequirement(x)\
    (r32Pcie[rcLtrMsgCmdActiveL0Reg/\
             4]=(r32Pcie[rcLtrMsgCmdActiveL0Reg/4]&0x7FFFFFFF)|((x<<31)&0x80000000))
#endif    // if _ENABLE_PCIE_LS

#define rmPcieLtr0Value                                        r32Pcie[rcLtrMsgCmdActiveL0Reg/4]

#define rcLtrMsgCmdActiveL0sReg                                0xC34
#if _ENABLE_PCIE_LS
#define rmSetLtrMsgReg4MaxSnoopLatencyValue(x)\
    (r32Pcie[rcLtrMsgCmdActiveL0sReg/\
             4]=(r32Pcie[rcLtrMsgCmdActiveL0sReg/4]&0xFFFFFC00)|x)    //
// 10
#define rmSetLtrMsgReg4MaxSnoopLatencyScale(x)\
    (r32Pcie[rcLtrMsgCmdActiveL0sReg/\
             4]=(r32Pcie[rcLtrMsgCmdActiveL0sReg/4]&0xFFFFE3FF)|x)    //
// 3
// LWORD Rsvd1                           :   2;
//                 (r32Pcie[rcLtrMsgCmdActiveL0sReg/4]=(r32Pcie[rcLtrMsgCmdActiveL0sReg/4]&0xFFFF9FFF)|x)   //2
#define rmSetLtrMsgReg4SnoopLatencyRequirement(x)\
    (r32Pcie[rcLtrMsgCmdActiveL0sReg/\
             4]=(r32Pcie[rcLtrMsgCmdActiveL0sReg/4]&0xFFFF7FFF)|x)    //
// 1
#define rmSetLtrMsgReg4MaxNoSnoopLatencyValue(x)\
    (r32Pcie[rcLtrMsgCmdActiveL0sReg/\
             4]=(r32Pcie[rcLtrMsgCmdActiveL0sReg/4]&0xFC00FFFF)|x)    //
// 10
#define rmSetLtrMsgReg4MaxNoSnoopLatencyScale(x)\
    (r32Pcie[rcLtrMsgCmdActiveL0sReg/\
             4]=(r32Pcie[rcLtrMsgCmdActiveL0sReg/4]&0xE3FFFFFF)|x)    //
// 3
// LWORD Rsvd2                           :   2;
//                 (r32Pcie[rcLtrMsgCmdActiveL0sReg/4]=(r32Pcie[rcLtrMsgCmdActiveL0sReg/4]&0x9FFFFFFF)|x)   //2
#define rmSetLtrMsgReg4NoSnoopLatencyRequirement(x)\
    (r32Pcie[rcLtrMsgCmdActiveL0sReg/\
             4]=(r32Pcie[rcLtrMsgCmdActiveL0sReg/4]&0x7FFFFFFF)|x)    //
// 1
#else    // if _ENABLE_PCIE_LS
#define rmSetLtrMsgReg4MaxSnoopLatencyValue(x)\
    (r32Pcie[rcLtrMsgCmdActiveL0sReg/\
             4]=(r32Pcie[rcLtrMsgCmdActiveL0sReg/4]&0xFFFFFC00)|(x&0x000003FF))
#define rmSetLtrMsgReg4MaxSnoopLatencyScale(x)\
    (r32Pcie[rcLtrMsgCmdActiveL0sReg/\
             4]=(r32Pcie[rcLtrMsgCmdActiveL0sReg/4]&0xFFFFE3FF)|((x<<10)&0x00001C00))
// LWORD Rsvd1                           :   2;
//                 (r32Pcie[rcLtrMsgCmdActiveL0sReg/4]=(r32Pcie[rcLtrMsgCmdActiveL0sReg/4]&0xFFFF9FFF)|((x<<13)&0x00006000))   //2
#define rmSetLtrMsgReg4SnoopLatencyRequirement(x)\
    (r32Pcie[rcLtrMsgCmdActiveL0sReg/\
             4]=(r32Pcie[rcLtrMsgCmdActiveL0sReg/4]&0xFFFF7FFF)|((x<<15)&0x00008000))
#define rmSetLtrMsgReg4MaxNoSnoopLatencyValue(x)\
    (r32Pcie[rcLtrMsgCmdActiveL0sReg/\
             4]=(r32Pcie[rcLtrMsgCmdActiveL0sReg/4]&0xFC00FFFF)|((x<<16)&0x03FF0000))
#define rmSetLtrMsgReg4MaxNoSnoopLatencyScale(x)\
    (r32Pcie[rcLtrMsgCmdActiveL0sReg/\
             4]=(r32Pcie[rcLtrMsgCmdActiveL0sReg/4]&0xE3FFFFFF)|((x<<26)&0x1C000000))
// LWORD Rsvd2                           :   2;
//                 (r32Pcie[rcLtrMsgCmdActiveL0sReg/4]=(r32Pcie[rcLtrMsgCmdActiveL0sReg/4]&0x9FFFFFFF)|((x<<29)&0x60000000))   //2
#define rmSetLtrMsgReg4NoSnoopLatencyRequirement(x)\
    (r32Pcie[rcLtrMsgCmdActiveL0sReg/\
             4]=(r32Pcie[rcLtrMsgCmdActiveL0sReg/4]&0x7FFFFFFF)|((x<<31)&0x80000000))
#endif    // if _ENABLE_PCIE_LS

#define rmPcieLtr1Value                                        r32Pcie[rcLtrMsgCmdActiveL0sReg/4]

#define rcLtrMsgCmdActiveL1Reg                                 0xC38
#define rmSetMacLtrL1(x)                                       (r32Pcie[rcLtrMsgCmdActiveL1Reg/4]=(x))
#if _ENABLE_PCIE_LS
#define rmSetLtrMsgReg5MaxSnoopLatencyValue(x)\
    (r32Pcie[rcLtrMsgCmdActiveL1Reg/\
             4]=(r32Pcie[rcLtrMsgCmdActiveL1Reg/4]&0xFFFFFC00)|x)    //
// 10
#define rmSetLtrMsgReg5MaxSnoopLatencyScale(x)\
    (r32Pcie[rcLtrMsgCmdActiveL1Reg/\
             4]=(r32Pcie[rcLtrMsgCmdActiveL1Reg/4]&0xFFFFE3FF)|x)    //
// 3
// LWORD Rsvd1                           :   2;
//                 (r32Pcie[rcLtrMsgCmdActiveL1Reg/4]=(r32Pcie[rcLtrMsgCmdActiveL1Reg/4]&0xFFFF9FFF)|x)   //2
#define rmSetLtrMsgReg5SnoopLatencyRequirement(x)\
    (r32Pcie[rcLtrMsgCmdActiveL1Reg/\
             4]=(r32Pcie[rcLtrMsgCmdActiveL1Reg/4]&0xFFFF7FFF)|x)    //
// 1
#define rmSetLtrMsgReg5MaxNoSnoopLatencyValue(x)\
    (r32Pcie[rcLtrMsgCmdActiveL1Reg/\
             4]=(r32Pcie[rcLtrMsgCmdActiveL1Reg/4]&0xFC00FFFF)|x)    //
// 10
#define rmSetLtrMsgReg5MaxNoSnoopLatencyScale(x)\
    (r32Pcie[rcLtrMsgCmdActiveL1Reg/\
             4]=(r32Pcie[rcLtrMsgCmdActiveL1Reg/4]&0xE3FFFFFF)|x)    //
// 3
// LWORD Rsvd2                           :   2;
//                 (r32Pcie[rcLtrMsgCmdActiveL1Reg/4]=(r32Pcie[rcLtrMsgCmdActiveL1Reg/4]&0x9FFFFFFF)|x)   //2
#define rmSetLtrMsgReg5NoSnoopLatencyRequirement(x)\
    (r32Pcie[rcLtrMsgCmdActiveL1Reg/\
             4]=(r32Pcie[rcLtrMsgCmdActiveL1Reg/4]&0x7FFFFFFF)|x)    //
// 1
#else    // if _ENABLE_PCIE_LS
#define rmSetLtrMsgReg5MaxSnoopLatencyValue(x)\
    (r32Pcie[rcLtrMsgCmdActiveL1Reg/\
             4]=(r32Pcie[rcLtrMsgCmdActiveL1Reg/4]&0xFFFFFC00)|(x&0x000003FF))
#define rmSetLtrMsgReg5MaxSnoopLatencyScale(x)\
    (r32Pcie[rcLtrMsgCmdActiveL1Reg/\
             4]=(r32Pcie[rcLtrMsgCmdActiveL1Reg/4]&0xFFFFE3FF)|((x<<10)&0x00001C00))
// LWORD Rsvd1                           :   2;
//                 (r32Pcie[rcLtrMsgCmdActiveL1Reg/4]=(r32Pcie[rcLtrMsgCmdActiveL1Reg/4]&0xFFFF9FFF)|((x<<13)&0x00006000))   //2
#define rmSetLtrMsgReg5SnoopLatencyRequirement(x)\
    (r32Pcie[rcLtrMsgCmdActiveL1Reg/\
             4]=(r32Pcie[rcLtrMsgCmdActiveL1Reg/4]&0xFFFF7FFF)|((x<<15)&0x00008000))
#define rmSetLtrMsgReg5MaxNoSnoopLatencyValue(x)\
    (r32Pcie[rcLtrMsgCmdActiveL1Reg/\
             4]=(r32Pcie[rcLtrMsgCmdActiveL1Reg/4]&0xFC00FFFF)|((x<<16)&0x03FF0000))
#define rmSetLtrMsgReg5MaxNoSnoopLatencyScale(x)\
    (r32Pcie[rcLtrMsgCmdActiveL1Reg/\
             4]=(r32Pcie[rcLtrMsgCmdActiveL1Reg/4]&0xE3FFFFFF)|((x<<26)&0x1C000000))
// LWORD Rsvd2                           :   2;
//                 (r32Pcie[rcLtrMsgCmdActiveL1Reg/4]=(r32Pcie[rcLtrMsgCmdActiveL1Reg/4]&0x9FFFFFFF)|((x<<29)&0x60000000))   //2
#define rmSetLtrMsgReg5NoSnoopLatencyRequirement(x)\
    (r32Pcie[rcLtrMsgCmdActiveL1Reg/\
             4]=(r32Pcie[rcLtrMsgCmdActiveL1Reg/4]&0x7FFFFFFF)|((x<<31)&0x80000000))
#endif    // if _ENABLE_PCIE_LS

#define rmPcieLtr2Value                                        r32Pcie[rcLtrMsgCmdActiveL1Reg/4]

#define rcLtrMsgCmdIdleL1SubReg                                0xC3C
#define rmSetMacLtrL12(x)                                      (r32Pcie[rcLtrMsgCmdIdleL1SubReg/4]=(x))

#if _ENABLE_PCIE_LS
#define rmSetLtrMsgReg6MaxSnoopLatencyValue(x)\
    (r32Pcie[rcLtrMsgCmdIdleL1SubReg/\
             4]=(r32Pcie[rcLtrMsgCmdIdleL1SubReg/4]&0xFFFFFC00)|x)    //
// 10
#define rmSetLtrMsgReg6MaxSnoopLatencyScale(x)\
    (r32Pcie[rcLtrMsgCmdIdleL1SubReg/\
             4]=(r32Pcie[rcLtrMsgCmdIdleL1SubReg/4]&0xFFFFE3FF)|x)    //
// 3
// LWORD Rsvd1                           :   2;
//                 (r32Pcie[rcLtrMsgCmdIdleL1SubReg/4]=(r32Pcie[rcLtrMsgCmdIdleL1SubReg/4]&0xFFFF9FFF)|x)   //2
#define rmSetLtrMsgReg6SnoopLatencyRequirement(x)\
    (r32Pcie[rcLtrMsgCmdIdleL1SubReg/\
             4]=(r32Pcie[rcLtrMsgCmdIdleL1SubReg/4]&0xFFFF7FFF)|x)    //
// 1
#define rmSetLtrMsgReg6MaxNoSnoopLatencyValue(x)\
    (r32Pcie[rcLtrMsgCmdIdleL1SubReg/\
             4]=(r32Pcie[rcLtrMsgCmdIdleL1SubReg/4]&0xFC00FFFF)|x)    //
// 10
#define rmSetLtrMsgReg6MaxNoSnoopLatencyScale(x)\
    (r32Pcie[rcLtrMsgCmdIdleL1SubReg/\
             4]=(r32Pcie[rcLtrMsgCmdIdleL1SubReg/4]&0xE3FFFFFF)|x)    //
// 3
// LWORD Rsvd2                           :   2;
//                 (r32Pcie[rcLtrMsgCmdIdleL1SubReg/4]=(r32Pcie[rcLtrMsgCmdIdleL1SubReg/4]&0x9FFFFFFF)|x)   //2
#define rmSetLtrMsgReg6NoSnoopLatencyRequirement(x)\
    (r32Pcie[rcLtrMsgCmdIdleL1SubReg/\
             4]=(r32Pcie[rcLtrMsgCmdIdleL1SubReg/4]&0x7FFFFFFF)|x)    //
// 1
#else    // if _ENABLE_PCIE_LS
#define rmSetLtrMsgReg6MaxSnoopLatencyValue(x)\
    (r32Pcie[rcLtrMsgCmdIdleL1SubReg/\
             4]=(r32Pcie[rcLtrMsgCmdIdleL1SubReg/4]&0xFFFFFC00)|(x&0x000003FF))
#define rmSetLtrMsgReg6MaxSnoopLatencyScale(x)\
    (r32Pcie[rcLtrMsgCmdIdleL1SubReg/\
             4]=(r32Pcie[rcLtrMsgCmdIdleL1SubReg/4]&0xFFFFE3FF)|((x<<10)&0x00001C00))    //
//
// 3
// LWORD Rsvd1                           :   2;
//                 (r32Pcie[rcLtrMsgCmdIdleL1SubReg/4]=(r32Pcie[rcLtrMsgCmdIdleL1SubReg/4]&0xFFFF9FFF)|((x<<13)&0x00006000))   //2
#define rmSetLtrMsgReg6SnoopLatencyRequirement(x)\
    (r32Pcie[rcLtrMsgCmdIdleL1SubReg/\
             4]=(r32Pcie[rcLtrMsgCmdIdleL1SubReg/4]&0xFFFF7FFF)|((x<<15)&0x00008000))    //
//
// 1
#define rmSetLtrMsgReg6MaxNoSnoopLatencyValue(x)\
    (r32Pcie[rcLtrMsgCmdIdleL1SubReg/\
             4]=(r32Pcie[rcLtrMsgCmdIdleL1SubReg/4]&0xFC00FFFF)|((x<<16)&0x03FF0000))    //
//
// 10
#define rmSetLtrMsgReg6MaxNoSnoopLatencyScale(x)\
    (r32Pcie[rcLtrMsgCmdIdleL1SubReg/\
             4]=(r32Pcie[rcLtrMsgCmdIdleL1SubReg/4]&0xE3FFFFFF)|((x<<26)&0x1C000000))    //
//
// 3
// LWORD Rsvd2                           :   2;
//                 (r32Pcie[rcLtrMsgCmdIdleL1SubReg/4]=(r32Pcie[rcLtrMsgCmdIdleL1SubReg/4]&0x9FFFFFFF)|((x<<29)&0x60000000))   //2
#define rmSetLtrMsgReg6NoSnoopLatencyRequirement(x)\
    (r32Pcie[rcLtrMsgCmdIdleL1SubReg/\
             4]=(r32Pcie[rcLtrMsgCmdIdleL1SubReg/4]&0x7FFFFFFF)|((x<<31)&0x80000000))    //
//
// 1
#endif    // if _ENABLE_PCIE_LS

#define rcLtrMsgCmdActiveP1Reg                                 0xC40
#define rmSetMacLtrP1(x)                                       (r32Pcie[rcLtrMsgCmdActiveP1Reg/4]=(x))

#if _ENABLE_PCIE_LS
#define rmSetLtrMsgReg7MaxSnoopLatencyValue(x)\
    (r32Pcie[rcLtrMsgCmdActiveP1Reg/\
             4]=(r32Pcie[rcLtrMsgCmdActiveP1Reg/4]&0xFFFFFC00)|x)    //
// 10
#define rmSetLtrMsgReg7MaxSnoopLatencyScale(x)\
    (r32Pcie[rcLtrMsgCmdActiveP1Reg/\
             4]=(r32Pcie[rcLtrMsgCmdActiveP1Reg/4]&0xFFFFE3FF)|x)    //
// 3
// LWORD Rsvd1                           :   2;
//                 (r32Pcie[rcLtrMsgCmdActiveP1Reg/4]=(r32Pcie[rcLtrMsgCmdActiveP1Reg/4]&0xFFFF9FFF)|x)   //2
#define rmSetLtrMsgReg7SnoopLatencyRequirement(x)\
    (r32Pcie[rcLtrMsgCmdActiveP1Reg/\
             4]=(r32Pcie[rcLtrMsgCmdActiveP1Reg/4]&0xFFFF7FFF)|x)    //
// 1
#define rmSetLtrMsgReg7MaxNoSnoopLatencyValue(x)\
    (r32Pcie[rcLtrMsgCmdActiveP1Reg/\
             4]=(r32Pcie[rcLtrMsgCmdActiveP1Reg/4]&0xFC00FFFF)|x)    //
// 10
#define rmSetLtrMsgReg7MaxNoSnoopLatencyScale(x)\
    (r32Pcie[rcLtrMsgCmdActiveP1Reg/\
             4]=(r32Pcie[rcLtrMsgCmdActiveP1Reg/4]&0xE3FFFFFF)|x)    //
// 3
// LWORD Rsvd2                           :   2;
//                 (r32Pcie[rcLtrMsgCmdActiveP1Reg/4]=(r32Pcie[rcLtrMsgCmdActiveP1Reg/4]&0x9FFFFFFF)|x)   //2
#define rmSetLtrMsgReg7NoSnoopLatencyRequirement(x)\
    (r32Pcie[rcLtrMsgCmdActiveP1Reg/\
             4]=(r32Pcie[rcLtrMsgCmdActiveP1Reg/4]&0x7FFFFFFF)|x)    //
// 1
#else    // if _ENABLE_PCIE_LS
#define rmSetLtrMsgReg7MaxSnoopLatencyValue(x)\
    (r32Pcie[rcLtrMsgCmdActiveP1Reg/\
             4]=(r32Pcie[rcLtrMsgCmdActiveP1Reg/4]&0xFFFFFC00)|(x&0x000003FF))
#define rmSetLtrMsgReg7MaxSnoopLatencyScale(x)\
    (r32Pcie[rcLtrMsgCmdActiveP1Reg/\
             4]=(r32Pcie[rcLtrMsgCmdActiveP1Reg/4]&0xFFFFE3FF)|((x<<10)&0x00001C00))    //
//
// 3
// LWORD Rsvd1                           :   2;
//                 (r32Pcie[rcLtrMsgCmdActiveP1Reg/4]=(r32Pcie[rcLtrMsgCmdActiveP1Reg/4]&0xFFFF9FFF)|((x<<13)&0x00006000))   //2
#define rmSetLtrMsgReg7SnoopLatencyRequirement(x)\
    (r32Pcie[rcLtrMsgCmdActiveP1Reg/\
             4]=(r32Pcie[rcLtrMsgCmdActiveP1Reg/4]&0xFFFF7FFF)|((x<<15)&0x00008000))    //
//
// 1
#define rmSetLtrMsgReg7MaxNoSnoopLatencyValue(x)\
    (r32Pcie[rcLtrMsgCmdActiveP1Reg/\
             4]=(r32Pcie[rcLtrMsgCmdActiveP1Reg/4]&0xFC00FFFF)|((x<<16)&0x03FF0000))    //
//
// 10
#define rmSetLtrMsgReg7MaxNoSnoopLatencyScale(x)\
    (r32Pcie[rcLtrMsgCmdActiveP1Reg/\
             4]=(r32Pcie[rcLtrMsgCmdActiveP1Reg/4]&0xE3FFFFFF)|((x<<26)&0x1C000000))    //
//
// 3
// LWORD Rsvd2                           :   2;
//                 (r32Pcie[rcLtrMsgCmdActiveP1Reg/4]=(r32Pcie[rcLtrMsgCmdActiveP1Reg/4]&0x9FFFFFFF)|((x<<29)&0x60000000))   //2
#define rmSetLtrMsgReg7NoSnoopLatencyRequirement(x)\
    (r32Pcie[rcLtrMsgCmdActiveP1Reg/\
             4]=(r32Pcie[rcLtrMsgCmdActiveP1Reg/4]&0x7FFFFFFF)|((x<<31)&0x80000000))    //
//
// 1
#endif    // if _ENABLE_PCIE_LS

#define rcLtrMsgCmdActiveP2Reg                                 0xC44
#define rmSetMacLtrP2(x)                                       (r32Pcie[rcLtrMsgCmdActiveP2Reg/4]=(x))

#define rcLtrMsgCmdActiveP3Reg                                 0xC48

#define rcL1TimerReg                                           0xC4C
#define rmSetL1TimerReg(x)                                     (r16Pcie[rcL1TimerReg/2]=x)
#define rmSetAutoSendL1SubLtr                                  (rPcie[rcL1TimerReg+2]|=cBit0)
#define rmClrAutoSendL1SubLtr                                  (rPcie[rcL1TimerReg+2]&=~cBit0)
#define rmSetAutoEnterL1SubState                               (rPcie[rcL1TimerReg+2]|=cBit1)
#define rmClrAutoEnterL1SubState                               (rPcie[rcL1TimerReg+2]&=~cBit1)
#define rmClrL1AutoGatePclk                                    (rPcie[rcL1TimerReg+2]|=cBit2)
#define rmSetL1AutoGatePclk                                    (rPcie[rcL1TimerReg+2]&=~cBit2)
#define rmSetWaitNvmeIdle                                      (rPcie[rcL1TimerReg+2]|=cBit3)
#define rmClrWaitNvmeIdle                                      (rPcie[rcL1TimerReg+2]&=~cBit3)

#define rcOrderingReg                                          0xC4E
#define rmSetOrderingReg(x)                                    (r16Pcie[rcOrderingReg/2]=x)

#define rcL1TimerRegReservedBits                               0xC4F
#define rmSetPmL12Changed                                      (rPcie[rcL1TimerRegReservedBits]|=cBit0)
#define rmChkPmL12Changed                                      (rPcie[rcL1TimerRegReservedBits]&cBit0)
#define rmClrPmL12Changed                                      (rPcie[rcL1TimerRegReservedBits]&=(~cBit0))

#define rmSetD3Changed                                         (rPcie[rcL1TimerRegReservedBits]|=cBit1)
#define rmChkD3Changed                                         (rPcie[rcL1TimerRegReservedBits]&cBit1)
#define rmClrD3Changed                                         (rPcie[rcL1TimerRegReservedBits]&=(~cBit1))

// Expansion ROM Register
#define rcEpromOffset                                          0x0C50
#define rmSetEpromSelSram                                      (r32Pcie[rcEpromOffset/4]|=c32Bit31)
#define rmSetEpromOffset(x)\
    (r32Pcie[rcEpromOffset/\
             4]=((r32Pcie[rcEpromOffset/4]&0x8000000F)|((x&0x7FFFFFF)<<4)))
#define rmSetEpromDpp                                          (r32Pcie[rcEpromOffset/4]|=c32Bit0)
#define rmClrEpromDpp                                          (r32Pcie[rcEpromOffset/4]&=(~c32Bit0))

#define rcPcieErrRegOffset                                     0xC90
#define rmPcieError                                            r32Pcie[rcPcieErrRegOffset/4]

#define rcPcieErrorIntrEnable                                  0xC98
#define rmRadmCplTimeoutDiagrEnable                            (r32Pcie[rcPcieErrorIntrEnable/4]|=c32Bit10)
#define rmFormFiltMalformTlpErrEnable                          (r32Pcie[rcPcieErrorIntrEnable/4]|=c32Bit22)

#define rcLtssmTrigOffset                                      0xCA0
#define rmLtssmTrig(x)                                         (r32Pcie[rcLtssmTrigOffset/4]=x)

#define rmLtssmCnt0En                                          (r32Pcie[rcLtssmTrigOffset/4]|=c32Bit6)
#define rmLtssmCnt1En                                          (r32Pcie[rcLtssmTrigOffset/4]|=c32Bit14)
#define rmLtssmCnt2En                                          (r32Pcie[rcLtssmTrigOffset/4]|=c32Bit22)
#define rmLtssmCnt3En                                          (r32Pcie[rcLtssmTrigOffset/4]|=c32Bit30)

#define rmLtssmCnt0Clr                                         (r32Pcie[rcLtssmTrigOffset/4]|=c32Bit7)
#define rmLtssmCnt1Clr                                         (r32Pcie[rcLtssmTrigOffset/4]|=c32Bit15)
#define rmLtssmCnt2Clr                                         (r32Pcie[rcLtssmTrigOffset/4]|=c32Bit23)
#define rmLtssmCnt3Clr                                         (r32Pcie[rcLtssmTrigOffset/4]|=c32Bit31)

#define rmLtssmCnt0DisClr                                      (r32Pcie[rcLtssmTrigOffset/4]&=(~c32Bit7))
#define rmLtssmCnt1DisClr                                      (r32Pcie[rcLtssmTrigOffset/4]&=(~c32Bit15))
#define rmLtssmCnt2DisClr                                      (r32Pcie[rcLtssmTrigOffset/4]&=(~c32Bit23))
#define rmLtssmCnt3DisClr                                      (r32Pcie[rcLtssmTrigOffset/4]&=(~c32Bit31))

#define rcSrisCtrlOffset                                       0xCB0
#define rmSetSrisEn                                            (rPcie[rcSrisCtrlOffset+3]|=cBit0)

#define rcSrisCtrl                                             0xCB2
#define rmClrAutoSrisEn                                        rPcie[rcSrisCtrl]=(~cBit0)

#define rcAxiWrPortCtrl                                        0xCB4
#define rmClrAxiWrWaitCnt                                      (r32Pcie[rcAxiWrPortCtrl/4]|=c32Bit0)

#define rcAxiRdPortCtrl                                        0xCB8
#define rmClrAxiRdWaitCnt                                      (r32Pcie[rcAxiRdPortCtrl/4]|=c32Bit0)

#define rcAxiRdWaitCnt                                         0xCBC
#define rcAxiWrWaitCnt                                         0xCBE
#define rmSetAxiRdWaitCnt(x)                                   (r16Pcie[rcAxiRdWaitCnt/2]=x)
#define rmSetAxiWrWaitCnt(x)                                   (r16Pcie[rcAxiWrWaitCnt/2]=x)

#define rcAes2TsbPortCtrl                                      0xCC8
#define rmClrAes2TsbWrWaitCnt                                  (r32Pcie[rcAes2TsbPortCtrl/4]|=c32Bit0)
#define rmClrAes2TsbRdWaitCnt                                  (r32Pcie[rcAes2TsbPortCtrl/4]|=c32Bit16)

#define rcAes2TsbRdWaitCnt                                     0xCCC
#define rcAes2TsbWrWaitCnt                                     0xCCE
#define rmSetAes2TsbRdWaitCnt(x)                               (r16Pcie[rcAes2TsbRdWaitCnt/2]=x)
#define rmSetAes2TsbWrWaitCnt(x)                               (r16Pcie[rcAes2TsbWrWaitCnt/2]=x)

#define rcLtssmEntrCnt0Offset                                  0xCD0
#define rmLtssmEntrCnt0                                        r32Pcie[rcLtssmEntrCnt0Offset/4]    // count L0(0x11)

#define rcLtssmEntrCnt1Offset                                  0xCD4
#define rmLtssmEntrCnt1                                        r32Pcie[rcLtssmEntrCnt1Offset/4]

#define rcLtssmEntrCnt2Offset                                  0xCD8
#define rmLtssmEntrCnt2                                        r32Pcie[rcLtssmEntrCnt2Offset/4]

#define rcLtssmEntrCnt3Offset                                  0xCDC
#define rmLtssmEntrCnt3                                        r32Pcie[rcLtssmEntrCnt3Offset/4]

// CRC Counter
#define rcCfgCrcCntRegOffset                                   0xCE0
#define rmEcrcCntEn                                            (r32Pcie[rcCfgCrcCntRegOffset/4]|=c32Bit6)
#define rmEcrcCntClr                                           (r32Pcie[rcCfgCrcCntRegOffset/4]|=c32Bit7)
#define rmEcrcCntDisClr                                        (r32Pcie[rcCfgCrcCntRegOffset/4]&=(~c32Bit7))
#define rmLcrcCntEn                                            (r32Pcie[rcCfgCrcCntRegOffset/4]|=c32Bit14)
#define rmLcrcCntClr                                           (r32Pcie[rcCfgCrcCntRegOffset/4]|=c32Bit15)
#define rmLcrcCntDisClr                                        (r32Pcie[rcCfgCrcCntRegOffset/4]&=(~c32Bit15))

#define rcEcrcCntOffset                                        0xCE4
#define rmEcrcCnt                                              r32Pcie[rcEcrcCntOffset/4]    // count ECRC

#define rcLcrcCntOffset                                        0xCE8
#define rmLcrcCnt                                              r32Pcie[rcLcrcCntOffset/4]    // count LCRC

#define rcLtssmTraceIntCtrl0                                   0xCEC
#define rmResetLtssmTraceIntCtrl0                              (r32Pcie[rcLtssmTraceIntCtrl0/4]=0)
#define rmLtssmTraceTrig(x)                                    (r32Pcie[rcLtssmTraceIntCtrl0/4]=x)

#define rcLtssmTraceIntCtrl1                                   0xCF0
#define rmResetLtssmTraceIntCtrl1                              (r32Pcie[rcLtssmTraceIntCtrl1/4]=0)
#define rmLtssmTraceTrig1(x)                                   (r32Pcie[rcLtssmTraceIntCtrl1/4]=x)

#define rcDevMacAppCtrlReg1                                    0xCF4
#define rmSetFwExtendSyncEnable                                (rPcie[rcDevMacAppCtrlReg1]|=cBit4)
#define rmSetFwExtendSyncDisable                               (rPcie[rcDevMacAppCtrlReg1]&=(~cBit4))
#define rmSetFwExtendSyncCnt                                   (rPcie[rcDevMacAppCtrlReg1]|=cBit7)
#define rmClrFwExtendSyncCnt                                   (rPcie[rcDevMacAppCtrlReg1]&=(~cBit7))

#define rmAppDrsReady(x)\
    (r32Pcie[rcDevMacAppCtrlReg1/4]=(r32Pcie[rcDevMacAppCtrlReg1/4]&0xFFFFFFFE)|\
                                     (x&0x00000001))    //
// :
//
//
// 1;
#define rmAppPfFrsReady(x)\
    (r32Pcie[rcDevMacAppCtrlReg1/4]=(r32Pcie[rcDevMacAppCtrlReg1/4]&0xFFFFFFFD)|\
                                     ((x&0x00000001)<<1))    //
// :
//
//
// 1;
#define rmAppL1PwrOffEn(x)\
    (r32Pcie[rcDevMacAppCtrlReg1/4]=(r32Pcie[rcDevMacAppCtrlReg1/4]&0xFFFFFFFB)|\
                                     ((x&0x00000001)<<2))    //
// :
//
//
// 1;
#define rmEpromBuffLagEn(x)\
    (r32Pcie[rcDevMacAppCtrlReg1/4]=(r32Pcie[rcDevMacAppCtrlReg1/4]&0xFFFFFFF7)|\
                                     ((x&0x00000001)<<3))    //
// :
//
//
// 1;
#define rmRcvLockFwExtendSyncEn(x)\
    (r32Pcie[rcDevMacAppCtrlReg1/4]=(r32Pcie[rcDevMacAppCtrlReg1/4]&0xFFFFFFEF)|\
                                     ((x&0x00000001)<<4))    //
// :
//
//
// 1;
#define rmRcvLockFwExtendSyncCoun(x)\
    (r32Pcie[rcDevMacAppCtrlReg1/4]=(r32Pcie[rcDevMacAppCtrlReg1/4]&0xFFFFFF1F)|\
                                     ((x&0x00000007)<<5))    //
// :
//
//
// 3;
#define rmPhyClkReqN(x)\
    (r32Pcie[rcDevMacAppCtrlReg1/4]=(r32Pcie[rcDevMacAppCtrlReg1/4]&0xFFFFFEFF)|\
                                     ((x&0x00000001)<<8))    //
// :
//
//
// 1;
#define rmTestBypassLp(x)\
    (r32Pcie[rcDevMacAppCtrlReg1/4]=(r32Pcie[rcDevMacAppCtrlReg1/4]&0xFFFFFDFF)|\
                                     ((x&0x00000001)<<9))    //
// :
//
//
// 1;
// #define rmRsvd0
//                                                                                                               //:   3;
#define rmFwSaveStateAck(x)\
    (r32Pcie[rcDevMacAppCtrlReg1/4]=(r32Pcie[rcDevMacAppCtrlReg1/4]&0xFFFFDFFF)|\
                                     ((x&0x00000001)<<13))    //
// :
//
//
// 1;
#define rmSysPwrState(x)\
    (r32Pcie[rcDevMacAppCtrlReg1/4]=(r32Pcie[rcDevMacAppCtrlReg1/4]&0xFFFF3FFF)|\
                                     ((x&0x00000003)<<14))    //
// :
//
//
// 2;
#define rmClrParityErrs(x)\
    (r32Pcie[rcDevMacAppCtrlReg1/4]=(r32Pcie[rcDevMacAppCtrlReg1/4]&0xFFFEFFFF)|\
                                     ((x&0x00000001)<<16))    //
// :
//
//
// 1;
#define rmAutoSendUncorreInterErr(x)\
    (r32Pcie[rcDevMacAppCtrlReg1/4]=(r32Pcie[rcDevMacAppCtrlReg1/4]&0xFFFDFFFF)|\
                                     ((x&0x00000001)<<17))    //
// :
//
//
// 1;
#define rmCfgL1TmpCount(x)\
    (r32Pcie[rcDevMacAppCtrlReg1/4]=(r32Pcie[rcDevMacAppCtrlReg1/4]&0x003FFFF)|\
                                     ((x&0x00003FFF)<<18))    //
// :
//
//
// 14;

#define rcMacLowPower                                          0xCF8
#define rmChkPcieMacLowPower                                   (r16Pcie[rcMacLowPower/2]&c16Bit8)
#define rmGetPresetValue                                       (r16Pcie[(rcMacLowPower/2)+1])
#define rmChkRefClkReqN                                        (r16Pcie[rcMacLowPower/2]&c16Bit7)
#define rmGetPresetValue                                       (r16Pcie[(rcMacLowPower/2)+1])

#define rcPcieIntr0Offset                                      0xD00
#define rmGetPcieIntr01Sts                                      r32Pcie[rcPcieIntr0Offset/4]
#define rmPcieIntr01StsInit                                     (r32Pcie[rcPcieIntr0Offset/4]=0xFFFFFFFF)

#define rmClrPcieDstateChangeIntr                              (rPcie[rcPcieIntr0Offset]=cBit0)
#define rmClrEnterL0Intr                                       (rPcie[rcPcieIntr0Offset]=cBit1)
#define rmClrEnterL0sIntr                                      (rPcie[rcPcieIntr0Offset]=cBit2)
#define rmClrRadmDebugIntr                                     (rPcie[rcPcieIntr0Offset]=cBit3)
#define rmClrL1Timeout                                         (rPcie[rcPcieIntr0Offset]=cBit4)
#define rmClrLinkRstDetect                                     (rPcie[rcPcieIntr0Offset]=cBit5)

#define rmChkPcieDstateChangeIntr                              (rPcie[rcPcieIntr0Offset]&cBit0)
#define rmChkEnterL0Intr                                       (rPcie[rcPcieIntr0Offset]&cBit1)
#define rmChkEnterL0sIntr                                      (rPcie[rcPcieIntr0Offset]&cBit2)
#define rmChkRadmDebugIntr                                     (rPcie[rcPcieIntr0Offset]&cBit3)
#define rmChkL1Timeout                                         (rPcie[rcPcieIntr0Offset]&cBit4)
#define rmChkLinkRstDetect                                     (rPcie[rcPcieIntr0Offset]&cBit5)

#define rmClrRadmCplTimeoutInt                                 (rPcie[rcPcieIntr0Offset+1]=cBit0)
#define rmChkRadmCplTimeoutInt                                 (rPcie[rcPcieIntr0Offset+1]&cBit0)
#define rmClrLtrEnChangeIntr                                   (rPcie[rcPcieIntr0Offset+1]=cBit1)
#define rmChkLtrEnChangeIntr                                   (rPcie[rcPcieIntr0Offset+1]&cBit1)
#define rmClrBusMasterChangeIntr                               (rPcie[rcPcieIntr0Offset+1]=cBit4)
#define rmChkBusMasterChangeIntr                               (rPcie[rcPcieIntr0Offset+1]&cBit4)

#define rcPcieIntr1Offset                                      0xD02
#define rmClrFormDebugInt                                      (rPcie[rcPcieIntr1Offset]=cBit2)
#define rmChkFormDebugInt                                      (rPcie[rcPcieIntr1Offset]&cBit2)

#define rmClrLtssmIntr0                                        (rPcie[rcPcieIntr1Offset+1]=cBit0)
#define rmChkLtssmIntr0                                        (rPcie[rcPcieIntr1Offset+1]&cBit0)
#define rmClrLtssmIntr1                                        (rPcie[rcPcieIntr1Offset+1]=cBit1)
#define rmChkLtssmIntr1                                        (rPcie[rcPcieIntr1Offset+1]&cBit1)

#define rmClrLtssmIntr2                                        (rPcie[rcPcieIntr1Offset+1]=cBit2)
#define rmChkLtssmIntr2                                        (rPcie[rcPcieIntr1Offset+1]&cBit2)
#define rmClrLtssmIntr3                                        (rPcie[rcPcieIntr1Offset+1]=cBit3)
#define rmChkLtssmIntr3                                        (rPcie[rcPcieIntr1Offset+1]&cBit3)

#define rmClrLtssmTraceIntr0                                   (rPcie[rcPcieIntr1Offset+1]=cBit4)
#define rmChkLtssmTraceIntr0                                   (rPcie[rcPcieIntr1Offset+1]&cBit4)
#define rmClrLtssmTraceIntr1                                   (rPcie[rcPcieIntr1Offset+1]=cBit5)
#define rmChkLtssmTraceIntr1                                   (rPcie[rcPcieIntr1Offset+1]&cBit5)

#define rmChkPcieVpdIntr                                       (rPcie[rcPcieIntr1Offset+1]&cBit7)
#define rmClrPcieVpdIntr                                       (rPcie[rcPcieIntr1Offset+1]=cBit7)

#define rcPcieIntr0EnOffset                                    0xD04
#define rmSetPcieDstateChangeIntrEn                            (rPcie[rcPcieIntr0EnOffset]|=cBit0)
#define rmClrPcieDstateChangeIntrEn                            (rPcie[rcPcieIntr0EnOffset]&=~cBit0)
#define rmSetRadmDebugIntrEn                                   (rPcie[rcPcieIntr0EnOffset]|=cBit3)
#define rmChkRadmDebugIntrEn                                   (rPcie[rcPcieIntr0EnOffset]&cBit3)
#define rmClrRadmDebugIntrEn                                   (rPcie[rcPcieIntr0EnOffset]&=~cBit3)
#define rmSetL1TimeoutEn                                       (rPcie[rcPcieIntr0EnOffset]|=cBit4)
#define rmChkL1TimeoutEn                                       (rPcie[rcPcieIntr0EnOffset]&cBit4)
#define rmClrL1TimeoutEn                                       (rPcie[rcPcieIntr0EnOffset]&=~cBit4)

#define rmSetLinkRstDetectEn                                   (rPcie[rcPcieIntr0EnOffset]|=cBit5)

#define rmRadmCplTimeoutIntEn                                  (rPcie[rcPcieIntr0EnOffset+1]|=cBit0)
#define rmSetLtrEnChangeEn                                     (rPcie[rcPcieIntr0EnOffset+1]|=cBit1)
#define rmClrLtrEnChangeEn                                     (rPcie[rcPcieIntr0EnOffset+1]&=~cBit1)
#define rmSetBusMaterChangeEn                                  (rPcie[rcPcieIntr0EnOffset+1]|=cBit4)
#define rmClrBusMaterChangeEn                                  (rPcie[rcPcieIntr0EnOffset+1]&=~cBit4)

#define rcPcieIntr1EnOffset                                    0xD06
#define rmFormDebugIntEn                                       (rPcie[rcPcieIntr1EnOffset]|=cBit2)

#define rmSetLtssmIntr0En                                      (rPcie[rcPcieIntr1EnOffset+1]|=cBit0)
#define rmClrLtssmIntr0En                                      (rPcie[rcPcieIntr1EnOffset+1]&=(~cBit0))
#define rmChkLtssmIntr0En                                      (rPcie[rcPcieIntr1EnOffset+1]&cBit0)
#define rmSetLtssmIntr1En                                      (rPcie[rcPcieIntr1EnOffset+1]|=cBit1)
#define rmClrLtssmIntr1En                                      (rPcie[rcPcieIntr1EnOffset+1]&=(~cBit1))
#define rmChkLtssmIntr1En                                      (rPcie[rcPcieIntr1EnOffset+1]&cBit1)
#define rmSetLtssmIntr2En                                      (rPcie[rcPcieIntr1EnOffset+1]|=cBit2)
#define rmClrLtssmIntr2En                                      (rPcie[rcPcieIntr1EnOffset+1]&=(~cBit2))
#define rmChkLtssmIntr2En                                      (rPcie[rcPcieIntr1EnOffset+1]&cBit2)
#define rmSetLtssmIntr3En                                      (rPcie[rcPcieIntr1EnOffset+1]|=cBit3)
#define rmClrLtssmIntr3En                                      (rPcie[rcPcieIntr1EnOffset+1]&=(~cBit3))
#define rmChkLtssmIntr3En                                      (rPcie[rcPcieIntr1EnOffset+1]&cBit3)

#define rmSetLtssmTraceIntr0En                                 (rPcie[rcPcieIntr1EnOffset+1]|=cBit4)
#define rmClrLtssmTraceIntr0En                                 (rPcie[rcPcieIntr1EnOffset+1]&=(~cBit4))
#define rmChkLtssmTraceIntr0En                                 (rPcie[rcPcieIntr1EnOffset+1]&cBit4)
#define rmSetLtssmTraceIntr1En                                 (rPcie[rcPcieIntr1EnOffset+1]|=cBit5)
#define rmClrLtssmTraceIntr1En                                 (rPcie[rcPcieIntr1EnOffset+1]&=(~cBit5))
#define rmChkLtssmTraceIntr1En                                 (rPcie[rcPcieIntr1EnOffset+1]&cBit5)
#define rmSetPcieVpdIntrEn                                     (rPcie[rcPcieIntr1EnOffset+1]|=cBit7)
#define rmClrPcieVpdIntrEn                                     (rPcie[rcPcieIntr1EnOffset+1]&=(~cBit7))

#define rcPcieLocalIntrReg2                                    0xD08
#define rmChkExpansionRomDps                                   (rPcie[rcPcieLocalIntrReg2]&cBit0)
#define rmClrExpansionRomDps                                   (rPcie[rcPcieLocalIntrReg2]&=cBit0)
#define rmGetPcieIntr23Sts                                     (r32Pcie[rcPcieLocalIntrReg2/4])
#define rmPcieIntr23StsInit                                    (r32Pcie[rcPcieLocalIntrReg2/4]=0xFFFFFFFF)

#define rcPcieLocalIntrReg3                                    0xD0A
#define rmChkAxiWrTimeoutErr                                   (rPcie[rcPcieLocalIntrReg3]&cBit0)
#define rmClrAxiWrTimeoutErr                                   (rPcie[rcPcieLocalIntrReg3]=cBit0)    // W1C
#define rmChkAxiRdTimeoutErr                                   (rPcie[rcPcieLocalIntrReg3]&cBit1)
#define rmClrAxiRdTimeoutErr                                   (rPcie[rcPcieLocalIntrReg3]=cBit1)    // W1C
#define rmChkAes2TsbWrTimeoutErr                               (rPcie[rcPcieLocalIntrReg3]&cBit2)
#define rmClrAes2TsbWrTimeoutErr                               (rPcie[rcPcieLocalIntrReg3]=cBit2)    // W1C
#define rmChkAes2TsbRdDramTimeoutErr                           (rPcie[rcPcieLocalIntrReg3]&cBit3)
#define rmClrAes2TsbRdDramTimeoutErr                           (rPcie[rcPcieLocalIntrReg3]=cBit3)    // W1C
#define rmChkAes2TsbRdSramTimeoutErr                           (rPcie[rcPcieLocalIntrReg3]&cBit4)
#define rmClrAes2TsbRdSramTimeoutErr                           (rPcie[rcPcieLocalIntrReg3]=cBit4)    // W1C
#define rmChkLtssmStateTimeoutIntr0                            (rPcie[rcPcieLocalIntrReg3+1]&cBit4)
#define rmClrLtssmStateTimeoutIntr0                            (rPcie[rcPcieLocalIntrReg3+1]=cBit4)    // W1C
#define rmChkLtssmStateTimeoutIntr1                            (rPcie[rcPcieLocalIntrReg3+1]&cBit5)
#define rmClrLtssmStateTimeoutIntr1                            (rPcie[rcPcieLocalIntrReg3+1]=cBit5)    // W1C
#define rmChkLtssmStateTimeoutIntr2                            (rPcie[rcPcieLocalIntrReg3+1]&cBit6)
#define rmClrLtssmStateTimeoutIntr2                            (rPcie[rcPcieLocalIntrReg3+1]=cBit6)    // W1C

#define rcPcieLocalIntrEnableReg2                              0xD0C
#define rmEnExpansionRomDps                                    (rPcie[rcPcieLocalIntrEnableReg2]|=cBit0)
#define rmDisExpansionRomDps                                    (rPcie[rcPcieLocalIntrEnableReg2]&=(~cBit0))

#define rcPcieLocalIntrEnableReg3                              0xD0E
#define rmSetAxiWrTimeoutErrEn                                 (rPcie[rcPcieLocalIntrEnableReg3]|=cBit0)
#define rmSetAxiWrTimeoutErrDis                                (rPcie[rcPcieLocalIntrEnableReg3]&=(~cBit0))
#define rmSetAxiRdTimeoutErrEn                                 (rPcie[rcPcieLocalIntrEnableReg3]|=cBit1)
#define rmSetAxiRdTimeoutErrDis                                (rPcie[rcPcieLocalIntrEnableReg3]&=(~cBit1))
#define rmSetAes2TsbWrTimeoutErrEn                             (rPcie[rcPcieLocalIntrEnableReg3]|=cBit2)
#define rmSetAes2TsbWrTimeoutErrDis                            (rPcie[rcPcieLocalIntrEnableReg3]&=(~cBit2))
#define rmSetAes2TsbRdDramTimeoutErrEn                         (rPcie[rcPcieLocalIntrEnableReg3]|=cBit3)
#define rmSetAes2TsbRdDramTimeoutErrDis                        (rPcie[rcPcieLocalIntrEnableReg3]&=(~cBit3))
#define rmSetAes2TsbRdSramTimeoutErrEn                         (rPcie[rcPcieLocalIntrEnableReg3]|=cBit4)
#define rmSetAes2TsbRdSramTimeoutErrDis                        (rPcie[rcPcieLocalIntrEnableReg3]&=(~cBit4))
#define rmSetLtssmStateTimeoutIntr1En                          (rPcie[rcPcieLocalIntrEnableReg3+1]|=cBit5)
#define rmClrLtssmStateTimeoutIntr1En                          (rPcie[rcPcieLocalIntrEnableReg3+1]&=(~cBit5))
#define rmSetLtssmStateTimeoutIntr2En                          (rPcie[rcPcieLocalIntrEnableReg3+1]|=cBit6)
#define rmClrLtssmStateTimeoutIntr2En                          (rPcie[rcPcieLocalIntrEnableReg3+1]&=(~cBit6))

#define rcPcieMsixTable                                        0xE00
#define rmPcieMsixTable(x)                                     r32Pcie[(rcPcieMsixTable/4)+x]

#define rcPcieMsixVector1Laddr                                 0xE10
#define rmGetMsixVector1Value                                  r32Pcie[rcPcieMsixVector1Laddr/4]

#define rcPcieNewFeatureCtl0offset                             0xF28
#define rmSet2262RstMechanism                                  (rPcie[rcPcieNewFeatureCtl0offset]|=cBit1)

#define rmSetAutoDetRxOffTx                                    (rPcie[rcPcieNewFeatureCtl0offset+1]|=cBit4)
#define rmClrAutoDetRxOffTx                                    (rPcie[rcPcieNewFeatureCtl0offset+1]&=(~cBit4))
#define rmSetDisUnEstablishLane                                (rPcie[rcPcieNewFeatureCtl0offset+1]|=cBit5)
#define rmClrDisUnEstablishLane                                (rPcie[rcPcieNewFeatureCtl0offset+1]&=(~cBit5))
#define rmSetAppFlrPfDone                                      (rPcie[rcPcieNewFeatureCtl0offset+1]|=cBit7)
#define rmClrAppFlrPfDone                                      (rPcie[rcPcieNewFeatureCtl0offset+1]&=(~cBit7))

// If 0x0F28.bit24 be 1, link can enter L1 when link idle.
#define rmClrL1RefNvmeIdle                                     (rPcie[rcPcieNewFeatureCtl0offset+3]|=cBit0)
// If 0x0F28.bit24 be 0, link can enter L1 when NVMe idle and link idle .
#define rmSetL1RefNvmeIdle                                     (rPcie[rcPcieNewFeatureCtl0offset+3]&=(~cBit0))

#define rmClrPcieDoNotEnterL1                                  (rPcie[rcPcieNewFeatureCtl0offset+3]&=(~cBit1))
#define rmSetPcieDoNotEnterL1                                  (rPcie[rcPcieNewFeatureCtl0offset+3]|=cBit1)
#define rmChkPcieDoNotEnterL1                                  (rPcie[rcPcieNewFeatureCtl0offset+3]&cBit1)
#define rmRestorePiceDoNotEnterL1(x)                           (rPcie[rcPcieNewFeatureCtl0offset+3]&=(x))

#define rmClrL1PdOnlayL12                                      (rPcie[rcPcieNewFeatureCtl0offset+3]|=cBit5)
#define rmSetL1PdOnlayL12                                      (rPcie[rcPcieNewFeatureCtl0offset+3]&=(~cBit5))

#define rmChkL1GateWithoutClkreq                               (rPcie[rcPcieNewFeatureCtl0offset+3]&cBit6)
#define rmSetL1GateWithoutClkreq                               (rPcie[rcPcieNewFeatureCtl0offset+3]|=cBit6)
#define rmClrL1GateWithoutClkreq                               (rPcie[rcPcieNewFeatureCtl0offset+3]&=(~cBit6))
#define rmSetL1KeepPll                                         (rPcie[rcPcieNewFeatureCtl0offset+3]|=cBit7)
#define rmClrL1KeepPll                                         (rPcie[rcPcieNewFeatureCtl0offset+3]&=(~cBit7))

#define rcLtssmTimeoutValue                                    0xF2C
#define rmSetLtssmTimeoutValue(x)                              (r32Pcie[rcLtssmTimeoutValue/4]=x)

#define rcLtssmTimeoutIntr                                     0xF30
#define rmSetDetectTimoutLtssm0(x)                             (rPcie[rcLtssmTimeoutIntr]=x)
#define rmSetDetectTimoutLtssm1(x)                             (rPcie[rcLtssmTimeoutIntr+1]=x)
#define rmSetDetectTimoutLtssm2(x)                             (rPcie[rcLtssmTimeoutIntr+2]=x)
#define rmSetDetectTimoutLtssm3(x)                             (rPcie[rcLtssmTimeoutIntr+3]=x)

#define rcL12RetryCountReg                                     0xF34
#define rmSetL12RetryCount(x)                                  (r16Pcie[rcL12RetryCountReg/2]=x)
#define rmSetAllStateRstProtectTimer                           (rPcie[rcL12RetryCountReg+2]|=cBit3)
#define rmClrAllStateRstProtectTimer                           (rPcie[rcL12RetryCountReg+2]&=(~cBit3))

#define rcPiceShareReg3                                        0xF36
#define rmSetClkReqOeCtln                                      (rPcie[rcPiceShareReg3]|=cBit1)
#define rmClrClkReqOeCtln                                      (rPcie[rcPiceShareReg3]&=(~cBit1))
#define rmSetClkReqICtln                                       (rPcie[rcPiceShareReg3]|=cBit2)
#define rmClrClkReqICtln                                       (rPcie[rcPiceShareReg3]&=(~cBit2))
#define rmChkKeepPcieLinkSleep                                 (rPcie[rcPiceShareReg3]&cBit4)
#define rmSetKeepPcieLinkSleep                                 (rPcie[rcPiceShareReg3]|=cBit4)
#define rmClrKeepPcieLinkSleep                                 (rPcie[rcPiceShareReg3]&=(~cBit4))

#endif    // ifndef __REG_PCIE_H__







