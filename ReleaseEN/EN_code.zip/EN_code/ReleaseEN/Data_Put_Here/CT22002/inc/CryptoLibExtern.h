







#ifndef __CRYPTOLIBEXTERN_H__
#define __CRYPTOLIBEXTERN_H__

#include "Option.h"
#include "Crypto_Library.h"

extern void DMA_MOVE_Lib(LWORD Src_Addr, LWORD Des_Addr, LWORD len, BYTE u8EnSrcAutoFlg, BYTE u8EnDesAutoFlg, BYTE wait);

extern void DebugLog_Lib(BYTE u8Priority,
                         BYTE u8Idx,
                         BYTE u8ParaCnt,
                         WORD u16para0,
                         WORD u16para1,
                         WORD u16para2,
                         WORD u16para3,
                         WORD u16SaveLogID);
extern void ResetRam_Lib(BYTE *ptr, LWORD size, BYTE u8Val);
extern void ReverseArray_Lib(BYTE *u8Datain, LWORD u32length);
extern LWORD MemoryAllocate_Lib(BYTE u8Mode, WORD u16Length, LWORD u32BaseAddr);
extern void MemoryRelease_Lib(LWORD u32BaseAddr);
extern LWORD Tran2DecClock_Lib(WORD u16Clk);
extern void MOVE_SDRAM2SDRAM_Lib(BYTE *Des_Addr, BYTE *Src_Addr, LWORD len);

#endif    // ifndef __CRYPTOLIBEXTERN_H__







