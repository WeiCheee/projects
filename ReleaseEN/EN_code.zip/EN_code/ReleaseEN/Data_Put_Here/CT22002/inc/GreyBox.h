







#ifndef __GreyBox_H__
#define __GreyBox_H__

// #include "inc/TypeDef.h"
// #include "inc/Option.h"

extern LWORD g32CodeCoverMapOffset;

extern GBINFO gsGbInfo;
extern LWORD g32GreyBoxSwapOffset;
extern LWORD g32GreyBoxSwapOffset1;
extern BYTE gGreyBoxUartEn;

// Variable for test item GC
extern BYTE gGbGcSrcBlkCnt;
extern BYTE gpGbGcSrcIndex[cMaxGcSrcBlkNum];
extern WORD g16GbGcCachebActThr;
extern WORD g16GbTlcFullCachebGcThr;
extern WORD g16GbSpareBlockCnt;
extern WORD g16GbGcSrcBlock[cMaxGcSrcBlkNum];
extern WORD g16GbGcDesTLCBlock;
extern WORD g16GbCounter;
extern LWORD g32GbGcCachebTime;
extern LWORD g32GbTotalSrcBlkVpc;
extern LWORD g32GbGcSlcVpcThr;

// Variable for test item Retry or Read Err Handle
extern BYTE gReadErrinjectEn;

// Variable for test item RAID
extern BYTE gGbDieAddr;
extern BYTE gGbCe;
extern BYTE gGbIntlvAddr;
extern BYTE gGbCh;
extern BYTE gGbPlaneAddr;
extern WORD g16GbFBlock;
extern WORD g16GbFPage;
extern WORD g16GbRetryTabLoop;
extern WORD g16GbRaidDecTotalCnt;

// Variable for test item Read Cnt & Reclaim
extern WORD g16GbSetReclaimBlk;
extern WORD g16GbGetReclaimBlk;

// Variable for test item Finger Fail
extern LWORD g32GbFingerFailBlk;

// Variable for test item WL
extern LWORD g16GbGlobEraseCnt[c16MaxBlockNum];
extern WORD g16GbWLGcSrcTLCBlock;
extern WORD g16GbWLGcDesTLCBlock;
extern WORD g16GbSlcMoSkipCnt;

// Variable for test item Program Fail
extern WORD g16GbGetPgFailFblk;
extern WORD g16GbGetPgFailFblkNowDiffFblk;
extern WORD g16GbGetPgFailFblkAfterDiffFblock;
extern WORD g16GbSetPgFailFpage;
extern BYTE gGbSetPgFailIntlvAddr;
extern BYTE gGbSetPgFailCh;
extern BYTE gGbSetPgFailPlane;
extern BYTE gGbSetPgFailCase;
extern BYTE gGbEnCacheProg;

extern ADDRINFO gsIspAddrInfo;
extern ADDRINFO gsGbAddrInfo;

extern UTINFO gsUtInfo;

// Variable for record Command
extern LWORD g32GbCmdHistoryPtr;
extern LWORD g32GbEndCmdHistoryPtr;
extern CMDSTRUCT garGbCmdHistory[cCmdHistorySize*cCmdHistorySize];
extern NVMEPRDSTRUCT garGbCmdValidHistory[cCmdHistorySize*cCmdHistorySize];

// dataInVendorCmdGreyBoxPre.c tag
extern CBYTE cbTagdataInVendorCmdGreyBoxPre[];
extern CBYTE cbTagdataInVendorCmdGreyBoxTrig[];
extern CBYTE cbTagdataInVendorCmdGreyBoxDone[];
extern CBYTE cbTagdataInVendorCmdGreyBoxInit[];
extern CBYTE cbTagdataInVendorCmdGreyBoxSaveQBInfo[];

// dataOutVendorCmd.c tag
extern CBYTE cbTagdataOutVendorCmdGreyBoxTrig[];

// F2hTab.c
extern CBYTE cbTagflushCacheF2hTab[];
extern CBYTE cbTagmodifyH2Ftab[];
extern CBYTE cbTagsetH2fSrcBlock[];

// Hmb.c
extern CBYTE cbTagwriteHmbH2fTab[];
extern CBYTE cbTagremHmbLink[];

// GcH2fTab.c
extern CBYTE cbTagbgdClnH2fTabblkProc[];

// GcCacheB.c
extern CBYTE cbTagflushGcDesF2hTab[];

// NvmeIoCmd.c
extern CBYTE cbTagnvmeWriteUncorrectable[];

// FlashReadRetry.c
extern CBYTE cbTagdoReadRetry[];
extern CBYTE cbTagdoReadRetryForPipeLine[];
extern CBYTE cbTagsetTestRetryCmd[];

// SaveIndx.c
extern CBYTE cbTagsaveIndexBlock[];

// Write.c
extern CBYTE cbTaginitNewFblkProc[];

extern CBYTE cVTrig[];
extern CBYTE cVOccur[];
extern CBYTE cVComplet[];
extern CBYTE cVFail[];

// GreyBox.c
void outInfo(BYTE uInfoType);
void outCS(CBYTE *upCallStack);
void outSta(CBYTE *upSta);
void outString(CBYTE *ups, LWORD uVal);
void triggerUGSD(BYTE uWaitCmdDone);
void makeAWGN(BYTE uAWGNlv, BYTE uCh);
void addCoverage(LWORD u32File, LWORD u32Line, LWORD u32ID);
void trigGreyBox(BYTE uSaveRam);
void chkGreyBoxStu(void);
void chkGreyBoxGc(BYTE uStag);
void saveRamInfo(void);
WORD getGreyBoxDifferFBlk(WORD u16FBlock, BYTE uCh, BYTE uIntlvIdx, BYTE uPlaneIdx);
// ==================================================
// For GC H2F
#define cGreyBoxGcH2fTabbHiThr          0x03
#define cGbInfoActH2fBlk                0x0600
#define cGbInfoH2fTabFreePagePtr        0x0602
#define cGbInfoH2fTabPagePerBlk3        0x0604
#define cGbInfoH2fTabBlockCnt           0x0606
#define cGbInfoGcH2fTabbHiThr           0x0608
#define cGbInfoReclimFBlk1              0x060A
#define cGbInfoReclimFBlk2              0x060C
#define cGbInfoReclimFBlk3              0x060E

// For E2E
#define cGbInfoeE2eCmdRetryCnt          0x0610
// For GC
#define cGbInfoGcDesTLCBlock            0x0800
#define cGbInfoFBlock                   0x0802
#define cGbInfoCh                       0x0804
#define cGbInfoCe                       0x0806
#define cGbInfoDie                      0x0808
#define cGbInfoIntlv                    0x080A
#define cGbInfoFPage                    0x080C
#define cGbInfoPlane                    0x080E
#define cGbTlcParity                    0x0810

// For Read Cnt & Reclaim
#define cGbGetInfoReclaimBlk            0x0400
#define cGbSetInfoReclaimBlk            0x0402

#define cGbGetGcStageIdle               0x0400

// For Program Fail
#define cGbSetPgFailFpage               0x200
#define cGbSetPgFailCh                  0x202
#define cGbSetPgFailIntlvAddr           0x203
#define cGbSetPgFailPlane               0x204
#define cGbGetPgFailFblk                0x205
#define cGbGetPgFailFblkAfterDiffFblock 0x207
#define cGbGetPgFailFblkNowDiffFblk     0x209
#define cGbSetGcPgFailFblkIndex         0x20B

#define  rmCovFunc(ustr)  {outString(ustr, 0);}
#define  rmCovFuncCode(u16File, u16Line, u16ID) {outString("F @", u16File);outString(" L @", u16Line);outString(" FC @", u16ID);}
#endif    // ifndef __GreyBox_H__







