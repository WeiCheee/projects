







#ifndef __SECAPI_BASEFW_VAR_H__
#define __SECAPI_BASEFW_VAR_H__

// #pragma default_variable_attributes = @ ".SecurityAPI_Const_BaseFW"    // TSB0
extern CBYTE cbSmiSecureDefaultPassword[cRootKeySize];
extern CBYTE cbRootKeyContext[16];
extern CBYTE cbRootKeyLabel[7];
// #pragma default_variable_attributes =

// #pragma default_variable_attributes = @ ".SecurityAPI_Var_CryptoLib"    // TSB0  (512B)
// #pragma data_alignment=16
extern BYTE garCryptoTmpBuf[512];    // For Crypto temp data
// #pragma default_variable_attributes =

#if _ENABLE_SECAPI
// TCG parameters in TSB0

// =====Don't need to be initialized for Power-cycle and DevSlp=======
extern LWORD g32SecLba;
extern LWORD g32SecGlobalHPage;
extern WORD g16ReceivedComId;
extern WORD g16ReadUnitCnt;
extern BYTE gReceivedProtocolId;
extern BYTE gReceivedRpmbTarget;    // Used for RPMB
extern BYTE gSecStartSectorH;

// IEEE1667 paramters in DRAM
// =====Need to be initialized for Power-cycle and DevSlp=======

// =====Don't need to be initialized for Power-cycle and DevSlp=======
#endif    // if _ENABLE_SECAPI

// #pragma default_variable_attributes = @ ".SecurityAPI_SecurityVar"    // TSB1
/* Used in GatherSecurityPageInfo() and UpdataSecurityKeyDRAMInfo() */
extern BYTE garEncryptedRootKey[cSp800_38fEncryptedSize];
extern BYTE garEncryptedOriginalKEK[cSp800_38fEncryptedSize];
extern BYTE garEncryptedMEK[cSp800_38fEncryptedMekSize];

// #pragma default_variable_attributes =

#endif    // end of __VAR_SECAPI_H__







