







#ifndef __REG_DRAM_H__
#define __REG_DRAM_H__

// ================== DrAM Controller Register     @0x5080_6000 ===============//
// PHY Initialization Register
#define rc32Pir                         0x01
#define rmSetDllLockBypas               r32DramCtrl[rc32Pir]=(r32DramCtrl[rc32Pir]|c32Bit17)
#define rmSetPir(x)                     r32DramCtrl[rc32Pir]=x
#define rmBypassInit                    r32DramCtrl[rc32Pir]=(r32DramCtrl[rc32Pir]|c32Bit31)
#define rmSetPirITMSrST(x)              r32DramCtrl[rc32Pir]=((r32DramCtrl[rc32Pir]&(~c32Bit4))|x<<4)

// PHY General Configuration Register 1
#define rc32Pgcr1                       0x05
#define rmSetWlStep                     r32DramCtrl[rc32Pgcr1]=(r32DramCtrl[rc32Pgcr1]|c32Bit2)
#define rmSetPgcr1(x)                   r32DramCtrl[rc32Pgcr1]=x
#define rmSetPgcrDFTCMP(x)              r32DramCtrl[rc32Pgcr1]=((r32DramCtrl[rc32Pgcr1]&(~c32Bit2))|x<<2)

// PHY General Configuration Register 2
#define rc32Pgcr2                       0x06
#define rmSetPgcr2(x)                   r32DramCtrl[rc32Pgcr2]=x
#define rmSetRefPrd(x)                  r32DramCtrl[rc32Pgcr2]=(r32DramCtrl[rc32Pgcr2]&~0x0003ffff)|x
#define rmGetPgcr2                      r32DramCtrl[rc32Pgcr2]

// PHY General Status Register 0
#define rc32PgSr                        0x0D
#define rmChkZcalDone                   (r32DramCtrl[rc32PgSr]&c32Bit2)
#define rmGetPgSr                       r32DramCtrl[rc32PgSr]
#define rmChkDramaReady                 (rmGetPgSr==0x80004FFF)
// PHY Timing Register 0
#define rc32Ptr0                        0x10
#define rmSetPtr0(x)                    r32DramCtrl[rc32Ptr0]=x

// PHY Timing Register 1
#define rc32Ptr1                        0x11
#define rmSetPtr1(x)                    r32DramCtrl[rc32Ptr1]=x

// PHY Timing Register 2
#define rc32Ptr2                        0x12
#define rmSetPtr2(x)                    r32DramCtrl[rc32Ptr2]=x

// PHY Timing Register 3
#define rc32Ptr3                        0x13
#define rmSetPtr3(x)                    r32DramCtrl[rc32Ptr3]=x

// PHY Timing Register 4
#define rc32Ptr4                        0x14
#define rmSetPtr4(x)                    r32DramCtrl[rc32Ptr4]=x

// PHY Timing Register 5
#define rc32Ptr5                        0x15
#define rmSetPtr5(x)                    r32DramCtrl[rc32Ptr5]=x

// PHY Timing Register 6
#define rc32Ptr6                        0x16
#define rmSetPtr6(x)                    r32DramCtrl[rc32Ptr6]=x

// DATX8 Common Configuration Register
#define rc32DxCcr                       0x22
#define rmEnDxOdt                       r32DramCtrl[rc32DxCcr]=(r32DramCtrl[rc32DxCcr]|c32Bit0)
#define rmDisDxOdt                      r32DramCtrl[rc32DxCcr]=(r32DramCtrl[rc32DxCcr]&~c32Bit0)
#define rmSetDxCcr(x)                   r32DramCtrl[rc32DxCcr]=x

// Ddr System General Configuration Register
#define rc32Dsgcr                       0x24
#define rmSetDsgcr(x)                   r32DramCtrl[rc32Dsgcr]=x

// ODT Configuration Register
#define rc32OdtCr                       0x26
#define rmGetOdtCr                      r32DramCtrl[rc32OdtCr]
#define rmSetOdtCr(x)                   r32DramCtrl[rc32OdtCr]=x

// DrAM Configuration Register
#define rc32Dcr                         0x40
#define rmSetDdrMd2                     r32DramCtrl[rc32Dcr]=((r32DramCtrl[rc32Dcr]&~0x00000007)|0x00000002)
#define rmSetDdrMd3                     r32DramCtrl[rc32Dcr]=((r32DramCtrl[rc32Dcr]&~0x00000007)|0x00000003)
#define rmSetLpDdr2Md                   r32DramCtrl[rc32Dcr]=((r32DramCtrl[rc32Dcr]&~0x00000007)|c32Bit2)
#define rmSetLpDdr3Md                   r32DramCtrl[rc32Dcr]=((r32DramCtrl[rc32Dcr]&~0x00000007)|0x00000005)

// DrAM Timing Parameters Register 0
#define rc32Dtpr0                       0x44
#define rmSetDtpr0(x)                   r32DramCtrl[rc32Dtpr0]=x
#define rmGetDtpr0                      r32DramCtrl[rc32Dtpr0]

// DrAM Timing Parameters Register 1
#define rc32Dtpr1                       0x45
#define rmSetDtpr1(x)                   r32DramCtrl[rc32Dtpr1]=x
#define rmGetDtpr1                      r32DramCtrl[rc32Dtpr1]

// DrAM Timing Parameters Register 2
#define rc32Dtpr2                       0x46
#define rmSetDtpr2(x)                   r32DramCtrl[rc32Dtpr2]=x
#define rmGetDtpr2                      r32DramCtrl[rc32Dtpr2]

// DrAM Timing Parameters Register 3
#define rc32Dtpr3                       0x47
#define rmSetDtpr3(x)                   r32DramCtrl[rc32Dtpr3]=x
#define rmGetDtpr3                      r32DramCtrl[rc32Dtpr3]

// DrAM Timing Parameters Register 4
#define rc32Dtpr4                       0x48
#define rmSetDtpr4(x)                   r32DramCtrl[rc32Dtpr4]=x
#define rmGetDtpr4                      r32DramCtrl[rc32Dtpr4]

// DrAM Timing Parameters Register 5
#define rc32Dtpr5                       0x49
#define rmSetDtpr5(x)                   r32DramCtrl[rc32Dtpr5]=x
#define rmGetDtpr5                      r32DramCtrl[rc32Dtpr5]

#define rc32RdimmGcr0                   0x50
#define rmPdErrOut                      r32DramCtrl[rc32RdimmGcr0]=(r32DramCtrl[rc32RdimmGcr0]|c32Bit21)
#define rmPuErrOut                      r32DramCtrl[rc32RdimmGcr0]=(r32DramCtrl[rc32RdimmGcr0]&~c32Bit21)

// Mode Register 0
#define rc32Mr0                         0x60
#define rmSetMr0(x)                     r32DramCtrl[rc32Mr0]=x
#define rmGetMr0                        r32DramCtrl[rc32Mr0]

// Mode Register 1
#define rc32Mr1                         0x61
#define rmSetMr1(x)                     r32DramCtrl[rc32Mr1]=x
#define rmGetMr1                        r32DramCtrl[rc32Mr1]

// Mode Register 2
#define rc32Mr2                         0x62
#define rmSetMr2(x)                     r32DramCtrl[rc32Mr2]=x
#define rmGetMr2                        r32DramCtrl[rc32Mr2]

// Mode Register 3
#define rc32Mr3                         0x63
#define rmSetMr3(x)                     r32DramCtrl[rc32Mr3]=x
#define rmGetMr3                        r32DramCtrl[rc32Mr3]

// Data Training Configuration Register 0
#define rc32Dtcr0                       0x80
#define rmSetDtcr0(x)                   r32DramCtrl[rc32Dtcr0]=x

// Data Training Configuration Register 1
#define rc32Dtcr1                       0x81
#define rmSetDtcr1(x)                   r32DramCtrl[rc32Dtcr1]=x

// Bist Run Register
#define rc32BistRr                      0x100
#define rmGetBistRr                     r32DramCtrl[rc32BistRr]
#define rmSetBistRr(x)                  r32DramCtrl[rc32BistRr]=x

// Bist Word Count Register
#define rc32BistWcr                     0x101
#define rmGetBistWcr                    r32DramCtrl[rc32BistWcr]
#define rmSetBistWcr(x)                 r32DramCtrl[rc32BistWcr]=x

// Bist Mask Register 1
#define rc32BistMskr1                   0x103
#define rmGetBistMskr1                  r32DramCtrl[rc32BistMskr1]
#define rmSetBistMskr1(x)               r32DramCtrl[rc32BistMskr1]=x

// Bist LFSr Seed Register
#define rc32BistLSr                     0x105
#define rmGetBistLSr                    r32DramCtrl[rc32BistLSr]
#define rmSetBistLSr(x)                 r32DramCtrl[rc32BistLSr]=x

// Bist ADdress Register 1
#define rc32BistAr1                     0x107
#define rmGetBistAr1                    r32DramCtrl[rc32BistAr1]
#define rmSetBistAr1(x)                 r32DramCtrl[rc32BistAr1]=x

// Bist General Status Register
#define rc32BistGSr                     0x10C
#define rmGetBistGSr                    r32DramCtrl[rc32BistGSr]
#define rmSetBistGSr(x)                 r32DramCtrl[rc32BistGSr]=x

// Bist Word Error Register 0
#define rc32BistWer                     0x10D
#define rmGetBistWer                    r32DramCtrl[rc32BistWer]
#define rmSetBistWer(x)                 r32DramCtrl[rc32BistWer]=x

// Bist Bit Error Register 2
#define rc32BistBer2                    0x111
#define rmGetBistBer2                   r32DramCtrl[rc32BistBer2]

// BIST Word Count Status Register
#define rc32BistWcSr                    0x114
#define rmGetBistWcSr                   r32DramCtrl[rc32BistWcSr]

// Rank ID Register
#define rc32RankIDr                     0x137
#define rmSetRankWid(x)                 r32DramCtrl[rc32RankIDr]=((r32DramCtrl[rc32RankIDr]&~0x00000007)|x)
#define rmSetRankRid(x)                 r32DramCtrl[rc32RankIDr]=((r32DramCtrl[rc32RankIDr]&~0x00070000)|(x<<16))

#define rc32IoVcr0                      0x148
#define rmSetAcrefIen                   r32DramCtrl[rc32IoVcr0]=(r32DramCtrl[rc32IoVcr0]|c32Bit24)
#define rmClrAcrefIen                   r32DramCtrl[rc32IoVcr0]=(r32DramCtrl[rc32IoVcr0]&~c32Bit24)
#define rmSetAcrefSen                   r32DramCtrl[rc32IoVcr0]=(r32DramCtrl[rc32IoVcr0]|c32Bit25)
#define rmClrAcrefSen                   r32DramCtrl[rc32IoVcr0]=(r32DramCtrl[rc32IoVcr0]&~c32Bit25)
#define rmSetAcrefEen                   r32DramCtrl[rc32IoVcr0]=(r32DramCtrl[rc32IoVcr0]|0x0C000000)
#define rmClrAcrefEen                   r32DramCtrl[rc32IoVcr0]=(r32DramCtrl[rc32IoVcr0]&~0x0C000000);

#define rc32IoVcr1                      0x149
#define rmSetZqrefIen                   r32DramCtrl[rc32IoVcr1]=(r32DramCtrl[rc32IoVcr1]|c32Bit8)
#define rmClrZqrefIen                   r32DramCtrl[rc32IoVcr1]=(r32DramCtrl[rc32IoVcr1]&~c32Bit8)

// Zq Impedance Control Register
#define rc32ZqIcr                       0x1A0
#define rmSetZqPd                       r32DramCtrl[rc32ZqIcr]=(r32DramCtrl[rc32ZqIcr]|c32Bit2)
#define rmSetZqPu                       r32DramCtrl[rc32ZqIcr]=(r32DramCtrl[rc32ZqIcr]&~c32Bit2)
#define rmSetZqcrFrxZcalVtUpd           r32DramCtrl[rc32ZqIcr]=(r32DramCtrl[rc32ZqIcr]|c32Bit27)
#define rmClrZqcrFrxZcalVtUpd           r32DramCtrl[rc32ZqIcr]=(r32DramCtrl[rc32ZqIcr]&~c32Bit27)

// Zq 0 Impedance Control Program Register
#define rc32Zq0Pr                       0x1A1
#define rmSetZq0Pr(x)                   r32DramCtrl[rc32Zq0Pr]=((r32DramCtrl[rc32Zq0Pr]&0xFFFFFF00)|x)

#define rc32Zq0Dr                       0x1A2
#define rmSetZq0DrDrvZd                 r32DramCtrl[rc32Zq0Dr]=(r32DramCtrl[rc32Zq0Dr]|c32Bit31)
#define rmClrZq0DrDrvZd                 r32DramCtrl[rc32Zq0Dr]=(r32DramCtrl[rc32Zq0Dr]&~c32Bit31)
#define rmSetZq0DrOdtZd                 r32DramCtrl[rc32Zq0Dr]=(r32DramCtrl[rc32Zq0Dr]|c32Bit30)
#define rmClrZq0DrOdtZd                 r32DramCtrl[rc32Zq0Dr]=(r32DramCtrl[rc32Zq0Dr]&~c32Bit30)
#define rmSetZq0DrZdata(x)              r32DramCtrl[rc32Zq0Dr]=((r32DramCtrl[rc32Zq0Dr]&~0x0fffffff)|x)

// ZQ 0 Impedance Control Status Register
#define rc32ZqnSr0                      0x1A3

#define rc32Zq1Dr                       0x1A6
#define rmSetZq1DrDrvZd                 r32DramCtrl[rc32Zq1Dr]=(r32DramCtrl[rc32Zq1Dr]|c32Bit31)
#define rmClrZq1DrDrvZd                 r32DramCtrl[rc32Zq1Dr]=(r32DramCtrl[rc32Zq1Dr]&~c32Bit31)
#define rmSetZq1DrOdtZd                 r32DramCtrl[rc32Zq1Dr]=(r32DramCtrl[rc32Zq1Dr]|c32Bit30)
#define rmClrZq1DrOdtZd                 r32DramCtrl[rc32Zq1Dr]=(r32DramCtrl[rc32Zq1Dr]&~c32Bit30)
#define rmSetZq1DrZdata(x)              r32DramCtrl[rc32Zq1Dr]=((r32DramCtrl[rc32Zq1Dr]&~0x0fffffff)|x)

#define rc32ZqnSr1                      0x1A7
#define rc32ZqnSr2                      0x1AB
#define rc32ZqnSr3                      0x1AF

// DATX8 0 General Configuration Register 0
#define rc32Dx0Gcr                      0x1C0
#define rmGetDx0Gcr                     r32DramCtrl[rc32Dx0Gcr]
#define rmSetDx0Gcr(x)                  r32DramCtrl[rc32Dx0Gcr]=x
#define rmEnDx0                         r32DramCtrl[rc32Dx0Gcr]=r32DramCtrl[rc32Dx0Gcr]|c32Bit0
#define rmDisDx0                        r32DramCtrl[rc32Dx0Gcr]=r32DramCtrl[rc32Dx0Gcr]&~c32Bit0

#define rmEnDx(x)                       r32DramCtrl[rc32Dx0Gcr+x*0x40]=r32DramCtrl[rc32Dx0Gcr+x*0x40]|c32Bit0
#define rmDisDx(x)                      r32DramCtrl[rc32Dx0Gcr+x*0x40]=r32DramCtrl[rc32Dx0Gcr+x*0x40]&~c32Bit0

#define rmPuDqs0se                      r32DramCtrl[rc32Dx0Gcr]=(r32DramCtrl[rc32Dx0Gcr]&~c32Bit12)
#define rmPdDqs0se                      r32DramCtrl[rc32Dx0Gcr]=(r32DramCtrl[rc32Dx0Gcr]|c32Bit12)
#define rmPuDqs0nse                     r32DramCtrl[rc32Dx0Gcr]=(r32DramCtrl[rc32Dx0Gcr]&~c32Bit13)
#define rmPdDqs0nse                     r32DramCtrl[rc32Dx0Gcr]=(r32DramCtrl[rc32Dx0Gcr]|c32Bit13)

#define rc32Dx0Gcr4                     0x1C4
#define rmSetDx0RefIen                  r32DramCtrl[rc32Dx0Gcr4]=(r32DramCtrl[rc32Dx0Gcr4]|0x0000003C)
#define rmClrDx0RefIen                  r32DramCtrl[rc32Dx0Gcr4]=(r32DramCtrl[rc32Dx0Gcr4]&~0x0000003C)
#define rmSetDx0RefSen                  r32DramCtrl[rc32Dx0Gcr4]=(r32DramCtrl[rc32Dx0Gcr4]|c32Bit25)
#define rmClrDx0RefSen                  r32DramCtrl[rc32Dx0Gcr4]=(r32DramCtrl[rc32Dx0Gcr4]&~c32Bit25)
#define rmSetDx0RefEen                  r32DramCtrl[rc32Dx0Gcr4]=(r32DramCtrl[rc32Dx0Gcr4]|0x0C000000)
#define rmClrDx0RefEen                  r32DramCtrl[rc32Dx0Gcr4]=(r32DramCtrl[rc32Dx0Gcr4]&~0x0C000000)

// DATX8 0 General Status Register 0
#define rc32Dx0GSr0                     0x1F8
#define rmSetDx0GSr0(x)                 r32DramCtrl[rc32Dx0GSr0]=x

#if 1
#define rc32Dx1Gcr                      0x200
#define rmGetDx1Gcr                     r32DramCtrl[rc32Dx1Gcr]
#define rmSetDx1Gcr(x)                  r32DramCtrl[rc32Dx1Gcr]=x
#define rmEnDx1                         r32DramCtrl[rc32Dx1Gcr]=r32DramCtrl[rc32Dx1Gcr]|c32Bit0
#define rmDisDx1                        r32DramCtrl[rc32Dx1Gcr]=r32DramCtrl[rc32Dx1Gcr]&~c32Bit0

#define rmPuDqs1se                      r32DramCtrl[rc32Dx1Gcr]=(r32DramCtrl[rc32Dx1Gcr]&~c32Bit12)
#define rmPdDqs1se                      r32DramCtrl[rc32Dx1Gcr]=(r32DramCtrl[rc32Dx1Gcr]|c32Bit12)
#define rmPuDqs1nse                     r32DramCtrl[rc32Dx1Gcr]=(r32DramCtrl[rc32Dx1Gcr]&~c32Bit13)
#define rmPdDqs1nse                     r32DramCtrl[rc32Dx1Gcr]=(r32DramCtrl[rc32Dx1Gcr]|c32Bit13)

#define rc32Dx1Gcr4                     0x204
#define rmSetDx1RefIen                  r32DramCtrl[rc32Dx1Gcr4]=(r32DramCtrl[rc32Dx1Gcr4]|0x0000003C)
#define rmClrDx1RefIen                  r32DramCtrl[rc32Dx1Gcr4]=(r32DramCtrl[rc32Dx1Gcr4]&~0x0000003C)
#define rmSetDx1RefSen                  r32DramCtrl[rc32Dx1Gcr4]=(r32DramCtrl[rc32Dx1Gcr4]|c32Bit25)
#define rmClrDx1RefSen                  r32DramCtrl[rc32Dx1Gcr4]=(r32DramCtrl[rc32Dx1Gcr4]&~c32Bit25)
#define rmSetDx1RefEen                  r32DramCtrl[rc32Dx1Gcr4]=(r32DramCtrl[rc32Dx1Gcr4]|0x0C000000)
#define rmClrDx1RefEen                  r32DramCtrl[rc32Dx1Gcr4]=(r32DramCtrl[rc32Dx1Gcr4]&~0x0C000000)

#define rc32Dx2Gcr                      0x240
#define rmGetDx2Gcr                     r32DramCtrl[rc32Dx2Gcr]
#define rmSetDx2Gcr(x)                  r32DramCtrl[rc32Dx2Gcr]=x
#define rmEnDx2                         r32DramCtrl[rc32Dx2Gcr]=r32DramCtrl[rc32Dx2Gcr]|c32Bit0
#define rmDisDx2                        r32DramCtrl[rc32Dx2Gcr]=r32DramCtrl[rc32Dx2Gcr]&~c32Bit0

#define rc32Dx3Gcr                      0x280
#define rmGetDx3Gcr                     r32DramCtrl[rc32Dx3Gcr]
#define rmSetDx3Gcr(x)                  r32DramCtrl[rc32Dx3Gcr]=x
#define rmEnDx3                         r32DramCtrl[rc32Dx3Gcr]=r32DramCtrl[rc32Dx3Gcr]|c32Bit0
#define rmDisDx3                        r32DramCtrl[rc32Dx3Gcr]=r32DramCtrl[rc32Dx3Gcr]&~c32Bit0

#define rc32MacCtl                      0x400
#define rmSetDramMacSrst                r32DramCtrl[rc32MacCtl]=(r32DramCtrl[rc32MacCtl]|c32Bit12)
#define rmClrDramMacSrst               r32DramCtrl[rc32MacCtl]=(r32DramCtrl[rc32MacCtl]&(~c32Bit12))
#define rmSetDramPhySrst                r32DramCtrl[rc32MacCtl]=(r32DramCtrl[rc32MacCtl]|c32Bit13)
#define rmClrDramPhySrst               r32DramCtrl[rc32MacCtl]=(r32DramCtrl[rc32MacCtl]&0xFFFFDFFF)
#define rmEnMctl                        r32DramCtrl[rc32MacCtl]=r32DramCtrl[rc32MacCtl]|c32Bit0
#define rmDisMctl                       r32DramCtrl[rc32MacCtl]=r32DramCtrl[rc32MacCtl]&~c32Bit0
#define rmEnMultiCS                     r32DramCtrl[rc32MacCtl]=r32DramCtrl[rc32MacCtl]|c32Bit3
#define rmDisMultiCS                    r32DramCtrl[rc32MacCtl]=r32DramCtrl[rc32MacCtl]&~c32Bit3
#define rmEnx16DQBus                    r32DramCtrl[rc32MacCtl]=r32DramCtrl[rc32MacCtl]|c32Bit14
#define rmDisx16DQBus                   r32DramCtrl[rc32MacCtl]=r32DramCtrl[rc32MacCtl]&~c32Bit14
#define rmSetHighDQBus                  r32DramCtrl[rc32MacCtl]=r32DramCtrl[rc32MacCtl]|c32Bit15
#define rmSetLowDQBus                   r32DramCtrl[rc32MacCtl]=r32DramCtrl[rc32MacCtl]&~c32Bit15
#define rmSetMacCtl(x)                  r32DramCtrl[rc32MacCtl]=x
#define rmSetDramSize(x)                r32DramCtrl[rc32MacCtl]=((r32DramCtrl[rc32MacCtl]&0xffffff00f)|x)
#define rmDramSetRfc(x)                 r32DramCtrl[rc32MacCtl]=(r32DramCtrl[rc32MacCtl]&0xffff)|(x<<16)

#define rc32DFICTL                               0x401
#define rMdfiDisDramCke                 r32DramCtrl[rc32DFICTL]=(r32DramCtrl[rc32DFICTL]&(~c32Bit1))
#define rMdfiEnDramCke                  r32DramCtrl[rc32DFICTL]|=c32Bit1
#define rMdfiEnaSelfRefresh             r32DramCtrl[rc32DFICTL]=(r32DramCtrl[rc32DFICTL]|c32Bit28)
#define rMdfiDisSelfRefresh             r32DramCtrl[rc32DFICTL]=(r32DramCtrl[rc32DFICTL]&0xEFFFFFFF)
#define rmEnDramCke                     r32DramCtrl[rc32DFICTL]=(r32DramCtrl[rc32DFICTL]|0x00000002)
#define rmChkDramClk                    (r32DramCtrl[rc32DFICTL]&0x00000002)
#define rmSetDfiEnaLowPwr(x)            r32DramCtrl[rc32DFICTL]=(r32DramCtrl[rc32DFICTL]|(x<<20)|c32Bit16|c32Bit17)
#define rmSetDfiLowPwr(x)               r32DramCtrl[rc32DFICTL]=(r32DramCtrl[rc32DFICTL]|(x<<20))
#define rmSetDfiEnLowPower              r32DramCtrl[rc32DFICTL]=(r32DramCtrl[rc32DFICTL]|c32Bit16)
#define rmSetDfiDisLowPower             r32DramCtrl[rc32DFICTL]=(r32DramCtrl[rc32DFICTL]&(~c32Bit16))
#define rmDfiDisLowPwr                  r32DramCtrl[rc32DFICTL]=(r32DramCtrl[rc32DFICTL]&0xFF00FFFF)
#define rmChkDfiLowPwr                  ((r32DramCtrl[rc32DFICTL]&0x00F30000)==0x00F30000)

#define rc32MctlSTS                     0x402
#define rmChkDfiRefreshAk               (r32DramCtrl[rc32MctlSTS]&c32Bit4)
#define rmChkDfiLowPwrAk                (r32DramCtrl[rc32MctlSTS]&0x00000100)
#define rmChkDrAMMacIdle                (r32DramCtrl[rc32MctlSTS]&c32Bit0)

#define rc32MacCtl1                     (0x403)
#define rmSetDramBankIntleav           r32DramCtrl[rc32MacCtl1]=r32DramCtrl[rc32MacCtl1]|c32Bit0    // (Max) 0:disable, 1:enable
#define rmClrDramBankIntleav            r32DramCtrl[rc32MacCtl1]=r32DramCtrl[rc32MacCtl1]&(~c32Bit0)    // (Max) 0:disable, 1:enable
#define rmSetSelfRefreshCnt(X)          r32DramCtrl[rc32MacCtl1]=((r32DramCtrl[rc32MacCtl1]&0x0000FFFF)|(X<<16))

#define rMrOUND_ROBIN_DmaENABLE         (r32DramCtrl[rc32MacCtl1]=r32DramCtrl[rc32MacCtl1]|c32Bit2)
#define rMrOUND_ROBIN_DmaDISABLE        (r32DramCtrl[rc32MacCtl1]=r32DramCtrl[rc32MacCtl1]&(~c32Bit2))
#define rmSetDmaCpuPrIORITY             (r32DramCtrl[rc32MacCtl1]=r32DramCtrl[rc32MacCtl1]|c32Bit4)

// ================== Cache Buffer Controller Register     @0x5080_7080 ===============//
// Register ADdr Define of Cache Buffer Control Registers
// ====================================================================================//

#define rc32CacheCtl0                   (0x420)
#define rmFlushDramCacheReq             (r32DramCtrl[rc32CacheCtl0]|=c32Bit0)    // (KT) - Flush the Dram cache request
#define rmChkFlushDramCache\
    while(r32DramCtrl[rc32CacheCtl0]&c32Bit0)    // (KT) - Chk flush cache done
#define rmCacheInitBypassEcc            (r32DramCtrl[rc32CacheCtl0]|=c32Bit9)    // (KT) - Use Cpu to assign DrAM value using in both WT/WB
// mode, burst in 32Bytes, read back first when cache miss
#define rmCacheInitBypassClear          (r32DramCtrl[rc32CacheCtl0]&=(~c32Bit9))    // (KT) - Clear Init flow bit (Clear after initialize)
#define rmSetCacheFlushWay(x)           (r32DramCtrl[rc32CacheCtl0]=(r32DramCtrl[rc32CacheCtl0]&~0x000000f0)|(x<<4))    // (KT)- Select the way
// caches to be flushed
#define rmInvalidCache                  (r32DramCtrl[rc32CacheCtl0]|=c32Bit12)    // (KT) - Clear all content in TAG RRAM (locate the
// valid and dirty bit information)
#define rmChkInvalidCache\
    while(r32DramCtrl[rc32CacheCtl0]&c32Bit12)    // (KT) - Check Clear Tag status if busy
#define rmFlushandInvaliDdramCache      (r32DramCtrl[rc32CacheCtl0]|=(c32Bit0|c32Bit12))    // (KT) - Flush and invalid the Dram cache

#define rc32CacheCtl1                   (0x421)
#define rmCacheEnable                   (r32DramCtrl[rc32CacheCtl1]|=c32Bit0)    // (KT) - enable cache function
#define rmCacheDisable                  (r32DramCtrl[rc32CacheCtl1]&=(~c32Bit0))    // (KT) - disable cache function
#define rMDramEccEnable                 (r32DramCtrl[rc32CacheCtl1]|=c32Bit1)    // (KT) - enable ecc function
#define rMDramEccDisable                (r32DramCtrl[rc32CacheCtl1]&=(~c32Bit1))    // (KT) - disable ecc function
#define rmChkDramEccEnable              (r32DramCtrl[rc32CacheCtl1]&c32Bit1)
#define rmSramECCEnable                 (r32DramCtrl[rc32CacheCtl1]|=c32Bit2)    // (62)enable Sram ecc function in L2 cache
#define rmSramECCDisable                (r32DramCtrl[rc32CacheCtl1]&=c32Bit2)    // (62)disable Sram ecc function in L2 cache
#define rmBypassL2Enable                (r32DramCtrl[rc32CacheCtl1]|=c32Bit3)    // (62)enable bypass L2 function when enable Encache
// and Enecc
#define rmBypassL2Disable               (r32DramCtrl[rc32CacheCtl1]&=(~c32Bit3))    // (62)disable bypass L2 function when enable Encache
// and Enecc
#define rmEccDrModeEnable               (r32DramCtrl[rc32CacheCtl1]|=c32Bit4)    // (KT) - enter ecc debug range mode
#define rmEccDrModeDisable              (r32DramCtrl[rc32CacheCtl1]&=(~c32Bit4))    // (KT) - exist enter ecc debug range mode
#define rmEnDramEccErrInt               (r32DramCtrl[rc32CacheCtl1]|=(0xFF0000))    // bit16, 17, 18, 19, 20, 21, 22, 23
#define rmClrDramEccStatus              (r32DramCtrl[rc32CacheCtl1]|=c32Bit24)    // Set 1 to clr err bit, Auto clr

#define rc32CacheCtl2                   (0x422)
#define rmSetHostMinADdr(x)             (r32DramCtrl[rc32CacheCtl2]=x)    // (KT) - The low boundary of the Dram which Protect by ECC,
//  8bytes align

#define rc32CacheCtl3                   (0x423)
#define rmSetHostMaxADdr(x)             (r32DramCtrl[rc32CacheCtl3]=x)    // (KT) - The boundary of the Dram cahce that won't Protect by
// ECC

#define rc32CacheCtl4                   (0x424)
#define rmChkOneErrCpu                  (r32DramCtrl[rc32CacheCtl4]&c32Bit0)    // (KT) - Report if one bit error occur via Cpu access
#define rmChkTwoErrCpu                  (r32DramCtrl[rc32CacheCtl4]&c32Bit1)    // (KT) - Report if two bit error occur via Cpu access
#define rmChkOneParityErrCpu            (r32DramCtrl[rc32CacheCtl4]&c32Bit2)    // (62) Report if one bit err in parity
#define rmChkOneErrDma                  (r32DramCtrl[rc32CacheCtl4]&c32Bit4)    // (KT) - Report if one bit error occur via Dma access
#define rmChkTwoErrDma                  (r32DramCtrl[rc32CacheCtl4]&c32Bit5)    // (KT) - Report if two bit error occur via Dma access
#define rmChkDramEccFail                (r32DramCtrl[rc32CacheCtl4]&0x7777)
#define rmChkDramEccFailCpu             (r32DramCtrl[rc32CacheCtl4]&0x77)
#define rmChkDramEccFailDma             ((r32DramCtrl[rc32CacheCtl4]&0x7700)>>8)
#define rmCacheFSMStatus                (r32DramCtrl[rc32CacheCtl4]&0x1F000000)    // (KT) - Finite State Mache debug information
#define rmChkOneParityErrDma            (r32DramCtrl[rc32CacheCtl4]&c32Bit6)    // (62) Report if one bit err in parity

#define rmChkOneErrTagRam               (r32DramCtrl[rc32CacheCtl4]&c32Bit16)    // (62) Tag ram has one bit err
#define rmChkTwoErrTagRam               (r32DramCtrl[rc32CacheCtl4]&c32Bit17)    // (62) Tag ram has two bit err
#define rmChkOneErrDataL                (r32DramCtrl[rc32CacheCtl4]&c32Bit20)    // (62) data_l ram has one bit error
#define rmChkOneErrDataH                (r32DramCtrl[rc32CacheCtl4]&c32Bit21)    // (62) data_h ram has one bit error
#define rmChkTwoErrDataL                (r32DramCtrl[rc32CacheCtl4]&c32Bit22)    // (62) data_l ram has two bit error
#define rmChkTwoErrDataH                (r32DramCtrl[rc32CacheCtl4]&c32Bit23)    // (62) data_h ram has two bit error

#define rc32CacheCtl5                   (0x425)    // (KT) - Hardware Debug Used, reserve
#define rc32CacheCtl6                   (0x426)    // (KT) - Hardware Debug Used, reserve

// --------------------------------------------------------------------------------------------------//
// Report error Dram ADdress:
// The ADdress will count by a rough unit: 0x20 bytes.
// If the error is occured at byte 0x8000_0008, the reported ADdress would be 0x8000_0000.
// If the error is occured at byte 0x8000_0022, the reported ADdress would be 0x8000_0020.

#define rc32DEccADdr20                  (0x43A)
#define rmGetOneErrCpuADdr              (r32DramCtrl[rc32DEccADdr20])    // (MAX) - Report error Dram ADdress if one bit error occur via
// Cpu access
#define rc32DEccADdr21                  (0x43B)
#define rmGetTwoErrCpuADdr              (r32DramCtrl[rc32DEccADdr21])    // (MAX) - Report error Dram ADdress if two bit error occur via
// Cpu access
#define rc32DEccADdr22                  (0x43C)
#define rmGetOneErrDmaADdr              (r32DramCtrl[rc32DEccADdr22])    // (MAX) - Report error Dram ADdress if one bit error occur via
// Dma access
#define rc32DEccADdr23                  (0x43D)
#define rmGetTwoErrDmaADdr              (r32DramCtrl[rc32DEccADdr23])    // (MAX) - Report error Dram ADdress if two bit error occur via
// Dma access
// --------------------------------------------------------------------------------------------------//

#define rc32DEccADdr30                  (0x444)
#define rmSetHostCrcStartADdr(x)        (r32DramCtrl[rc32DEccADdr30]=x)    // (62) Set host crc data start ADdress.
#define rc32DEccADdr31                  (0x445)
#define rmSetHostStartADdr(x)           (r32DramCtrl[rc32DEccADdr31]=x)    // (62) Set host  data start ADdress.
#define rc32DEccADdr32                  (0x446)
#define rmSetBypassL2MinADdr(x)         (r32DramCtrl[rc32DEccADdr32]=x)    // (62) Set bypass L2 cache min ADdress.
#define rc32DEccADdr33                  (0x447)
#define rmSetBypassL2MaxADdr(x)         (r32DramCtrl[rc32DEccADdr33]=x)    // (62) Set bypass L2 cache max ADdress.

// --------------------------------------------------------------------------------------------------//
// Report error Dram ADdress offset:
// If the error is occured at bit 3 of byte 0x8000_0008, the reported offset would be 0x8 * 8 + 3 = 0x43.
// If the error is occured at bit 1 of byte 0x8000_0022, the reported offset would be 0x2 * 8 + 1 = 0x11.
#define rc32DEccADdr34                  (0x448)
#define rmCpuOneErrDramOffset          (r32DramCtrl[rc32DEccADdr34]&0xFF)
#define rmCpuTwoErrDramOffset          (r32DramCtrl[rc32DEccADdr34]&0xFF00)
#define rmCpuParityErrDramOffset       (r32DramCtrl[rc32DEccADdr34]&0xFFF0000)
#define rc32DEccADdr35                  (0x449)
#define rMdmaOneErrDramOffset          (r32DramCtrl[rc32DEccADdr35]&0xFF)
#define rMdmaTwoErrDramOffset          (r32DramCtrl[rc32DEccADdr35]&0xFF00)
#define rMdmaParityErrDramOffset       (r32DramCtrl[rc32DEccADdr35]&0xFFF0000)
// --------------------------------------------------------------------------------------------------//

// --------------------------------------------------------------------------------------------------//
// Report error Dram position:
// Human readable format.
#define rmCpuOneErrDramADdrByte        (rmGetOneErrCpuADdr+(rmCpuOneErrDramOffset>>3))
#define rmCpuOneErrDramADdrBit         (rmCpuOneErrDramOffset&0x7)
#define rmCpuTwoErrDramADdrByte        (rmGetTwoErrCpuADdr+(rmCpuTwoErrDramOffset>>3))
#define rmCpuTwoErrDramADdrBit         (rmCpuTwoErrDramOffset&0x7)
#define rMdmaOneErrDramADdrByte        (rmGetOneErrDmaADdr+(rMdmaOneErrDramOffset>>3))
#define rMdmaOneErrDramADdrBit         (rMdmaOneErrDramOffset&0x7)
#define rMdmaTwoErrDramADdrByte        (rmGetTwoErrDmaADdr+(rMdmaTwoErrDramOffset>>3))
#define rMdmaTwoErrDramADdrBit         (rMdmaTwoErrDramOffset&0x7)
// --------------------------------------------------------------------------------------------------//
#endif    // if 1
#endif    // ifndef __REG_DRAM_H__







