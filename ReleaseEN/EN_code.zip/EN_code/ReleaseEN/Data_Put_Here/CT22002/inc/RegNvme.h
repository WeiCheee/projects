







#ifndef __REG_NVME_H__
#define __REG_NVME_H__

#include "Common/Model.h"

// Nvme Register @ 0x5001_0000
#define rcNvmeCapLow                             0x0000
#define rcNvmeCapHigh                            0x0004
#define rmCapSetLow                              (r32Nvme0[rcNvmeCapLow/4]=0x08000020)
#define rmCapSetHigh                             (r32Nvme0[rcNvmeCapHigh/4]=0x00100020)    // 0x00100000)

#define rcNvmeVs                                 0x0008
#define rcNvmeIntMs                              0x000C
#define rcNvmeIntMc                              0x0010

#define rcNvmeCc                                 0x0014

#define rmGetMps                                 ((r16Nvme0[rcNvmeCc/2]&0x0780)>>7)
#define rmChkMps                                 (r16Nvme0[rcNvmeCc/2]&0x0780)
#define rmClrMps                                 (r16Nvme0[rcNvmeCc/2]&=0xF87F)    // tnvme 1:1.0.0 20181226_SamHu_02_sync SMI John
#define rmChkShutdownNotify                      (rNvme0[rcNvmeCc+1]&0xC0)
#define rmChkNormalShutdownNotify                ((rNvme0[rcNvmeCc+1]&0xC0)==0x40)
#define rmChkAbruptShutdownNotify                ((rNvme0[rcNvmeCc+1]&0xC0)==0x80)
#define rmClrShutdownNotify                      (rNvme0[rcNvmeCc+1]&=0x3F)

// I/O Completion Queue Entry Size. This should be set to 4 indicating 16 byte Completion Queue Entry.
#define rmIoCqEntry16B                           (rNvme0[rcNvmeCc+2]=((rNvme0[rcNvmeCc+2]&0x0f)|0x40))
// I/O Submission Queue Entry Size. This should be set to 6 indicating 64 byte Submission Queue Entry.
#define rmIoSqEntry64B                           (rNvme0[rcNvmeCc+2]=((rNvme0[rcNvmeCc+2]&0xf0)|0x06))
// Host Memory Page Size(MPS) is (2 ^ (12+MPS))
#define rmSetCcAms                               (rNvme0[rcNvmeCc+1]=((rNvme0[rcNvmeCc+1]&0xc7)|cBit3))
#define rmClrCcAms                               (rNvme0[rcNvmeCc+1]=((rNvme0[rcNvmeCc+1]&0xc7)&(~cBit3)))
#define rmWeightingRoundMps                      (r16Nvme0[rcNvmeCc/2]=((r16Nvme0[rcNvmeCc/2]&0xf0ff)|0x0800))
// #define rmAms                                    ((r16Nvme0[rcNvmeCc/2]&0x3800)>>11)
// #define rmClrAms                                 (r16Nvme0[rcNvmeCc/2]= r16Nvme0[rcNvmeCc/2]&0xC7FF)
#define rmCcMps                                  ((r16Nvme0[rcNvmeCc/2]>>7)&0x000f)
#define rmCcEn                                   (rNvme0[rcNvmeCc]=((rNvme0[rcNvmeCc]&0x0e)|0x1))
#define rmClrCc                                  (r32Nvme0[rcNvmeCc/4]&=0xFF00000E)
#define rmCcEnClr                                (rNvme0[rcNvmeCc]&=0x0E)
#define rmChkCcEn                                (r32Nvme0[rcNvmeCc/4]&0x00000001)
#define rmCcCfg                                  (r32Nvme0[rcNvmeCc/4]=((r32Nvme0[rcNvmeCc/4]&0xff00f0ff)|0x00460800))

#define rcNvmeCsts                               0x001C
#define rmClrNvmeNSSRO                           (r32Nvme0[rcNvmeCsts/4]|=c32Bit4)    // write 1 to clear
#define rmChkNvmeNSSRO                           (r32Nvme0[rcNvmeCsts/4]&c32Bit4)

// removed by h/w #define NvmeNSSR                0x0020
#define rcNvmeAqa                                0x0024
#define rcNvmeAsqLow                             0x0028
#define rcNvmeAsqHigh                            0x002C
#define rcNvmeAcqLow                             0x0030
#define rcNvmeAcqHigh                            0x0034

#define rmGetAcqSize                             (r32Nvme0[rcNvmeAqa/4]>>16)

// Submission Queue Tail (SQT)&Completion Queue Head (CQH)
#define rcNvmeSq0TailDoorBell                    0x1000
#define rcNvmeCq0HeadDoorBell                    0x1004
#define rcNvmeSq1TailDoorBell                    0x1008
#define rcNvmeCq1HeadDoorBell                    0x100C
#define rcNvmeSq2TailDoorBell                    0x1010
#define rcNvmeCq2HeadDoorBell                    0x1014
#define rcNvmeSq3TailDoorBell                    0x1018
#define rcNvmeCq3HeadDoorBell                    0x101C
#define rcNvmeSq4TailDoorBell                    0x1020
#define rcNvmeCq4HeadDoorBell                    0x1024
#define rcNvmeSq5TailDoorBell                    0x1028
#define rcNvmeCq5HeadDoorBell                    0x102C
#define rcNvmeSq6TailDoorBell                    0x1030
#define rcNvmeCq6HeadDoorBell                    0x1034
#define rcNvmeSq7TailDoorBell                    0x1038
#define rcNvmeCq7HeadDoorBell                    0x103C
#define rcNvmeSq8TailDoorBell                    0x1040
#define rcNvmeCq8HeadDoorBell                    0x1044

#define rmGetSqTailDoorBell(x)                   r16Nvme0[(rcNvmeSq0TailDoorBell/2)+(x*4)]
#define rmSetSqTailDoorBell(x, y)                (r16Nvme0[(rcNvmeSq0TailDoorBell/2)+(x*4)]=y)
#define rmGetCqHeadDoorBell(x)                   r16Nvme0[(rcNvmeCq0HeadDoorBell/2)+(x*4)]

#define rmClrSqTailDoorBell(x)                   (r16Nvme0[(rcNvmeSq0TailDoorBell/2)+(x*4)]=0x0000)
#define rmClrCqHeadDoorBell(x)                   (r16Nvme0[(rcNvmeCq0HeadDoorBell/2)+(x*4)]=0x0000)

#define rcNvmeUnexVerRead                        0x1100
#define rcNvmeUnexCap                            0x1104
#define rcNvmeUnexCtrl                           0x1108

// LBA Data Size
#define rmLba512                                 (r32Nvme0[rcNvmeUnexCtrl/4]=(r32Nvme0[rcNvmeUnexCtrl/4]&0xF0FFFFFF))
#define rmLba1024                                (r32Nvme0[rcNvmeUnexCtrl/4]=((r32Nvme0[rcNvmeUnexCtrl/4]&0xF0FFFFFF)|0x01000000))
#define rmLba2048                                (r32Nvme0[rcNvmeUnexCtrl/4]=((r32Nvme0[rcNvmeUnexCtrl/4]&0xF0FFFFFF)|0x02000000))
#define rmLba4096                                (r32Nvme0[rcNvmeUnexCtrl/4]=((r32Nvme0[rcNvmeUnexCtrl/4]&0xF0FFFFFF)|0x03000000))
#define rmLba8192                                (r32Nvme0[rcNvmeUnexCtrl/4]=((r32Nvme0[rcNvmeUnexCtrl/4]&0xF0FFFFFF)|0x04000000))
#define rmLba16384                               (r32Nvme0[rcNvmeUnexCtrl/4]=((r32Nvme0[rcNvmeUnexCtrl/4]&0xF0FFFFFF)|0x05000000))

// Local Memory IF Burst Size
#define rmLocalMemory64                          (r32Nvme0[rcNvmeUnexCtrl/4]=(r32Nvme0[rcNvmeUnexCtrl/4]&0xFF0FFFFF))
#define rmLocalMemory128                         (r32Nvme0[rcNvmeUnexCtrl/4]=((r32Nvme0[rcNvmeUnexCtrl/4]&0xFF0FFFFF)|0x00100000))
#define rmLocalMemory256                         (r32Nvme0[rcNvmeUnexCtrl/4]=((r32Nvme0[rcNvmeUnexCtrl/4]&0xFF0FFFFF)|0x00200000))
#define rmLocalMemory512                         (r32Nvme0[rcNvmeUnexCtrl/4]=((r32Nvme0[rcNvmeUnexCtrl/4]&0xFF0FFFFF)|0x00300000))

// Host IF Burst Size
#define rmLocalHost128                           (r32Nvme0[rcNvmeUnexCtrl/4]=((r32Nvme0[rcNvmeUnexCtrl/4]&0xFFF0FFFF)|0x00010000))
#define rmLocalHost256                           (r32Nvme0[rcNvmeUnexCtrl/4]=((r32Nvme0[rcNvmeUnexCtrl/4]&0xFFF0FFFF)|0x00020000))
#define rmLocalHost512                           (r32Nvme0[rcNvmeUnexCtrl/4]=((r32Nvme0[rcNvmeUnexCtrl/4]&0xFFF0FFFF)|0x00030000))

// Global DMA Enable
#define rmAllDmaEngineEn                         (r32Nvme0[rcNvmeUnexCtrl/4]|=0x00000001)
#define rmAllDmaEngineDis                        (r32Nvme0[rcNvmeUnexCtrl/4]&=0xFFFFFFFE)

#define rcNvmeUnexVerWrite                       0x1110
#define rmSetNvmeVersion(x)                      (r32Nvme0[rcNvmeUnexVerWrite/4]=x)

#define rcNvmeUnexDmaCtrl0                       0x1120
#define rmDisDmaEngine(x)                        (r32Nvme1[rcNvmeUnexDmaCtrl0+(4*x)]=0)

#define rcNvmeUnexFerqWaterMark                  0x11A8

// UnexInt_Stat
#define rcNvmeUnexIntStatLow                     0x11C0
#define rmChkWaterMarkInt                        (r32Nvme0[rcNvmeUnexIntStatLow/4]&0x01)
#define rmUnexIntLowClr                          (r32Nvme0[rcNvmeUnexIntStatLow/4]=0xFFFFFFFF)
#define rmChkNvmeUnexIntStatLow                  (r32Nvme0[rcNvmeUnexIntStatLow/4])
#define rmChkNvmeCrcInt                          (r32Nvme0[rcNvmeUnexIntStatLow/4]&c32Bit20)
#define rmChkNvmeSmartChangeInt                  (r32Nvme0[rcNvmeUnexIntStatLow/4]&c32Bit19)    // Asynchronous Event Configuration
#define rmChkNvmePmChangeInt                     (r32Nvme0[rcNvmeUnexIntStatLow/4]&c32Bit18)    // Power Management
#define rmChkNvmeWriteCacheChangeInt             (r32Nvme0[rcNvmeUnexIntStatLow/4]&c32Bit17)    // Volatile Write Cache
#define rmChkNvmeTmperThresChangeInt             (r32Nvme0[rcNvmeUnexIntStatLow/4]&c32Bit16)    // Temperature Threshold
#define rmChkNvmeInvDbWriteInt                   (r32Nvme0[rcNvmeUnexIntStatLow/4]&c32Bit15)    // CSSD-1740
#define rmChkNvmeShnChangeInt                    (r32Nvme0[rcNvmeUnexIntStatLow/4]&c32Bit14)
#define rmChkNvmeDoorBellInt                     (r32Nvme0[rcNvmeUnexIntStatLow/4]&c32Bit13)
#define rmChkNvmeDpsDppInt                       (r32Nvme0[rcNvmeUnexIntStatLow/4]&c32Bit11)
#define rmChkNvmeResetInt                        (r32Nvme0[rcNvmeUnexIntStatLow/4]&c32Bit10)
#define rmChkNvmeCcEnOnInt                       (r32Nvme0[rcNvmeUnexIntStatLow/4]&c32Bit9)
#define rmChkNvmeFwRqRdyInt                      (r32Nvme0[rcNvmeUnexIntStatLow/4]&c32Bit8)
#define rmChkNvmeFlrInt                          (r32Nvme0[rcNvmeUnexIntStatLow/4]&c32Bit7)    // Function Level Reset

#define rmClrNvmeCrcInt                          (r32Nvme0[rcNvmeUnexIntStatLow/4]=c32Bit20)
#define rmClrNvmeSmartChangeInt                  (r32Nvme0[rcNvmeUnexIntStatLow/4]=c32Bit19)    // Asynchronous Event Configuration
#define rmClrNvmePmChangeInt                     (r32Nvme0[rcNvmeUnexIntStatLow/4]=c32Bit18)    // Power Management
#define rmClrNvmeWriteCacheChangeInt             (r32Nvme0[rcNvmeUnexIntStatLow/4]=c32Bit17)    // Volatile Write Cache
#define rmClrNvmeTmperThresChangeInt             (r32Nvme0[rcNvmeUnexIntStatLow/4]=c32Bit16)    // Temperature Threshold
#define rmClrNvmeInvDbWriteInt                   (r32Nvme0[rcNvmeUnexIntStatLow/4]=c32Bit15)
#define rmClrNvmeShnChangeInt                    (r32Nvme0[rcNvmeUnexIntStatLow/4]=c32Bit14)
#define rmClrNvmeDoorBellInt                     (r32Nvme0[rcNvmeUnexIntStatLow/4]=c32Bit13)
#define rmClrNvmeDpsDppInt                       (r32Nvme0[rcNvmeUnexIntStatLow/4]=c32Bit11)
#define rmClrNvmeResetInt                        (r32Nvme0[rcNvmeUnexIntStatLow/4]=c32Bit10)
#define rmClrNvmeCcEnOnInt                       (r32Nvme0[rcNvmeUnexIntStatLow/4]=c32Bit9)
#define rmClrNvmeFwRqRdyInt                      (r32Nvme0[rcNvmeUnexIntStatLow/4]=c32Bit8)
#define rmClrNvmeFlrInt                          (r32Nvme0[rcNvmeUnexIntStatLow/4]=c32Bit7)    // Function Level Reset

#define rcNvmeUnexIntStatHigh                    0x11C4
#define rmUnexIntHighClr                         (r32Nvme0[rcNvmeUnexIntStatHigh/4]=0xFFFFFFFF)
#define rmChkNvmeUnexIntStatHigh                 (r32Nvme0[rcNvmeUnexIntStatHigh/4])
#define rmChkNvmeDmaErrorInt                     ((r32Nvme0[rcNvmeUnexIntStatHigh/4]&0x0000ff00)>>8)    // DMA engine error
#define rmClrNvmeDmaErrorInt                     (r32Nvme0[rcNvmeUnexIntStatHigh/4]|=0x0000ff00)    // DMA engine error

// UnexIntEn
#define rcNvmeUnexIntEnLow                       0x11C8
#define rmNvmeEnShutDnInt                        (rNvme0[rcNvmeUnexIntEnLow+1]|=cBit6)
#define rmNvmeEnSqDbInt                          (rNvme0[rcNvmeUnexIntEnLow+1]|=cBit5)
#define rmNvmeEnUncCplRdyInt                     (rNvme0[rcNvmeUnexIntEnLow+1]|=cBit4)
#define rmNvmeEnDppDpsInt                        (rNvme0[rcNvmeUnexIntEnLow+1]|=cBit3)
#define rmNvmeEnCcRstInt                         (rNvme0[rcNvmeUnexIntEnLow+1]|=cBit2)
#define rmNvmeEnCcRdyInt                         (rNvme0[rcNvmeUnexIntEnLow+1]|=cBit1)
#define rmNvmeEnFwRqRdyInt                       (rNvme0[rcNvmeUnexIntEnLow+1]|=cBit0)

#define rmNvmeEnFlrInt                           (rNvme0[rcNvmeUnexIntEnLow]|=cBit7)
#define rmNvmeEnFwRqOvInt                        (rNvme0[rcNvmeUnexIntEnLow]|=cBit4)
#define rmNvmeEnFwCqFullInt                      (rNvme0[rcNvmeUnexIntEnLow]|=cBit3)
#define rmNvmeEnFwRqUdInt                        (rNvme0[rcNvmeUnexIntEnLow]|=cBit2)
#define rmNvmeEnFwRqFullInt                      (rNvme0[rcNvmeUnexIntEnLow]|=cBit1)
#define rmNvmeEnFwRqWtMkInt                      (rNvme0[rcNvmeUnexIntEnLow]|=cBit0)

#define rmNvmeDisShutDnInt                       (rNvme0[rcNvmeUnexIntEnLow+1]&=(~cBit6))
#define rmNvmeDisSqDbInt                         (rNvme0[rcNvmeUnexIntEnLow+1]&=(~cBit5))
#define rmNvmeDisUncCplRdyInt                    (rNvme0[rcNvmeUnexIntEnLow+1]&=(~cBit4))
#define rmNvmeDisDppDpsInt                       (rNvme0[rcNvmeUnexIntEnLow+1]&=(~cBit3))
#define rmNvmeDisCcRstInt                        (rNvme0[rcNvmeUnexIntEnLow+1]&=(~cBit2))
#define rmNvmeDisCcRdyInt                        (rNvme0[rcNvmeUnexIntEnLow+1]&=(~cBit1))
#define rmNvmeDisFwRqRdyInt                      (rNvme0[rcNvmeUnexIntEnLow+1]&=(~cBit0))

#define rmNvmeDisFlrInt                          (rNvme0[rcNvmeUnexIntEnLow]|=(~cBit7))
#define rmNvmeDisFwRqOvInt                       (rNvme0[rcNvmeUnexIntEnLow]&=(~cBit4))
#define rmNvmeDisFwCqFullInt                     (rNvme0[rcNvmeUnexIntEnLow]&=(~cBit3))
#define rmNvmeDisFwRqUdInt                       (rNvme0[rcNvmeUnexIntEnLow]&=(~cBit2))
#define rmNvmeDisFwRqFullInt                     (rNvme0[rcNvmeUnexIntEnLow]&=(~cBit1))
#define rmNvmeDisFwRqWtMkInt                     (rNvme0[rcNvmeUnexIntEnLow]&=(~cBit0))

#define rmNvmeIntLowEn                           (r32Nvme0[rcNvmeUnexIntEnLow/4]=0xFFFFC6FE)
#define rmNvmeIntLowEnAll                        (r32Nvme0[rcNvmeUnexIntEnLow/4]=0xFFFFFFFF)
#define rmNvmeIntLowDisAll                       (r32Nvme0[rcNvmeUnexIntEnLow/4]=0x00)
#define rmNvmeCrcIntEn                           (r32Nvme0[rcNvmeUnexIntEnLow/4]|=c32Bit20)
#define rmNvmeSmartChangeEn                      (r32Nvme0[rcNvmeUnexIntEnLow/4]|=c32Bit19)    // Asynchronous Event Configuration
#define rmNvmePmChangeEn                         (r32Nvme0[rcNvmeUnexIntEnLow/4]|=c32Bit18)    // Power Management
#define rmNvmeWriteCacheChangeEn                 (r32Nvme0[rcNvmeUnexIntEnLow/4]|=c32Bit17)    // Volatile Write Cache
#define rmNvmeTmperThresChangeEn                 (r32Nvme0[rcNvmeUnexIntEnLow/4]|=c32Bit16)    // Temperature Threshold
#define rmNvmeInvDbWriteEn                       (r32Nvme0[rcNvmeUnexIntEnLow/4]|=c32Bit15)
#define rmNvmeInvDbWriteDis                      (r32Nvme0[rcNvmeUnexIntEnLow/4]&=(~c32Bit15))
#define rmNvmeShnChangeEn                        (r32Nvme0[rcNvmeUnexIntEnLow/4]|=c32Bit14)
#define rmNvmeDpsDppIntEn                        (r32Nvme0[rcNvmeUnexIntEnLow/4]|=c32Bit11)
#define rmNvmeResetIntEn                         (r32Nvme0[rcNvmeUnexIntEnLow/4]|=c32Bit10)
#define rmNvmeCcEnOnEn                           (r32Nvme0[rcNvmeUnexIntEnLow/4]|=c32Bit9)
#define rmNvmeFwRqRdyEn                          (r32Nvme0[rcNvmeUnexIntEnLow/4]|=c32Bit8)
#define rmNvmeResetIntDis                        (r32Nvme0[rcNvmeUnexIntEnLow/4]&=0xFFFFFBFF)

#define rcNvmeUnexIntEnHigh                      0x11CC
#define rmNvmeIntHighEnAll                       (r32Nvme0[rcNvmeUnexIntEnHigh/4]=0xFFFFFFFF)
#define rmNvmeIntHighDisAll                      (r32Nvme0[rcNvmeUnexIntEnHigh/4]=0x00)
#define rmNvmeDmaEngineIntEn                     (r32Nvme0[rcNvmeUnexIntEnHigh/4]|=0x00FF0000)

#define rcUnexAxiHostMastStat                    0x11E0
#define rcUnexAxiMsMastStat                      0x11E4
#define rcUnexAxiSlaveStatLow                    0x11E8
#define rcUnexAxiSlaveErrAddrLow                 0x11EC
#define rcUnexAxiSlaveErrAddrHigh                0x11F0

#define rcNvme0Misc0                              0x11F4
#define rmSetNss                                 (r32Nvme0[rcNvme0Misc0/4]=0x01)
#define rmSetPp                                  (r32Nvme0[rcNvme0Misc0/4]|=c32Bit15)
#define rmClrPp                                  (r32Nvme0[rcNvme0Misc0/4]&=(~c32Bit15))
#define rmChkPp                                  (r32Nvme0[rcNvme0Misc0/4]&c32Bit15)

#define rcNvmeMisc1                              0x11F8
#define rmNvmeCcRdyHwCtrl                        (rNvme0[rcNvmeMisc1]|=cBit0)
#define rmNvmeCcRdyFwCtrl                        (rNvme0[rcNvmeMisc1]&=(~cBit0))

#define rcNvmeOacs                               0x11FB    // Optional Admin Cmd Support
#define rmSetOacs(x)                             (rNvme0[rcNvmeOacs]=x)

#define rcNvmeAcl                                0x11FC    // Abort Cmd Limit
#define rmSetAcl(x)                              (rNvme0[rcNvmeAcl]=x)

#define rcNvmeAerl                               0x11FD    // Async Evnet Request Limit
#define rmSetAerl(x)                             (rNvme0[rcNvmeAerl]=x)
#define rmChkAerl                                rNvme0[rcNvmeAerl]

// bit4: HW support Save/Select Field
// bit3: HW support Write Zeros Command
// bit2: HW support Data Set Management Command
// bit1: HW support Write Uncorrectable Command
// bit0: HW support Compare Command
#define rcNvmeOncs                               0x11FE    // Optional NVM Cmd Supported
#define rmSetOncs(x)                             (rNvme0[rcNvmeOncs]=x)

#define rcNvmeApst                               0x11FF    // bit 0 APST enabl bit
#define rmSetApst(x)                             (rNvme0[rcNvmeApst]=(x&0x1))

#define rcNvmeMaxIntVec                          0x1200
// #define rmSetMaxIntVec                           (r16Nvme0[rcNvmeMaxIntVec/2]=0x10)
#define rmSetMaxIntVec(x)                        (r16Nvme0[rcNvmeMaxIntVec/2]=x)

#define rcNvmeMpsMaxMin                          0x1204
#define rmSetMpsMaxMin(max, min)                  (rNvme0[rcNvmeMpsMaxMin]=(max|(min<<4)))

#define rcNvmeTo                                 0x1205
#define rmSetTo(x)                               (rNvme0[rcNvmeTo]=x)

#define rcNvmeMqes                               0x1206
#define rmSetMqes(x)                             (r16Nvme0[rcNvmeMqes/2]=x)

// it is a write only register
#define rcNvmeMisc5                              0x1208
#define rmSetNvmeMisc5(x)                        (rNvme0[rcNvmeMisc5]=x)    // b3:CQR, b2:CFS, b1:AMS, b0:NSSRS

#define rcCmdDw0                                 0x1210
#define rmSetUnexCmdDw0(x)                       (rNvme0[rcCmdDw0]=x)
#define rmSetCreateSqCq                          (rNvme0[rcCmdDw0+1]|=cBit0)

#define rcCmdDw10                                0x1214
#define rmSetUnexCmdDw10(x)                      (r32Nvme0[rcCmdDw10/4]=x)

#define rcCmdDw11                                0x1218
#define rmSetUnexCmdDw11(x)                      (r32Nvme0[rcCmdDw11/4]=x)

#define rcCmdPrp1Low                             0x121C
#define rmSetUnexCmdPrp1L(x)                     (r32Nvme0[rcCmdPrp1Low/4]=x)

#define rcCmdPrp1High                            0x1220
#define rmSetUnexCmdPrp1H(x)                     (r32Nvme0[rcCmdPrp1High/4]=x)

#define rcNvmeCtrl0                              0x1224
#define rmSetPorSoftReset                        (rNvme0[rcNvmeCtrl0]|=cBit4)
#define rmClrPorSoftReset                        (rNvme0[rcNvmeCtrl0]&=(~cBit4))
#define rmForceBurstSize                         (rNvme0[rcNvmeCtrl0]|=cBit3)
#define rmSetCcRdy                               (rNvme0[rcNvmeCtrl0]|=cBit0)
#define rmClrCcRdy                               (rNvme0[rcNvmeCtrl0]&=(~cBit0))
#define rmChkCcRdy                               (rNvme0[rcNvmeCtrl0]&cBit0)

#define rmSetShstOccuring                        (rNvme0[rcNvmeCtrl0]=((rNvme0[rcNvmeCtrl0]&(~cBit2))|cBit1))
#define rmSetShstComplete                        (rNvme0[rcNvmeCtrl0]=((rNvme0[rcNvmeCtrl0]&(~cBit1))|cBit2))
#define rmChkShstComplete                        (rNvme0[rcNvmeCtrl0]&cBit2)
#define rmSetShstNormal                          (rNvme0[rcNvmeCtrl0]=(rNvme0[rcNvmeCtrl0]&(~(cBit1|cBit2))))

#define rcNvmeSetFeatAbitration                  0x1228
// #define rmSetFeatArbitration(x)                  (r32Nvme0[rcNvmeSetFeatAbitration/4]=x)
// #define rmSetFeatHPW(x)                          (rNvme0[rcNvmeSetFeatAbitration+3]=x)
// #define rmSetFeatMPW(x)                          (rNvme0[rcNvmeSetFeatAbitration+2]=x)
// #define rmSetFeatLPW(x)                          (rNvme0[rcNvmeSetFeatAbitration+1]=x)
// #define rmSetFeatAB(x)                           (rNvme0[rcNvmeSetFeatAbitration]=x)
#define rmSetFeatArbitrationAll(x)               (r32Nvme0[rcNvmeSetFeatAbitration/4]=x)
#if (_RR_WORKAROUND)
#define rmSetFeatArbitrationHpw(x)               (rNvme0[rcNvmeSetFeatAbitration+3]=x)
#define rmSetFeatArbitrationMpw(x)               (rNvme0[rcNvmeSetFeatAbitration+2]=x)
#define rmSetFeatArbitrationLpw(x)               (rNvme0[rcNvmeSetFeatAbitration+1]=x)
#define rmSetFeatArbitrationAb(x)                (rNvme0[rcNvmeSetFeatAbitration]=x)
#endif
#define rcNvmeSetFeatCoalescing                  0x122C
#define rmSetFeatCoalescing(x)                   (r32Nvme0[rcNvmeSetFeatCoalescing/4]=x)

#define rcNvmeSetFeatIntVecCfg                   0x1230
#define rmSetFeatIntVecCfg(x)                    (r32Nvme0[rcNvmeSetFeatIntVecCfg/4]=x)
#define rmSetFeatIntVecCfgUpdate                 (r16Nvme0[(rcNvmeSetFeatIntVecCfg/2)+1]|=cBit1)
#define rmClrFeatIntVecCfgUpdate                 (r16Nvme0[(rcNvmeSetFeatIntVecCfg/2)+1]&=(~cBit1))

#define rcNvmeSqHeadPtr                          0x1234
#define rmGet2263SqHeadDoorBell(x)               r32Nvme0[(rcNvmeSqHeadPtr/4)+x]

#define rcNvmeIntSqHeadPtr                       0x1278
#define rmGet2263IntSqHeadDoorBell(x)            r32Nvme0[(rcNvmeIntSqHeadPtr/4)+x]

#define rcNvmeCqTailPtr                          0x12BC
#define rmGet2263CqTailDoorBell(x)               r32Nvme0[(rcNvmeCqTailPtr/4)+x]

#define rcNvmeInvSqDb                            0x1300
#define rmGetNvmeInvSqDb                         r32Nvme0[rcNvmeInvSqDb/4]
#define rmChkNvmeInvSqDbAdmin                    (r32Nvme0[rcNvmeInvSqDb/4]&c32Bit0)
#define rmChkNvmeInvSqDbIo                       (r32Nvme0[rcNvmeInvSqDb/4]&0x0001FFFE)
#define rmClrNvmeInvSqDb(x)                      (r32Nvme0[rcNvmeInvSqDb/4]=x)
#define rmClrNvmeInvSqDbAll                      (r32Nvme0[rcNvmeInvSqDb/4]=r32Nvme0[rcNvmeInvSqDb/4])

#define rcNvmeInvCqDb                             0x1304
#define rmGetNvmeInvCqDb                         (r32Nvme0[rcNvmeInvCqDb/4])
#define rmChkNvmeInvCqDbAdmin                    (r32Nvme0[rcNvmeInvCqDb/4]&c32Bit0)
#define rmChkNvmeInvCqDbIo                       (r32Nvme0[rcNvmeInvCqDb/4]&0x0001FFFE)
#define rmClrNvmeInvCqDb(x)                      (r32Nvme0[rcNvmeInvCqDb/4]=(x))
#define rmClrNvmeInvCqDbAll                      (r32Nvme0[rcNvmeInvCqDb/4]=r32Nvme0[rcNvmeInvCqDb/4])

#define rcNvmeSqSize                             0x1308
#define rmGetSqSize(x)                           (r32Nvme0[(rcNvmeSqSize+(x-1))])

#define rcNvmeCqSize                             0x1348
#define rmGetCqSize(x)                           (r32Nvme0[(rcNvmeCqSize+(x-1))])

#define rcNvmeCqSq                               0x1388
#define rmGetParingCq(x)                         (r32Nvme0[rcNvmeCqSq+(x-1)])

#define rcNvmeCqSqEn                             0x13C8
#define rmGetNvmeCqSqEn                          r32Nvme0[rcNvmeCqSqEn/4]
#define rmGetNvmeSqEn                            r16Nvme0[rcNvmeCqSqEn/2]
#define rmChkNvmeSqEn(x)                         ((r16Nvme0[rcNvmeCqSqEn/2]>>(x-1))&0x1)
#define rmGetNvmeCqEn                            r16Nvme0[(rcNvmeCqSqEn/2)+1]
#define rmChkNvmeCqEn(x)                         ((r16Nvme0[(rcNvmeCqSqEn/2)+1]>>(x-1))&0x1)

// For IntelAPI
#define rmNVMeChkCqSqExist                       ((r32Nvme0[rcNvmeCqSqEn/4]&0xFFFF0000)&&(r32Nvme0[rcNvmeCqSqEn/4]&0x0000FFFF))
#define rcNvmeCqIntVec1                          0x13CC
#define rcNvmeCqIntVec2                          0x13D0
#define rcNvmeCqIntVec3                          0x13D4
#define rcNvmeCqIntVec4                          0x13D8
#define rcNvmeCqIntVec5                          0x13DC
#define rcNvmeCqIntVec6                          0x13E0
#define rcNvmeCqIntVec7                          0x13E4
#define rcNvmeCqIntVec8                          0x13E8
#define rcNvmeCqIntVec9                          0x13EC
#define rcNvmeCqIntVec10                         0x13F0
#define rcNvmeCqIntVec11                         0x13F4
#define rcNvmeCqIntVec12                         0x13F8
#define rcNvmeCqIntVec13                         0x13FC
#define rcNvmeCqIntVec14                         0x1400
#define rcNvmeCqIntVec15                         0x1404
#define rcNvmeCqIntVec16                         0x1408

#define rmGetCq1IntVec                           r16Nvme0[rcNvmeCqIntVec1/2]
#define rmGetCq2IntVec                           r16Nvme0[rcNvmeCqIntVec2/2]
#define rmGetCq3IntVec                           r16Nvme0[rcNvmeCqIntVec3/2]
#define rmGetCq4IntVec                           r16Nvme0[rcNvmeCqIntVec4/2]
#define rmGetCq5IntVec                           r16Nvme0[rcNvmeCqIntVec5/2]
#define rmGetCq6IntVec                           r16Nvme0[rcNvmeCqIntVec6/2]
#define rmGetCq7IntVec                           r16Nvme0[rcNvmeCqIntVec7/2]
#define rmGetCq8IntVec                           r16Nvme0[rcNvmeCqIntVec8/2]
#define rmGetCq9IntVec                           r16Nvme0[rcNvmeCqIntVec9/2]
#define rmGetCq10IntVec                          r16Nvme0[rcNvmeCqIntVec10/2]
#define rmGetCq11IntVec                          r16Nvme0[rcNvmeCqIntVec11/2]
#define rmGetCq12IntVec                          r16Nvme0[rcNvmeCqIntVec12/2]
#define rmGetCq13IntVec                          r16Nvme0[rcNvmeCqIntVec13/2]
#define rmGetCq14IntVec                          r16Nvme0[rcNvmeCqIntVec14/2]
#define rmGetCq15IntVec                          r16Nvme0[rcNvmeCqIntVec15/2]
#define rmGetCq16IntVec                          r16Nvme0[rcNvmeCqIntVec16/2]

// IO Queue Base Address for deubg purpose
// Power Domain 0
#define rcSq1BaseAddr0Low                        0x140C
#define rcSq1BaseAddr0High                       0x1410
#define rcSq2BaseAddr0Low                        0x1414
#define rcSq2BaseAddr0High                       0x1418
#define rcSq3BaseAddr0Low                        0x141C
#define rcSq3BaseAddr0High                       0x1420
#define rcSq4BaseAddr0Low                        0x1424
#define rcSq4BaseAddr0High                       0x1428
#define rcSq5BaseAddr0Low                        0x142C
#define rcSq5BaseAddr0High                       0x1430
#define rcSq6BaseAddr0Low                        0x1434
#define rcSq6BaseAddr0High                       0x1438
#define rcSq7BaseAddr0Low                        0x143C
#define rcSq7BaseAddr0High                       0x1440
#define rcSq8BaseAddr0Low                        0x1444
#define rcSq8BaseAddr0High                       0x1448
#define rcSq9BaseAddr0Low                        0x144C
#define rcSq9BaseAddr0High                       0x1450
#define rcSq10BaseAddr0Low                       0x1454
#define rcSq10BaseAddr0High                      0x1458
#define rcSq11BaseAddr0Low                       0x145C
#define rcSq11BaseAddr0High                      0x1460
#define rcSq12BaseAddr0Low                       0x1464
#define rcSq12BaseAddr0High                      0x1468
#define rcSq13BaseAddr0Low                       0x146C
#define rcSq13BaseAddr0High                      0x1470
#define rcSq14BaseAddr0Low                       0x1474
#define rcSq14BaseAddr0High                      0x1478
#define rcSq15BaseAddr0Low                       0x147C
#define rcSq15BaseAddr0High                      0x1480
#define rcSq16BaseAddr0Low                       0x1484
#define rcSq16BaseAddr0High                      0x1488
#define rmGetSq1BaseAddr0Low                     r32Nvme0[rcSq1BaseAddr0Low/4]
#define rmGetSq1BaseAddr0High                    r32Nvme0[rcSq1BaseAddr0High/4]
#define rmGetSq2BaseAddr0Low                     r32Nvme0[rcSq2BaseAddr0Low/4]
#define rmGetSq2BaseAddr0High                    r32Nvme0[rcSq2BaseAddr0High/4]
#define rmGetSq3BaseAddr0Low                     r32Nvme0[rcSq3BaseAddr0Low/4]
#define rmGetSq3BaseAddr0High                    r32Nvme0[rcSq3BaseAddr0High/4]
#define rmGetSq4BaseAddr0Low                     r32Nvme0[rcSq4BaseAddr0Low/4]
#define rmGetSq4BaseAddr0High                    r32Nvme0[rcSq4BaseAddr0High/4]
#define rmGetSq5BaseAddr0Low                     r32Nvme0[rcSq5BaseAddr0Low/4]
#define rmGetSq5BaseAddr0High                    r32Nvme0[rcSq5BaseAddr0High/4]
#define rmGetSq6BaseAddr0Low                     r32Nvme0[rcSq6BaseAddr0Low/4]
#define rmGetSq6BaseAddr0High                    r32Nvme0[rcSq6BaseAddr0High/4]
#define rmGetSq7BaseAddr0Low                     r32Nvme0[rcSq7BaseAddr0Low/4]
#define rmGetSq7BaseAddr0High                    r32Nvme0[rcSq7BaseAddr0High/4]
#define rmGetSq8BaseAddr0Low                     r32Nvme0[rcSq8BaseAddr0Low/4]
#define rmGetSq8BaseAddr0High                    r32Nvme0[rcSq8BaseAddr0High/4]
#define rmGetSq9BaseAddr0Low                     r32Nvme0[rcSq9BaseAddr0Low/4]
#define rmGetSq9BaseAddr0High                    r32Nvme0[rcSq9BaseAddr0High/4]
#define rmGetSq10BaseAddr0Low                    r32Nvme0[rcSq10BaseAddr0Low/4]
#define rmGetSq10BaseAddr0High                   r32Nvme0[rcSq10BaseAddr0High/4]
#define rmGetSq11BaseAddr0Low                    r32Nvme0[rcSq11BaseAddr0Low/4]
#define rmGetSq11BaseAddr0High                   r32Nvme0[rcSq11BaseAddr0High/4]
#define rmGetSq12BaseAddr0Low                    r32Nvme0[rcSq12BaseAddr0Low/4]
#define rmGetSq12BaseAddr0High                   r32Nvme0[rcSq12BaseAddr0High/4]
#define rmGetSq13BaseAddr0Low                    r32Nvme0[rcSq13BaseAddr0Low/4]
#define rmGetSq13BaseAddr0High                   r32Nvme0[rcSq13BaseAddr0High/4]
#define rmGetSq14BaseAddr0Low                    r32Nvme0[rcSq14BaseAddr0Low/4]
#define rmGetSq14BaseAddr0High                   r32Nvme0[rcSq14BaseAddr0High/4]
#define rmGetSq15BaseAddr0Low                    r32Nvme0[rcSq15BaseAddr0Low/4]
#define rmGetSq15BaseAddr0High                   r32Nvme0[rcSq15BaseAddr0High/4]
#define rmGetSq16BaseAddr0Low                    r32Nvme0[rcSq16BaseAddr0Low/4]
#define rmGetSq16BaseAddr0High                   r32Nvme0[rcSq16BaseAddr0High/4]
#define rmGetSqBaseAddrLow(x)                    r32Nvme0[(rcSq1BaseAddr0Low/4)+((x-1)*2)]
#define rmGetSqBaseAddrHigh(x)                   r32Nvme0[(rcSq1BaseAddr0High/4)+((x-1)*2)]

#define rcCq1BaseAddr0Low                        0x148C
#define rcCq1BaseAddr0High                       0x1490
#define rcCq2BaseAddr0Low                        0x1494
#define rcCq2BaseAddr0High                       0x1498
#define rcCq3BaseAddr0Low                        0x149C
#define rcCq3BaseAddr0High                       0x14A0
#define rcCq4BaseAddr0Low                        0x14A4
#define rcCq4BaseAddr0High                       0x14A8
#define rcCq5BaseAddr0Low                        0x14AC
#define rcCq5BaseAddr0High                       0x14B0
#define rcCq6BaseAddr0Low                        0x14B4
#define rcCq6BaseAddr0High                       0x14B8
#define rcCq7BaseAddr0Low                        0x14BC
#define rcCq7BaseAddr0High                       0x14C0
#define rcCq8BaseAddr0Low                        0x14C4
#define rcCq8BaseAddr0High                       0x14C8
#define rcCq9BaseAddr0Low                        0x14CC
#define rcCq9BaseAddr0High                       0x14D0
#define rcCq10BaseAddr0Low                       0x14D4
#define rcCq10BaseAddr0High                      0x14D8
#define rcCq11BaseAddr0Low                       0x14DC
#define rcCq11BaseAddr0High                      0x14E0
#define rcCq12BaseAddr0Low                       0x14E4
#define rcCq12BaseAddr0High                      0x14E8
#define rcCq13BaseAddr0Low                       0x14EC
#define rcCq13BaseAddr0High                      0x14F0
#define rcCq14BaseAddr0Low                       0x14F4
#define rcCq14BaseAddr0High                      0x14F8
#define rcCq15BaseAddr0Low                       0x14FC
#define rcCq15BaseAddr0High                      0x1500
#define rcCq16BaseAddr0Low                       0x1504
#define rcCq16BaseAddr0High                      0x1508
#define rmGetCq1BaseAddrLow                      r32Nvme0[rcCq1BaseAddr0Low/4]
#define rmGetCq1BaseAddr0High                    r32Nvme0[rcCq1BaseAddr0High/4]
#define rmGetCq2BaseAddr0Low                     r32Nvme0[rcCq2BaseAddr0Low/4]
#define rmGetCq2BaseAddr0High                    r32Nvme0[rcCq2BaseAddr0High/4]
#define rmGetCq3BaseAddr0Low                     r32Nvme0[rcCq3BaseAddr0Low/4]
#define rmGetCq3BaseAddr0High                    r32Nvme0[rcCq3BaseAddr0High/4]
#define rmGetCq4BaseAddr0Low                     r32Nvme0[rcCq4BaseAddr0Low/4]
#define rmGetCq4BaseAddr0High                    r32Nvme0[rcCq4BaseAddr0High/4]
#define rmGetCq5BaseAddr0Low                     r32Nvme0[rcCq5BaseAddr0Low/4]
#define rmGetCq5BaseAddr0High                    r32Nvme0[rcCq5BaseAddr0High/4]
#define rmGetCq6BaseAddr0Low                     r32Nvme0[rcCq6BaseAddr0Low/4]
#define rmGetCq6BaseAddr0High                    r32Nvme0[rcCq6BaseAddr0High/4]
#define rmGetCq7BaseAddr0Low                     r32Nvme0[rcCq7BaseAddr0Low/4]
#define rmGetCq7BaseAddr0High                    r32Nvme0[rcCq7BaseAddr0High/4]
#define rmGetCq8BaseAddr0Low                     r32Nvme0[rcCq8BaseAddr0Low/4]
#define rmGetCq8BaseAddr0High                    r32Nvme0[rcCq8BaseAddr0High/4]
#define rmGetCq9BaseAddr0Low                     r32Nvme0[rcCq9BaseAddr0Low/4]
#define rmGetCq9BaseAddr0High                    r32Nvme0[rcCq9BaseAddr0High/4]
#define rmGetCq10BseAddr0Low                     r32Nvme0[rcCq10BaseAddr0Low/4]
#define rmGetCq10BaseAddr0High                   r32Nvme0[rcCq10BaseAddr0High/4]
#define rmGetCq11BaseAddr0Low                    r32Nvme0[rcCq11BaseAddr0Low/4]
#define rmGetCq11BaseAddr0High                   r32Nvme0[rcCq11BaseAddr0High/4]
#define rmGetCq12BaseAddr0Low                    r32Nvme0[rcCq12BaseAddr0Low/4]
#define rmGetCq12BaseAddr0High                   r32Nvme0[rcCq12BaseAddr0High/4]
#define rmGetCq13BaseAddr0Low                    r32Nvme0[rcCq13BaseAddr0Low/4]
#define rmGetCq13BaseAddr0High                   r32Nvme0[rcCq13BaseAddr0High/4]
#define rmGetCq14BaseAddr0Low                    r32Nvme0[rcCq14BaseAddr0Low/4]
#define rmGetCq14BaseAddr0High                   r32Nvme0[rcCq14BaseAddr0High/4]
#define rmGetCq15BaseAddr0Low                    r32Nvme0[rcCq15BaseAddr0Low/4]
#define rmGetCq15BaseAddr0High                   r32Nvme0[rcCq15BaseAddr0High/4]
#define rmGetCq16BaseAddr0Low                    r32Nvme0[rcCq16BaseAddr0Low/4]
#define rmGetCq16BaseAddr0High                   r32Nvme0[rcCq16BaseAddr0High/4]
#define rmGetCqBaseAddrLow(x)                    r32Nvme0[(rcCq1BaseAddr0Low/4)+((x-1)*2)]
#define rmGetCqBaseAddrHigh(x)                   r32Nvme0[(rcCq1BaseAddr0High/4)+((x-1)*2)]

#define rcStopFetchAllCmd                        0x1534    // include all IO and Admin command
#define rmSetStopFetchAllCmd                     (r32Nvme0[rcStopFetchAllCmd/4]|=c32Bit0)
#define rmClrStopFetchAllCmd                     (r32Nvme0[rcStopFetchAllCmd/4]&=(~c32Bit0))

// IO Queue Base Address for deubg purpose
// It will be reset when disable Power Domain 1
#define rcSq1BaseAddr1Low                        0x2300
#define rcSq1BaseAddr1High                       0x2304
#define rcSq2BaseAddr1Low                        0x2308
#define rcSq2BaseAddr1High                       0x230C
#define rcSq3BaseAddr1Low                        0x2310
#define rcSq3BaseAddr1High                       0x2314
#define rcSq4BaseAddr1Low                        0x2318
#define rcSq4BaseAddr1High                       0x231C
#define rcSq5BaseAddr1Low                        0x2320
#define rcSq5BaseAddr1High                       0x2324
#define rcSq6BaseAddr1Low                        0x2328
#define rcSq6BaseAddr1High                       0x232C
#define rcSq7BaseAddr1Low                        0x2330
#define rcSq7BaseAddr1High                       0x2334
#define rcSq8BaseAddr1Low                        0x2338
#define rcSq8BaseAddr1High                       0x233C
#define rmGetSq1BaseAddr1Low                     r32Nvme0[rcSq1BaseAddr1Low/4]
#define rmGetSq1BaseAddr1High                    r32Nvme0[rcSq1BaseAddr1High/4]
#define rmGetSq2BaseAddr1Low                     r32Nvme0[rcSq2BaseAddr1Low/4]
#define rmGetSq2BaseAddr1High                    r32Nvme0[rcSq2BaseAddr1High/4]
#define rmGetSq3BaseAddr1Low                     r32Nvme0[rcSq3BaseAddr1Low/4]
#define rmGetSq3BaseAddr1High                    r32Nvme0[rcSq3BaseAddr1High/4]
#define rmGetSq4BaseAddr1Low                     r32Nvme0[rcSq4BaseAddr1Low/4]
#define rmGetSq4BaseAddr1High                    r32Nvme0[rcSq4BaseAddr1High/4]
#define rmGetSq5BaseAddr1Low                     r32Nvme0[rcSq5BaseAddr1Low/4]
#define rmGetSq5BaseAddr1High                    r32Nvme0[rcSq5BaseAddr1High/4]
#define rmGetSq6BaseAddr1Low                     r32Nvme0[rcSq6BaseAddr1Low/4]
#define rmGetSq6BaseAddr1High                    r32Nvme0[rcSq6BaseAddr1High/4]
#define rmGetSq7BaseAddr1Low                     r32Nvme0[rcSq7BaseAddr1Low/4]
#define rmGetSq7BaseAddr1High                    r32Nvme0[rcSq7BaseAddr1High/4]
#define rmGetSq8BaseAddr1Low                     r32Nvme0[rcSq8BaseAddr1Low/4]
#define rmGetSq8BaseAddr1High                    r32Nvme0[rcSq8BaseAddr1High/4]

#define rcCq1BaseAddr1Low                        0x2340
#define rcCq1BaseAddr1High                       0x2344
#define rcCq2BaseAddr1Low                        0x2348
#define rcCq2BaseAddr1High                       0x234C
#define rcCq3BaseAddr1Low                        0x2350
#define rcCq3BaseAddr1High                       0x2354
#define rcCq4BaseAddr1Low                        0x2358
#define rcCq4BaseAddr1High                       0x235C
#define rcCq5BaseAddr1Low                        0x2360
#define rcCq5BaseAddr1High                       0x2364
#define rcCq6BaseAddr1Low                        0x2368
#define rcCq6BaseAddr1High                       0x236C
#define rcCq7BaseAddr1Low                        0x2370
#define rcCq7BaseAddr1High                       0x2374
#define rcCq8BaseAddr1Low                        0x2378
#define rcCq8BaseAddr1High                       0x237C
#define rmGetCq1BaseAddr1Low                     r32Nvme0[rcCq1BaseAddr1Low/4]
#define rmGetCq1BaseAddr1High                    r32Nvme0[rcCq1BaseAddr1High/4]
#define rmGetCq2BaseAddr1Low                     r32Nvme0[rcCq2BaseAddr1Low/4]
#define rmGetCq2BaseAddr1High                    r32Nvme0[rcCq2BaseAddr1High/4]
#define rmGetCq3BaseAddr1Low                     r32Nvme0[rcCq3BaseAddr1Low/4]
#define rmGetCq3BaseAddr1High                    r32Nvme0[rcCq3BaseAddr1High/4]
#define rmGetCq4BaseAddr1Low                     r32Nvme0[rcCq4BaseAddr1Low/4]
#define rmGetCq4BaseAddr1High                    r32Nvme0[rcCq4BaseAddr1High/4]
#define rmGetCq5BaseAddr1Low                     r32Nvme0[rcCq5BaseAddr1Low/4]
#define rmGetCq5BaseAddr1High                    r32Nvme0[rcCq5BaseAddr1High/4]
#define rmGetCq6BaseAddr1Low                     r32Nvme0[rcCq6BaseAddr1Low/4]
#define rmGetCq6BaseAddr1High                    r32Nvme0[rcCq6BaseAddr1High/4]
#define rmGetCq7BaseAddr1Low                     r32Nvme0[rcCq7BaseAddr1Low/4]
#define rmGetCq7BaseAddr1High                    r32Nvme0[rcCq7BaseAddr1High/4]
#define rmGetCq8BaseAddr1Low                     r32Nvme0[rcCq8BaseAddr1Low/4]
#define rmGetCq8BaseAddr1High                    r32Nvme0[rcCq8BaseAddr1High/4]

// Nvme Register @ 0x5101_0000
// UNEXDmaStat 0~7 (RW1C)
#define rcNvmeUnexDmaCtrl0                       0x1120
#define rmDisDmaEngine(x)                        (r32Nvme1[rcNvmeUnexDmaCtrl0+(4*x)]=0)

#define rcNvmeUnexDmaStat0                       0x112C
#define rmGetDmaStatus(x)                        (r32Nvme1[(rcNvmeUnexDmaStat0/4)+(4*x)])
#define rmClrDmaStatus(x)                        (r32Nvme1[(rcNvmeUnexDmaStat0/4)+(4*x)]=0xFFFFFFFF)
#define rmClrDma0Status                          (r32Nvme1[(rcNvmeUnexDmaStat0/4)]=0xFFFFFFFF)

#define rcNvmeUnexDmaCtrl1                       0x1130

#define rcNvmeUnexDmaStat1                       0x113C
#define rmClrDma1Status                          (r32Nvme1[rcNvmeUnexDmaStat1/4]=0xFFFFFFFF)
#define rcNvmeUnexDmaCtrl2                       0x1140

#define rcNvmeUnexDmaStat2                       0x114C
#define rmClrDma2Status                          (r32Nvme1[rcNvmeUnexDmaStat2/4]=0xFFFFFFFF)
#define rcNvmeUnexDmaCtrl3                       0x1150

#define rcNvmeUnexDmaStat3                       0x115C
#define rmClrDma3Status                          (r32Nvme1[rcNvmeUnexDmaStat3/4]=0xFFFFFFFF)
#define rcNvmeUnexDmaCtrl4                       0x1160

#define rcNvmeUnexDmaStat4                       0x116C
#define rmClrDma4Status                          (r32Nvme1[rcNvmeUnexDmaStat4/4]=0xFFFFFFFF)

#define rcNvmeUnexDmaCtrl5                       0x1170

#define rcNvmeUnexDmaStat5                       0x117C
#define rmClrDma5Status                          (r32Nvme1[rcNvmeUnexDmaStat5/4]=0xFFFFFFFF)

#define rcNvmeUnexDmaCtrl6                       0x1180

#define rcNvmeUnexDmaStat6                       0x118C
#define rmClrDma6Status                          (r32Nvme1[rcNvmeUnexDmaStat6/4]=0xFFFFFFFF)

#define rcNvmeUnexDmaCtrl7                       0x1190

#define rcNvmeUnexDmaStat7                       0x119C
#define rmClrDma7Status                          (r32Nvme1[rcNvmeUnexDmaStat7/4]=0xFFFFFFFF)

// test code-s
#define rmChkDma0Busy                            (r32Nvme1[rcNvmeUnexDmaStat0/4]&c32Bit9)
#define rmChkDma1Busy                            (r32Nvme1[rcNvmeUnexDmaStat1/4]&c32Bit9)
#define rmChkDma2Busy                            (r32Nvme1[rcNvmeUnexDmaStat2/4]&c32Bit9)
#define rmChkDma3Busy                            (r32Nvme1[rcNvmeUnexDmaStat3/4]&c32Bit9)
#define rmChkDma4Busy                            (r32Nvme1[rcNvmeUnexDmaStat4/4]&c32Bit9)
#define rmChkDma5Busy                            (r32Nvme1[rcNvmeUnexDmaStat5/4]&c32Bit9)
// test code-e

#define rcNvmeUnexDmaDescIndex                   0x11A0
#define rcNvmeUnexDmaDescData                    0x11A4
#define rcNvmeUnexFwRqWaterMark                  0x11A8
// #define rmSetWaterMark                           (r32Nvme1[rcNvmeUnexFwRqWaterMark/4]=0x00000000)
#define rmSetWaterMark                           (r32Nvme1[rcNvmeUnexFwRqWaterMark/4]=0x0000FFFF)

#define rcNvmeUnexFwRqStat                       0x11AC
#define rmChkFwRqEmpty                           (rNvme1[rcNvmeUnexFwRqStat+2]&cBit0)

#define rcNvmeUnexFwCqStat                       0x11B0
#define rmChkFwCqFull                            (rNvme1[rcNvmeUnexFwCqStat+2]&cBit1)
#define rmChkFwCqEmpty                           (rNvme1[rcNvmeUnexFwCqStat+2]&cBit0)
#define rmGetFwCqCnt                             (r16Nvme1[rcNvmeUnexFwCqStat/2])

#define rcNvmeUnexFwCqRsp                        0x11B8
#define rmSetFwCqRspDw(x)                        (r32Nvme1[rcNvmeUnexFwCqRsp/4]=x)

#define rcBridgeCtrl0                            0x2000
#define rmE2eEn                                  (rNvme1[rcBridgeCtrl0]|=cBit2)
#define rmBgRstEn                                (rNvme1[rcBridgeCtrl0]|=cBit3)
#define rmBgRstOff                               (rNvme1[rcBridgeCtrl0]&=(~cBit3))
#define rmNvmeRstEn                              (rNvme1[rcBridgeCtrl0]|=(cBit3|cBit4))
#define rmNvmeRstOff                             (rNvme1[rcBridgeCtrl0]&=(~(cBit3|cBit4)))
#define rmEnAesMixRW                             (rNvme1[rcBridgeCtrl0]|=cBit5)    // Read and write cmds can trig at the same time when enable
// AES
#define rmNvmeTsbReadPreCREn                     (rNvme1[rcBridgeCtrl0]|=cBit7)

#define rmSetLbaBuffDis                          (r16Nvme1[rcBridgeCtrl0/2]|=c16Bit13)

#define rmEnAnotherQueue                         (r16Nvme1[rcBridgeCtrl0/2]|=c16Bit14)    // 0:Use original trigger Queue(1 trigger queue),
// 1:enable another Queue for schedule engine(2
// Queues)
#define rmDisNvmeIpArb                           (rNvme1[rcBridgeCtrl0+3]=0x00)    // Nvme DMA disable Nvme IP arbitration, local dma will
// request arbitor by buffer status

#define rcBridgeCtrl1                            0x2004
#define rmPopNextCmd                             {(rNvme1[rcBridgeCtrl1]=cBit1);(rmResetWdtTimer);}
#define rmChkCmdRdy                              (rNvme1[rcBridgeCtrl1]&cBit0)    // FW request queue

#define rmChkRwCmdIn                             (rmChkCmdRdy&&rmNvmeSqId&&((rmNvmeOpCode==cNvmeCmdWrite)||(rmNvmeOpCode==cNvmeCmdRead)))

#define rmChkFlushWriteEmpty                     (r16Nvme1[rcBridgeCtrl1/2]&c16Bit8)
#define rmChkFlushReadEmpty                      (r16Nvme1[rcBridgeCtrl1/2]&c16Bit9)

#define rmChkBridgeAxiRwFlushBsy                 (rNvme1[rcBridgeCtrl1+1]&0x07)

#define rcBridgeCtrl2                            0x2008
#define rmDmaGating(x)                           (rNvme1[rcBridgeCtrl2+3]=x)

#define rcGateEngine                             0x200B
#define rmSwOneNvmeEngine                        (rNvme1[rcGateEngine]|=cBit7)
#define rmSrOneNvmeEngine                        (rNvme1[rcGateEngine]|=cBit1)
#define rmSwTwoNvmeEngine                        (rNvme1[rcGateEngine]&=(~cBit7))
#define rmSrTwoNvmeEngine                        (rNvme1[rcGateEngine]&=(~cBit1))

#define rcPrdEngineMap                           0x200C
#define rmSetEngineMap(x)                        (rNvme1[rcPrdEngineMap+1]=x)
#define rmChkEngineMap                           rNvme1[rcPrdEngineMap]

#define rcTsbSt0Addr                             0x2010
#define rcTsbEnD0Addr                            0x2012
#define rcTsbSt1Addr                             0x2014
#define rcTsbEnD1Addr                            0x2016
#define rcTsbSt2Addr                             0x2018
#define rcTsbEnD2Addr                            0x201A

#define rcDramST0Addr                            0x201C
#define rcDramEND0Addr                           0x2020
#define rcDramST1Addr                            0x2024
#define rcDramEND1Addr                           0x2028
#define rcDramST2Addr                            0x202C
#define rcDramEND2Addr                           0x2030

#define rmSetTsbWrap0NvmeS(x)                    (r16Nvme1[rcTsbSt0Addr/2]=x)
#define rmSetTsbWrap0NvmeE(x)                    (r16Nvme1[rcTsbEnD0Addr/2]=x)

#define rmSetTsbWrap1NvmeS(x)                    (r16Nvme1[rcTsbSt1Addr/2]=x)
#define rmSetTsbWrap1NvmeE(x)                    (r16Nvme1[rcTsbEnD1Addr/2]=x)

#define rmSetTsbWrap2NvmeS(x)                    (r16Nvme1[rcTsbSt2Addr/2]=x)
#define rmSetTsbWrap2NvmeE(x)                    (r16Nvme1[rcTsbEnD2Addr/2]=x)

#define rmSetBvciWrap0NvmeS(x)                   (r32Nvme1[rcDramST0Addr/4]=x)
#define rmSetBvciWrap0NvmeE(x)                   (r32Nvme1[rcDramEND0Addr/4]=x)
#define rmSetBvciWrap1NvmeS(x)                   (r32Nvme1[rcDramST1Addr/4]=x)
#define rmSetBvciWrap1NvmeE(x)                   (r32Nvme1[rcDramEND1Addr/4]=x)
#define rmSetBvciWrap2NvmeS(x)                   (r32Nvme1[rcDramST2Addr/4]=x)
#define rmSetBvciWrap2NvmeE(x)                   (r32Nvme1[rcDramEND2Addr/4]=x)

#define rcEngineDpp0                             0x2034    // h/w change offset in SVN_V727
#define rmWaitWDpp                               (!(rNvme1[rcEngineDpp0]&cBit6))    // bit6 for write
#define rmWaitRDpp                               (!(rNvme1[rcEngineDpp0]&(~cBit6)))    // bit7 for priority
#define rmClrWDpp                                (rNvme1[rcEngineDpp0]=cBit6)
#define rmClrRDpp                                (rNvme1[rcEngineDpp0]=(~cBit6))

#define rmChkDpp                                 rNvme1[rcEngineDpp0]
#define rmChkDps                                 rNvme1[rcEngineDpp0+1]

#define rmClrDpp(x)                              (rNvme1[rcEngineDpp0]=(0x1<<x))
#define rmClrDppAll                              (rNvme1[rcEngineDpp0]=0xFF)

#define rmClrDps(x)                              (rNvme1[rcEngineDpp0+1]=(0x1<<x)
#define rmClrDpsAll                              (rNvme1[rcEngineDpp0+1]=0xFF)

#define rcFshTrigHostEnLowDw                     0x2038
#define rcFshTrigHostEnHiDw                      0x203C    // h/w change offset in SVN_V727
#define rmSetPrdOfFlashTrigHost(PrdIdx)\
    (PrdIdx<32)?(r32Nvme1[rcFshTrigHostEnLowDw]|=\
                     (1<<PrdIdx)):(r32Nvme1[rcFshTrigHostEnHiDw]|=(1<<(PrdIdx-32)))
#define rmChkPrdOfFlashTrigHost(PrdIdx)\
    (PrdIdx<32)?(r32Nvme1[rcFshTrigHostEnLowDw]&\
                 (1<<PrdIdx)):(r32Nvme1[rcFshTrigHostEnHiDw]&(1<<(PrdIdx-32)))
#define rmClrPrdOfFlashTrigHost(PrdIdx)\
    (PrdIdx<32)?(r32Nvme1[rcFshTrigHostEnLowDw]&=\
                     (~(1<<PrdIdx))):(r32Nvme1[rcFshTrigHostEnHiDw]&=(~(1<<(PrdIdx-32))))

#define rcFwRqCmd0                               0x2040
#define rcFwRqCmd1                               0x2044
#define rcFwRqCmd2                               0x2048
#define rcFwRqCmd3                               0x204c
#define rcFwRqCmd4                               0x2050
#define rcFwRqCmd5                               0x2054
#define rcFwRqCmd6                               0x2058
#define rcFwRqCmd7                               0x205C
#define rcFwRqCmd8                               0x2060
#define rcFwRqCmd9                               0x2064
#define rcFwRqCmd10                              0x2068
#define rcFwRqCmd11                              0x206C
#define rcFwRqCmd12                              0x2070
#define rcFwRqCmd13                              0x2074
#define rcFwRqCmd14                              0x2078
#define rcFwRqCmd15                              0x207C

#define rmNvmeOpCode                             rNvme1[rcFwRqCmd0]
#define rmNvmeSgl                                (rNvme1[rcFwRqCmd0+1]&0xC0)
#define rmNvmeCid                                r16Nvme1[(rcFwRqCmd0/2)+1]
#define rmNvmeNsId                               r32Nvme1[rcFwRqCmd1/4]

#define rmNvmeCqId                               r16Nvme1[rcFwRqCmd2/2]
#define rmNvmeSqId                               r16Nvme1[(rcFwRqCmd2/2)+1]

#define rmNvmeMptrLow                            r32Nvme1[rcFwRqCmd4/4]
#define rmNvmeMptrHigh                           r32Nvme1[rcFwRqCmd5/4]
#define rmNvmePrp1Low                            r32Nvme1[rcFwRqCmd6/4]
#define rmNvmePrp1High                           r32Nvme1[rcFwRqCmd7/4]
#define rmNvmePrp2Low                            r32Nvme1[rcFwRqCmd8/4]
#define rmNvmePrp2High                           r32Nvme1[rcFwRqCmd9/4]

#define rmNvmeCmdDw10                            r32Nvme1[rcFwRqCmd10/4]

// For Delete IO SQ
#define rmNvmeDeleteqQid                         r16Nvme1[rcFwRqCmd10/2]

// For Create IO Queu
#define rmNvmeCreateqCmd10                       r32Nvme1[rcFwRqCmd10/4]
#define rmNvmeCreateqCmd11                       r32Nvme1[rcFwRqCmd11/4]

#define rmNvmeCreateqPc                          (rNvme1[rcFwRqCmd11]&cBit0)    // /Oakgate(conformance 5)
#define rmNvmeCreateqIen                         (rNvme1[rcFwRqCmd11]&cBit1)

#define rmNvmeCreateqQid                         (r16Nvme1[rcFwRqCmd10/2])
#define rmNvmeCreateqQsize                       (r16Nvme1[(rcFwRqCmd10/2)+1])
#define rmNvmeCreateqQprio                       (rNvme1[rcFwRqCmd11]&(cBit1|cBit2))
#define rmNvmeCreateqCqid                        (r16Nvme1[(rcFwRqCmd11/2)+1])
#define rmNvmeCreateqQiv                         (r16Nvme1[(rcFwRqCmd11/2)+1])

// For Identify
#define rmNvmeCntid                              (r16Nvme1[(rcFwRqCmd10/2)+1])

// For Get Log Command Use
#define rmNvmeLid                                rNvme1[rcFwRqCmd10]
#define rmNvmeLsp                                (rNvme1[rcFwRqCmd10+1]&0x0F)
#define rmNvmeGetLogNumDw                        ((r16Nvme1[(rcFwRqCmd10/2)+1]|(r16Nvme1[rcFwRqCmd11/2]<<16))+1)
#define rmNvmeGetLogNumDwOverflowChk             (r16Nvme1[(rcFwRqCmd10/2)+1]|(r16Nvme1[rcFwRqCmd11/2]<<16))
#define rmRetainAsyncEvent                       (r16Nvme1[rcFwRqCmd10/2]&c16Bit15)
#define rmLogPageOffsetLower                     (r32Nvme1[rcFwRqCmd12/4])
#define rmLogPageOffsetUpper                     (r32Nvme1[rcFwRqCmd13/4])

// For Abort Cmd Use
#define rmNvmeAbortSqId                          r16Nvme1[rcFwRqCmd10/2]
#define rmNvmeAbortCid                           r16Nvme1[(rcFwRqCmd10/2)+1]

// For Firmware Image Download
#define rmNvmeFwImageDlNumDw                     (r32Nvme1[rcFwRqCmd10/4]+1)
#define rmNvmeFwImageDlOffset                    r32Nvme1[rcFwRqCmd11/4]

// For Firmware Commit
#define rmNvmeFwCommitAction                     ((r32Nvme1[rcFwRqCmd10/4]&0x0038)>>3)
#define rmNvmeFwCommitFwSlot                     (r32Nvme1[rcFwRqCmd10/4]&0x07)

// For NvmeFormat
#define rmNvmeFormatLbaf                         (rNvme1[rcFwRqCmd10]&0x0F)    // LBA Format
#define rmNvmeFormatMs                           ((rNvme1[rcFwRqCmd10]&0x10)>>4)    // Metadata Settings
#define rmNvmeFormatPi                           ((rNvme1[rcFwRqCmd10]&0xE0)>>5)    // Protection Information
#define rmNvmeFormatPil                          (rNvme1[rcFwRqCmd10+1]&0x01)    // Protection Information Location
#define rmNvmeFormatSes                          ((rNvme1[rcFwRqCmd10+1]&0x0E)>>1)    // Secure Erase Settings

// For Write Uncorrectable Command
#define rmNvmeWriteUncSlbaLow                    r32Nvme1[rcFwRqCmd10/4]    // Starting LBA L
#define rmNvmeWriteUncSlbaHigh                   r32Nvme1[rcFwRqCmd11/4]    // Starting LBA H
#define rmNvmeWriteUncNlb                        (r16Nvme1[rcFwRqCmd12/2]+1)    // Number of Logical Blocks(0's based value)
#define rmNvmeFwCommitDebugMode                  ((r32Nvme1[rcFwRqCmd10/4]&0xFFFF0000)>>16)

// For Write Zeros Command
#define rmNvmeWriteZerosSLbaLow                  r32Nvme1[rcFwRqCmd10/4]    // Starting LBA L
#define rmNvmeWriteZerosSLbaHigh                 r32Nvme1[rcFwRqCmd11/4]    // Starting LBA H
#define rmNvmeWriteZerosLr                       (r32Nvme1[rcFwRqCmd12/4]&c32Bit31)
#define rmNvmeWriteZerosFua                      (r32Nvme1[rcFwRqCmd12/4]&c32Bit30)
#define rmNvmeWriteZerosPrInfo                   (r32Nvme1[rcFwRqCmd12/4]&0x3C000000)
#define rmNvmeWriteZerosDeac                     (r32Nvme1[rcFwRqCmd12/4]&c32Bit25)
#define rmNvmeWriteZerosNlb                      ((r32Nvme1[rcFwRqCmd12/4]&0x0000FFFF)+1)    // Number of Logical Blocks(0's based value)

// For Dataset Management Command
#define rmNvmeTrimRangeCnt                       (rNvme1[rcFwRqCmd10]+1)    // 0's based value
#define rmNvmeAttributeIdr                       (rNvme1[rcFwRqCmd11]&cBit0)    // Bit0: Integral Dataset for Read
#define rmNvmeAttributeIdw                       (rNvme1[rcFwRqCmd11]&cBit1)    // Bit1: Integral Dataset for Write
#define rmNvmeAttributeAd                        (rNvme1[rcFwRqCmd11]&cBit2)    // Bit2: Deallocate(Trim)

// For Get/Set Feature Command Use
#define rmNvmeHmbEnable                          (r32Nvme1[rcFwRqCmd11/4]&c32Bit0)
#define rmNvmeHmbMemReturn                       (r32Nvme1[rcFwRqCmd11/4]&c32Bit1)

#define rmNvmeSv                                 (rNvme1[rcFwRqCmd10+3]&cBit7)
#define rmNvmeCmdDw11                            r32Nvme1[rcFwRqCmd11/4]

#define rmNvmeNcqr                               ((r32Nvme1[rcFwRqCmd11/4]&0xFFFF0000)>>16)
#define rmNvmeNsqr                               (r32Nvme1[rcFwRqCmd11/4]&0xFFFF)
#define rmNvmePmWithWh                           (rNvme1[rcFwRqCmd11])
#define rmNvmePowerState                         (rNvme1[rcFwRqCmd11]&0x1F)
#define rmNvmeErrRecoveryDulbe                   ((r32Nvme1[rcFwRqCmd11/4]&0x00010000)>>16)
#define rmNvmeErrRecoveryTler                    (r32Nvme1[rcFwRqCmd11/4]&0x0000FFFF)

#define rmNvmeTempThresSel                       ((r32Nvme1[rcFwRqCmd11/4]>>16)&0x0F)
#define rmNvmeTempThresType                      ((r32Nvme1[rcFwRqCmd11/4]>>20)&0x03)
#define rmNvmeTempThres                          (r32Nvme1[rcFwRqCmd11/4]&0xFFFF)

#define rmNvmeFid                                rNvme1[rcFwRqCmd10]
#define rmNvmeSel                                (rNvme1[rcFwRqCmd10+1]&0x07)
#define rmNvmeCns                                rNvme1[rcFwRqCmd10]
#define rmNvmeLbaLow                             r32Nvme1[rcFwRqCmd10/4]
#define rmNvmeVenderLength                       r32Nvme1[rcFwRqCmd10/4]

// For Device Self-Test Use
#define rmNvmeStc                                (rNvme1[rcFwRqCmd10]&0x0F)

#define rmNvmeVenderMptrLength                   r32Nvme1[rcFwRqCmd11/4]
#define rmNvmeLbaHigh                            r32Nvme1[rcFwRqCmd11/4]
#define rmNvmeNlb                                ((r32Nvme1[rcFwRqCmd12/4]&0x0000FFFF)+1)    // Zero base
#define rmNvmeFua                                (r32Nvme1[rcFwRqCmd12/4]&c32Bit30)

// For Security Send/Receive
#define rmNvmeSecNssf                            rNvme1[rcFwRqCmd10]    // Nvme Security Specific Field
#define rmNvmeSecSpsp                            (rNvme1[rcFwRqCmd10+2]<<8|rNvme1[rcFwRqCmd10+1])    // SP Specific
#define rmNvmeSecSecp                            rNvme1[rcFwRqCmd10+3]    // Security Protocol
#define rmNvmeSecAl                              r32Nvme1[rcFwRqCmd11/4]    // Allocation Length // INC512=0 means receive data in increments of
// one byte
#define rmNvmeSecTl                              r32Nvme1[rcFwRqCmd11/4]    // Transfer Length

// For APST
#define rmNvmeApstEn                             (r32Nvme1[rcFwRqCmd11/4]&0x01)

// Set Feature "AsyncEvent"
#define rmNvmeAsyncEventValidBits                (r32Nvme1[rcFwRqCmd11/4]&0x7FF)

// Set Feature "Temperature Threshold"
#define rmNvmeFeatTemperatureThres               r32Nvme1[rcFwRqCmd11/4]
// Set Feature "Number of Queues"
#define rmNvmeFeatNumQueueNsqr                   r16Nvme1[rcFwRqCmd11/2]
#define rmNvmeFeatNumQueueNcqr                   r16Nvme1[(rcFwRqCmd11/2)+2]    // ???
// Set Feature "Arbitration"
#define rmNvmeFeatAbitration                     r32Nvme1[rcFwRqCmd11/4]
// Set Feature "Interrupt Coalescing"
#define rmNvmeFeatIntCoalescing                  r32Nvme1[rcFwRqCmd11/4]
// Set Feature "Interrupt Vectors Configuration"
#define rmNvmeFeatIntVecCfg                      r32Nvme1[rcFwRqCmd11/4]
#define rmNvmeFeatIntVecCfgIv                    r16Nvme1[rcFwRqCmd11/2]
// Set Feature "Volatile Write Cache"
#define rmNvmeFeatIntWriteCache                  r32Nvme1[rcFwRqCmd11/4]
// Set Feature "Intel DITT Light and Heavey Throttling Temperature"
#define rmNvmeFeatHctmLight                      r16Nvme1[(rcFwRqCmd11/2)+1]
#define rmNvmeFeatHctmHeavy                      r16Nvme1[(rcFwRqCmd11/2)]

// For LBA Range Type
#define rmNvmeLbaRangeNumDw                      ((rNvme1[rcFwRqCmd11]&0x3F)+1)    // 0's based value

// For Namespace Attachment/Management
#define rmNvmeSelect                             (rNvme1[rcFwRqCmd10]&0x0F)

// For Non-Operational Power State Config
#define rmNvmeNonOpPwrStateConfig                (rNvme1[rcFwRqCmd11]&0x01)

// For Software Progress Maker
#define rmNvmeSwProgressMaker                    rNvme1[rcFwRqCmd11]

// #if (OEM==DELL)    // 20181010_Jesse_01, Add for Dell spec "ENG0013785_A01"
#if _ENABLE_SCP_PLP
#define rmNvmeScpEn                              (r32Nvme1[rcFwRqCmd11/4]&0x01)
#endif
// #endif

// For Sanitize
#define rmNvmeSanitizeDw10                       (r32Nvme1[rcFwRqCmd10/4])
#define rmNvmeSanitizeAction                     (rNvme1[rcFwRqCmd10]&0x7)
#define rmNvmeSanitizeAuse                       (rNvme1[rcFwRqCmd10]&cBit3)
#define rmNvmeSanitizeOwrPass                    (rNvme1[rcFwRqCmd10]>>4)
#define rmNvmeSanitizeOipbp                      (rNvme1[rcFwRqCmd10+1]&cBit0)
#define rmNvmeSanitizeNoDeallo                   (rNvme1[rcFwRqCmd10+1]&cBit1)
#define rmNvmeSanitizeOvrPat                     (r32Nvme1[rcFwRqCmd11/4])

// For Directive
#define rmNvmeDirectiveNumDw                     (r32Nvme1[rcFwRqCmd10/4])
#define rmNvmeDspec                              (r16Nvme1[(rcFwRqCmd11/2)+1])
#define rmNvmeDtype                              (rNvme1[rcFwRqCmd11+1])
#define rmNvmeDoper                              (rNvme1[rcFwRqCmd11])

#define rmNvmeSubOpcode                          rNvme1[rcFwRqCmd12]
// #define rmNvmeMicronSubOpcode                  rNvme1[rcFwRqCmd12+1]

// For LiteonVU
#define rmNVmeLiteonVscFunctionCode              (rNvme1[rcFwRqCmd12])
#define rmNVmeLiteonVscModeCode                  (rNvme1[rcFwRqCmd12+1])
#define rmNVmeLiteonVscHeaderFlag                (rNvme1[rcFwRqCmd14])

#define rmNvmeMicronCmdClass                     rNvme1[rcFwRqCmd12+1]
#define rmNvmeMicronCmdCode                      rNvme1[rcFwRqCmd12+2]

#define rmNvmeSubCmdParam0                       g32CmdPara0    // r32Nvme1[rcFwRqCmd12/4]
#define rmNvmeSubCmdParam1                       g32CmdPara1    // r32Nvme1[rcFwRqCmd13/4]
#define rmNvmeSubCmdParam2                       g32CmdPara2    // r32Nvme1[rcFwRqCmd14/4]
#define rmNvmeSubCmdParam3                       g32CmdPara3    // r32Nvme1[rcFwRqCmd15/4]

#define rmVndrFBlock                             (rmNvmeSubCmdParam1&0xFFFF)
#define rmVndrFPage                              ((rmNvmeSubCmdParam1>>16)&0xFFFF)
#define rmVndrCh                                 ((rmNvmeSubCmdParam2&0x00FF)&0x0F)
#define rmVndrCe                                 (((rmNvmeSubCmdParam2&0x00FF)>>4)&0x0F)
#define rmVndrDie                                ((rmNvmeSubCmdParam2>>24)&0x00FF)
#define rmVndrPlane                              ((rmNvmeSubCmdParam2>>8)&0x00FF)
#define rmVndr2kChunk                            ((rmNvmeSubCmdParam2>>16)&0x00FF)
#define rmVndrRwOpt                              ((rmNvmeSubCmdParam0>>8)&0x00FF)

#define rmVndrEnScrambler                        (rmVndrRwOpt&cBit0)
#define rmVndrDisEcc                             (rmVndrRwOpt&cBit1)
#define rmVndrForce1Plane                        (rmVndrRwOpt&cBit2)
#define rmVndrNoSpare                            (rmVndrRwOpt&cBit3)
#define rmVndrEnMaxEcc                           (rmVndrRwOpt&cBit4)
#define rmVndrNoReadData                         (rmVndrRwOpt&cBit5)
#define rmVndrDisDiffAddr                        (rmVndrRwOpt&cBit6)
#define rmVndrEnSlcMode                          (rmVndrRwOpt&cBit7)

// For IntelAPI
#define rmNVMeSecurityBlobId                     rNvme1[rcFwRqCmd12+1]
#define rmNVMeSecurityEnDecryptFlag              rNvme1[rcFwRqCmd12+2]
#define rmNVMeSecurityKeyNum                     rNvme1[rcFwRqCmd12+3]
#define rmNVMeSecurityOffset                     r32Nvme1[rcFwRqCmd13/4]    // offset/bytes

// #define rmNVMeMicronCmdClass                     rNVMe1[rcFwRQCmd12+1]
// #define rmNVMeMicronCmdCode                      rNVMe1[rcFwRQCmd12+2]
#define rmNvmeCdw12                              r32Nvme1[rcFwRqCmd12/4]
#define rmNvmeCdw13                              r32Nvme1[rcFwRqCmd13/4]
#define rmNvmePprwCycleLength                    r32Nvme1[rcFwRqCmd13/4]
#define rmNvmeCdw14                              r32Nvme1[rcFwRqCmd14/4]
#define rmNvmePprwCycleStartByte                 r32Nvme1[rcFwRqCmd14/4]
#define rmNvmeCdw15                              r32Nvme1[rcFwRqCmd15/4]

#define rcPrdDoneFlag0                           0x2080
#define rcPrdDoneFlag1                           0x2084
#define rmChkPrdDoneFlag0(x)                     (r32Nvme1[rcPrdDoneFlag0/4]&(0x01<<x))
#define rmChkPrdDoneFlag1(x)                     (r32Nvme1[rcPrdDoneFlag1/4]&(0x01<<(x-32)))

#define rmClrPrdDoneFlag(x)                      ((x<32)?(r32Nvme1[rcPrdDoneFlag0/4]=(1<<x)):(r32Nvme1[rcPrdDoneFlag1/4]=(1<<(x-32))))
#define rmChkPrdDoneFlag(x)                      ((x<32)?(r32Nvme1[rcPrdDoneFlag0/4]&(1<<x)):(r32Nvme1[rcPrdDoneFlag1/4]&(1<<(x-32))))
#define rmClrPrdDoneFlag0(x)                     (r32Nvme1[rcPrdDoneFlag0/4]=(1<<x))
#define rmClrPrdDoneFlag1(x)                     (r32Nvme1[rcPrdDoneFlag1/4]=(1<<(x-32)))

#define rcNvmeBiasAdd                            0x208C
#define rmSetNvmeBias(x)                         (r16Nvme1[rcNvmeBiasAdd/2]=x)

#define rcNvmeMisc0                              0x2090
#define rmNvmeGetPs                              (r32Nvme1[rcNvmeMisc0/4]>>27)
#define rmNvmeCrcFailInfo                        (rNvme1[rcNvmeMisc0]&0x07)    /* Get CRC fail engine information */
#define rmClrNvmeCrcFail(Engine)                 (rNvme1[rcNvmeMisc0]&=(Engine))

#define rcInvalidPcStatus                        0x2094
#define rmChkPrpListErr                          (rNvme1[rcInvalidPcStatus]&0x07)
#define rmClrAllPrpListErr                       {rNvme1[rcInvalidPcStatus]|=0x07;rNvme1[rcInvalidPcStatus]&=0xF8;}
#define rmClrOnePrpListErr(x)                    {rNvme1[rcInvalidPcStatus]|=cbBitTab[x];rNvme1[rcInvalidPcStatus]&=(~cbBitTab[x]);}

#define rcPrdPdtr0                               0x20C8
#define rcPrdPdtr1                               0x20CC
#define rmPrdPdtr0                               r32Nvme1[rcPrdPdtr0/4]
#define rmPrdPdtr0ChkBusy(Index)                 (rmPrdPdtr0&(0x1<<Index))
#define rmPrdPdtr1                               r32Nvme1[rcPrdPdtr1/4]
#define rmPrdPdtr1ChkBusy(Index)                 (rmPrdPdtr1&(0x1<<(Index-32)))

#define rcUncFlag0                               0x20D0
#define rcUncFlag1                               0x20D4

#define rmNvmeSetUncFlag(x)                      ((x<32)?(r32Nvme1[rcUncFlag0/4]|=(0x1<<x)):(r32Nvme1[rcUncFlag1/4]|=(0x1<<(x-32))))
#define rmNvmeSetUncFlag0(x)                     (r32Nvme1[rcUncFlag0/4]|=(0x1<<x))
#define rmNvmeSetUncFlag1(x)                     (r32Nvme1[rcUncFlag1/4]|=(0x1<<(x-32)))

#define rmNvmeClrUncFlag(x)                      ((x<32)?(r32Nvme1[rcUncFlag0/4]&=~(0x1<<x)):(r32Nvme1[rcUncFlag1/4]&=~(0x1<<(x-32))))
#define rmNvmeClrUncFlag0(x)                     (r32Nvme1[rcUncFlag0/4]&=~(0x1<<x))
#define rmNvmeClrUncFlag1(x)                     (r32Nvme1[rcUncFlag1/4]&=~(0x1<<(x-32)))

#define rcUncRpdReady0                           0x20D8
#define rcUncRpdReady1                           0x20DC

#define rmNmveClrUncPrdReady(x)                  ((x<32)?(r32Nvme1[rcUncRpdReady0/4]=(0x1<<x)):(r32Nvme1[rcUncRpdReady1/4]=(0x1<<(x-32))))
#define rmNmveClrUncPrdReady0(x)                 (r32Nvme1[rcUncRpdReady0/4]=(0x1<<x))
#define rmNmveClrUncPrdReady1(x)                 (r32Nvme1[rcUncRpdReady1/4]=(0x1<<(x-32)))

#define rcDppDpsFifoStatus                       0x20E0

#define rmGetNvmeIdle                            rNvme1[rcDppDpsFifoStatus+3]
#define rmChkSqEmpty                             (rNvme1[rcDppDpsFifoStatus+1]&cBit7)
#define rmCurrentEngine                          (rNvme1[rcDppDpsFifoStatus+1]&0x07)
#define rmCurrentPrd                             (rNvme1[rcDppDpsFifoStatus]&0x3F)
#define rmChkDpsDppFifoNotEmpty                  (rNvme1[rcDppDpsFifoStatus+1]&cBit3)
#define rmPopNextValue                           (rNvme1[rcDppDpsFifoStatus+2]=cBit0)
#define rmChkDppBit                              (rNvme1[rcDppDpsFifoStatus+1]&cBit4)
#define rmChkUncBit                              (rNvme1[rcDppDpsFifoStatus+1]&cBit5)
#define rmChkCqDbMatch                           (rNvme1[rcDppDpsFifoStatus+1]&cBit6)

#define rmGetPrdRestSctrCnt(x)                   (r32NvmePrd[x][5])

#define rcFshTHostRst0                           0x2100
#define rcFshTHostRst1                           0x2104

#define rmFshTHostReset0                         (r32Nvme1[rcFshTHostRst0/4]=0xFFFFFFFF)
#define rmFshTHostReset1                         (r32Nvme1[rcFshTHostRst1/4]=0xFFFFFFFF)

#define rcStopFetchIoCmd                         0x2284
#define rmSetAllQueStopFetchCmd                  (r32Nvme1[rcStopFetchIoCmd/4]=0x0001FFFE)
#define rmClrAllQueStopFetchCmd                  (r32Nvme1[rcStopFetchIoCmd/4]=0x00000000)

#define rcCrcFailLbaLo                           0x2474
#define rmGetCrcFailLbaLo(x)                     r32Nvme1[(rcCrcFailLbaLo+x*8)/4]

#define rcCrcFailLbaHi                           0x2478
#define rmGetCrcFailLbaHi(x)                     r32Nvme1[(rcCrcFailLbaHi+x*8)/4]

#define rcFailCrc                                0x2494
#define rmGetFailCrc(x)                          r32Nvme1[(rcFailCrc+x*4)/4]

// HMB register
#define rcConfigHmbDma                           0x0040
#define rmSetFixGroup1MSize                      rNvmeHmb[rcConfigHmbDma]=(rNvmeHmb[rcConfigHmbDma]&0xF0)
#define rmSetFixGroup2MSize                      rNvmeHmb[rcConfigHmbDma]=((rNvmeHmb[rcConfigHmbDma]&0xF0)|0x01)
#define rmSetFixGroup4MSize                      rNvmeHmb[rcConfigHmbDma]=((rNvmeHmb[rcConfigHmbDma]&0xF0)|0x02)
#define rmSetFixGroup8MSize                      rNvmeHmb[rcConfigHmbDma]=((rNvmeHmb[rcConfigHmbDma]&0xF0)|0x03)
#define rmSetFixGroupLLSize                      rNvmeHmb[rcConfigHmbDma]=((rNvmeHmb[rcConfigHmbDma]&0xF0)|0x04)
#define rmSetFixGroupSize(x)                     rNvmeHmb[rcConfigHmbDma]=((rNvmeHmb[rcConfigHmbDma]&0xF0)|x)
#define rmChkFixGroupSize                        (rNvmeHmb[rcConfigHmbDma]&0x0F)

#define rcConfigArbWeightSel                     0x0044
#define rmSetHmbArbWeightSel(x)\
    (r16NvmeHmb[(rcConfigArbWeightSel/2)+\
                1]=((r16NvmeHmb[(rcConfigArbWeightSel/2)+1]&0xFF0F)|(x<<4)))
#define rmSetNvmeArbWeightSel(x)                 (r16NvmeHmb[(rcConfigArbWeightSel/2)+1]=((r16NvmeHmb[(rcConfigArbWeightSel/2)+1]&0xFFF0)|x))

#define rcAXIPipePathSel                         0x0048

#define rcHmbSoftReset                           0x007C
#define rmSetHmbSoftReset                        (rNvmeHmb[rcHmbSoftReset]|=cBit0)
#define rmClrHmbSoftReset                        (rNvmeHmb[rcHmbSoftReset]&=~cBit0)

#define rcHmbPrdDw0                              0x0080
#define rcHmbPrdDw1                              0x0084
#define rcHmbPrdDw2                              0x0088
#define rcHmbPrdDw3                              0x008C
#define rcHmbPrdDw4                              0x0090
#define rcHmbPrdDw5                              0x0094
#define rcHmbPrdDw6                              0x0098
#define rcHmbPrdDw7                              0x009C
#define rcHmbPrdDw8                              0x00A0
#define rcHmbPrdDw9                              0x00A4
#define rcHmbPrdDw10                             0x00A8

#define rmHmbPrdDw0                              r32NvmeHmb[rcHmbPrdDw0/4]
#define rmHmbPrdDw1                              r32NvmeHmb[rcHmbPrdDw1/4]
#define rmHmbPrdDw2                              r32NvmeHmb[rcHmbPrdDw2/4]
#define rmHmbPrdDw3                              r32NvmeHmb[rcHmbPrdDw3/4]
#define rmHmbPrdDw4                              r32NvmeHmb[rcHmbPrdDw4/4]
#define rmHmbPrdDw5                              r32NvmeHmb[rcHmbPrdDw5/4]
#define rmHmbPrdDw6                              r32NvmeHmb[rcHmbPrdDw6/4]
#define rmHmbPrdDw7                              r32NvmeHmb[rcHmbPrdDw7/4]
#define rmHmbPrdDw8                              r32NvmeHmb[rcHmbPrdDw8/4]
#define rmHmbPrdDw9                              r32NvmeHmb[rcHmbPrdDw9/4]
#define rmHmbPrdDw10                             r32NvmeHmb[rcHmbPrdDw10/4]

#define rcHmbPrdQueCtrl                          0x00AC
#define rmPushHmbPrd                             r32NvmeHmb[rcHmbPrdQueCtrl/4]|=c32Bit31
#define rmChkHmbPrdFull                          (r32NvmeHmb[rcHmbPrdQueCtrl/4]&cBit1)
#define rmChkHmbPrdEmpty                         (r32NvmeHmb[rcHmbPrdQueCtrl/4]&cBit0)

#define rcHmbPrdQueStatus                        0x00B0
#define rmHmbPrdQueHeadIdx                       (rNvmeHmb[rcHmbPrdQueStatus+1]&0x1F)
#define rmHmbPrdQueTrigIdx                       (rNvmeHmb[rcHmbPrdQueStatus+2]&0x1F)

#define rcHmbE2eCrcChkInt                        0x00B4
#define rmHmbE2eCrcErr                           (rNvmeHmb[rcHmbE2eCrcChkInt]&cBit0)

#define rcCrc32ErrFlag                           0x00C0
#define rmCrc32ErrFlag                           r32NvmeHmb[rcCrc32ErrFlag/4]

#define rcCrc32ChkFifoOut                        0x00C8
#define rmCrc32ChkFifoOut                        r32NvmeHmb[rcCrc32ChkFifoOut/4]

#define rcCrc32ChkFifoGet                        0x00CC
#define rmRstCrc32PutAddr                        r32NvmeHmb[rcCrc32ChkFifoGet/4]|=c32Bit31
#define rmCrc32CurrCnt                           ((r32NvmeHmb[rcCrc32ChkFifoGet/4]>>8)&0x1F)
#define rmChkCrc32GetAddr                        (r32NvmeHmb[rcCrc32ChkFifoGet/4]&0x1F)
#define rmSetCrc32GetAddr(x)                     (r32NvmeHmb[rcCrc32ChkFifoGet/4]=((r32NvmeHmb[rcCrc32ChkFifoGet/4]&0xFFFFFFE0)|((x)&0x1F)))

#define rcDescEntryNumFixGroup                   0x0100
#define rmDescEntryNumFixGroup(x)                rNvmeHmb[rcDescEntryNumFixGroup+x*4]

#define rcFixGroupTotalNumber                    0x0200
#define rmSetTotalFixGroupNumber(x)\
    (r32NvmeHmb[rcFixGroupTotalNumber/\
                4]=((r32NvmeHmb[rcFixGroupTotalNumber/4]&0x00FFFFFF)|((x&0xFF)<<24)))
#define rmSetTotalEntryNumber(x)\
    (r32NvmeHmb[rcFixGroupTotalNumber/\
                4]=((r32NvmeHmb[rcFixGroupTotalNumber/4]&0xFFFF0000)|(x&0xFFFF)))

#define rcARBSoftReset                           0x03FC
#define rmSetARBSoftReset                        (rNvmeHmb[rcARBSoftReset]|=cBit0)
#define rmClrARBSoftReset                        (rNvmeHmb[rcARBSoftReset]&=~cBit0)

#define rcHmbDescEntryAddrLow                    0x1000
#define rmHmbDescEntryAddrLow(x)                 r32NvmeHmb[rcHmbDescEntryAddrLow/4+x*4]

#define rcHmbDescEntryAddrHigh                   0x1004
#define rmHmbDescEntryAddrHigh(x)                r32NvmeHmb[rcHmbDescEntryAddrHigh/4+x*4]

#define rcHmbDescEntrySize                       0x1008
#define rmHmbDescEntrySize(x)                    r32NvmeHmb[rcHmbDescEntrySize/4+x*4]

#endif    // ifndef __REG_NVME_H__







