







#define cKpNormal                                0
#define cKpLoopback                              1

// APHY
#define cAddrAphyLane0                           0x2000
#define cAddrAphyLane1                           0x2100
#define cAddrAphyLane2                           0x2200
#define cAddrAphyLane3                           0x2300

#define cAddrSmb                                 0x0080

#define cDatSetSmbSqPd                           0x0020
#define cAddrSqPd                                0x002E
#define cSmbSqPd                                 0x0020
#define cDatClrSqPd                              0x0000

#define cDatSetSmbKd                             0x000F
#define cDatSetKd                                0x0000

#define cDatSetSmbKp                             0x00FF
#define cDatSetKp                                0x000E
#define cDatSetKpLpbk                            0x0006

#define cDatSetSmbKi                             0x00FF
#define cDatSetKi                                0x0000

#define cAddrPllPd                               0x0000
#define cSmbPllPd                                0x0001

#define cAddrPdWPll                              0x0014
#define cSmbPdWPll                               0x0080

// DPHY
#define cAddrDphyLane0                           0x3C00
#define cAddrDphyLane1                           0x3D00
#define cAddrDphyLane2                           0x3E00
#define cAddrDphyLane3                           0x3F00

// Lane drop issue-Start
#define cAddrErrRpt                              0x0087
#define cEnDecErrRpt                             0x10
#define cEnOvfRpt                                0x20
#define cEnUdfRpt                                0x40
#define cEnRdErrRpt                              0x80
// Lane drop issue- End

#define cAddrDphyParityBit                       0xFF
#define cDatSetDphyParityBit                     0x0001
#define cDatClrDphyParityBit                     0x0000

#define cAddrGen12DfEqc                          0xE9
#define cDatSetGen12DfEqc                        0x000C

#define cAddrFomEcCntLenH                        0x00FB    // 2263
#define cDatSetFomEcCntLenH                      0x000f    // 2263

#define cAddrEcCntLenH                           0x00C6
#define cDatSetEcCntLenH                         0x001F

#define cAddrEcCntLenL                           0x00C7
#define cDatSetEcCntLenL                         0x00FF

#define cAddrChkPtFom                            0x00D1
#define cAddrChkPtCtle                           0x00D2
#define cAddrChkPtDfe                            0x00D3
#define cAddrChkPtOffd                           0x00D4
// #define cAddrRxtVth                              0x00D6
#define cAddrRxtOffvVthL                         0x00D6
#define cAddrRxRonCtrl                           0x0099

// #define cDatSetChkPtFom                          0x0031 //0x0021  //remove, 2263
// #define cDatSetChkPtCtle                         0x006A //0x003C  //remove, 2263
// #define cDatSetChkPtDfe                          0x00B9 //0x0064  //remove 2263
// #define cDatSetChkPtOffd                         0x00BE //0x0071  //remove, 2263
// #define cDatSetRxtVth                            0x0008  //2263
#define cDatSetRxtOffvVthL                       0x0020    // 2263

#define cAddrEqrIni                              0x00D7
#define cAddrEqrIniMag                           0x00D9
#define cAddrEqcIni                              0x00DA
#define cAddrEqcDir                              0x00DB
#define cAddrEqcMag                              0x00DC
#define cAddrOffdIni                             0x00E6
#define cAddrOffdIniMag                          0x00E8
#define cAddrTap1Ini                             0x00DD
#define cAddrTap1IniDir                          0x00DE    // 2263
#define cAddrTap1IniMag                          0x00DF
#define cAddrTap2Ini                             0x00E0
#define cAddrTap2IniDir                          0x00E1
#define cAddrTap2IniMag                          0x00E2
#define cAddrTap3Ini                             0x00E3
#define cAddrTap3IniDir                          0x00E4    // 2263
#define cAddrTap3IniMag                          0x00E5
#define cAddrCnt400NsGen3RxRdyH                  0x0046
#define cAddrCnt400NsGen3RxRdyL                  0x000E
#define cDatSetEqcDir                            0x0000    // 0x0001, 2263
#define cAddrVgat                                0x00F3    // 2263
#define cAddrVga                                 0x00F0    // 2263
#define cDatSetVgat                              0x0000    // 2263
#define cDatSetVga                               0x00E0    // 2263

#define cDatSetEqrIni                            0x0006    // 0x0000, 2263
#define cDatSetEqrIniMag                         0x0000    // 0x0000, 2263
#define cDatSetEqcIni                            0x000B    // 0x000C, 2263
#define cDatSetEqcMag                            0x0002    // 0x0004, 2263
#define cDatSetOffdIni                           0x00FC    // 0x00FC, 2263
#define cDatSetOffdIniMag                        0x0000    // 0x0000, 2263
#define cDatSetTap1Ini                           0x0020    // 0x0020, 2263
#define cDatSetTap1IniDir                        0x0001    // 2263
#define cDatSetTap1IniMag                        0x0008    // 0x0007, 2263
#define cDatSetTap2Ini                           0x0010    // 0x0010, 2263
#define cDatSetTap2IniDir                        0x0001    // 0x0001, 2263
#define cDatSetTap2IniMag                        0x0008    // 0x0007, 2263
#define cDatSetTap3Ini                           0x0010    // 0x0010, 2263
#define cDatSetTap3IniDir                        0x0001    // 2263
#define cDatSetTap3IniMag                        0x0008    // 0x0007, 2263

// THreshold = 8
#define cAddrOffset0A                            0x000A
#define cDatSetOffset0A                          0x0013    // (Sam) 1B->13 Skip hand-shke  fifo condition with DPHY
// purpose, Apollo, fix speed change fail, it is related to CSDD-2519 and CSSD-2484
// after L1 w/o EIOS, link will try to do speed change, 0x13 can build link back but it may low to gen1
// actually, once 2519/2484 fix, there won't be spee change issue

#define cAddrLaneRevOpt                          0x0010
#define cDatSetLaneRevOpt                        0x0010

#define cAddrEieosDetAlways                      0x003D
#define cDatSetAddrEieosDetAlways                0x08

#define cAddrDpatchCtl                           0x003C
#define cDatSetEnSpdChgDisRx                     0x0008
#define cDatSetEnFilterCom                       0x0004
#define cDatSetEnFshEiosClrBlkAlignN             0x0002
#define cDatSetEnEiosClrBlkAlignN                0x0001

#define cAddrDpatch1Ctl                          0x003D
#define cDatSetCheckBlockAlign                   0x0008
#define cDatSetCheckFollowAlignContRo            0x0004

#define cDatSetCnt400NsGen3RxRdyH                0x0003
#define cDatSetCnt400NsGen3RxRdyL                0x00FF

#define cAddrIsa                                 0x0038
#define cAddrTxpd                                0x0014
#define cAddrRxpd                                0x0029
#define cAddrTbcOff                              0x0013
#define cSmbTxpd                                 0x0040
#define cSmbRxpd                                 0x0040
#define cSmbTbcOff                               0x0010
#define cDatSetTxpd                              0x0040
#define cDatSetRxpd                              0x0040
#define cDatSetTbcOff                            0x0010

#define cAddrD0DisLane                           0x008F
#define cDatSetD0DisLane                         0x0001
#define cDatSetAllTimeDisLane                    0x0008

#define cAddrAb                                  0x00AB
#define cDatSetAb                                0x001E

#define cAddrTbcOffIssueOp12En                   0x0084
#define cDatClrTbcOffIssueOp2En                  0x0010
#define cDatSetTbcOffIssueOp2En                  0x0000

#define cDatClrTbcOffIssueOp1En                  0x0008
#define cDatSetTbcOffIssueOp1En                  0x0000

#define cAddrC0                                  0x00C0
#define cDatSetC0                                0x00C0
#define cDatClrC0                                0x0000

#define cAddrF5                                  0x00F5
#define cDatSetF5                                0x0001
#define cDatClrF5                                0x0000

// Global DPHY
#define cAddrG3NormalTxSwing                     0x11    // GD
#define cAddrG2NormalTxSwing                     0x7B    // GD
#define cAddrG1NormalTxSwing                     0x77    // GD
#define cAddrDm0Manual                           0x93    // A
#define cAddrDm0                                 0x13    // A
#define cAddrDm1Manual                           0x95    // A
#define cAddrDm1                                 0x15    // A
#define cAddrDm2Manual                           0x94    // A
#define cAddrDm2                                 0x14    // A
#define cAddrKdManual                            0xAB    // A
#define cAddrKd                                  0x2B    // A
#define cAddrKpManual                            0xAC    // A
#define cAddrKp                                  0x2C    // A
#define cAddrKiManual                            0xAD    // A
#define cAddrKi                                  0x2D    // A
#define cAddrEqrManual                           0xA4    // A
#define cAddrEqr                                 0x24    // A
#define cAddrEqcManual                           0xAB    // A
#define cAddrEqc                                 0x2B    // A
#define cAddrTap1Manual                          0xA7    // A
#define cAddrTap1                                0x27    // A
#define cAddrTap2Manual                          0xA8    // A
#define cAddrTap2                                0x28    // A
#define cAddrTap3Manual                          0xA9    // A
#define cAddrTap3                                0x29    // A
#define cAddrNormalModeMax                       0x00    // D
#define cAddrSrisSrnsMax                         0x01    // D
#define cAddrSqaOffset                           0x04    // D
#define cAddrPllVvco                             0x06    // GA
#define cAddrOffc                                0x25    // (Terence) for BER test signal quality with long channel
#define cAddrKis                                 0x35
#define cAddrOffv                                0x26
#define cAddrSqa                                 0x2E
#define cAddrRxOffc                              0x25
#define cAddrRt                                  0x0A
#define cSmbSqa                                  0x1F
#define cSmbOffv                                 0x3F
#define cSmbTap2                                 0x1F
#define cSmbRxOffc                               0x7F
#define cSmbRt                                   0x3F

#define cAddrDeemphManualGen1Dm0Ini              0x18

#define cAddrGen3Dm0Ini                          0x26
#define cAddrGen3Dm1Ini                          0x27
#define cAddrGen3Dm2Ini                          0x28
#define cAddrGen3KdIni                           0x02
#define cAddrGen3KpIni                           0x03
#define cAddrGen3KiIni                           0x05
#define cAddrGen3EqrIni                          0xD7
#define cAddrGen3EqcIni                          0xDA
#define cAddrGen3Tap1Ini                         0xDD
#define cAddrGen3Tap2Ini                         0xE0
#define cAddrGen3Tap3Ini                         0xE3

#define cAddrGen2Dm0Ini                          0x23
#define cAddrGen2Dm1Ini                          0x24
#define cAddrGen2Dm2Ini                          0x25
#define cAddrGen2KdIni                           0x48
#define cAddrGen2KpIni                           0x49
#define cAddrGen2KiIni                           0x4A
#define cAddrGen2EqrIni                          0xEA
#define cAddrGen2EqcIni                          0xE9
#define cAddrGen2Tap1Ini                         0xEC
#define cAddrGen2Tap2Ini                         0xED
#define cAddrGen2Tap3Ini                         0xEE

#define cAddrGen1Dm0Ini                          0x18
#define cAddrGen1Dm1Ini                          0x19
#define cAddrGen1Dm2Ini                          0x1A
#define cAddrGen1KdIni                           0x43
#define cAddrGen1KpIni                           0x44
#define cAddrGen1KiIni                           0x45
#define cAddrGen1EqrIni                          0xF7
#define cAddrGen1EqcIni                          0xF6
#define cAddrGen1Tap1Ini                         0xF8
#define cAddrGen1Tap2Ini                         0xF9
#define cAddrGen1Tap3Ini                         0xFA

#define ADDR_EN_LOG_CODE_ERR_DPHYREG             0x00B
#define DAT_SET_EN_LOG_CODE_ERR_DPHYREG          0x0001

// #if 0 //======================================================== w/o CSSD-3222 fix
//
// #define ADDR_CNT_REFRDY_H                      0x00B1 //[7:2]
// #define ADDR_CNT_REFRDY_M                      0x00B0 //[7:0]
// #define ADDR_CNT_REFRDY_L                      0x00AF //[3:0]
//
// // 120us = 0xBB8 * 40ns
// #define DAT_SET_120usec_REFRDY_H               (0x0000 << 2)
// #define DAT_SET_120usec_REFRDY_M               0x00BB
// #define DAT_SET_120usec_REFRDY_L               0x0008
//
// // 15us = 0x177 * 40ns
// #define DAT_SET_15usec_REFRDY_H                (0x0000 << 2)
// #define DAT_SET_15usec_REFRDY_M                0x0017
// #define DAT_SET_15usec_REFRDY_L                0x0007
//
// #else //======================================================== w/i CSSD-3222 fix
#define cAddrCntRefRdyH                          0x00AF    // [3:0]  //CSSD-3222
#define cAddrCntRefRdyM                          0x00B0    // [7:0]
#define cAddrCntRefRdyL                          0x00B1    // [7:2]

// #if 0 // 5.7ms (org) 120us = 0xBB8 * 40ns
// #define DAT_SET_120usec_REFRDY_H               0x0008          //CSSD-3222
// #define DAT_SET_120usec_REFRDY_M               0x00BB
// #define DAT_SET_120usec_REFRDY_L               (0x0000 << 2)
// #else // 1ms (new)
#define cDatSet120usecRefRdyH                    0x0001
#define cDatSet120usecRefRdyM                    0x0086
#define cDatSet120usecRefRdyL                    (0x0028<<2)
// #endif

// 1ms = 0x61A8 * 40ns, (0x61A8<<2)
#define cDatSet1msecRefRdyH                      0x0001
#define cDatSet1msecRefRdyM                      0x0086
#define cDatSet1msecRefRdyL                      (0x0028<<2)

// 30us = 0x2EE * 40ns
#define cDatSet30usecRefRdyH                     0x0000
#define cDatSet30usecRefRdyM                     0x000B
#define cDatSet30usecRefRdyL                     (0x002E<<2)

// 15us = 0x177 * 40ns
#define cDatSet15usecRefRdyH                     0x0000    // CSSD-3222
#define cDatSet15usecRefRdyM                     0x0005
#define cDatSet15usecRefRdyL                     (0x0037<<2)

// #endif

#define cSmbG3NormalTxSwing                      0x1F    // GD
#define cSmbG2NormalTxSwing                      0x1F    // GD
#define cSmbG1NormalTxSwing                      0x1F    // GD
#define cSmbDm0Manual                            0x0F    // A
#define cSmbDm0                                  0x0F    // A
#define cSmbDm1Manual                            0x1F    // A
#define cSmbDm1                                  0x1F    // A
#define cSmbDm2Manual                            0x1F    // A
#define cSmbDm2                                  0x1F    // A
#define cSmbKdManual                             0x0F    // A
#define cSmbKd                                   0x0F    // A
#define cSmbKpManual                             0xFF    // A
#define cSmbKp                                   0xFF    // A
#define cSmbKiManual                             0xFF    // A
#define cSmbKi                                   0xFF    // A
#define cSmbEqrManual                            0x1F    // A
#define cSmbEqr                                  0x1F    // A
#define cSmbEqcManual                            0xF0    // A
#define cSmbEqc                                  0xF0    // A
#define cSmbTap1Manual                           0x3F    // A
#define cSmbTap1                                 0x3F    // A
#define cSmbTap2Manual                           0x1F    // A
#define cSmbTap2                                 0x1F    // A
#define cSmbTap3Manual                           0x1F    // A
#define cSmbTap3                                 0x1F    // A
#define cSmbNormalModeMax                        0x0F    // D
#define cSmbSrisSrnsMax                          0x0F    // D
#define cSmbSqaOffset                            0x3E    // D
#define cSmbPllVvco                              0x3C    // GA
#define cSmbOffcLimt                             0x10
#define cSmbGen3Dm0                              0x0F
#define cSmbGen3Dm1                              0x1F
#define cSmbGen3Dm2                              0x1F
#define cSmbGen3Kd                               0x0F
#define cSmbGen3Kp                               0xFF
#define cSmbGen3Ki                               0xFF
#define cSmbGen3Eqr                              0x1F
#define cSmbGen3Eqc                              0x0F
#define cSmbGen3Tap1                             0x3F
#define cSmbGen3Tap2                             0x1F
#define cSmbGen3Tap3                             0x1F

#define cSmbGen2Dm0                              0x0F
#define cSmbGen2Dm1                              0x1F
#define cSmbGen2Dm2                              0x1F
#define cSmbGen2Kd                               0x0F
#define cSmbGen2Kp                               0xFF
#define cSmbGen2Ki                               0xFF
#define cSmbGen2Eqr                              0x1F
#define cSmbGen2Eqc                              0x0F
#define cSmbGen2Tap1                             0x3F
#define cSmbGen2Tap2                             0x1F
#define cSmbGen2Tap3                             0x1F

#define cSmbGen1Dm0                              0x0F
#define cSmbGen1Dm1                              0x1F
#define cSmbGen1Dm2                              0x1F
#define cSmbGen1Kd                               0x0F
#define cSmbGen1Kp                               0xFF
#define cSmbGen1Ki                               0xFF
#define cSmbGen1Eqr                              0x1F
#define cSmbGen1Eqc                              0x0F
#define cSmbGen1Tap1                             0x3F
#define cSmbGen1Tap2                             0x1F
#define cSmbGen1Tap3                             0x1F







