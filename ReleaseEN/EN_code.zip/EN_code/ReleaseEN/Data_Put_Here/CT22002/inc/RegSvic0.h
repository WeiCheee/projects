







#ifndef __REG_SVIC0_H__
#define __REG_SVIC0_H__

// #include "inc/GlobVar0.h"

// VIC Vector Address
#define rmVic0VectAddr00                         r32Svic0[0x00/4]
#define rmVic0VectAddr01                         r32Svic0[0x04/4]
#define rmVic0VectAddr02                         r32Svic0[0x08/4]
#define rmVic0VectAddr03                         r32Svic0[0x0C/4]
#define rmVic0VectAddr04                         r32Svic0[0x10/4]
#define rmVic0VectAddr05                         r32Svic0[0x14/4]
#define rmVic0VectAddr06                         r32Svic0[0x18/4]
#define rmVic0VectAddr07                         r32Svic0[0x1C/4]
#define rmVic0VectAddr08                         r32Svic0[0x20/4]
#define rmVic0VectAddr09                         r32Svic0[0x24/4]
#define rmVic0VectAddr10                         r32Svic0[0x28/4]
#define rmVic0VectAddr11                         r32Svic0[0x2C/4]
#define rmVic0VectAddr12                         r32Svic0[0x30/4]
#define rmVic0VectAddr13                         r32Svic0[0x34/4]
#define rmVic0VectAddr14                         r32Svic0[0x38/4]
#define rmVic0VectAddr15                         r32Svic0[0x3C/4]
#define rmVic0VectAddr16                         r32Svic0[0x40/4]
#define rmVic0VectAddr17                         r32Svic0[0x44/4]
#define rmVic0VectAddr18                         r32Svic0[0x48/4]
#define rmVic0VectAddr19                         r32Svic0[0x4C/4]
#define rmVic0VectAddr20                         r32Svic0[0x50/4]
#define rmVic0VectAddr21                         r32Svic0[0x54/4]
#define rmVic0VectAddr22                         r32Svic0[0x58/4]
#define rmVic0VectAddr23                         r32Svic0[0x5C/4]
#define rmVic0VectAddr24                         r32Svic0[0x60/4]
#define rmVic0VectAddr25                         r32Svic0[0x64/4]
#define rmVic0VectAddr26                         r32Svic0[0x68/4]
#define rmVic0VectAddr27                         r32Svic0[0x6C/4]
#define rmVic0VectAddr28                         r32Svic0[0x70/4]
#define rmVic0VectAddr29                         r32Svic0[0x74/4]
#define rmVic0VectAddr30                         r32Svic0[0x78/4]
#define rmVic0VectAddr31                         r32Svic0[0x7C/4]

// Vector Priority Register 0
#define rmVic0Pri0                               r32Svic0[0x80/4]
#define rmVic0Int00Pri0                          (rmVic0Pri0=(rmVic0Pri0&0xFFFF_FFFC))
#define rmVic0Int00Pri1                          (rmVic0Pri0=(rmVic0Pri0&0xFFFF_FFFC)|0x00000001)
#define rmVic0Int00Pri2                          (rmVic0Pri0=(rmVic0Pri0&0xFFFF_FFFC)|0x00000002)
#define rmVic0Int00Pri3                          (rmVic0Pri0=(rmVic0Pri0|0x0000_0003))
#define rmVic0Int01Pri0                          (rmVic0Pri0=(rmVic0Pri0&0xFFFF_FFF3))
#define rmVic0Int01Pri1                          (rmVic0Pri0=(rmVic0Pri0&0xFFFF_FFF3)|0x00000004)
#define rmVic0Int01Pri2                          (rmVic0Pri0=(rmVic0Pri0&0xFFFF_FFF3)|0x00000008)
#define rmVic0Int01Pri3                          (rmVic0Pri0=(rmVic0Pri0|0x0000_000C))
#define rmVic0Int02Pri0                          (rmVic0Pri0=(rmVic0Pri0&0xFFFF_FFCF))
#define rmVic0Int02Pri1                          (rmVic0Pri0=(rmVic0Pri0&0xFFFF_FFCF)|0x00000010)
#define rmVic0Int02Pri2                          (rmVic0Pri0=(rmVic0Pri0&0xFFFF_FFCF)|0x00000020)
#define rmVic0Int02Pri3                          (rmVic0Pri0=(rmVic0Pri0|0x0000_0030))
#define rmVic0Int03Pri0                          (rmVic0Pri0=(rmVic0Pri0&0xFFFF_FF3F))
#define rmVic0Int03Pri1                          (rmVic0Pri0=(rmVic0Pri0&0xFFFF_FF3F)|0x00000040)
#define rmVic0Int03Pri2                          (rmVic0Pri0=(rmVic0Pri0&0xFFFF_FF3F)|0x00000080)
#define rmVic0Int03Pri3                          (rmVic0Pri0=(rmVic0Pri0|0x0000_0300))
#define rmVic0Int04Pri0                          (rmVic0Pri0=(rmVic0Pri0&0xFFFF_FCFF))
#define rmVic0Int04Pri1                          (rmVic0Pri0=(rmVic0Pri0&0xFFFF_FCFF)|0x00000100)
#define rmVic0Int04Pri2                          (rmVic0Pri0=(rmVic0Pri0&0xFFFF_FCFF)|0x00000200)
#define rmVic0Int04Pri3                          (rmVic0Pri0=(rmVic0Pri0|0x0000_0300))
#define rmVic0Int05Pri0                          (rmVic0Pri0=(rmVic0Pri0&0xFFFF_F3FF))
#define rmVic0Int05Pri1                          (rmVic0Pri0=(rmVic0Pri0&0xFFFF_F3FF)|0x00000400)
#define rmVic0Int05Pri2                          (rmVic0Pri0=(rmVic0Pri0&0xFFFF_F3FF)|0x00000800)
#define rmVic0Int05Pri3                          (rmVic0Pri0=(rmVic0Pri0|0x0000_0C00))
#define rmVic0Int06Pri0                          (rmVic0Pri0=(rmVic0Pri0&0xFFFF_CFFF))
#define rmVic0Int06Pri1                          (rmVic0Pri0=(rmVic0Pri0&0xFFFF_CFFF)|0x00001000)
#define rmVic0Int06Pri2                          (rmVic0Pri0=(rmVic0Pri0&0xFFFF_CFFF)|0x00002000)
#define rmVic0Int06Pri3                          (rmVic0Pri0=(rmVic0Pri0|0x0000_3000))
#define rmVic0Int07Pri0                          (rmVic0Pri0=(rmVic0Pri0&0xFFFF_3FFF))
#define rmVic0Int07Pri1                          (rmVic0Pri0=(rmVic0Pri0&0xFFFF_3FFF)|0x00004000)
#define rmVic0Int07Pri2                          (rmVic0Pri0=(rmVic0Pri0&0xFFFF_3FFF)|0x00008000)
#define rmVic0Int07Pri3                          (rmVic0Pri0=(rmVic0Pri0|0x0000_C000))
#define rmVic0Int08Pri0                          (rmVic0Pri0=(rmVic0Pri0&0xFFFC_FFFF))
#define rmVic0Int08Pri1                          (rmVic0Pri0=(rmVic0Pri0&0xFFFC_FFFF)|0x00010000)
#define rmVic0Int08Pri2                          (rmVic0Pri0=(rmVic0Pri0&0xFFFC_FFFF)|0x00020000)
#define rmVic0Int08Pri3                          (rmVic0Pri0=(rmVic0Pri0|0x0003_0000))
#define rmVic0Int09Pri0                          (rmVic0Pri0=(rmVic0Pri0&0xFFF3_FFFF))
#define rmVic0Int09Pri1                          (rmVic0Pri0=(rmVic0Pri0&0xFFF3_FFFF)|0x00040000)
#define rmVic0Int09Pri2                          (rmVic0Pri0=(rmVic0Pri0&0xFFF3_FFFF)|0x00080000)
#define rmVic0Int09Pri3                          (rmVic0Pri0=(rmVic0Pri0|0x000C_0000))
#define rmVic0Int10Pri0                          (rmVic0Pri0=(rmVic0Pri0&0xFFCF_FFFF))
#define rmVic0Int10Pri1                          (rmVic0Pri0=(rmVic0Pri0&0xFFCF_FFFF)|0x00100000)
#define rmVic0Int10Pri2                          (rmVic0Pri0=(rmVic0Pri0&0xFFCF_FFFF)|0x00200000)
#define rmVic0Int10Pri3                          (rmVic0Pri0=(rmVic0Pri0|0x0030_0000))
#define rmVic0Int11Pri0                          (rmVic0Pri0=(rmVic0Pri0&0xFF3F_FFFF))
#define rmVic0Int11Pri1                          (rmVic0Pri0=(rmVic0Pri0&0xFF3F_FFFF)|0x00400000)
#define rmVic0Int11Pri2                          (rmVic0Pri0=(rmVic0Pri0&0xFF3F_FFFF)|0x00800000)
#define rmVic0Int11Pri3                          (rmVic0Pri0=(rmVic0Pri0|0x00C0_0000))
#define rmVic0Int12Pri0                          (rmVic0Pri0=(rmVic0Pri0&0xFCFF_FFFF))
#define rmVic0Int12Pri1                          (rmVic0Pri0=(rmVic0Pri0&0xFCFF_FFFF)|0x01000000)
#define rmVic0Int12Pri2                          (rmVic0Pri0=(rmVic0Pri0&0xFCFF_FFFF)|0x02000000)
#define rmVic0Int12Pri3                          (rmVic0Pri0=(rmVic0Pri0|0x0300_0000))
#define rmVic0Int13Pri0                          (rmVic0Pri0=(rmVic0Pri0&0xF3FF_FFFF))
#define rmVic0Int13Pri1                          (rmVic0Pri0=(rmVic0Pri0&0xF3FF_FFFF)|0x04000000)
#define rmVic0Int13Pri2                          (rmVic0Pri0=(rmVic0Pri0&0xF3FF_FFFF)|0x08000000)
#define rmVic0Int13Pri3                          (rmVic0Pri0=(rmVic0Pri0|0x0C00_0000))
#define rmVic0Int14Pri0                          (rmVic0Pri0=(rmVic0Pri0&0xCFFF_FFFF))
#define rmVic0Int14Pri1                          (rmVic0Pri0=(rmVic0Pri0&0xCFFF_FFFF)|0x10000000)
#define rmVic0Int14Pri2                          (rmVic0Pri0=(rmVic0Pri0&0xCFFF_FFFF)|0x20000000)
#define rmVic0Int14Pri3                          (rmVic0Pri0=(rmVic0Pri0|0x3000_0000))
#define rmVic0Int15Pri0                          (rmVic0Pri0=(rmVic0Pri0&0x3FFF_FFFF))
#define rmVic0Int15Pri1                          (rmVic0Pri0=(rmVic0Pri0&0x3FFF_FFFF)|0x40000000)
#define rmVic0Int15Pri2                          (rmVic0Pri0=(rmVic0Pri0&0x3FFF_FFFF)|0x80000000)
#define rmVic0Int15Pri3                          (rmVic0Pri0=(rmVic0Pri0|0xC000_0000))

// Vector Priority Register 1
#define rmVic0Pri1                               r32Svic0[0x84/4]
#define rmVic0Int16Pri0                          (rmVic0Pri1=(rmVic0Pri1&0xFFFF_FFFC))
#define rmVic0Int16Pri1                          (rmVic0Pri1=(rmVic0Pri1&0xFFFF_FFFC)|0x0000_0001)
#define rmVic0Int16Pri2                          (rmVic0Pri1=(rmVic0Pri1&0xFFFF_FFFC)|0x0000_0002)
#define rmVic0Int16Pri3                          (rmVic0Pri1=(rmVic0Pri1|0x0000_0003))
#define rmVic0Int17Pri0                          (rmVic0Pri1=(rmVic0Pri1&0xFFFF_FFF3))
#define rmVic0Int17Pri1                          (rmVic0Pri1=(rmVic0Pri1&0xFFFF_FFF3)|0x0000_0004)
#define rmVic0Int17Pri2                          (rmVic0Pri1=(rmVic0Pri1&0xFFFF_FFF3)|0x0000_0008)
#define rmVic0Int17Pri3                          (rmVic0Pri1=(rmVic0Pri1|0x0000_000C))
#define rmVic0Int18Pri0                          (rmVic0Pri1=(rmVic0Pri1&0xFFFF_FFCF))
#define rmVic0Int18Pri1                          (rmVic0Pri1=(rmVic0Pri1&0xFFFF_FFCF)|0x0000_0010)
#define rmVic0Int18Pri2                          (rmVic0Pri1=(rmVic0Pri1&0xFFFF_FFCF)|0x0000_0020)
#define rmVic0Int18Pri3                          (rmVic0Pri1=(rmVic0Pri1|0x0000_0030))
#define rmVic0Int19Pri0                          (rmVic0Pri1=(rmVic0Pri1&0xFFFF_FF3F))
#define rmVic0Int19Pri1                          (rmVic0Pri1=(rmVic0Pri1&0xFFFF_FF3F)|0x0000_0040)
#define rmVic0Int19Pri2                          (rmVic0Pri1=(rmVic0Pri1&0xFFFF_FF3F)|0x0000_0080)
#define rmVic0Int19Pri3                          (rmVic0Pri1=(rmVic0Pri1|0x0000_0300))
#define rmVic0Int20Pri0                          (rmVic0Pri1=(rmVic0Pri1&0xFFFF_FCFF))
#define rmVic0Int20Pri1                          (rmVic0Pri1=(rmVic0Pri1&0xFFFF_FCFF)|0x0000_0100)
#define rmVic0Int20Pri2                          (rmVic0Pri1=(rmVic0Pri1&0xFFFF_FCFF)|0x0000_0200)
#define rmVic0Int20Pri3                          (rmVic0Pri1=(rmVic0Pri1|0x0000_0300))
#define rmVic0Int21Pri0                          (rmVic0Pri1=(rmVic0Pri1&0xFFFF_F3FF))
#define rmVic0Int21Pri1                          (rmVic0Pri1=(rmVic0Pri1&0xFFFF_F3FF)|0x0000_0400)
#define rmVic0Int21Pri2                          (rmVic0Pri1=(rmVic0Pri1&0xFFFF_F3FF)|0x0000_0800)
#define rmVic0Int21Pri3                          (rmVic0Pri1=(rmVic0Pri1|0x0000_0C00))
#define rmVic0Int22Pri0                          (rmVic0Pri1=(rmVic0Pri1&0xFFFF_CFFF))
#define rmVic0Int22Pri1                          (rmVic0Pri1=(rmVic0Pri1&0xFFFF_CFFF)|0x0000_1000)
#define rmVic0Int22Pri2                          (rmVic0Pri1=(rmVic0Pri1&0xFFFF_CFFF)|0x0000_2000)
#define rmVic0Int22Pri3                          (rmVic0Pri1=(rmVic0Pri1|0x0000_3000))
#define rmVic0Int23Pri0                          (rmVic0Pri1=(rmVic0Pri1&0xFFFF_3FFF))
#define rmVic0Int23Pri1                          (rmVic0Pri1=(rmVic0Pri1&0xFFFF_3FFF)|0x0000_4000)
#define rmVic0Int23Pri2                          (rmVic0Pri1=(rmVic0Pri1&0xFFFF_3FFF)|0x0000_8000)
#define rmVic0Int23Pri3                          (rmVic0Pri1=(rmVic0Pri1|0x0000_C000))
#define rmVic0Int24Pri0                          (rmVic0Pri1=(rmVic0Pri1&0xFFFC_FFFF))
#define rmVic0Int24Pri1                          (rmVic0Pri1=(rmVic0Pri1&0xFFFC_FFFF)|0x0001_0000)
#define rmVic0Int24Pri2                          (rmVic0Pri1=(rmVic0Pri1&0xFFFC_FFFF)|0x0002_0000)
#define rmVic0Int24Pri3                          (rmVic0Pri1=(rmVic0Pri1|0x0003_0000))
#define rmVic0Int25Pri0                          (rmVic0Pri1=(rmVic0Pri1&0xFFF3_FFFF))
#define rmVic0Int25Pri1                          (rmVic0Pri1=(rmVic0Pri1&0xFFF3_FFFF)|0x0004_0000)
#define rmVic0Int25Pri2                          (rmVic0Pri1=(rmVic0Pri1&0xFFF3_FFFF)|0x0008_0000)
#define rmVic0Int25Pri3                          (rmVic0Pri1=(rmVic0Pri1|0x000C_0000))
#define rmVic0Int26Pri0                          (rmVic0Pri1=(rmVic0Pri1&0xFFCF_FFFF))
#define rmVic0Int26Pri1                          (rmVic0Pri1=(rmVic0Pri1&0xFFCF_FFFF)|0x0010_0000)
#define rmVic0Int26Pri2                          (rmVic0Pri1=(rmVic0Pri1&0xFFCF_FFFF)|0x0020_0000)
#define rmVic0Int26Pri3                          (rmVic0Pri1=(rmVic0Pri1|0x0030_0000))
#define rmVic0Int27Pri0                          (rmVic0Pri1=(rmVic0Pri1&0xFF3F_FFFF))
#define rmVic0Int27Pri1                          (rmVic0Pri1=(rmVic0Pri1&0xFF3F_FFFF)|0x0040_0000)
#define rmVic0Int27Pri2                          (rmVic0Pri1=(rmVic0Pri1&0xFF3F_FFFF)|0x0080_0000)
#define rmVic0Int27Pri3                          (rmVic0Pri1=(rmVic0Pri1|0x00C0_0000))
#define rmVic0Int28Pri0                          (rmVic0Pri1=(rmVic0Pri1&0xFCFF_FFFF))
#define rmVic0Int28Pri1                          (rmVic0Pri1=(rmVic0Pri1&0xFCFF_FFFF)|0x0100_0000)
#define rmVic0Int28Pri2                          (rmVic0Pri1=(rmVic0Pri1&0xFCFF_FFFF)|0x0200_0000)
#define rmVic0Int28Pri3                          (rmVic0Pri1=(rmVic0Pri1|0x0300_0000))
#define rmVic0Int29Pri0                          (rmVic0Pri1=(rmVic0Pri1&0xF3FF_FFFF))
#define rmVic0Int29Pri1                          (rmVic0Pri1=(rmVic0Pri1&0xF3FF_FFFF)|0x0400_0000)
#define rmVic0Int29Pri2                          (rmVic0Pri1=(rmVic0Pri1&0xF3FF_FFFF)|0x0800_0000)
#define rmVic0Int29Pri3                          (rmVic0Pri1=(rmVic0Pri1|0x0C00_0000))
#define rmVic0Int30Pri0                          (rmVic0Pri1=(rmVic0Pri1&0xCFFF_FFFF))
#define rmVic0Int30Pri1                          (rmVic0Pri1=(rmVic0Pri1&0xCFFF_FFFF)|0x1000_0000)
#define rmVic0Int30Pri2                          (rmVic0Pri1=(rmVic0Pri1&0xCFFF_FFFF)|0x2000_0000)
#define rmVic0Int30Pri3                          (rmVic0Pri1=(rmVic0Pri1|0x3000_0000))
#define rmVic0Int31Pri0                          (rmVic0Pri1=(rmVic0Pri1&0x3FFF_FFFF))
#define rmVic0Int31Pri1                          (rmVic0Pri1=(rmVic0Pri1&0x3FFF_FFFF)|0x4000_0000)
#define rmVic0Int31Pri2                          (rmVic0Pri1=(rmVic0Pri1&0x3FFF_FFFF)|0x8000_0000)
#define rmVic0Int31Pri3                          (rmVic0Pri1=(rmVic0Pri1|0xC000_0000))

// FIQ Status Register
#define rmVic0FiqStatus                          r32Svic0[0x88/4]
// IRQ Status Register
#define rmVic0IrqStatus                          r32Svic0[0x8C/4]
// Raw Interrupt Status Register
#define rmVic0RawInt                             r32Svic0[0x90/4]
// Interrupt Select Register
#define rmVic0IntSel                             r32Svic0[0x94/4]
// Interrupt Source Mode
#define rmVic0IntMode                            r32Svic0[0x98/4]
// Interrupt Source Polarity
#define rmVic0IntPolarity                        r32Svic0[0x9C/4]
// Soft Interrupt Source
#define rmVic0SoftInt                            r32Svic0[0xA0/4]
// Clear Software Interrupt once ISR completed
#define rmVic0SoftIntClr(x)                      (r32Svic0[0xA0/4]=(r32Svic0[0xA0/4]&(~x)))
// Software Mask Register
#define rmVic0SoftMaskN                          r32Svic0[0xA4/4]
// Software Clear Interrupt
#define rmVic0IntClr                             r32Svic0[0xA8/4]
// Interrupt Enable Register
#define rmVic0IntEnable                          r32Svic0[0xAC/4]
#define rmGetVic0IntSrc                          rmVic0IntEnable
#define rmVic0EnInt(x)                           (rmVic0IntEnable|=(x))
#define rmVic0DisInt(x)                          (rmVic0IntEnable&=~(x))
// VIC Controller Enable
#define rmVic0GCtrl                              rSvic0[0xB0]
#define rmVic0Enable                             (rmVic0GCtrl=cBit0)
#define rmVic0Disable                            (rmVic0GCtrl=0)

// VIC Event Select
#define rmVic0EventSel                           r64Svic0[0xB8/8]
#define rmVic0EnEvent(x)                         (rmVic0EventSel|=(x))
#define rmVic0DisEvent(x)                        (rmVic0EventSel&=~(x))

// Vector Addr Register -
// Write any value to this register to clear current interrupt, this is necessary after ISR done
#define rmVic0Addr                               r32Svic0[0xF00/4]
#define rmVic0IrqClr                             rmVic0Addr=0x00000000

// Just for fake interrupt
#define rmClrFakeInt                             r32Svic0[0xFF0/4]

#endif    // ifndef __REG_SVIC_H__







