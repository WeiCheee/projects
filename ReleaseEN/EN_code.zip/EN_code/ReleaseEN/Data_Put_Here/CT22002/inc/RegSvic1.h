







#ifndef __REG_SVIC1_H__
#define __REG_SVIC1_H__

// #include "inc/GlobVar0.h"

// VIC Vector Address
#define rmVic1VectAddr00                         r32Svic1[0x00/4]
#define rmVic1VectAddr01                         r32Svic1[0x04/4]
#define rmVic1VectAddr02                         r32Svic1[0x08/4]
#define rmVic1VectAddr03                         r32Svic1[0x0C/4]
#define rmVic1VectAddr04                         r32Svic1[0x10/4]
#define rmVic1VectAddr05                         r32Svic1[0x14/4]
#define rmVic1VectAddr06                         r32Svic1[0x18/4]
#define rmVic1VectAddr07                         r32Svic1[0x1C/4]
#define rmVic1VectAddr08                         r32Svic1[0x20/4]
#define rmVic1VectAddr09                         r32Svic1[0x24/4]
#define rmVic1VectAddr10                         r32Svic1[0x28/4]
#define rmVic1VectAddr11                         r32Svic1[0x2C/4]
#define rmVic1VectAddr12                         r32Svic1[0x30/4]
#define rmVic1VectAddr13                         r32Svic1[0x34/4]
#define rmVic1VectAddr14                         r32Svic1[0x38/4]
#define rmVic1VectAddr15                         r32Svic1[0x3C/4]
#define rmVic1VectAddr16                         r32Svic1[0x40/4]
#define rmVic1VectAddr17                         r32Svic1[0x44/4]
#define rmVic1VectAddr18                         r32Svic1[0x48/4]
#define rmVic1VectAddr19                         r32Svic1[0x4C/4]
#define rmVic1VectAddr20                         r32Svic1[0x50/4]
#define rmVic1VectAddr21                         r32Svic1[0x54/4]
#define rmVic1VectAddr22                         r32Svic1[0x58/4]
#define rmVic1VectAddr23                         r32Svic1[0x5C/4]
#define rmVic1VectAddr24                         r32Svic1[0x60/4]
#define rmVic1VectAddr25                         r32Svic1[0x64/4]
#define rmVic1VectAddr26                         r32Svic1[0x68/4]
#define rmVic1VectAddr27                         r32Svic1[0x6C/4]
#define rmVic1VectAddr28                         r32Svic1[0x70/4]
#define rmVic1VectAddr29                         r32Svic1[0x74/4]
#define rmVic1VectAddr30                         r32Svic1[0x78/4]
#define rmVic1VectAddr31                         r32Svic1[0x7C/4]

// Vector Priority Register 0
#define rmVic1Pri0                               r32Svic1[0x80/4]
#define rmVic1Int00Pri0                          (rmVic1Pri0=(rmVic1Pri0&0xFFFF_FFFC))
#define rmVic1Int00Pri1                          (rmVic1Pri0=(rmVic1Pri0&0xFFFF_FFFC)|0x00000001)
#define rmVic1Int00Pri2                          (rmVic1Pri0=(rmVic1Pri0&0xFFFF_FFFC)|0x00000002)
#define rmVic1Int00Pri3                          (rmVic1Pri0=(rmVic1Pri0|0x0000_0003))
#define rmVic1Int01Pri0                          (rmVic1Pri0=(rmVic1Pri0&0xFFFF_FFF3))
#define rmVic1Int01Pri1                          (rmVic1Pri0=(rmVic1Pri0&0xFFFF_FFF3)|0x00000004)
#define rmVic1Int01Pri2                          (rmVic1Pri0=(rmVic1Pri0&0xFFFF_FFF3)|0x00000008)
#define rmVic1Int01Pri3                          (rmVic1Pri0=(rmVic1Pri0|0x0000_000C))
#define rmVic1Int02Pri0                          (rmVic1Pri0=(rmVic1Pri0&0xFFFF_FFCF))
#define rmVic1Int02Pri1                          (rmVic1Pri0=(rmVic1Pri0&0xFFFF_FFCF)|0x00000010)
#define rmVic1Int02Pri2                          (rmVic1Pri0=(rmVic1Pri0&0xFFFF_FFCF)|0x00000020)
#define rmVic1Int02Pri3                          (rmVic1Pri0=(rmVic1Pri0|0x0000_0030))
#define rmVic1Int03Pri0                          (rmVic1Pri0=(rmVic1Pri0&0xFFFF_FF3F))
#define rmVic1Int03Pri1                          (rmVic1Pri0=(rmVic1Pri0&0xFFFF_FF3F)|0x00000040)
#define rmVic1Int03Pri2                          (rmVic1Pri0=(rmVic1Pri0&0xFFFF_FF3F)|0x00000080)
#define rmVic1Int03Pri3                          (rmVic1Pri0=(rmVic1Pri0|0x0000_0300))
#define rmVic1Int04Pri0                          (rmVic1Pri0=(rmVic1Pri0&0xFFFF_FCFF))
#define rmVic1Int04Pri1                          (rmVic1Pri0=(rmVic1Pri0&0xFFFF_FCFF)|0x00000100)
#define rmVic1Int04Pri2                          (rmVic1Pri0=(rmVic1Pri0&0xFFFF_FCFF)|0x00000200)
#define rmVic1Int04Pri3                          (rmVic1Pri0=(rmVic1Pri0|0x0000_0300))
#define rmVic1Int05Pri0                          (rmVic1Pri0=(rmVic1Pri0&0xFFFF_F3FF))
#define rmVic1Int05Pri1                          (rmVic1Pri0=(rmVic1Pri0&0xFFFF_F3FF)|0x00000400)
#define rmVic1Int05Pri2                          (rmVic1Pri0=(rmVic1Pri0&0xFFFF_F3FF)|0x00000800)
#define rmVic1Int05Pri3                          (rmVic1Pri0=(rmVic1Pri0|0x0000_0C00))
#define rmVic1Int06Pri0                          (rmVic1Pri0=(rmVic1Pri0&0xFFFF_CFFF))
#define rmVic1Int06Pri1                          (rmVic1Pri0=(rmVic1Pri0&0xFFFF_CFFF)|0x00001000)
#define rmVic1Int06Pri2                          (rmVic1Pri0=(rmVic1Pri0&0xFFFF_CFFF)|0x00002000)
#define rmVic1Int06Pri3                          (rmVic1Pri0=(rmVic1Pri0|0x0000_3000))
#define rmVic1Int07Pri0                          (rmVic1Pri0=(rmVic1Pri0&0xFFFF_3FFF))
#define rmVic1Int07Pri1                          (rmVic1Pri0=(rmVic1Pri0&0xFFFF_3FFF)|0x00004000)
#define rmVic1Int07Pri2                          (rmVic1Pri0=(rmVic1Pri0&0xFFFF_3FFF)|0x00008000)
#define rmVic1Int07Pri3                          (rmVic1Pri0=(rmVic1Pri0|0x0000_C000))
#define rmVic1Int08Pri0                          (rmVic1Pri0=(rmVic1Pri0&0xFFFC_FFFF))
#define rmVic1Int08Pri1                          (rmVic1Pri0=(rmVic1Pri0&0xFFFC_FFFF)|0x00010000)
#define rmVic1Int08Pri2                          (rmVic1Pri0=(rmVic1Pri0&0xFFFC_FFFF)|0x00020000)
#define rmVic1Int08Pri3                          (rmVic1Pri0=(rmVic1Pri0|0x0003_0000))
#define rmVic1Int09Pri0                          (rmVic1Pri0=(rmVic1Pri0&0xFFF3_FFFF))
#define rmVic1Int09Pri1                          (rmVic1Pri0=(rmVic1Pri0&0xFFF3_FFFF)|0x00040000)
#define rmVic1Int09Pri2                          (rmVic1Pri0=(rmVic1Pri0&0xFFF3_FFFF)|0x00080000)
#define rmVic1Int09Pri3                          (rmVic1Pri0=(rmVic1Pri0|0x000C_0000))
#define rmVic1Int10Pri0                          (rmVic1Pri0=(rmVic1Pri0&0xFFCF_FFFF))
#define rmVic1Int10Pri1                          (rmVic1Pri0=(rmVic1Pri0&0xFFCF_FFFF)|0x00100000)
#define rmVic1Int10Pri2                          (rmVic1Pri0=(rmVic1Pri0&0xFFCF_FFFF)|0x00200000)
#define rmVic1Int10Pri3                          (rmVic1Pri0=(rmVic1Pri0|0x0030_0000))
#define rmVic1Int11Pri0                          (rmVic1Pri0=(rmVic1Pri0&0xFF3F_FFFF))
#define rmVic1Int11Pri1                          (rmVic1Pri0=(rmVic1Pri0&0xFF3F_FFFF)|0x00400000)
#define rmVic1Int11Pri2                          (rmVic1Pri0=(rmVic1Pri0&0xFF3F_FFFF)|0x00800000)
#define rmVic1Int11Pri3                          (rmVic1Pri0=(rmVic1Pri0|0x00C0_0000))
#define rmVic1Int12Pri0                          (rmVic1Pri0=(rmVic1Pri0&0xFCFF_FFFF))
#define rmVic1Int12Pri1                          (rmVic1Pri0=(rmVic1Pri0&0xFCFF_FFFF)|0x01000000)
#define rmVic1Int12Pri2                          (rmVic1Pri0=(rmVic1Pri0&0xFCFF_FFFF)|0x02000000)
#define rmVic1Int12Pri3                          (rmVic1Pri0=(rmVic1Pri0|0x0300_0000))
#define rmVic1Int13Pri0                          (rmVic1Pri0=(rmVic1Pri0&0xF3FF_FFFF))
#define rmVic1Int13Pri1                          (rmVic1Pri0=(rmVic1Pri0&0xF3FF_FFFF)|0x04000000)
#define rmVic1Int13Pri2                          (rmVic1Pri0=(rmVic1Pri0&0xF3FF_FFFF)|0x08000000)
#define rmVic1Int13Pri3                          (rmVic1Pri0=(rmVic1Pri0|0x0C00_0000))
#define rmVic1Int14Pri0                          (rmVic1Pri0=(rmVic1Pri0&0xCFFF_FFFF))
#define rmVic1Int14Pri1                          (rmVic1Pri0=(rmVic1Pri0&0xCFFF_FFFF)|0x10000000)
#define rmVic1Int14Pri2                          (rmVic1Pri0=(rmVic1Pri0&0xCFFF_FFFF)|0x20000000)
#define rmVic1Int14Pri3                          (rmVic1Pri0=(rmVic1Pri0|0x3000_0000))
#define rmVic1Int15Pri0                          (rmVic1Pri0=(rmVic1Pri0&0x3FFF_FFFF))
#define rmVic1Int15Pri1                          (rmVic1Pri0=(rmVic1Pri0&0x3FFF_FFFF)|0x40000000)
#define rmVic1Int15Pri2                          (rmVic1Pri0=(rmVic1Pri0&0x3FFF_FFFF)|0x80000000)
#define rmVic1Int15Pri3                          (rmVic1Pri0=(rmVic1Pri0|0xC000_0000))

// Vector Priority Register 1
#define rmVic1Pri1                               r32Svic1[0x84/4]
#define rmVic1Int16Pri0                          (rmVic1Pri1=(rmVic1Pri1&0xFFFF_FFFC))
#define rmVic1Int16Pri1                          (rmVic1Pri1=(rmVic1Pri1&0xFFFF_FFFC)|0x0000_0001)
#define rmVic1Int16Pri2                          (rmVic1Pri1=(rmVic1Pri1&0xFFFF_FFFC)|0x0000_0002)
#define rmVic1Int16Pri3                          (rmVic1Pri1=(rmVic1Pri1|0x0000_0003))
#define rmVic1Int17Pri0                          (rmVic1Pri1=(rmVic1Pri1&0xFFFF_FFF3))
#define rmVic1Int17Pri1                          (rmVic1Pri1=(rmVic1Pri1&0xFFFF_FFF3)|0x0000_0004)
#define rmVic1Int17Pri2                          (rmVic1Pri1=(rmVic1Pri1&0xFFFF_FFF3)|0x0000_0008)
#define rmVic1Int17Pri3                          (rmVic1Pri1=(rmVic1Pri1|0x0000_000C))
#define rmVic1Int18Pri0                          (rmVic1Pri1=(rmVic1Pri1&0xFFFF_FFCF))
#define rmVic1Int18Pri1                          (rmVic1Pri1=(rmVic1Pri1&0xFFFF_FFCF)|0x0000_0010)
#define rmVic1Int18Pri2                          (rmVic1Pri1=(rmVic1Pri1&0xFFFF_FFCF)|0x0000_0020)
#define rmVic1Int18Pri3                          (rmVic1Pri1=(rmVic1Pri1|0x0000_0030))
#define rmVic1Int19Pri0                          (rmVic1Pri1=(rmVic1Pri1&0xFFFF_FF3F))
#define rmVic1Int19Pri1                          (rmVic1Pri1=(rmVic1Pri1&0xFFFF_FF3F)|0x0000_0040)
#define rmVic1Int19Pri2                          (rmVic1Pri1=(rmVic1Pri1&0xFFFF_FF3F)|0x0000_0080)
#define rmVic1Int19Pri3                          (rmVic1Pri1=(rmVic1Pri1|0x0000_0300))
#define rmVic1Int20Pri0                          (rmVic1Pri1=(rmVic1Pri1&0xFFFF_FCFF))
#define rmVic1Int20Pri1                          (rmVic1Pri1=(rmVic1Pri1&0xFFFF_FCFF)|0x0000_0100)
#define rmVic1Int20Pri2                          (rmVic1Pri1=(rmVic1Pri1&0xFFFF_FCFF)|0x0000_0200)
#define rmVic1Int20Pri3                          (rmVic1Pri1=(rmVic1Pri1|0x0000_0300))
#define rmVic1Int21Pri0                          (rmVic1Pri1=(rmVic1Pri1&0xFFFF_F3FF))
#define rmVic1Int21Pri1                          (rmVic1Pri1=(rmVic1Pri1&0xFFFF_F3FF)|0x0000_0400)
#define rmVic1Int21Pri2                          (rmVic1Pri1=(rmVic1Pri1&0xFFFF_F3FF)|0x0000_0800)
#define rmVic1Int21Pri3                          (rmVic1Pri1=(rmVic1Pri1|0x0000_0C00))
#define rmVic1Int22Pri0                          (rmVic1Pri1=(rmVic1Pri1&0xFFFF_CFFF))
#define rmVic1Int22Pri1                          (rmVic1Pri1=(rmVic1Pri1&0xFFFF_CFFF)|0x0000_1000)
#define rmVic1Int22Pri2                          (rmVic1Pri1=(rmVic1Pri1&0xFFFF_CFFF)|0x0000_2000)
#define rmVic1Int22Pri3                          (rmVic1Pri1=(rmVic1Pri1|0x0000_3000))
#define rmVic1Int23Pri0                          (rmVic1Pri1=(rmVic1Pri1&0xFFFF_3FFF))
#define rmVic1Int23Pri1                          (rmVic1Pri1=(rmVic1Pri1&0xFFFF_3FFF)|0x0000_4000)
#define rmVic1Int23Pri2                          (rmVic1Pri1=(rmVic1Pri1&0xFFFF_3FFF)|0x0000_8000)
#define rmVic1Int23Pri3                          (rmVic1Pri1=(rmVic1Pri1|0x0000_C000))
#define rmVic1Int24Pri0                          (rmVic1Pri1=(rmVic1Pri1&0xFFFC_FFFF))
#define rmVic1Int24Pri1                          (rmVic1Pri1=(rmVic1Pri1&0xFFFC_FFFF)|0x0001_0000)
#define rmVic1Int24Pri2                          (rmVic1Pri1=(rmVic1Pri1&0xFFFC_FFFF)|0x0002_0000)
#define rmVic1Int24Pri3                          (rmVic1Pri1=(rmVic1Pri1|0x0003_0000))
#define rmVic1Int25Pri0                          (rmVic1Pri1=(rmVic1Pri1&0xFFF3_FFFF))
#define rmVic1Int25Pri1                          (rmVic1Pri1=(rmVic1Pri1&0xFFF3_FFFF)|0x0004_0000)
#define rmVic1Int25Pri2                          (rmVic1Pri1=(rmVic1Pri1&0xFFF3_FFFF)|0x0008_0000)
#define rmVic1Int25Pri3                          (rmVic1Pri1=(rmVic1Pri1|0x000C_0000))
#define rmVic1Int26Pri0                          (rmVic1Pri1=(rmVic1Pri1&0xFFCF_FFFF))
#define rmVic1Int26Pri1                          (rmVic1Pri1=(rmVic1Pri1&0xFFCF_FFFF)|0x0010_0000)
#define rmVic1Int26Pri2                          (rmVic1Pri1=(rmVic1Pri1&0xFFCF_FFFF)|0x0020_0000)
#define rmVic1Int26Pri3                          (rmVic1Pri1=(rmVic1Pri1|0x0030_0000))
#define rmVic1Int27Pri0                          (rmVic1Pri1=(rmVic1Pri1&0xFF3F_FFFF))
#define rmVic1Int27Pri1                          (rmVic1Pri1=(rmVic1Pri1&0xFF3F_FFFF)|0x0040_0000)
#define rmVic1Int27Pri2                          (rmVic1Pri1=(rmVic1Pri1&0xFF3F_FFFF)|0x0080_0000)
#define rmVic1Int27Pri3                          (rmVic1Pri1=(rmVic1Pri1|0x00C0_0000))
#define rmVic1Int28Pri0                          (rmVic1Pri1=(rmVic1Pri1&0xFCFF_FFFF))
#define rmVic1Int28Pri1                          (rmVic1Pri1=(rmVic1Pri1&0xFCFF_FFFF)|0x0100_0000)
#define rmVic1Int28Pri2                          (rmVic1Pri1=(rmVic1Pri1&0xFCFF_FFFF)|0x0200_0000)
#define rmVic1Int28Pri3                          (rmVic1Pri1=(rmVic1Pri1|0x0300_0000))
#define rmVic1Int29Pri0                          (rmVic1Pri1=(rmVic1Pri1&0xF3FF_FFFF))
#define rmVic1Int29Pri1                          (rmVic1Pri1=(rmVic1Pri1&0xF3FF_FFFF)|0x0400_0000)
#define rmVic1Int29Pri2                          (rmVic1Pri1=(rmVic1Pri1&0xF3FF_FFFF)|0x0800_0000)
#define rmVic1Int29Pri3                          (rmVic1Pri1=(rmVic1Pri1|0x0C00_0000))
#define rmVic1Int30Pri0                          (rmVic1Pri1=(rmVic1Pri1&0xCFFF_FFFF))
#define rmVic1Int30Pri1                          (rmVic1Pri1=(rmVic1Pri1&0xCFFF_FFFF)|0x1000_0000)
#define rmVic1Int30Pri2                          (rmVic1Pri1=(rmVic1Pri1&0xCFFF_FFFF)|0x2000_0000)
#define rmVic1Int30Pri3                          (rmVic1Pri1=(rmVic1Pri1|0x3000_0000))
#define rmVic1Int31Pri0                          (rmVic1Pri1=(rmVic1Pri1&0x3FFF_FFFF))
#define rmVic1Int31Pri1                          (rmVic1Pri1=(rmVic1Pri1&0x3FFF_FFFF)|0x4000_0000)
#define rmVic1Int31Pri2                          (rmVic1Pri1=(rmVic1Pri1&0x3FFF_FFFF)|0x8000_0000)
#define rmVic1Int31Pri3                          (rmVic1Pri1=(rmVic1Pri1|0xC000_0000))

// FIQ Status Register
#define rmVic1FiqStatus                          r32Svic1[0x88/4]
// IRQ Status Register
#define rmVic1IrqStatus                          r32Svic1[0x8C/4]
// Raw Interrupt Status Register
#define rmVic1RawInt                             r32Svic1[0x90/4]
// Interrupt Select Register
#define rmVic1IntSel                             r32Svic1[0x94/4]
// Interrupt Source Mode
#define rmVic1IntMode                            r32Svic1[0x98/4]
// Interrupt Source Polarity
#define rmVic1IntPolarity                        r32Svic1[0x9C/4]
// Soft Interrupt Source
#define rmVic1SoftInt                            r32Svic1[0xA0/4]
// Clear Software Interrupt once ISR completed
#define rmVic1SoftIntClr(x)                      (r32Svic1[0xA0/4]=(r32Svic1[0xA0/4]&(~x)))
// Software Mask Register
#define rmVic1SoftMaskN                          r32Svic1[0xA4/4]
// Software Clear Interrupt
#define rmVic1IntClr                             r32Svic1[0xA8/4]
// Interrupt Enable Register
#define rmVic1IntEnable                          r32Svic1[0xAC/4]
#define rmVic1EnInt(x)                           (rmVic1IntEnable|=(x))
#define rmVic1DisInt(x)                          (rmVic1IntEnable&=~(x))
// VIC Controller Enable
#define rmVic1GCtrl                              rSvic1[0xB0]
#define rmVic1Enable                             (rmVic1GCtrl=cBit0)
#define rmVic1Disable                            (rmVic1GCtrl=0)

// VIC Event Select
#define rmVic1EventSel                           r64Svic1[0xB8/8]
#define rmVic1EnEvent(x)                         (rmVic1EventSel|=(x))
#define rmVic1DisEvent(x)                        (rmVic1EventSel&=~(x))

// Vector Addr Register -
// Write any value to this register to clear current interrupt, this is necessary after ISR done
#define rmVic1Addr                               r32Svic1[0xF00/4]
#define rmVic1IrqClr                             rmVic1Addr=0x00000000

// Just for fake interrupt
#define rmClrVic1FakeInt                         r32Svic1[0xFF0/4]

#endif    // ifndef __REG_SVIC1_H__







