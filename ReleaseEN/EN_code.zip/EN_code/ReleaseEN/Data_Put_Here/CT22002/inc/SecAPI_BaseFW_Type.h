







#ifndef __SECAPI_TYPE_BASEFW_H__
#define __SECAPI_TYPE_BASEFW_H__

#if _ENABLE_SECAPI
#include "SecAPI_BaseFW_Define.h"

typedef struct
{
    BYTE MBRShadow;    // MBR info
    BYTE LockingStatus;    // locking info
    BYTE TcgNviSpLockingLifeCycleState;    // TcgNviSpLockingLifeCycleState
}lba_policy_st;

typedef struct
{
    BYTE EnAES;
    BYTE EnTCG;
    BYTE EnIEEE1667;
    BYTE EnSessionTimer;    // Depend on whether the project supports RTC
    BYTE EnPyrite;
    BYTE EnATAPassThrough;
    BYTE EnE2EWorkAround;
    BYTE EnAtaPassword;
}cid_st;

typedef struct
{
    BYTE Map_TCG_1;
    BYTE Map_TCG_2;
    BYTE TCGReadOrigin;
    BYTE TCGReadUpdated;
    BYTE WPRO_TCGIEEE1667Info_ID;
    BYTE WPRO_SECURITY_ID;
    BYTE Security_Log_ID;
}const_st;

typedef struct
{
    BYTE uSectorPerUnitH2n;
    BYTE uSectorPerUnitH;
    BYTE uSectorPerPageH;
    BYTE uSectorPerWPROPageH;
    BYTE uTCGReservedSecShiftCnt;
    LWORD u32ReservedAreaStartSector;    // User Addressable Logical Sectors(Aligned 4K)
    LWORD u32MemoryUsageAddr;    // must be on TSB //Inform Security FW where SecIntf_MemoryUsage/SecIntf_Crypto can take place
    LWORD u32MaxSessionTimeout;
}parameter_st;

typedef struct
{
    volatile LWORD *uarH2FMap;
    volatile UCBYTE(*uarRwBuf)[512];
    BYTE *uarWWN;    // World Wide Name
    BYTE *uarAtaPassword;
}pointer_st;

typedef struct
{
    LWORD *u32arWriteRangeStart;    // 9 elements
    LWORD *u32arWriteRangeEnd;    // 9 elements
    LWORD *u32arReadRangeStart;    // 9 elements
    LWORD *u32arReadRangeEnd;    // 9 elements
    BYTE *uarTCGMBRValidBitMap;    // 4416 elements
}pointer_sec_st;

typedef struct
{
/*=====================================================================*/
// ------ SecurityFW Revision
/*=====================================================================*/
    CBYTE SecurityFW_Rev[16];

/*=====================================================================*/
// ------ implement by SecurityFW
/*=====================================================================*/
#if _ENABLE_ATA_PASSTHROUGH
    void (*gfpSecIntf_NoticeModifyMEKs)(BYTE *upMEK);
    void (*gfpSecIntf_InitATASecurity)(BYTE uMode);
#endif
#if _ENABLE_ATA_PASSTHROUGH    // For liteon use
    void (*gfpSecIntf_VU_EraseUnit)();
#endif
    void (*gfpSecIntf_SessionTimeoutCall)(LWORD u32TimerDiff, LWORD u32MaxSessionTimeout);
    void (*gfpSecIntf_InitStart)(BYTE uMode);
    void (*gfpSecIntf_InitParameter)();
    void (*gfpSecIntf_InitSecurityFWParameter)();
    void (*gfpSecIntf_UpdateSecurityFWParameter)(cid_st *CID, const_st *CONST, parameter_st *PARAMETER, pointer_st *POINTER);
    LWORD (*gfpSecIntf_GetReadGHP)(BYTE u8Mode, LWORD u32GHP);
    void (*gfpSecIntf_NoticeBackupResume)(BYTE u8Action);
    void (*gfpSecIntf_NoticeReset)(BYTE uType);
    BYTE (*gfpSecIntf_SetCPin)(BYTE *uarCPinMSID, BYTE *uarCPinPSID);
    LWORD (*gfpSecIntf_TCG_JudgeRWGHP)(LWORD *up32GlobalHPage);
    void (*gfpSecIntf_TCG_ReadDone)(BYTE u8Mode, LWORD u32SectorOffset);
    void (*gfpSecIntf_GetLBAInfo)(BYTE u8Mode, LWORD *u32LBA, LWORD *u32HostXfrCnt);
    void (*gfpSecIntf_TCG_WriteProcess)(BYTE u8Mode, LWORD u32SectorOffset, LWORD u32Cache0Edge, LWORD u32CacheStartAddr);
    BYTE (*gfpSecIntf_IfSendCmd)(BYTE uProtocolID, WORD u16ComID, LWORD u32HostXfrByte);
    BYTE (*gfpSecIntf_IfSendData)(LWORD u32SendBufAddr);
    BYTE (*gfpSecIntf_IfRecvCmd)(BYTE uProtocolID, WORD u16ComID, LWORD u32HostXfrByte);
    void (*gfpSecIntf_IfRecvComplete)();

/*=====================================================================*/
// ------ implement by SecurityFW - Crypto
/*=====================================================================*/
    BYTE (*gfpSecIntf_Crypto_UpdateGlobalRangeKey)(BYTE *uarGlobalRangeKey);
    void (*gfpSecIntf_Crypto_RestoreAESHWInfo)();

/*=====================================================================*/
// ------ implement by BaseFW
/*=====================================================================*/
#if _ENABLE_ATA_PASSTHROUGH
    void (*gfpSecIntf_EraseUserArea)(BYTE u8DoNotChangeSecurityState);
    void (*gfpSecIntf_UpdateATASecurityStatus)(BYTE uMode, BYTE *uSecurityStatus);
    void (*gfpSecIntf_SYS_DCache_Invalidte)();
#endif
    BYTE (*gfpSecIntf_JudgeWrittenGHP)(LWORD u8GHP);
    void (*gfpSecIntf_SetSecurityWProMode)();
    LWORD (*gfpSecIntf_GetCurrentMs)();
    void (*gfpSecIntf_TimerWaitMs)(LWORD time);
    void (*gfpSecIntf_SetSessionTimeout)(BYTE uAtion, LWORD u32SessionTimerStart, LWORD u32MaxSessionTimeout);
    void (*gfpSecIntf_MOVE_MEM2MEM)(LWORD Src_Addr, LWORD Des_Addr, LWORD len);
    BYTE (*gfpSecIntf_MemoryCompare)(LWORD Src_Addr, LWORD Des_Addr, LWORD len);
    void (*gfpSecIntf_ResetMemory)(BYTE *ptr, LWORD size, LWORD u32Val);
    void (*gfpSecIntf_ResetTSB)(UCBYTE *ptr, LWORD size, LWORD u32Val);
    LWORD (*gfpSecIntf_MemoryUsage)(BYTE u8Usage, BYTE u8Mode, WORD u16Length, LWORD u32BaseAddr);
    void (*gfpSecIntf_DebugLog)(BYTE u8Priority, BYTE u8Idx, BYTE u8ParaCnt, WORD u16para0, WORD u16para1, WORD u16para2, WORD u16para3,
                                WORD u16SaveLogID);
    void (*gfpSecIntf_SaveWProPage)(BYTE u8PageIdx);
    BYTE (*gfpSecIntf_LoadWProPage)(BYTE u8PageIdx);
    BYTE (*gfpSecIntf_CheckWProPageExist)(BYTE u8PageIdx);
    void (*gfpSecIntf_SaveLinkMap)(BYTE u8SaveMapID, BYTE u8PartialMap);
    void (*gfpSecIntf_AddTrimEntry)(LWORD u32TrimStartLBA, LWORD u32XfrCnt);
    void (*gfpSecIntf_RangePolicyUpdate)(BYTE u8Action, lba_policy_st *RangePolicy);
    BYTE (*gfpSecIntf_TCG_Write)(BYTE u8Mode);
    BYTE (*gfpSecIntf_TCG_Read)(BYTE u8Mode);
    void (*gfpSecIntf_UpdateBaseFWParameter)(pointer_sec_st *POINTER_SEC);

/*=====================================================================*/
// ------ implement by BaseFW - Crypto
/*=====================================================================*/
    void (*gfpSecIntf_Crypto_LoadKey)(BYTE *upRangeKey, BYTE uRangeID);
    void (*gfpSecIntf_Crypto_SetRangePartitionRegister)(BYTE u8Action, LWORD u32LBAStart, LWORD u32LBAEnd, BYTE uRangeID);
    void (*gfpSecIntf_Crypto_GenerateRandomNum)(BYTE u8ByteLen, BYTE *uRandomNum);
}funcptr_st;

#endif    // if _ENABLE_SECAPI
#endif    // ifndef __SECAPI_TYPE_BASEFW_H__







