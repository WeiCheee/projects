







#ifndef __REG_GPIO_H__
#define __REG_GPIO_H__

// System Register Address @ 0x5000_0000
// GPIO Register Index
#define rcGpioP0Io                               0x70
#define rcGpioP0Oe                               0x79
#define rcGpioP0Pu                               0x7A
#define rcGpioP0Pd                               0x7B

#define cGpioB0                                  0
#define cGpioB1                                  1
#define cGpioB2                                  2
#define cGpioB3                                  3
#define cGpioB4                                  4
#define cGpioB5                                  5
#define cGpioB6                                  6
#define cGpioB7                                  7

#define rmGpio0SetHi(x)                          (rSysCtrl0[rcGpioP0Io]|=x)
#define rmGpio0SetLo(x)                          (rSysCtrl0[rcGpioP0Io]&=(~x))

#define rcGpioP1Io                               0x71
#define rcGpioP1Oe                               0x7D
#define rcGpioP1Pu                               0x7E
#define rcGpioP1Pd                               0x7F

#define rmGPIO1SetHi(x)                          (rSysCtrl0[rcGpioP1Io]|=x)
#define rmGPIO1SetLo(x)                          (rSysCtrl0[rcGpioP1Io]&=(~x))

#define rmChkGpioP11                             (rSysCtrl0[rcGpioP1Io]&cBit1)
#define rmChkPerstDeassert                       (rSysCtrl0[rcGpioP1Io]&cBit1)

#define rcGpioP2Io                               0xF4
#define rcGpioP2Oe                               0xF1
#define rcGpioP2Pu                               0xF2
#define rcGpioP2Pd                               0xF3
#define rcGpioP2Dd                               0xF0
#define rcGpioP27                                0xF6

#define rmP27OutputClk                           (rSysCtrl0[rcGpioP27]|=cBit0)

// GPIO 0
// GPIO Control
#define rmGpioP0Init                             (rSysCtrl0[rcGpioP0Oe]=0x18)
#define rmGpioP0OeEn(x)                          (rSysCtrl0[rcGpioP0Oe]|=x)
#define rmGpioP0OeDis(x)                         (rSysCtrl0[rcGpioP0Oe]&=(~x))
#define rmGpioP0PuEnable(x)                      (rSysCtrl0[rcGpioP0Pu]|=x)    // x  : the pin assignment bitmap would like to enable , ex, pin0
// and pin1 enable => 0x03 as x
#define rmGpioP0PuDisable(x)                     (rSysCtrl0[rcGpioP0Pu]&=(~x))    // x  : the pin assignment bitmap would like to disable , ex,
// pin0 and pin1 disable => 0x03 as x
#define rmGpioP0PdEnable(x)                      (rSysCtrl0[rcGpioP0Pd]|=x)    // x  : the pin assignment bitmap would like to enable , ex, pin0
// and pin1 enable => 0x03 as x
#define rmGpioP0PdDisable(x)                     (rSysCtrl0[rcGpioP0Pd]&=(~x))    // x  : the pin assignment bitmap would like to disable , ex,
// pin0 and pin1 disable => 0x03 as x
#define rmSetGpioP0Pu(x)                         (rSysCtrl0[rcGpioP0Pu]=x)
#define rmSetGpioP0Pd(x)                         (rSysCtrl0[rcGpioP0Pd]=x)

#define rmGpioP0Pu                               rSysCtrl0[rcGpioP0Pu]
#define rmGpioP0Pd                               rSysCtrl0[rcGpioP0Pd]
#define rmGpioP0Oe                               rSysCtrl0[rcGpioP0Oe]

// #define rmGpioP00SetOutput                     (rSysCtrl0[rcGpioP0Oe]|=cBit0)
// #define rmGpioP01SetOutput                     (rSysCtrl0[rcGpioP0Oe]|=cBit1)
// #define rmGpioP02SetOutput                     (rSysCtrl0[rcGpioP0Oe]|=cBit2)
// #define rmGpioP03SetOutput                     (rSysCtrl0[rcGpioP0Oe]|=cBit3)
// #define rmGpioP04SetOutput                     (rSysCtrl0[rcGpioP0Oe]|=cBit4)
// #define rmGpioP05SetOutput                     (rSysCtrl0[rcGpioP0Oe]|=cBit5)
// #define rmGpioP06SetOutput                     (rSysCtrl0[rcGpioP0Oe]|=cBit6)
// #define rmGpioP07SetOutput                     (rSysCtrl0[rcGpioP0Oe]|=cBit7)

// #define rmGpioP00SetInput                      (rSysCtrl0[rcGpioP0Oe]&=(~cBit0))
// #define rmGpioP01SetInput                      (rSysCtrl0[rcGpioP0Oe]&=(~cBit1))
// #define rmGpioP02SetInput                      (rSysCtrl0[rcGpioP0Oe]&=(~cBit2))
// #define rmGpioP03SetInput                      (rSysCtrl0[rcGpioP0Oe]&=(~cBit3))
// #define rmGpioP04SetInput                      (rSysCtrl0[rcGpioP0Oe]&=(~cBit4))
// #define rmGpioP05SetInput                      (rSysCtrl0[rcGpioP0Oe]&=(~cBit5))
// #define rmGpioP06SetInput                      (rSysCtrl0[rcGpioP0Oe]&=(~cBit6))
// #define rmGpioP07SetInput                      (rSysCtrl0[rcGpioP0Oe]&=(~cBit7))

// GPIO P0 Output Value
#define rmGpioP0OutputVal(x)                     (rSysCtrl0[rcGpioP0Io]=x)
#define rmGpioP03NandIoPwrEn                     (rSysCtrl0[rcGpioP0Io]|=cBit3)    // NAND IO power control(1.8V/1.2V) 1:enable(default)
// 0:diable
#define rmGpioP03NandIoPwrDis                    (rSysCtrl0[rcGpioP0Io]&=(~cBit3))    // NAND IO power control(1.8V/1.2V) 1:enable(default)
// 0:diable
#define rmGpioP04NandVppPwrEn                    (rSysCtrl0[rcGpioP0Io]|=cBit4)    // NAND VPP power control(1.8V/1.2V) 1:enable(default)
// 0:diable
#define rmGpioP04NandVppPwrDis                   (rSysCtrl0[rcGpioP0Io]&=(~cBit4))    // NAND VPP power control(1.8V/1.2V) 1:enable(default)
// 0:diable

// GPIO P0 Input Value
#define rmGpioP0InputVal                         rSysCtrl0[rcGpioP0Io]
#define rmGpioP00SelCeNumber                     (rSysCtrl0[rcGpioP0Io]&cBit0)    // flash io dd and du, 0:less CE(defult)  1:many CE
#define rmGpioP01InvertPcieTx                    (rSysCtrl0[rcGpioP0Io]&cBit1)    // Invert all Pcie Tx signal, 0:normal(default) 1:invert
#define rmGpioP02CEDeMuxEn                       (rSysCtrl0[rcGpioP0Io]&cBit2)    // CE De-Mux mode, 0:diable(default) 1:enable
#define rmGpioP05SixAleEnable                    (rSysCtrl0[rcGpioP0Io]&cBit5)    // ALE feature set, 0: 5ALE(default) 1: 6ALE enable
#define rmGpioP06SelToggle                       (rSysCtrl0[rcGpioP0Io]&cBit6)    // flash mode, 0:legacy mode(default) 1: toggle mode flash
#define rmGpioP07SelSpiLoad                      (rSysCtrl0[rcGpioP0Io]&cBit7)    // SPI load, 0:disable(default)  1:enable

// GPIO 1
// GPIO Control
#define rmGpioP1Init                             (rSysCtrl0[rcGpioP1Oe]=0x44)    // Init as default setting
#define rmGpioP1OeEn(x)                          (rSysCtrl0[rcGpioP1Oe]|=x)
#define rmGpioP1OeDis(x)                         (rSysCtrl0[rcGpioP1Oe]&=~(x))
#define rmGpioP1PuEnable(x)                      (rSysCtrl0[rcGpioP1Pu]|=x)    // x  : the pin assignment bitmap would like to enable , ex, pin0
// and pin1 enable => 0x03 as x
#define rmGpioP1PuDisable(x)                     (rSysCtrl0[rcGpioP1Pu]&=~(x))    // x  : the pin assignment bitmap would like to disable , ex,
// pin0 and pin1 disable => 0x03 as x
#define rmGpioP1PdEnable(x)                      (rSysCtrl0[rcGpioP1Pd]|=x)    // x  : the pin assignment bitmap would like to enable , ex, pin0
// and pin1 enable => 0x03 as x
#define rmGpioP1PdDisable(x)                     (rSysCtrl0[rcGpioP1Pd]&=~(x))    // x  : the pin assignment bitmap would like to disable , ex,
// pin0 and pin1 disable => 0x03 as x
#define rmSetGpioP1Pu(x)                         (rSysCtrl0[rcGpioP1Pu]=x)
#define rmSetGpioP1Pd(x)                         (rSysCtrl0[rcGpioP1Pd]=x)

#define rmGpioP1Pu                               rSysCtrl0[rcGpioP1Pu]
#define rmGpioP1Pd                               rSysCtrl0[rcGpioP1Pd]
#define rmGpioP1Oe                               rSysCtrl0[rcGpioP1Oe]

// #define rmGpioP10SetOutput                     (rSysCtrl0[rcGpioP1Oe]|=cBit0)
// #define rmGpioP11SetOutput                     (rSysCtrl0[rcGpioP1Oe]|=cBit1)
// #define rmGpioP12SetOutput                     (rSysCtrl0[rcGpioP1Oe]|=cBit2)
// #define rmGpioP13SetOutput                     (rSysCtrl0[rcGpioP1Oe]|=cBit3)
// #define rmGpioP14SetOutput                     (rSysCtrl0[rcGpioP1Oe]|=cBit4)
// #define rmGpioP15SetOutput                     (rSysCtrl0[rcGpioP1Oe]|=cBit5)
// #define rmGpioP16SetOutput                     (rSysCtrl0[rcGpioP1Oe]|=cBit6)
// #define rmGpioP17SetOutput                     (rSysCtrl0[rcGpioP1Oe]|=cBit7)

// #define rmGpioP10SetInput                      (rSysCtrl0[rcGpioP1Oe]&=(~cBit0))
// #define rmGpioP11SetInput                      (rSysCtrl0[rcGpioP1Oe]&=(~cBit1))
// #define rmGpioP12SetInput                      (rSysCtrl0[rcGpioP1Oe]&=(~cBit2))
// #define rmGpioP13SetInput                      (rSysCtrl0[rcGpioP1Oe]&=(~cBit3))
// #define rmGpioP14SetInput                      (rSysCtrl0[rcGpioP1Oe]&=(~cBit4))
// #define rmGpioP15SetInput                      (rSysCtrl0[rcGpioP1Oe]&=(~cBit5))
// #define rmGpioP16SetInput                      (rSysCtrl0[rcGpioP1Oe]&=(~cBit6))
// #define rmGpioP17SetInput                      (rSysCtrl0[rcGpioP1Oe]&=(~cBit7))

// GPIO P1 Output Value
#define rmGpioP1OutputVal(x)                     (rSysCtrl0[rcGpioP1Io]=x)

#define rmGreyBoxTest(x)                         (rSysCtrl0[rcGpioP1Io]=((rSysCtrl0[rcGpioP1Io]&(~cBit2))|((x)<<2)))
#define rmFlashCorePower(x)                      (rSysCtrl0[rcGpioP0Io]=((rSysCtrl0[rcGpioP0Io]&(~cBit3))|((x)<<3)))
#define rmGpioP12Led(x)                          (rSysCtrl0[rcGpioP1Io]=((rSysCtrl0[rcGpioP1Io]&(~cBit2))|((x)<<2)))    // LED,0:ON 1:OFF
#define rmGpioP16Led(x)                          (rSysCtrl0[rcGpioP1Io]=((rSysCtrl0[rcGpioP1Io]&(~cBit6))|((x)<<6)))    // LED

// Set Das Led like open-drain
#define mSetDaspLed                              {rSysCtrl0[rcGpioP1Pu]&=~cBit6;rSysCtrl0[rcGpioP1Oe]|=cBit6;rSysCtrl0[rcGpioP1Io]&=~cBit6;}
#define mClrDaspLed                              {rSysCtrl0[rcGpioP1Oe]&=~cBit6;rSysCtrl0[rcGpioP1Pu]|=cBit6;}
#define mToggleDaspLed\
    {if(rSysCtrl0[rcGpioP1Pu]&cBit6){mSetDaspLed}\
     else{mClrDaspLed}\
    }

// GPIO P1 Input Value
#define rmGpioP1InputVal                         rSysCtrl0[rcGpioP1Io]
#define rmGpioP10Int                             (!(rSysCtrl0[rcGpioP1Io]&cBit0))    // 1: default
#if _FPGA
#define rmGpioP10SecurityEnable                  (!(rSysCtrl0[rcGpioP1Io]&cBit0))    // FPGA security check, 0:enable, 1: disable
#endif

#define rmGpioP11Int                             (!(rSysCtrl0[rcGpioP1Io]&cBit1))    // 1: default
#define rmGpioP12SecureErase                     (!(rSysCtrl0[rcGpioP1Io]&cBit2))    // 1: default; 1: disable 0:enable
#define rmGpioP13ForceRom                        (!(rSysCtrl0[rcGpioP1Io]&cBit3))    // Force ROM code, 0: rom, 1: ISP(default)
#define rmGpioP14SelReliable                     (!(rSysCtrl0[rcGpioP1Io]&cBit4))    // reliable mode,  0:reliable mode, 1:Normal mode (default)
#define rmGpioP15RandomizerDisable               (rSysCtrl0[rcGpioP1Io]&cBit5)    // Disable L85C/L06B/B0KB randomizer, 0:none(default)  1:use
// set feature to diable
#define rmGpioP17ExtVdtInpt                      (rSysCtrl0[rcGpioP1Io]&cBit7)    // External VDT input

// #define rmGpioP11HwWp                          (!(rSysCtrl0[rcGpioP1Io]&cBit1))           // HW Write Protect (1'b1:normal /
// 1'b0:enable)//not define but use in FW
// #define rmGpioP15QuickErase                    (rSysCtrl0[rcGpioP1Io]&cBit5)              //not define but use in FW

// GPIO 2
// GPIO Control
#define rmGpioP2OutputVal(x)                     (rSysCtrl0[rcGpioP2Io]|=x)
#define rmGpioP2InputVal                         rSysCtrl0[rcGpioP2Io]
#define rmGpioP2Init                             (rSysCtrl0[rcGpioP2Oe]=0x40)    // Init as default setting
#define rmGpioP2PuEnable(x)                      (rSysCtrl0[rcGpioP2Pu]|=x)    // x  : the pin assignment bitmap would like to enable , ex, pin0
// and pin1 enable => 0x03 as x
#define rmGpioP2PuDisable(x)                     (rSysCtrl0[rcGpioP2Pu]&=~(x))    // x  : the pin assignment bitmap would like to disable , ex,
// pin0 and pin1 disable => 0x03 as x
#define rmGpioP2PdEnable(x)                      (rSysCtrl0[rcGpioP2Pd]|=x)    // x  : the pin assignment bitmap would like to enable , ex, pin0
// and pin1 enable => 0x03 as x
#define rmGpioP2PdDisable(x)                     (rSysCtrl0[rcGpioP2Pd]&=~(x))    // x  : the pin assignment bitmap would like to disable , ex,
// pin0 and pin1 disable => 0x03 as x
#define rmGpioP2OeDis(x)                          (rSysCtrl0[rcGpioP2Oe]&=~(x))
#define rmGpioP2OeEn(x)                          (rSysCtrl0[rcGpioP2Oe]|=x)
#define rmSetGpioP2Pu(x)                         (rSysCtrl0[rcGpioP2Pu]=x)
#define rmSetGpioP2Pd(x)                         (rSysCtrl0[rcGpioP2Pd]=x)

#define rmGpioP2Pu                               rSysCtrl0[rcGpioP2Pu]
#define rmGpioP2Pd                               rSysCtrl0[rcGpioP2Pd]
#define rmGpioP2Oe                               rSysCtrl0[rcGpioP2Oe]

// #define rmGpioP20SetOutput                     (rSysCtrl0[rcGpioP2Oe]|=cBit0)
// #define rmGpioP21SetOutput                     (rSysCtrl0[rcGpioP2Oe]|=cBit1)
// #define rmGpioP22SetOutput                     (rSysCtrl0[rcGpioP2Oe]|=cBit2)
// #define rmGpioP23SetOutput                     (rSysCtrl0[rcGpioP2Oe]|=cBit3)
// #define rmGpioP24SetOutput                     (rSysCtrl0[rcGpioP2Oe]|=cBit4)
// #define rmGpioP25SetOutput                     (rSysCtrl0[rcGpioP2Oe]|=cBit5)
// #define rmGpioP26SetOutput                     (rSysCtrl0[rcGpioP2Oe]|=cBit6)
// #define rmGpioP27SetOutput                     (rSysCtrl0[rcGpioP2Oe]|=cBit7)

// #define rmGpioP20SetInput                      (rSysCtrl0[rcGpioP2Oe]&=(~cBit0))
// #define rmGpioP21SetInput                      (rSysCtrl0[rcGpioP2Oe]&=(~cBit1))
// #define rmGpioP22SetInput                      (rSysCtrl0[rcGpioP2Oe]&=(~cBit2))
// #define rmGpioP23SetInput                      (rSysCtrl0[rcGpioP2Oe]&=(~cBit3))
// #define rmGpioP24SetInput                      (rSysCtrl0[rcGpioP2Oe]&=(~cBit4))
// #define rmGpioP25SetInput                      (rSysCtrl0[rcGpioP2Oe]&=(~cBit5))
// #define rmGpioP26SetInput                      (rSysCtrl0[rcGpioP2Oe]&=(~cBit6))
// #define rmGpioP27SetInput                      (rSysCtrl0[rcGpioP2Oe]&=(~cBit7))

// GPIO P2 Output Value
#define rmGpioP26Lpddr2IoPwrEn                   (rSysCtrl0[rcGpioP2Io]|=cBit6)    // DEVSLP power switch 1:enable(default) 0:diable
#define rmGpioP26Lpddr2IoPwrDis                  (rSysCtrl0[rcGpioP2Io]&=(~cBit6))    // DEVSLP power switch 1:enable(default) 0:diable

#define rmGpioP27CeDeMuxClkOutEn                 (rSysCtrl0[rcGpioP27]|=cBit0)    // when CE_DeMux enable, must set P27 as output and bit[0] of
// register 0x5000_00F6 set to 1
//                                                //P27 as clk
// output when CE_MeMux enable

#if (_ENABLE_SCP_PLP==_EN_PLP)
#define rmGpioP20PlpFBackAssert                   (rSysCtrl0[rcGpioP2Io]&=(~cBit0))
#define rmGpioP20PlpFBackDeAssert                 (rSysCtrl0[rcGpioP2Io]|=cBit0)
#else
#define rmGpioP20PlpFBackAssert                   ;    // For SCP, no need FBack
#define rmGpioP20PlpFBackDeAssert                 ;    // For SCP, no need FBack
#endif
#define rmGpioP25PlpInitAssert                    (!(rSysCtrl0[rcGpioP2Io]&cBit5))
#define rmGpioP25PlpInitDeAssert                  (rSysCtrl0[rcGpioP2Io]&cBit5)

// GPIO P2 Input Value
#define rmGpioP20HostPwDetect                    (rSysCtrl0[rcGpioP2Io]&cBit0)    // Host power PG detect, 0: fail, 1: PASS
#define rmGpioP21NandPwDetect                    (rSysCtrl0[rcGpioP2Io]&cBit1)    // Nand Core Power PG detect, 0: fail, 1: PASS
#define rmGpioP22NandIoPwDetect                  (rSysCtrl0[rcGpioP2Io]&cBit2)    // Nand I/O power PG detect, 0: fail, 1: PASS
#define rmGpioP23NandVppPwDetect                 (rSysCtrl0[rcGpioP2Io]&cBit3)    // Nand VPP power PG detect
#define rmGpioP24Ddr3CoreIoDetect                (rSysCtrl0[rcGpioP2Io]&cBit4)    // DDR3 core and I/O power PG detect(1.5/1.35V)
#define rmGpioP24Ddr2CoreDetect                  (rSysCtrl0[rcGpioP2Io]&cBit4)    // LPDDR2 core power PG detect(1.8V)
#define rmGpioP25Ddr2IoDetect                    (rSysCtrl0[rcGpioP2Io]&cBit5)    // LPDDR2 I/O power PG detect(1.2V)
#define rmGpioP27                                (rSysCtrl0[rcGpioP2Io]&cBit7)

// 2260 A1 features
#define cGpioIrqBitShift                         3
#define cGpioModeBitShift                        2
#define cGpioHiActiveBitShift                    1
// #define cGpioActiveBitShift                    0

// GPIO interrupt register (offset 32)
#define rcGpioIntSetP0                           0x130    // 0x4c
#define rcGpioIntSetP1                           0x134    // 0x4d
#define rcGpioIntSetP2                           0x138    // 0x4e

#define rcGpioIntrClr                            0x13C    // 0x4f

// typedef enum GPIOMODE
// {
// cGpioModeLevel = 0,
// cGpioModeEdge  = 1,
//
// }GPIOMODES;

#define rmGpioP0GetMode(pinIdx)                  ((r32SysCtrl0[rcGpioIntSetP0/4]>>(((pinIdx)<<2)+cGpioModeBitShift))&0x1)
#define rmGpioP1GetMode(pinIdx)                  ((r32SysCtrl0[rcGpioIntSetP1/4]>>(((pinIdx)<<2)+cGpioModeBitShift))&0x1)
#define rmGpioP2GetMode(pinIdx)                  ((r32SysCtrl0[rcGpioIntSetP2/4]>>(((pinIdx)<<2)+cGpioModeBitShift))&0x1)

// GPIO get single pin interrupt status
#define mGpioP0GetIsrState(pinIdx)               (r32SysCtrl0[rcGpioIntrClr/4]&(0x1<<(pinIdx)))
#define mGpioP1GetIsrState(pinIdx)               (r32SysCtrl0[rcGpioIntrClr/4]&(0x1<<((pinIdx)+8)))
#define mGpioP2GetIsrState(pinIdx)               (r32SysCtrl0[rcGpioIntrClr/4]&(0x1<<((pinIdx)+16)))

// GPIO get interrupt event
#define rmGpioP0Irq()                            (r32SysCtrl0[rcGpioIntrClr/4]&0x000000FF)
#define rmGpioP1Irq()                            (r32SysCtrl0[rcGpioIntrClr/4]&0x0000FF00)
#define rmGpioP2Irq()                            (r32SysCtrl0[rcGpioIntrClr/4]&0x00FF0000)

#endif    // ifndef __REG_GPIO_H__







