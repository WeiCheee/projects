







#ifndef __SECAPI_FUNCPTR_BASEFW_H__
#define __SECAPI_FUNCPTR_BASEFW_H__

#if _ENABLE_SECAPI
#include "SecAPI_BaseFW.h"
#include "SecAPI_BaseFW_Type.h"
#endif

#if _ENABLE_SECAPI

#define NULL 0

#ifdef SECURITY_FIRMWARE_CORE

#define SFASSIGN(func)  func
#define BFASSIGN(func)  NULL
#define NOASSIGN(func)  NULL

#else    // #ifdef BASE_FIRMWARE_CORE

#define SFASSIGN(func)  NULL
#define BFASSIGN(func)  func
#define NOASSIGN(func)  NULL

#endif

#endif    // if _ENABLE_SECAPI

#pragma default_variable_attributes = @ ".SecurityAPI_FunPtr"
#if _ENABLE_SECAPI
volatile funcptr_st SFP=
{
/*=====================================================================*/
// ------ SecurityFW Revision
/*=====================================================================*/

#if _ENABLE_SECAPI_SATA
    {'S', 'M', 'I', 'S', 'E', 'C', 'S', 'A', 'T', 'A', 'R', '1', '0', '1', '8', 'A'},
#else
    {'S', 'M', 'I', 'S', 'E', 'C', 'N', 'V', 'M', 'E', 'R', '1', '0', '1', '8', 'A'},
#endif

/*=====================================================================*/
// ------ implement by SecurityFW
/*=====================================================================*/
#if _ENABLE_ATA_PASSTHROUGH
    SFASSIGN(SecIntf_NoticeModifyMEKs),
    SFASSIGN(SecIntf_InitATASecurity),
#endif
#if _ENABLE_ATA_PASSTHROUGH    // For liteon use
    SFASSIGN(SecIntf_VU_EraseUnit),
#endif
    SFASSIGN(SecIntf_SessionTimeoutCall),
    SFASSIGN(SecIntf_InitStart),
    SFASSIGN(SecIntf_InitParameter),
    SFASSIGN(SecIntf_InitSecurityFWParameter),
    SFASSIGN(SecIntf_UpdateSecurityFWParameter),
    SFASSIGN(SecIntf_GetReadGHP),
    SFASSIGN(SecIntf_NoticeBackupResume),
    SFASSIGN(SecIntf_NoticeReset),
    SFASSIGN(SecIntf_SetCPin),
    SFASSIGN(SecIntf_TCG_JudgeRWGHP),
    SFASSIGN(SecIntf_TCG_ReadDone),
    SFASSIGN(SecIntf_GetLBAInfo),
    SFASSIGN(SecIntf_TCG_WriteProcess),
    SFASSIGN(SecIntf_IfSendCmd),
    SFASSIGN(SecIntf_IfSendData),
    SFASSIGN(SecIntf_IfRecvCmd),
    SFASSIGN(SecIntf_IfRecvComplete),

/*=====================================================================*/
// ------ implement by SecurityFW - Crypto
/*=====================================================================*/
    SFASSIGN(SecIntf_Crypto_UpdateGlobalRangeKey),
    SFASSIGN(SecIntf_Crypto_RestoreAESHWInfo),

/*=====================================================================*/
// ------ implement by BaseFW
/*=====================================================================*/
#if _ENABLE_ATA_PASSTHROUGH
    BFASSIGN(SecIntf_EraseUserArea),
    BFASSIGN(SecIntf_UpdateATASecurityStatus),
    BFASSIGN(SecIntf_SYS_DCache_Invalidte),
#endif
    BFASSIGN(SecIntf_JudgeWrittenGHP),
    BFASSIGN(SecIntf_SetSecurityWProMode),
    BFASSIGN(SecIntf_GetCurrentMs),
    BFASSIGN(SecIntf_TimerWaitMs),
    BFASSIGN(SecIntf_SetSessionTimeout),
    BFASSIGN(SecIntf_MOVE_MEM2MEM),
    BFASSIGN(SecIntf_MemoryCompare),
    BFASSIGN(SecIntf_ResetMemory),
    BFASSIGN(SecIntf_ResetTSB),
    BFASSIGN(SecIntf_MemoryUsage),
    BFASSIGN(SecIntf_DebugLog),
    BFASSIGN(SecIntf_SaveWProPage),
    BFASSIGN(SecIntf_LoadWProPage),
    BFASSIGN(SecIntf_CheckWProPageExist),
    BFASSIGN(SecIntf_SaveLinkMap),
    BFASSIGN(SecIntf_AddTrimEntry),
    BFASSIGN(SecIntf_RangePolicyUpdate),
    BFASSIGN(SecIntf_TCG_Write),
    BFASSIGN(SecIntf_TCG_Read),
    BFASSIGN(SecIntf_UpdateBaseFWParameter),

/*=====================================================================*/
// ------ implement by BaseFW - Crypto
/*=====================================================================*/
    BFASSIGN(SecIntf_Crypto_LoadKey),
    BFASSIGN(SecIntf_Crypto_SetRangePartitionRegister),
    BFASSIGN(SecIntf_Crypto_GenerateRandomNum),
};
#endif    // if _ENABLE_SECAPI
#pragma default_variable_attributes =

#endif    // ifndef __SECAPI_FUNCPTR_BASEFW_H__







