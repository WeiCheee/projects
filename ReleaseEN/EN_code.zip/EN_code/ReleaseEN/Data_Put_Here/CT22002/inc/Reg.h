







#ifndef __REG_H__
#define __REG_H__

#include "inc/RegBop.h"
#include "inc/RegBva.h"
#include "inc/RegCpu.h"
#include "inc/RegFake.h"
#include "inc/RegFsh.h"
#include "inc/RegGpio.h"
#include "inc/RegHdma.h"
#include "inc/RegI2c.h"
#include "inc/RegSysCtrl.h"
#include "inc/RegTsb.h"
#include "inc/RegPcie.h"
#include "inc/RegSvic0.h"
#include "inc/RegSvic1.h"
#include "inc/RegNvme.h"
#include "inc/RegEfuse.h"
#include "inc/RegSha.h"
#include "inc/RegRsa.h"
#include "inc/RegLdpc.h"
#include "inc/ArmCp15.h"
#include "inc/Vic.h"
#include "inc/RegPhy.h"
#include "inc/FlashCtrl.h"
#include "inc/RegUart.h"
#include "inc/RegAes.h"
#include "inc/RegTrng.h"
#include "inc/RegI2c.h"
#include "inc/RegDram.h"
#endif    // ifndef __REG_H__







