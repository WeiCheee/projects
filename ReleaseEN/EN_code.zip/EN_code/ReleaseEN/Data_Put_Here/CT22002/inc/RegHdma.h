







#ifndef __REG_HDA_H__
#define __REG_HDA_H__

// HOST DMA Control register  @ 0x5100_1E00

// HDMA Trig
#define rcHdmaTrig                               0x00
#define rmTrigHdmaOp(pause, op)                  (rHdmaCtrl[rcHdmaTrig]=((pause<<2)|op))
#define rmTrigHdmaCrcOp(pause)                   (rHdmaCtrl[rcHdmaTrig]=((pause<<2)|cHdmaCrcOp))
#define rmTrigHdmaSrchOp(pause)                  (rHdmaCtrl[rcHdmaTrig]=((pause<<2)|cHdmaSrchOp))
#define rmTrigHdmaDmaOp(pause)                   (rHdmaCtrl[rcHdmaTrig]=((pause<<2)|cHdmaDmaOp))
#define rmTrigHdmaOFlagOp(pause)                 (rHdmaCtrl[rcHdmaTrig]=((pause<<2)|cHdmaOFlagOp))
#define rmTrigHdmaRaidCmd(pause)                 (rHdmaCtrl[rcHdmaTrig]=((pause<<2)|cHdmaDmaOp|cBit5))

// HDMA Parameter
#define rcHdmaParr1                              0x01

// #define rmHdmaBvciPat                          (rHdmaCtrl[rcHdmaParr1]= 0x98) //Enable dest flag
// #define rmHdmaTsbPat                           (rHdmaCtrl[rcHdmaParr1]= 0xA8) //Enable dest flag
// #define rmHdmaBvci2Tsb                         (rHdmaCtrl[rcHdmaParr1]=0x20)  //Enable BVCI & TSB  flag

// #define rmHdmaEnScramb                         (rHdmaCtrl[rcHdmaParr1]|= cBit1)
// #define rmHdmaCompMode                         (rHdmaCtrl[rcHdmaParr1]|= cBit2)
// #define rmHdmaPatMode                          (rHdmaCtrl[rcHdmaParr1]|= cBit3)
// #define rmHdmaTsb2Tsb                          (rHdmaCtrl[rcHdmaParr1]&= 0xCF)
// #define rmHdmaTsb2Bvci                         (rHdmaCtrl[rcHdmaParr1]= ((rHdmaCtrl[rcHdmaParr1]&(~cBit5))|cBit4))
// #define rmHdmaBvci2Tsb                         (rHdmaCtrl[rcHdmaParr1]= ((rHdmaCtrl[rcHdmaParr1]&(~cBit4))|cBit5))
// #define rmHdmaBvci2Bvci                        (rHdmaCtrl[rcHdmaParr1]|= (cBit5|cBit4))

// #define rmHdmaBypassSrc                        (rHdmaCtrl[rcHdmaParr1]|= cBit7)
// #define rmHdmaSrcAutoFlag                      (rHdmaCtrl[rcHdmaParr1]&= (~cBit7))
// #define rmHdmaBypassDes                        (rHdmaCtrl[rcHdmaParr1]|= cBit6)
// #define rmHdmaDesAutoFlag                      (rHdmaCtrl[rcHdmaParr1]&= (~cBit6))
// #define rmHdmaParr1Reset                       (rHdmaCtrl[rcHdmaParr1]= 0xC0)

#define rmHdmaParrResetEnAutoFlag                (rHdmaCtrl[rcHdmaParr1]=0x00)

#define rmSetHdmaCcm                             (rHdmaCtrl[rcHdmaParr1]|=cBit0)
#define rmSetHdmaDram                            (rHdmaCtrl[rcHdmaParr1]&=~cBit0)
#define rmSetHdmaScrbMo                          (rHdmaCtrl[rcHdmaParr1]|=cBit1)
#define rmSetHdmaCompMo                          (rHdmaCtrl[rcHdmaParr1]|=cBit2)
#define rmSetHdmaFillMo                          (rHdmaCtrl[rcHdmaParr1]|=cBit3)
#define rmSetHdmaDataDir(x)                      (rHdmaCtrl[rcHdmaParr1]=(rHdmaCtrl[rcHdmaParr1]&0xCF)|(x<<4))
#define rmEnHdmaWrBypass                         (rHdmaCtrl[rcHdmaParr1]|=cBit6)
#define rmDisHdmaWrBypass                        (rHdmaCtrl[rcHdmaParr1]&=(~cBit6))
#define rmEnHdmaRdBypass                         (rHdmaCtrl[rcHdmaParr1]|=cBit7)
#define rmDisHdmaRdBypass                        (rHdmaCtrl[rcHdmaParr1]&=~cBit7)
#define rmRstHdmaParam                           (rHdmaCtrl[rcHdmaParr1]=0xC0)

#define rcHdmaParr2                              0x02
#define rmHdmaOccpSaddr(uSaddr)                  (r16HdmaCtrl[rcHdmaParr2/2]|=uSaddr)
// #define rmSET_HDMAPara2                        (r16HdmaCtrl[rcHdmaParr2/2]=c16Bit15)   //Enable  TSB runtime Occupy flag
#define rmSetHdmaOccFlag(uBufIdx)                {rmHdmaEnStrOccp;r16HdmaCtrl[rcHdmaParr2/2]|=uBufIdx;}
#define rmRstHdmaParam2                          (r16HdmaCtrl[rcHdmaParr2/2]=0x0000)

#define rcHdmaParr3                              0x03
#define rmHdmaEnStrOccp                          (rHdmaCtrl[rcHdmaParr3]|=cBit6)
#define rmHdmaEnRunOccp                          (rHdmaCtrl[rcHdmaParr3]|=cBit7)

#define rcSetHdmaLen                             0x04
#define rmSetHdmaXfrLen(uUnit)                   (r32HdmaCtrl[rcSetHdmaLen/4]=uUnit)

#define rcSetHdmaOffSet                          0x08
#define rmSetHdmaDesAddr(uDesAddr)               (r32HdmaCtrl[rcSetHdmaOffSet/4]=uDesAddr)

#define rcSetRaidBGKVal                          0x08
#define rmSetRaidBGKVal(KVal)                    (r16HdmaCtrl[rcSetRaidBGKVal/2]=KVal)

#define rcSetRaidBGSctrNum                       0x0A
#define rmSetRaidBGSctrNum(SctrNum)              (r16HdmaCtrl[rcSetRaidBGSctrNum/2]=(0x0007&SctrNum))

#define rcHdmaSAddr                              0x0C    // 0x0C 0x0D 0x0E 0x0F
#define rmSetHdmaSrcAddr(uSrcAddr)               (r32HdmaCtrl[rcHdmaSAddr/4]=uSrcAddr)

// HDMA Current Cmd Status
#define rcHdmaCmdQDepth                          0x20
#define rmChkHdmaDone\
    while(rHdmaCtrl[rcHdmaCmdQDepth]!=cMaxHdmaDepth)
#define rmChkHdmaFree\
    while(!rHdmaCtrl[rcHdmaCmdQDepth])

#define rmChkHdmaCmdFifoFull                     (rHdmaCtrl[rcHdmaCmdQDepth]==0)
#define rmChkHdmaCmdFifoDpt                      rHdmaCtrl[rcHdmaCmdQDepth]
#define rmGetHdmaCmdFifoCnt                      (cMaxHdmaDepth-rHdmaCtrl[rcHdmaCmdQDepth])
#define rmChkHdmaBz                              (rHdmaCtrl[rcHdmaCmdQDepth]!=cMaxHdmaDepth)

#define rcHdmaCmdPtr                             0x24

#define rcHdmaStatus                             0x25
#define rmChkHdmaBusy                            rHdmaCtrl[rcHdmaStatus]
#define rmChkHdmaPause                           (!rHdmaCtrl[rcHdmaStatus])

#define rcEnHdmaInt                              0x26
#define rmEnHdmaInt                              (rHdmaCtrl[rcEnHdmaInt]|=cBit0)
#define rmEnHdmaBufRaidFlag                      (rHdmaCtrl[rcEnHdmaInt]|=cBit2)
#define rmDisHdmaBufRaidFlag                     (rHdmaCtrl[rcEnHdmaInt]&=~cBit2)
#define rmEnHdmaRaidFlagDes                      (rHdmaCtrl[rcEnHdmaInt]|=cBit3)
#define rmDisHdmaRaidFlagDes                     (rHdmaCtrl[rcEnHdmaInt]&=~cBit3)
#define rmEnHdmaRaidFlagSrc                      (rHdmaCtrl[rcEnHdmaInt]|=cBit4)
#define rmDisHdmaRaidFlagSrc                     (rHdmaCtrl[rcEnHdmaInt]&=~cBit4)
#define rmEnHdmaCrcCompare                       (rHdmaCtrl[rcEnHdmaInt]|=cBit5)
#define rmDisHdmaCrcCompare                      (rHdmaCtrl[rcEnHdmaInt]&=~cBit5)
#define rmEnHdmaCrcGen                           (rHdmaCtrl[rcEnHdmaInt]|=cBit6)
#define rmDisHdmaCrcGen                          (rHdmaCtrl[rcEnHdmaInt]&=~cBit6)
#define rmDisHdmaCrc                             (rHdmaCtrl[rcEnHdmaInt]|=cBit7)
#define rmEnHdmaCrc                              (rHdmaCtrl[rcEnHdmaInt]&=~cBit7)
#define rmRstHdmaInt                             (rHdmaCtrl[rcEnHdmaInt]=0x00)

#define rmRstHdmaRaidFlag                        (rHdmaCtrl[rcEnHdmaInt]&=0xE3)

#define rcHdmaResume                             0x27
#define rmHdmaResume                             (rHdmaCtrl[rcHdmaResume]=1)

// HDMA DMA Parameter
#define rcHdmaCfg                                0x28
#define rmHdmaDrmManualTrigSize512B              (rHdmaCtrl[rcHdmaCfg]=((rHdmaCtrl[rcHdmaCfg]&(~cBit1))&(~cBit0)))
#define rmHdmaDrmManualTrigSize1K                (rHdmaCtrl[rcHdmaCfg]=((rHdmaCtrl[rcHdmaCfg]&(~cBit1))|cBit0))
#define rmHdmaDrmManualTrigSize2K                (rHdmaCtrl[rcHdmaCfg]=((rHdmaCtrl[rcHdmaCfg]|cBit1)&(~cBit0)))
#define rmHdmaDrmManualTrigSize4K                (rHdmaCtrl[rcHdmaCfg]=((rHdmaCtrl[rcHdmaCfg]|cBit1)|cBit0))
#define rmHdmaEnDrmManualFlag                    (rHdmaCtrl[rcHdmaCfg]|=cBit2)
#define rmHdmaDisDrmManualFlag                   (rHdmaCtrl[rcHdmaCfg]&=(~cBit2))
#define rmHdmaTsbManualTrigSize512B              (rHdmaCtrl[rcHdmaCfg]=((rHdmaCtrl[rcHdmaCfg]&(~cBit4))&(~cBit3)))
#define rmHdmaTsbManualTrigSize1K                (rHdmaCtrl[rcHdmaCfg]=((rHdmaCtrl[rcHdmaCfg]&(~cBit4))|cBit3))
#define rmHdmaTsbManualTrigSize2K                (rHdmaCtrl[rcHdmaCfg]=((rHdmaCtrl[rcHdmaCfg]|cBit4)&(~cBit3)))
#define rmHdmaTsbManualTrigSize4K                (rHdmaCtrl[rcHdmaCfg]=((rHdmaCtrl[rcHdmaCfg]|cBit4)|cBit3))
#define rmHdmaEnTsbManualFlag                    (rHdmaCtrl[rcHdmaCfg]|=cBit5)
#define rmHdmaDisTsbManualFlag                   (rHdmaCtrl[rcHdmaCfg]&=(~cBit5))

#define rmEnHdmaDmaClkSync                       (rHdmaCtrl[rcHdmaCfg]|=cBit7)
#define rmDisHdmaDmaClkSync                      (rHdmaCtrl[rcHdmaCfg]=0)

#define rcHdmaCompOk                             0x29
#define rmChkHdmaComp                            (rHdmaCtrl[rcHdmaCompOk]&cBit0)
#define rmGetHdmaCrcFailCnt                      (rHdmaCtrl[rcHdmaCompOk]&0x06)

#define rcHdmaDramPackLen                        0x2A
#define rmSetHdmaDramPackLen(uLen)               (r16HdmaCtrl[rcHdmaDramPackLen/2]=uLen)

#define rcHdmaTsbPackLen                         0x2E
#define rmSetHdmaTsbPackLen(uLen)                (r16HdmaCtrl[rcHdmaTsbPackLen/2]=uLen)

#define rcHdmaSeed0                              0x30
#define rmSetHdmaScrbSeed0(uSeed)                (rHdmaCtrl[rcHdmaSeed0]=uSeed)

#define rcHdmaSeed1                              0x31
#define rmSetHdmaScrbSeed1(uSeed)                (rHdmaCtrl[rcHdmaSeed1]=uSeed)

#if _FLASH_TRIG_HOST
#define rcHdmaSelCls                             0x33
#define rmSetHdmaSelCls(uSelCls)                 (rHdmaCtrl[rcHdmaSelCls]=uSelCls)
#endif

#define rcBgEncPgIdx                             0x38
#define rmChkBgEncPgIdx                          r16HdmaCtrl[rcBgEncPgIdx/2]

#define rcBgEncSctrIdx                           0x3A
#define rmChkBgEncSctrIdx                        rHdmaCtrl[rcBgEncSctrIdx]

#define rcBgMemoryIdx                            0x3B
#define rmChkBgMemoryIdx                         rHdmaCtrl[rcBgMemoryIdx]

// HDMA Wrapping Control
#define rcHdmaDramHead2                          0x50
#define rmSetHdmaDramHead2(uHead)                (r32HdmaCtrl[rcHdmaDramHead2/4]=uHead)

#define rcHdmaDramTail2                          0x54
#define rmSetHdmaDramTail2(uTail)                (r32HdmaCtrl[rcHdmaDramTail2/4]=uTail)

#define rcHdmaTsbHead0                           0x58
#define rmSetHdmaTsbHead0(uHead)                 (r16HdmaCtrl[rcHdmaTsbHead0/2]=uHead)

#define rcHdmaTsbTail0                           0x5C
#define rmSetHdmaTsbTail0(uTail)                 (r16HdmaCtrl[rcHdmaTsbTail0/2]=uTail)

#define rcHdmaTsbHead1                           0x60
#define rmSetHdmaTsbHead1(uHead)                 (r16HdmaCtrl[rcHdmaTsbHead1/2]=uHead)

#define rcHdmaTsbTail1                           0x64
#define rmSetHdmaTsbTail1(uTail)                 (r16HdmaCtrl[rcHdmaTsbTail1/2]=uTail)

#define rcHdmaTsbHead2                           0x68
#define rmSetHdmaTsbHead2(uHead)                 (r16HdmaCtrl[rcHdmaTsbHead2/2]=uHead)

#define rcHdmaTsbTail2                           0x6C
#define rmSetHdmaTsbTail2(uTail)                 (r16HdmaCtrl[rcHdmaTsbTail2/2]=uTail)

#define rcHdmaDramHead0                          0x70
#define rmSetHdmaDramHead0(uHead)                (r32HdmaCtrl[rcHdmaDramHead0/4]=uHead)

#define rcHdmaDramTail0                          0x74
#define rmSetHdmaDramTail0(uTail)                (r32HdmaCtrl[rcHdmaDramTail0/4]=uTail)

#define rcHdmaDramHead1                          0x78
#define rmSetHdmaDramHead1(uHead)                (r32HdmaCtrl[rcHdmaDramHead1/4]=uHead)

#define rcHdmaDramTail1                          0x7C
#define rmSetHdmaDramTail1(uTail)                (r32HdmaCtrl[rcHdmaDramTail1/4]=uTail)

#define rcHdmaDramCacheBias                      0x80
#define rmSetHdmaDramCacheBias(Bias)             (r16HdmaCtrl[rcHdmaDramCacheBias/2]=Bias)

// HDMA Ciru Reset
#define rcHdmaDramThreshold                      0x82
#define rmHdmaDramThr(uThr)                      (r16HdmaCtrl[rcHdmaDramThreshold/2]=uThr)

#define rcHdmaMiscCtl                            0x84
#define rmHdmaSoftReset                          {rHdmaCtrl[rcHdmaMiscCtl]|=cBit0;rHdmaCtrl[rcHdmaMiscCtl]&=(~cBit0);}
#define rmRaidCodecClr                           {rHdmaCtrl[rcHdmaMiscCtl]|=cBit7;rHdmaCtrl[rcHdmaMiscCtl]&=(~cBit7);}

#define rcHdmaPauseCtl                           0x85
#define rmHdmaPause\
    {rHdmaCtrl[rcHdmaPauseCtl]|=cBit0;\
     while(!(rHdmaCtrl[rcHdmaPauseCtl]&cBit7))\
         ;\
    }
#define rmHdmaPauseClr\
    {rHdmaCtrl[rcHdmaPauseCtl]&=(~cBit0);\
     while(rHdmaCtrl[rcHdmaPauseCtl]&cBit7)\
         ;\
    }
#define rmHdmaDecInit\
    {rHdmaCtrl[rcHdmaPauseCtl]|=cBit1;\
     while(!(rHdmaCtrl[rcHdmaPauseCtl]&cBit6))\
         ;\
    }

#define rcHdmaRaidCmd                            0x88

#define rmEnRaidKValue                           (rHdmaCtrl[rcHdmaRaidCmd]|=cBit7)
#define rmRaidPtyClr                             (rHdmaCtrl[rcHdmaRaidCmd]|=cBit6)
#define rmRaidEncOnly                            (rHdmaCtrl[rcHdmaRaidCmd]|=cBit5)
#define rmRaidCmdClr                             (rHdmaCtrl[rcHdmaRaidCmd]|=cBit4)
#define rmRaidBgEnc                              (rHdmaCtrl[rcHdmaRaidCmd]|=cBit2)
#define rmSetRaidCmd(cmd)                        (rHdmaCtrl[rcHdmaRaidCmd]=cmd)
#define rmClrHdmaRaidCmd                         (rHdmaCtrl[rcHdmaRaidCmd]=0x00)

#define rcRaidCtl0                               0x89
#define rmSetRaidSctrNum(SctrNum)                (rHdmaCtrl[rcRaidCtl0]=(rHdmaCtrl[rcRaidCtl0]&0xE0)|SctrNum)
#define rmClrRaidSctrNum                         (rHdmaCtrl[rcRaidCtl0]=(rHdmaCtrl[rcRaidCtl0]&0xE0)|0x00)

#define rcRaidCtl1                               0x8A
#define rmSetRaidKValue(PgNum)                   (r16HdmaCtrl[rcRaidCtl1/2]=PgNum)
#define rmClrRaidKValue                          (r16HdmaCtrl[rcRaidCtl1/2]=0x0000)

#define rcRaidResmPgIdx                          0x8C
#define rmSetRaidResmPgIdx(index)                (r16HdmaCtrl[rcRaidResmPgIdx/2]=index)
#define rmClrRaidResmPgIdx                       (r16HdmaCtrl[rcRaidResmPgIdx/2]=0x0000)

#define rcRaidResmSctrIdx                        0x8E
#define rmSetRaidResmSctrIdx(index)              (rHdmaCtrl[rcRaidResmSctrIdx]=index)
#define rmClrRaidResmSctrIdx                     (rHdmaCtrl[rcRaidResmSctrIdx]=0x00)

#define rcParityNum                              0x8F
#define rmSetParityNum(PtyNum)                   (rHdmaCtrl[rcParityNum]=PtyNum)
#define rmClrParityNum                           (rHdmaCtrl[rcParityNum]=0x00)

#define rcRaidTermPgIdx                          0x90
#define rmChkRaidTermPgIdx                       r16HdmaCtrl[rcRaidTermPgIdx/2]
#define rmClrRaidTermPgIdx                       (r16HdmaCtrl[rcRaidTermPgIdx/2]=0x0000)

#define rcRaidTermSctrIdx                        0x92
#define rmChkRaidTermSctrIdx                     rHdmaCtrl[rcRaidTermSctrIdx]
#define rmClrRaidTermSctrIdx                     (rHdmaCtrl[rcRaidTermSctrIdx]=0x00)

#define rcRaidMergeFshCnt                        0x9A
#define rmChkRaidMergeClrThr                     rHdmaCtrl[rcRaidMergeFshCnt]
#define rmSetRaidMergeClrThr(Cnt)                (rHdmaCtrl[rcRaidMergeFshCnt]=Cnt)
#define rmClrRaidMergeClrThr                     (rHdmaCtrl[rcRaidMergeFshCnt]=0x00)

#define rcRaidMerge0Cnt                          0x9C
#define rmChkRaidMerge0Cnt                       rHdmaCtrl[rcRaidMerge0Cnt]

#define rcRaidMerge1Cnt                          0x9D
#define rmChkRaidMerge1Cnt                       rHdmaCtrl[rcRaidMerge1Cnt]

#define rcRaidMerge2Cnt                          0x9E
#define rmChkRaidMerge2Cnt                       rHdmaCtrl[rcRaidMerge2Cnt]

#define rcRaidMerge3Cnt                          0x9F
#define rmChkRaidMerge3Cnt                       rHdmaCtrl[rcRaidMerge3Cnt]

#define rcRaidMerge4Cnt                          0xA0
#define rmChkRaidMerge4Cnt                       rHdmaCtrl[rcRaidMerge4Cnt]

#define rcRaidMerge5Cnt                          0xA1
#define rmChkRaidMerge5Cnt                       rHdmaCtrl[rcRaidMerge5Cnt]

#define rcRaidE2ECtl                             0xC1
#define rmSetRaidE2eCtl                          (rHdmaCtrl[rcRaidE2ECtl]|=cBit0)
#define rmClrRaidE2eCtl                          (rHdmaCtrl[rcRaidE2ECtl]&=(~cBit0))
#define rmChkRaidCurBgEncEn                      (rHdmaCtrl[rcRaidE2ECtl]&cBit1)
#define rmDisRaidCurBgEncEn                      (rHdmaCtrl[rcRaidE2ECtl]&=(~cBit1))

#define rcRaidCtl2                               0xC2
#define rmEnRaidMergeFunc                        (rHdmaCtrl[rcRaidCtl2]|=cBit7)
#define rmDisRaidMergeFunc                       (rHdmaCtrl[rcRaidCtl2]&=(~cBit7))
#define rmSetRaidEngineSel(x)\
    (rHdmaCtrl[rcRaidCtl2]=(rHdmaCtrl[rcRaidCtl2]&0xF0)|\
                            ((x>8)?(x+3):((x>5)?(x+2):((x>2)?(x+1):x))))

#define rcRaidCtl3                               0xC3
#define rmChkRaidCurMergeEn                      (rHdmaCtrl[rcRaidCtl3]&cBit7)
#define rmSetRaidCurMergeEn                      {rHdmaCtrl[rcRaidCtl3]|=cBit7;rmEnRaidMergeFunc;}
#define rmClrRaidCurMergeEn                      {rHdmaCtrl[rcRaidCtl3]&=(~cBit7);rmDisRaidMergeFunc;}
#define rmChkRaidCurEngineSel                    ((rHdmaCtrl[rcRaidCtl3]&0x7F)-((rHdmaCtrl[rcRaidCtl3]&0x7F)>>2))
#define rmSetRaidCurEngineSel(x)\
    {(rHdmaCtrl[rcRaidCtl3]=(rHdmaCtrl[rcRaidCtl3]&0xF0)|((x>8)?(x+3):((x>5)?(x+2):((x>2)?(x+1):x))));\
     rmSetRaidEngineSel(x);}

#define rcHdmaFillPattern                        0xC8
#define rmSetHdmaPat(uPat)                       (r32HdmaCtrl[rcHdmaFillPattern/4]=uPat)

#define rcHdmaTsbThreshold                       0xCC
#define rmHdmaTsbThr(uThr)                       (r16HdmaCtrl[rcHdmaTsbThreshold/2]=uThr)

// HDMA for AES Cmd
#define rcHdaAesCmd                              0xD0
#define rmHdmaAutoAesEnc                         (rHdmaCtrl[rcHdaAesCmd]=((rHdmaCtrl[rcHdaAesCmd]&(~cBit0))|0x80))
#define rmHdmaAutoAesDec                         (rHdmaCtrl[rcHdaAesCmd]|=0x81)

#define rmHdmaAutoAesXts                         (rHdmaCtrl[rcHdaAesCmd]=((rHdmaCtrl[rcHdaAesCmd]&0x81)|cBit3))
#define rmHdmaAutoAesFxts                        (rHdmaCtrl[rcHdaAesCmd]=((rHdmaCtrl[rcHdaAesCmd]&0x81)|cBit3|cBit5))
#define rmHdmaAutoAesCbc                         (rHdmaCtrl[rcHdaAesCmd]=((rHdmaCtrl[rcHdaAesCmd]&0x81)|cBit2))
#define rmHdmaAutoAesReloadCbciv                 (rHdmaCtrl[rcHdaAesCmd]=((rHdmaCtrl[rcHdaAesCmd]&0x81)|cBit2|cBit6))
#define rmHdmaAutoAesEcb                         (rHdmaCtrl[rcHdaAesCmd]=((rHdmaCtrl[rcHdaAesCmd]&0x81)|cBit1))
#define rmHdmaDisAutoAes                         (rHdmaCtrl[rcHdaAesCmd]=0x00)

#define rcHdaAesLba                              0xD4
#define rmSetHdmaAesLba(lba)                     (r32HdmaCtrl[rcHdaAesLba/4]=lba)

#define rcHdaAesExtLba                           0xD8
#define rmSetHdmaAesExtLba(extlba)               (r16HdmaCtrl[rcHdaAesExtLba/2]=extlba)

#define rcHdaCrcFailSector                       0xDC
#define rmGetHdmaCrcFailSector                   r32HdmaCtrl[rcHdaCrcFailSector/4]    // must manual clear

#define rcDramMacCtl1                            0x103
#define rmDramBankIntLeav                        (r32HdmaCtrl[rcDramMacCtl1/4]|=cBit0)

#endif    // ifndef __REG_HDA_H__







