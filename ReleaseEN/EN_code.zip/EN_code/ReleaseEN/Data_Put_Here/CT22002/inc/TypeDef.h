







#ifndef __TYPEDEF_H__
#define __TYPEDEF_H__

#include "inc/Const.h"
#include "intrinsics.h"
#include "inc/Option.h"
#include "Common/Model.h"

#define  SIGNLE_TASK_SERVICE
#define  HOST_CMD_FAKE_MODE

#define  BYTE     unsigned char    // size:  8 bits
#define  WORD     unsigned short    // Size: 16 bits
#define  LWORD    unsigned int    // Size: 32 bits
#define  QWORD    unsigned long long    // Size: 64 bits

#define  SBYTE    signed char    // size:  8 bits
#define  SWORD    signed short    // Size: 16 bits
#define  SLWORD   signed int    // Size: 32 bits
#define  SQWORD   signed long long    // Size: 64 bits

#define  UCBYTE   unsigned char    // _Uncached unsigned char  //size:  8 bits
#define  UCWORD   unsigned short    // _Uncached unsigned short //Size: 16 bits
#define  UCLWORD  unsigned int    // _Uncached unsigned int   //Size: 32 bits
#define  UCSBYTE  signed char    // _Uncached signed char    //size:  8 bits
#define  UCSWORD  signed short    // _Uncached signed short   //Size: 16 bits
#define  UCSLWORD signed int    // _Uncached signed int     //Size: 32 bits
#define  EXTFAR   extern _Far

#define  _nop __no_operation    // KT20140818 - ARC intrinsic functions

typedef  const BYTE CBYTE;
typedef  const WORD CWORD;
typedef  const LWORD CLWORD;
typedef  const QWORD CQWORD;

// Common use phrases
// #define  cTRUE               1
// #define  cFALSE              0

#pragma pack(1)
typedef struct _BITS
{
    BYTE BIT00  : 1;
    BYTE BIT01  : 1;
    BYTE BIT02  : 1;
    BYTE BIT03  : 1;
    BYTE BIT04  : 1;
    BYTE BIT05  : 1;
    BYTE BIT06  : 1;
    BYTE BIT07  : 1;
}BITS;
#pragma pack()
typedef struct _WBITS
{
    BYTE BIT00  : 1;
    BYTE BIT01  : 1;
    BYTE BIT02  : 1;
    BYTE BIT03  : 1;
    BYTE BIT04  : 1;
    BYTE BIT05  : 1;
    BYTE BIT06  : 1;
    BYTE BIT07  : 1;

    BYTE BIT08  : 1;
    BYTE BIT09  : 1;
    BYTE BIT0A  : 1;
    BYTE BIT0B  : 1;
    BYTE BIT0C  : 1;
    BYTE BIT0D  : 1;
    BYTE BIT0E  : 1;
    BYTE BIT0F  : 1;
}WBITS;

typedef struct _LWBITS
{
    BYTE BIT00  : 1;
    BYTE BIT01  : 1;
    BYTE BIT02  : 1;
    BYTE BIT03  : 1;
    BYTE BIT04  : 1;
    BYTE BIT05  : 1;
    BYTE BIT06  : 1;
    BYTE BIT07  : 1;

    BYTE BIT08  : 1;
    BYTE BIT09  : 1;
    BYTE BIT0A  : 1;
    BYTE BIT0B  : 1;
    BYTE BIT0C  : 1;
    BYTE BIT0D  : 1;
    BYTE BIT0E  : 1;
    BYTE BIT0F  : 1;

    BYTE BIT10  : 1;
    BYTE BIT11  : 1;
    BYTE BIT12  : 1;
    BYTE BIT13  : 1;
    BYTE BIT14  : 1;
    BYTE BIT15  : 1;
    BYTE BIT16  : 1;
    BYTE BIT17  : 1;

    BYTE BIT18  : 1;
    BYTE BIT19  : 1;
    BYTE BIT1A  : 1;
    BYTE BIT1B  : 1;
    BYTE BIT1C  : 1;
    BYTE BIT1D  : 1;
    BYTE BIT1E  : 1;
    BYTE BIT1F  : 1;
}LWBITS;

typedef struct _LINKNODE16
{
    WORD u16Prev;
    WORD u16Next;
}LINKNODE16;

typedef struct _LINKNODE
{
    WORD uPrev;
    WORD uNext;
}LINKNODE;

typedef struct _LINKINFO
{
    WORD u16Head;
    WORD u16Tail;
    WORD u16Trig;
    WORD u16Cnt;
}LINKINFO;

typedef struct _BOOTCMDINFO
{
    volatile BYTE uAsignCnt;
    volatile BYTE uDoneCnt;
}BOOTCMDINFO;

typedef struct _BOOTERSINFO
{
    volatile BYTE uSysBlkIdx;
    volatile BYTE uOpt;
}BOOTERSINFO;

typedef struct _CLSDW0
{
    BYTE uNcqTag        : 5;
    BYTE ubAesRstBit    : 1;
    BYTE ubDir          : 1;
    BYTE ubPio          : 1;
    BYTE ubFpdma        : 1;
    BYTE ubAutoAct      : 1;
    BYTE ubRsv2         : 1;
    BYTE ubEnTsbPreOcc  : 1;
    BYTE ubRsv3         : 1;
    BYTE ubEnTsbBuf     : 1;
    BYTE ubEnRtOcc      : 1;
    BYTE ubPause        : 1;
    WORD u16PrdLen;
}CLSDW0;

typedef struct _DIFFTYPE2ADDRINFO
{
    WORD u16FBlock;
    WORD u16arBitMap[(cMaxChNum*cMaxIntlvWay*cMaxPlaneNum)>>4];
    WORD u16arPhyAddr[cMaxChNum*cMaxIntlvWay*cMaxPlaneNum];
}DIFFTYPE2ADDRINFO;

typedef struct _FOUNDWPRO
{
    LWORD u32Serial;
    WORD u16FBlock;
    WORD u16FreePtr;
    WORD u16EraseCnt;
    BYTE uIndex;
    BYTE uDiffType2;
}FOUNDWPRO;

typedef struct _FOUNDQINFO
{
    LWORD u32Serial;
    WORD u16FBlock;
    BYTE uSeedGrp   : 4;
    BYTE uBlkType   : 4;
    BYTE uGcFluBlkSn_B0;
}FOUNDQINFO;

typedef struct _RLH2FTABQINFO
{
    WORD u16Index;

    // WORD u16Group;
    WORD u16FBlock;
    WORD u16EraseCnt;
    LWORD u32H2fTabBlkSerial;
}RLH2FTABQINFO;

typedef struct _RLERRBLKINFO
{
    WORD u16Id;
    WORD u16FBlock;
    WORD u16EraseCnt;
}RLERRBLKINFO;

typedef struct _RLFLUSHF2HTAB
{
    LWORD u32arSerial[cMaxReBuBankNum];
    WORD u16arBlock[cMaxReBuBankNum];
    BYTE uarBankNum[cMaxReBuBankNum];
    BYTE uCnt;
}RLFLUSHF2HTAB;

typedef struct _ESFAILADDR
{
    LWORD u32EsFailSts;
    WORD u16EsFailFBlock;
    WORD u16EraseCnt;
}ESFAILADDR;

typedef struct _H2F1KTABSGMT
{
    WORD u16HSgmt;

    // BYTE ubTrig         :1;
    WORD u16HBlock;

    // BYTE ubPrep         :1;
}H2F1KTABSGMT;

typedef struct _HADDRINFO
{
    LWORD u32RestSctrCnt;
    LWORD u32HSector;
    WORD u16HPage;
    WORD u16HBlock;

    // H2F1KTABSGMT uarTabSgmt;
    WORD u16HSgmt;

    // WORD u16SgmtStHPage;
    // WORD u16CmdSrc4kCnt;
    WORD u16Srch4kCnt;

    // BYTE uServ4kCnt;
    WORD u16FlashRBufPtr;
    WORD u16SrchSrcTabStIdx;

    // BYTE uLoadTabState;
    // BYTE ubSrchDone;    // : 1;
    // BYTE ubRsv1     : 7;
    // BYTE uHSgmtCnt;

    BYTE uTabSgmtIdx;
    BYTE ubChgBlock;    // : 1;
    // BYTE ubChgPlane;    // : 1;
    BYTE ubNewSrcF;    // : 1;
    // BYTE uRsv2      : 5;
    BYTE uStartSector;
    BYTE uSrchHitCnt;
    BYTE uSrcFromH2F;

    // BYTE uHmbHitCnt;
    // BYTE uPrdIdx;
}HADDRINFO;

typedef struct _F2HTABLE
{
    WORD u16HPage;
    WORD u16HBlock;
}F2HTABLE;

typedef struct _H2FTABLE
{
    LWORD u32FPage;
    WORD u16FBlock;

    // WORD u16FBlock  :15;
    // WORD ubNonWUNC  :1;
}H2FTABLE;

typedef struct _H2FTABLER
{
    LWORD u32F4k;
    WORD u16FBlock;

    BYTE uUncType;
}H2FTABLER;

typedef struct _ERASECNTTAB
{
    WORD u16EraseCnt : 15;
    BYTE ubPopped   : 1;
}ERASECNTTAB;

typedef struct _CACHEINFO
{
    LWORD u32arDiffType2PopBit[cMaxDiffType2Num/32];
    LWORD u32CacheBlkSerial;
    LWORD u32CacheInfoSerial;
    LWORD u32H2fTabBlkSerial;
    LWORD u32FluBlkSerial;
    LWORD u32WriteSctr2ChgBlk;
    LWORD u32CacheFreePagePtr;
    LWORD u32H2f1kTabSgmtPrep;
    LWORD u32SrchF4kBase;
    LWORD u32SrchF4kBaseFlu;
    LWORD u32SrchRslFPage;

    // CPU0 & CPU1
    volatile LWORD u32CacheInfoFlag;
    volatile LWORD u32CacheInfoChangeFlag;

    // QWORD u64TotalSlcProgCnt;
    // QWORD u64TotalTlcOneShotCnt;
    // F2HTABLE *upEofF2hTab;

/* CPU0 - WORD and BYTE have to be sorted if CPU ECC enable. */
    // WORD u16F2hTabHitPtr;
    WORD u16SrchRslFBlock;
    WORD u16H2fTabFreePagePtr;
    WORD u16H2fTabPagePerBlk3;
    WORD u16F2HTabFlushStart;
    WORD u16F2HTabFlushEnd;
    WORD u16PrePopCacheBlock;
    WORD u16H2fTabPagePtrMsk;

    // WORD u16FlushF2hTabPtr;
    WORD u16ValidPgPerF2hTab;
    WORD u16TotalPgPerF2hTab;
    WORD u16MaxTotalPgPerF2hTab;
    WORD u16F2hPadStartAddr_2;
    WORD u16F2hChkFlushStart;
    WORD u16F2hChkFlushSize;

    // WORD u16debugPcieErrCnt;
    // WORD u16FlushTotalPgPerF2hTab;

/* CPU0&1 - WORD and BYTE have to be sorted if CPU ECC enable. */
    LWORD u32ModifyH2fPtrHead;    // CPU0
    LWORD u32ModifyH2fPtrTail;    // CPU1
    // WORD u16MotherBlockCnt;    // not use
    WORD u16SpareBlockCnt;    // CPU0&1
    WORD u16TLCSprBlockCnt;    // CPU0&1
    WORD u16ActiveCacheBlock;    // CPU0&1
    WORD u16CacheF2hTabFreePtr;    // CPU0&1
    WORD u16CacheBlockCnt;    // CPU0&1
    WORD u16FullCacheBlockCnt;    // CPU0&1
    WORD u16HblkCntInCache;    // CPU0&1
    WORD u16ErrCod;    // CPU0&1
    WORD u16FluCacheBlock;    // CPU0&1
    WORD u16MlcMoSkipCnt;    // CPU0&1
    WORD u16SlcMoSkipCnt;    // CPU0&1
    WORD u16TLCFullCacheBlockCnt;    // CPU0&1
    WORD u16Rsv0;

    WORD u16PartialParityPtr;
    WORD u16PartialParityPtrGc;
    WORD u16PartialParityNum;
    WORD u16PartialParityNumGc;
    WORD u16ProgRaidChStr4K;
    WORD u16Rsv1;

    WORD u16SLCSpareCnt;
    WORD u16DynamicSpareCnt;

/* CPU1  - WORD and BYTE have to be sorted if CPU ECC enable. */
    WORD u16RaidPtyFreePagePtr;
    WORD u16RaidGcPtyFreePagePtr;
    WORD u16RaidPtyPagePerBlk3;
    WORD u16Rsv2;

#if _EN_SLCOpenBlkReadScrub
    WORD u16BakF2HTabFlushStart;
    WORD u16BakF2HTabFlushEnd;
#endif

    /*******daul core flush**********/
    // LWORD u32ModifyH2fPtrHead;    // CPU0
    // LWORD u32ModifyH2fPtrTail;    // CPU1
    LWORD u32FluValidHBlkNum;    // CPU0
    LWORD u32FluModifidHBlkNum;    // CPU0&1

    /********************************/

    LWORD u32TotalEraseCnt;
    LWORD u32DynamicTotalEraseCnt;
    LWORD u32SLCTotalEraseCnt;
    LWORD u32SlcNextEraseCntThr;
    LWORD u32RecRtcTime1s;
    LWORD u32RecEntryPS4RtcStartTime1s;
    WORD u16AvgEraseCnt;
    WORD u16DynamicAvgEraseCnt;
    WORD u16SLCAvgEraseCnt;
    WORD u16Rev;    // u16TLCGcWLCnt; for 4 byte align
    // WORD u16SLCReclaimCnt;
    // WORD u16ReclaimCnt;
// #if _EN_SLCOpenBlkReadScrub
    // WORD u16SLCFlushCnt;
    // WORD u16H2FScrubCnt;
// #endif

/* CPU0 only */

    BYTE uH2fTabProgSlotShift;
    BYTE uH2fTabPagePtrShift;
    BYTE uMaxH2f2kTabSgmt;
    BYTE uFlushCacheBlkBank;
    BYTE uMaxBankNum;
    BYTE uMaxFlushBankNum;
    BYTE u4KNumToPadF2h;
    BYTE uPadF2h4KNum;
    BYTE uProgF2HRem4KNum;
    BYTE uSecNumPadF2h_1;
    BYTE uChkF2hRegion;

    // BYTE uarCacheF2hPBitTabIdx[cMaxF2hPBitTabNum];
    BYTE uH2fTabBlockCnt;
    BYTE uActH2fTabBlkIdx;
    BYTE uF2hTabBank;
    BYTE uH2f1kTabCnt;
    BYTE uH2f1kSgmtFreePtr;
    BYTE uF4kNumReadF2hTab;
    BYTE uReadF2hTabPlaneNumPerCh;
    BYTE ubSLCCacheEnable;
    BYTE uCacheEobFlag;
    BYTE ubEnDualCoreFlush;

    BYTE uRaidProcF;
    BYTE uRsv0;
    BYTE uRsv1;
    BYTE uRsv2;

/* CPU0 & CPU1 */
    BYTE uDiffType2SprBlkCnt;
    BYTE uRsv3;
    BYTE uRsv4;
    BYTE uRsv5;

    BYTE uRaidPtr;
    BYTE uRaidPtrGc;
    BYTE uRaidF2HBank;
    BYTE uRaidF2HBankGc;

/* CPU1 only */
    BYTE uRaidPtyBlockCnt;
    BYTE uRaidPtyBlkIdx;
    BYTE uRaidGcPtyBlkIdx;
    BYTE uRsv7;
}CACHEINFO;

typedef struct _GCINFO
{
    F2HTABLE *upBuildSrcF2hTabSt;
    F2HTABLE *upFlushDesF2hTabSt;
    LWORD u32GcSrcF4kPtr;
    LWORD u32GcDesF4kPtr;
    LWORD u32GcDesF4kPtr2;
    LWORD u32GcDesbFreePagePtr;

    // LWORD u32GcInfobFreePagePtr;
    // LWORD u32CorUpPtr;
    LWORD u32GcDesSerial;
    LWORD u32FluBlkSerial;
    LWORD u32TotalSlcVpc;
    LWORD u32TotalTlcVpc;
    LWORD u32TotalSrcBlkVpc;
    LWORD u32BgdGcEndTime;
    LWORD u32GcCachebTime;
    LWORD u32GcLeastBudget;
    LWORD u32GcLastS2TProcTime;
    LWORD u32GcLastT2TProcTime;
    LWORD u32GcMaxS2TProcTime;
    LWORD u32GcMaxT2TProcTime;
    LWORD u32GcLastX2TBuildSrcTabTime;
    LWORD u32GcLastX2TMoveDataTime;
    LWORD u32GcLastX2TPostWRTime;
    LWORD u32GcLastX2TFlushF2hTabTime;
    LWORD u32GcMaxS2TBuildSrcTabTime;
    LWORD u32GcMaxS2TMoveDataTime;
    LWORD u32GcMaxS2TPostWRTime;
    LWORD u32GcMaxS2TFlushF2hTabTime;
    LWORD u32GcMaxT2TBuildSrcTabTime;
    LWORD u32GcMaxT2TMoveDataTime;
    LWORD u32GcMaxT2TPostWRTime;
    LWORD u32GcMaxT2TFlushF2hTabTime;
    LWORD u32PwrOnGcStartTime;
    LWORD u32PwrOnGcEndTime;
    LWORD u32PwrOnExtraGcTimeLimit;
    LWORD u32PWRFailCnt;
    LWORD u32GcSrcBlkVpc[cMaxGcSrcBlkNum];
    LWORD u32Prog4kCntPerChIntPlnWl;
    LWORD u32Prog4kCntPerChPg;
    LWORD u32GCInfoTabSize;

    WORD u16GcPwReadPagePtr;

    // WORD u16GcSrcStUnit;

    // WORD u16GcDesbPage2ChgBlk;
    WORD u16GcDesBlock;
    WORD u16GcDesSLCBlock;
    WORD u16GcDesTLCBlock;
    WORD u16GcDesPfBlock;
    WORD u16GcDesF2hTabFreePtr;
    WORD u16GCDesValidPgPerF2hTab;
    WORD u16GCDesTotalPgPerF2hTab;
    WORD u16GCDesProgRaidChStr4K;
    WORD u16ProgRaidChStr4K;
    WORD u16PadF2hTabPgStr;
    WORD u16PadF2hTabPgEnd;
    WORD u16ProgF2hTabStr;
    WORD u16ProgF2hTabEnd;

    // WORD u16GcDesF2hTabUpdOfstSt;
    // WORD u16GcDesF2hTabUpdOfstLen;
    // WORD u16FlushDesTabCnt;
    WORD u16GcSrcBlock[cMaxGcSrcBlkNum];    // MIKEY GC
    WORD u16arGcSkipPopSrcBlock[cMaxSkipGcSrcBlkNum];
    WORD u16arGcPostWrFailBlock[32];
    WORD u16arGcPostWrFailPage[32];

    // WORD u16OccFSkipSize;
    // WORD u16OccFSkipStBufPtr;
    // WORD u16OccFSkipSizeBk;
    // WORD u16BgdClnStartSprblkThr;
    // WORD u16BgdClnStopSprblkThr;
    WORD u16GcCachebActThr;
    WORD u16BgdGcCachebActThr;
    WORD u16MtCacheBlockCnt;
    WORD u16GcIncompleteSrchFblk;
    WORD u16GcIncompleteSrchHblk;
    WORD u16GcIncompleteSrchHpg;
    WORD u16TotalPgPerF2hTab;
    WORD u16ValidPgPerF2hTab;

    // WORD u16GcDesF2hUpdSrcStUnit;
    // WORD u16DesHandlePage;
    // WORD u16SrcHandlePage;
    // WORD u16buildF2h;
    WORD u16BuSrcActH2fTab;
    WORD u16PwrStrPage;
    WORD u16PwrEofPage;
    WORD u16GcOneShotPtr;
    WORD u16EntryInPlane;
    WORD u16RemainF2h4k;
    WORD u16DumF2h4K;
    WORD u16GapOfMoveTab;

    // WORD u16HMBBufSize;
    WORD u16HmbGcCache4kCnt;
    WORD u16HmbXfrUnit;
    WORD u16RaidStrAddr;

    volatile WORD u16GcRCSlcBlock[cMaxGcPrioBlkNum];
    volatile WORD u16Gc1stPrioTlcBlock[cMaxGcPrioBlkNum];
#if _EN_SLCOpenBlkReadScrub
    volatile WORD u16FlushBlk;
    volatile WORD u16H2FReclaimBlk;
#endif
    volatile BYTE uGc1stPrioTlcBlockTyp[cMaxGcPrioBlkNum];
    volatile BYTE uGCSLCReclaimPtr;
    volatile BYTE uGcPrioTlcBlkNumPtr;
    volatile BYTE uOccTsbFlag;

    BYTE uGcPostWrFailBlockCnt;
    BYTE uTotalBankOfF2hTab;
    BYTE uGcDesType;
    BYTE uGcSrcBlkIdx[cMaxGcSrcBlkNum];    // MIKEY GC
    BYTE uGcSrcBlkCnt;
    BYTE uGcDesBlkCnt;
    BYTE uGcIncompleteSrchSrcBlkPtr;
    BYTE uGcMaxSrcBlkCnt;
    BYTE uGcH2fTabBlkIdx;
    BYTE uGcH2fTabbHiThr;
    BYTE uGcH2fTabbLoThr;
    BYTE uGcRd4kPtr;
    BYTE uGcWr4kPtr;
    BYTE uGcDesF2hTabBank;
    BYTE uGcSrcF2hTabBank;
    BYTE uPushSprbHiThr;
    BYTE uGcSkipPopSrcBlockCnt;

    // BYTE uClrOccFCnt;
    BYTE uGcDesF2hTabUpdBank;
    BYTE uGcDesF2hTabBuildBank;
    BYTE uGcDesF2hTabPWRBank;
    BYTE uGCDesF2hBankNum;
    BYTE uGCDes4KNumOfF2hTab;
    BYTE uGCDesPadF2h4KNum;
    BYTE uGCDesProgF2HRem4KNum;

    // BYTE uGCDesProgPageCnt;
    BYTE uGCDesPagePerWL;

    // BYTE uGcCorUpTabBuildBank;
    // BYTE uGcCorUpTabLoadBank;
    BYTE uS2TAmpFactor;
    BYTE uT2TOpFactor;
    BYTE uBgdGcTimeLimit;
    BYTE uPwrOnGcTimeLimit;
    BYTE uSrcHandlePageType;
    BYTE uGcIntlvPtr;
    BYTE uLoadGCTabIdx;
    BYTE uRsvSLCBlkInBgdCln;

    // BYTE uPwrOnExtraGcTimeLimit;
    // BYTE uDesHandlePageType;
    BYTE uPreProgFifo;
    BYTE uPreSrcFifo;
    BYTE uHmbGcCachePtr;
    BYTE uMaxHmbGcCacheNum;
    BYTE uHmbGcCacheCnt;
    BYTE uHmbEnGcCache;
    BYTE uHmbEnPtCache;
    BYTE uGcTypBit;
    BYTE uGcQueueCnt;
    BYTE ubBgdProcF;

    BYTE uGcFlow;
    BYTE uGcState;
    BYTE uOneShotChPtr;
    BYTE uPartTabSizeInBank;
    BYTE uHMBchg;
    LWORD u32GcFlag;
    volatile BYTE uGcBrkPwr;
#if _EN_SLCOpenBlkReadScrub
    volatile BYTE uFlushState;
#endif

    // -
    // BYTE ubGcSrcValid       : 1;//obs
    // BYTE ubGcBuildSrc       : 1;//obs
    // BYTE ubGcDesFull        : 1;
    // BYTE ubGcCloseDesb      : 1;
    // BYTE ubGcDesUpdt        : 1;//obs
    // BYTE ubGcCheckSrc       : 1;//obs
    // BYTE ubGcForceClean     : 1;
    // BYTE ubWaitLastDesfullB4S2T : 1;
    // BYTE ubGcF2hTabValid    :1;
    // BYTE ubPartialClean     :1;
    // BYTE ubStopBgdClean     : 1;
    // BYTE ubBrkBgdGcF        : 1;
    // BYTE ubUnderBgdGc       : 1;
    // BYTE ubOddPlaneProg     : 1;
    // -
    // BYTE ubGcInfobFull      : 1;
    // BYTE ubGcSrchWearF      : 1;
    // BYTE ubGc500ms          : 1;
    // BYTE ubForQBoot         : 1;
    // BYTE ubGcFlow           : 2;
    // BYTE ubUnderSlcGc       : 1;
    // BYTE ubDataBufFull      : 1;//obs
    // BYTE ubEndWrFlow        : 1;
    // BYTE ubChkDataDone      : 1;
    // BYTE ubS2TRndIO         : 1;
    // -
    // BYTE ubUnderReclaim     : 1;
    // BYTE ubGcProgGcInfo     : 1;
    // BYTE ubSrchSrcHBlkDone  : 1;
    // BYTE ubUnderGcH2FTab    : 1;
    // BYTE ubS2TReFold        : 1;
    // BYTE ubSvCacheInfo      : 1;
    // BYTE ubGcFlushDesTab    : 1;
    // BYTE ubGcS2tState       : 2;
    // BYTE ubGcS2tUpdH2fSrchHBlkDone  : 1;
    // -
    // BYTE ubPwOnGcF          : 1;
    // BYTE ubGcInfoPf         : 1;
    // BYTE ubS2tPf            : 1;
    // BYTE ubS2sPf            : 1;
    // BYTE ubGcSrchTlcWearF   : 1;
    // BYTE ubGcDesSlctBlk     : 1;
    // BYTE ubInGcFlg          : 1;
}GCINFO;

typedef struct _F2HINFO
{
    WORD u16arHPage[cMax4kNum];
    WORD u16arHBlock[cMax4kNum];
}F2HINFO;

typedef struct _PLTTABLE
{
    WORD u16HPage;
    WORD u16HBlock;
    WORD u16FPage;
    WORD u16FBlock;
}PLTTABLE;

typedef struct _RDLINKINFO
{
    LWORD u32RdlinkTimeStamp[40];
    LWORD u32arPwrOnSysBlockSerial[cRsvSysBlkNum];
    LWORD u32TotalSlcVpc;
    LWORD u32TotalTlcVpc;

    WORD u16arSysBlockEraseCnt[cRsvSysBlkNum];
    WORD u16arReBuCacheBlock[cMaxReBuCacheBlockNum];
    WORD u16arUpdH2fTabCnt[cMaxReBuH2fBlockNum];
    WORD u16arMoveH2fTab[cMaxUpdateH2fCnt];
    WORD u16arMoveH2fTabPagePtr[cMaxUpdateH2fCnt];
    WORD u16arWproBlk[cMaxWproBlkCnt];

    // move risk page
    WORD u16RiskyBlock;
    WORD u16RiskyStartPagePtr;
    WORD u16RiskyEndPagePtr;
    WORD u16RiskyFreePagePtr;
    WORD u16DummyProgPagePtr;
    WORD u16FirstEmptyPagePtr;
    WORD u16ReflashStartPagePtr;
    WORD u16ReflashEndPagePtr;
    WORD u16LastH2fTabFblk;
    WORD u16LastH2fTabFreePage;
    WORD u16BreakPage;
    BYTE uBreakIntv;
    BYTE uBreakCh;
    BYTE uBreakPlane;
    BYTE uRefreshH2fCnt;
    WORD u16ErrBlkCnt;    // 0x
    WORD u16ActH2fTabFblk;    // 0x
    WORD u16H2fTabFreePagePtr;    // 0x
    WORD u16FoundH2fTabBlkCnt;    // 0x
    // WORD u16WproBlk;    // 0x
    WORD u16FoundWproFreePtr;    // 0x
    WORD u16OrgWproBlk;    // 0x
    WORD u16MaxGrpDist;    // 0x
    WORD u16BadCacheInfoPageCnt;    // 0x
    WORD u16AbnorId;    // 0x
    WORD u16DebugId;    // 0x
    WORD u16UpdH2fTabPageCnt;    // 0x
    WORD u16BkActiveCacheBlock;    // 0x
    WORD u16BkActiveGcDesBlock;    // 0x
    WORD u16BkFluCacheBlock;    // 0x
    WORD u16BkPrePopCacheBlock;    // 0x
    WORD u16BkGcDesSlcBlock;
    WORD u16BkGcDesTlcBlock;    // 0x
    WORD u16SlcSprBlockCnt;    // 0x
    WORD u16TlcSprBlockCnt;    // 0x
    // WORD u16DbgRebuBlkF2hTab_Fpage;
    // WORD u16DbgRebuBlkF2hTab_Ch_Intlv;
    // WORD u16DbgRebuBlkF2hTab_Pln_BrkPt;
    WORD u16CacheInfoWproPagePtr;
    WORD u16CacheInfoWproBlock;
    WORD u16ProgHCnt;

    WORD u16DiffFBlock0;
    WORD u16DiffFBlock1;
    WORD u16DiffFPageNoTran;
    WORD u16BadInfoWproPagePtr;
    WORD u16BadInfoWproBlock;

    WORD u16BadInfoPhyFBlock0;
    WORD u16BadInfoPhyFBlock1;
    WORD u16BadInfoPhyFPage;
    BYTE uBadInfoPhyIntlv;
    BYTE uBadInfoPhyCh;
    BYTE uBadInfoPhyPlane;

    BYTE uarReBuCacheBlockBank[cMaxReBuCacheBlockNum];

    BYTE uCacheInfoWproIdx;
    BYTE uRebuCachebCnt;    // 0x146
    BYTE uReBuH2fBlockCnt;    // 0x
    BYTE uReBuWproCnt;
    BYTE uH2fTabBlockCnt;
    BYTE uQBootFailId;    // 0x
    BYTE uCacheInfoLastPageOpTyp;    // 0x
    BYTE uOrgCacheInfoLastPageOpTyp;    // 0x
    BYTE uGcInfoLastPageOpTyp;    // 0x
    BYTE uActH2fLastPageOpTyp;    // 0x
    BYTE uPreRdLkMigrateTyp;    // 0x
    BYTE uPowerOnExtraGcCnt;
    BYTE uPowerDownMode;
    BYTE uWproActIdx;
    BYTE uResumeFromPs4;

    BYTE ubCacheInfoValid       : 1;
    BYTE ubCacheInfoFound       : 1;
    BYTE ubSaveCacheInfo        : 1;
    BYTE ubAbnorScenario        : 1;
    BYTE ubBadInfoValid         : 1;
    BYTE ubIndexBlockFull       : 1;
    BYTE ubPageWithErr          : 1;
    BYTE ubPwrOnFromDevSlp      : 1;
    BYTE ubWproBlkFound         : 1;
    BYTE ubSporF                : 1;
    BYTE ubFoundValidRefreshBlk : 1;
    BYTE ubPwrOnByQBoot         : 1;
    BYTE ubMultiCopiesErr       : 1;
    BYTE ubPwrOnGcF             : 1;
    BYTE ubH2fTabRefreshF       : 1;
    BYTE ubRstDataInvalidF      : 1;
    BYTE ubDoNotScanAllBlk      : 1;    // 0x150
    BYTE ubRebuildFinish        : 1;
    BYTE ubPwrWrIdxBlk          : 1;
    BYTE ubBadInfoFound         : 1;
    BYTE ubPwrWrLogInfo         : 1;
    BYTE ubDoNotPushSpare       : 1;
    BYTE ubSaveIdxBlk           : 1;
    BYTE ubVdt23Triger          : 1;
    BYTE ubVdt18Triger          : 1;
    BYTE ubExistTempInfoBlk     : 1;
    BYTE ubRsvBit7              : 6;
}RDLINKINFO;

typedef struct _RLIDGRP
{
    WORD u16Id;
    WORD u16Grp;
}RLIDGRP;

typedef struct _RLGRPWIN
{
    WORD u16Grp;
    WORD u16Win;
}RLGRPWIN;

typedef struct _SATAERRLOG
{
    WORD u16ReadErrCnt;
    WORD u16AbnorRdErrCnt;
    WORD u16WriteErrCnt;
    WORD u16AbnorWrErrCnt;
    LWORD u32PortPSERR;
    LWORD u32PPBCR;

    WORD u16arDebug[16];
    WORD u16arTestCnt[32];
    BYTE uarFuncTrace[32];

    /*add new members here, 0xb0 bytes in total*/
    LWORD u32StopLBA;
    LWORD u32SataStatus;
    LWORD u32Ofst0x160;
    LWORD u32Ofst0x161;
    WORD u16AddLbaCnt;
    WORD u16PostLbaCnt;
    WORD u16WriteStopBufPtr;
    WORD u16StopHBlock;
    WORD u16StopHPage;
    BYTE uProgFifoStop;
    BYTE uCurPrdTrig;
    BYTE uFuncTracePtr;

    // BYTE uRstPhyCnt;
    BYTE uConsecIFSCnt;
    BYTE uConsecComrstCnt;

    // BYTE uClrDPSInComrstCnt;
    // BYTE uPwrOnLnkLossCnt;

    // BYTE uErrorField;
    // BYTE uDeviceField;
    // BYTE uStatusField;
}SATAERRLOG;

typedef struct _RDECCFAILADDR
{
    WORD u16Fblock;
    WORD u16Fpage;
    WORD u16EraseCnt;
    BYTE uSectorH;
    BYTE uPlaneAddr;
    BYTE uCh;
    BYTE uIntlvAddr;
    BYTE uFailID;
    BYTE uTemperture;
    BYTE uRaidDecFail;
}RDECCFAILADDR;

typedef struct _BADINFO
{
    RDECCFAILADDR uarEccFailQue[cEccFailQuedpth];
    ESFAILADDR uarEsFailQue[cEraseFailQueDpth];
    WORD u16TotalNewBadCnt;
    WORD u16NewBadInBufPtr;
    WORD u16BadInfoPageFreePtr;
    WORD u16ProgFailFblkCnt;
    WORD u16EraseFailFblkCnt;    // 20181213_KevinGG_01
    WORD u16TotalTLCEccFailCnt;
    LWORD u32BadInfoBlkSerial;
    BYTE uRdEccFailQueCnt;

    // BYTE uBadInfoBlkSerial;
    BYTE uEraseFailQueCnt;
    BYTE uBadInfoFlg;

    // BYTE ubBadInfoChg       : 1;
    // BYTE uRsv               : 6;
}BADINFO;

typedef struct _PUSHSPRINFO
{
    WORD u16FBlock  : 13;
    BYTE uPushOpt   : 3;
}PUSHSPRINFO;

typedef struct _WPROINFO
{
    BYTE uActIdx;    // current used idx
    BYTE uCnt;    // current used wpro block counts
    BYTE uSwap;
    BYTE uWPROFull;
    WORD u16WproFreePagePtr;
    WORD u16PagePerBlock3;
    WORD u16CacheInfoPlaneSize;
    LWORD u32Serial;
    WORD u16arWproBlk[cMaxWproBlkCnt];    // array size 16 byte
    WORD u16arVpCnt[cMaxWproBlkCnt];
    WORD u16arWproIdxPagePtr[cMaxWproPageType];
    BYTE uarWproIdxPtr[cMaxWproPageType];
}WPROINFO;

typedef struct _BLKCLNQUE
{
    WORD u16FBlock  : 16;

    // BYTE uClnTyp    :3;
    WORD u16FPage;
}BLKCLNQUE;

typedef struct _SYSRSVINFO
{
    BYTE uRsvSysExistFlag;
    BYTE uNextPopIndex;
    BYTE uSysRegionAvaiable[cMaxRsvSpareBlkNum/8];
}SYSRSVINFO;

typedef struct _QBOOTINFO
{
    // WORD u16arStartBuf[3];
    // BYTE uPgCnt[3];
    WORD u16Serial;
    WORD u16QBVarPgSectorCnt;
    BYTE uQBVarPgCnt;
    BYTE uSavePgCnt;
    BYTE ubQBootValid   : 1;
    BYTE uRsv           : 7;
}QBOOTINFO;

typedef struct _BZINFO
{
    // LWORD LastPhyAddrAll;
    WORD u16FBlock;
    WORD u16FPage;
    BYTE uWaitFlag;
    BYTE uStatusErrStop;
    BYTE uLastOPIndex;
    BYTE uLastFifoIdxIndex;
}BZINFO;

typedef struct _PROGH2FPARA
{
    WORD u16SbufPtr;
    WORD u16Hblock;
    WORD u16RwOpt;
    WORD u16Caller;
    BYTE uSpecialOpt;
    BYTE uWaitChBitMap;
}PROGH2FPARA;

#if _ENABLE_RAID
typedef struct _RAIDENCPARA
{
    LWORD u32ByteOfst;
    WORD u16SbufPtr;
    WORD u16TotalSctrCnt;
    WORD u16FPage;
    WORD u16TskOpt;
    BYTE uRaidOpt;
    BYTE uPageType;
}RAIDENCPARA;
#endif

typedef struct _RWCTRL
{
    WORD u16arCacheHPage[cMax4kNum];
    WORD u16arCacheHBlock[cMax4kNum];
    BYTE uPrdPtr[cMax4kNum];
#if 0
    BZINFO usWaitInfo[cMaxChNum][cCePin][cMaxDieNum];
#else
    BZINFO usWaitInfo[cMaxChNum][cMaxIntlvWay];
    BYTE uChProgFifoIdx[cMaxChNum][cMaxChFifoDepth];
    BYTE uChProgFifoHead[cMaxChNum];    // ************************//
    BYTE uChProgFifoTrig[cMaxChNum];    // for sata Write Error  //
    BYTE uChProgFifoTail[cMaxChNum];    // ************************//
    BYTE uChProgFifoCnt[cMaxChNum];
    BYTE uChProgFifoPlaneCnt[cMaxChNum];
    BYTE uChPreFifoIdx[cMaxChNum][cMaxIntlvWay][cMaxCeFifoRDepth];
    BYTE uChPreFifoHead[cMaxChNum][cMaxIntlvWay];
    BYTE uChPreFifoTail[cMaxChNum][cMaxIntlvWay];

    // BYTE uChAleCnt[cMaxChNum][4];
    // BYTE uChDmaCnt[cMaxChNum][4];
    BYTE uChPreFifoCnt[cMaxChNum];
    BYTE uChReadFifoIdx[cMaxChNum][cMaxChFifoRDepth];
    BYTE uChReadFifoHead[cMaxChNum];
    BYTE uChReadFifoTrig[cMaxChNum];
    BYTE uChReadFifoTail[cMaxChNum];
    BYTE uChReadFifoCnt[cMaxChNum];
#endif    // if 0
    BYTE uOpIdxSerial[cMaxChNum];
    BYTE uOpIdxAccCntR[cMaxChNum];
    BYTE uOpIdxAccCntW[cMaxChNum];

    // BYTE uarBopPrdPtr[cMaxQDept];
    BYTE uCmdFifoDpt[cMaxChNum];
    BYTE uRdyTyp[cMaxChNum][cMaxCePinNum];

    WORD u16LastFBlockR[cMaxChNum][cMaxIntlvWay];
    WORD u16LastFPageR[cMaxChNum][cMaxIntlvWay];
    BYTE uPreFixCmd[cMaxChNum][cMaxIntlvWay];
    BYTE uContiAddrCnt[cMaxChNum][cMaxIntlvWay];
    BYTE uChLastReadCmdWay[cMaxChNum];
    BYTE uChForceDataOut[cMaxChNum];
    BYTE uarTabPrdPtr[cPostTabDept];
    BYTE uarSrcPrdPtr[cPostSrcDept];
    BYTE uarTab2PrdPtr[cMaxRH2fTabNum];
    BYTE uarTabLinkPtr[cPrdDepth];
    F2HTABLE usSrchQ[cSrchQDepth];
    BYTE uarSrchQ2RdHaddr[cSrchQDepth];
    BYTE uarNbs2SrchQ[cSrchEnginDepth];
    BYTE uarFreeNbsSlot[cSrchEnginDepth];
    BYTE uarHdmaFifoIdx[cMaxHdmaQNum];
    BYTE uarTrigHostPrd[cPrdDepth];
    LINKNODE uarSrcCmdLink[cReadFifoDpt];
    BYTE uarFreeSrcQue[cReadFifoDpt];
    BYTE uarH2fSgmtRdyQ[cH2fSgmtRdyDept];
    BYTE uarTrigHmbPrd[cPrdDepth];

    // BYTE uarCompleHmbPrd[cPrdDepth];

    volatile LINKINFO usSrcCmdList;
    F2HTABLE usSeqSrchTriged;

    // LINKINFO usFreeSrcCmdList;
    BOOTCMDINFO usBootSrcCmdInfo;
    BOOTCMDINFO usBootDesCmdInfo;
    BOOTERSINFO usBootErsCmdInfo;

    // LWORD u32ReadAheadLbaN;
    LWORD u32ReadHostLbaN;
    LWORD u32ReadFifoLbaN;

    // LWORD u32ReadTrigLbaN;

    // LWORD u32WriteFifoLbaS;
    // LWORD u32LastLbaW;
    LWORD u32LastTrimLba;

    LWORD u32Debug1;

    // LWORD u32Debug2;
    LWORD u32Debug3;
    LWORD u32Debug4;
    LWORD u32Debug5;
    LWORD u32Debug6;

/* CPU0 - WORD and BYTE have to be sorted if CPU ECC enable. */
    WORD u16CacheInBuf;
    WORD u16ProgPageOfst;

    // WORD u16MaxProgSctrCnt;
    WORD u16MaxBufFree4kCnt;
    WORD u16BufOvfl4kThr;
    WORD u16ReadAheadSize;
    WORD u16ConsecWriteSize;

    // WORD u16ProgSctrCnt;
    WORD u16SeqSrchStPage;
    WORD u16SrchFreeCnt;
    WORD u16OccFSkipSize;
    WORD u16OccFSkipStBufPtr;
    WORD u16MskRptF2hBasePtr;

    BYTE uCacheStartSctr;
    BYTE uCacheEndSctr;
    BYTE uCachePtr;

    // BYTE uMaxFLChFifoDpt;
    // BYTE uMaxReadPageCnt;
    BYTE uConsecReadCnt;

    BYTE uFreeHSgmtCnt;
    BYTE uPreTrimCnt;
    BYTE uSeqRdHaddrIdx;
    BYTE uSrchQHead;

    // BYTE uSrchQTrig;
    BYTE uSrchQTail;
    BYTE uSrchQCnt;
    BYTE uFreeNbsSlotHead;
    BYTE uFreeNbsSlotTail;
    BYTE uFreeNbsSlotCnt;
    BYTE uTabPrdHead;
    BYTE uTabPrdTail;
    BYTE uTabPrdCnt;
    BYTE uSrcPrdHead;
    BYTE uSrcPrdTail;
    BYTE uSrcPrdCnt;
    BYTE uRwBrk;
    BYTE ubDelayTrigHost;
    BYTE uSrchQCntW;
    BYTE uMaskTgtPtr;
    BYTE uTimerFlag;

/* CPU1 - WORD and BYTE have to be sorted if CPU ECC enable. */
// Fisrt variable set LWORD to separate.
    LWORD u32AllReadFifoCnt;
    BYTE uAllOpIdxCntR;
    BYTE uHdmaAccCnt;
    BYTE uHdmaFifoHead;
    BYTE uHdmaFifoTail;
    BYTE uActTabSgmtIdx;
    BYTE uEnCacheR;

/* CPU0&1 - WORD and BYTE have to be sorted if CPU ECC enable. */
    volatile LWORD u32SeqRdFlag;
    volatile LWORD u32LdpcSyncWithCore1;
    volatile LWORD u32SeqRdCpu1Flag;

    volatile LWORD u32H2fSgmtRdyHead;    // CPU 0&1
    volatile LWORD u32H2fSgmtRdyTail;    // CPU 0
    volatile LWORD u32FreeSrcFifoHead;    // CPU 0&1
    volatile LWORD u32FreeSrcFifoTrig;    // CPU 1
    volatile LWORD u32FreeSrcFifoTail;    // CPU 1
    volatile LWORD u32ProgFifoHead;    // CPU 0
    volatile LWORD u32ProgFifoTrig;    // CPU 1
    volatile LWORD u32ProgFifoTail;    // CPU 1
    volatile LWORD u32SrchFifoPtr;    // CPU0
    volatile LWORD u32UpdFifoPtr;    // CPU 0
    volatile LWORD u32TrigHostHead;    // CPU 1
    volatile LWORD u32TrigHostTail;    // CPU 0
    // volatile LWORD u32TrigHmbHead;    // CPU 1
    // volatile LWORD u32TrigHmbTail;    // CPU 0
    // volatile LWORD u32CompleHmbHead;    // CPU 0
    // volatile LWORD u32CompleHmbTail;    // CPU 1

    // volatile BYTE uProgFifoCnt;

    // LINKNODE uarDesCmdLink[cWriteFifoDpt];
    // LINKINFO usDesCmdList;
    // LINKINFO usFreeDesCmdList;

    // BYTE uReadFifoHead;
    // BYTE uReadFifoTrig;
    // BYTE uReadFifoTail;
    // BYTE uSrcCmdFifoCnt;
    // BYTE uAllPreFifoCnt;

    // BYTE ubEnSortReadFifo   :1;
    // BYTE ubWithContRdTab : 1;
    // BYTE ubPostH2fTab   : 1;
    // BYTE ubPostH2f1kTab : 1;
    // BYTE ubRsv1         : 5;
}RWCTRL;

typedef struct _TASKENTRY
{
    WORD u16TskSBufPtr;
    BYTE uTskOpt;    // uTskWproIdx;
    BYTE uTskPgOfst;
    BYTE uTskTyp;
}TASKENTRY;

typedef struct _TASKFIFOCTRL
{
    TASKENTRY uarTskFifo[cTaskDepth];
    PROGH2FPARA usProgH2fPara;
#if _ENABLE_RAID
    RAIDENCPARA usRaidEncPara;
#endif
    LWORD u32EraseFail;
    WORD u16PopFBlk;
    WORD u16PushFBlk;

    // WORD u16PrePopFBlk;
    WORD u16Seed;
    WORD u16FBlk;
    WORD u16EraseCnt;

    // BYTE uTaskCnt;
    LWORD u32HeadPtr;    // CPU ECC must be LWORD.
    LWORD u32TailPtr;    // CPU ECC must be LWORD.

    // BYTE uChkPrePop;
}TASKFIFOCTRL;

// typedef struct _ISRCTRL
// {
//    WORD u16BufFree4kCnt;
//    BYTE uBopPrdHead;
//    BYTE uBopPrdTail;
// }ISRCTRL;

typedef struct _DIFFCACHE
{
    WORD u16CacheDiffFblkAddr[cDiffCacheSize];
    WORD u16CacheDiffFblkOfst[cDiffCacheSize];
    BYTE uDiffCachePtr;
}DIFFCACHE;

typedef struct _VDTERRLOG
{
    WORD u16Signature;
    BYTE uRwDir;
    BYTE uThermoSensVal;
    LWORD u32Vdt27FailCnt;
    LWORD u32Vdt40FailCnt;
    LWORD u32Ofst0x160;
    LWORD u32Ofst0x161;
    LWORD u32FlOfst0xC0[cMaxChNum];
    LWORD u32FlOfst0x1C8[cMaxChNum];
}VDTERRLOG;

typedef struct _NCQERRLOGINFO
{
    LWORD u32ReadLogNcqErrSec;
    LWORD u32ReadLogNcqErrLba;
    BYTE uReadLogNcqErrTag;
    BYTE uReadLogErrCode;
    BYTE uReadLogErrField;
    BYTE uReadLogExtDevice;
    BYTE uRetReadLog;
}NCQERRLOGINFO;

typedef struct _ERASEUNITPARAM
{
    LWORD u32arPattern[3];
    BYTE uTotalPass;
    BYTE uNeedVerify;
    BYTE uTotalParam;
    BYTE uRsvd;
}ERASEUNITPARAM;

typedef struct _ERASEUNITOPERATION
{
    WORD u16NextFBlock;
    WORD u16CurrBlkOpCnt;
    BYTE uPassCount;
    BYTE uParamIndex;
    BYTE uStage;
    BYTE uSkipInitBuffer;
    BYTE uContinue;
    BYTE Rsvd;
}ERASEUNITOPERATION;

/* There are only three parameters those are currently supported. */
typedef struct _ERASEUNITINFO
{
    ERASEUNITPARAM usEraseParam;
    ERASEUNITOPERATION usCurrentOperation;
    LWORD u32TotalOperationsPerBlock;
    LWORD u32TotalBlockOperations;
    LWORD u32TotalFail;
    BYTE uEraseMode;
    BYTE uEraseMethod;
}ERASEUNITINFO;

typedef struct _RWLOGTMEPERATURE
{
    LWORD g32TemperatureHour;
    LWORD g32TemperatureTick;
    BYTE uShortTermPrt;
    BYTE uShortTerm[144];
    BYTE uLongTermPrt;
    BYTE uLongTerm[42];
    BYTE uAvgShortTerm;
    BYTE uAvgLongTerm;
    BYTE uHi;
    BYTE uLo;
    BYTE uHiAvgShortTerm;
    BYTE uLoAvgShortTerm;
    BYTE uHiAvgLongTerm;
    BYTE uLoAvgLongTerm;
    BYTE uTimeInOver;
    BYTE uTimeInUnder;
    BYTE uSpecMaxOper;
    BYTE uSpecMinOper;
}RWLOGTMEPERATURE;

typedef struct _MPINFO
{
    // BYTE uarRdtLs[4096];    // first 4KB is LS for Rdt
    // BYTE uarRsvdOffset[512];    // 0x200 offset for package
    BYTE uarSerialNum[20];
    BYTE uarRsvd1[12];
    BYTE uarModelName[40];
    BYTE uarRsvd2[8];
    BYTE uarIeee[3];
    BYTE uarRsvd3[13];
    BYTE uarEui64[8];
    BYTE uarRsvd4[8];
    BYTE uarFwVersion[8];
    WORD u16MPInfoPageFreePtr;
    WORD u16MPInfoPage;
    LWORD u32MPInfoSerial;
}MPINFO;

typedef struct _LOGINFO
{
    WORD u16LogInfoBlkFreePagePtr;
    WORD u16Timer0CntLogInfo;
    LWORD u32LogInfoBlkSerial;

    // BYTE uLogInfoBlkSerial;
    BYTE uLogInfoStampStart;
}LOGINFO;

typedef struct _PCIEERRLOGINFO
{
#if (_EN_PCIE_TIME_REC||_EN_PCIE_PATH_REC)
    LWORD u32LastPcieErrTimeStamp[8];
#endif
#if _EN_PCIE_PATH_REC
    LWORD u32CurrPcieErrPath;
    LWORD u32LastPcieErrPath;
#endif

    LWORD u32LastNewCacheFreePagePtr;
    LWORD u32BkSrchF4kBaseFlu;
    LWORD u32BkFluBlkSerial;
    WORD u16debugPcieWErrCnt;
    WORD u16debugPcieRErrCnt;
    WORD u16GetWrPrdTailPtr;

    // WORD u16LastPrdFreeHeadPtr;
    // WORD u16LastPrdFreeTailPtr;
    // WORD u16LastHwFreeHeadPtr;
    // WORD u16LastHwFreeTailPtr;
    WORD u16LastOrgCacheF2hTabFreePtr;
    WORD u16LastNewCacheF2hTabFreePtr;

    // WORD u16LastWrStopBufPtr;
    WORD u16BkFluCacheBlock;
    BYTE uLastProgFifoHead;
    BYTE uLastProgFifoTrig;
    BYTE uLastProgFifoTail;
    BYTE uLastPreProgFifoTail;

    BYTE uLastBgdProcF;
    BYTE uLastWrKeep4kCnt;
    BYTE uBkFlushCacheBlkBank;
    BYTE uBkMaxFlushBankNum;
}PCIEERRLOGINFO;

typedef struct _FWDLINFO
{
    LWORD u32ChkSum;
    LWORD u32IspCodePerEndOffset;    // Record the end offset of the ISP code have been download
    WORD u16FidFreePagePtr;
    BYTE uSysRsvFwDlImageBlk;
    BYTE uFidStatus;
    BYTE uHashCmpCnt;
    BYTE uRstTag;
    BYTE uAuthPass;
}FWDLINFO;

typedef struct _SMARTERRLOG
{
    BYTE uDevCtrl[5];
    BYTE uFea[5];
    BYTE uFeaExt[5];
    BYTE uSecCnt[5];
    BYTE uSecCntExt[5];
    BYTE uLbal[5];
    BYTE uLbam[5];
    BYTE uLbah[5];
    BYTE uLbalExt[5];
    BYTE uDevHd[5];
    BYTE uCmd[5];
    BYTE uPrdPtr[5];

    BYTE uSecCntField;
    BYTE uSecCntExtField;
    BYTE uLbalField;
    BYTE uLbamField;
    BYTE uLbahField;
    BYTE uLbalExtField;
    BYTE uErrorField;
    BYTE uDeviceField;
    BYTE uStatusField;
}SMARTERRLOG;

typedef struct _PROGFAILINFO
{
    volatile LWORD u32ProgFailFlag;
    LWORD u32MaxPfProcTime;
    WORD u16PopPfFBlk;
    WORD u16SparePoolFBlk[cPopPfFBlkCnt];
    WORD u16DiffPoolFBlk[cMaxPlaneNum];
    WORD u16FBlock;
    WORD u16FPage;
    WORD u16SbufPtr[cSortH2FBufSize/(64*1024/512)];
    WORD u16Hblock[cSortH2FBufSize/(64*1024/512)];
    BYTE uarPfProgFifoPtr[cMaxPfHdlNum];
    BYTE uReProgCnt;
    BYTE uCh;
    BYTE uIntlv;
    BYTE uPlaneAddr;
    BYTE uFailedStatus;
    BYTE uPopPfFBlkCnt;
    BYTE uChLastProgFifoIdx;
    BYTE uChPrevProgFifoIdx;
    BYTE uPfParaV1;
    BYTE uPfParaV2;
    BYTE uDiffPool;
    BYTE uProgH2fCnt;
    BYTE uLastProgFifoTail;

    BYTE uLastChProgFifoTail;
    BYTE uLastChProgFifoTrig;
    BYTE uLastChProgFifoHead;
}PROGFAILINFO;

typedef struct _TRIMTOUTINFO
{
    LWORD u32TrimSourceEntryAddr;
    LWORD u32TrimLbaInfoBufIdx;
    LWORD u32TrimH2fTabBufIdx;
    WORD u16TotalValidEntryCnt;
    WORD u16ActiveH2F;
    BYTE uTotalTOutUnitCnt;
    BYTE uNowToutUnitCnt;
}TRIMTOUTINFO;

// for Nvme Abort command
typedef struct _ABORTQUEUE
{
    WORD u16StsFlag;    // Bit7:Complete, Bit6:Same SQ, Bit5:Success, Bit4:Fail, Bit0:Used
    WORD u16ToDoCnt;
    WORD u16SqId;    // 1 ~ 8
    WORD u16CqId;    // needed for manual completion
    WORD u16Cid;    // cmd id
    WORD u16AbSqId;    // SQ that holds cmd to abort
    WORD u16AbCid;    // CID for that cmd to abort
    WORD u16AbCqId;    // CID for that cmd to abort
}ABORTQUEUE;

// for Nvme Delete IO SQ Cmd
typedef struct _DELSQQUEUE
{
    WORD u16StsFlag;    // for recording command status, ie pass or fail
    WORD u16SqId;    // 1 ~ 8
    WORD u16CqId;    // needed for manual completion
    WORD u16Cid;    // cmd id
    WORD u16DelSqId;    // SQ to delete
    WORD u16DelCqId;    // CQ bond to the SQ to be deleted
}DELSQQUEUE;

// Nvme host PRD Info
// typedef struct _HOSTCMDINFO
// {
//    LWORD u32Lba;
//    LWORD u32SctrCnt;
//    BYTE uOpCode;
//    BYTE uSgl;
//    BYTE uFua;
//
//    // Information for manual compeletion
//    WORD u16SqId;    // 1 ~ 8
//    WORD u16CqId;    // needed for manual completion
//    WORD u16Cid;    // cmd id
//    // Information for trigger command
//    LWORD u32Prp1H;
//    LWORD u32Prp1L;
//    LWORD u32Prp2H;
//    LWORD u32Prp2L;
// }HOSTCMDINFO;

typedef struct _PRDQUEUE
{
    LWORD u32LbaAddr;
    LWORD u32SctrCnt;
    LWORD u32Prp1H;
    LWORD u32Prp1L;
    LWORD u32Prp2H;
    LWORD u32Prp2L;
    LWORD u32RestScrtCnt;
    LWORD u32NsId;
    LWORD u32PrdProcTime;

    WORD u16SqId;    // 1 ~ 8
    WORD u16CqId;    // needed for manual completion
    WORD u16Cid;    // cmd id
    WORD u16BufPtr;
    WORD u16PrdLen;
    WORD u16PrdRd4kCnt;    // Fixed
    WORD u16RestQRd4kCnt;    // For control post trig host read
    // WORD u16RestPrd4kCnt;    // decrease during read process.

    // BYTE uRdHAddrIdx;
    // BYTE uSelCls;
    // BYTE uXfrMode;
    // BYTE ubStatusF      : 1;
    // BYTE ubTrigF        : 1;
    // BYTE ubSeqRdF       : 1;
    // BYTE ubRsv2         : 5;
    BYTE uOpCode;
    BYTE uSgl;
    BYTE uFua;
    BYTE uStartSctr;
    BYTE ubContLba;    // : 1;
    BYTE ubSetOccF;    // : 1;
    // BYTE ubRandom4kWr   : 1;
    // BYTE ubBufOvfl      : 1;
    // BYTE ubSrcAddrOk    : 1;
    BYTE ubQRdCmd;    // : 1;
    // BYTE ubUncDetectF   : 1;
    // BYTE ubRsv1         : 1;
    BYTE uHwPrdIdx;
    BYTE uUncFlag;
    BYTE uSecFlag;
    BYTE uE2eRetry;
    BYTE uFuaDone;
}PRDQUEUE;

typedef struct _PRDINFO
{
    PRDQUEUE uarPrdQue[cPrdDepth];
    LINKNODE uarPrdLink[cPrdDepth];
    BYTE uarFreePrdQue[cPrdDepth];
    WORD u16arIdxToPrdInfo[cHwPrdDepth];    // 64, HW Prd mapping to FW Prd
    BYTE uarFreeHwPrdQue[cHwPrdDepth];    // 64
    BYTE uarSeqPrdQue[cSeqPrdDepth];

    // BYTE uPrdHead;
    // BYTE uPrdTail;
    // BYTE uPrdTrig;

    // BYTE uTagHead;
    // BYTE uTagTail;

    // BYTE uarFreePrdIdx[cPrdDepth];
    // BYTE uFreePrdHead;
    // BYTE uFreePrdTail;
    // BYTE uFreePrdCnt;
    // LINKINFO usFreePrdList;

    // BYTE uReadPrdHead;
    // BYTE uReadPrdTail;
    // BYTE uReadPrdTrig;
    // BYTE uReadPrdTaskCnt;
    volatile LINKINFO usReadPrdList;

    // WORD u16ReadPrdList4kPtr;

    // BYTE uWritePrdHead;
    // BYTE uWritePrdTail;
    // BYTE uWritePrdTrig;
    // BYTE uWritePrdTaskCnt;
    volatile LINKINFO usWritePrdList;

    // LWORD u32TotalWritePrdListSctrCnt;
    volatile LWORD u32TrigWrCmdHead;
    volatile LWORD u32TrigWrCmdTail;
    volatile LWORD u32TrigWrCmdTrig;

    WORD u16TrigHostRestSectCnt;
    WORD u16SeqRd4kRstCnt;
    BYTE uSeqPrdHead;
    BYTE uSeqPrdTail;
    BYTE uSeqRCmdCnt;
    BYTE uTrigWCmdCnt;
    BYTE uQCmdCnt;
    BYTE uTotalPrdTaskCnt;
    BYTE uFreePrdHead;
    BYTE uFreePrdTail;
    BYTE uFreeHwPrdHead;
    BYTE uFreeHwPrdTail;
    BYTE uFreeHwPrdCnt;
    BYTE uSeqRTrigCnt;
}PRDINFO;

#define cSaveable           c32Bit0
#define cNamespaceSpecific  c32Bit1
#define cChangeable         c32Bit2
// #define cSaveValid          c32Bit31

typedef struct _NVMEFEATURESEL
{
    LWORD u32Current;
    LWORD u32Default;
    LWORD u32Saved;
    LWORD u32SelSC;    // NvmeFeatureSelSC SupportedCapability;
}NVMEFEATURESEL;

typedef struct _NVMEFEATURESET
{
    NVMEFEATURESEL usArbitration;    // FID 01h
    NVMEFEATURESEL usPowerManagement;    // FID 02h
    NVMEFEATURESEL usLbaRangeType[cNamespaceMax];    // FID 03h
    NVMEFEATURESEL usTemperatureThres[2][9];    // FID 04h
    NVMEFEATURESEL usErrorRecovery[cNamespaceMax];    // FID 05h
    NVMEFEATURESEL usVolatileWc;    // FID 06h
    NVMEFEATURESEL usNumberOfQueues;    // FID 07h
    NVMEFEATURESEL usIntCoalescing;    // FID 08h
    NVMEFEATURESEL usIntVecCfg[16];    // FID 09h
    NVMEFEATURESEL usWriteAtomicityNormal[cNamespaceMax];    // FID 0Ah
    NVMEFEATURESEL usAsyncEventCfg;    // FID 0Bh
    NVMEFEATURESEL usAutoPst;    // FID 0Ch
    NVMEFEATURESEL usHostMemoryBuffer;    // FID 0Dh
    NVMEFEATURESEL usTimerStamp;    // FID 0Eh
    NVMEFEATURESEL usKeepAliveTimer;    // FID 0Fh
    NVMEFEATURESEL usHostThermalPwrMgmt;    // FID 10h
    NVMEFEATURESEL usNonOpPwrStateConfig;    // FID 11h
    NVMEFEATURESEL usSwProgress;    // FID 80h
// #ifdef _SUPPORT_FEATURE_DITM    // 20181010_Jesse_01, Add for Dell spec "ENG0013785_A01"
    NVMEFEATURESEL usDellHdDITM;    // FID D4h
// #endif
// #if _ENABLE_SCP_PLP
    NVMEFEATURESEL usPlpScp;    // FID D8h
// #endif
}NVMEFEATURESET;

#define cNvmeFeatEntryNumber    (sizeof(NVMEFEATURESET)/sizeof(NVMEFEATURESEL))
#define cNvmeFeatSavedInvalid   0xFFFFFFFF
#define cNvmeFeatSIdx           (c16Tsb0SIdx+0x08)    // First 4k reserved for host xfer

typedef struct _NVMEHMBENTRY
{
    LWORD u32AddrLow;
    LWORD u32AddrHigh;
    LWORD u32Size;
    LWORD u32Rsvd;
}NVMEHMBENTRY;

// Asynchronous Event Struct
#define cMaxAsyncCnt               (8)

// for Nvme Abort command
typedef struct _ASYNCEVENTQUEUE
{
    WORD u16SqId;    // 1 ~ 8
    WORD u16CqId;    // needed for manual completion
    WORD u16Cid;    // cmd id
}ASYNCEVENTQUEUE;

typedef struct _NVMEAERDW0
{
    BYTE uAsyncEventType;
    BYTE uAsyncEventInfo;
    BYTE uLogPageId;
    BYTE uRsvd1;
}NVMEAERDW0;

typedef union _AEREVENTSTR
{
    LWORD u32Data;
    struct
    {
        BYTE uAerErr;    // AerErr_t     AerErr;
        BYTE uAerSmart;    // AerSmart_t       AerSmart;
        BYTE uAerNotice;    // AerNotice_t      AerNotice;
        BYTE uRsvd;

        // AerIO_t           AerIO;
        // AerVendor_t       AerVendor;
    };
}AEREVENTSTR;

#define cMaskAerErr        cBit0
#define cMaskAerSmart      cBit1
#define cMaskAerNotice     cBit2
#define cMaskAerIO         cBit3
#define cMaskAerVendor     cBit4

// typedef union
// {
// BYTE    uData;
// struct
// {
// BYTE    Spare:1;
// BYTE    TempWarn:1;
// BYTE    Reliability:1;
// BYTE    ReadOnly:1;
// BYTE    MemoryFail:1;
// BYTE    uRsvd:3;
// };
// }SmartWarn_t;

typedef union _AECSTR
{
    LWORD u32Data;
    struct
    {
        BYTE uSmartWarn;    // SmartWarn_t   SmartWarn;
        BYTE uNotice;

        // BYTE      NamespaceNotice:1;
        // BYTE      FWActivateNotice:1;
        // BYTE      uRsvd:6;
        WORD u16Rsvd;
    };
}AECSTR;

typedef struct _NVMEAERSTR
{
    ASYNCEVENTQUEUE uarAsyncQueue[cMaxAsyncCnt];
    LWORD u32AerEvent;
    LWORD u32AerMask;
    BYTE uAerQueueCnt;
    BYTE uAerQueueHead;
    BYTE uAerQueueTail;
    LWORD u32AerCriticalWarning;
}NVMEAERSTR;

// Nvme Identify Controller Data V1.20

typedef struct _IDPOWERSTATEDESC
{
    WORD u16Mp;    // Maximum Power
    BYTE uRsv0;
    BYTE uMpsNops;    // Max Power Scale (bit0) and Non-Operational State (bit 1)
    LWORD u32EnLat;    // Entry Latency
    LWORD u32ExLat;    // Exit Latency
    BYTE uRrt;    // Relative Read Throughtput
    BYTE uRrl;    // Relative Read Latency
    BYTE uRwt;    // Relative Write Throughtput
    BYTE uRwl;    // Relative Write Latency
    WORD u16Idlp;
    BYTE uIps;
    BYTE uRsv1;
    WORD u16Actp;
    BYTE uApwAps;
    BYTE uRsv2;
    LWORD uarRsv3[2];
}IDPOWERSTATEDESC;

typedef struct _IDCONTROLLERDATA
{
    // Controller Capabilities and Features
    WORD u16Vid;
    WORD u16Ssvid;
    BYTE uarSn[20];    // Serial Number
    BYTE uarMn[40];    // Model Number
    BYTE uarFr[8];    // Firmware Revision
    BYTE uRab;    // Recommended Abritration Burst
    BYTE uarIeee[3];    // IEEE OUI Identifier
    BYTE uCmic;    // Controller Multi-Path I/O and Namespace Sharing Capabilities
    BYTE uMdts;    // Maximum Data Transfer Size
    WORD u16CtrlId;    // Controller ID
    LWORD u32Ver;    // Version
    LWORD u32Rtd3R;    // RTD3 Resume Latency
    LWORD u32Rtd3E;    // RTD3 Entry Latency
    LWORD u32Oaes;    // Optional Asynchronous Events Supported
    LWORD u32Ctratt;    // Controller Attributes
    BYTE uarRsvd0[12];
    BYTE uarFguid[16];    // FRU Globally Unique Identifier
    BYTE uarRsvd1[112];
    BYTE uarNvmeManaSpec[16];

    // Admin Command Set Attributes & Optional Controller Capabilities
    WORD u16Oacs;    // Optional Admin Command Support
    BYTE uAcl;    // Abort Command Limit
    BYTE uAerl;    // Asynchronous Event Request Limit
    BYTE uFrmw;    // Firmware Updates
    BYTE uLpa;    // Log Page Attributes
    BYTE uElpe;    // Error Log Page Entries
    BYTE uNpss;    // Number of Power States Support
    BYTE uAvScc;    // Admin Vendor Specific Command Configuration
    BYTE uApsta;    // Autonomous Power State Transition Attributes
    WORD u16Wctemp;    // Warning Composite Temperature Threshold
    WORD u16Cctemp;    // Critical Composite Temperature Threshold
    WORD u16Mtfa;    // Maximum Time for Firmware Activation
    LWORD u32HmPre;    // Host Memory Buffer Preferred Size
    LWORD u32HmMin;    // Host Memory Buffer Minimum Size
    QWORD u64TnvmCapQw0;    // Total NVM Capacity QW0
    QWORD u64TnvmCapQw1;    // Total NVM Capacity QW1
    QWORD u64UnvmCapQw0;    // Unallocated NVM Capacity QW0
    QWORD u64UnvmCapQw1;    // Unallocated NVM Capacity QW1
    LWORD u32Rpmbs;    // Replay Protected Memory Block Support
    WORD u16Edstt;    // Extended Device Self-test Time (317:316)
    BYTE uDsto;    // Device Self-test Options (318)
    BYTE uFwUg;    // Firmware Update Granularity (319)
    WORD u16Kas;    // Keep Alive Support (321:320)
    WORD u16Hctma;    // Host Controlled Thermal Management Attributes (323:322)
    WORD u16MnTmt;    // Minimum Thermal Management Temperature (325:324)
    WORD U16MxTmt;    // Maximum Thermal Management Temperature (327:326)
    LWORD u32SaniCap;    // Sanitize Capabilities (331:328)
    BYTE uarRsvd2[180];

    // NVM Command Set Attributes
    BYTE uSqEs;    // Submission Queue Entry Size
    BYTE uCqEs;    // Completion Queue Entry Size
    WORD uMaxCmd;    // Maximum Outstanding Commands
    LWORD u32Nn;    // Number of Namespaces
    WORD u16Oncs;    // Optional NVM Command Support
    WORD u16Fuses;    // Fused Operation Support
    BYTE uFna;    // Format NVM Attributes
    BYTE uVwc;    // Volatile Write Cache
    WORD u16Awun;    // Atomic Write Unit Normal
    WORD u16Awupf;    // Atomic Write Unit Power Fail
    BYTE uNvScc;    // NVM Vendor Specific Command Configuration
    BYTE uRsvd3;
    WORD u16AcWu;    // Atomic Compare & Write Unit
    BYTE uarRsv4[2];
    LWORD u32SglS;    // SGL Support
    BYTE uarRsvd5[228];
    BYTE uarSubqn[256];
    BYTE uarRsvd6[768];
    BYTE uarNvmeFrbricsSpec[256];

    // Power State Descriptors
    IDPOWERSTATEDESC uarPsd[32];    // Power State Descriptors
    // Vendor Specific
    BYTE uarVs[1024];
}IDCONTROLLERDATA;

// Nvme Identify Namespace Data V1.20
typedef struct _LBAFORMAT
{
    WORD u16Ms;    // Metadata Size
    BYTE uLbaDs;    // LBA Data Size
    BYTE uRp;    // Relative Performance
}LBAFORMAT;

typedef struct _IDNAMESPACEDATA
{
    LWORD u32NszeL;    // Namespace Size Low DW
    LWORD u32NszeH;    // Namespace Size High DW
    LWORD u32NcapL;    // Namespace Capacity Low DW
    LWORD u32NcapH;    // Namespace Capacity High DW
    LWORD u32NuseL;    // Namespace Utilization Low DW
    LWORD u32NuseH;    // Namespace Utilization High DW
    BYTE uNsFeat;    // Namespace Features
    BYTE uNlbaf;    // Number of LBA Formats
    BYTE uFlbas;    // Formatted LBA Size
    BYTE uMc;    // Metadata Capabilities
    BYTE uDpc;    // End-to-end Data Protection Capabilities
    BYTE uDps;    // End-to-end Data Protection Type Settings
    BYTE uNmic;    // Namespace Multi-path I/O and Namespace Sharing Capabilities
    BYTE uResCap;    // Reservation Capabilities
    BYTE uFpi;    // Format Progress Idicator
    BYTE uDlfeat;
    WORD u16Nawun;    // Namespace Atomic Write Unit Normal
    WORD u16Nawupf;    // Namespace Atomic Write Unit Power Fail
    WORD u16Nacwu;    // Namespace Atomic Compare & Write Unit
    WORD u16Nabsn;    // Namespace Atomic Boundary Size Normal
    WORD u16Nabo;    // Namespace Atomic Boundary Offset
    WORD u16Nabspf;    // Namespace Atomic Boundary Size Power Fail
    BYTE uarRsv1[2];
    QWORD u64arNvmCap[2];    // NVM Capacity
    BYTE uarRsv2[40];
    BYTE uarNguid[16];    // Namespace Globally Unique Identifier
    BYTE uarEui64[8];    // IEEE Extended Unique Identifier
    LBAFORMAT uarLbaF[16];
    BYTE uarResC0[192];
    BYTE uarVs[3712];
}IDNAMESPACEDATA;

typedef struct _IDNSIDENFICATIONDESC
{
    BYTE uNidt;    // Namespace Identifier Type
    BYTE uNidl;    // Namespace Identifier Length
    WORD u16Rsvd1;
    BYTE uarNid[16];    // Just for longest NIDL, might overlap with next desc if the NIDL!=0x10
}IDNSIDENFICATIONDESC;

typedef struct _IDCONTROLLERLISTDATA
{
    WORD u16NumIdentifier;
    WORD u16Idetifier[2047];
}IDCONTROLLERLISTDATA;

// Nvme Status Code Definitions
typedef struct _CMDSTRUCT
{
    LWORD u32Dword0;
    LWORD u32Dword10;
    LWORD u32Dword11;
    LWORD u32Dword12;
    LWORD u32TimeStamp;
}CMDSTRUCT;

// Nvme Prd
typedef struct _NVMEPRDSTRUCT
{
    LWORD u32Dword0;
    LWORD u32Dword1;
    LWORD u32Dword5;
    LWORD u32Dword6;
    LWORD u32TimeStamp;
}NVMEPRDSTRUCT;

typedef struct _ADDRINFO
{
    // LWORD u32Serial;
    LWORD u32FPageNoTran;
    WORD u16BufPtr;
    WORD u16AbstractFBlock;
    WORD u16RwOpt;
    WORD u16FBlock;
    WORD u16FPage;
    BYTE uDieAddr;
    BYTE uCe;
    BYTE uIntlvAddr;
    BYTE uCh;
    BYTE uPlaneAddr;
    BYTE uSectorH;
    BYTE uOpTyp;
    BYTE uPlaneCnt;
    BYTE uRwHalfKb;
    BYTE uOpIdxSerial;
    BYTE uAddrOpt;    // uBlkId bit7~4,ubProgFail bit3, ubDone bit2, ubSkipClrOccF bit1, ubClrOccF bit0
    BYTE uStartPlaneAddr;

    // BYTE uOrgSectorH;
    BYTE uPrdPtr;
    BYTE uTsb4kIdx;
    BYTE uReadBufSerl;
    BYTE uSrcIdx;
    BYTE uDmaCnt;

    // BYTE uSprSetDone: 1
    // BYTE uTabSpar: 2
    // BYTE uSparUseCnt: 2
    // BYTE uPageSelCmd: 3
    BYTE uSprOpt;
}ADDRINFO;

typedef struct _RETRYINFO
{
    ADDRINFO usReadRetryAddr;
    BYTE uRetryPageTyp;
    BYTE uRetryOpt;
    BYTE uRetryTabTyp;
    BYTE uRetryStartLevel;
    BYTE uLdpcMode;
    BYTE uSprEccBit;
    WORD u16DataEccBit;
}RETRYINFO;

typedef struct _WORDINBYTE
{
    BYTE LowByte;
    BYTE HighByte;
}WORDINBYTE;

typedef struct _LWORDINBYTE
{
    BYTE LowByte : 8;
    BYTE mLowByte : 8;
    BYTE mHighByte : 8;
    BYTE HighByte : 8;
}LWORDINBYTE;

typedef struct _BLKSPRINFO
{
    WORD u16Seed;

    union
    {
        WORD u16all;
        WORDINBYTE us2BYTE;
    }u16Spr0;

    union
    {
        WORD u16all;
        WORDINBYTE us2BYTE;
    }u16Spr1;

    union
    {
        WORD u16all;
        WORDINBYTE us2BYTE;
    }u16Spr2;

    union
    {
        WORD u16all;
        WORDINBYTE us2BYTE;
    }u16Spr3;

    union
    {
        WORD u16all;
        WORDINBYTE us2BYTE;
    }u16Spr4;

    union
    {
        WORD u16all;
        WORDINBYTE us2BYTE;
    }u16Spr5;

    union
    {
        WORD u16all;
        WORDINBYTE us2BYTE;
    }u16Spr6;

    union
    {
        WORD u16all;
        WORDINBYTE us2BYTE;
    }u16Spr7;

    union
    {
        WORD u16all;
        WORDINBYTE us2BYTE;
    }u16Spr8;

    union
    {
        LWORD u32all;
        LWORDINBYTE us4BYTE;
    }u32Spr9and10;

    union
    {
        WORD u16all;
        WORDINBYTE us2BYTE;
    }u16Spr11;
}BLKSPRINFO;

typedef struct _HMBPRDQ
{
    LWORD u32HmbAddrLow;

    // LWORD u32HmbAddrHigh;
    LWORD u32SctrCnt;

    // LWORD u32TrigMo;
    WORD u16BufPtr;
    WORD u16HmbIdx;
    BYTE uOpCode;
    BYTE uFuncId;
    BYTE uSgmtIdx;
    BYTE uSrcIdx;
}HMBPRDQ;

typedef struct _HMBINFO
{
    // WORD u16H2fBackup[c16HmbMaxTableNum];
    LINKNODE16 uarHmbLink[c16HmbMaxTableNum];
    WORD u16arFreeHmbQ[c16HmbMaxTableNum];
    LWORD u32HmbStAddr[cHmbStAddrNum];
    HMBPRDQ uarHmbPrdQ[cMaxRH2fTabNum];

    // LINKNODE uarHmbPrdLink[cMaxRH2fTabNum];
    // BYTE uarFreeHmbPrdQ[cMaxRH2fTabNum];
    // BYTE uarHmbSgmtRdyQ[cMaxRH2fTabNum];
    // LWORD u32HmbCacheHp[cMax4kNum];    // 2260
    // WORD u16HmbCacheHb[cMax4kNum];    // 2260
    // WORD u16IdxToHmbPrdQ[32];
    // LINKINFO usHmbPrdList;
    LINKINFO usHmbList;

    // WORD u16HmbCacheBufPtr;

    // WORD u16HmbCacheSize;    // 2260
    WORD u16FreeHmbHead;
    WORD u16FreeHmbTail;

    // BYTE uFreeHmbPrdHead;
    // BYTE uFreeHmbPrdTail;
    BYTE uHmbSgmtRdyHead;
    BYTE uHmbSgmtRdyTail;
    BYTE uHmbSgmtRdyCnt;

    // BYTE uHmbCacheCnt;    // 2260
    // BYTE uHmbCache4kPtr;//2260
    BYTE uHmbHwPrdHead;
    BYTE uHmbHwPrdTail;
    BYTE uHmbFreeHwPrdCnt;
    BYTE uHmbCache4kCnt;

    BYTE uHmbValid;
    BYTE uHmbEnable;
    BYTE uHmbStsChg;

    BYTE uHmbSwichChkTimer;

    // BYTE uHmbEnWrCache;
    // BYTE uHmbEnRdCache;
    BYTE uHmbEnGcCache;
    BYTE uHmbEnPtCache;

    // BYTE uHmbEnGcInfoCache;
#if _ENABLE_HMB_FLUSH
    WORD u16HmbLastDirtyPtr;
#endif
    BYTE uRdCrcIdx;
    BYTE uWrCrcIdx;
}HMBINFO;

// typedef struct _HMBREQ
// {
//    LWORD u32HmbAddr;
//    WORD u16BufIdx;
//    WORD u16XferSecCnt;
//    WORD u16H2fIdx;
//    BYTE uDir;
//    BYTE uType;
//    BYTE uHwPrd;
// }HMBREQ;

// typedef struct _HMBQINFO
// {
//    HMBREQ usHmbReqQ[cHmbReqDept];
//    BYTE uHead;
//    BYTE uTrig;
//    BYTE uTail;
//    BYTE uState;    // cHmbEngIdle or cHmbEngBusy
// }HMBQINFO;

typedef struct _VENDORCMDDEBUGINFO
{
    // 0x00
    BYTE uarDebugInfoTag[16];    // Fix Pattern, don't change

    // 0x10
    BYTE uRunMode;    // 0:Impossible, 1:MPISP,  2:ISP,  3:ROMDEBUG
    BYTE uStatus;    // 0:Fail, 1:Success
    BYTE uErrorType;
    BYTE uNvmeSubCmdOpCode;
    BYTE uarRsv0[12];

    // 0x20
    LWORD u32NvmeSubCmdParam0;
    LWORD u32NvmeSubCmdParam1;
    LWORD u32NvmeSubCmdParam2;
    LWORD u32NvmeSubCmdParam3;

    // 0x30
    LWORD u32StartTime;
    LWORD u32EndTime;
    LWORD u32DataStartAddr;
    LWORD u32DataEndAddr;

    // 0x40~0x1FF
    BYTE uarDebugInfo[0x1C0];    // Debug Info (448Bytes)
}VENDORCMDDEBUGINFO;

typedef struct _VendorRwOption
{
    BYTE ubEnScrambler      : 1;    // Bit0
    BYTE ubDisEcc           : 1;    // Bit1
    BYTE ubForce1Plane      : 1;    // Bit2
    BYTE ubNoReadSpare      : 1;    // Bit3
    BYTE ubEnMaxEcc         : 1;    // Bit4
    BYTE ubRsv1             : 1;    // Bit5
    BYTE ubDisDiffAddr      : 1;    // Bit6
    BYTE ubEnSlcMode        : 1;    // Bit7
}VendorRwOption;

// NVMe Error Information (Log Identifier 01h)
typedef struct _ERRORINFO
{
    LWORD u32arErrorCount[2];
    WORD u16SubmissionQueueId;
    WORD u16CommandId;
    WORD u16StatusField;
    WORD u16ParameterErrorLocation;
    LWORD u32arLba[2];
    LWORD u32Namespace;
    BYTE uVendorSpecificInformationAvailable;
    BYTE uarReserved0[3];
    LWORD u32CommandSpecificInformation[2];    // currently only used in Namespace Management
    BYTE uarReserved1[24];
}ERRORINFO;

typedef struct _SMARTCNT
{
    QWORD u64ControllerBusyTimeMs;
    QWORD u64PowerOnSec;
    QWORD u64WcTempElapsedTimeSec;
    QWORD u64CcTempElapsedTimeSec;
    QWORD u64MediaDataIntegrityErr;
    LWORD u32TotalUncCnt;

    // LWORD u32RsvVar0;
    WORD u16FeatureFID4Cnt;
    WORD u16FeatureFID4failCnt;
}SMARTCNT;

typedef struct _SMARTSTATUS
{
    LWORD u32KeepSmartRtcTimeStamp;
    LWORD u32RtcStartTimeWcTemp;
    LWORD u32RtcStartTimeCcTemp;
    WORD u16OverTempThres;
    WORD u16UnderTempThres;
    BYTE uarSaveIspRev[8];
    BYTE uNextFwSlot;
    BYTE uCurrFwSlot;
    BYTE uSavedFwSlotBitMap;
    BYTE uOverTempBitMap;
    BYTE uWuncEver;
    BYTE uRsvd0;
}SMARTSTATUS;

typedef struct _SMARTATTRIBUTE
{
    SMARTCNT usCnt;
    SMARTSTATUS usStatus;
}SMARTATTRIBUTE;

// NVMe SMART / Health Information (Log Identifier 02h)
typedef struct _SMARTINFO
{
    BYTE uCriticalWarning;
    BYTE uCompositeTemperate[2];    // For word aligned
    BYTE uAvailableSpare;
    BYTE uAvailableSpareThreshold;
    BYTE uPercentageUsed;
    BYTE uarRsvd0[26];
    QWORD u64arDataUnitsRead[2];
    QWORD u64arDataUnitsWritten[2];
    QWORD u64arHostReadCommands[2];
    QWORD u64arHostWriteCommands[2];
    QWORD u64arControllerBusyTime[2];
    QWORD u64arPowerCycles[2];
    QWORD u64arPowerOnHours[2];
    QWORD u64arUnsafeShutdowns[2];
    QWORD u64arMediaAndDataIntegrityErrors[2];
    QWORD u64arNumOfErrorLogEntries[2];
    LWORD u32WarningCompositeTemperatureTime;
    LWORD u32CriticalCompositeTempTime;
    WORD u16arTemperatureSensor[8];
    LWORD u32ThermalMT1TransitionCount;    // NVMe 1.3 [219:216]
    LWORD u32ThermalMT2TransitionCount;    // NVMe 1.3 [223:220]
    LWORD u32TotalTimeForThermalMT1;    // NVMe 1.3 [227:224]
    LWORD u32TotalTimeForThermalMT2;    // NVMe 1.3 [231:228]
#if 0    // Jira-75, don't return unexpected data here
    // debug log, should be removed before formal deliver to customer
    BYTE uarRsvd1[0xD8];
    WORD u16FwSpareBlkCnt;    // [449:448]
    WORD u16FwMinSpareBlkCnt;    // [451:450]
    WORD u16FwTlcSprBlockCnt;    // [453:452]
    WORD u16FwMinTlcSprBlockCnt;    // [455:454]
    WORD u16FwSlcMoSkipCnt;    // [457:456]
    WORD u16FwMlcMoSkipCnt;    // [459:458]
    WORD u16FwFullCacheBlockCnt;    // [461:460] //closed SLC
    WORD u16FwTLCFullCacheBlockCnt;    // [463:462] // close TLC
    BYTE uGcT2tOpFactor;    // [464]
    BYTE uGcRsvValue[3];    // [467:465]
    BYTE uarRsvd3[0x1C];    // [495:468]
    BYTE uHmbFlag;    // [496]
    BYTE udebugFlag[3];    // [499:497]
    BYTE uarRsvd4[0xC];    // [511:500]
#else    // if 1
    BYTE uarRsvd1[280];    // Spec structure total 512byte
#endif    // if 1
    SMARTATTRIBUTE usSmart;    // Backup runtime smart(gsSmart) value
    BYTE uarRsvd2[0xE00-sizeof(SMARTATTRIBUTE)];    // Expand reserved space to 4k for future use
}SMARTINFO;

// Dell Smart (Log Identifier CAh) 20181203_SamHu_01
typedef struct _DELLSMARTINFO
{
    BYTE uReAssignedSectorCount;    // [0] Re-Assigned Sector Count
    BYTE uProgramFailCountWorst;    // [1] Program Fail Count (Worst Case Component)
    BYTE uProgramFailCountTotal;    // [2] Program Fail Count (SSD Total)
    BYTE uEraseFailCountWorst;    // [3] Erase Fail Count (Worst Case Component)
    BYTE uEraseFailCountTotal;    // [4] Erase Fail Count (SSD Total)
    BYTE uWearLevelingCount;    // [5] Wear Leveling Count
    BYTE uUsedReservedBlockCountWorst;    // [6] Used Reserved Block Count (Worst Case Component)
    BYTE uUsedReservedBlockCountTotal;    // [7] Used Reserved Block Count (SSD Total)
    LWORD u32ReservedBlockCountTotal;    // [11:8] Reserved Block Count (SSD Total)
    BYTE uarRsvd1[500];
}DELLSMARTINFO;

// Lenovo DFh(Log Identifier DFh) 20190107_SamHu_01
typedef struct _LENOVOLOGDF
{
    BYTE uarUpperCaseCharacters[4];
    BYTE uarRsvd1[16];
    BYTE uarOriginal8SLabel[30];
    BYTE uarSupplierModelNumber[40];
    BYTE uarSupplierSerialNumber[20];
    BYTE uarCurrent8SLabel[30];
    BYTE uarRsvd2[84];
    LWORD NANDWriteIn512KBLower;
    LWORD NANDWriteIn512KBMiddle;
    LWORD NANDWriteIn512KBUpper;
    LWORD NANDWriteIn512KBUnused;
    LWORD CRCErrorCNT;
    LWORD SLCNANDWriteIn512KBLower;
    LWORD SLCNANDWriteIn512KBMiddle;
    LWORD SLCNANDWriteIn512KBUpper;
    LWORD SLCNANDWriteIn512KBUnused;
    BYTE PercentageUsed;
    BYTE uarRsvd3[251];
}LENOVOLOGDF;

typedef struct _PLPSTATISTICS
{
    LWORD u32CompletedPLPCount;
    LWORD u32IncompletedPLPCount;
    BYTE uarReservedForOPPE1[4];
    BYTE uarReservedForOPPE2[4];
    BYTE uarReservedForOPPE3[4];
    BYTE uarReservedForOPPE4[4];
    BYTE uarReservedForFutureUse[8];
    BYTE uarRsvd1[480];
}PLPSTATISTICS;

// NVMe Firmware Slot Information (Log Identifier 03h)
typedef struct _FWSLOTINFO
{
    // BYTE uAFI;    // Active Firmware Info
    // BYTE uarRsvd0[7];
    BYTE uarFrs[8][8];    // Firmware Revision for Slot AFI/1~7
    BYTE uarRsvd1[448];
}FWSLOTINFO;

// NVMe Commands Supported and Effects (Log Identifier 05h)
typedef struct _CMDEFFECTLOG
{
    LWORD u32arAcs[256];    // Admin Command Supported
    LWORD u32arIocs[256];    // I/O Command Supported
    LWORD u32arReserved[512];
}CMDEFFECTLOG;

typedef struct _INTELRDTTELEMMETRY
{
    QWORD u64Version;
    QWORD u64RealloSctrCnt;
    QWORD u64RealloSctrCntSlc;
    QWORD u64PwrOnHours;
    QWORD u64UncErrCnt;
    QWORD u64UncErrCntSlc;
    QWORD u64EccUncSoftLdpcfail;
    QWORD u64SoftLdpcCorrectCnt;
    QWORD u64ReadRetryFail;
    QWORD u64ReadRetryFailSlc;
    QWORD u64Temperature;
    QWORD u64ReadRetryTrigger;
    QWORD u64TotalLbaWritten;
    QWORD u64TotalLbaRead;
    QWORD u64Ps3Cnt;
    QWORD u64Ps4Cnt;
    QWORD u64L12Cnt;    // 2262 no L12 cnt
    QWORD u64AvailSpareBlk;
    QWORD u64AvailSpareBlksSlc;
    QWORD u64WearRangeDelta;
    QWORD u64WearRangeDeltaSlc;
    QWORD u64HighTemp;
    QWORD u64LowTemp;
    QWORD u64AvgTemp;
    QWORD u64RecentHigh;
    QWORD u64RecentLow;
    QWORD u64AutoCalFail;
    QWORD u64NandDataRead;
    QWORD u64NandDataReadSlc;
    QWORD u64ValidBlkCnt;
    QWORD u64NandDataWrite;
    QWORD u64NandDataWriteSlc;
    QWORD u64WearLevelingCnt;
    QWORD u64WearLevelingCntSlc;
    QWORD u64WearLevelingNandWr;
    QWORD u64WearLevelingNandWrSlc;
    QWORD u64CurrSpareSuperBlk;
    QWORD u64CurrSpareSuperBlkSlc;
    QWORD u64Slc2TlcDefragCnt;
    QWORD u64DefragCnt;
    QWORD u64DefragCntSlc;
    QWORD u64ReadBackFailCnt;
    QWORD u64ProgramFailCnt;
    QWORD u64ProgramFailCntSlc;
    QWORD u64EraseFailCnt;
    QWORD u64EraseFailCntSlc;
    QWORD u64EraseCycleAvg;
    QWORD u64EraseCycleMax;
    QWORD u64EraseCycleMin;
    QWORD u64EraseCycleAvgSlc;
    QWORD u64EraseCycleMaxSlc;
    QWORD u64EraseCycleMinSlc;
    QWORD u64Ps0toPs1;
    QWORD u64Ps1toPs0;
    QWORD u64Ps1toPs2;
    QWORD u64Ps2toPs1;
    QWORD u64Ps2toPsShutDown;
    QWORD u64LinkDownShift;
    QWORD u64IdleSleepCnt;
    QWORD u64L1EventCnt;
    QWORD u64EcrcEventCnt;
    QWORD u64LcrcEventCnt;
    QWORD u64Slc2TlcProgCntIdle;
    QWORD u64Slc2TlcProgCntActivity;
    QWORD u64DramOneBitErrCnt;    // =512
    QWORD u64SramOneBitErrCnt;
    QWORD u64E2eDetectCnt;
    QWORD u64Ps3p5Cnt;
    QWORD u64ThrottlingLightCnt;    // CSSD-5321
    QWORD u64ThrottlingHeavyCnt;    // CSSD-5321
    QWORD u64ThrottlingLightDuration;    // CSSD-5321
    QWORD u64ThrottlingHeavyDuration;    // CSSD-5321
    QWORD u64RetryCnt;    // CSSD-5321
    QWORD u64SoftDecodeCnt;    // CSSD-5321
    QWORD u64WaiInteger;
    QWORD u64WaiDecimal;
    QWORD u64TotalPcieRdErrCnt;
    QWORD u64TotalPcieWrErrCnt;
}INTELRDTTELEMMETRY;

typedef struct _GBINFO
{
    BYTE uStag;
    BYTE uGreyBoxItem;
    BYTE uGreyBoxOpt;
    BYTE uResult;
    LWORD u32BkValue;
    LWORD u32LBA;
    LWORD u32BurnInStart;
    LWORD u32LBATag;
    LWORD u32BurnInCnt;
    BYTE upParaTab[cParaTabCnt];
}GBINFO;

typedef struct _UTINFO
{
    QWORD u64UtPath;
    LWORD u32UtItem;
    LWORD u32UtFunc;
    LWORD u32UtCase;
}UTINFO;

typedef struct _MUTEXINFO
{
    LWORD u32CoreLock0;
    LWORD u32CoreLock1;
    LWORD u32Lock;
}MUTEXINFO;

typedef struct _BOOTMUTEXINFO
{
    BYTE uAddSrcAddrLock;
    BYTE uAddDoneSrcAddrLock;
    BYTE uAddDesAddrLock;
    BYTE uAddDoneDesAddrLock;
}BOOTMUTEXINFO;

typedef struct _SORTF2HTAB
{
    LWORD u32arRslOfst[c16CacheF2hSize];
    WORD u16arH2fPage[c16CacheF2hSize];    // +0xC000
    BYTE uHBlkBitMap[c16MaxH2fTabNum/8];    // +0x12000
    WORD u16HBlock[c16MaxH2fTabNum];    // +0x12480
    WORD u16HBlockStartOft[c16MaxH2fTabNum];    // +0x16C80
    BYTE uH2FRamPtr[c16MaxH2fTabNum];    // +0x1B480
    LWORD u32H2fTableAddr[4];    // +0x1D880
    WORD u16H2fTableBufPtr[4];    // +0x1D890
    LWORD u32HblkNum;    // +0x1D898
    LWORD u32DoneHBlkNum;    // 1D89C
    LWORD u32LoadHBlkNum;    // 1D8A0
    LWORD u32ProgH2fTabNum;    // 1D8A4
    LWORD u32LoadH2FPtr;    // 1D8A8
    LWORD u32arCacheBlkVpCnt[2];    // 1D8AC
    LWORD u32TotalSlcVpc;
    LWORD u32TotalTlcVpc;
    LWORD u32SortH2FTabNum;
}SORTF2HTAB;

#pragma pack(1)
typedef struct _DramlessParamTab
{
    // 0x00~0x0F
    BYTE XgarParaPageId[10];
    BYTE uRsv0;
    BITS XgbsCardMode;
    BITS XgbsFLParam;
    BITS XgbsFLOption;
    WORD Xg16BadinfoUnitSecNum;

    // 0x10~0x1F
    BYTE XgChMap;
    BYTE XgCeMap;
    BYTE XgIntlvWay;
    BYTE uRsv1;
    BYTE XgSectorPerPageF;
    BYTE XgSectorPerPageH;
    BYTE XgSectorPerPlaneF;
    BYTE XgSectorPerPlaneH;
    BYTE XgarFlashVendorId[8];

    // 0x20~0x2F
    BYTE XgarSysBlock[12];
    WORD Xg16First16BlkBitMap;
    BYTE XgBlkSizeREG;
    BYTE XgBlkNumREG;

    // 0x30~0x3F
    BYTE XgTotalDiePerCe;
    BYTE XgPlaneNum;
    BYTE XgarRsv2[2];
    BYTE XgTotalIntlvChNum;
    BYTE XgLogiPlaneNum;
    BYTE XgTotalIntlvChPlaneNum;
    BYTE XgTotalChPlaneNum;
    BYTE garSpareRegion[2];
    WORD Xg16PageNum;
    BYTE XgTotalChNum;
    BYTE XgTotalCeNum;
    BYTE XgInterChipNumShiftCnt;
    BYTE XgChunkPerPlaneF;

    // 0x40~0x4F
    WORD Xg16TotalFBlock;
    WORD Xg16TotalHBlock;
    WORD Xg16BadCntBeforeDiff;
    WORD Xg16BadCntAfterDiff;
    WORD Xg16ExtendBlock;
    BYTE XgDataEccLv;
    BYTE XgSprEccLv;
    LWORD Xg32TotalDatSector;

    // 0x50~0x5F
    BYTE Xg4kFlashAddrBitNum;
    BYTE XgPlaneFlashAddrBitNum;
    BYTE XgChFlashAddrBitNum;
    BYTE XgDieFlashAddrBitNum;
    BYTE XgCeFlashAddrBitNum;
    BYTE XgPhyPageFlashAddrBitNum;
    BYTE XgPhyBlkFlashAddrBitNum;
    BYTE XgRsv3;
    WORD Xg16PagePerBlock1;
    WORD Xg16PagePerBlock2;
    WORD Xg16PagePerBlock3;
    WORD Xg16OrgSpareBlockCnt;

    // 0x60~0x6F
    BYTE XgarFLCmdSetTab[16];

    // 0x70~0x7F
    LWORD Xg32SectorPerBlockH;
    WORD Xg16FirstFBlock;
    BYTE XgFlashDrive;
    BYTE XgRsv4;
    BYTE XgarDllAdj[8];

    // 0x80~0x8F
    BYTE XgOrgBlockStatusStartPage;
    BYTE XgEraseBlockStatusStartPage;
    BYTE XgProgBlockStatusStartPage;
    BYTE XgTotalBlockStatusStartPage;
    BYTE XgBadBlockBitMapStartPage;
    BYTE XgDiffType2BitTabeStartPage;
    BYTE XgTotalDiffAddrTableStartPage;
    BYTE XgRetryTableStartPage;
    WORD Xg16PagePerBlock1Slc;
    WORD Xg16PagePerBlock2Slc;
    WORD Xg16PagePerBlock3Slc;
    WORD Xg16SlcBlockCnt;

    // 0x90~0xAF
    LWORD Xg32arChIoDriving[4][2];

    // 0xB0~0xBF
    WORD Xg16ValidPgPerF2hTab;
    WORD Xg16PagePerH2fTab;
    WORD Xg16TotalPgPerF2hTab;
    WORD Xg16MaxCachePageNum;
    WORD Xg16MaxCacheBlkNum;
    BYTE XgTotalPlaneOfH2fTab;
    BYTE XgTotal4kNumOfF2hTab;
    BYTE XgTotalPlaneOfCacheInfoTab;
    BYTE XgTotalBankOfF2hTab;
    BYTE Xg4kNumPerPlane;
    BYTE Xg4kNumPerPage;

    // 0xC0~0xCF
    LWORD Xg32PagePerBlock2By4kMode;
    LWORD Xg32PagePerBlock2SlcBy4kMode;
    LWORD Xg32FlushF2hTabStAddr;
    BYTE XgarRsv5[4];

    // 0xD0~0xEF
    BYTE garSysBlkIndexBitMap[32];

    // 0xF0~0xFF
    BYTE XgarSTPG[4];
    BYTE XgarRsv6[4];
    BYTE XgCe0DieMap;
    BYTE XgCe1DieMap;
    BYTE XgCe2DieMap;
    BYTE XgCe3DieMap;
    BYTE XgarRsv7[4];
}DramlessParamTab;
#pragma pack()

typedef struct _POWERSTATE
{
    NVMEFEATURESEL uFeatVal;
    BYTE uDevPrePs;
    BYTE uDevCurPs;
    BYTE uDevNextPs;
    BYTE uDevLastPs;
    BYTE uHostNextPs;
    BYTE uHostLastPs;
    BYTE uPsChg;
    BYTE uPwrState;
}POWERSTATE;

typedef struct _LBARANGETYPE
{
    BYTE uType;
    BYTE uAttribute;
    BYTE uRsvd0[14];
    QWORD u64Slba;
    QWORD u64Nlb;
    LWORD u32Guid[4];
    BYTE uRsvd1[16];
}LBARANGETYPE;

// APST data structure
typedef struct _APSTTABLE
{
    // Since the Rsvd bit should be zero, use the normal unit just for convinience
    LWORD uRsvd : 3;    // bit[0:2]:Rsv
    LWORD uItps : 5;    // bit[3:7]:ITPS
    LWORD uItpt : 24;    // bit[8:23]:ITPT
    LWORD u32Rsvd;
}APSTTABLE;

typedef struct _APSTDATA
{
    APSTTABLE uarDefault[cMaxApstSize];
    APSTTABLE uarCurrent[cMaxApstSize];
    APSTTABLE uarSaved[cMaxApstSize];
}APSTDATA;

typedef struct _NVMEFEATURETIMESTAMP
{
    LWORD u32TimestampLow;
    WORD u16TimestampHigh;
    BYTE uSynchOrigin;
    BYTE uRsvd;
    LWORD u32LastTimestamp;    // Not in spec, Need to skip while report
}NVMEFEATURETIMESTAMP;

typedef struct _HMBHWDATA
{
    LWORD u32arDescEntryAddrLow[256];
    LWORD u32arDescEntryAddrHigh[256];
    LWORD u32arDescEntrySize[256];
    LWORD u32TotalFixGroupNumber;
    LWORD u32HmbSize;
    LWORD u32HmbDescListAddrLow;
    LWORD u32HmbDescListAddrHigh;
    LWORD u32HmbDescListEntryCnt;
    LWORD u32ActiveSize;
    WORD u16arDescNumInFixGroup[64];
    BYTE uFixGroupSize;
    BYTE uRsvd0;
}HMBHWDATA;

typedef struct _NVMEFEATVAR
{
    BYTE uarBuff[0x1000];    // 4k buffer for the feature data transfer
    NVMEFEATURESET usFeat;
    BYTE uarRsvd0[0x1000-sizeof(NVMEFEATURESET)];    // Reserved for future feature
    LBARANGETYPE usLbaRangeTypeEntry[cNamespaceMax][64];
    APSTDATA usApstEntry;
    HMBHWDATA usHmbHwInfo;
    NVMEFEATURETIMESTAMP usTimestamp;
}NVMEFEATVAR;

typedef struct _TRIMINFO
{
    LWORD u32ContextAttr;
    LWORD u32Length;
    QWORD u64StartLba;
}TRIMINFO;

////////////////////////////////////////////////
// Updated by Kane, 20161223
//
// 1. u16KVal: 16bits
// 2. uSctrNum: 5bits
// 3. uPtyNum = 1 for SM2263
////////////////////////////////////////////////
typedef struct _RAIDTYPE
{
    WORD u16KVal;
    BYTE uSctrNum;

    // BYTE uPtyNum;
}RAIDTYPE;

////////////////////////////////////////////////
// Updated by Kane, 20161229
//
// 1.uRaidTermInfo:
//     [Bit15 to Bit12] uRaidType: (cRaidTotalType=3) cRaidDataBlk, cRaidGcBlk, cRaidHTabBlk
//     [Bit11 to Bit08] Fore-Ground(FG) Raid Engine Idx: 0 ~ 11 (Cancelled, 20161229)
//     [Bit6] uBGEn
//     [Bit0] uRaidTermFlag
//
// 2. u16DesTsbIdx: The TSB address that keeps the temp Raid parity
//
// 3. u16TermPgIdx: The next start enc page Idx, or the current enc-ed page cnt
//
// 4. uTermSctrIdx:
//
////////////////////////////////////////////////
typedef struct _RAIDTERMQUEUE
{
    WORD u16RaidTermInfo;
    WORD u16DesTsbIdx;
    WORD u16TermPgIdx;
    BYTE uTermSctrIdx;
}RAIDTERMQUEUE;

typedef struct _RAIDDECADDR
{
    LWORD u32FPageNoTran;
    WORD u16FBlock;
    WORD u16FPage;
    WORD u16BufPtr;
    WORD u16RwOpt;

    BYTE uPlaneAddr;
    BYTE uSectorH;
    BYTE uOpTyp;
    BYTE uCh;
    BYTE uIntlvAddr;
    BYTE uDieAddr;
    BYTE uRwHalfKb;
    BYTE uPrdPtr;
    BYTE uPageSelCmd;
    BYTE uRdEccFailIdx;
}RAIDDECADDR;

typedef struct _RAIDINFO
{
    // Define for Encode flow
    RAIDTYPE uarRaidTotalType[cRaidTotalType];
    RAIDTERMQUEUE uarRaidTermQue[cRaidTotalEng];

    WORD u16RaidEngBitMap;    // Is Eng busy? 1 (yes) or 0 (no)
    WORD u16RaidEngPtyBitMap;    // Is Eng Pty ready? 1 (yes) or 0 (no)
    WORD u16arRaidEngPgIdx[cRaidTotalEng];
    WORD u16arRaidFPage[cRaidTotalType-1][cRaidParityNum];

    BYTE uarRaidEngSctrIdx[cRaidTotalEng];
    BYTE uarRaidEngIdx[cRaidTotalType-1][cRaidParityNum];
    BYTE uarBkDataRaidEngIdx[cRaidParityNum];
    BYTE uRaidPopEngCnt;

    // Define for Decode flow
    RAIDDECADDR uarRaidDecQue[cRaidDecQueDepth];
    WORD u16arErrChunkMap[cRaidDecQueDepth];
    WORD u16RaidLdpcPgIdx;

    // WORD u16RaidDecTotalCnt;    //Move to CacheInfoTab
    // WORD u16RaidDecSkipCnt;
    // WORD u16RaidDecH2fFailCnt;
    // WORD u16RaidDecDataFailCnt;

    BYTE uRaidDecFifoHead;
    BYTE uRaidDecFifoTail;
    BYTE uRaidDecQueCnt;
    BYTE uRaidDecodeF;
}RAIDINFO;

////////////////////////////////////////////////
// Updated by Kane, 20180113
//
// 1. u16TsbIdx, u16XfrSctrCnt - units: sctr addr, not byte addr
//
// 2. u16RaidOpts
//     [Bit15 to Bit12] uRaidType: (cRaidTotalType=3) cRaidDataBlk, cRaidGcBlk, cRaidHTabBlk
//     [Bit11 to Bit08] Raid Engine Idx: 0 ~ 11
//     [Bit07 to Bit00] RAID Actions
//                            Bit5: ParityClr
//                            Bit3-Bit0: Other RAID Actions ... , refer to RAID const in "Const.h"
////////////////////////////////////////////////
typedef struct _HDMAQUEUE
{
    WORD u16TsbIdx;
    WORD u16XfrSctrCnt;

    WORD u16RaidOpts;
    WORD u16RaidStEncPgIdx;
    BYTE uRaidStEncSctrIdx;
}HDMAQUEUE;

typedef struct _HDMAINFO
{
    HDMAQUEUE uarHdmaQue[cHdmaQueDptFW];
    BYTE uHdmaQueHead;
}HDMAINFO;

typedef struct _HMBPTYQ
{
    WORD u16BufPtr;
    WORD u16PtyIdx;
    BYTE uPagePerWL;
    BYTE uPageSel;
    BYTE uXfrDir;
}HMBPTYQ;

typedef struct _HMBPTYINFO
{
    HMBPTYQ uarHmbPtyQ[cHmbPtyQueDpt];
    LWORD u32HmbPtyHead;
    LWORD u32HmbPtyTail;
}HMBPTYINFO;

#pragma pack(1)
typedef struct _DSTRESULT
{
    BYTE uDstStatus;    // Device Self-test Status
    BYTE uSegmentNum;    // Segment Number: the first self-test failure occurred number
    BYTE uValidDiagInfo;    // Valid Diagnostic Information: Bit0:NSID_Valid, Bit1:FLBA_Valid, Bit2: SCT_Valid, and Bit3:SC_Valid
    BYTE uRsvd0;
    QWORD u64Poh;    // Power On Hours
    LWORD u32Nsid;    // Namespace Identifier
    QWORD u64FailLba;
    BYTE uStatusCodeType;
    BYTE uStatusCode;
    WORD u16VenderSpecific;
}DSTRESULT;

typedef struct _DSTLOG
{
    BYTE uCurrDstOperation;
    BYTE uCurrDstCompletion;
    WORD uRsvd0;
    DSTRESULT usDstResult[21];    // Add one to backup current but not complete/abort result
    LWORD u32NvmeDstStartTimeMs;
    LWORD u32LastMemChkLba;
    LWORD u32CurrDstNsId;
    LWORD u32MemChkLbaUnit;
    BYTE uCurrDstFailBitMap;
    BYTE uUnderDataIntegrity;
    BYTE uarRsvd2[3486];    // Expand reserved space to 4k for future use
}DSTLOG;

typedef struct _TELELOG
{
    BYTE uLid;    // Log Identifier
    LWORD u32Rsvd0;
    BYTE uarIeee[3];    // IEEE OUI Identifier
    WORD u16DataArea1LastBlock;
    WORD u16DataArea2LastBlock;
    WORD u16DataArea3LastBlock;
    BYTE uarRsvd1[368];
    BYTE uCtrllerInitDataAvail;
    BYTE uCtrllerInitDataGenNum;
    BYTE uarReasonId[128];
    BYTE uarTeleDataBlk1[512];
}TELELOG;

#pragma pack()

typedef struct _SANITIZE
{
    ERASEUNITPARAM usEraseParam;
    BYTE uMode;
    BYTE uState;
    BYTE uAuse;
    BYTE uRsvd;
}SANITIZE;

typedef struct _SANILOG
{
    WORD u16Sprog;
    BYTE uSstatL;
    BYTE uSstatH;
    LWORD u32ScDw10;
    LWORD u32EstiTimeForOverWrite;
    LWORD u32EstiTimeForBlkErase;
    LWORD u32EstiTimeForCrpErase;
    BYTE uRsvd0[492];
    SANITIZE usSanitizeInfo;
    ERASEUNITINFO usEraseUnitInfo;
    QWORD u64LastHostWrCmdCnt;
    BYTE uRsvd1[0xE00-sizeof(SANITIZE)-sizeof(ERASEUNITINFO)-8];    // Expand reserved space to 4k
}SANILOG;

#define cNvmeGetLogSIdx             (c16Tsb0SIdx)
#define cNvmeGetLogSmartIdx         (cNvmeGetLogSIdx+((sizeof(ERRORINFO)*cMaxErrLogEntryCnt)/cSectorSize))
#define cNvmeGetLogFwSlotIdx        (cNvmeGetLogSmartIdx+(sizeof(SMARTINFO)/cSectorSize))
#define cNvmeGetLogChangeNsIdx      (cNvmeGetLogFwSlotIdx+(sizeof(FWSLOTINFO)/cSectorSize))
#define cNvmeGetLogCmdEffectIdx     (cNvmeGetLogChangeNsIdx+((sizeof(LWORD)*1024)/cSectorSize))
#define cNvmeGetLogDstIdx           (cNvmeGetLogCmdEffectIdx+(sizeof(CMDEFFECTLOG)/cSectorSize))
#define cNvmeGetLogTeleHostIdx      (cNvmeGetLogDstIdx+(sizeof(DSTLOG)/cSectorSize))
#define cNvmeGetLogTeleCtrlIdx      (cNvmeGetLogTeleHostIdx+(sizeof(TELELOG)/cSectorSize))
#define cNvmeGetLogSanitizeIdx      (cNvmeGetLogTeleCtrlIdx+(sizeof(TELELOG)/cSectorSize))
#define cNvmeGetLogDellSmartIdx     (cNvmeGetLogSanitizeIdx+(sizeof(SANILOG)/cSectorSize))    // 20181203_SamHu_01
#define cNvmeGetLogLenovoPageDFhIdx  (cNvmeGetLogDellSmartIdx+(sizeof(DELLSMARTINFO)/cSectorSize))    // 20190108_SamHu_01
#define cNvmeGetLogPLPStatisticsIdx  (cNvmeGetLogLenovoPageDFhIdx+(sizeof(LENOVOLOGDF)/cSectorSize))    // 20190108_SamHu_01

typedef struct _GETLOGINFO
{
    ERRORINFO uarErrorLog[cMaxErrLogEntryCnt];    // LID 01h, reserved just in case
    SMARTINFO usSmartLog;    // LID 02h
    FWSLOTINFO usFwSlot;    // LID 03h
    LWORD u32arChangeNsList[1024];    // LID 04h
    CMDEFFECTLOG usCmdEffectLog;    // LID 05h
    DSTLOG usDstLog;    // LID 06h
    TELELOG usTeleHostLog;    // LID 07h
    TELELOG usTeleCtrlLog;    // LID 08h
    SANILOG usSaniLog;    // LID 81h
    DELLSMARTINFO usDellSmartLog;    // LID CAh
    LENOVOLOGDF usLenovoDFhLog;    // LID DFh
    PLPSTATISTICS usPLPStatisticsLog;    // LID F0h
}GETLOGINFO;

#if _ENABLE_ECC_TEAM_TRACKING_MODULE

#define TrackingDebug           0
#define SLCTrackingLimit        40
#define HynixKV3SLCLimit        32
#define HynixKV4SLCLimit        90
#define HynixTLCTrackingLimit   25
#define TLCTrackingLimit        32
#define HynixKV3ARLimit         10
#define HynixKV4ARLimit         15    ///
#define HynixKV4GRLimit         40    ///
#define HynixF16ARLimit         6
#define BaseCnt                 4096
#define TrackStepCnt            6
#define OverHillCount           500
#define TLCSoftStep             10
#define HTLCSoftStep            7
#define HMLCSoftStep            8
#define  R_LDPC_DSP             (((volatile unsigned int *)0x51200000))
#define S_2258 0
#define S_2260 0
#define S_2262 0
#define S_2263 1

#if S_2258
#define C_LDPC_N4_Mode 0x01
#define C_LDPC_N6_Mode 0x02
#define C_LDPC_N8_Mode 0x03
#define C_LDPC_RdCntBySoftMode(mode) (mode*2+2-1)
#elif S_2260||S_2262||S_2263
#define C_LDPC_N4_Mode 0x02
#define C_LDPC_N6_Mode 0x04
#define C_LDPC_N8_Mode 0x06
#define C_LDPC_RdCntBySoftMode(mode) (mode+1)
#endif

#define C_MaxSoftMode           4
#define C_VthRegNum             cMaxRetryRegisterCnt+2    // 10

typedef struct _vtTracking
{
    BYTE u8arFlashID[6];    // [Input] Flash ID

    // Power on initial (FW Set)
    BYTE ubEnTracking : 1;    // [Input] enable or disable
    BYTE ubEnN2RRT : 1;    ////[Input] if set this bit then vth center swill initialize to zero while N4 first loop

    ///Control flag (FW Set)
    BYTE ubFirstLoopInitalize : 1;    // [Input], power on or after soft decode
    BYTE ubEnSeparateTrack : 1;    // [Input] Enable or disable separate tracking       enable or disable, set when tracking
    BYTE ubEnSeparateUpper : 1;    // [Input] Enable or disable separate upper           Up or Down

    // Status Flag
    BYTE ubLowerOverHill : 1;    // [Output]
    BYTE ubUpperOverHill : 1;    // [Output]
    BYTE ubReserved : 1;    // ..

    ///Normal Soft Decode
    BYTE u8SoftMode;    // [Input]                            // [Input] N4: 1,//             N6: 2,//             N8: 3
    BYTE PageKSize;    // [Input] Decode size (K)
    BYTE u8RetryCnt;    // [Input] Soft decode
    BYTE u8CurPageType;    // [Input] (1) LSB=0, (2) CSB=1, (3 )MSB=2, (4) SLC=4, (5) SLCPageOnTLC=8, (6) MLCPageOnTLC=12
    BYTE u8SoftNLoop;    // [Output] update by tracking function, // initial from "ubFirstLoopInitalize=1"

    ///Tracking
    BYTE u8ActiveCh;

    BYTE u8Debug_0[3];

    LWORD g32arZero2OneCnt[(C_MaxSoftMode<<1)+2-1];    // [Output] Indirect read LDPC register 0xC4, 0xC5
    LWORD g32arOne2ZeroCnt[(C_MaxSoftMode<<1)+2-1];    // [Output] Indirect read LDPC register 0xC2, 0xC3
    LWORD g32arLowerDis[(C_MaxSoftMode<<1)+2-1];    // [Output]
    LWORD g32arUpperDis[(C_MaxSoftMode<<1)+2-1];    // [Output]

    ///Parameter
    BYTE u8arSoftStep[C_VthRegNum];    // [Output] It should be updated by tracking function before lower/upper read.
    BYTE u8arTrackVthCenter[C_VthRegNum];    // [Output] Keep previous tracking result

    // Debug
    // LWORD u8arEventLog[8];                                  // [Output] for debug
    LWORD u8arEventLog[7];    // [Output] for debug
}Tracking;
#endif    // if _ENABLE_ECC_TEAM_TRACKING_MODULE

typedef struct _DEBUGINFO
{
    LWORD u32PcieErrCnt0;
    LWORD u32PcieErrCnt1;
    LWORD u32PcieErrCnt2;
    LWORD u32PcieErrCnt3;
    LWORD u32PcieErrCnt4;
    LWORD u32PcieErrCnt5;

    LWORD u32PowerOnTime;
    LWORD u32FindSysBlkTime;
    LWORD u32RdLinkStartTime;
    LWORD u32RdLinkStep1Time;
    LWORD u32RdLinkStep2Time;
    LWORD u32RdLinkStep3Time;
    LWORD u32RdLinkTime;
    LWORD u32CcEnTime;
    LWORD u32CcRdyTime;
    LWORD u32CcEnFirstTime;
    LWORD u32CcRdyFirstTime;

    LWORD u32LastHwPrdValidTime;

    LWORD u32StandbyMoEntryTime;
    LWORD u32StandbyMoExitTime1;

    // LWORD u32StandbyMoExitTime2;
    LWORD u32StandbyMoExitTime3;

    LWORD u32ResumeFromPcieAppIrq0Time;
    LWORD u32SrvAdminCmdFirstTime;
    LWORD u32SrvAdminCmdTime;
    LWORD u32SrvRwCmdTime;

    // LWORD u32NonTaskCntTime1;
    // LWORD u32NonTaskCntTime2;
    // LWORD u32PcieErrHandleTime;

    // LWORD u32EntryIsrTimerCnt;
    // LWORD u32EntryIsrTimerTime[32];
    // LWORD u32ExitIsrTimerTime[32];
    // LWORD u32CcRdyTime1s;
    LWORD u32BootDlyTime;
    LWORD u32InitNvmeTime;
    LWORD u32PowerOnSec;

    BYTE uarLastIntSrc[32];
    LWORD uar32LastIntSrcTimeStamp[32];
    BYTE uLastIntSrcCnt;

    BYTE uarPcieDebugTrace[32];
    LWORD uar32PcieDebugTraceTimeStamp[32];
    BYTE uPcieDebugCnt;
}DEBUGINFO;

typedef struct _E2EINFO
{
    LWORD u32GenerateCnt[cE2eMaxType];
    LWORD u32CompareCnt[cE2eMaxType];
    LWORD u32InternalDataCrcCnt[cE2eMaxType];
    LWORD u32GenerateLba;
    LWORD u32CompareLba;
    LWORD u32CurrentSctCnt;
    WORD u16CommandRetryPrd;

    // BYTE uHmbEnable;
    BYTE uTableType;
}E2EINFO;

#pragma pack(1)
typedef struct _PS4BACKUP
{
    BYTE uPs4BootIspCodeRsv[c32Ps4BootIspCodeSize];    // PS4 boot code address need start at 0x4018_0000
    BYTE uBkCore0Dcccm[cPs4Core0DccmBkSize];
    BYTE uBkStcm[cPs4StcmBkSize];
    WORD u16BkDiffFBlock0;
    WORD u16BkDiffFBlock1;
    WORD u16BkDiffFPageNoTran;

    // Offset 0x6800 start put parameter table and seed table
}PS4BACKUP;
#pragma pack()

typedef struct _NSINFO
{
    LWORD u32StartLba;
    LWORD u32Size;
}NSINFO;

typedef struct _NAMESPACEINFO
{
    NSINFO usInfo[cNamespaceMax];
    LWORD u32UnvmCap;
    LWORD u32DummyPatt;
    BYTE uRsvd;
    BYTE uDulbeBitMap;
    BYTE uActiveBitMap;
    BYTE uAllocatedBitMap;
    BYTE uActiveNsNumber;
    BYTE uAllocatedNsNumber;
}NAMESPACEINFO;

typedef struct _INVALIDDBINFO
{
    WORD uarErrQid[cMaxIoSqCqCnt];
    BYTE uErrLogHead;
    BYTE uErrLogTail;
}INVALIDDBINFO;

#define cIdenDireSupport        cBit0
#define cStreamDireSupport      cBit1

#define cIdenDireEnable         cBit0
#define cStreamDireEnable       cBit1

typedef struct _IDENDIRECTIVE
{
    BYTE uDirectiveSupport;
    BYTE uDsRsvd[31];
    BYTE uDirectiveEnable;
    BYTE uDeRsvd[31];
    BYTE uRsvd[4032];
}IDENDIRECTIVE;

#pragma pack(1)
typedef struct _DBGLOG
{
    WORD uUgsdCacheBlock;
    WORD u16TLCGcWLCnt;
    WORD u16SLCReclaimCnt;
    WORD u16ReclaimCnt;
    WORD u16SLCFlushCnt;
    WORD u16H2FScrubCnt;
    WORD u16FtlEventReason;
    WORD u16LastSBPassChAndCe;
    WORD u16LastSBPassDieAndPlane;
    WORD u16LastSBPassBlk;
    WORD u16LastSBPassPage;
    WORD u16LastSBRetryDataAndSlc;
    WORD u16LastSBEccBit;
    WORD u16LastHBPassChAndCe;
    WORD u16LastHBPassDieAndPlane;
    WORD u16LastHBPassBlk;
    WORD u16LastHBPassPage;
    WORD u16LastHBRetryDataAndSlc;
    WORD u16LastHBEccBit;
    LWORD u32SlcRetryTablePassCnt;
    LWORD u32SlcRetryTableFailCnt;
    LWORD u32TlcRetryTablePassCnt;
    LWORD u32TlcRetryTableFailCnt;
    LWORD u32SlcVthTrackingPassCnt;
    LWORD u32SlcVthTrackingFailCnt;
    LWORD u32TlcVthTrackingPassCnt;
    LWORD u32TlcVthTrackingFailCnt;
    LWORD u32RaidB2bRehCnt;
    QWORD u64TotalSlcProgCnt;    // g64TotalSlcProgCnt
    QWORD u64TotalTlcOneShotCnt;    // g64TotalTlcOneShotCnt
    QWORD u64TotalHostWrSecCnt;    // g64TotalHostWrSecCnt
    QWORD u64BgdClnProcCnt;
    LWORD u32RRCnt;    // g32RRCnt
    LWORD u32TotalScrubBlkCnt;    // g32TotalScrubBlkCnt
    LWORD u32ForceCleanCnt;    // g32ForceCleanCnt
    LWORD u32PowerOnCnt;    // u32PowerOnCnt
    LWORD u32UGSDPwrOnCnt;    // g32UGSDPwrOnCnt
    LWORD u32GSDPwrOnCnt;    // g32GSDPwrOnCnt
    LWORD u32Vdt23FailCnt;    // g32Vdt23FailCnt
    LWORD u32Vdt18FailCnt;    // g32Vdt18FailCnt
    LWORD u32PfRehCnt;    // g16PfRehCnt
    LWORD u32PlpScpGpioInitCnt;
    LWORD u32PlpScpCompleteCnt;
    WORD u16MinSpareBlockCnt;    // g16MinSpareBlockCnt
    WORD u16TlcMinSpareBlockCnt;    // g16TlcMinSpareBlockCnt
    WORD u16MaxPushSpareCnt;    // g16MaxPushSpareCnt
    WORD u16EraseFailCount;    // g16EraseFailCount
    WORD u16RaidDecH2fPassCnt;    // g16RaidDecH2fPassCnt
    WORD u16RaidDecH2fFailCnt;    // g16RaidDecH2fFailCnt
    WORD u16RaidDecDataPassCnt;    // g16RaidDecDataPassCnt
    WORD u16RaidDecDataFailCnt;    // g16RaidDecDataFailCnt
    WORD u16PfB2bCnt;    // g16PfB2bCnt;
    WORD u16EfB2bCnt;    // g16EfB2bCnt
    WORD u16MarkBadCount;    // g16MarkBadCount;
    WORD u16DummyFailType;    // g16DummyFailType

    BYTE uStaticMode;    // gStaticMode

    BYTE uPfH2fCnt;    // gsProgFailInfo.uDgTestCnt[0];
    BYTE uPfWproCnt;    // gsProgFailInfo.uDgTestCnt[1];
    BYTE uPfRaidCnt;    // gsProgFailInfo.uDgTestCnt[2];
    BYTE uPfGcDesCnt;    // gsProgFailInfo.uDgTestCnt[3];
    BYTE uPfActCacheCnt;    // gsProgFailInfo.uDgTestCnt[4];

    WORD u16CrcH2fErrCnt;
    WORD u16CrcDataErrCnt;
    WORD u16CrcGcDataErrCnt;
    WORD u16CrcGcInfoErrCnt;
    WORD u16CrcGcPtErrCnt;
}DBGLOG;
typedef struct _FTLDBGLOG
{
    BYTE ubPwrOnByQBoot;    // gsRdlinkInfo.ubPwrOnByQBoot
    BYTE ubPwrOnGcF;    // gsRdlinkInfo.ubPwrOnGcF
    BYTE uSysOpFlag;    // gSysOpFlag // chk dummy W/R
    DBGLOG gsFtlDbg;

    // pcie error
}FTLDBGLOG;
#pragma pack()

typedef struct _FRONTENDDBGLOG
{
    BYTE uReservedDebugInfo[512];    // reserved 512 bytes for gsDebugInfo
    LWORD u32NandThermalMT1TranCnt;
    LWORD u32NandThermalMT1TransitionCount;
    LWORD u32AsicThermalMT1TranCnt;
    LWORD u32AsicThermalMT1TransitionCount;
    LWORD u32NandThermalMT2TranCnt;
    LWORD u32NandThermalMT2TransitionCount;
    LWORD u32AsicThermalMT2TranCnt;
    LWORD u32AsicThermalMT2TransitionCount;
    LWORD u32NandThermalMT3TranCnt;
    LWORD u32NandThermalMT3TransitionCount;
    LWORD u32AsicThermalMT3TranCnt;
    LWORD u32AsicThermalMT3TransitionCount;
    QWORD u64PwrOnPs3Cnt;
    QWORD u64PwrOnPs4Cnt;
    LWORD u32PwrOnAbortPs3Cnt;
    LWORD u32PwrOnAbortPs4Cnt;
    LWORD u32Vdt27FailCnt;
    BYTE uReserved[434];
    BYTE uTelemetryControllerDataAvail;
    BYTE uTelemetryControllerDataGenNum;
}FRONTENDDBGLOG;

#include "inc/LightSwitch.h"
#include "inc/SecAPI_BaseFW_Type.h"

#define gbEnAes                 gbsSecurity.BIT00
#define gbEnTCG                 gbsSecurity.BIT01
#define gbEnIEEE1667            gbsSecurity.BIT02
#define gbEnSessionTimer        gbsSecurity.BIT03
#define gbEnPyrite              gbsSecurity.BIT04
#define gbEnOpalite             gbsSecurity.BIT05
#define gbEnATAPassThrough      gbsSecurity.BIT06
#define gbEnRpmb                gbsSecurity.BIT07

#define gbSecAPIInitial             gbsSecAPI.BIT00
#define gbSecAPIPendingPCIeReset    gbsSecAPI.BIT01
#define gbSecAPIPendingNSSR             gbsSecAPI.BIT02
#define gbSecAPIPendingInitATA      gbsSecAPI.BIT03
#define gbSecAPIProgWproAfterResume  gbsSecAPI.BIT04
#define gbSecAPIClearATASecurityPrepare gbsSecAPI.BIT05

#if _DEBUG_UART|_DEBUG_LOG
typedef char *va_list;
#define _INTSIZEOF(n) ((sizeof(n)+sizeof(int)-1)&~(sizeof(int)-1))
#define va_start(ap, v) (ap=(va_list)&v+_INTSIZEOF(v))
#define va_arg(ap, t) (*(t *)((ap+=_INTSIZEOF(t))-_INTSIZEOF(t)))
#define va_end(ap) (ap=(va_list)0)
#endif

#if (_EN_CHRONUS_UART_DEBUG)
typedef struct _sChonusUartCMD
{
    LWORD SOF;
    BYTE Opcode;    // DW0 byte0
    BYTE DW0B1;    // DW0 byte1
    BYTE DW0B2;    // DW0 byte2
    BYTE DW0B3;    // DW0 byte3
    LWORD NSID;    // DW1 name space ID
    LWORD DWrsv[8];    // DW2 ~ DW9
    LWORD DW10;    // DW10
    LWORD DW11;    // DW11
    LWORD DW12;
    LWORD DW13;
    LWORD DW14;
    LWORD DW15;
    LWORD DataSecLength;
}sChronusUartCMD;
#endif    // if (_EN_CHRONUS_UART_DEBUG)

typedef struct _MPINFODATA
{
    // BYTE uarRdtLs[4096];    // first 4KB is LS for Rdt
    // BYTE uarRsvdOffset[512];    // 0x200 offset for package
    BYTE uarSerialNum[20];
    BYTE uarRsvd1[12];
    BYTE uarModelName[40];
    BYTE uarRsvd2[8];
    BYTE uarIeee[3];
    BYTE uarRsvd3[13];
    BYTE uarEui64[8];
    BYTE uarRsvd4[8];
    BYTE uarFwVersion[8];
}MPINFODATA;

#if _EN_WUNCTable    // WUNCTable Chief_21081121
typedef struct _WUNCInfo
{
    BYTE uWuncCnt;
    WORD u16HBlock[C_MaxWUNCLAACnt];
    WORD u16HPage[C_MaxWUNCLAACnt];
    BYTE uBitMap[C_MaxWUNCLAACnt];
    BYTE uWZeroFlag;
}WUNCInfo;
#endif

#if _EN_WriteZeroNonAlign    // WUNCTable Chief_21081121
typedef struct _WZNonAlginInfo
{
    LWORD u32LBA;
    BYTE uSCnt;
#if WZ_debug
    WORD u16HBlock;
    WORD u16HPage;
#endif
}WZNonAlginInfo;
#endif

typedef struct _IomInfo
{
    LWORD u32SeqLba;
    LWORD u32SeqCmdCnt;
    LWORD u32RanCmdCnt;
    LWORD u32ReadCmdCnt;
    LWORD u32SeqLen;
    LWORD u32TrigTimer;
    BYTE u8Status;
    BYTE u8ThrdCnt;
}IomInfo;

typedef struct _VUFWSlotInfo
{
    WORD u16Index;
    WORD u16PowerOnCnt;
    BYTE uFwSlot;
    BYTE uAction;
    BYTE uarRsvd1[10];
    BYTE uarSlot1FwVersion[8];
    BYTE uarSlot2FwVersion[8];
}VUFWSlotInfo;

typedef struct _VUFWHISTORY
{
    VUFWSlotInfo usVUFWHeadInfo;
    VUFWSlotInfo usVUFWSlotInfo[cMaxFWHistoryNum];
}VUFWHISTORY;

#define gbPwOnGC   cBit0
#define gbRWEndGC  cBit1
#define gbGCVpcMismatch  cBit2
#define gbGCSrcVpcChk    cBit3

#endif    // ifndef __TYPEDEF_H__







