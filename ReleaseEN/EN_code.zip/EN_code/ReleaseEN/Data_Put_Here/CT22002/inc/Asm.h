







#ifndef __ASM_H__
#define __ASM_H__

// assembly function
void __enableDataCache(void);
void __disableDataCache(void);
void __enableInstCache(void);
void __disableInstCache(void);
void __invalidateDataCache(void);
void __invalidateInstCache(void);
void __flushCache(void);
void __enableDataCache(void);
void __finishDataTransfer(void);
void __waitForEvent(void);

void __enable_ve(void);
void __disable_ve(void);
void __initMpuRegion(void);
void __enableMPU(void);
void __disableMPU(void);

void __enableBranchPredict(void);
void __disableBranchPredict(void);

void __enableArmEccFunc(void);
void __disableArmEccFunc(void);

#endif    // ifndef __ASM_H__







