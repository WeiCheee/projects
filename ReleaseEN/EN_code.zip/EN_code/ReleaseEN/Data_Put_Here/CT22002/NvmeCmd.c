







#include "inc/DebugLog.h"
#include "inc/EventLogIDX.h"
#include "inc/EventLogFunctionIDX.h"
#include "inc/TypeDef.h"
#include "inc/Option.h"
#include "inc/ProType.h"
#include "inc/Reg.h"
#include "inc/NvmeCtrl.h"
#include "inc/table.h"
#include "inc/GlobVar0.h"
#include "inc/GlobVarS.h"
#include "Common/Model.h"

#if (!_ICE_LOAD_ALL)
#pragma default_variable_attributes = @ ".NVME_CMD_GRP"
#endif

void(*const NvmeCmdGrp[]) (void)=
{
    nvmeDeleteSubQueueSwap,    // 00h
    nvmeCreateSubQueueSwap,    // 01h
    nvmeGetLogPageSwap,    // 02h
    nvmeInvalidCmd,    // 03h
    nvmeDeleteCmplQueueSwap,    // 04h
    nvmeCreateCmplQueueSwap,    // 05h
    nvmeIdentifySwap,    // 06h
    nvmeInvalidCmd,    // 07h
    nvmeAbortSwap,    // 08h
    nvmeSetFeatureSwap,    // 09h
    nvmeGetFeatureSwap,    // 0Ah
    nvmeInvalidCmd,    // 0Bh
    nvmeAsynEventSwap,    // 0Ch
    nvmeNamespaceManagementSwap,    // 0Dh
    nvmeInvalidCmd,    // 0Eh
    nvmeInvalidCmd,    // 0Fh
    nvmeFwCommitSwap,    // 10h
    nvmeFwImageDlSwap,    // 11h
    nvmeInvalidCmd,    // 12h
    nvmeInvalidCmd,    // 13h
    nvmeDstSwap,    // 14h
    nvmeNamespaceAttachmentSwap,    // 15h
    nvmeInvalidCmd,    // 16h
    nvmeInvalidCmd,    // 17h
    nvmeInvalidCmd,    // 18h, Keep Alive
    nvmeDirectiveSendSwap,    // 19h
    nvmeDirectiveReceSwap,    // 1Ah
    nvmeInvalidCmd,    // 1Bh
    nvmeInvalidCmd,    // 1Ch, Virtualization Management
    nvmeInvalidCmd,    // 1Dh, NVMe-MI Send
    nvmeInvalidCmd,    // 1Eh, NVMe-MI Receive
    nvmeInvalidCmd,    // 7Ch, Doorbell Buffer Config (index=1Fh)
    nvmeInvalidCmd,    // 7Dh (index=20h)
    nvmeInvalidCmd,    // 7Eh (index=21h)
    nvmeInvalidCmd,    // 7Fh, Nvme over Fabrics (index=22h)
    nvmeFormatSwap,    // 80h (index=23h)
    nvmeSecuritySendSwap,    // 81h (index=24h)
    nvmeSecurityReceiveSwap,    // 82h (index=25h)
    nvmeInvalidCmd,    // 83h (index=26h)
    nvmeSanitizeSwap,    // 84h (index=27h)
    nvmeVendorNonDataSwap,    // C0h (index=28h)
    nvmeVendorDataOutSwap,    // C1h (index=29h)
    nvmeVendorDataInSwap,    // C2h (index=2Ah)
    nvmeLiteonVendorNonDataSwap,    // FCh (index=2Bh)
    nvmeLiteonVendorDataOutSwap,    // FDh (index=2Ch)
    nvmeLiteonVendorDataInSwap,    // FEh (index=2Dh)
};

#if (!_ICE_LOAD_ALL)
#pragma default_variable_attributes =
#endif

#if (!_ICE_LOAD_ALL)
#pragma default_function_attributes = @ ".NVME_CMD"
#endif

void nvmeDeleteSubQueueSwap()
{
    mCallFuncPtr(cfuncNvmeDeleteSubQueue);
}

void nvmeCreateSubQueueSwap()
{
    mCallFuncPtr(cfuncNvmeCreateSubQueue);
}

void nvmeDeleteCmplQueueSwap()
{
    mCallFuncPtr(cfuncNvmeDeleteCmplQueue);
}

void nvmeCreateCmplQueueSwap()
{
    mCallFuncPtr(cfuncNvmeCreateCmplQueue);
}

void nvmeGetLogPageSwap()
{
    mCallFuncPtr(cfuncNvmeGetLogPage);
}

void nvmeInvalidCmd()
{
    manualCompletion(cStatusInvalidOpCode, 0, cNoRwCmd, 0);
}

void nvmeIdentifySwap()
{
    mCallFuncPtr(cfuncNvmeIdentify);
}

void nvmeAbortSwap()
{
    mCallFuncPtr(cfuncNvmeAbort);
}

void nvmeSetFeatureSwap()
{
    mCallFuncPtr(cfuncNvmeSetFeature);
}

void nvmeGetFeatureSwap()
{
    mCallFuncPtr(cfuncNvmeGetFeature);
}

void nvmeAsynEventSwap()
{
    mCallFuncPtr(cfuncNvmeAsynEvent);
}

void nvmeFwCommitSwap()
{
    mCallFuncPtr(cfuncNvmeFwCommit);
}

void nvmeFwImageDlSwap()
{
    mCallFuncPtr(cfuncNvmeFwImageDl);
}

void nvmeFormatSwap()
{
    mCallFuncPtr(cfuncNvmeFormat);
}

void nvmeIoCommandSwap(BYTE uFuncNum)
{
    loadISPCodeCore0(cNvmeIsp, 0);
    mCallFuncPtr(uFuncNum);
    loadISPCodeCore0(cRwIsp, 0);
}

void nvmeSecuritySendSwap()
{
    mCallFuncPtr(cfuncSecApiTrustedSend);
}

void nvmeSecurityReceiveSwap()
{
    mCallFuncPtr(cfuncSecApiTrustedReceive);
}

void nvmeDstSwap()
{
    mCallFuncPtr(cfuncNvmeDst);
}

void nvmeNamespaceManagementSwap()
{
    mCallFuncPtr(cfuncNvmeNsManagemet);
}

void nvmeNamespaceAttachmentSwap()
{
    mCallFuncPtr(cfuncNvmeNsAttachment);
}

void nvmeDirectiveSendSwap()
{
    mCallFuncPtr(cfuncNvmeDirectiveSend);
}

void nvmeDirectiveReceSwap()
{
    mCallFuncPtr(cfuncNvmeDirectiveReceive);
}

void nvmeSanitizeSwap()
{
    mCallFuncPtr(cfuncNvmeSanitize);
}

void addCmdHistory()
{
    CMDSTRUCT *upIOCmd;

    upIOCmd=&garCmdHistory[g32CmdHistoryPtr];

#if _GREYBOX
    CMDSTRUCT *upGbIOCmd;

    upGbIOCmd=&garGbCmdHistory[g32GbCmdHistoryPtr];
#endif

    // if(gsCacheInfo.u16debugPcieRErrCnt!=0)
    // {
    //    upIOCmd->u32Dword0=0x55AA55AA;
    //    upIOCmd->u32Dword10=0x55AA55AA;
    //    upIOCmd->u32Dword11=0x55AA55AA;
    //    upIOCmd->u32Dword12=0x55AA55AA;
    // }
    // else
    {
        if(!(rmNvmeSqId))    // admin
        {
            // upIOCmd->u16Dword0 = (r32Nvme2[rcFwRqCmd0/4] & (~c32Bit10));  //SM2260 original code
            upIOCmd->u32Dword0=(r32Nvme1[rcFwRqCmd0/4]&0x0000FFFF);
#if _GREYBOX
            upGbIOCmd->u32Dword0=(r32Nvme1[rcFwRqCmd0/4]&0x0000FFFF);
#endif
        }
        else    // IO
        {
            upIOCmd->u32Dword0=(r32Nvme1[rcFwRqCmd0/4]|c32Bit10);
#if _GREYBOX
            upGbIOCmd->u32Dword0=(r32Nvme1[rcFwRqCmd0/4]|c32Bit10);
#endif
        }

        upIOCmd->u32Dword10=r32Nvme1[rcFwRqCmd10/4];
        upIOCmd->u32Dword11=r32Nvme1[rcFwRqCmd11/4];
        upIOCmd->u32Dword12=r32Nvme1[rcFwRqCmd12/4];
        upIOCmd->u32TimeStamp=getRtcCurrent32k();

#if _GREYBOX
        upGbIOCmd->u32Dword10=r32Nvme1[rcFwRqCmd10/4];
        upGbIOCmd->u32Dword11=r32Nvme1[rcFwRqCmd11/4];
        upGbIOCmd->u32Dword12=r32Nvme1[rcFwRqCmd12/4];
        upGbIOCmd->u32TimeStamp=rmGetRtc32kTick;
#endif
    }
    g32CmdHistoryPtr++;

    if(g32CmdHistoryPtr>=cCmdHistorySize)
    {
        g32CmdHistoryPtr=0;
    }

#if _GREYBOX
    g32GbCmdHistoryPtr++;

    if(g32GbCmdHistoryPtr>=(cCmdHistorySize*cCmdHistorySize))
    {
        g32GbCmdHistoryPtr=0;
    }
#endif
}    /* addCmdHistory */

void nvmeHandleAdmin()
{
    BYTE uOpCode;
    BYTE uCmdIdx;

#if (_EN_CHRONUS_UART_DEBUG)
    if(mChkUartCMDRdy)
    {
        uCmdIdx=uOpCode=gpUartCMD->Opcode;
    }
    else
#endif
    {
        uCmdIdx=uOpCode=rmNvmeOpCode;
    }

#if _EN_SHN_SUPPORT_CMD
    if(rmChkShstComplete)
    {
        rmClrShutdownNotify;
    }
#endif

#if (_ENABLE_DASP_LED)
    mSetDaspLed;
    rmRtc32kIntEnable;
#endif

    NLOG(cLogAdmin, NVMECMD_C, 3, " Admin Cmd OpCode=0x%04X, NSID=0x%08X", uOpCode, rmNvmeNsId>>16, rmNvmeNsId);

    if(mChkSanitizeCommandAbort&&((uOpCode>0x20)||(!(c32SanitizeAllowCmdBitmap&cb32BitTab[uOpCode]))))
    {
        if(mChkSanitizeInProgress)
        {
            NLOG(cLogHost, NVMECMD_C, 1, " Sanitize in progress, Current issued ADMIN OP=0x%04X ", rmNvmeOpCode);
            manualCompletion(cStatusSanitizeInProgress, 0, cNoRwCmd, 0);
            return;
        }
        else if(uOpCode!=cNvmeCmdSanitize)
        {
            NLOG(cLogHost, NVMECMD_C, 1, " Sanitize failed, Current issued ADMIN OP=0x%04X ", rmNvmeOpCode);
            manualCompletion(cStatusSanitizeFailed, 0, cNoRwCmd, 0);
            return;
        }
    }

    if(uOpCode<=cNvmeCmdNvmeMiRecv)
    {
        // CmdIdx=Opcode
    }
    else if((uOpCode>=cNvmeDoorbellBuffConfig)&&(uOpCode<=cNvmeCmdSanitize))
    {
        // 0x7C-0x84
        uCmdIdx=(uOpCode-cNvmeDoorbellBuffConfig)+cNvmeCmdGap1;
    }
    else if((uOpCode>=cNvmeCmdVendorNonData)&&(uOpCode<=cNvmeCmdVendorDataIn))
    {
        // 0xC0, 0xC1, 0xC2
        uCmdIdx=(uOpCode-cNvmeCmdVendorNonData)+cNvmeCmdGap2;    // get offset in NvmeCmdGrp
    }
    else if((uOpCode>=cNvmeCmdLiteonVendorNonData)&&(uOpCode<=cNvmeCmdLiteonVendorDataIn))
    {
        // 0xFC, 0xFD, 0xFE
        uCmdIdx=(uOpCode-cNvmeCmdLiteonVendorNonData)+cNvmeCmdGap3;    // get offset in NvmeCmdGrp
    }
    else
    {
        uCmdIdx=cNvmeCmdInvalidOpCode;    // Any calling Invalid command idx
    }

    addCmdHistory();

    if(((uOpCode==cNvmeCmdSetFeatures)||(uOpCode==cNvmeCmdGetFeatures))&&(rmNvmeFid==cNvmeFeatPowerMgmt))
    {
        nvmeAdminPM(uOpCode);
    }
    else
    {
        if((uOpCode==cNvmeCmdVendorNonData)||(uOpCode==cNvmeCmdVendorDataOut)||(uOpCode==cNvmeCmdVendorDataIn)
           ||(uOpCode==cNvmeCmdLiteonVendorNonData)||(uOpCode==cNvmeCmdLiteonVendorDataOut)||(uOpCode==cNvmeCmdLiteonVendorDataIn))
        {
            NLOG(cLogHost, NVMECMD_C, 1, "  VU Function Code=0x%02X, Mode Code=0x%02X ",
                 (WORD)(rmNVmeLiteonVscFunctionCode<<8|rmNVmeLiteonVscModeCode));
            NLOG(cLogHost, NVMECMD_C, 4, "  DW13=0x%08X, DW14=0x%08X ", (WORD)(rmNvmeCdw13>>16), (WORD)rmNvmeCdw13, (WORD)(rmNvmeCdw14>>16),
                 (WORD)rmNvmeCdw14);
            loadISPCodeCore0(cSmiVuIsp, 0);
        }

#if _ENABLE_SECAPI
        else if((uOpCode==cNvmeCmdSecuritySend)||(uOpCode==cNvmeCmdSecurityRecv))
        {
            if(gsWproInfo.uCnt>=cWproGcThr)
            {
                swapWproBlkCore0();
            }

            // If host craze to swap security code about 15000 times, SLC block will be popped out of spare.
            if(g16PushSpareCnt)
            {
                chkPushSpareQCore0(0);
            }

            gInSecApi=1;
            loadISPCodeCore0(cSecTsbBank, 3);
        }
#endif/* if _ENABLE_SECAPI */
        else
        {
            loadISPCodeCore0(cNvmeIsp, 0);
        }

        NvmeCmdGrp[uCmdIdx]();
#if _ENABLE_SECAPI
        if((uOpCode==cNvmeCmdSecuritySend)||(uOpCode==cNvmeCmdSecurityRecv))
        {
            gInSecApi=0;
        }
        else
#endif
        {
            loadISPCodeCore0(cRwIsp, 0);
        }
    }

#if _ENABLE_ATA_PASSTHROUGH
    if(rmChkSecurityErasePrepare)
    {
        if(uOpCode!=cNvmeCmdSecuritySend)
        {
            rmClrSecurityErasePrepare;
            gbSecAPIClearATASecurityPrepare=1;
        }
    }
#endif

#if (_ENABLE_DASP_LED)
    rmRtc32kIntDisable;
    mClrDaspLed;
#endif
}    /* nvmeHandleAdmin */

// handle admin set/get feature Power Management command
void nvmeAdminPM(BYTE uOpCode)
{
    LWORD u32CmdSpecific=0, u32NsId=rmNvmeNsId;
    WORD u16StatusCode=cStatusSuccess;
    BYTE uSel=rmNvmeSel, uSkipInternalPsChange=0, uPm=rmNvmePmWithWh;

    switch(uOpCode)
    {
        case cNvmeCmdSetFeatures:
            NLOG(cLogHost, NVMECMD_C, 3, " Set Feature PS, SV=0x%04X, Attr=0x%08X", rmNvmeSv>>7, rmNvmeCmdDw11>>16, rmNvmeCmdDw11);

            if((rmNvmePowerState>gsLightSwitch.usNvmeLs.uNpss)
               /*||chkDstInProgress()*/    /*||mChkSanitizeInProgress*/||mChkDummyWrite)    // For Devx sanitize test  20181219_SamHu_01
            {
                if(chkDstInProgress())
                {
                    NLOG(cLogHost, NVMECMD_C, 0, " DstInProgress() ");
                }

                if(mChkDummyWrite)
                {
                    NLOG(cLogHost, NVMECMD_C, 1, "nvmeAdminPM mSetDummyWrite! FailType=0x%04x", gsFtlDbg.u16DummyFailType);
                }

                u16StatusCode=cStatusInvalidField;
            }
            else
            {
#if 0    // _SM226X_A0
                // Backup PCIe MSIx Table once
                if((!gMsixTableFlag)&&rmChkMsixCtrlRegMsixEnable)
                {
                    for(uIdx=0; uIdx<64; uIdx++)
                    {
                        gar32BkMsixTab[uIdx]=rmPcieMsixTable(uIdx);
                    }

                    gMsixTableFlag=1;
                }
#endif

                if((u32NsId!=cNamespaceAll)&&(u32NsId!=cNamespaceNotSpecific))
                {
                    u16StatusCode=cStatusFeatureNotNsSpecific;
                    NLOG(cLogPS, NVMECMD_C, 0, " NSID Err");
                }

                if(!chkHostEnAspm()&&(rmNvmePowerState>=cPs3))
                {
                    uSkipInternalPsChange=1;
                    NLOG(cLogPS, NVMECMD_C, 0, " PS>3 ASPM Dis");
                }

#if 0
                u16StatusCode=nvmeSetFeatureAttribute((NVMEFEATURESEL *)&gpNvmeFeatVar->usFeat.usPowerManagement, rmNvmeCmdDw11, rmNvmeSv);
#else
                if(rmNvmeSv)
                {
                    if(gsPowerState.uFeatVal.u32SelSC&cSaveable)
                    {
                        gsPowerState.uFeatVal.u32Saved=uPm;
                        gsPowerState.uFeatVal.u32Current=uPm;
                        // u16StatusCode=cStatusSuccess;
                    }
                    else
                    {
                        u16StatusCode=cStatusFeatureIdUnSavable;
                    }
                }
                else
                {
                    if(gsPowerState.uFeatVal.u32SelSC&cChangeable)
                    {
                        gsPowerState.uFeatVal.u32Current=uPm;
                        // u16StatusCode=cStatusSuccess;
                    }
                    else
                    {
                        u16StatusCode=cStatusFeatureUnChangable;
                    }
                }
#endif/* if 0 */

                if((u16StatusCode==cStatusSuccess)&&(!uSkipInternalPsChange))
                {
                    // gsPowerState.uHostNextPs=gpNvmeFeatVar.usFeat.usPowerManagement.u32Current;
                    gsPowerState.uHostNextPs=rmNvmePowerState;
                    // Host set feature - Power state 0x%02X, Cur State 0x%02X
                    NLOG(cLogPS,
                         NVMECMD_C,
                         1,
                         " Host set feature - Power state=0x%02X, CurPS=0x%02X ",
                         (gsPowerState.uHostNextPs<<8)|gsPowerState.uDevCurPs);

#if APST_Timer
                    gApstOperationToPs3=0xFF;
                    g32APSTTimeGap=0;        // 20190604_LeverYu_APST timing
#endif

                    if(gsPowerState.uHostNextPs<cPs3)    // PS0 / PS1 / PS2
                    {
                        gsPowerState.uHostLastPs=gsPowerState.uHostNextPs;    // store last power state
                        mPSChgClrPs34;
                        // mPSChgClrLink12;
                        mPSChgClrThrottling;

                        chgCurrentPowerState(gsPowerState.uHostNextPs);
                    }
                    else if(gsPowerState.uDevCurPs!=gsPowerState.uHostNextPs)    // PS3 / PS4
                    {
                        gsPowerState.uDevNextPs=gsPowerState.uHostNextPs;
                        gLowPowerStateRetryCnt=0;
                        mPSChgSetPs34;
                        // mPSChgSetLink12;
                    }
                }

                startRtcCountingMs();    // remove for latency
            }

            break;

        case cNvmeCmdGetFeatures:
            NLOG(cLogHost, NVMECMD_C, 2, " Get Feature PS, FID=0x%04X, SEL=0x%04X ", rmNvmeFid, uSel);

#if 0
            // Update Power State
            gpNvmeFeatVar->usFeat.usPowerManagement.u32Current=gsPowerState.uDevCurPs;
            u32CmdSpecific=nvmeGetFeatureAttribute((NVMEFEATURESEL *)&gpNvmeFeatVar->usFeat.usPowerManagement, uSel);
#else
            if((u32NsId!=cNamespaceAll)&&((u32NsId>gsLightSwitch.usNvme2Ls.u32NamespaceNum)
                                          ||((u32NsId!=cNamespaceNotSpecific)&&(!(gsNamespace.uActiveBitMap&cbBitTab[u32NsId-1])))))
            {
                u16StatusCode=cStatusInvalidNsFormat;
            }

            if(uSel==cNvmeGetFeatSelCurrent)
            {
                u32CmdSpecific=gsPowerState.uFeatVal.u32Current;
            }
            else if(uSel==cNvmeGetFeatSelDefault)
            {
                u32CmdSpecific=gsPowerState.uFeatVal.u32Default;
            }
            else if(uSel==cNvmeGetFeatSelSaved)
            {
                if((gsLightSwitch.usNvmeLs.uOncs&cSaveFieldAndTheSelectField)&&(gsPowerState.uFeatVal.u32Saved!=cNvmeFeatSavedInvalid))
                {
                    u32CmdSpecific=gsPowerState.uFeatVal.u32Saved;
                }
            }
            else if(uSel==cNvmeGetFeatSelSc)
            {
                u32CmdSpecific=gsPowerState.uFeatVal.u32SelSC;
            }
            else    // SEL field set to a reserved, should retrun invalid field
            {
                u16StatusCode=cStatusInvalidField;
            }
            break;
#endif/* if 0 */
        default:
            u16StatusCode=cStatusInvalidOpCode;
            break;
    }    /* switch */

    if(u16StatusCode)
    {
        u32CmdSpecific=0;    // WD Jira-88
    }

    manualCompletion(u16StatusCode, u32CmdSpecific, cNoRwCmd, 0);    // manual send completion, and pop next cmd
}    /* nvmeAdminPM */

void nvmeVendorNonDataSwap()
{
    mCallFuncPtr(cfuncVendorNonData);
}

void nvmeVendorDataOutSwap()
{
    mCallFuncPtr(cfuncVendorDataOut);
}

void nvmeVendorDataInSwap()
{
    mCallFuncPtr(cfuncVendorDataIn);
}

void nvmeLiteonVendorNonDataSwap()
{
    mCallFuncPtr(cfuncLiteonVendorNonData);
}

void nvmeLiteonVendorDataOutSwap()
{
    mCallFuncPtr(cfuncLiteonVendorDataOut);
}

void nvmeLiteonVendorDataInSwap()
{
    mCallFuncPtr(cfuncLiteonVendorDataIn);
}

#if 0
void nvmeVuCmdNonDataSwap()
{
    // loadIspCode(cNvmeIsp,0);
    // codeFuncPtr[cfuncNvmeVuCmdNonData]();
    mCallFuncPtr(cfuncNvmeVuCmdNonData);
    // loadIspCode(cRwIsp,0);
}

void nvmeVuCmdDataOutSwap()
{
    // loadIspCode(cNvmeIsp,0);
    // codeFuncPtr[cfuncNvmeVuCmdDataOut]();
    mCallFuncPtr(cfuncNvmeVuCmdDataOut);
    // loadIspCode(cRwIsp,0);
}

void nvmeVuCmdDataInSwap()
{
    // loadIspCode(cNvmeIsp,0);
    // codeFuncPtr[cfuncNvmeVuCmdDataIn]();
    mCallFuncPtr(cfuncNvmeVuCmdDataIn);
    // loadIspCode(cRwIsp,0);
}

#endif/* if 0 */

void updateNvmeFeatureSetting()
{
    NVMEFEATURESEL *upNvmeFeature=(void *)&gpNvmeFeatVar->usFeat;
    BYTE uLoop;

    if((!mNvmeChkShn)&&(!mNvmeChkShnEntry))
    {
        if(gsWproInfo.u16arWproIdxPagePtr[cWproFeaturePg]!=c16BitFF)
        {
            readWproPageCore0(cWproFeaturePg, cNvmeFeatSIdx, 0);
        }

        if(gsPowerState.uFeatVal.u32SelSC)    // Don't call at bootFunc
        {
            bopCopyRam((LWORD)&gpNvmeFeatVar->usFeat.usPowerManagement,
                       (LWORD)&gsPowerState.uFeatVal, (sizeof(NVMEFEATURESEL)-sizeof(LWORD)), cCopyDccm2Tsb|cBopWait);
        }

#if _ENABLE_NVME_LS
        if(gsLightSwitch.usNvmeLs.uOncs&cSaveFieldAndTheSelectField)
#endif
        {
            for(uLoop=0; uLoop<cNvmeFeatEntryNumber; uLoop++)
            {
                if(upNvmeFeature->u32SelSC&cSaveable)
                {
                    if(upNvmeFeature->u32Saved!=cNvmeFeatSavedInvalid)
                    {
                        upNvmeFeature->u32Current=upNvmeFeature->u32Saved;
                    }
                    else
                    {
                        upNvmeFeature->u32Current=upNvmeFeature->u32Default;
                    }
                }
                else
                {
                    upNvmeFeature->u32Current=upNvmeFeature->u32Default;
                }

                upNvmeFeature++;
            }
        }
        else
        {
            for(uLoop=0; uLoop<cNvmeFeatEntryNumber; uLoop++)
            {
                upNvmeFeature->u32Current=upNvmeFeature->u32Default;
                upNvmeFeature++;
            }
        }

        gsNvmeAer.u32AerCriticalWarning=gpNvmeFeatVar->usFeat.usAsyncEventCfg.u32Current;

        // volatile write cache (in PS, it is not saveable feature)
        if(gpNvmeFeatVar->usFeat.usVolatileWc.u32Current)
        {
            mSetCacheEnable;
        }
        else
        {
            mClrCacheEnable;
        }

        // Host Controlled Thermal Management
        // make sure saved value is non-zero before convert to Celesius
        gMt1In=0;
        gMt2In=0;
        gMt1Out=0;
        gMt2Out=0;
#if _EN_Delay_Dis_LTSSM
        gGCRestFlg=0;
        IORestFlg=0;
#endif

        if(gpNvmeFeatVar->usFeat.usHostThermalPwrMgmt.u32Current>>16)
        {
            gMt1In=mChgKelvintoCelsius(gpNvmeFeatVar->usFeat.usHostThermalPwrMgmt.u32Current>>16);
            gMt1Out=gMt1In-gsLightSwitch.usThermalLs.uMt1FallDelta;
        }

        if(gpNvmeFeatVar->usFeat.usHostThermalPwrMgmt.u32Current&0x0000FFFF)
        {
            gMt2In=mChgKelvintoCelsius(gpNvmeFeatVar->usFeat.usHostThermalPwrMgmt.u32Current&0x0000FFFF);
            gMt2Out=gMt2In-gsLightSwitch.usThermalLs.uMt2FallDelta;
        }

#ifdef _SUPPORT_FEATURE_DITM    // 20190218_Jesse_01, Add for Dell spec "ENG0013785_A01", DITM saveable doesn't keep after Power-off.
// #if (0)    // 20181219_Jesse_01, Modify for eDevx NFEA18.G00 Feature 0x10 test
#if (OEM==DELL)    // 20190219_Jesse_01, Add for Lenovo "NVMe Pur spec 1.26" DITT function
        if(mNvmeChkPowerOn)    // Only do in Power_On process
        {
            gpNvmeFeatVar->usFeat.usDellHdDITM.u32Current=gpNvmeFeatVar->usFeat.usDellHdDITM.u32Default;
            // gpNvmeFeatVar->usFeat.usDellHdDITM.u32Saved=cNvmeFeatSavedInvalid;    // Clear Save data
            gpNvmeFeatVar->usFeat.usDellHdDITM.u32Saved=gpNvmeFeatVar->usFeat.usDellHdDITM.u32Default;    // Clear Save data
// 20190528_Jesse_01, Add for Dell 3D512G for Dell spec A02 DITM function
#if ((PRODUCT_NAME&0x0008)==0x0008)
            gpNvmeFeatVar->usFeat.usHostThermalPwrMgmt.u32Current=gpNvmeFeatVar->usFeat.usHostThermalPwrMgmt.u32Default;
            gpNvmeFeatVar->usFeat.usHostThermalPwrMgmt.u32Saved=gpNvmeFeatVar->usFeat.usHostThermalPwrMgmt.u32Default;
#endif
#elif (OEM==LENOVO)
        {
#endif

#if (OEM==DELL)
// 20190528_Jesse_01, Add for Dell 3D512G for Dell spec A02 DITM function
#if ((PRODUCT_NAME&0x0008)==0x0008)
            if(gpNvmeFeatVar->usFeat.usHostThermalPwrMgmt.u32Current>>16)
            {
                gMt1In=mChgKelvintoCelsius(gpNvmeFeatVar->usFeat.usHostThermalPwrMgmt.u32Current>>16);
                gMt1Out=gMt1In-gsLightSwitch.usThermalLs.uMt1FallDelta;
            }

            if(gpNvmeFeatVar->usFeat.usHostThermalPwrMgmt.u32Current&0x0000FFFF)
            {
                gMt2In=mChgKelvintoCelsius(gpNvmeFeatVar->usFeat.usHostThermalPwrMgmt.u32Current&0x0000FFFF);
                gMt2Out=gMt2In-gsLightSwitch.usThermalLs.uMt2FallDelta;
            }
#else
            if(gpNvmeFeatVar->usFeat.usDellHdDITM.u32Current>>16)
            {
                gMt1In=mChgKelvintoCelsius(gpNvmeFeatVar->usFeat.usDellHdDITM.u32Current>>16);
                gMt1Out=gMt1In-gsLightSwitch.usThermalLs.uMt1FallDelta;
            }

            if(gpNvmeFeatVar->usFeat.usDellHdDITM.u32Current&0x0000FFFF)
            {
                gMt2In=mChgKelvintoCelsius(gpNvmeFeatVar->usFeat.usDellHdDITM.u32Current&0x0000FFFF);
                gMt2Out=gMt2In-gsLightSwitch.usThermalLs.uMt2FallDelta;
            }
#endif/* if ((PRODUCT_NAME&0x0008)==0x0008) */
#endif/* if (OEM==DELL) */
        }
#endif/* ifdef _SUPPORT_FEATURE_DITM */
        mNvmeClrPowerOn;    // 20190218_Jesse_01, Add for Dell spec "ENG0013785_A01", DITM saveable doesn't keep after Power-off.

        gMt3In=gsLightSwitch.usThermalLs.uMt3;
        gMt3Out=gsLightSwitch.usThermalLs.uMt3-gsLightSwitch.usThermalLs.uMt3FallDelta;
        /*
           #if OEM == HP //throttling setting for HP F.J. Kuo 20190401
           * gMt2In=84;
           * gMt2Out=81;
           * gMt3In=90; //for HP entering Mt3 status won't back to PS2 PS1 or PS0
           * gsLightSwitch.usThermalLs.usPs1.u16SysClock=250;
           * gsLightSwitch.usThermalLs.usPs1.u16FlashClock=100;
           * gsLightSwitch.usThermalLs.usPs1.u16LdpcClock=100;
           * gsLightSwitch.usThermalLs.usPs2.u16SysClock=25;
           * gsLightSwitch.usThermalLs.usPs2.u16FlashClock=33;
           * gsLightSwitch.usThermalLs.usPs2.u16LdpcClock=33;
           * gsLightSwitch.usThermalLs.usPsShutdown.u16SysClock=25; //the min setting for clock
           * gsLightSwitch.usThermalLs.usPsShutdown.u16FlashClock=33;
           * gsLightSwitch.usThermalLs.usPsShutdown.u16LdpcClock=33;
           #elif OEM == DELL //throttling setting for DELL in master F.J. Kuo 20190403
           * gMt1In=82;
           * gMt1Out=79;
           * gMt2In=84;
           * gMt2Out=79;
           * gMt3In=85;
           * gMt3Out=79;
           #endif
           */
        // Update current operating attribute value to HW
        rmSetFeatArbitrationAll(gpNvmeFeatVar->usFeat.usArbitration.u32Current);

#if _RR_WORKAROUND    // HW setting
        rmSetFeatArbitrationHpw(127);    // CSSD-2875, CSSD-2833
        rmSetFeatArbitrationMpw(127);
        rmSetFeatArbitrationLpw(127);
        rmSetFeatArbitrationAb(3);
#endif
        rmSetFeatCoalescing(gpNvmeFeatVar->usFeat.usIntCoalescing.u32Current);

        for(uLoop=0; uLoop<16; uLoop++)
        {
            rmClrFeatIntVecCfgUpdate;
            rmSetFeatIntVecCfg(gpNvmeFeatVar->usFeat.usIntVecCfg[uLoop].u32Current);
            rmSetFeatIntVecCfgUpdate;
        }

        bopCopyRam((LWORD)&gsPowerState.uFeatVal,
                   (LWORD)&gpNvmeFeatVar->usFeat.usPowerManagement, sizeof(NVMEFEATURESEL), cCopyTsb2Dccm|cBopWait);

        // CSSD-4031 gsPowerState.uHostLastPs should also change at PCIe Reset/NVMe Reset/FLR.
        if((gsPowerState.uFeatVal.u32Current&cPowerStateMask)<cPs3)    // PS 0/1/2
        {
            gsPowerState.uHostLastPs=(gsPowerState.uFeatVal.u32Current&cPowerStateMask);

            // Change to default state
            chgCurrentPowerState(gsPowerState.uHostLastPs);
        }

#if _ENABLE_NVMEFEAT_APST
        updateNvmeApstTable();
#endif

        if(gpNvmeFeatVar->usFeat.usTemperatureThres[cOverTempTh][0].u32Current!=gsLightSwitch.usNvmeLs.u16WcTemp)
        {
            gsSmart.usStatus.u16OverTempThres=gpNvmeFeatVar->usFeat.usTemperatureThres[cOverTempTh][0].u32Current;
        }

        if(gpNvmeFeatVar->usFeat.usTemperatureThres[cUnderTempTh][0].u32Current!=0)
        {
            gsSmart.usStatus.u16UnderTempThres=gpNvmeFeatVar->usFeat.usTemperatureThres[cUnderTempTh][0].u32Current;
        }

        mSetStartThrottlingSt;
        initTimestamp(0, 0, cInitializedByReset);

        for(uLoop=0; uLoop<gsLightSwitch.usNvme2Ls.u32NamespaceNum; uLoop++)
        {
            if(!(gpNvmeFeatVar->usFeat.usLbaRangeType[uLoop].u32SelSC&cSaveable))
            {
                bopClrRam((LWORD)&gpNvmeFeatVar->usLbaRangeTypeEntry[uLoop],
                          sizeof(LBARANGETYPE),
                          0x00000000,
                          cBopWait|cClrTsb);

                if(gsLightSwitch.usNvmeLs.uFeatOption&cEnableNamespace)
                {
                    gpNvmeFeatVar->usLbaRangeTypeEntry[uLoop][0].uAttribute=1;    // LBA range may be overwritten
                    gpNvmeFeatVar->usLbaRangeTypeEntry[uLoop][0].u64Nlb=((g32HostTotalDataSectorCnt/gsLightSwitch.usNvme2Ls.u32NamespaceNum)-1);
                }
                else
                {
                    gpNvmeFeatVar->usLbaRangeTypeEntry[0][0].uAttribute=1;
                    gpNvmeFeatVar->usLbaRangeTypeEntry[0][0].u64Nlb=(g32HostTotalDataSectorCnt-1);
                    break;    // Only one namespace case
                }
            }
        }

// #if (OEM==DELL)    // 20181010_Jesse_01, Add for Dell spec "ENG0013785_A01"
// #if _ENABLE_SCP_PLP
//        if(gpNvmeFeatVar->usFeat.usDellScpFunction.u32Saved)
//        {
//            gScpEnable=gpNvmeFeatVar->usFeat.usDellScpFunction.u32Current;
//        }
// #endif
// #endif

        if(gpNvmeFeatVar->usFeat.usErrorRecovery[uLoop].u32Current&cDulbeEnable)
        {
            gsNamespace.uDulbeBitMap|=cbBitTab[uLoop];
        }
        else
        {
            gsNamespace.uDulbeBitMap&=~cbBitTab[uLoop];
        }

#if (_ENABLE_SCP_PLP)
        // update SCP flag
        if(gpNvmeFeatVar->usFeat.usPlpScp.u32Saved)
        {
            if(gpNvmeFeatVar->usFeat.usPlpScp.u32Current)
            {
                mSetNvmeEnPlpScp;
                rSysCtrl0[0x13A]|=cBit7;
                NLOG(cLogHost, NVMECMD_C, 1, " PLP_EN=0x%04X ", rSysCtrl0[0x13A]);
            }
            else
            {
                mClrNvmeEnPlpScp;
                rSysCtrl0[0x13A]&=~cBit7;
                NLOG(cLogHost, NVMECMD_C, 1, " PLP_Dis=0x%04X ", rSysCtrl0[0x13A]);
            }
        }
        else
        {
            mClrNvmeEnPlpScp;
            rSysCtrl0[0x13A]&=~cBit7;
            NLOG(cLogHost, NVMECMD_C, 1, " PLP_default=0x%04X ", rSysCtrl0[0x13A]);
        }
#endif/* if (_ENABLE_SCP_PLP) */

        progWproPageCore0(cWproFeaturePg, cNvmeFeatSIdx);
    }

    gsSmart.usStatus.u16OverTempThres=gsLightSwitch.usNvmeLs.u16WcTemp;
    gsSmart.usStatus.u16UnderTempThres=0;
}    /* updateNvmeFeatureSetting */

#if _ENABLE_NVMEFEAT_APST
void updateNvmeApstTable()
{
    LWORD u32MaxApstSize;

    u32MaxApstSize=sizeof(APSTTABLE)*gsLightSwitch.usNvmeLs.uNpss;

    if(gpNvmeFeatVar->usFeat.usAutoPst.u32Saved!=cNvmeFeatSavedInvalid)
    {
        gpNvmeFeatVar->usFeat.usAutoPst.u32Current=gpNvmeFeatVar->usFeat.usAutoPst.u32Saved;
        g32ApstEnable=gpNvmeFeatVar->usFeat.usAutoPst.u32Saved;

        // if not resume from PS4, restore saved value to current
        bopCopyRam((LWORD)&gpNvmeFeatVar->usApstEntry.uarCurrent,
                   (LWORD)&gpNvmeFeatVar->usApstEntry.uarSaved, u32MaxApstSize, cCopyTsb2Tsb|cBopWait);
    }
    else
    {
        gpNvmeFeatVar->usFeat.usAutoPst.u32Current=gpNvmeFeatVar->usFeat.usAutoPst.u32Default;
        g32ApstEnable=gpNvmeFeatVar->usFeat.usAutoPst.u32Default;

        bopCopyRam((LWORD)&gpNvmeFeatVar->usApstEntry.uarCurrent,
                   (LWORD)&gpNvmeFeatVar->usApstEntry.uarDefault, u32MaxApstSize, cCopyTsb2Tsb|cBopWait);
    }

    bopCopyRam((LWORD)&garApstCurrent,
               (LWORD)&gpNvmeFeatVar->usApstEntry.uarCurrent, u32MaxApstSize, cCopyTsb2Dccm|cBopWait);
}    /* updateNvmeApstTable */

#endif/* if _ENABLE_NVMEFEAT_APST */

void chkAerTempThreshold(WORD u16CurrTemp)
{
    WORD u16KelvinTemp;

    if((gsLightSwitch.usSmartLs.uWarning&cSmartWarnTemperature)&&(!mChkAerTemp))    // Only perform checking if warning bit has not been set
    {
        u16KelvinTemp=mChgCelsiustoKelvin(u16CurrTemp);    // convert to Kelvin

        if((u16KelvinTemp>=gsSmart.usStatus.u16OverTempThres)||(u16KelvinTemp<=gsSmart.usStatus.u16UnderTempThres))
        {
            mSetAerTemp;    // Set Asynchronous Eevent Flag
            // NLOG(cLogSYS, AERCMD_C, 2, " AER_SMART Temp Over, TH=0x%04X, Val=0x%04X ", gsSmart.u16TempThres, u16KelvinTemp);
        }
    }
}    /* chkAerTempThreshold */

void chkAerReliability()
{
    if((gsLightSwitch.usSmartLs.uWarning&cSmartWarnReliability)&&(!mChkAerReliability))
    {
        if((getDriveUsedPercentage()>gsLightSwitch.usSmartLs.uWearLevelingCntThres))    // Romesh request in 105K
        {
            mSetAerReliability;
            // DebugLog(C_LOG_Sys, 0x08, 0, 0, 0, 0, 0, 0);//AER_SMART Reliability
        }
    }
}    /* chkAerReliability */

#if 0
void chkAerReadOnly()
{
    if((gsLightSwitch.usSmartLs.uWarning&cSmartWarnReadOnly)&&(!mChkAerReadOnly))
    {
        mSetAerReadOnly;
        // NLOG_SAVE(cLogSYS, AERCMD_C, 0, cSaveIdReadOnlyMode, "ASSERT LOG: AER_SMART Read Only ");
    }
}

void chkAerVolatileMemFail()
{
    if((gsLightSwitch.usSmartLs.uWarning&cSmartWarnVolatileMemFail)&&(!mChkAerMemoryFail))
    {
        mSetAerMemoryFail;
        // NLOG_SAVE(cLogSYS, AERCMD_C, 0, cSaveIdMemFail, " ASSERT LOG: AER_SMART Mem Fail ");
    }
}

#endif/* if 0 */
BYTE getDriveUsedPercentage()
{
    LWORD u32SumOfGlobEraseCnt=0, u32DriveUsedPercentage;
    WORD u16Fblock, u16AvgOfGlobEraseCnt, u16TotalofGlobErasedBlkCnt=0;

    for(u16Fblock=g16StaticBound; u16Fblock<g16TotalFBlock; u16Fblock++)    // 20181217_Kevin_01
    {
        getGlobEraseCntOfSpecFblock(u16Fblock);

        if(g16OneFblockGlobEraseCnt!=c16BitFF)
        {
            u32SumOfGlobEraseCnt+=g16OneFblockGlobEraseCnt;
            u16TotalofGlobErasedBlkCnt+=1;
        }
    }

    if(u32SumOfGlobEraseCnt!=0)
    {
        u16AvgOfGlobEraseCnt=div(u32SumOfGlobEraseCnt, u16TotalofGlobErasedBlkCnt);
    }
    else
    {
        u16AvgOfGlobEraseCnt=0;
    }

    u32DriveUsedPercentage=div((u16AvgOfGlobEraseCnt*100), g32GrtPeCycle);

    if(u32DriveUsedPercentage>254)
    {
        return 255;
    }
    else
    {
        return u32DriveUsedPercentage;
    }
}    /* getDriveUsedPercentage */

void addErrorLog(WORD u16StatusCode, BYTE uPrdIdx, BYTE uErrorType)
{
    bopClrRam((LWORD)&garErrorLog[gErrLogPtr], sizeof(ERRORINFO), 0x00000000, cBopWait|cClrCore0Dccm);

    if(uErrorType==cIoCommandError)
    {
        garErrorLog[gErrLogPtr].u16SubmissionQueueId=gsPrdInfo.uarPrdQue[uPrdIdx].u16SqId;
        garErrorLog[gErrLogPtr].u16CommandId=gsPrdInfo.uarPrdQue[uPrdIdx].u16Cid;
    }
    else if(uErrorType==cAdminCommandError)
    {
        garErrorLog[gErrLogPtr].u16SubmissionQueueId=rmNvmeSqId;
        garErrorLog[gErrLogPtr].u16CommandId=rmNvmeCid;
    }
    else if(uErrorType==cInvalidDbError)
    {
        garErrorLog[gErrLogPtr].u16SubmissionQueueId=gsInvalidDbInfo.uarErrQid[gsInvalidDbInfo.uErrLogTail];
        garErrorLog[gErrLogPtr].u16CommandId=cNoneSpecificCmdId;
    }
    else
    {
        garErrorLog[gErrLogPtr].u16SubmissionQueueId=cNoneSpecificCmdId;
        garErrorLog[gErrLogPtr].u16CommandId=cNoneSpecificCmdId;
    }

    g32ErrorCountL++;    // (Jack) Request by Ram

    if(!g32ErrorCountL)
    {
        g32ErrorCountH++;
    }

    garErrorLog[gErrLogPtr].u16StatusField=(u16StatusCode<<1);
    garErrorLog[gErrLogPtr].u32arErrorCount[0]=g32ErrorCountL;
    garErrorLog[gErrLogPtr].u32arErrorCount[1]=g32ErrorCountH;
    garErrorLog[gErrLogPtr].u32Namespace=rmNvmeNsId;

    switch(u16StatusCode)
    {
        case cStatusLbaOutofRange:
            garErrorLog[gErrLogPtr].u16ParameterErrorLocation=cParaErrLocationOor;
            garErrorLog[gErrLogPtr].u32arLba[0]=rmNvmeLbaLow;
            mSetAerTransientInternalErr;
            break;

        case cStatusUnrecoveredRdErr:    // (A) get info from prdInfo structure
            garErrorLog[gErrLogPtr].u16ParameterErrorLocation=cNoneSpecificCmdId;
            garErrorLog[gErrLogPtr].u32arLba[0]=gsPrdInfo.uarPrdQue[uPrdIdx].u32LbaAddr;
            mSetAerTransientInternalErr;
            break;

        case cStatusWrFault:
            garErrorLog[gErrLogPtr].u16ParameterErrorLocation=cNoneSpecificCmdId;
            garErrorLog[gErrLogPtr].u32arLba[0]=rmNvmeLbaLow;
            break;

        case cStatusDataXfrErr:
            garErrorLog[gErrLogPtr].u16ParameterErrorLocation=cParaErrLocationDxe;

            if(uErrorType==cIoCommandError)
            {
                garErrorLog[gErrLogPtr].u32arLba[0]=rmNvmeLbaLow;
            }

            mSetAerTransientInternalErr;
            break;

        default:
            garErrorLog[gErrLogPtr].u16ParameterErrorLocation=cNoneSpecificCmdId;
            break;
    }    /* switch */

    gErrLogPtr=addPtrBy1(gErrLogPtr, (gsLightSwitch.usNvmeLs.uElpe+1));
}    /* addErrorLog */

void saveSmartInfo(BYTE uReadWpro)
{
    BYTE uCurrCmdFwSlot=rmNvmeFwCommitFwSlot;

    if(uReadWpro)
    {
        readWproPageCore0(cWproGetLogPg, cNvmeGetLogSIdx, 0);

        gsSmart.usCnt.u64PowerOnSec+=getRtcDiff1s();
        startRtcCounting1s();
        chkOverTmpTime();
    }

    // The rmNvmeFwCommitFwSlot only work under FwDl command
    if(uReadWpro&cUpdateFrs)
    {
        if(!uCurrCmdFwSlot)
        {
            uCurrCmdFwSlot++;
        }

        copyCcmVal((UCBYTE *)(gpGetLog->usFwSlot.uarFrs[uCurrCmdFwSlot]), (BYTE *)(gsSmart.usStatus.uarSaveIspRev), 8);
    }

    if(uReadWpro&cUpdateSlotInfo)
    {
        gpGetLog->usFwSlot.uarFrs[cFirmwareSlotAfi][0]=(gsSmart.usStatus.uCurrFwSlot+1);
    }

    bopCopyRam((LWORD)&gpGetLog->usSmartLog.usSmart, (LWORD)&gsSmart, sizeof(SMARTATTRIBUTE), cCopyDccm2Tsb|cBopWait);
    progWproPageCore0(cWproGetLogPg, cNvmeGetLogSIdx);
}    /* saveSmartInfo */

void resumeHmbSetting(BYTE uReadWpro)
{
    WORD u16Loop;

    if(uReadWpro)
    {
        readWproPageCore0(cWproFeaturePg, cNvmeFeatSIdx, 0);
    }

#if _EN_DisHMBInReset    // 20190805_Chief_DisHMB
    if(gChkFlag&cEnableFakeHMB)
    {
        NLOG(cLogHost, NVMECMD_C, 0, " Enable resumeHmbSetting");
        return;
    }
#endif
    rmSetFixGroupSize(gpNvmeFeatVar->usHmbHwInfo.uFixGroupSize);
    rmSetTotalFixGroupNumber(gpNvmeFeatVar->usHmbHwInfo.u32TotalFixGroupNumber);
    rmSetTotalEntryNumber(gpNvmeFeatVar->usHmbHwInfo.u32HmbDescListEntryCnt);

    for(u16Loop=0; u16Loop<gpNvmeFeatVar->usHmbHwInfo.u32TotalFixGroupNumber; u16Loop++)
    {
        rmDescEntryNumFixGroup(u16Loop+1)=gpNvmeFeatVar->usHmbHwInfo.u16arDescNumInFixGroup[u16Loop+1];
    }

    for(u16Loop=0; u16Loop<gpNvmeFeatVar->usHmbHwInfo.u32HmbDescListEntryCnt; u16Loop++)
    {
        rmHmbDescEntryAddrLow(u16Loop)=gpNvmeFeatVar->usHmbHwInfo.u32arDescEntryAddrLow[u16Loop];
        rmHmbDescEntryAddrHigh(u16Loop)=gpNvmeFeatVar->usHmbHwInfo.u32arDescEntryAddrHigh[u16Loop];
        rmHmbDescEntrySize(u16Loop)=gpNvmeFeatVar->usHmbHwInfo.u32arDescEntrySize[u16Loop];
    }
}    /* resumeHmbSetting */

void initTimestamp(LWORD u32TimestampLow, WORD u16TimestampHigh, BYTE uOrigin)
{
    gpNvmeFeatVar->usTimestamp.uSynchOrigin|=uOrigin;
    gpNvmeFeatVar->usTimestamp.u32TimestampLow=u32TimestampLow;
    gpNvmeFeatVar->usTimestamp.u16TimestampHigh=u16TimestampHigh;
    gpNvmeFeatVar->usTimestamp.u32LastTimestamp=getRtcCurrentMs();
}

void saveNvmeFeatInfo(BYTE uReadWpro)
{
    if(uReadWpro)
    {
        readWproPageCore0(cWproFeaturePg, cNvmeFeatSIdx, 0);
    }

    bopCopyRam((LWORD)&gpNvmeFeatVar->usFeat.usPowerManagement,
               (LWORD)&gsPowerState.uFeatVal, (sizeof(NVMEFEATURESEL)-sizeof(LWORD)), cCopyDccm2Tsb|cBopWait);

    progWproPageCore0(cWproFeaturePg, cNvmeFeatSIdx);
    waitAllChCeBzCore0();

    while(gsTskFifoCtrl.u32HeadPtr!=gsTskFifoCtrl.u32TailPtr)
        ;
}

void updateInvalidDbErrLog()
{
    while(gsInvalidDbInfo.uErrLogHead!=gsInvalidDbInfo.uErrLogTail)
    {
        addErrorLog(cStatusDeviceErr, 0, cInvalidDbError);
        gsInvalidDbInfo.uErrLogTail=addPtrBy1(gsInvalidDbInfo.uErrLogTail, cMaxIoSqCqCnt);
    }
}

BYTE pendingAsyncEvent()
{
    return (((gsNvmeAer.u32AerCriticalWarning<<8)|0xFFFF00FF)&gsNvmeAer.u32AerEvent&gsNvmeAer.u32AerMask)&&gsNvmeAer.uAerQueueCnt;
}

#if (!_ICE_LOAD_ALL)
#pragma default_function_attributes =
#endif







