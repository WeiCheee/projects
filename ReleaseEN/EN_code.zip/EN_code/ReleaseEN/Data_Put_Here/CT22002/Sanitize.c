







#include "inc/TypeDef.h"
#include "inc/Option.h"
#include "inc/ProType.h"
#include "inc/Reg.h"
#include "inc/NvmeCtrl.h"
#include "inc/table.h"
#include "inc/GlobVar0.h"
#include "inc/GlobVarS.h"
#include "inc/GlobVar1.h"

void nvmeSanitize()
{
    LWORD u32NsId=rmNvmeNsId;
    WORD u16StatusCode=cStatusSuccess;
    BYTE uSanitizeMode=rmNvmeSanitizeAction;

    if(gsLightSwitch.usNvme2Ls.u32SaniCap)
    {
#if _ENABLE_SECAPI    // [D.H]For Liteon IF_003
        if(gbEnTCG)
        {
            if(gTcgNviSpLockingLifeCycleState==C_Manufactured)
            {
                // M_ChkWriteLock is unnecessary : WriteLock only exists in Manufactured state
                NLOG_SAVE(cLogSecApiBaseFw,
                          SANITIZE_C,
                          0,
                          cSaveIdSecurity,
                          "  NVMeSanitize() abort, SP Life Cycle = Manufactured.");
                manualCompletion(cStatusInvalidFormat, 0, cNoRwCmd, 0);
                return;
            }
        }
#endif
#if _ENABLE_ATA_PASSTHROUGH
        if(gbEnATAPassThrough)
        {
            if(rmChkSecurityLock||rmChkSecurityFrozen)    // for liteon.
            {
                NLOG_SAVE(cLogSecApiBaseFw,
                          SANITIZE_C,
                          1,
                          cSaveIdSecurity,
                          "  nvmeSanitize(), ATA Security Locked, status = 0x%04X.",
                          gSecurityStatus);
                manualCompletion(cStatusCmdSequenceErr, 0, cNoRwCmd, 0);
                return;
            }
        }
#endif

        if((u32NsId!=cNamespaceAll)&&(u32NsId!=cNamespaceNotSpecific))
        {
            u16StatusCode=cStatusInvalidNsFormat;
        }
        else if(mChkSanitizeCommandErr&&(!gsSanitizeInfo.uAuse)&&
                ((uSanitizeMode==cSanitizeExitFailureMode)||(!rmNvmeSanitizeAuse)))
        {
            u16StatusCode=cStatusSanitizeFailed;
        }
        else if(mChkFwCommitSuccess)
        {
            u16StatusCode=cStatusFwReqSReset;
        }

#if (OEM==DELL)    // 20181214_01 add for NSANI18.g00
        else if(rmNvmeSanitizeNoDeallo)
        {
            u16StatusCode=cStatusInvalidFormat;
        }
#endif
        else
        {
            switch(uSanitizeMode)
            {
                case cSanitizeExitFailureMode:

                    if(mChkSanitizeCommandErr)
                    {
                        mClrSanitizeState;
                    }

                    break;

                case cSanitizeBlockErase:

                    if(!(gsLightSwitch.usNvme2Ls.u32SaniCap&c32BlockErase))
                    {
                        u16StatusCode=cStatusInvalidField;
                    }
                    else
                    {
                        // rmNvmeSanitizeNoDeallo and !rmNvmeSanitizeNoDeallo are the same case.
                        sanitizeBlockErase();
                    }

                    break;

#if _ENABLE_SECAPI
                case cSanitizeCryptoErase:

                    if(!((gbEnAes)||(gsLightSwitch.usNvme2Ls.u32SaniCap&c32CryptoErase)))
                    {
                        u16StatusCode=cStatusInvalidField;
                    }
                    else
                    {
                        gInSecApi=1;    // for progCacheInfoTab();
                        loadISPCodeCore0(cSecTsbBank, 3);
                        SecAPI_NoticeSecCodeSwap(0);

                        if(processCryptoErase())
                        {
                            u16StatusCode=cStatusDeviceErr;
                        }

                        SecAPI_NoticeSecCodeSwap(1);
                        gInSecApi=0;

                        if((!u16StatusCode)&&(!rmNvmeSanitizeNoDeallo))
                        {
                            enableLdpcPipe();
                            processTrim(cNvmeCmdSanitize);
                            disableLdpcPipe();
                        }
                    }
                    break;
#endif/* if _ENABLE_SECAPI */
                case cSanitizeOverwrite:

                    if(!(gsLightSwitch.usNvme2Ls.u32SaniCap&c32Overwrite))
                    {
                        u16StatusCode=cStatusInvalidField;
                    }
                    else
                    {
                        sanitizeOverwrite();
                    }

                    break;

                default:
                    u16StatusCode=cStatusInvalidField;
                    break;
            }    /* switch */

            if(u16StatusCode==cStatusSuccess)
            {
                mClrAerIoTypeMask;
                mClrIoType;
                readWproPageCore0(cWproGetLogPg, cNvmeGetLogSIdx, 0);
                gpGetLog->usSaniLog.u32ScDw10=rmNvmeSanitizeDw10;
                gsSanitizeInfo.uMode=uSanitizeMode;
                gsSanitizeInfo.uAuse=rmNvmeSanitizeAuse;

                if(uSanitizeMode==cSanitizeCryptoErase)
                {
                    mSetSanitizeCompletedNoError;
                    mSetAerSanitizeOperation;
                    gsCurrDstResult.uDstStatus|=cOperationAbortSanitize;
                }
                else if(uSanitizeMode!=cSanitizeExitFailureMode)
                {
                    mSetSanitizeInProgress;
                    gsCurrDstResult.uDstStatus|=cOperationAbortSanitize;
                }

                saveSanitizeInfo(cNotReadWpro);
            }

#if 0    // Security related
            if(u16StatusCode!=cStatusSuccess)    // CSSD-5245
            {
                UpdateFwAuthenticateParameter(SEC_SanitizeFail);    // only update at the end
            }
#endif
        }
    }
    else
    {
        u16StatusCode=cStatusInvalidOpCode;
    }

    manualCompletion(u16StatusCode, 0, cNoRwCmd, 0);
}    /* nvmeSanitize */

void sanitizeStartOperation()
{
    handleCore0VarErase();
    bopClrRam((LWORD)&gsEraseUnitInfo, sizeof(gsEraseUnitInfo), 0x00000000, cClrStcm|cBopWait);
    copyCcmVal((BYTE *)&gsEraseUnitInfo.usEraseParam, (BYTE *)&gsSanitizeInfo.usEraseParam, sizeof(ERASEUNITPARAM));

    eraseUnitStartCore0(cSanitize, rmNvmeSanitizeAction);
}

void sanitizeBlockErase()
{
    bopClrRam((LWORD)&gsSanitizeInfo.usEraseParam, sizeof(ERASEUNITPARAM), 0x00000000, cClrCore0Dccm|cBopWait);
    gsSanitizeInfo.usEraseParam.uTotalPass=1;
    gsSanitizeInfo.usEraseParam.uNeedVerify=0;
    sanitizeStartOperation();
}    /* sanitizeBlockEraseExt */

void sanitizeContinueOperation()
{
    if(mChkSanitizeInProgress)
    {
        if(!eraseUnitContinueCore0())
        {
            if(gsEraseUnitInfo.u32TotalFail)
            {
                mSetSanitizeCommandErr;
            }
            else
            {
                mSetSanitizeCompletedNoError;
            }

            mSetAerSanitizeOperation;
            saveSanitizeInfo(cReadWpro);
        }
    }
}    /* sanitizeContinueOperation */

void saveSanitizeInfo(BYTE uReadWpro)
{
    if(uReadWpro)
    {
        readWproPageCore0(cWproGetLogPg, cNvmeGetLogSIdx, 0);
    }

    bopCopyRam((LWORD)&gpGetLog->usSaniLog.usSanitizeInfo, (LWORD)&gsSanitizeInfo, sizeof(gsSanitizeInfo), cCopyDccm2Tsb|cBopWait);
    bopCopyRam((LWORD)&gpGetLog->usSaniLog.usEraseUnitInfo, (LWORD)&gsEraseUnitInfo, sizeof(gsEraseUnitInfo), cCopyStcm2Tsb|cBopWait);

    if(mChkSanitizeCompletedNoError||mChkSanitizeCommandErr)
    {
        gpGetLog->usSaniLog.u64LastHostWrCmdCnt=g64HostWrCmdCnt;
        gsSmart.usStatus.uWuncEver=0;
        gpGetLog->usSaniLog.uSstatL=mChkSanitizeState;
        gpGetLog->usSaniLog.uSstatH=cSanitizeGlobalDataErased;
    }

    progWproPageCore0(cWproGetLogPg, cNvmeGetLogSIdx);
}    /* saveSanitizeInfo */

void sanitizeOverwrite()
{
    LWORD u32Pattern;

    bopClrRam((LWORD)&gsSanitizeInfo.usEraseParam, sizeof(ERASEUNITPARAM), 0x00000000, cClrCore0Dccm|cBopWait);

    gsSanitizeInfo.usEraseParam.uTotalPass=rmNvmeSanitizeOwrPass;

    if(!gsSanitizeInfo.usEraseParam.uTotalPass)
    {
        gsSanitizeInfo.usEraseParam.uTotalPass=0x10;
    }

    u32Pattern=rmNvmeSanitizeOvrPat;

    if(mod(gsSanitizeInfo.usEraseParam.uTotalPass, 2))
    {
        gsSanitizeInfo.usEraseParam.u32arPattern[0]=u32Pattern;
    }
    else
    {
        gsSanitizeInfo.usEraseParam.u32arPattern[0]=~u32Pattern;
    }

    if(rmNvmeSanitizeOipbp)
    {
        gsSanitizeInfo.usEraseParam.uTotalParam=2;
        gsSanitizeInfo.usEraseParam.u32arPattern[1]=~gsSanitizeInfo.usEraseParam.u32arPattern[0];
    }
    else
    {
        gsSanitizeInfo.usEraseParam.uTotalParam=1;
    }

    // gsSanitizeInfo.usEraseParam.uNeedVerify=1;
    sanitizeStartOperation();
}    /* sanitizeOverwriteExt */

#if 0
BYTE sanitizeCryptoErase()
{
    BYTE uProcessCryptoEraseFail=0;
    uint32_t uencRangeIndex=1;
    secInternalStatus_e usecInternalStatus;

    usecInternalStatus=SAF->gfpSecIntf_ProcessCryptoErase(uencRangeIndex);

    if(usecInternalStatus!=API_SUCCESS)
    {
        uProcessCryptoEraseFail=1;
    }

    // NLOG_SMI_SEC_1(C_LOG_BaseFW, " ProcessCryptoErase(),  usecInternalStatus=0x%04X ",usecInternalStatus);

    return uProcessCryptoEraseFail;
}

#endif/* if 0 */

void eraseUnitStartCore0(BYTE uEraseMode, BYTE uEraseMethod)
{
    TASKENTRY usTskEntry;

    usTskEntry.uTskTyp=cTskEraseUnitStart;
    usTskEntry.uTskOpt=uEraseMode;
    usTskEntry.uTskPgOfst=uEraseMethod;
    insertTaskFifo(usTskEntry);

    while(gsTskFifoCtrl.u32HeadPtr!=gsTskFifoCtrl.u32TailPtr)
        ;
}

BYTE eraseUnitContinueCore0()
{
    TASKENTRY usTskEntry;

    usTskEntry.uTskTyp=cTskEraseUnitContinue;
    insertTaskFifo(usTskEntry);

    while(gsTskFifoCtrl.u32HeadPtr!=gsTskFifoCtrl.u32TailPtr)
        ;

    return gsEraseUnitInfo.usCurrentOperation.uContinue;
}







