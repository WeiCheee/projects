







#include "inc/ProType.h"
#include "inc/Reg.h"
#include "inc/GlobVarT.h"

// void saveIndexBlockCore0();
// void findReadSrc(WORD, WORD);

#if (_PRJ_SMIVU||_ICE_LOAD_ALL)
BYTE dataInVendorCmdReadVendorCmdDebugInfo()
{
    // copyCcmVal((UCBYTE *)&garTsb0[0][0], (UCBYTE *)&gsVendorCmdDebugInfo, cVendorCmdDebugInfoByte);
    return cSuccess;
}

BYTE dataInVendorCmdReadFlashId()
{
    // readFlashId((BYTE *)(&garTsb0[0][0x30]));    // fill garTsb0[0][0x30~0x30+C_CePin*C_MaxChNum*6]
    insertVendorTask(cVendorCore1ReadFlashId);

    garTsb0[0][0x03]=gSectorPerPlaneH;    // [Momo] For Read log vu used

    garTsb0[0][0x04]=cIsp;    // 0:ROM / 1:MPISP / 2:ISP
    garTsb0[0][0x1F0]='S';
    garTsb0[0][0x1F1]='M';
    garTsb0[0][0x1F2]='2';
    garTsb0[0][0x1F3]='2';
    garTsb0[0][0x1F4]='6';
    garTsb0[0][0x1F5]='3';
    garTsb0[0][0x1F6]='X';
    garTsb0[0][0x1F7]='T';

    if(gsWproInfo.u16arWproIdxPagePtr[cWproEventLog]!=c16BitFF)
    {
        garTsb0[1][0x09F]=1;    // [Momo]For Read log vu used
    }
    else
    {
        garTsb0[1][0x09F]=0;
    }

    copyCcmVal((BYTE *)&garTsb0[0x02][0x00], (BYTE *)cParaAddr, cSizeOfParaTab);

    //////////////////////////////////////////////////////////////////////////////////////for EZTool
    copyCcmVal((BYTE *)garTsb0[3], (BYTE *)&cbMainTag, 16);
    garTsb0[3][0x10]=cIsp;    // 0:ROM / 1:MPISP / 2:ISP
    garTsb0[3][0x11]='I';
    garTsb0[3][0x12]='S';
    garTsb0[3][0x13]='P';

    garTsb0[3][0x20]='S';
    garTsb0[3][0x21]='M';
    garTsb0[3][0x22]='2';
    garTsb0[3][0x23]='2';
    garTsb0[3][0x24]='6';
    garTsb0[3][0x25]='3';
    garTsb0[3][0x26]='X';
    garTsb0[3][0x27]='T';

#if ((!_GREYBOX)&&_EN_AUTHENTICATION)
    if(gsLightSwitch.usSecLs.uHpAuthen&cBit0)
    {
        garTsb0[3][0x30]='A';
        garTsb0[3][0x31]='u';
        garTsb0[3][0x32]='t';
        garTsb0[3][0x33]='h';
        garTsb0[3][0x34]='e';
        garTsb0[3][0x35]='n';
        garTsb0[3][0x36]='t';
        garTsb0[3][0x37]='i';
        garTsb0[3][0x38]='c';
        garTsb0[3][0x39]='a';
        garTsb0[3][0x3A]='t';
        garTsb0[3][0x3B]='i';
        garTsb0[3][0x3C]='o';
        garTsb0[3][0x3D]='n';
        garTsb0[3][0x3E]='E';
        garTsb0[3][0x3F]='n';
    }
#endif/* if ((!_GREYBOX)&&_EN_AUTHENTICATION) */
    //////////////////////////////////////////////////////////////////////////////////////
    return cSuccess;
}    /* dataInVendorCmdReadFlashId */

BYTE dataInVendorCmdReadRam()
{
    BYTE *upMem;

    upMem=(BYTE *)(rmNvmeSubCmdParam1);

#if (_GREYBOX)
    copySdram2Tsb((UCBYTE *)&garTsb0[0][0], (UCBYTE *)upMem, (g32HostXfrCnt*512));
#else
    copyCcmVal((UCBYTE *)&garTsb0[0][0], (UCBYTE *)upMem, (g32HostXfrCnt*512));
#endif
    return cSuccess;
}

BYTE dataInVendorCmdReadLog()
{
    bopClrRam(c32Tsb0SAddr, (2*gSectorPerPlaneH*cSingleSectorByte),
              0x00000000, cBopWait|cClrTsb);

    if(g32CmdPara3&c32Bit31)
    {
        saveEventLog(0);
    }
    else
    {
        if(g32CmdPara3&c32Bit30)
        {
            saveEventLog(1);
        }
        else
        {
            readWproPageCore0(cWproEventLog, c16Tsb0SIdx, 0);
        }
    }

    readRdCntToTsb0Core0(gSectorPerPlaneH);
    return cSuccess;
}    /* dataInVendorCmdReadLog */

BYTE dataInVendorCmdReadWproPage()
{
    readWproPageCore0(rmNvmeSubCmdParam1, c16Tsb0SIdx, rmNvmeSubCmdParam2);
    return cSuccess;
}

BYTE dataInVendorCmdReadDriveInfo()
{
    // MOVE Parameter Table in the front.
    copyCcmVal((BYTE *)garTsb0, (BYTE *)cParaAddr, cSizeOfParaTab);

    copyCcmVal((BYTE *)garTsb0[1], (BYTE *)&cbMainTag, 16);
    garTsb0[1][0x10]=cIsp;    // 0:ROM / 1:MPISP / 2:ISP
    garTsb0[1][0x11]='I';
    garTsb0[1][0x12]='S';
    garTsb0[1][0x13]='P';

    garTsb0[1][0x20]='S';
    garTsb0[1][0x21]='M';
    garTsb0[1][0x22]='2';
    garTsb0[1][0x23]='2';
    garTsb0[1][0x24]='6';
    garTsb0[1][0x25]='3';
    garTsb0[1][0x26]='X';
    garTsb0[1][0x27]='T';

#if ((!_GREYBOX)&&_EN_AUTHENTICATION)
    if(gsLightSwitch.usSecLs.uHpAuthen&cBit0)
    {
        garTsb0[1][0x30]='A';
        garTsb0[1][0x31]='u';
        garTsb0[1][0x32]='t';
        garTsb0[1][0x33]='h';
        garTsb0[1][0x34]='e';
        garTsb0[1][0x35]='n';
        garTsb0[1][0x36]='t';
        garTsb0[1][0x37]='i';
        garTsb0[1][0x38]='c';
        garTsb0[1][0x39]='a';
        garTsb0[1][0x3A]='t';
        garTsb0[1][0x3B]='i';
        garTsb0[1][0x3C]='o';
        garTsb0[1][0x3D]='n';
        garTsb0[1][0x3E]='E';
        garTsb0[1][0x3F]='n';
    }
#endif/* if ((!_GREYBOX)&&_EN_AUTHENTICATION) */
    return cSuccess;
}    /* dataInVendorCmdReadDriveInfo */

BYTE dataInVendorCmdReadGlobEraseCnt()
{
    // BYTE *upMem;
    insertVendorTask(cVendorCore1ReadGlobEraseCnt);

    // upMem=(BYTE *)(rmNvmeSubCmdParam1);
    // copyCcmVal((UCBYTE *)&garTsb0[0][0], (UCBYTE *)upMem, (g32HostXfrCnt*512));
    return cSuccess;
}

BYTE dataInVendorCmdReadGlobReadCnt()
{
    insertVendorTask(cVendorCore1ReadGlobReadCnt);

    return cSuccess;
}

#if 0
void dataInVendorCmdFlashConnectivityTest()
{
    BYTE uCh;
    BYTE uCe;
    BYTE uDie;
    BYTE uNoFlash;
    BYTE uMatchCnt;
    WORD u16Delay;
    WORD uShiftAddr;
    volatile BYTE *upTsb0;

    upTsb0=garTsb0[0];

    rmSelMulFlash(0xff);

    // Read Test
    for(uCe=0; uCe<cCePin; uCe++)
    {
        for(uCh=0; uCh<cMaxChNum; uCh++)
        {
            for(uDie=0; uDie<1; uDie++)
            {
                uShiftAddr=uDie<<4;
                rFLCtrl=rFshA[uCh];
                rFLCtrl[rcCeOn]=uCe;
                rmCle(0x00);
                rmAle(0x00);
                rmAle(0x00);
                rmAle(0x00);
                rmAle(0x00);
                rmAle(uShiftAddr);
                rmCle(0x30);
                rmCle(0x78);
                rmAle(0x00);
                rmAle(0x00);
                rmAle(uShiftAddr);

                if(rmGpioP06SelToggle)
                {
                    rmRdStatus(cPollMaskNor);
                    uNoFlash=0;
                    u16Delay=0;

                    while(rmChkCmdFifoBz)
                    {
                        u16Delay++;

                        if(u16Delay>2000)
                        {
                            uNoFlash=1;
                            break;
                        }
                    }

                    if(uNoFlash==0)
                    {
                        upTsb0[uCh*cCePin+uCe]|=cbBitTable[uDie];
                    }
                }
                else
                {
                    rmEnMaskACle;
                    rmCle(0xFF);
                    rmDisMaskACle;
                    rmManRd(1);

                    while(rmChkCmdFifoBz)
                        ;

                    uMatchCnt=0;

                    while((uMatchCnt<10)&&(rFLCtrl[0x104]&c16Bit6))
                    {
                        rmManRd(1);

                        while(rmChkCmdFifoBz)
                            ;

                        uMatchCnt++;
                    }

                    if(uMatchCnt<10)
                    {
                        upTsb0[uCh*cCePin+uCe]|=cbBitTable[uDie];
                    }
                }

                rmChSoftReset;    // rmRstCmdFifo;
                rmAllCeOff;
            }
        }

        rmAllCeOff;

        if(uCh>cMaxChNum)
        {
            uCh=cMaxChNum;
            rFLCtrl=rFshA[8];
        }
    }
}    /* dataInVendorCmdFlashConnectivityTest */

#endif/* if 0 */
BYTE dataInVendorCmdReadPhysicalPage()
{
#if 1
    insertVendorTask(cVendorCore1ReadFlash);
#else
    LWORD u32TlcMode;
    BLKSPRINFO upBlkSprInfo;
    WORD u16BlkTemp;

    u16BlkTemp=rmVndrFBlock;
    // save as cell mode
    u32TlcMode=mChkMlcMoBit(rmVndrFBlock);
    gpFlashAddrInfo=&gpVendorAddrInfo;
    gOpTyp=cVenderRead;

    mGetReadOpt=c16Bit4;

    setVendorRwInfo();
    mGetReadBuf=c16Tsb0SIdx;

    if(mGetReadOpt&c16Bit5)
    {
        mGetReadSctrCnt=g32HostXfrCnt-1;
    }
    else
    {
        mGetReadSctrCnt=g32HostXfrCnt;
    }

    // mGetReadSctrCnt=gSectorPerPlaneH;
    fillCcmVal((BYTE *)&garTsb0[g32HostXfrCnt-1][0], 0x100, cZero);

    // flashReadPage();
    insertVendorTask(cVendorCore1ReadFlash);

#if _GREYBOX
    if((gsGbInfo.uGreyBoxItem==cRAIDDecOnNormData))
    {
#if _EN_RAID_DECODE
        while(g32DecodeWait)
            ;
#endif
    }
#endif

    /* Save as spare byte*/
    if(mGetReadOpt&c16Bit5)
    {
        getSprByte(&upBlkSprInfo, gPlaneAddr);
        copyReg2Tsb((BYTE *)&garTsb0[g32HostXfrCnt-1][0], (volatile BYTE *)&upBlkSprInfo, sizeof(BLKSPRINFO));
        /* check status*/
        // Note: Here still need to add a valid "gPlaneUNCSts" and "gPlaneCorrSts".
        garTsb0[g32HostXfrCnt-1][0x19]=gbOnesCntFail;
        garTsb0[g32HostXfrCnt-1][0x20]=gPlaneUNCSts[gActiveCh];
        garTsb0[g32HostXfrCnt-1][0x21]=gPlaneCorrSts[gActiveCh];
    }

    if(gSecurityOption&cEnE2e)
    {
        for(BYTE uCnt=0; uCnt<gSectorPerPlaneH; uCnt++)
        {
            garTsb0[g32HostXfrCnt-1][0x30+(uCnt*2)]=(*(BYTE *)(c32TsbCrcAddr+(mGetReadBuf*8)+(uCnt*8)));
            garTsb0[g32HostXfrCnt-1][0x31+(uCnt*2)]=(*(BYTE *)(c32TsbCrcAddr+(mGetReadBuf*8)+(uCnt*8)+1));
        }
    }

    if(u32TlcMode)
    {
        mSetMlcMoBit(u16BlkTemp);
    }
    else
    {
        mClrMlcMoBit(u16BlkTemp);
    }
    ctrlScrbBothAndEcc(1, 1);
#endif/* if 1 */
    return cSuccess;
}    /* dataInVendorCmdReadPhysicalPage */

BYTE dataInVuCmdLba2Pba()
{
    HADDRINFO usReadHAddrInfo;

    tranLba2HAddr(rmNvmeSubCmdParam1, &usReadHAddrInfo);
    gsCacheInfo.u16SrchRslFBlock=c16FBlockInitValue;
    gsCacheInfo.u32SrchRslFPage=c32BitFF;
    gsCacheInfo.u16TotalPgPerF2hTab=g16TotalPgPerF2hTab;
    rstH2F1KInfo();

    if(srchSrcInF2hTab(usReadHAddrInfo.u16HBlock, usReadHAddrInfo.u16HPage)==c16BitFF)
    {
        findReadSrc(usReadHAddrInfo.u16HBlock, usReadHAddrInfo.u16HPage, 0);
    }

    if(gsCacheInfo.u16SrchRslFBlock<g16TotalFBlock)
    {
        g16FBlock=gsCacheInfo.u16SrchRslFBlock;
        g32FPageNoTran=gsCacheInfo.u32SrchRslFPage;
        // g16FPage=mTran4kAddr(g32FPageNoTran);
        tranAddrInfo(gpFlashAddrInfo);
        // tranCeNum(gpFlashAddrInfo);

        // g32arTsb0[0x00][0x00]=((gIntlvAddr>>gDieBitCnt)*gTotalDiePerCe*gTotalChNum)+(gDieAddr*gTotalChNum)+gCh;
        // g32arTsb0[0x00][0x01]=(g16FBlock*gPlaneNum)+gPlaneAddr;
        // g32arTsb0[0x00][0x02]=g16FPage;
        // g32arTsb0[0x00][0x03]=g32FPageNoTran%g4kNumPerPlane;
        g32arTsb0[0x00][0x00]=g16FBlock;

        if(!mChkMlcMoBit(g16FBlock))
        {
            g32arTsb0[0x00][0x01]=g16FPage;
        }
        else
        {
            g32arTsb0[0x00][0x01]=(g16FPage*cProgCntPerWL)+mGetPageSelCmd(gpFlashAddrInfo);    // gPageSelCmd;
        }

        g32arTsb0[0x00][0x02]=g32FPageNoTran%g4kNumPerPlane;
        g32arTsb0[0x00][0x03]=gSectorH;    // gOrgSectorH;
        g32arTsb0[0x00][0x04]=gPlaneAddr;
        g32arTsb0[0x00][0x05]=gCh;
        g32arTsb0[0x00][0x06]=gCe;
        g32arTsb0[0x00][0x07]=gDieAddr;
        g32arTsb0[0x00][0x08]=gIntlvAddr;
        g32arTsb0[0x00][0x09]=g32arCacheBlkVpCnt[g16FBlock];
        // copyCcmVal((BYTE *)&g32arTsb0[0x01][0x00], (BYTE *)&g32arCacheBlkVpCnt[0], g16TotalFBlock*4);
    }
    else
    {
        g32arTsb0[0x00][0x00]=0xFFFFFFFF;
        g32arTsb0[0x00][0x01]=0xFFFFFFFF;
        g32arTsb0[0x00][0x02]=0xFFFFFFFF;
        g32arTsb0[0x00][0x03]=0xFFFFFFFF;
        g32arTsb0[0x00][0x04]=0xFFFFFFFF;
        g32arTsb0[0x00][0x05]=0xFFFFFFFF;
        g32arTsb0[0x00][0x06]=0xFFFFFFFF;
        g32arTsb0[0x00][0x07]=0xFFFFFFFF;
        g32arTsb0[0x00][0x08]=0xFFFFFFFF;
        g32arTsb0[0x00][0x09]=0xFFFFFFFF;
    }

    return cSuccess;
}    /* dataInVuCmdLba2Pba */

BYTE dataInVuCmdReadHmbInfo()
{
    LWORD u32Loop;
    WORD u16HblkLoop;

    bopClrRam(cTsb0Addr, 0x10000, 0x00000000, cBopWait|cClrTsb);
    readWproPageCore0(cWproFeaturePg, cNvmeFeatSIdx, 0);

    garTsb0[0x40][0x00]=gsHmbInfo.uHmbEnable;

#if _EN_DisHMBInReset    // 20190805_Chief_DisHMB
    if(gsHmbInfo.uHmbEnable||(gChkFlag&cEnableFakeHMB))    // &&(upPrdInfo->uE2eRetry&cBit7))
#else
    if(gsHmbInfo.uHmbEnable)
#endif
    {
        *(WORD *)(&garTsb0[0x40][0x01])=cMaxRH2fTabNum;
        *(WORD *)(&garTsb0[0x40][0x03])=g16HmbMaxTableNum;
        garTsb0[0x40][0x05]=cHmbStAddrNum;
        *(LWORD *)(&garTsb0[0x40][0x06])=gpNvmeFeatVar->usHmbHwInfo.u32HmbDescListEntryCnt;
        garTsb0[0x40][0x0A]=cMax4kNum;

        g32arTsb0[0x40][0x04]=gpNvmeFeatVar->usHmbHwInfo.u32HmbSize;
        g32arTsb0[0x40][0x05]=gpNvmeFeatVar->usHmbHwInfo.u32HmbDescListAddrLow;
        g32arTsb0[0x40][0x06]=gpNvmeFeatVar->usHmbHwInfo.u32HmbDescListAddrHigh;

        for(u32Loop=0; u32Loop<=gpNvmeFeatVar->usHmbHwInfo.u32HmbDescListEntryCnt; u32Loop++)
        {
            g32arTsb0[0x4A][(u32Loop*sizeof(LWORD))]=gpNvmeFeatVar->usHmbHwInfo.u32arDescEntryAddrLow[u32Loop];
            g32arTsb0[0x4A][1+(u32Loop*sizeof(LWORD))]=gpNvmeFeatVar->usHmbHwInfo.u32arDescEntryAddrHigh[u32Loop];
            g32arTsb0[0x4A][2+(u32Loop*sizeof(LWORD))]=gpNvmeFeatVar->usHmbHwInfo.u32arDescEntrySize[u32Loop];
        }

        garTsb0[0x40][0x1E0]=gsHmbInfo.uHmbValid;
        garTsb0[0x40][0x1E1]=gsHmbInfo.uHmbSwichChkTimer;
        garTsb0[0x40][0x1E2]=0;    // gsHmbInfo.uHmbEnWrCache;
        garTsb0[0x40][0x1E3]=0;    // gsHmbInfo.uHmbEnRdCache;
        garTsb0[0x40][0x1E4]=gsHmbInfo.uHmbEnGcCache;
        garTsb0[0x40][0x1E5]=0;    // gsHmbInfo.uHmbEnGcInfoCache;
        garTsb0[0x40][0x1E6]=gsHmbInfo.uHmbEnPtCache;

        *(WORD *)(&garTsb0[0x40][0x1F0])=0;    // gsHmbInfo.u16HmbCacheBufPtr;
        *(WORD *)(&garTsb0[0x40][0x1F2])=gsHmbInfo.u16FreeHmbHead;
        *(WORD *)(&garTsb0[0x40][0x1F4])=gsHmbInfo.u16FreeHmbTail;
        garTsb0[0x40][0x1F6]=gsHmbInfo.uHmbSgmtRdyHead;
        garTsb0[0x40][0x1F7]=gsHmbInfo.uHmbSgmtRdyTail;
        garTsb0[0x40][0x1F8]=gsHmbInfo.uHmbSgmtRdyCnt;
        garTsb0[0x40][0x1F9]=gsHmbInfo.uHmbHwPrdHead;
        garTsb0[0x40][0x1FA]=gsHmbInfo.uHmbHwPrdTail;
        garTsb0[0x40][0x1FB]=gsHmbInfo.uHmbFreeHwPrdCnt;
        garTsb0[0x40][0x1FC]=0;    // gsHmbInfo.uHmbCache4kCnt;

        // LINKNODE16 uarHmbLink[c16HmbMaxTableNum];
        for(u32Loop=0; u32Loop<g16HmbMaxTableNum; u32Loop++)
        {
            copyCcmVal((BYTE *)(&garTsb0[0x40][0x200]+(u32Loop*sizeof(LINKNODE16))), (BYTE *)&gsHmbInfo.uarHmbLink[u32Loop],
                       sizeof(LINKNODE16));
        }

        // WORD u16arFreeHmbQ[c16HmbMaxTableNum];
        for(u32Loop=0; u32Loop<g16HmbMaxTableNum; u32Loop++)
        {
            copyCcmVal((BYTE *)(&garTsb0[0x45][0x00]+(u32Loop*sizeof(WORD))), (BYTE *)&gsHmbInfo.u16arFreeHmbQ[u32Loop], sizeof(WORD));
        }

        // LWORD u32HmbStAddr[cHmbStAddrNum];
        for(u32Loop=0; u32Loop<cHmbStAddrNum; u32Loop++)
        {
            copyCcmVal((BYTE *)(&garTsb0[0x47][0x00]+(u32Loop*sizeof(LWORD))), (BYTE *)&gsHmbInfo.u32HmbStAddr[u32Loop], sizeof(LWORD));
        }

        // HMBPRDQ uarHmbPrdQ[cMaxRH2fTabNum];
        for(u32Loop=0; u32Loop<cMaxRH2fTabNum; u32Loop++)
        {
            copyCcmVal((BYTE *)(&garTsb0[0x47][0x30]+(u32Loop*sizeof(HMBPRDQ))), (BYTE *)&gsHmbInfo.uarHmbPrdQ[u32Loop], sizeof(HMBPRDQ));
        }

        /*
           * // BYTE uarHmbSgmtRdyQ[cMaxRH2fTabNum];
           * for(u32Loop=0; u32Loop<cMaxRH2fTabNum; u32Loop++)
           * {
           *  copyCcmVal((BYTE *)(&garTsb0[0x48][0x140]+u32Loop), (BYTE *)&gsHmbInfo.uarHmbSgmtRdyQ[u32Loop], sizeof(BYTE));
           * }
           *
           * // LWORD u32HmbCacheHp[cMax4kNum];
           * for(u32Loop=0; u32Loop<cMax4kNum; u32Loop++)
           * {
           *  copyCcmVal((BYTE *)(&garTsb0[0x48][0x170]+(u32Loop*sizeof(LWORD))), (BYTE *)&gsHmbInfo.u32HmbCacheHp[u32Loop], sizeof(LWORD));
           * }
           *
           * // WORD u16HmbCacheHb[cMax4kNum];
           * for(u32Loop=0; u32Loop<cMax4kNum; u32Loop++)
           * {
           *  copyCcmVal((BYTE *)(&garTsb0[0x48][0x190]+(u32Loop*sizeof(WORD))), (BYTE *)&gsHmbInfo.u16HmbCacheHb[u32Loop], sizeof(WORD));
           * }
           */

        //  LINKINFO usHmbList;
        copyCcmVal((BYTE *)(&garTsb0[0x48][0x1A0]), (BYTE *)&gsHmbInfo.usHmbList, sizeof(LINKINFO));

        // Whitch H2F on HMB
        for(u16HblkLoop=0, u32Loop=0; u16HblkLoop<g16TotalHBlock; u16HblkLoop++)
        {
            if(mChkHmbLink(u16HblkLoop))
            {
                *(WORD *)(&garTsb0[0x48][0x1B0]+(u32Loop*sizeof(WORD)))=u16HblkLoop;
                u32Loop++;
            }
        }

        copyCcmVal((BYTE *)&(garTsb0[0x00][0x00]), (BYTE *)&(garTsb0[0x40][0x00]), 0x4000);
    }
    else
    {
        fillCcmVal((BYTE *)&garTsb0[0][0], 0x10000, cInvalid8Bit);
    }

    return cSuccess;
}    /* dataInVuCmdReadHmbInfo */

BYTE dataInVuCmdReadCR()
{
    WORD u16DphyAddr, u16PCIeLaneAddr, u16CrAddr;

    bopClrRam(cTsb0Addr, 0x100, 0x00000000, cBopWait|cClrTsb);
    u16PCIeLaneAddr=rmNvmeSubCmdParam1;
    crWrite(((cAddrDphyLane0|(u16PCIeLaneAddr<<8))|cAddrDphyParityBit), cDatSetDphyParityBit);

    for(u16DphyAddr=0x00; u16DphyAddr<cBitFF; u16DphyAddr++)
    {
        u16CrAddr=(cAddrDphyLane0|(u16PCIeLaneAddr<<8))|u16DphyAddr;
        g16arTsb0[0x00][u16DphyAddr]=crRead(u16CrAddr);
    }

    crWrite(((cAddrDphyLane0|(u16PCIeLaneAddr<<8))|cAddrDphyParityBit), cDatClrDphyParityBit);
    return cSuccess;
}    /* dataInVuCmdReadCR */

BYTE dataInVuCmdReadMpInfo()
{
    // WORD u16IspPage;
    BYTE uStatus;

    // bopCopyRam((LWORD)c32Tsb0SAddr, (LWORD)&gsLightSwitch, sizeof(gsLightSwitch), cCopyDccm2Tsb|cBopWait); //read lightswitch from DCCM
    // u16IspPage=gISPBlockStartPage+(((cLightswitchBank+1)*cSwapCodeSize)/gSectorPerPlaneH);                 //read lightswitch from MPINFO
    // if(!loadInfoPage(u16IspPage, gSectorPerPlaneH, c16WriteSIdx, 0, cSysBlock1stInfo, cBit1))
    // {
    //    uStatus=cStatusSuccess;
    // }
    // else
    // {
    //    uStatus=cStatusDeviceErr;
    // }

    if(!loadInfoPage(0, gSectorPerPlaneH, c16WriteSIdx, 0, cSysBlockMPInfo, cBit1))
    {
        uStatus=cSuccess;
    }
    else
    {
        uStatus=cFail;
    }

    return uStatus;
}    /* dataInVuCmdReadMpInfo */

BYTE dataInVuCmdReadPcieCfg()
{
    copyCcmVal((BYTE *)(&g32arTsb0[0]), (BYTE *)(&rPcie[0]), 0x144);
    return cSuccess;
}

#if 0
BYTE dataInVuCmdSetFeature()
{
    // setFeature
    insertVendorTask(cVendorCore1SetFeature);

    return cSuccess;
}

BYTE dataInVendorCmdReadInfoPg()
{
    // readInfoPg
    BYTE uStatus;

    insertVendorTask(cVendorCore1ReadInfoPg);

    if(!loadInfoPage((rmNvmeSubCmdParam1&0xF), gSectorPerPlaneH, c16WriteSIdx, 0, (rmNvmeSubCmdParam2&0xF), cBit1))
    {
        uStatus=cSuccess;
    }
    else if(!loadInfoPage((rmNvmeSubCmdParam1&0xF), gSectorPerPlaneH, c16WriteSIdx, 0, (rmNvmeSubCmdParam3&0xF), cBit1))
    {
        uStatus=cSuccess;
    }
    else
    {
        uStatus=cFail;
    }

    return cSuccess;
}    /* dataInVendorCmdReadInfoPg */

#endif/* if 0 */
BYTE dataInVendorCmddoVtDistribution()
{
    // doVtDistribution

    insertVendorTask(cVendorCore1doVtDistribution);

    return cSuccess;
}

BYTE dataInVendorCmdReadEfuseReg()
{
    // g32arTsb0[0][0x00]=((r32EfuseCtrl[0x40+0x3C]&0x3FFFFFF)<<9)|(r32EfuseCtrl[0x40+0x3D]>>23);    // Controller Lot Number
    // g32arTsb0[0][0x01]=(r32EfuseCtrl[0x40+0x3C]>>11)&0x1F;    // Controller Wafer Number
    // g32arTsb0[0][0x02]=r32EfuseCtrl[0x40+0x3C]>>26;    // rEfuseCtrl[0xF0]>>2;//Controller Die X Position
    // g32arTsb0[0][0x03]=(r32EfuseCtrl[0x40+0x3B]&0xEF)>>1;    // rEfuseCtrl[0xEC+3]>>1;//Controller Die Y Position

    // 20180927, Akira.Wang correct value. verified by OP tool.
    g32arTsb0[0][0x00]=((r32EfuseCtrl[0x40+0x3D]&0x01FF)<<21)|((r32EfuseCtrl[0x40+0x3C]&0xFFFFF800)>>11);
    g32arTsb0[0][0x01]=(r32EfuseCtrl[0x40+0x3C]>>6)&0x1F;
    g32arTsb0[0][0x02]=r32EfuseCtrl[0x40+0x3C]&0x3F;
    g32arTsb0[0][0x03]=(r32EfuseCtrl[0x40+0x3B]>>24)&0x7F;
    return cSuccess;
}

BYTE dataInVendorCmdWdPhyErase()
{
    insertVendorTask(cVendorCore1WdPhyErase);
    return cSuccess;
}

BYTE dataInVendorCmdWdPhyRead()
{
    insertVendorTask(cVendorCore1WdPhyRead);
    return cSuccess;
}

BYTE dataInVendorCmdWdCheckSts()
{
    insertVendorTask(cVendorCore1WdCheckSts);
    return cSuccess;
}

#if _GREYBOX
BYTE dataInVendorCmdGreyBoxPre()
{
    outCS(cbTagdataInVendorCmdGreyBoxPre);
    copyCcmVal((BYTE *)&gsGbInfo, (BYTE *)&garTsb0[0][0], sizeof(gsGbInfo));
    copyCcmVal((BYTE *)(gsGbInfo.upParaTab), (BYTE *)garParaPageId, cParaSize);
    gsGbInfo.uGreyBoxItem=rmNvmeSubCmdParam1;
    gsGbInfo.uGreyBoxOpt=rmNvmeSubCmdParam2;

    if((gsGbInfo.uGreyBoxItem==cTabHdlH2fOnHmb)||(gsGbInfo.uGreyBoxItem==cRAIDEncOnH2fTab))
    {
        WORD u16HblkLoop;

        if(gsHmbInfo.uHmbEnable)
        {
            gsGbInfo.uResult=cSuccess;
            fillCcmVal((BYTE *)c32GreyBoxBuf, cGreyBoxBufSize, cZero);

            for(u16HblkLoop=0; u16HblkLoop<g16TotalHBlock; u16HblkLoop++)
            {
                if(mChkHmbLink(u16HblkLoop))
                {
                    *(BYTE *)(c32GreyBoxBuf+u16HblkLoop)=cTrue;
                }
            }
        }
        else
        {
            gsGbInfo.uResult=cFail;
        }

        outInfo(cGbHmbInfo);
    }
    else if((gsGbInfo.uGreyBoxItem==cTabHdlGcH2f)||(gsGbInfo.uGreyBoxItem==cUGSDGcH2fTableID))
    {
        gsGbInfo.uResult=cSuccess;
        fillCcmVal((BYTE *)c32GreyBoxBuf, cGreyBoxBufSize, cZero);
        *(WORD *)(c32Tsb0SAddr+cGbInfoActH2fBlk)=g16arH2fTabBlk[gsCacheInfo.uActH2fTabBlkIdx];
        *(WORD *)(c32Tsb0SAddr+cGbInfoH2fTabFreePagePtr)=gsCacheInfo.u16H2fTabFreePagePtr;
        *(WORD *)(c32Tsb0SAddr+cGbInfoH2fTabPagePerBlk3)=gsCacheInfo.u16H2fTabPagePerBlk3;
        *(WORD *)(c32Tsb0SAddr+cGbInfoH2fTabBlockCnt)=gsCacheInfo.uH2fTabBlockCnt;
        *(WORD *)(c32Tsb0SAddr+cGbInfoGcH2fTabbHiThr)=gsGcInfo.uGcH2fTabbHiThr;
        outInfo(cGbH2fInfo);

        if(gsGbInfo.u32BkValue==0)
        {
            gsGbInfo.u32BkValue=(gsGcInfo.uGcH2fTabbHiThr<<8)+(gsGcInfo.uGcH2fTabbLoThr);
            gsGcInfo.uGcH2fTabbHiThr+=2;
            gsGcInfo.uGcH2fTabbLoThr+=2;
        }
    }
    else if(gsGbInfo.uGreyBoxItem==cUGSDProgIndxBlkID)
    {
        gsGbInfo.uStag=cVsIdl;

        if(gsGbInfo.uGreyBoxOpt==cVOpErasing)
        {
            // Dummy program
            while(g16IdxBlkFreePagePtr<(g16PagePerBlock1_SLC))
            {
                saveIndexBlockCore0();
            }

            mSetCacheInfoFlag(cIndexBlockFull);    // gsCacheInfo.ubIndexBlockFull=1;
        }
    }
    else if(gsGbInfo.uGreyBoxItem==cUGSDProgWPROID)
    {
        gsGbInfo.uStag=cVsIdl;

        if(gsGbInfo.uGreyBoxOpt==cVOpErasing)
        {
            // Dummy program
            // while(gsWproInfo.u16WproFreePagePtr<((g16PagePerBlock1_SLC)*(gIntlvWay*gPlaneNum*cWriteChNum)))
            while(gsWproInfo.u16WproFreePagePtr<(gsWproInfo.u16PagePerBlock3-3))
            {
                progWproPageCore0(cMaxWproPageType, c16Tsb0SIdx);
            }
        }
    }
    else if((gsGbInfo.uGreyBoxItem==cUGSDHmbID)||
            (((gsGbInfo.uGreyBoxItem==cUGSDS2TID)||(gsGbInfo.uGreyBoxItem==cUGSDT2TID)||(gsGbInfo.uGreyBoxItem==cUGSDS2SID))&&
             (gsGbInfo.uGreyBoxOpt==cVOpProgH2fonHmb)))
    {
        if(gsHmbInfo.uHmbEnable)
        {
            gsGbInfo.uResult=cSuccess;
            WORD u16HblkLoop;

            for(u16HblkLoop=0; u16HblkLoop<g16TotalHBlock; u16HblkLoop++)
            {
                if(mChkHmbLink(u16HblkLoop))
                {
                    *(BYTE *)(c32GreyBoxBuf+u16HblkLoop)=cTrue;
                    // outString("H=@", u16HblkLoop);
                }
            }
        }
        else
        {
            gsGbInfo.uResult=cFail;
        }
    }
    else if(gsGbInfo.uGreyBoxItem==cUGSDReclaimID)
    {
        fillCcmVal((BYTE *)c32GreyBoxBuf, cGreyBoxBufSize, cZero);
    }
    else if(gsGbInfo.uGreyBoxItem==cGCS2TThree2OneFull)
    {
        g16GbGcCachebActThr=gsGcInfo.u16GcCachebActThr;
        gsGcInfo.u16GcCachebActThr=gsCacheInfo.u16SLCSpareCnt-7;
        g16GbGcDesTLCBlock=0;

        for(WORD u16Idx=0; u16Idx<cMaxGcSrcBlkNum; u16Idx++)
        {
            g16GbGcSrcBlock[u16Idx]=cInvldFBlk;
        }

        gsGbInfo.uResult=cFail;
        // outInfo(cGbGcInfo);
    }
    else if((gsGbInfo.uGreyBoxItem==cGCS2TSixteen2OneFull)||(gsGbInfo.uGreyBoxItem==cGCS2TSixteen2OneNotFull))
    {
        g16GbGcCachebActThr=gsGcInfo.u16GcCachebActThr;
        gsGcInfo.u16GcCachebActThr=gsCacheInfo.u16SLCSpareCnt-35;
        g16GbGcDesTLCBlock=0;

        for(WORD u16Idx=0; u16Idx<cMaxGcSrcBlkNum; u16Idx++)
        {
            g16GbGcSrcBlock[u16Idx]=cInvldFBlk;
        }

        gsGbInfo.uResult=cFail;
        // outInfo(cGbGcInfo);
    }
    else if((gsGbInfo.uGreyBoxItem==cGCT2TX2OneNotFull))
    {
        g16GbGcCachebActThr=gsGcInfo.u16GcCachebActThr;
        g16GbTlcFullCachebGcThr=g16TlcFullCachebGcThr;
        gsGcInfo.u16GcCachebActThr=gsCacheInfo.u16SLCSpareCnt-7;
        g16TlcFullCachebGcThr=8;
        g16GbGcDesTLCBlock=0;

        for(WORD u16Idx=0; u16Idx<cMaxGcSrcBlkNum; u16Idx++)
        {
            g16GbGcSrcBlock[u16Idx]=cInvldFBlk;
        }

        gsGbInfo.uResult=cFail;
        // outInfo(cGbGcInfo);
    }
    else if((gsGbInfo.uGreyBoxItem==cGCT2TX2OneFull))
    {
        g16GbGcCachebActThr=gsGcInfo.u16GcCachebActThr;
        g16GbTlcFullCachebGcThr=g16TlcFullCachebGcThr;
        gsGcInfo.u16GcCachebActThr=gsCacheInfo.u16SLCSpareCnt-13;
        g16TlcFullCachebGcThr=5;
        g16GbGcDesTLCBlock=0;

        for(WORD u16Idx=0; u16Idx<cMaxGcSrcBlkNum; u16Idx++)
        {
            g16GbGcSrcBlock[u16Idx]=cInvldFBlk;
        }

        gsGbInfo.uResult=cFail;
        // outInfo(cGbGcInfo);
    }
    else if((gsGbInfo.uGreyBoxItem==cGCT2TSixteen2OneMoreFull))
    {
        g16GbGcCachebActThr=gsGcInfo.u16GcCachebActThr;
        g16GbTlcFullCachebGcThr=g16TlcFullCachebGcThr;
        gsGcInfo.u16GcCachebActThr=gsCacheInfo.u16SLCSpareCnt+3;
        g16TlcFullCachebGcThr=15;
        g16GbGcDesTLCBlock=0;

        for(WORD u16Idx=0; u16Idx<cMaxGcSrcBlkNum; u16Idx++)
        {
            g16GbGcSrcBlock[u16Idx]=cInvldFBlk;
        }

        gsGbInfo.uResult=cFail;
        // outInfo(cGbGcInfo);
    }
    else if(gsGbInfo.uGreyBoxItem==cGCPartialS2Tfour2OneFull)
    {
        g16GbGcCachebActThr=gsGcInfo.u16GcCachebActThr;
        gsGcInfo.u16GcCachebActThr=gsCacheInfo.u16SLCSpareCnt-7;
        g16GbGcDesTLCBlock=0;

        for(WORD u16Idx=0; u16Idx<cMaxGcSrcBlkNum; u16Idx++)
        {
            g16GbGcSrcBlock[u16Idx]=cInvldFBlk;
        }

        gsGbInfo.uResult=cFail;
        // outInfo(cGbGcInfo);
    }
    else if(gsGbInfo.uGreyBoxItem==cGCS2SThirtytwo2OneNotFull)
    {
        g16GbGcCachebActThr=gsGcInfo.u16GcCachebActThr;
        gsGcInfo.u16GcCachebActThr=gsCacheInfo.u16SLCSpareCnt-36;
        gsGcInfo.u32GcCachebTime=c32BitFF;
        g16GbGcDesTLCBlock=0;

        for(WORD u16Idx=0; u16Idx<cMaxGcSrcBlkNum; u16Idx++)
        {
            g16GbGcSrcBlock[u16Idx]=cInvldFBlk;
        }

        gsGbInfo.uResult=cFail;
        // outInfo(cGbGcInfo);
    }
    else if(gsGbInfo.uGreyBoxItem==cUGSDSwapWproID)
    {
        // Dummy program
        while(gsWproInfo.u16WproFreePagePtr<(gsWproInfo.u16PagePerBlock3))
        {
            progWproPageCore0(cMaxWproPageType, c16Tsb0SIdx);
            waitAllChCeBzCore0();
        }
    }
    else if(gsGbInfo.uGreyBoxItem==cReadRetryDecodeTestID)
    {
        gReadErrinjectEn=cFalse;
    }
    else if(gsGbInfo.uGreyBoxItem==cErrHdlReadUncInSlcDataID)
    {
        gReadErrinjectEn=cFalse;
    }
    else if(gsGbInfo.uGreyBoxItem==cErrHdlReadUncInTlcDataID)
    {
        gReadErrinjectEn=cFalse;
        g16GbGcCachebActThr=gsGcInfo.u16GcCachebActThr;
        gsGcInfo.u16GcCachebActThr=gsCacheInfo.u16SLCSpareCnt-gsGbInfo.uGreyBoxOpt;
        g16GbGcDesTLCBlock=0;

        g16GbTlcFullCachebGcThr=g16TlcFullCachebGcThr;
    }
    else if(gsGbInfo.uGreyBoxItem==cErrHdlGcFingerFailTestID)
    {
        gReadErrinjectEn=cFalse;
        g32GbFingerFailBlk=c32BitFF;
        gsGbInfo.uStag=cVsIdl;
    }
    else if(gsGbInfo.uGreyBoxItem==cFtlRuleReadReclaimID)
    {
        g16GbGcCachebActThr=gsGcInfo.u16GcCachebActThr;
        gsGcInfo.u16GcCachebActThr=gsCacheInfo.u16SLCSpareCnt-gsGbInfo.uGreyBoxOpt;
        g16GbGcDesTLCBlock=0;

        g16GbGetReclaimBlk=c16BitFF;
        g16GbSetReclaimBlk=c16BitFF;
    }
    else if((gsGbInfo.uGreyBoxItem==cRAIDDecOnH2fTab))
    {
        WORD u16HblkLoop;

        if(gsHmbInfo.uHmbEnable)
        {
            gsGbInfo.uResult=cSuccess;
            fillCcmVal((BYTE *)c32GreyBoxBuf, cGreyBoxBufSize, cZero);

            for(u16HblkLoop=0; u16HblkLoop<g16TotalHBlock; u16HblkLoop++)
            {
                if(mChkHmbLink(u16HblkLoop))
                {
                    *(BYTE *)(c32GreyBoxBuf+u16HblkLoop)=cTrue;
                }
            }
        }
        else
        {
            gsGbInfo.uResult=cFail;
        }

        outInfo(cGbHmbInfo);

        gReadErrinjectEn=cFalse;
    }
    else if((gsGbInfo.uGreyBoxItem==cRAIDDecOnH2f1kTab))
    {
        g16GbFBlock=0;    // Recode H2f Tsb Bufferptr
        gReadErrinjectEn=cFalse;
    }
    else if(gsGbInfo.uGreyBoxItem==cErrHdlE2EHostData)
    {
        *(LWORD *)(c32GreyBoxBuf+cGbInfoeE2eCmdRetryCnt)=g32PrdCommandRetryCnt;
    }
    else if(gsGbInfo.uGreyBoxItem==cRAIDEncOnGc)
    {
        gGbDieAddr=0;
        gGbCe=0;
        gGbIntlvAddr=0;
        gGbCh=0;
        gGbPlaneAddr=0;
        g16GbFBlock=0;
        g16GbFPage=0;
        gsGbInfo.uStag=cVsIdl;
        gReadErrinjectEn=cFalse;
        g16GbGcCachebActThr=gsGcInfo.u16GcCachebActThr;
        g32GbGcCachebTime=gsGcInfo.u32GcCachebTime;

        if(!g32GbGcCachebTime)
        {
            g32GbGcCachebTime=gsGcInfo.u32GcLeastBudget;
        }

        gsGcInfo.u16GcCachebActThr=gsCacheInfo.u16SLCSpareCnt-2;
        gsGcInfo.u32GcCachebTime=c32BitFF;
        g16GbGcDesTLCBlock=0;
        gsGbInfo.uResult=cFail;
        // outInfo(cGbGcInfo);
    }
    else if((gsGbInfo.uGreyBoxItem==cRAIDEncOnData)||(gsGbInfo.uGreyBoxItem==cRAIDDecOnNormData)||(gsGbInfo.uGreyBoxItem==cRAIDDecOnOpenData)||
            (gsGbInfo.uGreyBoxItem==cRAIDDecOnPreReadData)||(gsGbInfo.uGreyBoxItem==cRAIDDecOnLastReadData)||
            ((gsGbInfo.uGreyBoxItem==cSecurityRW)&&(gsGbInfo.uGreyBoxOpt==cVOpSecurityRAID)))
    {
        gGbDieAddr=0;
        gGbCe=0;
        gGbIntlvAddr=0;
        gGbCh=0;
        gGbPlaneAddr=0;
        g16GbFBlock=0;
        g16GbFPage=0;
        g16GbRaidDecTotalCnt=0;
        gReadErrinjectEn=cFalse;

        if((gsGbInfo.uGreyBoxItem==cRAIDDecOnOpenData))
        {
            *(LWORD *)(c32Tsb0SAddr+cGbInfoFBlock)=gsCacheInfo.u32CacheFreePagePtr;
        }

        if((gsGbInfo.uGreyBoxItem==cRAIDDecOnPreReadData)||(gsGbInfo.uGreyBoxItem==cRAIDDecOnLastReadData))
        {
            g16GbGcCachebActThr=0;
        }
    }
    else if(gsGbInfo.uGreyBoxItem==cRAIDDecOnMoveReadData)
    {
        g16GbRaidDecTotalCnt=0;
        gsGbInfo.uStag=cVsIdl;
        gReadErrinjectEn=cFalse;
        g16GbGcCachebActThr=gsGcInfo.u16GcCachebActThr;
        g32GbGcCachebTime=gsGcInfo.u32GcCachebTime;

        if(!g32GbGcCachebTime)
        {
            g32GbGcCachebTime=gsGcInfo.u32GcLeastBudget;
        }

        gsGcInfo.u16GcCachebActThr=gsCacheInfo.u16SLCSpareCnt-2;
        gsGcInfo.u32GcCachebTime=c32BitFF;
        g16GbGcDesTLCBlock=0;
        gsGbInfo.uResult=cFail;
    }
    else if(gsGbInfo.uGreyBoxItem==cErrHdlEraseFID)
    {
        gsGbInfo.uResult=cFail;
        g16GbFBlock=0;
    }
    else if(gsGbInfo.uGreyBoxItem==cWearleveingRule)
    {
#if _EN_VPC_SWAP
        bopClrRam((LWORD)g16GbGlobEraseCnt, c16MaxBlockNum*2, 0x00000000, cClrStcm|cBopWait);
#else
        bopClrRam((LWORD)g16GbGlobEraseCnt, c16MaxBlockNum*2, 0x00000000, cClrCore1Dccm|cBopWait);
#endif
        g16GbWLGcDesTLCBlock=0;
        g16GbWLGcSrcTLCBlock=0;
        gsGbInfo.uResult=cFail;
    }
    else if((gsGbInfo.uGreyBoxItem==cErrHdlProgCacheBlk)||(gsGbInfo.uGreyBoxItem==cErrHdlProgWPROID)||
            (gsGbInfo.uGreyBoxItem==cErrHdlProgH2fTableID)||(gsGbInfo.uGreyBoxItem==cErrHdlProgS2TGcDesID)||
            (gsGbInfo.uGreyBoxItem==cErrHdlProgT2TGcDesID)||(gsGbInfo.uGreyBoxItem==cErrHdlProgS2SGcDesID))
    {
        rmEnStsFailStop;
        g16GbSetPgFailFpage=c16BitFF;
        gGbSetPgFailCh=cBitFF;
        gGbSetPgFailIntlvAddr=cBitFF;
        gGbSetPgFailPlane=cBitFF;
        g16GbGetPgFailFblk=c16BitFF;
        g16GbGetPgFailFblkAfterDiffFblock=c16BitFF;
        g16GbGetPgFailFblkNowDiffFblk=c16BitFF;
        gGbSetPgFailCase=cBitFF;
        gsGbInfo.u32BkValue=c32BitFF;

        if(mChkFLOption(cEnCacheProg))
        {
            gGbEnCacheProg=1;
            mClrFLOption(cEnCacheProg);
        }
        else
        {
            gGbEnCacheProg=0;
        }
    }
    else if(gsGbInfo.uGreyBoxItem==cHmbErrHandle)
    {
        gsGbInfo.u32BkValue=mGetH2fTabPagePtr((WORD)rmNvmeSubCmdParam3);
    }
    else if((gsGbInfo.uGreyBoxItem==cUGSDonEraseFail)&&
            ((gsGbInfo.uGreyBoxOpt==cVOpPopWPROIDBfErase)||(gsGbInfo.uGreyBoxOpt==cVOpPopWPROIDAfErase)))
    {
        gsGbInfo.uStag=cVsIdl;

        // Dummy program
        while(gsWproInfo.u16WproFreePagePtr<(gsWproInfo.u16PagePerBlock3-3))
        {
            progWproPageCore0(cMaxWproPageType, c16Tsb0SIdx);
        }
    }
    else if(gsGbInfo.uGreyBoxItem==cUGSDonWearleveling)
    {
        g16GbWLGcDesTLCBlock=0;
        g16GbWLGcSrcTLCBlock=0;
        gsGbInfo.uResult=cFail;
    }
    else if((gsGbInfo.uGreyBoxItem==cSecurityRW)&&(gsGbInfo.uGreyBoxOpt==cVOpSecurityGC))
    {
        g16GbGcCachebActThr=gsGcInfo.u16GcCachebActThr;
        gsGcInfo.u16GcCachebActThr=gsCacheInfo.u16SLCSpareCnt-7;

        gsGbInfo.uResult=cFail;
    }

    copyCcmVal((BYTE *)&garTsb0[0][0], (BYTE *)&gsGbInfo, sizeof(gsGbInfo));
    garTsb0[0x07][0x1F9]='G';
    garTsb0[0x07][0x1FA]='B';
    garTsb0[0x07][0x1FB]=' ';
    garTsb0[0x07][0x1FC]=' ';
    garTsb0[0x07][0x1FD]='P';
    garTsb0[0x07][0x1FE]='R';
    garTsb0[0x07][0x1FF]='E';

    return cSuccess;
}    /* dataInVendorCmdGreyBoxPre */

BYTE dataInVendorCmdGreyBoxTrig()
{
    outCS(cbTagdataInVendorCmdGreyBoxTrig);
    gsGbInfo.uGreyBoxItem=rmNvmeSubCmdParam1;
    gsGbInfo.uGreyBoxOpt=rmNvmeSubCmdParam2;

    if(gsGbInfo.uGreyBoxItem==cErrHdlReadRetry)
    {
        if(gsGbInfo.uStag!=cVsTriggered)
        {
            outSta(cVTrig);

            if(gsGbInfo.uGreyBoxOpt==cVOpAwgnUnc)
            {
                makeAWGN(cAWGNUNC, 0    /*gsGbAddrInfo.uCh*/);
            }
            else if(gsGbInfo.uGreyBoxOpt==cVOpSoftRead)
            {
                setFLActCh(gsGbAddrInfo.uCh);
                rmCeOn(gsGbAddrInfo.uCe);
                BYTE uParamVul;
                gsIspAddrInfo.u16BufPtr=0;
                getNandParam(cRv1SlcTh, &uParamVul);
                gsIspAddrInfo.u16BufPtr=uParamVul;    // use for greybox save as value of flash param.
                setNandParam(cRv1SlcTh, uParamVul+10);

                getNandParam(cRv1TlcTh, &uParamVul);
                gsIspAddrInfo.u16BufPtr|=uParamVul<<8;    // use for greybox save as value of flash param.
                setNandParam(cRv1TlcTh, uParamVul+10);
                rmAllCeOff;
            }

            trigGreyBox(cFalse);
        }
    }
    else if((gsGbInfo.uGreyBoxItem==cTabHdlGcH2f)||(gsGbInfo.uGreyBoxItem==cUGSDGcH2fTableID))
    {
        *(WORD *)(c32Tsb0SAddr+cGbInfoActH2fBlk)=g16arH2fTabBlk[gsCacheInfo.uActH2fTabBlkIdx];
        *(WORD *)(c32Tsb0SAddr+cGbInfoH2fTabFreePagePtr)=gsCacheInfo.u16H2fTabFreePagePtr;
        *(WORD *)(c32Tsb0SAddr+cGbInfoH2fTabPagePerBlk3)=gsCacheInfo.u16H2fTabPagePerBlk3;
        *(WORD *)(c32Tsb0SAddr+cGbInfoH2fTabBlockCnt)=gsCacheInfo.uH2fTabBlockCnt;
        *(WORD *)(c32Tsb0SAddr+cGbInfoGcH2fTabbHiThr)=gsGcInfo.uGcH2fTabbHiThr;

        if(gsGcInfo.uGcH2fTabbLoThr>(((g16TotalHBlock*gTotalPlaneOfH2fTab)+(g16PagePerBlock3_SLC-1))/g16PagePerBlock3_SLC))
        {
            gsGcInfo.uGcH2fTabbLoThr=(((g16TotalHBlock*gTotalPlaneOfH2fTab)+(g16PagePerBlock3_SLC-1))/g16PagePerBlock3_SLC);
            gsGcInfo.uGcH2fTabbHiThr=(((g16TotalHBlock*gTotalPlaneOfH2fTab)+(g16PagePerBlock3_SLC-1))/g16PagePerBlock3_SLC)+1;
        }

        // outSta(cVTrig);
    }
    else if(gsGbInfo.uGreyBoxItem==cUGSDHmbID)
    {
        trigGreyBox(cFalse);
    }
    else if((gsGbInfo.uGreyBoxItem==cGreyboxPreConditionID)||(gsGbInfo.uGreyBoxItem==cUGSDS2TID)||(gsGbInfo.uGreyBoxItem==cUGSDReclaimID))
    {
        if(gsCacheInfo.u16FullCacheBlockCnt>3)
        {
            gsGbInfo.u32BkValue=gsGcInfo.u16GcCachebActThr;

            if(gsCacheInfo.u16SLCSpareCnt>gsGcInfo.u16GcCachebActThr)
            {
                gsGcInfo.u16GcCachebActThr=gsCacheInfo.u16SLCSpareCnt-2;
            }

            gsGbInfo.uResult=cSuccess;
        }
        else
        {
            gsGbInfo.uResult=cFail;
        }
    }
    else if(gsGbInfo.uGreyBoxItem==cReadRetryDecodeTestID)
    {
        gReadErrinjectEn=cFalse;
    }
    else if(gsGbInfo.uGreyBoxItem==cErrHdlReadUncInSlcDataID)
    {
        gReadErrinjectEn=cFalse;
        g16GbGcCachebActThr=gsGcInfo.u16GcCachebActThr;
        gsGcInfo.u16GcCachebActThr=gsCacheInfo.u16SLCSpareCnt-gsGbInfo.uGreyBoxOpt;
    }
    else if(gsGbInfo.uGreyBoxItem==cErrHdlReadUncInTlcDataID)
    {
        gReadErrinjectEn=cFalse;
        g16GbGcCachebActThr=gsGcInfo.u16GcCachebActThr;
        g16GbTlcFullCachebGcThr=g16TlcFullCachebGcThr;
        gsGcInfo.u16GcCachebActThr=gsCacheInfo.u16SLCSpareCnt-gsGbInfo.uGreyBoxOpt;
        g16TlcFullCachebGcThr=0;
    }
    else if(gsGbInfo.uGreyBoxItem==cFtlRuleReadReclaimID)
    {
        *(WORD *)(c32Tsb0SAddr+cGbGetInfoReclaimBlk)=g16GbGetReclaimBlk;
        *(WORD *)(c32Tsb0SAddr+cGbSetInfoReclaimBlk)=g16GbSetReclaimBlk;

        if(g16GbGetReclaimBlk==g16GbSetReclaimBlk)
        {
            gsGcInfo.u16GcCachebActThr=g16GbGcCachebActThr;
            g16GbGcCachebActThr=gsGcInfo.u16GcCachebActThr;
            gsGcInfo.u16GcCachebActThr=gsCacheInfo.u16SLCSpareCnt-gsGbInfo.uGreyBoxOpt;
            g16GbTlcFullCachebGcThr=g16TlcFullCachebGcThr;

            if(!mChkMlcMoBit(g16GbGetReclaimBlk))
            {
                while(1)
                    ;// Not Support Slc reclaim
            }
            else
            {
                g16TlcFullCachebGcThr=0;
            }
        }
    }
    else if((gsGbInfo.uGreyBoxItem==cRAIDDecOnNormData)||(gsGbInfo.uGreyBoxItem==cRAIDDecOnPreReadData)||
            ((gsGbInfo.uGreyBoxItem==cSecurityRW)&&(gsGbInfo.uGreyBoxOpt==cVOpSecurityRAID)))
    {
        gReadErrinjectEn=cFalse;
        *(WORD *)(c32Tsb0SAddr+cGbInfoFBlock)=g16GbFBlock;
        *(WORD *)(c32Tsb0SAddr+cGbInfoCh)=gGbCh;
        *(WORD *)(c32Tsb0SAddr+cGbInfoCe)=gGbCe;
        *(WORD *)(c32Tsb0SAddr+cGbInfoDie)=gGbDieAddr;
        *(WORD *)(c32Tsb0SAddr+cGbInfoIntlv)=gGbIntlvAddr;
        *(WORD *)(c32Tsb0SAddr+cGbInfoFPage)=g16GbFPage;
        *(WORD *)(c32Tsb0SAddr+cGbInfoPlane)=gGbPlaneAddr;
    }
    else if(gsGbInfo.uGreyBoxItem==cWearleveingRule)
    {
        g16WLCheckBlk=g16GbWLGcSrcTLCBlock-1;
        g16GbSlcMoSkipCnt=g16MinStaticTlcCnt;
        g16MinStaticTlcCnt=35;
        gsCacheInfo.u16DynamicAvgEraseCnt=(gsCacheInfo.u32DynamicTotalEraseCnt/g16MinStaticTlcCnt);
    }
    else if((gsGbInfo.uGreyBoxItem==cErrHdlProgCacheBlk)||(gsGbInfo.uGreyBoxItem==cErrHdlProgWPROID)||
            (gsGbInfo.uGreyBoxItem==cErrHdlProgH2fTableID)||(gsGbInfo.uGreyBoxItem==cErrHdlProgS2TGcDesID)||
            (gsGbInfo.uGreyBoxItem==cErrHdlProgT2TGcDesID)||(gsGbInfo.uGreyBoxItem==cErrHdlProgS2SGcDesID))
    {
        if(gsGbInfo.uGreyBoxOpt==cVopProgFailSetS2TGc)
        {
            g16GbGcCachebActThr=gsGcInfo.u16GcCachebActThr;
            gsGcInfo.u16GcCachebActThr=gsCacheInfo.u16SLCSpareCnt-1;
        }
        else if(gsGbInfo.uGreyBoxOpt==cVopProgFailGetGcStageIdle)
        {
            if(mGetGcFlow==cGcFlowIdl)
            {
                *(BYTE *)(c32Tsb0SAddr+cGbGetGcStageIdle)=cBitFF;
            }
            else
            {
                *(BYTE *)(c32Tsb0SAddr+cGbGetGcStageIdle)=cZero;
            }
        }
        else if(gsGbInfo.uGreyBoxOpt==cVopProgFailDiffBlkSta)
        {
            if(g16GbGetPgFailFblk!=c16BitFF)
            {
                g16GbGetPgFailFblkAfterDiffFblock=
                    getGreyBoxDifferFBlk(g16GbGetPgFailFblk, gGbSetPgFailCh, gGbSetPgFailIntlvAddr, gGbSetPgFailPlane);
            }

            *(WORD *)(c32Tsb0SAddr+cGbGetPgFailFblk)=g16GbGetPgFailFblk;
            *(WORD *)(c32Tsb0SAddr+cGbGetPgFailFblkAfterDiffFblock)=g16GbGetPgFailFblkAfterDiffFblock;
            *(WORD *)(c32Tsb0SAddr+cGbGetPgFailFblkNowDiffFblk)=g16GbGetPgFailFblkNowDiffFblk;
        }
        else if(gsGbInfo.uGreyBoxOpt==cVopProgFailResetS2TGc)
        {
            gsGcInfo.u16GcCachebActThr=g16GbGcCachebActThr;
        }
        else if(gsGbInfo.uGreyBoxOpt==cVopProgFailSetSta)
        {
            if((gsGbInfo.uGreyBoxItem==cErrHdlProgWPROID)&&(gGbSetPgFailCase==cWproBadInfo))
            {
                gReadErrinjectEn=cFalse;
                g16GbRetryTabLoop=0;
            }

            *(WORD *)(c32Tsb0SAddr+cGbSetPgFailFpage)=g16GbSetPgFailFpage;
            *(BYTE *)(c32Tsb0SAddr+cGbSetPgFailCh)=gGbSetPgFailCh;
            *(BYTE *)(c32Tsb0SAddr+cGbSetPgFailIntlvAddr)=gGbSetPgFailIntlvAddr;
            *(BYTE *)(c32Tsb0SAddr+cGbSetPgFailPlane)=gGbSetPgFailPlane;
        }
        else if(gsGbInfo.uGreyBoxOpt==cVopProgFailSetT2TGc)
        {
            g16GbGcCachebActThr=gsGcInfo.u16GcCachebActThr;
            g16GbTlcFullCachebGcThr=g16TlcFullCachebGcThr;
            gsGcInfo.u16GcCachebActThr=gsCacheInfo.u16SLCSpareCnt-gsGbInfo.uGreyBoxOpt;
            g16TlcFullCachebGcThr=0;
            g16CurrSlcCacheBlockThr=0;
        }
        else if(gsGbInfo.uGreyBoxOpt==cVopProgFailResetT2TGc)
        {
            gsGcInfo.u16GcCachebActThr=g16GbGcCachebActThr;
            g16TlcFullCachebGcThr=g16GbTlcFullCachebGcThr;
        }
        else
        {}
    }
    else if((gsGbInfo.uGreyBoxItem==cUGSDT2TID))
    {
        if(gsCacheInfo.u16FullCacheBlockCnt>3)
        {
            gsGbInfo.u32BkValue=gsGcInfo.u16GcCachebActThr|(g16TlcFullCachebGcThr<<16);

            if(gsCacheInfo.u16SLCSpareCnt>gsGcInfo.u16GcCachebActThr)
            {
                gsGcInfo.u16GcCachebActThr=gsCacheInfo.u16SLCSpareCnt-2;
                g16TlcFullCachebGcThr=2;
            }
            else
            {
                g16TlcFullCachebGcThr=2;
            }

            gsGbInfo.uResult=cSuccess;
            gGbGcSrcBlkCnt=0;
        }
        else
        {
            gsGbInfo.uResult=cFail;
        }
    }
    else if((gsGbInfo.uGreyBoxItem==cUGSDS2SID))
    {
        if(gsCacheInfo.u16FullCacheBlockCnt>3)
        {
            gsGbInfo.u32BkValue=gsGcInfo.u16GcCachebActThr;

            if(gsCacheInfo.u16SLCSpareCnt>gsGcInfo.u16GcCachebActThr)
            {
                gsGcInfo.u16GcCachebActThr=gsCacheInfo.u16SLCSpareCnt-5;
            }

            gsGbInfo.uResult=cSuccess;
            gGbGcSrcBlkCnt=0;
        }
        else
        {
            gsGbInfo.uResult=cFail;
        }
    }
    else if((gsGbInfo.uGreyBoxItem==cUGSDonEraseFail)&&
            ((gsGbInfo.uGreyBoxOpt==cVOpPopCacheSlcAfErase)||(gsGbInfo.uGreyBoxOpt==cVOpPopH2fTableAfErase)||
             (gsGbInfo.uGreyBoxOpt==cVOpPopWPROIDAfErase)))
    {
        gsGbInfo.u32BkValue=rmNvmeSubCmdParam3;
        g16GbFBlock=0;
    }
    else if((gsGbInfo.uGreyBoxItem==cUGSDonWearleveling)&&(gsGbInfo.uGreyBoxOpt!=cVOpNormal))
    {
        if(gsGbInfo.uGreyBoxOpt==cVOpProgLastF2H)
        {
            *(WORD *)(c32GreyBoxBuf+cGbInfoGcDesTLCBlock)=g16GbWLGcSrcTLCBlock;
            *(WORD *)(c32GreyBoxBuf+cGbInfoFBlock)=g16GbWLGcDesTLCBlock;
        }

        gsGbInfo.u32BkValue=g16MinStaticTlcCnt|(g16GbWLGcSrcTLCBlock<<16);
        g16WLCheckBlk=g16GbWLGcSrcTLCBlock-1;
        g16MinStaticTlcCnt=35;
        gsCacheInfo.u16DynamicAvgEraseCnt=(gsCacheInfo.u32DynamicTotalEraseCnt/g16MinStaticTlcCnt);
    }

    copyCcmVal((BYTE *)&garTsb0[0][0], (BYTE *)&gsGbInfo, sizeof(gsGbInfo));
    garTsb0[0x07][0x1F9]='G';
    garTsb0[0x07][0x1FA]='B';
    garTsb0[0x07][0x1FB]=' ';
    garTsb0[0x07][0x1FC]='T';
    garTsb0[0x07][0x1FD]='R';
    garTsb0[0x07][0x1FE]='I';
    garTsb0[0x07][0x1FF]='G';
    return cSuccess;
    // closeVendorCmdDebugInfo(cSuccess, cZero);
}    /* dataInVendorCmdGreyBoxTrig */

BYTE dataInVendorCmdGreyBoxDone()
{
    outCS(cbTagdataInVendorCmdGreyBoxDone);

    /* Recover and output result*/
    gsGbInfo.uGreyBoxItem=rmNvmeSubCmdParam1;
    gsGbInfo.uGreyBoxOpt=rmNvmeSubCmdParam2;
    gsGbInfo.u32BkValue=rmNvmeSubCmdParam3;

    if(gsGbInfo.uGreyBoxItem==cTabHdlH2fOnHmb)
    {
        WORD u16HblkLoop;

        for(u16HblkLoop=0; u16HblkLoop<g16TotalHBlock; u16HblkLoop++)
        {
            if((mChkHmbLink(u16HblkLoop))&&((*(BYTE *)(c32GreyBoxBuf+u16HblkLoop))!=cTrue))
            {
                /* GreyBox : H2f table on HMB is uncorrect.*/
                gsGbInfo.uResult=cFail;
            }
        }

        outInfo(cGbHmbInfo);
    }
    else if(gsGbInfo.uGreyBoxItem==cErrHdlReadRetry)
    {
        // garTsb0[0x00][0x00]=gsGbInfo.uResult;
    }
    else if((gsGbInfo.uGreyBoxItem==cTabHdlGcH2f)||(gsGbInfo.uGreyBoxItem==cUGSDGcH2fTableID))
    {
        gsGcInfo.uGcH2fTabbLoThr=(gsGbInfo.u32BkValue)&0x00FF;
        gsGcInfo.uGcH2fTabbHiThr=((gsGbInfo.u32BkValue)&0xFF00)>>8;
        gsGbInfo.u32BkValue=0;
        outSta(cVComplet);
    }
    else if(gsGbInfo.uGreyBoxItem==cGreyboxPreConditionID)
    {
        gsGcInfo.u16GcCachebActThr=gsGbInfo.u32BkValue;
        gsGbInfo.uResult=cSuccess;
    }
    else if((gsGbInfo.uGreyBoxItem==cGCS2TThree2OneFull)||(gsGbInfo.uGreyBoxItem==cGCS2TSixteen2OneFull)||
            (gsGbInfo.uGreyBoxItem==cGCS2TSixteen2OneNotFull)||(gsGbInfo.uGreyBoxItem==cGCPartialS2Tfour2OneFull)||
            (gsGbInfo.uGreyBoxItem==cGCS2SThirtytwo2OneNotFull))
    {
        g16GbCounter=0;
        *(WORD *)(c32Tsb0SAddr+cGbInfoGcDesTLCBlock)=g16GbGcDesTLCBlock;
        gsGbInfo.uResult=cSuccess;
        gsGcInfo.u16GcCachebActThr=g16GbGcCachebActThr;
    }
    else if((gsGbInfo.uGreyBoxItem==cGCT2TX2OneNotFull)||(gsGbInfo.uGreyBoxItem==cGCT2TX2OneFull)||
            (gsGbInfo.uGreyBoxItem==cGCT2TSixteen2OneMoreFull))
    {
        *(WORD *)(c32Tsb0SAddr+cGbInfoGcDesTLCBlock)=g16GbGcDesTLCBlock;
        gsGcInfo.u16GcCachebActThr=g16GbGcCachebActThr;
        g16TlcFullCachebGcThr=g16GbTlcFullCachebGcThr;
    }
    else if((gsGbInfo.uGreyBoxItem==cGreyboxPreConditionID)||(gsGbInfo.uGreyBoxItem==cUGSDS2TID)||(gsGbInfo.uGreyBoxItem==cUGSDReclaimID))
    {
        if(gsGbInfo.u32BkValue)
        {
            gsGcInfo.u16GcCachebActThr=gsGbInfo.u32BkValue;
        }

        gsGbInfo.uResult=cSuccess;
    }
    else if(gsGbInfo.uGreyBoxItem==cErrHdlReadUncInSlcDataID)
    {
        gReadErrinjectEn=cFalse;
        gsGcInfo.u16GcCachebActThr=g16GbGcCachebActThr;
    }
    else if(gsGbInfo.uGreyBoxItem==cErrHdlReadUncInTlcDataID)
    {
        gReadErrinjectEn=cFalse;
        *(WORD *)(c32Tsb0SAddr+cGbInfoGcDesTLCBlock)=g16GbGcDesTLCBlock;
        gsGcInfo.u16GcCachebActThr=g16GbGcCachebActThr;
        g16TlcFullCachebGcThr=g16GbTlcFullCachebGcThr;
        g16GbGcDesTLCBlock=0;
    }
    else if(gsGbInfo.uGreyBoxItem==cErrHdlGcFingerFailTestID)
    {
        gReadErrinjectEn=cFalse;
        gsGcInfo.u16GcCachebActThr=g16GbGcCachebActThr;
        gsGbInfo.u32BkValue=g32GbFingerFailBlk;
    }
    else if(gsGbInfo.uGreyBoxItem==cReadRetryDecodeTestID)
    {
        gReadErrinjectEn=cFalse;
    }
    else if(gsGbInfo.uGreyBoxItem==cFtlRuleReadReclaimID)
    {
        g16GbGetReclaimBlk=c16BitFF;
        g16GbSetReclaimBlk=cZero;
        *(WORD *)(c32Tsb0SAddr+cGbGetInfoReclaimBlk)=g16GbGetReclaimBlk;
        *(WORD *)(c32Tsb0SAddr+cGbSetInfoReclaimBlk)=g16GbSetReclaimBlk;

        gsGcInfo.u16GcCachebActThr=g16GbGcCachebActThr;
        g16TlcFullCachebGcThr=g16GbTlcFullCachebGcThr;
        g16GbGcDesTLCBlock=0;
    }
    else if(gsGbInfo.uGreyBoxItem==cRAIDEncOnH2fTab)
    {
        WORD u16ReadH2fOpt;
        u16ReadH2fOpt=c16Bit0|c16Bit4|c16Bit15;
        fillCcmVal((BYTE *)c32GreyBoxBuf, c32H2fTabRamSize, cZero);
        readH2fTable(c16Tsb0SIdx, (WORD)gsGbInfo.u32BkValue, u16ReadH2fOpt, cWaitReadDone);
        copyTsb2Sdram((BYTE *)c32GreyBoxBuf, (UCBYTE *)(cTsb0Addr), g32H2fTabFullSize);
        // copyTsb2Sdram((BYTE *)c32GreyBoxBuf, (UCBYTE *)(cTsb0Addr+c16RH2fTabSIdx*512), c32H2fTabRamSize);
    }
    else if(gsGbInfo.uGreyBoxItem==cRAIDDecOnH2fTab)
    {
        WORD u16ReadH2fOpt, u16FBlock;
        LWORD u32FPage;
        ADDRINFO usAddrInfo;
        u16ReadH2fOpt=c16Bit0|c16Bit4|c16Bit15;
        fillCcmVal((BYTE *)c32GreyBoxBuf, c32H2fTabRamSize, cZero);
        waitAllChCeBzCore0();
        enableLdpcPipe();
        readH2fTable(c16Tsb0SIdx, (WORD)gsGbInfo.u32BkValue, u16ReadH2fOpt, cWaitReadDone);
#if _EN_RAID_DECODE
        while(g32DecodeWait)
            ;
#endif
        waitAllChCeBzCore0();
        disableLdpcPipe();
        rstH2F1KInfo();
        copyTsb2Sdram((BYTE *)c32GreyBoxBuf, (UCBYTE *)(cTsb0Addr), c32H2fTabRamSize);
        // copyTsb2Sdram((BYTE *)c32GreyBoxBuf, (UCBYTE *)(cTsb0Addr+c16RH2fTabSIdx*512), c32H2fTabRamSize);

        gReadErrinjectEn=cFalse;
        gsGbInfo.uGreyBoxOpt=0x03;
        u16FBlock=g16arH2fTabBlk[mGetH2fTabBlkIndex((WORD)gsGbInfo.u32BkValue)];
        u32FPage=(LWORD)(mGetH2fTabPagePtr((WORD)gsGbInfo.u32BkValue))*gPage4kPerH2fTab;
        usAddrInfo.u16FBlock=u16FBlock;
        usAddrInfo.u32FPageNoTran=u32FPage;
        tranAddrInfo(&usAddrInfo);
        *(WORD *)(c32Tsb0SAddr+cGbInfoFBlock)=usAddrInfo.u16FBlock;
        *(WORD *)(c32Tsb0SAddr+cGbInfoCh)=usAddrInfo.uCh;
        *(WORD *)(c32Tsb0SAddr+cGbInfoDie)=usAddrInfo.uDieAddr;
        *(WORD *)(c32Tsb0SAddr+cGbInfoIntlv)=usAddrInfo.uIntlvAddr;
        *(WORD *)(c32Tsb0SAddr+cGbInfoFPage)=usAddrInfo.u16FPage;
        *(WORD *)(c32Tsb0SAddr+cGbInfoPlane)=usAddrInfo.uPlaneAddr;
    }
    else if(gsGbInfo.uGreyBoxItem==cRAIDDecOnH2f1kTab)
    {
#if _EN_RAID_DECODE
        while(g32DecodeWait)
            ;
#endif
        gReadErrinjectEn=cFalse;
        gsGbInfo.uGreyBoxOpt=0x03;
        *(WORD *)(c32Tsb0SAddr+cGbInfoFBlock)=g16GbFBlock;
        copyTsb2Sdram((BYTE *)c32GreyBoxBuf, (UCBYTE *)(cTsb0Addr+g16GbFBlock*512), 2*1024);
    }
    else if(gsGbInfo.uGreyBoxItem==cErrHdlE2EHostData)
    {
        *(LWORD *)(c32GreyBoxBuf+cGbInfoeE2eCmdRetryCnt)=g32PrdCommandRetryCnt;
        // gReadErrinjectEn=cFalse;
    }
    else if((gsGbInfo.uGreyBoxItem==cRAIDEncOnGc))
    {
/*
   *      LWORD u32Loop;
   *
   *      for(u32Loop=0; u32Loop<(gSectorPerPageH*3*g16TlcPartialParityNum); u32Loop+=cTsb0Size)
   *      {
   *          readHmbData(c16Tsb0SIdx,
   *                      cTsb0Size,
   *                      (cTsb0Size*u32Loop)<<9,
   *                      0,
   *                      cHmbGcPtCache,
   *                      cHmbTsbPath|cHmbReadDir, 0);
   *          mWaitHmbTransferDone();
   *          copyTsb2Sdram((BYTE *)(c32GreyBoxBuf+(u32Loop*cTsb0Size*512)), (UCBYTE *)(cTsb0Addr), cTsb0Size<<9);
   *      }
   */
        *(WORD *)(c32Tsb0SAddr+cGbInfoFBlock)=g16GbFBlock;
        *(WORD *)(c32Tsb0SAddr+cGbInfoCh)=gGbCh;
        *(WORD *)(c32Tsb0SAddr+cGbInfoCe)=gGbCe;
        *(WORD *)(c32Tsb0SAddr+cGbInfoDie)=gGbDieAddr;
        *(WORD *)(c32Tsb0SAddr+cGbInfoIntlv)=gGbIntlvAddr;
        *(WORD *)(c32Tsb0SAddr+cGbInfoFPage)=g16GbFPage;
        *(WORD *)(c32Tsb0SAddr+cGbInfoPlane)=gGbPlaneAddr;
        *(WORD *)(c32Tsb0SAddr+cGbTlcParity)=g16TlcPartialParityNum;
        gsGbInfo.uResult=cSuccess;
        gsGcInfo.u16GcCachebActThr=g16GbGcCachebActThr;
        gsGcInfo.u32GcCachebTime=g32GbGcCachebTime;
        gReadErrinjectEn=cFalse;
        outInfo(cGbGcInfo);
    }
    else if((gsGbInfo.uGreyBoxItem==cRAIDEncOnData))
    {
        *(WORD *)(c32Tsb0SAddr+cGbInfoFBlock)=g16GbFBlock;
        *(WORD *)(c32Tsb0SAddr+cGbInfoCh)=gGbCh;
        *(WORD *)(c32Tsb0SAddr+cGbInfoCe)=gGbCe;
        *(WORD *)(c32Tsb0SAddr+cGbInfoDie)=gGbDieAddr;
        *(WORD *)(c32Tsb0SAddr+cGbInfoIntlv)=gGbIntlvAddr;
        *(WORD *)(c32Tsb0SAddr+cGbInfoFPage)=g16GbFPage;
        *(WORD *)(c32Tsb0SAddr+cGbInfoPlane)=gGbPlaneAddr;
        *(WORD *)(c32Tsb0SAddr+cGbTlcParity)=g16SlcPartialParityNum;
        gReadErrinjectEn=cFalse;
    }
    else if((gsGbInfo.uGreyBoxItem==cRAIDDecOnNormData)||(gsGbInfo.uGreyBoxItem==cRAIDDecOnOpenData)||
            ((gsGbInfo.uGreyBoxItem==cSecurityRW)&&(gsGbInfo.uGreyBoxOpt==cVOpSecurityRAID)))
    {
        gReadErrinjectEn=cFalse;
        gsGbInfo.uGreyBoxOpt=0x03;
#if _EN_RAID_DECODE
        while(g32DecodeWait)
            ;
#endif
    }
    else if((gsGbInfo.uGreyBoxItem==cRAIDDecOnPreReadData)||(gsGbInfo.uGreyBoxItem==cRAIDDecOnLastReadData))
    {
        // copyTsb2Sdram((BYTE *)c32GreyBoxBuf, (UCBYTE *)(cTsb0Addr+g16GbGcCachebActThr*512), 2*1024);
        gReadErrinjectEn=cFalse;
        gsGbInfo.uGreyBoxOpt=0x03;
#if _EN_RAID_DECODE
        while(g32DecodeWait)
            ;
#endif
    }
    else if((gsGbInfo.uGreyBoxItem==cRAIDDecOnMoveReadData))
    {
        gReadErrinjectEn=cFalse;
        gsGbInfo.uGreyBoxOpt=0x03;
        gsGbInfo.uResult=cSuccess;
        gsGcInfo.u16GcCachebActThr=g16GbGcCachebActThr;
        gsGcInfo.u32GcCachebTime=g32GbGcCachebTime;
#if _EN_RAID_DECODE
        while(g32DecodeWait)
            ;
#endif
    }
    else if(gsGbInfo.uGreyBoxItem==cErrHdlEraseFID)
    {
        gsGbInfo.uResult=cSuccess;
        *(WORD *)(c32Tsb0SAddr+cGbInfoFBlock)=g16GbFBlock;
    }
    else if(gsGbInfo.uGreyBoxItem==cWearleveingRule)
    {
        g16MinStaticTlcCnt=g16GbSlcMoSkipCnt;
        gsCacheInfo.u16DynamicAvgEraseCnt=(gsCacheInfo.u32DynamicTotalEraseCnt/g16MinStaticTlcCnt);
    }
    else if((gsGbInfo.uGreyBoxItem==cErrHdlProgCacheBlk)||(gsGbInfo.uGreyBoxItem==cErrHdlProgWPROID)||
            (gsGbInfo.uGreyBoxItem==cErrHdlProgH2fTableID)||(gsGbInfo.uGreyBoxItem==cErrHdlProgS2TGcDesID)||
            (gsGbInfo.uGreyBoxItem==cErrHdlProgT2TGcDesID)||(gsGbInfo.uGreyBoxItem==cErrHdlProgS2SGcDesID))
    {
        g16GbSetPgFailFpage=c16BitFF;
        gGbSetPgFailCh=cBitFF;
        gGbSetPgFailIntlvAddr=cBitFF;
        gGbSetPgFailPlane=cBitFF;
        g16GbGetPgFailFblk=c16BitFF;
        g16GbGetPgFailFblkAfterDiffFblock=c16BitFF;
        g16GbGetPgFailFblkNowDiffFblk=c16BitFF;
        gGbSetPgFailCase=cBitFF;

        if(gGbEnCacheProg)
        {
            mSetFLOption(cEnCacheProg);
        }
    }
    else if((gsGbInfo.uGreyBoxItem==cUGSDT2TID))
    {
        if(gsGbInfo.u32BkValue)
        {
            gsGcInfo.u16GcCachebActThr=gsGbInfo.u32BkValue&0x0000FFFF;
            g16TlcFullCachebGcThr=(gsGbInfo.u32BkValue>>16);
        }

        gsGbInfo.uResult=cSuccess;
    }
    else if((gsGbInfo.uGreyBoxItem==cUGSDS2SID))
    {
        gsGcInfo.u16GcCachebActThr=gsGbInfo.u32BkValue;
        gsGbInfo.uResult=cSuccess;
    }
    else if((gsGbInfo.uGreyBoxItem==cUGSDonEraseFail)&&
            ((gsGbInfo.uGreyBoxOpt==cVOpPopCacheSlcAfErase)||(gsGbInfo.uGreyBoxOpt==cVOpPopH2fTableAfErase)||
             (gsGbInfo.uGreyBoxOpt==cVOpPopWPROIDAfErase)))
    {
        g16GbFBlock=0;
    }
    else if(gsGbInfo.uGreyBoxItem==cUGSDonWearleveling)
    {
        g16WLCheckBlk=(gsGbInfo.u32BkValue>>16);
        g16MinStaticTlcCnt=gsGbInfo.u32BkValue&0x0000FFFF;
        gsCacheInfo.u16DynamicAvgEraseCnt=(gsCacheInfo.u32DynamicTotalEraseCnt/g16MinStaticTlcCnt);
    }
    else if((gsGbInfo.uGreyBoxItem==cSecurityRW)&&(gsGbInfo.uGreyBoxOpt==cVOpSecurityGC))
    {
        gsGbInfo.uResult=cSuccess;
        gsGcInfo.u16GcCachebActThr=g16GbGcCachebActThr;
    }

    copyCcmVal((BYTE *)&garTsb0[0][0], (BYTE *)&gsGbInfo, sizeof(gsGbInfo));

    // clear GbInfo
    fillCcmVal((BYTE *)&gsGbInfo, sizeof(gsGbInfo), cZero);

    garTsb0[0x07][0x1F9]='G';
    garTsb0[0x07][0x1FA]='B';
    garTsb0[0x07][0x1FB]=' ';
    garTsb0[0x07][0x1FC]='D';
    garTsb0[0x07][0x1FD]='O';
    garTsb0[0x07][0x1FE]='N';
    garTsb0[0x07][0x1FF]='E';
    return cSuccess;
}    /* dataInVendorCmdGreyBoxDone */

BYTE dataInVendorCmdGreyBoxInit()
{
    outCS(cbTagdataInVendorCmdGreyBoxInit);
    copyCcmVal((BYTE *)&gsGbInfo, (BYTE *)&garTsb0[0][0], sizeof(gsGbInfo));
    copyCcmVal((BYTE *)(gsGbInfo.upParaTab), (BYTE *)garParaPageId, cParaSize);
    gGreyBoxUartEn=rmNvmeSubCmdParam1;
    return cSuccess;
}

BYTE dataInVendorCmdGreyBoxModifyEraseCnt()
{
    insertVendorTask(cVendorCore1ModifyEraseCnt);
    return cSuccess;
}

BYTE dataInVendorCmdGreyBoxMarkBadBlock()
{
    insertVendorTask(cVendorCore1MarkBadBlock);
    return cSuccess;
}

BYTE dataInVendorCmdIdGreyBoxFwUniTestOut()
{
    LWORD u32UtFunc=rmNvmeSubCmdParam1;
    LWORD u32UtItem=rmNvmeSubCmdParam2;
    LWORD u32UtCase=rmNvmeSubCmdParam3;

    bopClrRam(c32Tsb0SAddr, 0x1000, 0, cClrTsb|cBopWait);

    return cSuccess;
}    /* dataInVendorCmdIdGreyBoxFwUniTestOut */

BYTE dataInVendorCmdGreyBoxGetFwDefPara()
{
    WORD u16FwNowOffset=0;
    WORD u16Loop=0;

    copyCcmVal((BYTE *)garTsb0, (BYTE *)cParaAddr, cSizeOfParaTab);
    u16FwNowOffset+=cSizeOfParaTab;

    *(LWORD *)(c32Tsb0SAddr+u16FwNowOffset)=0x87654321;
    u16FwNowOffset+=4;
    *(WORD *)(c32Tsb0SAddr+u16FwNowOffset)=0x1234;
    u16FwNowOffset+=2;
    *(BYTE *)(c32Tsb0SAddr+u16FwNowOffset)=0x5A;
    u16FwNowOffset+=1;

    for(u16Loop=0; u16Loop<16; u16Loop++)
    {
        *(WORD *)(c32Tsb0SAddr+u16FwNowOffset)=0x5001+u16Loop;
        u16FwNowOffset+=2;
    }

    *(LWORD *)(c32Tsb0SAddr+u16FwNowOffset)=g16PagePerBlock1*gIntlvWay*gPlaneNum*gTotalChNum;
    u16FwNowOffset+=4;

    *(BYTE *)(c32Tsb0SAddr+u16FwNowOffset+0)='F';
    *(BYTE *)(c32Tsb0SAddr+u16FwNowOffset+1)='W';
    *(BYTE *)(c32Tsb0SAddr+u16FwNowOffset+2)='D';
    *(BYTE *)(c32Tsb0SAddr+u16FwNowOffset+3)='E';
    *(BYTE *)(c32Tsb0SAddr+u16FwNowOffset+4)='F';
    *(BYTE *)(c32Tsb0SAddr+u16FwNowOffset+5)='P';
    *(BYTE *)(c32Tsb0SAddr+u16FwNowOffset+6)='A';
    *(BYTE *)(c32Tsb0SAddr+u16FwNowOffset+7)='R';
    return cSuccess;
}    /* dataInVendorCmdGreyBoxGetFwDefPara */

BYTE dataInVendorCmdGreyBoxSaveQBInfo()
{
    outCS(cbTagdataInVendorCmdGreyBoxSaveQBInfo);
    BYTE uQBootType=(BYTE)rmNvmeSubCmdParam1;
    saveQBInfo(uQBootType);
    // callCore1Task(cTskInitRaidEngine);
    return cSuccess;
}    /* dataInVendorCmdGreyBoxSaveQBInfo */

BYTE dataInVendorCmdGreyBoxSecurityRW()
{
    gMBRShadow=0;
    gbEnTCG=gbEnATAPassThrough=gbEnRpmb=gbEnAes=0;
    gInSecApi=1;

    if(gsGbInfo.uGreyBoxOpt==cVOpSecurityW)
    {
        gsGbInfo.u32BkValue=g32HostXfrCnt;
        SecIntf_TCG_Write(0);
        g32HostXfrCnt=gsGbInfo.u32BkValue;
    }
    else if(gsGbInfo.uGreyBoxOpt&0x01)
    {
        gsGbInfo.u32BkValue=g32HostXfrCnt;
        SecIntf_TCG_Read(0);
        copyTsb2Sdram((BYTE *)c32GreyBoxBuf, (UCBYTE *)(cTsb0Addr), (g32HostXfrCnt<<cSingleSectorShift));
        g32HostXfrCnt=gsGbInfo.u32BkValue;
    }

    gInSecApi=0;

    copyCcmVal((BYTE *)&garTsb0[0][0], (BYTE *)&gsGbInfo, sizeof(gsGbInfo));
    return cSuccess;
}    /* dataInVendorCmdGreyBoxSecurityRW */

BYTE getH2fTabBlkInfo(WORD u16FBlock, WORD u16FPage)
{
    BLKSPRINFO usBlkSprInfo;
    ADDRINFO usTmpAddrInfo;
    WORD u16BufPtr=c16Tsb0SIdx+g16H2fTabSctrSize;
    BYTE uPageOfst, uPlaneAddr;
    volatile BYTE uStop=0;
    WORD u16NowSrcAddrIdx;

    rstUNCStsCore0();

    for(uPageOfst=0; uPageOfst<gTotalPlaneOfH2fTab; uPageOfst+=gPlaneNum)
    {
        usTmpAddrInfo.u16FBlock=u16FBlock;
        usTmpAddrInfo.u32FPageNoTran=((LWORD)(u16FPage<<gsCacheInfo.uH2fTabProgSlotShift)+uPageOfst)*g4kNumPerPlane;
        tranAddrInfo(&usTmpAddrInfo);
        setFLAddrActCh(usTmpAddrInfo.uCh, &usTmpAddrInfo);
        gSectorH=0;
        mSetFRwParam(u16BufPtr, gSectorPerPageH, c16Bit0|c16Bit4|c16Bit5|c16Bit10|c16Bit14|c16Bit15, cReadData);
        u16NowSrcAddrIdx=gsRwCtrl.uarFreeSrcQue[gsRwCtrl.u32FreeSrcFifoHead];
        gpFlashAddrInfo->uTsb4kIdx=0xFF;
        copyCcmVal((BYTE *)&garSrcAddrInfo[u16NowSrcAddrIdx], (BYTE *)gpFlashAddrInfo, sizeof(ADDRINFO));
        gsRwCtrl.u32FreeSrcFifoHead=(gsRwCtrl.u32FreeSrcFifoHead+1)&(cReadFifoDpt-1);
        waitCmdAllDone(cWaitTrigRCnt|cWaitCmdBz);

        if(!gPlaneUNCSts[usTmpAddrInfo.uCh])
        {
            for(uPlaneAddr=0; uPlaneAddr<gPlaneNum; uPlaneAddr++)
            {
                getSprByte(&usBlkSprInfo, uPlaneAddr);

                if((mGetMetaBlockId(usBlkSprInfo)!=cH2fTableID))
                {
                    uStop=1;

                    while(uStop)
                        ;
                }

                if(mGetMetaH2fPgPtr(usBlkSprInfo)!=u16FPage)
                {
                    uStop=1;

                    while(uStop)
                        ;
                }
            }

            u16BufPtr+=gSectorPerPageH;
        }
        else
        {
            return cFalse;
        }
    }

    return cTrue;
}    /* getH2fTabBlkPageInfo */

BYTE dataInVendorCmdGreyBoxReadH2fTab()
{
    LWORD u32Value;
    WORD u16Hblock;

    u32Value=rmNvmeSubCmdParam3;

    if(u32Value&c32Bit31)
    {
        resetRam((BYTE *)c32GreyBoxBuf, cGreyBoxBufSize, cZero);
        copyTsb2Sdram((BYTE *)c32GreyBoxBuf, (BYTE *)&g32arCacheBlkVpCnt[0], g16TotalFBlock*4);
    }
    else if(u32Value&c32Bit30)
    {
        resetRam((BYTE *)c32GreyBoxBuf, cGreyBoxBufSize, cZero);
        copyTsb2Sdram((BYTE *)c32GreyBoxBuf, (BYTE *)&g16arH2fTabPtr[0], g16TotalHBlock*2);
    }
    else
    {
        u16Hblock=rmNvmeSubCmdParam3;
        resetRam((BYTE *)c32GreyBoxBuf, cGreyBoxBufSize, cZero);

        bopClrRam(c32Tsb0SAddr, c32Tsb0SizeByte, 0x00000000, cClrTsb|cBopWait);

        if(g16arH2fTabPtr[u16Hblock]!=c16H2FTabInitValue)
        {
            if(mChkHmbLink(u16Hblock))
            {
#if ((!(_PRJ_BOOT||_PRJ_BOOT2))||_ICE_LOAD_ALL)
                waitHmbPrdDone();
#endif
                getH2fTabBlkInfo(g16arH2fTabBlk[mGetH2fTabBlkIndex(g16TotalHBlock+mGetHmbLink(u16Hblock))],
                                 mGetH2fTabPagePtr(g16TotalHBlock+mGetHmbLink(u16Hblock)));
            }
            else
            {
                getH2fTabBlkInfo(g16arH2fTabBlk[mGetH2fTabBlkIndex(u16Hblock)], mGetH2fTabPagePtr(u16Hblock));
            }

            while(rmChkHdmaBz)
                ;
        }

        copyTsb2Sdram((BYTE *)c32GreyBoxBuf, (UCBYTE *)c32H2f0SAddr, g32H2fTabValidSize);
    }

    return cSuccess;
}    /* dataInVendorCmdGreyBoxReadH2fTab */

#endif/* if _GREYBOX */
#endif    // (_PRJ_SMIVU)







